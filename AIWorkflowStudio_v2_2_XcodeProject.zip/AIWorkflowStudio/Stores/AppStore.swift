import Foundation
import SwiftUI

struct AppAlert: Identifiable, Hashable {
    let id = UUID()
    var title: String
    var message: String
}

@MainActor
final class AppStore: ObservableObject {
    @Published var projects: [WorkflowProject] = []
    @Published var apiConfigs: [APIProviderConfig] = [] { didSet { saveAPIConfigs() } }
    @Published var runRecords: [RunRecord] = [] { didSet { saveRunRecords() } }
    @Published var snapshots: [VersionSnapshot] = [] { didSet { saveSnapshots() } }
    @Published var settings: AppSettings = AppSettings() { didSet { saveSettings() } }
    @Published var selectedProjectID: UUID?
    @Published var activeRunID: UUID?
    @Published var isAutoBuilding = false
    @Published var autoBuildProgress: Double = 0
    @Published var autoBuildMessage = ""
    @Published var appAlert: AppAlert?
    @Published var cacheSizeText: String = "计算中"

    let aiClient = AIClient()
    let engine = WorkflowEngine()
    private var activeRunTask: Task<Void, Never>?
    private var runWatchdogTask: Task<Void, Never>?
    private var undoStacks: [UUID: [WorkflowProject]] = [:]
    private var redoStacks: [UUID: [WorkflowProject]] = [:]

    init() {
        loadAll()
        if projects.isEmpty {
            let starter = WorkflowProject.blank(title: "AI 工作流项目")
            projects = [starter]
            selectedProjectID = starter.id
            saveProjects()
        } else {
            selectedProjectID = projects.first?.id
        }
        refreshCacheSize()
    }

    var selectedProject: WorkflowProject? {
        guard let selectedProjectID else { return projects.first }
        return projects.first(where: { $0.id == selectedProjectID }) ?? projects.first
    }

    var selectedProjectRunRecords: [RunRecord] {
        guard let id = selectedProject?.id else { return [] }
        return runRecords.filter { $0.projectID == id }
    }

    var selectedProjectSnapshots: [VersionSnapshot] {
        guard let id = selectedProject?.id else { return [] }
        return snapshots.filter { $0.projectID == id }
    }

    var selectedProjectActiveRun: RunRecord? {
        guard let projectID = selectedProject?.id else { return nil }
        if let id = activeRunID, let run = runRecords.first(where: { $0.id == id && $0.projectID == projectID }) { return run }
        return runRecords.first(where: { $0.projectID == projectID })
    }

    var canUndoSelectedProject: Bool {
        guard let id = selectedProject?.id else { return false }
        return !(undoStacks[id]?.isEmpty ?? true)
    }

    var canRedoSelectedProject: Bool {
        guard let id = selectedProject?.id else { return false }
        return !(redoStacks[id]?.isEmpty ?? true)
    }

    private func pushUndoSnapshot(projectID: UUID) {
        guard let project = projects.first(where: { $0.id == projectID }) else { return }
        var stack = undoStacks[projectID] ?? []
        stack.append(project)
        if stack.count > 80 { stack.removeFirst(stack.count - 80) }
        undoStacks[projectID] = stack
        redoStacks[projectID] = []
    }

    func undoSelectedProject() {
        guard let projectID = selectedProject?.id,
              var undo = undoStacks[projectID],
              let previous = undo.popLast(),
              let index = projects.firstIndex(where: { $0.id == projectID }) else { return }
        var redo = redoStacks[projectID] ?? []
        redo.append(projects[index])
        redoStacks[projectID] = redo
        undoStacks[projectID] = undo
        projects[index] = previous
        saveProjects()
    }

    func redoSelectedProject() {
        guard let projectID = selectedProject?.id,
              var redo = redoStacks[projectID],
              let next = redo.popLast(),
              let index = projects.firstIndex(where: { $0.id == projectID }) else { return }
        var undo = undoStacks[projectID] ?? []
        undo.append(projects[index])
        undoStacks[projectID] = undo
        redoStacks[projectID] = redo
        projects[index] = next
        saveProjects()
    }

    func createProject(title: String = "新工作流") {
        let project = WorkflowProject.blank(title: title)
        projects.insert(project, at: 0)
        selectedProjectID = project.id
        saveProjects()
    }

    func deleteProject(_ project: WorkflowProject) {
        projects.removeAll { $0.id == project.id }
        runRecords.removeAll { $0.projectID == project.id }
        snapshots.removeAll { $0.projectID == project.id }
        if selectedProjectID == project.id { selectedProjectID = projects.first?.id }
        saveProjects()
    }

    func updateProject(_ project: WorkflowProject) {
        guard let index = projects.firstIndex(where: { $0.id == project.id }) else { return }
        var updated = project
        updated.updatedAt = Date()
        projects[index] = updated
        saveProjects()
    }

    func updatePrompt(projectID: UUID, prompt: String, autoSelect: Bool) {
        guard var project = projects.first(where: { $0.id == projectID }) else { return }
        project.userPrompt = prompt
        project.autoSelectModules = autoSelect
        updateProject(project)
    }

    func autoBuildSelectedProject() {
        startAutoBuildSelectedProject()
    }

    func startAutoBuildSelectedProject() {
        guard let project = selectedProject else { return }
        let trimmed = project.userPrompt.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else {
            appAlert = AppAlert(title: "需要先填写提示词", message: "请打开开始模块，填写这次工作流要完成的任务/要求，然后再使用 AI 自动选择模块。")
            return
        }

        Task { [weak self] in
            await self?.autoBuildSelectedProjectWithAI(projectID: project.id)
        }
    }

    private func autoBuildSelectedProjectWithAI(projectID: UUID) async {
        guard var project = projects.first(where: { $0.id == projectID }) else { return }
        isAutoBuilding = true
        autoBuildProgress = 0.08
        autoBuildMessage = "正在读取开始模块提示词"
        defer {
            isAutoBuilding = false
            autoBuildProgress = 0
            autoBuildMessage = ""
        }

        var preferredKinds: [WorkflowNodeKind]? = nil
        autoBuildProgress = 0.22
        autoBuildMessage = "正在调用默认文本模型规划模块"

        if let resolved = defaultTextResolution(),
           let config = apiConfigs.first(where: { $0.id == resolved.providerID }),
           let apiKey = try? KeychainService.read(account: config.keychainAccount),
           !apiKey.isEmpty {
            do {
                let prompt = WorkflowAutoBuilder.aiPlannerPrompt(for: project)
                let response = try await aiClient.completeText(
                    baseURL: config.baseURL,
                    apiKey: apiKey,
                    model: resolved.modelID,
                    messages: [AIMessage(role: "system", content: "你是工作流架构师，只输出适合的模块类型列表。"), AIMessage(role: "user", content: prompt)],
                    maxTokens: 900,
                    temperature: 0.2,
                    timeoutSeconds: 90
                )
                preferredKinds = WorkflowAutoBuilder.parseKinds(from: response.text)
                autoBuildProgress = 0.72
                autoBuildMessage = "AI 已返回模块方案，正在生成连线"
            } catch {
                appAlert = AppAlert(title: "AI 自动选择失败，已使用本地规则", message: error.localizedDescription)
                preferredKinds = nil
            }
        } else {
            appAlert = AppAlert(title: "未配置默认文本模型", message: "已使用本地规则生成工作流。要让 AI 根据提示词选择模块，请先在设置页配置全局默认文本模型。")
        }

        pushUndoSnapshot(projectID: project.id)
        project = WorkflowAutoBuilder.build(from: project, preferredKinds: preferredKinds)
        applyDefaultModels(to: &project)
        updateProject(project)
        autoBuildProgress = 1
        autoBuildMessage = "工作流已生成"
    }

    func addNode(_ kind: WorkflowNodeKind, to projectID: UUID, near preferredPoint: CGPoint? = nil) {
        guard var project = projects.first(where: { $0.id == projectID }) else { return }
        pushUndoSnapshot(projectID: projectID)
        let point = nextVisiblePoint(for: project, preferredPoint: preferredPoint)
        var node = WorkflowNode(kind: kind, title: kind.title, x: Double(point.x), y: Double(point.y))
        node.prompt = kind == .custom ? "" : kind.defaultPrompt
        node.retryLimit = settings.maxReturnCount
        node.maxReturnCount = settings.maxReturnCount
        if kind == .codeWorker { node.timeoutSeconds = 180 }
        applyDefaultModel(to: &node)
        project.nodes.append(node)
        updateProject(project)
    }

    private func nextVisiblePoint(for project: WorkflowProject, preferredPoint: CGPoint? = nil) -> CGPoint {
        if let preferredPoint {
            let offset = CGFloat(project.nodes.count % 5) * 26
            return CGPoint(x: max(preferredPoint.x + offset, 160), y: max(preferredPoint.y + offset, 160))
        }
        let count = CGFloat(project.nodes.count)
        let x = 220 + (count.truncatingRemainder(dividingBy: 4)) * 260
        let y = 220 + floor(count / 4) * 170
        return CGPoint(x: min(max(x, 160), 1100), y: min(max(y, 160), 760))
    }

    func removeNode(projectID: UUID, nodeID: UUID) {
        guard var project = projects.first(where: { $0.id == projectID }) else { return }
        pushUndoSnapshot(projectID: projectID)
        project.nodes.removeAll { $0.id == nodeID && $0.kind != .start && $0.kind != .output }
        project.edges.removeAll { $0.from == nodeID || $0.to == nodeID }
        updateProject(project)
    }

    func duplicateNode(projectID: UUID, nodeID: UUID) -> UUID? {
        guard var project = projects.first(where: { $0.id == projectID }),
              let original = project.nodes.first(where: { $0.id == nodeID }),
              original.kind != .start,
              original.kind != .output else { return nil }
        pushUndoSnapshot(projectID: projectID)
        var copy = original
        copy.id = UUID()
        copy.title = original.title + " 副本"
        copy.x += 34
        copy.y += 34
        copy.status = .waiting
        copy.lastOutput = ""
        project.nodes.append(copy)
        updateProject(project)
        return copy.id
    }

    func pasteNode(_ node: WorkflowNode, to projectID: UUID, near preferredPoint: CGPoint? = nil) -> UUID? {
        guard var project = projects.first(where: { $0.id == projectID }) else { return nil }
        pushUndoSnapshot(projectID: projectID)
        var copy = node
        copy.id = UUID()
        copy.title = node.title + " 副本"
        if let preferredPoint {
            copy.x = Double(max(preferredPoint.x, 160))
            copy.y = Double(max(preferredPoint.y, 160))
        } else {
            copy.x += 42
            copy.y += 42
        }
        copy.status = .waiting
        copy.lastOutput = ""
        project.nodes.append(copy)
        updateProject(project)
        return copy.id
    }

    func updateNode(_ node: WorkflowNode, in projectID: UUID) {
        guard var project = projects.first(where: { $0.id == projectID }) else { return }
        guard let index = project.nodes.firstIndex(where: { $0.id == node.id }) else { return }
        pushUndoSnapshot(projectID: projectID)
        project.nodes[index] = node
        updateProject(project)
    }

    func moveNode(projectID: UUID, nodeID: UUID, x: Double, y: Double, persist: Bool = true) {
        guard let projectIndex = projects.firstIndex(where: { $0.id == projectID }) else { return }
        guard let nodeIndex = projects[projectIndex].nodes.firstIndex(where: { $0.id == nodeID }) else { return }
        if persist { pushUndoSnapshot(projectID: projectID) }
        let clampedX = max(x, 120)
        let clampedY = max(y, 100)
        objectWillChange.send()
        projects[projectIndex].nodes[nodeIndex].x = clampedX
        projects[projectIndex].nodes[nodeIndex].y = clampedY
        projects[projectIndex].updatedAt = Date()
        if persist { saveProjects() }
    }

    func moveNodes(projectID: UUID, positions: [UUID: CGPoint], persist: Bool = true) {
        guard let projectIndex = projects.firstIndex(where: { $0.id == projectID }) else { return }
        if persist { pushUndoSnapshot(projectID: projectID) }
        objectWillChange.send()
        for (id, point) in positions {
            guard let nodeIndex = projects[projectIndex].nodes.firstIndex(where: { $0.id == id }) else { continue }
            projects[projectIndex].nodes[nodeIndex].x = Double(max(point.x, 120))
            projects[projectIndex].nodes[nodeIndex].y = Double(max(point.y, 100))
        }
        projects[projectIndex].updatedAt = Date()
        if persist { saveProjects() }
    }

    func removeNodes(projectID: UUID, nodeIDs: Set<UUID>) {
        guard var project = projects.first(where: { $0.id == projectID }) else { return }
        let removable = Set(project.nodes.filter { nodeIDs.contains($0.id) && $0.kind != .start && $0.kind != .output }.map(\.id))
        guard !removable.isEmpty else { return }
        pushUndoSnapshot(projectID: projectID)
        project.nodes.removeAll { removable.contains($0.id) }
        project.edges.removeAll { removable.contains($0.from) || removable.contains($0.to) }
        updateProject(project)
    }

    func pasteNodes(_ nodes: [WorkflowNode], to projectID: UUID, near preferredPoint: CGPoint? = nil) -> Set<UUID> {
        guard var project = projects.first(where: { $0.id == projectID }) else { return [] }
        let copyable = nodes.filter { $0.kind != .start && $0.kind != .output }
        guard !copyable.isEmpty else { return [] }
        pushUndoSnapshot(projectID: projectID)
        let minX = copyable.map(\.x).min() ?? 0
        let minY = copyable.map(\.y).min() ?? 0
        let anchor = preferredPoint ?? CGPoint(x: 260, y: 260)
        var newIDs = Set<UUID>()
        for original in copyable {
            var copy = original
            copy.id = UUID()
            copy.title = original.title + " 副本"
            copy.x = Double(anchor.x) + (original.x - minX)
            copy.y = Double(anchor.y) + (original.y - minY)
            copy.status = .waiting
            copy.lastOutput = ""
            newIDs.insert(copy.id)
            project.nodes.append(copy)
        }
        updateProject(project)
        return newIDs
    }

    func connect(projectID: UUID, from: UUID, to: UUID, condition: EdgeCondition = .always) {
        guard var project = projects.first(where: { $0.id == projectID }) else { return }
        guard from != to else { return }
        guard !project.edges.contains(where: { $0.from == from && $0.to == to && $0.condition == condition }) else { return }
        pushUndoSnapshot(projectID: projectID)
        project.edges.append(WorkflowEdge(from: from, to: to, condition: condition))
        updateProject(project)
    }

    func removeEdge(projectID: UUID, edgeID: UUID) {
        guard var project = projects.first(where: { $0.id == projectID }) else { return }
        pushUndoSnapshot(projectID: projectID)
        project.edges.removeAll { $0.id == edgeID }
        updateProject(project)
    }

    func removeAllEdges(projectID: UUID) {
        guard var project = projects.first(where: { $0.id == projectID }) else { return }
        pushUndoSnapshot(projectID: projectID)
        project.edges.removeAll()
        updateProject(project)
    }

    func resetWorkflow(projectID: UUID) {
        guard var project = projects.first(where: { $0.id == projectID }) else { return }
        pushUndoSnapshot(projectID: projectID)
        let blank = WorkflowProject.blank(title: project.title)
        project.nodes = blank.nodes
        project.edges = []
        project.resources = []
        updateProject(project)
    }

    func applyDefaultModelsToSelectedProject() {
        guard let project = selectedProject else { return }
        applyDefaultModels(to: project.id)
    }

    func applyDefaultModels(to projectID: UUID) {
        guard let projectIndex = projects.firstIndex(where: { $0.id == projectID }) else { return }
        pushUndoSnapshot(projectID: projectID)
        objectWillChange.send()
        for nodeIndex in projects[projectIndex].nodes.indices {
            let kind = projects[projectIndex].nodes[nodeIndex].kind
            guard kind != .start && kind != .output else { continue }
            guard let resolved = resolvedGlobalDefault(for: kind) else { continue }
            projects[projectIndex].nodes[nodeIndex].providerID = resolved.providerID
            projects[projectIndex].nodes[nodeIndex].modelID = resolved.modelID
        }
        projects[projectIndex].updatedAt = Date()
        saveProjects()
    }

    func addAPIConfig(_ config: APIProviderConfig, apiKey: String) {
        apiConfigs.append(config)
        try? KeychainService.save(apiKey, account: config.keychainAccount)
        seedGlobalDefaultsIfEmpty(providerID: config.id, models: config.models)
    }

    func updateAPIConfig(_ config: APIProviderConfig, apiKey: String?) {
        guard let index = apiConfigs.firstIndex(where: { $0.id == config.id }) else { return }
        apiConfigs[index] = config
        if let apiKey, !apiKey.isEmpty {
            try? KeychainService.save(apiKey, account: config.keychainAccount)
        }
    }

    func deleteAPIConfig(_ config: APIProviderConfig) {
        apiConfigs.removeAll { $0.id == config.id }
        try? KeychainService.delete(account: config.keychainAccount)
    }

    func refreshModels(for config: APIProviderConfig) async throws {
        let key = try KeychainService.read(account: config.keychainAccount)
        let models = try await aiClient.fetchModels(baseURL: config.baseURL, apiKey: key)
        var updated = config
        updated.models = models
        updateAPIConfig(updated, apiKey: nil)
        seedGlobalDefaultsIfEmpty(providerID: config.id, models: models)
    }

    func seedGlobalDefaultsIfEmpty(providerID: UUID, models: [AIModelInfo]) {
        guard let first = models.first?.id else { return }
        if settings.defaultTextProviderID == nil || settings.defaultTextModelID?.isEmpty != false {
            settings.defaultTextProviderID = providerID
            settings.defaultTextModelID = first
        }
        if settings.defaultVisionProviderID == nil || settings.defaultVisionModelID?.isEmpty != false {
            settings.defaultVisionProviderID = providerID
            settings.defaultVisionModelID = models.first(where: { $0.supportsVision })?.id ?? first
        }
        if settings.defaultImageProviderID == nil || settings.defaultImageModelID?.isEmpty != false {
            settings.defaultImageProviderID = providerID
            settings.defaultImageModelID = models.first(where: { $0.supportsImageGeneration })?.id ?? first
        }
        if settings.defaultCodeProviderID == nil || settings.defaultCodeModelID?.isEmpty != false {
            settings.defaultCodeProviderID = providerID
            settings.defaultCodeModelID = first
        }
        if settings.defaultReviewerProviderID == nil || settings.defaultReviewerModelID?.isEmpty != false {
            settings.defaultReviewerProviderID = providerID
            settings.defaultReviewerModelID = first
        }
    }

    func startSelectedProjectRun() {
        guard activeRunTask == nil else { return }
        activeRunTask = Task { [weak self] in
            await self?.runSelectedProject()
            await MainActor.run {
                self?.activeRunTask = nil
                self?.stopRunWatchdog()
            }
        }
    }

    func stopActiveRun() {
        activeRunTask?.cancel()
        activeRunTask = nil
        stopRunWatchdog()
        guard let id = activeRunID, let index = runRecords.firstIndex(where: { $0.id == id }) else { return }
        runRecords[index].status = .cancelled
        runRecords[index].endedAt = Date()
        runRecords[index].currentNodeIDs = []
        runRecords[index].currentStage = "用户已停止"
        runRecords[index].diagnosticMessage = "运行已被用户手动停止。"
        runRecords[index].lastLogAt = Date()
        runRecords[index].logs.append(RunLogEntry(level: .warning, message: "用户点击停止运行"))
    }

    func runSelectedProject() async {
        guard let project = selectedProject else { return }
        let trimmed = project.userPrompt.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else {
            appAlert = AppAlert(title: "不能运行", message: "开始模块里的提示词/要求为空。请先填写任务目标，再运行工作流。")
            return
        }


        let estimate = TokenEstimator.estimate(project: project)
        if let tokenBlockMessage = tokenLimitBlockMessage(for: estimate.estimatedTotal) {
            var record = RunRecord(projectID: project.id, projectTitle: project.title, status: .failed)
            record.endedAt = Date()
            record.currentStage = "Token 限制拦截"
            record.diagnosticMessage = tokenBlockMessage
            record.logs.append(RunLogEntry(level: .error, message: tokenBlockMessage))
            runRecords.insert(record, at: 0)
            activeRunID = record.id
            return
        }

        var record = RunRecord(projectID: project.id, projectTitle: project.title)
        record.currentStage = "已创建运行任务"
        record.diagnosticMessage = "正在准备模块执行队列。"
        record.logs.append(RunLogEntry(level: .info, message: "运行记录已创建，正在交给工作流引擎。"))
        runRecords.insert(record, at: 0)
        activeRunID = record.id
        startRunWatchdog(for: record.id)

        do {
            record = try await engine.run(
                runID: record.id,
                project: project,
                apiConfigs: apiConfigs,
                settings: settings,
                aiClient: aiClient
            ) { [weak self] partial in
                Task { @MainActor in
                    self?.replaceRunRecord(partial)
                }
            }
            replaceRunRecord(record)
            saveSnapshot(project: project, output: record.output, note: "运行完成自动快照")
        } catch is CancellationError {
            var current = runRecords.first(where: { $0.id == record.id }) ?? record
            current.status = .cancelled
            current.endedAt = Date()
            current.currentNodeIDs = []
            current.currentStage = "已停止"
            current.diagnosticMessage = "运行被取消。"
            current.logs.append(RunLogEntry(level: .warning, message: "运行已停止"))
            replaceRunRecord(current)
        } catch {
            var current = runRecords.first(where: { $0.id == record.id }) ?? record
            current.status = .failed
            current.endedAt = Date()
            current.currentNodeIDs = []
            current.currentStage = "运行失败"
            current.diagnosticMessage = error.localizedDescription
            current.logs.append(RunLogEntry(level: .error, message: error.localizedDescription))
            replaceRunRecord(current)
        }
    }

    func replaceRunRecord(_ record: RunRecord) {
        var updated = record
        updated.lastLogAt = Date()
        activeRunID = updated.id
        if let index = runRecords.firstIndex(where: { $0.id == updated.id }) {
            runRecords[index] = updated
        } else {
            runRecords.insert(updated, at: 0)
        }
    }

    private func startRunWatchdog(for runID: UUID) {
        stopRunWatchdog()
        runWatchdogTask = Task { [weak self] in
            while !Task.isCancelled {
                try? await Task.sleep(nanoseconds: 10_000_000_000)
                await MainActor.run {
                    self?.tickRunWatchdog(runID: runID)
                }
            }
        }
    }

    private func stopRunWatchdog() {
        runWatchdogTask?.cancel()
        runWatchdogTask = nil
    }

    private func tickRunWatchdog(runID: UUID) {
        guard let index = runRecords.firstIndex(where: { $0.id == runID }) else { return }
        guard runRecords[index].status == .running else { return }
        let idle = Date().timeIntervalSince(runRecords[index].lastLogAt)
        guard idle > 18 else { return }
        let seconds = Int(idle)
        let current = runRecords[index].currentNodeTitle ?? "未进入模块"
        runRecords[index].currentStage = "等待中：\(current)"
        runRecords[index].diagnosticMessage = "超过 \(seconds) 秒没有新日志。可能正在等待 API 返回、网络超时或模型响应过慢；可点停止运行。"
        runRecords[index].logs.append(RunLogEntry(level: .warning, nodeTitle: runRecords[index].currentNodeTitle, message: "Watchdog：\(seconds) 秒无新日志，仍在等待 \(current)。"))
        runRecords[index].lastLogAt = Date()
    }

    func saveSnapshot(project: WorkflowProject, output: String, note: String) {
        let snapshot = VersionSnapshot(projectID: project.id, title: project.title, project: project, output: output, note: note)
        snapshots.insert(snapshot, at: 0)
    }

    private func tokenLimitBlockMessage(for estimatedTotal: Int) -> String? {
        switch settings.tokenLimitMode {
        case .none:
            return nil
        case .singleWorkflow:
            return estimatedTotal > settings.singleWorkflowTokenLimit
                ? "预估 Token 超过单次工作流限制：\(estimatedTotal) / \(settings.singleWorkflowTokenLimit)"
                : nil
        case .daily:
            let usedToday = runRecords
                .filter { Calendar.current.isDateInToday($0.startedAt) }
                .map { $0.tokenUsage.total }
                .reduce(0, +)
            let projected = usedToday + estimatedTotal
            return projected > settings.dailyTokenLimit
                ? "预估 Token 超过今日总量限制：今日已用 \(usedToday)，本次预估 \(estimatedTotal)，限制 \(settings.dailyTokenLimit)"
                : nil
        }
    }

    func applyDefaultModelIfPossible(to node: inout WorkflowNode) {
        applyDefaultModel(to: &node)
    }

    private func applyDefaultModel(to node: inout WorkflowNode) {
        guard node.kind != .start && node.kind != .output else { return }
        guard let resolved = resolvedGlobalDefault(for: node.kind) else { return }
        node.providerID = resolved.providerID
        node.modelID = resolved.modelID
    }

    private func applyDefaultModels(to project: inout WorkflowProject) {
        for index in project.nodes.indices {
            let kind = project.nodes[index].kind
            guard kind != .start && kind != .output else { continue }
            guard let resolved = resolvedGlobalDefault(for: kind) else { continue }
            project.nodes[index].providerID = resolved.providerID
            project.nodes[index].modelID = resolved.modelID
        }
    }

    private func defaultTextResolution() -> (providerID: UUID, modelID: String)? {
        guard let providerID = settings.defaultTextProviderID,
              let modelID = settings.defaultTextModelID,
              !modelID.isEmpty else { return nil }
        return (providerID, modelID)
    }

    private func resolvedGlobalDefault(for kind: WorkflowNodeKind) -> (providerID: UUID, modelID: String)? {
        let preferred: (providerID: UUID?, modelID: String?)

        if kind.requiresImageGenerationModel {
            preferred = (settings.defaultImageProviderID, settings.defaultImageModelID)
        } else if kind.requiresVisionModel {
            preferred = (settings.defaultVisionProviderID, settings.defaultVisionModelID)
        } else if kind == .codeWorker || kind == .autoFixer {
            preferred = (settings.defaultCodeProviderID, settings.defaultCodeModelID)
        } else if kind == .codeReviewer || kind == .qualityReviewer || kind == .visualReviewer {
            preferred = (settings.defaultReviewerProviderID, settings.defaultReviewerModelID)
        } else {
            preferred = (settings.defaultTextProviderID, settings.defaultTextModelID)
        }

        if let providerID = preferred.providerID,
           let modelID = preferred.modelID,
           !modelID.isEmpty,
           apiConfigs.contains(where: { $0.id == providerID }) {
            return (providerID, modelID)
        }

        guard let fallbackConfig = apiConfigs.first,
              let fallbackModel = fallbackConfig.models.first?.id else { return nil }
        return (fallbackConfig.id, fallbackModel)
    }

    func refreshCacheSize() {
        let bytes = cacheBytes()
        cacheSizeText = ByteCountFormatter.string(fromByteCount: Int64(bytes), countStyle: .file)
    }

    func clearCache() {
        URLCache.shared.removeAllCachedResponses()
        let tmp = FileManager.default.temporaryDirectory
        if let items = try? FileManager.default.contentsOfDirectory(at: tmp, includingPropertiesForKeys: nil) {
            for item in items where item.lastPathComponent.contains("AIWorkflowStudio") || item.pathExtension.lowercased() == "zip" {
                try? FileManager.default.removeItem(at: item)
            }
        }
        refreshCacheSize()
        appAlert = AppAlert(title: "缓存已清除", message: "已清除网络缓存和临时导出文件。项目、API 配置、运行记录不会被删除。")
    }

    private func cacheBytes() -> Int {
        var total = URLCache.shared.currentDiskUsage
        let tmp = FileManager.default.temporaryDirectory
        if let items = try? FileManager.default.contentsOfDirectory(at: tmp, includingPropertiesForKeys: [.fileSizeKey]) {
            for item in items where item.lastPathComponent.contains("AIWorkflowStudio") || item.pathExtension.lowercased() == "zip" {
                let values = try? item.resourceValues(forKeys: [.fileSizeKey])
                total += values?.fileSize ?? 0
            }
        }
        return total
    }

    private func loadAll() {
        projects = Self.load([WorkflowProject].self, key: "projects") ?? []
        apiConfigs = Self.load([APIProviderConfig].self, key: "apiConfigs") ?? []
        runRecords = Self.load([RunRecord].self, key: "runRecords") ?? []
        snapshots = Self.load([VersionSnapshot].self, key: "snapshots") ?? []
        settings = Self.load(AppSettings.self, key: "settings") ?? AppSettings()
    }

    private func saveProjects() { Self.save(projects, key: "projects") }
    private func saveAPIConfigs() { Self.save(apiConfigs, key: "apiConfigs") }
    private func saveRunRecords() { Self.save(runRecords, key: "runRecords") }
    private func saveSnapshots() { Self.save(snapshots, key: "snapshots") }
    private func saveSettings() { Self.save(settings, key: "settings") }

    private static func save<T: Encodable>(_ value: T, key: String) {
        let encoder = JSONEncoder()
        encoder.dateEncodingStrategy = .iso8601
        if let data = try? encoder.encode(value) {
            UserDefaults.standard.set(data, forKey: key)
        }
    }

    private static func load<T: Decodable>(_ type: T.Type, key: String) -> T? {
        guard let data = UserDefaults.standard.data(forKey: key) else { return nil }
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        return try? decoder.decode(T.self, from: data)
    }
}
