# Changelog

## v1.0 - 2026-06-12

### 新增

- 新建 AI Comic Studio iPadOS / iOS SwiftUI Xcode Project。
- 新增两种创作模式：已有故事 / AI 写故事。
- 新增文本 API 与图片 API 分离设置。
- 新增主流 API Base URL 预设。
- 新增“刷新模型”功能：文本和图片模型分别刷新。
- 新增角色自动提取与角色一致性 Prompt Anchor。
- 新增故事扩写、logline、页面规划、分镜规划、dialogue 规划。
- 新增页面工作区，可切换查看每一页。
- 新增单页生成和一键生成全部页面。
- 新增角色、页面 Prompt、分镜、dialogue 的手动编辑。
- 新增运行日志与复制日志按钮。
- 新增本地兜底规划：没填文本 API Key 时也能测试 UI 流程。
- 新增 README 使用说明。

### API 预设

- 文本：OpenAI、OpenRouter、DeepSeek、Anthropic、Gemini、SiliconFlow、火山方舟 / Doubao、DashScope、Moonshot / Kimi、智谱 GLM、自定义 OpenAI 兼容。
- 图片：OpenAI Images、Stability AI、Replicate、fal.ai、SiliconFlow Images、自定义 OpenAI 图片兼容。

### 已知限制

- 图片文字气泡由图片模型直接绘制时可能变形或乱码。
- Stability / fal.ai 部分服务没有统一稳定的可用模型列表接口，本版会用内置模型兜底。
- Replicate 不同模型输入字段不完全一致，本版优先支持常见 prompt / aspect_ratio / output_format。
- 本版 API Key 存在本地 Documents JSON，正式产品建议使用 Keychain 或后端代理。
