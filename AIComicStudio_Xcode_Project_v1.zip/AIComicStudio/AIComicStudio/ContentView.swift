import SwiftUI

struct ContentView: View {
    @EnvironmentObject private var store: ProjectStore
    @EnvironmentObject private var apiSettings: APISettings
    @State private var section: SidebarSection = .create

    var body: some View {
        NavigationSplitView {
            List(selection: $section) {
                Section("项目") {
                    NavigationLink(value: SidebarSection.create) { Label("创作", systemImage: "sparkles.rectangle.stack") }
                    NavigationLink(value: SidebarSection.characters) { Label("角色", systemImage: "person.2") }
                    NavigationLink(value: SidebarSection.pages) { Label("页面", systemImage: "square.grid.2x2") }
                }
                Section("设置") {
                    NavigationLink(value: SidebarSection.api) { Label("API 与模型", systemImage: "slider.horizontal.3") }
                    NavigationLink(value: SidebarSection.logs) { Label("日志", systemImage: "doc.text") }
                }
            }
            .navigationTitle("AI Comic Studio")
            .toolbar {
                ToolbarItemGroup(placement: .topBarTrailing) {
                    Button { store.newProject() } label: { Image(systemName: "plus") }
                    Button { store.loadSample() } label: { Image(systemName: "wand.and.stars") }
                }
            }
        } detail: {
            switch section {
            case .create:
                CreationView()
            case .characters:
                CharacterListView()
            case .pages:
                PageWorkspaceView()
            case .api:
                APISettingsView()
            case .logs:
                LogsView()
            }
        }
    }
}

enum SidebarSection: String, CaseIterable, Hashable, Identifiable {
    case create, characters, pages, api, logs
    var id: String { rawValue }
}
