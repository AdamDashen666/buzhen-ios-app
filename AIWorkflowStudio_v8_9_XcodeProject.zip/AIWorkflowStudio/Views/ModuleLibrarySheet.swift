import SwiftUI

struct ModuleLibrarySheet: View {
    @EnvironmentObject private var store: AppStore
    @Environment(\.dismiss) private var dismiss
    var spawnPoint: CGPoint? = nil
    var visibleRect: CGRect? = nil

    var body: some View {
        NavigationStack {
            List(WorkflowNodeKind.allCases.filter { $0 != .start && $0 != .output && $0 != .autoFixer && $0 != .autoGraph }) { kind in
                Button {
                    if let project = store.selectedProject {
                        store.addNode(kind, to: project.id, near: spawnPoint, constrainedTo: visibleRect)
                    }
                    dismiss()
                } label: {
                    HStack(alignment: .top, spacing: 12) {
                        Image(systemName: kind.icon)
                            .frame(width: 30)
                            .foregroundStyle(.cyan)
                        VStack(alignment: .leading, spacing: 5) {
                            Text(kind.title)
                                .font(.headline)
                            Text(kind.summary)
                                .font(.caption)
                                .foregroundStyle(.secondary)
                            Text(kind.inputDescription)
                                .font(.caption2)
                                .foregroundStyle(.secondary)
                            Text(kind.outputDescription)
                                .font(.caption2)
                                .foregroundStyle(.secondary)
                        }
                    }
                    .padding(.vertical, 4)
                }
            }
            .scrollContentBackground(.hidden)
            .studioBackground()
            .navigationTitle("添加模块")
            .toolbar { Button("关闭") { dismiss() } }
        }
    }
}
