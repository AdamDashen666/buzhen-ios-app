import Foundation

enum ZipArchiveService {
    struct Entry {
        var path: String
        var data: Data
    }

    struct GeneratedFile: Identifiable, Hashable {
        var id: String { path }
        var path: String
        var data: Data
        var sourceNodeTitle: String
        var sourceKindTitle: String

        var fileName: String { URL(fileURLWithPath: path).lastPathComponent }
        var byteCountText: String { ByteCountFormatter.string(fromByteCount: Int64(data.count), countStyle: .file) }
    }

    enum ArchiveError: Error, LocalizedError {
        case entryNameTooLong(String)
        case entryTooLarge(String)
        case archiveTooLarge

        var errorDescription: String? {
            switch self {
            case .entryNameTooLong(let name): return "ZIP 条目名称过长：\(name)"
            case .entryTooLarge(let name): return "ZIP 条目过大，当前轻量打包器暂不支持 Zip64：\(name)"
            case .archiveTooLarge: return "ZIP 文件过大，当前轻量打包器暂不支持 Zip64"
            }
        }
    }

    static func shareableRunArchive(for run: RunRecord) -> URL {
        do {
            return try exportRunArchive(run)
        } catch {
            return exportFallbackReport(run: run, error: error)
        }
    }

    static func generatedFiles(for run: RunRecord) -> [GeneratedFile] {
        generatedFilesInternal(from: run)
    }

    static func shareableGeneratedFile(_ file: GeneratedFile, run: RunRecord) -> URL {
        let exportRoot = FileManager.default.temporaryDirectory
            .appendingPathComponent("AIWorkflowStudio-Files", isDirectory: true)
            .appendingPathComponent(run.id.uuidString, isDirectory: true)
        do {
            try FileManager.default.createDirectory(at: exportRoot, withIntermediateDirectories: true)
            let target = exportRoot.appendingPathComponent(normalizedPath(file.path))
            try FileManager.default.createDirectory(at: target.deletingLastPathComponent(), withIntermediateDirectories: true)
            try file.data.write(to: target, options: .atomic)
            return target
        } catch {
            let fallback = exportRoot.appendingPathComponent("export-failed-\(file.fileName).txt")
            try? "文件导出失败：\(error.localizedDescription)".write(to: fallback, atomically: true, encoding: .utf8)
            return fallback
        }
    }

    static func shareableGeneratedFilesArchive(for run: RunRecord) -> URL {
        do {
            let files = generatedFiles(for: run)
            let entries = files.map { Entry(path: "generated/\(normalizedPath($0.path))", data: $0.data) }
            let exportRoot = FileManager.default.temporaryDirectory
                .appendingPathComponent("AIWorkflowStudio-Files", isDirectory: true)
            try FileManager.default.createDirectory(at: exportRoot, withIntermediateDirectories: true)
            let destination = exportRoot.appendingPathComponent("generated-files-\(run.id.uuidString.prefix(8)).zip")
            try write(entries: entries.isEmpty ? [Entry(path: "NO_FILES_FOUND.txt", data: "未检测到可单独导出的文件。".utf8Data)] : entries, to: destination)
            return destination
        } catch {
            return exportFallbackReport(run: run, error: error)
        }
    }

    @discardableResult
    static func exportRunArchive(_ run: RunRecord) throws -> URL {
        let exportRoot = FileManager.default.temporaryDirectory
            .appendingPathComponent("AIWorkflowStudio-Exports", isDirectory: true)
        try FileManager.default.createDirectory(at: exportRoot, withIntermediateDirectories: true)

        let fileName = "\(safeFileName(run.projectTitle))-\(run.id.uuidString.prefix(8)).zip"
        let destination = exportRoot.appendingPathComponent(fileName)

        var entries: [Entry] = []
        entries.append(Entry(path: "README.md", data: readme(for: run).utf8Data))
        entries.append(Entry(path: "output/final-output.md", data: (run.output.isEmpty ? LogExportService.markdown(for: run) : run.output).utf8Data))
        entries.append(Entry(path: "logs/run-log.md", data: LogExportService.markdown(for: run).utf8Data))
        entries.append(Entry(path: "logs/events.json", data: try LogExportService.jsonData(for: run)))

        for (index, node) in run.nodeRecords.enumerated() {
            let number = String(format: "%02d", index + 1)
            let name = safeFileName(node.nodeTitle)
            let body = nodeMarkdown(node)
            entries.append(Entry(path: "nodes/\(number)-\(name).md", data: body.utf8Data))
        }

        entries.append(contentsOf: generatedFileEntries(from: run))

        try write(entries: entries, to: destination)
        return destination
    }

    static func write(entries: [Entry], to destination: URL) throws {
        var archive = Data()
        var centralDirectory = Data()
        var centralRecords: [(entry: Entry, crc: UInt32, offset: UInt32)] = []

        for entry in entries {
            let cleanPath = normalizedPath(entry.path)
            let nameData = cleanPath.utf8Data
            guard nameData.count <= Int(UInt16.max) else { throw ArchiveError.entryNameTooLong(cleanPath) }
            guard entry.data.count <= Int(UInt32.max) else { throw ArchiveError.entryTooLarge(cleanPath) }
            guard archive.count <= Int(UInt32.max) else { throw ArchiveError.archiveTooLarge }

            let crc = CRC32.checksum(entry.data)
            let offset = UInt32(archive.count)
            appendLocalHeader(to: &archive, nameData: nameData, crc: crc, size: UInt32(entry.data.count))
            archive.append(entry.data)
            centralRecords.append((Entry(path: cleanPath, data: entry.data), crc, offset))
        }

        let centralStart = UInt32(archive.count)
        for record in centralRecords {
            let nameData = record.entry.path.utf8Data
            appendCentralDirectoryHeader(
                to: &centralDirectory,
                nameData: nameData,
                crc: record.crc,
                size: UInt32(record.entry.data.count),
                localHeaderOffset: record.offset
            )
        }
        guard centralDirectory.count <= Int(UInt32.max), archive.count + centralDirectory.count <= Int(UInt32.max) else {
            throw ArchiveError.archiveTooLarge
        }
        archive.append(centralDirectory)
        appendEndOfCentralDirectory(
            to: &archive,
            entryCount: UInt16(min(centralRecords.count, Int(UInt16.max))),
            centralDirectorySize: UInt32(centralDirectory.count),
            centralDirectoryOffset: centralStart
        )

        if FileManager.default.fileExists(atPath: destination.path) {
            try FileManager.default.removeItem(at: destination)
        }
        try archive.write(to: destination, options: .atomic)
    }

    private static func appendLocalHeader(to data: inout Data, nameData: Data, crc: UInt32, size: UInt32) {
        data.appendUInt32LE(0x04034b50)
        data.appendUInt16LE(20)       // version needed
        data.appendUInt16LE(0)        // flags
        data.appendUInt16LE(0)        // compression method: stored / no compression
        data.appendUInt16LE(0)        // mod time
        data.appendUInt16LE(33)       // mod date: 1980-01-01
        data.appendUInt32LE(crc)
        data.appendUInt32LE(size)
        data.appendUInt32LE(size)
        data.appendUInt16LE(UInt16(nameData.count))
        data.appendUInt16LE(0)        // extra length
        data.append(nameData)
    }

    private static func appendCentralDirectoryHeader(to data: inout Data, nameData: Data, crc: UInt32, size: UInt32, localHeaderOffset: UInt32) {
        data.appendUInt32LE(0x02014b50)
        data.appendUInt16LE(20)       // version made by
        data.appendUInt16LE(20)       // version needed
        data.appendUInt16LE(0)        // flags
        data.appendUInt16LE(0)        // compression method
        data.appendUInt16LE(0)        // mod time
        data.appendUInt16LE(33)       // mod date: 1980-01-01
        data.appendUInt32LE(crc)
        data.appendUInt32LE(size)
        data.appendUInt32LE(size)
        data.appendUInt16LE(UInt16(nameData.count))
        data.appendUInt16LE(0)        // extra length
        data.appendUInt16LE(0)        // comment length
        data.appendUInt16LE(0)        // disk start
        data.appendUInt16LE(0)        // internal attributes
        data.appendUInt32LE(0)        // external attributes
        data.appendUInt32LE(localHeaderOffset)
        data.append(nameData)
    }

    private static func appendEndOfCentralDirectory(to data: inout Data, entryCount: UInt16, centralDirectorySize: UInt32, centralDirectoryOffset: UInt32) {
        data.appendUInt32LE(0x06054b50)
        data.appendUInt16LE(0)        // disk number
        data.appendUInt16LE(0)        // central dir disk
        data.appendUInt16LE(entryCount)
        data.appendUInt16LE(entryCount)
        data.appendUInt32LE(centralDirectorySize)
        data.appendUInt32LE(centralDirectoryOffset)
        data.appendUInt16LE(0)        // comment length
    }

    private static func readme(for run: RunRecord) -> String {
        """
        # \(run.projectTitle)

        这是 AI Workflow Studio 导出的真实 ZIP 项目包。

        - 状态：\(run.status.title)
        - 开始：\(run.startedAt.formatted(date: .abbreviated, time: .standard))
        - Token：\(run.tokenUsage.total)
        - 节点数：\(run.nodeRecords.count)

        ## 目录
        - `output/final-output.md`：最终输出
        - `logs/run-log.md`：Markdown 运行日志
        - `logs/events.json`：完整 JSON 运行记录
        - `nodes/`：每个模块的独立输出
        - `generated/`：从格式转换者/项目打包者/代码工作者输出中识别出的真实文件，例如 `.py`、`.md`、`.html`
        """
    }

    private static func nodeMarkdown(_ node: NodeRunRecord) -> String {
        """
        # \(node.nodeTitle)

        - 类型：\(node.kind.title)
        - 状态：\(node.status.title)
        - 模型：\(node.modelID ?? "未配置")
        - Provider：\(node.providerName ?? "未配置")
        - Token：\(node.tokenUsage.total)

        ## 输入预览

        ```text
        \(node.inputPreview)
        ```

        ## 输出

        ```text
        \(node.output)
        ```

        ## 错误

        \(node.errorMessage ?? "无")
        """
    }

    static func detectGeneratedFilePaths(in text: String) -> [String] {
        extractedFileEntries(from: text, preferredDefaultName: nil).map(\.path)
    }

    static func generatedProjectValidationIssues(in text: String, strictWhenProjectMentioned: Bool = false) -> [String] {
        let entries = extractedFileEntries(from: text, preferredDefaultName: nil)
        let files = entries.map { entry in
            GeneratedFile(
                path: normalizedPath(entry.path),
                data: entry.data,
                sourceNodeTitle: "检查者输入",
                sourceKindTitle: "上游产物"
            )
        }
        var issues = projectValidationIssues(for: normalizedAndDeduplicated(files))
        if strictWhenProjectMentioned {
            let lower = text.lowercased()
            let mentionsProject = lower.contains("hugo")
                || lower.contains("静态博客")
                || lower.contains("个人博客")
                || lower.contains("blog")
                || lower.contains("github pages")
            let expectsFiles = lower.contains("file path")
                || lower.contains("config.toml")
                || lower.contains("content/")
                || lower.contains("layouts/")
                || lower.contains("项目打包")
                || lower.contains("格式转换")
                || lower.contains("运行包")
            if entries.isEmpty && mentionsProject && expectsFiles {
                issues.append("没有检测到明确的 `file path=\"...\"` 文件块，无法证明最终运行包包含真实文件。")
            }
        }
        return issues
    }

    private static func generatedFileEntries(from run: RunRecord) -> [Entry] {
        generatedFilesInternal(from: run).map { file in
            let clean = normalizedPath(file.path)
            let generatedPath = clean.hasPrefix("generated/") ? clean : "generated/\(clean)"
            return Entry(path: generatedPath, data: file.data)
        }
    }

    private static func generatedFilesInternal(from run: RunRecord) -> [GeneratedFile] {
        // v8.5: 最终打包节点优先，但不再“只要最高优先级有文件就完全停止”。
        // 原因：项目打包者/格式转换者如果少提了 config.toml、样式、文章等关键文件，旧逻辑会把下游包导出成残缺项目。
        // 新逻辑：高优先级文件先占位，低优先级已通过产物只补“缺失路径”，绝不覆盖最终打包者已经给出的同名文件。
        let priorityGroups: [[WorkflowNodeKind]] = [
            [.filePackager],
            [.formatter],
            [.output],
            [.aggregator],
            [.codeWorker],
            [.worker]
        ]

        var merged: [GeneratedFile] = []
        var seen = Set<String>()
        for group in priorityGroups {
            let sourceNodes = latestPassedRecordsByNode(from: run.nodeRecords.filter { group.contains($0.kind) })
            let ownedFilesByNodeID = expectedOwnedFilesByTargetNodeID(from: run)
            let files = filesExtracted(from: sourceNodes, ownedFilesByNodeID: ownedFilesByNodeID)
            for file in files {
                let key = normalizedPath(file.path)
                guard !key.isEmpty, !seen.contains(key) else { continue }
                seen.insert(key)
                merged.append(file)
            }
        }

        if merged.isEmpty {
            let fallbackEntries = extractedFileEntries(from: run.output, preferredDefaultName: nil)
            merged = fallbackEntries.map { entry in
                GeneratedFile(
                    path: normalizedPath(entry.path),
                    data: entry.data,
                    sourceNodeTitle: "最终输出",
                    sourceKindTitle: "输出模块"
                )
            }
        }

        return validatedProjectFiles(normalizedAndDeduplicated(merged), run: run)
    }


    private static func latestPassedRecordsByNode(from records: [NodeRunRecord]) -> [NodeRunRecord] {
        var latestByNode: [UUID: NodeRunRecord] = [:]
        var orderByNode: [UUID: Int] = [:]
        for (index, record) in records.enumerated() {
            latestByNode[record.nodeID] = record
            orderByNode[record.nodeID] = index
        }
        return latestByNode.values
            .filter { $0.status == .passed }
            .sorted { (orderByNode[$0.nodeID] ?? 0) < (orderByNode[$1.nodeID] ?? 0) }
    }

    private static func filesExtracted(from records: [NodeRunRecord], ownedFilesByNodeID: [UUID: [String]]) -> [GeneratedFile] {
        var files: [GeneratedFile] = []
        for node in records {
            let preferred = preferredFallbackPath(for: node, ownedFilesByNodeID: ownedFilesByNodeID)
            let entries = extractedFileEntries(from: node.output, preferredDefaultName: preferred)
            files.append(contentsOf: entries.map { entry in
                GeneratedFile(
                    path: normalizedPath(entry.path),
                    data: entry.data,
                    sourceNodeTitle: node.nodeTitle,
                    sourceKindTitle: node.kind.title
                )
            })
        }
        return normalizedAndDeduplicated(files)
    }

    private static func normalizedAndDeduplicated(_ files: [GeneratedFile]) -> [GeneratedFile] {
        var result: [GeneratedFile] = []
        var indexByPath: [String: Int] = [:]
        for file in files {
            let clean = normalizedPath(file.path)
            guard !clean.isEmpty else { continue }
            let normalized = clean.hasPrefix("generated/") ? String(clean.dropFirst("generated/".count)) : clean
            var next = file
            next.path = normalized
            if let index = indexByPath[normalized] {
                result[index] = next
            } else {
                indexByPath[normalized] = result.count
                result.append(next)
            }
        }
        return result.sorted { $0.path.localizedStandardCompare($1.path) == .orderedAscending }
    }

    private static func extractedFileEntries(from text: String, preferredDefaultName: String?) -> [Entry] {
        let lines = text.components(separatedBy: .newlines)
        var entries: [Entry] = []
        var pendingPathHint: String?
        var insideFence = false
        var fencePath: String?
        var fenceLanguage: String?
        var fenceTickCount = 0
        var buffer: [String] = []

        for line in lines {
            let trimmed = line.trimmingCharacters(in: .whitespacesAndNewlines)
            if let tickCount = leadingBacktickFenceLength(in: trimmed) {
                if insideFence {
                    guard tickCount >= fenceTickCount else {
                        buffer.append(line)
                        continue
                    }
                    let body = buffer.joined(separator: "\n").trimmingCharacters(in: .whitespacesAndNewlines)
                    if !body.isEmpty {
                        let path = fencePath ?? pendingPathHint ?? preferredDefaultName ?? fallbackFileName(forLanguage: fenceLanguage)
                        if let path, isSupportedGeneratedFile(path), shouldAcceptGeneratedBody(body, forPath: path), let data = generatedData(for: body, path: path) {
                            entries.append(Entry(path: path, data: data))
                        }
                    }
                    insideFence = false
                    fencePath = nil
                    fenceLanguage = nil
                    fenceTickCount = 0
                    buffer.removeAll()
                    pendingPathHint = nil
                } else {
                    insideFence = true
                    fenceTickCount = tickCount
                    fencePath = explicitPathHint(fromFenceOpening: trimmed)
                    fenceLanguage = languageHint(fromFenceOpening: trimmed, tickCount: tickCount)
                    buffer.removeAll()
                }
                continue
            }

            if insideFence {
                buffer.append(line)
            } else if let hint = contextualPathHint(from: line) {
                pendingPathHint = hint
            }
        }
        return entries
    }






    private static func leadingBacktickFenceLength(in line: String) -> Int? {
        guard line.hasPrefix("```") else { return nil }
        var count = 0
        for ch in line {
            if ch == "`" { count += 1 } else { break }
        }
        return count >= 3 ? count : nil
    }

    private static func explicitPathHint(fromFenceOpening opening: String) -> String? {
        let lower = opening.lowercased()
        guard lower.contains("path") || lower.contains("filename") || lower.contains("file=") || lower.contains("file ") else { return nil }
        return firstSupportedPath(in: opening, allowMultiple: false)
    }

    private static func contextualPathHint(from line: String) -> String? {
        let trimmed = line.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return nil }
        let lower = trimmed.lowercased()

        // 只接受“文件标题/清单项”里的路径，不从普通说明句里抓路径。
        // 这能避免把“baseof.html 中引用 style.css”误判为 style.css 文件块的路径，
        // 也避免把 README 教程里的 `hugo new posts/my-post.md` 误提取成真实文章文件。
        let isHeading = trimmed.hasPrefix("#")
        let isFileLabel = lower.hasPrefix("file ") || lower.hasPrefix("文件") || lower.contains(" file path") || lower.contains("文件路径")
        let isNumberedTitle = trimmed.range(of: #"^[-*• ]*\d+[.)、]\s*`[^`]+`"#, options: .regularExpression) != nil
        let isBacktickedHeading = isHeading && trimmed.contains("`")
        guard isHeading || isFileLabel || isNumberedTitle || isBacktickedHeading else { return nil }
        return firstSupportedPath(in: trimmed, allowMultiple: false)
    }

    private static func firstSupportedPath(in line: String, allowMultiple: Bool) -> String? {
        var candidates: [String] = []
        let cleaned = line
            .replacingOccurrences(of: "`", with: " ")
            .replacingOccurrences(of: "\"", with: " ")
            .replacingOccurrences(of: "'", with: " ")
            .replacingOccurrences(of: "=", with: " ")
            .replacingOccurrences(of: ":", with: " ")
            .replacingOccurrences(of: "，", with: " ")
            .replacingOccurrences(of: "：", with: " ")
        let parts = cleaned.split { ch in
            ch == " " || ch == "\t" || ch == "(" || ch == ")" || ch == "[" || ch == "]" || ch == "<" || ch == ">" || ch == ","
        }
        for part in parts {
            let candidate = String(part).trimmingCharacters(in: CharacterSet(charactersIn: "#*-•；;。，"))
            if isSupportedGeneratedFile(candidate) {
                candidates.append(normalizedPath(candidate))
            }
        }
        guard allowMultiple || candidates.count <= 1 else { return nil }
        return candidates.first
    }

    private static func languageHint(fromFenceOpening opening: String, tickCount: Int) -> String? {
        let marker = String(repeating: "`", count: tickCount)
        let value = opening.replacingOccurrences(of: marker, with: "")
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .lowercased()
        return value.isEmpty ? nil : value
    }


    private static func preferredFallbackPath(for node: NodeRunRecord, ownedFilesByNodeID: [UUID: [String]]) -> String? {
        guard let owned = ownedFilesByNodeID[node.nodeID] else { return nil }
        let exactFiles = owned
            .map { normalizedPath($0) }
            .filter { path in
                !path.isEmpty
                && !path.contains("*")
                && !path.hasSuffix("/")
                && isSupportedGeneratedFile(path)
            }
        // 只有“单一明确文件职责”的节点，才允许把无 path 的 Markdown/文本代码块落到 ownedFiles。
        // 多文件代码工作者必须显式写 file path，防止把内部代码块拆成错误文件。
        return exactFiles.count == 1 ? exactFiles.first : nil
    }

    private static func expectedOwnedFilesByTargetNodeID(from run: RunRecord) -> [UUID: [String]] {
        var result: [UUID: [String]] = [:]
        for record in run.nodeRecords {
            let output = record.output
            guard output.contains("targetNodeID"), output.contains("ownedFiles") else { continue }
            for match in matches(
                pattern: #"(?s)\"targetNodeID\"\s*:\s*\"([A-Fa-f0-9-]{36})\".*?\"ownedFiles\"\s*:\s*\[(.*?)\]"#,
                in: output
            ) {
                guard match.count >= 3, let id = UUID(uuidString: match[1]) else { continue }
                let owned = quotedValues(in: match[2])
                    .map { normalizedPath($0) }
                    .filter { !$0.isEmpty }
                if !owned.isEmpty { result[id, default: []].append(contentsOf: owned) }
            }
        }
        return result.mapValues { Array(Set($0)).sorted() }
    }

    private static func expectedOwnedFiles(from run: RunRecord) -> [String] {
        expectedOwnedFilesByTargetNodeID(from: run).values
            .flatMap { $0 }
            .map { normalizedPath($0) }
            .filter { path in
                !path.isEmpty
                && !path.contains("*")
                && !path.hasSuffix("/")
                && isSupportedGeneratedFile(path)
            }
            .uniquedSorted()
    }

    private static func matches(pattern: String, in text: String) -> [[String]] {
        guard let regex = try? NSRegularExpression(pattern: pattern, options: []) else { return [] }
        let ns = text as NSString
        let range = NSRange(location: 0, length: ns.length)
        return regex.matches(in: text, options: [], range: range).map { match in
            (0..<match.numberOfRanges).map { index in
                let r = match.range(at: index)
                guard r.location != NSNotFound else { return "" }
                return ns.substring(with: r)
            }
        }
    }

    private static func quotedValues(in text: String) -> [String] {
        matches(pattern: #"\"([^\"]+)\""#, in: text).compactMap { $0.count > 1 ? $0[1] : nil }
    }

    private static func generatedData(for body: String, path: String) -> Data? {
        let lowerPath = normalizedPath(path).lowercased()
        if isBinaryImagePath(lowerPath) || lowerPath.hasSuffix(".ico") {
            if let decoded = firstBase64Payload(in: body) { return decoded }
            // 兜底：如果模型只给了“占位图片说明”，生成一个真实 1x1 PNG，避免导出不存在或伪文本图片。
            if lowerPath.hasSuffix(".png") || lowerPath.hasSuffix(".ico") {
                return Data(base64Encoded: "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==")
            }
            return nil
        }
        return body.utf8Data
    }

    private static func isBinaryImagePath(_ lowerPath: String) -> Bool {
        lowerPath.hasSuffix(".png") || lowerPath.hasSuffix(".jpg") || lowerPath.hasSuffix(".jpeg") || lowerPath.hasSuffix(".webp") || lowerPath.hasSuffix(".gif")
    }

    private static func firstBase64Payload(in text: String) -> Data? {
        let candidates = matches(pattern: #"[A-Za-z0-9+/]{40,}={0,2}"#, in: text).compactMap { $0.first }
        for candidate in candidates {
            if let data = Data(base64Encoded: candidate), !data.isEmpty { return data }
        }
        return nil
    }

    private static func chooseCanonicalProjectRoot(_ files: [GeneratedFile]) -> [GeneratedFile] {
        let normalized = normalizedAndDeduplicated(files)
        let paths = normalized.map { normalizedPath($0.path) }
        let roots = candidateProjectRoots(from: paths)
        guard roots.count > 1 else {
            if roots.count == 1, let root = roots.first, !root.isEmpty, !hasRootLevelProjectSignal(paths) {
                return stripProjectRoot(root, from: normalized)
            }
            return normalized
        }

        let scored = roots.map { root in (root, projectRootScore(root, paths: paths)) }
            .sorted { lhs, rhs in
                if lhs.1 != rhs.1 { return lhs.1 > rhs.1 }
                return lhs.0.count < rhs.0.count
            }
        guard let selected = scored.first?.root else { return normalized }
        if selected.isEmpty {
            let nestedRoots = roots.filter { !$0.isEmpty }
            let rootFiles = normalized.filter { file in
                let clean = normalizedPath(file.path)
                return !nestedRoots.contains { clean.hasPrefix($0 + "/") }
            }
            return normalizedAndDeduplicated(rootFiles)
        }
        let selectedFiles = normalized.filter { normalizedPath($0.path).hasPrefix(selected + "/") }
        let stripped = stripProjectRoot(selected, from: selectedFiles)
        return normalizedAndDeduplicated(stripped)
    }

    private static func candidateProjectRoots(from paths: [String]) -> [String] {
        var roots = Set<String>()
        for path in paths {
            let lower = path.lowercased()
            if ["hugo.toml", "config.toml", "package.json", "pyproject.toml", "vite.config.ts", "next.config.ts", "next.config.js"].contains(lower) {
                roots.insert("")
            }
            let parts = lower.split(separator: "/").map(String.init)
            guard parts.count >= 2 else { continue }
            let name = parts.last ?? ""
            if ["hugo.toml", "config.toml", "package.json", "pyproject.toml", "vite.config.ts", "next.config.ts", "next.config.js"].contains(name) {
                roots.insert(parts.dropLast().joined(separator: "/"))
            }
        }
        return roots.sorted()
    }

    private static func hasRootLevelProjectSignal(_ paths: [String]) -> Bool {
        paths.contains { path in
            let lower = path.lowercased()
            return ["hugo.toml", "config.toml", "package.json", "pyproject.toml", "vite.config.ts", "next.config.ts", "next.config.js"].contains(lower)
        }
    }

    private static func projectRootScore(_ root: String, paths: [String]) -> Int {
        func inside(_ path: String) -> Bool { root.isEmpty ? true : path.hasPrefix(root + "/") }
        func relative(_ path: String) -> String { root.isEmpty ? path : String(path.dropFirst(root.count + 1)) }
        let rels = paths.filter(inside).map(relative)
        var score = 0
        let set = Set(rels.map { $0.lowercased() })
        if set.contains("hugo.toml") || set.contains("config.toml") { score += 30 }
        if set.contains("package.json") { score += 30 }
        if set.contains(where: { $0.hasPrefix("content/") && $0.hasSuffix(".md") }) { score += 20 }
        if set.contains(where: { $0.hasPrefix("layouts/") && $0.hasSuffix(".html") }) { score += 20 }
        if set.contains(where: { $0.hasPrefix("app/") && $0.hasSuffix(".tsx") }) { score += 20 }
        if set.contains(where: { $0.hasPrefix("static/") || $0.hasPrefix("assets/") }) { score += 10 }
        if set.contains("readme.md") { score += 5 }
        score += min(rels.count, 20)
        return score
    }

    private static func stripProjectRoot(_ root: String, from files: [GeneratedFile]) -> [GeneratedFile] {
        guard !root.isEmpty else { return files }
        return files.compactMap { file in
            let clean = normalizedPath(file.path)
            guard clean.hasPrefix(root + "/") else { return nil }
            var next = file
            next.path = String(clean.dropFirst(root.count + 1))
            return next
        }
    }

    private static func fallbackFileName(for node: NodeRunRecord) -> String? {
        // 不再给代码工作者/格式转换者默认 main.py。
        // 没有明确路径的代码块很可能是目录树、教程命令或片段，默认命名会污染运行包。
        return nil
    }

    private static func fallbackFileName(forLanguage language: String?) -> String? {
        // v8.9：没有显式路径或单一 ownedFiles 兜底时，不再根据语言自动生成 main.py/data.json/style.css。
        // 运行包导出必须优先“少但真实”，避免把教程代码块、示例片段、JSON 说明误打包成项目文件。
        return nil
    }


    private static func isSupportedGeneratedFile(_ path: String) -> Bool {
        let clean = normalizedPath(path)
        let lower = clean.lowercased()
        guard !lower.isEmpty, !lower.contains(".."), lower.count < 220 else { return false }
        if ["dockerfile", "makefile", "license", "readme"].contains(lower) { return true }
        if lower.hasSuffix("/.gitignore") || lower == ".gitignore" || lower.hasSuffix("/.gitmodules") || lower == ".gitmodules" || lower.hasSuffix("/.env.example") || lower == ".env.example" { return true }
        let supported = [
            ".py", ".swift", ".js", ".jsx", ".ts", ".tsx", ".html", ".htm", ".css", ".scss",
            ".json", ".md", ".txt", ".plist", ".yml", ".yaml", ".toml", ".xml", ".svg", ".ico",
            ".png", ".jpg", ".jpeg", ".webp", ".gif",
            ".sh", ".rb", ".go", ".rs", ".java", ".kt", ".c", ".cpp", ".h", ".hpp"
        ]
        return supported.contains { lower.hasSuffix($0) }
    }


    private static func shouldAcceptGeneratedBody(_ body: String, forPath path: String) -> Bool {
        let lowerPath = normalizedPath(path).lowercased()
        if looksLikeDirectoryTree(body), !(lowerPath.hasSuffix(".md") || lowerPath.hasSuffix(".txt")) {
            return false
        }
        if looksLikeBareReviewerDecision(body) { return false }
        if looksLikeTutorialFragment(body, forPath: lowerPath) { return false }
        if lowerPath.hasSuffix(".html") || lowerPath.hasSuffix(".htm") {
            if looksLikeCSSOnly(body) { return false }
        }
        if lowerPath.hasSuffix(".css") || lowerPath.hasSuffix(".scss") {
            if body.contains("<html") || body.contains("{{ define") { return false }
        }
        if lowerPath.hasSuffix(".toml") {
            if !body.contains("=") { return false }
        }
        if lowerPath.hasSuffix(".svg") || lowerPath.hasSuffix(".xml") {
            if !body.trimmingCharacters(in: .whitespacesAndNewlines).hasPrefix("<") { return false }
        }
        if lowerPath.hasSuffix(".ico") {
            // iOS 端轻量 ZIP 导出以文本为主；不要把“请自行生成 favicon.ico”这类说明当成二进制图标。
            let trimmed = body.trimmingCharacters(in: .whitespacesAndNewlines)
            if trimmed.contains("请") || trimmed.lowercased().contains("placeholder") || trimmed.lowercased().contains("favicon.io") { return false }
        }
        return true
    }



    private static func looksLikeCSSOnly(_ body: String) -> Bool {
        let trimmed = body.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        guard !trimmed.contains("<html"), !trimmed.contains("<!doctype"), !trimmed.contains("{{ define"), !trimmed.contains("{{ block") else { return false }
        let cssMarkers = ["{", "}", ";", "font-family", "background", "color:", "margin", "padding"]
        let score = cssMarkers.filter { trimmed.contains($0) }.count
        return score >= 4
    }

    private static func looksLikeTutorialFragment(_ body: String, forPath lowerPath: String) -> Bool {
        let trimmed = body.trimmingCharacters(in: .whitespacesAndNewlines)
        let lower = trimmed.lowercased()
        if trimmed.count < 120 {
            if lower.contains("then edit") || lower.contains("your content") || lower.contains("运行") || lower.contains("执行") {
                return true
            }
        }
        if lowerPath.hasSuffix(".md") && trimmed.split(separator: "\n").count <= 3 {
            if lower.hasPrefix("hugo new ") || lower.hasPrefix("npm ") || lower.hasPrefix("git ") || lower.hasPrefix("cd ") || lower.hasPrefix("python ") {
                return true
            }
        }
        return false
    }

    private static func looksLikeDirectoryTree(_ body: String) -> Bool {
        let lines = body.components(separatedBy: .newlines).map { $0.trimmingCharacters(in: .whitespaces) }
        let treeMarkers = lines.filter { $0.contains("├──") || $0.contains("└──") || $0.contains("│") || $0.hasPrefix("|--") || $0.hasPrefix("`--") }
        return treeMarkers.count >= 2
    }

    private static func looksLikeBareReviewerDecision(_ body: String) -> Bool {
        let trimmed = body.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        return trimmed.hasPrefix("{\"passed\":") && trimmed.contains("\"feedback\"") && trimmed.count < 300
    }


    private static func validatedProjectFiles(_ files: [GeneratedFile], run: RunRecord) -> [GeneratedFile] {
        var cleaned = files.filter { shouldAcceptGeneratedBody(String(data: $0.data, encoding: .utf8) ?? "", forPath: $0.path) }
        cleaned = normalizedAndDeduplicated(cleaned)
        cleaned = chooseCanonicalProjectRoot(cleaned)
        cleaned = normalizedAndDeduplicated(cleaned)
        let report = projectValidationReport(for: cleaned, run: run)
        guard !report.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return cleaned }
        let reportFile = GeneratedFile(
            path: "EXPORT_VALIDATION_REPORT.md",
            data: report.utf8Data,
            sourceNodeTitle: "导出完整性检查",
            sourceKindTitle: "系统校验"
        )
        return normalizedAndDeduplicated(cleaned + [reportFile])
    }

    private static func projectValidationIssues(for files: [GeneratedFile], expectedOwnedFiles: [String] = []) -> [String] {
        let paths = Set(files.map { normalizedPath($0.path).lowercased() })
        let hasHugoSignal = paths.contains("config.toml")
            || paths.contains("hugo.toml")
            || paths.contains(".github/workflows/hugo.yml")
            || paths.contains("github/workflows/hugo.yml")
            || paths.contains(where: { $0.hasPrefix("content/") || $0.hasPrefix("layouts/") || $0.hasPrefix("themes/") })
        guard hasHugoSignal else { return [] }

        var issues: [String] = []
        if !(paths.contains("config.toml") || paths.contains("hugo.toml")) {
            issues.append("缺少 Hugo 必需配置文件：`config.toml` 或 `hugo.toml`。")
        }
        if !paths.contains(where: { $0.hasPrefix("content/") && $0.hasSuffix(".md") }) {
            issues.append("缺少 `content/` 下的 Markdown 内容文件。")
        }
        if !(paths.contains("layouts/index.html") || paths.contains("layouts/_default/baseof.html") || paths.contains(where: { $0.hasPrefix("themes/") && $0.contains("/layouts/") && $0.hasSuffix(".html") })) {
            issues.append("缺少 Hugo 页面模板：例如 `layouts/index.html` 或主题 layouts。")
        }

        for file in files {
            let path = normalizedPath(file.path).lowercased()
            guard path.hasSuffix(".html"), let text = String(data: file.data, encoding: .utf8), looksLikeCSSOnly(text) else { continue }
            issues.append("`\(file.path)` 内容看起来是 CSS，不是 HTML 模板。")
        }

        let postPaths = paths.filter { $0.hasPrefix("posts/") && $0.hasSuffix(".md") }
        if !postPaths.isEmpty {
            issues.append("检测到根目录 `posts/` 下的 Markdown 文件：\(postPaths.sorted().map { "`\($0)`" }.joined(separator: ", "))。Hugo 文章应放在 `content/post/` 或 `content/posts/` 下。")
        }

        let nestedProjectRoots = nestedProjectRootSignals(in: paths)
        if !nestedProjectRoots.isEmpty {
            issues.append("检测到多个项目根目录或嵌套项目：\(nestedProjectRoots.sorted().map { "`\($0)`" }.joined(separator: ", "))。导出包应只保留一个可运行项目根。")
        }

        let strayRootFiles = paths.filter { ["main.py", "data.json", "index.js", "index.ts", "style.css"].contains($0) }
        if !strayRootFiles.isEmpty, hasHugoSignal || paths.contains("package.json") {
            issues.append("检测到疑似从无路径代码块误提取的根目录杂散文件：\(strayRootFiles.sorted().map { "`\($0)`" }.joined(separator: ", "))。")
        }

        if let hugoConfig = files.first(where: { ["hugo.toml", "config.toml"].contains(normalizedPath($0.path).lowercased()) }),
           let text = String(data: hugoConfig.data, encoding: .utf8),
           let theme = hugoThemeName(in: text),
           !theme.isEmpty {
            let lowerTheme = theme.lowercased()
            let hasThemeDir = paths.contains(where: { $0.hasPrefix("themes/\(lowerTheme)/") })
            let hasGitmodules = paths.contains(".gitmodules")
            if !hasThemeDir && !hasGitmodules {
                issues.append("`\(hugoConfig.path)` 声明 `theme = \"\(theme)\"`，但导出包缺少 `themes/\(theme)/` 或 `.gitmodules`，用户直接运行 `hugo server` 可能会找不到主题。")
            }
        }

        let missingOwned = expectedOwnedFiles
            .map { normalizedPath($0).lowercased() }
            .filter { path in
                !path.isEmpty && !path.contains("*") && !path.hasSuffix("/") && !paths.contains(path)
            }
            .uniquedSorted()
        if !missingOwned.isEmpty {
            issues.append("任务分配者 ownedFiles 中的文件未进入最终运行包：\(missingOwned.map { "`\($0)`" }.joined(separator: ", "))。")
        }
        return issues
    }


    private static func nestedProjectRootSignals(in paths: Set<String>) -> [String] {
        paths.compactMap { path in
            let parts = path.split(separator: "/").map(String.init)
            guard parts.count >= 2 else { return nil }
            let file = parts.last ?? ""
            guard ["hugo.toml", "config.toml", "package.json", "pyproject.toml", "next.config.ts", "next.config.js"].contains(file) else { return nil }
            return parts.dropLast().joined(separator: "/")
        }
    }

    private static func hugoThemeName(in toml: String) -> String? {
        for line in toml.components(separatedBy: .newlines) {
            let trimmed = line.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !trimmed.hasPrefix("#"), trimmed.lowercased().hasPrefix("theme") else { continue }
            let parts = trimmed.components(separatedBy: "=")
            guard parts.count >= 2 else { continue }
            let value = parts.dropFirst().joined(separator: "=")
                .trimmingCharacters(in: .whitespacesAndNewlines)
                .trimmingCharacters(in: CharacterSet(charactersIn: "\"'"))
            return value.isEmpty ? nil : value
        }
        return nil
    }

    private static func projectValidationReport(for files: [GeneratedFile], run: RunRecord) -> String {
        let issues = projectValidationIssues(for: files, expectedOwnedFiles: expectedOwnedFiles(from: run))
        guard !issues.isEmpty else { return "" }
        return """
        # 导出完整性检查报告

        App 已检测到当前导出的 Hugo 项目仍存在可能导致运行失败的问题：

        \(issues.map { "- \($0)" }.joined(separator: "\n"))

        ## 处理方式
        - 这份报告由 App 自动生成，用于阻止“看起来完成但运行包残缺”的情况被悄悄忽略。
        - 请优先检查项目打包者 / 格式转换者是否输出了明确的 `file path="..."` 文件块。
        - Markdown 文件如 README / DEPLOY / USER_GUIDE 内部需要代码块时，建议让模型使用四反引号包裹外层文件块，避免嵌套代码块被拆坏。

        项目：\(run.projectTitle)
        运行 ID：\(run.id.uuidString)
        """
    }

    private static func exportFallbackReport(run: RunRecord, error: Error) -> URL {
        let exportRoot = FileManager.default.temporaryDirectory
            .appendingPathComponent("AIWorkflowStudio-Exports", isDirectory: true)
        try? FileManager.default.createDirectory(at: exportRoot, withIntermediateDirectories: true)
        let url = exportRoot.appendingPathComponent("zip-export-failed-\(run.id.uuidString.prefix(8)).txt")
        let text = "ZIP 导出失败：\(error.localizedDescription)\n\n" + LogExportService.markdown(for: run)
        try? text.write(to: url, atomically: true, encoding: .utf8)
        return url
    }

    private static func safeFileName(_ value: String) -> String {
        let allowed = CharacterSet.alphanumerics.union(CharacterSet(charactersIn: "-_ ."))
        let scalars = value.unicodeScalars.map { allowed.contains($0) ? Character($0) : "-" }
        let cleaned = String(scalars).trimmingCharacters(in: .whitespacesAndNewlines)
        return cleaned.isEmpty ? "AIWorkflowStudio" : String(cleaned.prefix(80))
    }

    private static func normalizedPath(_ path: String) -> String {
        path.replacingOccurrences(of: "\\", with: "/")
            .split(separator: "/")
            .filter { !$0.isEmpty && $0 != "." && $0 != ".." }
            .joined(separator: "/")
    }
}

private enum CRC32 {
    private static let table: [UInt32] = (0..<256).map { value in
        var crc = UInt32(value)
        for _ in 0..<8 {
            if crc & 1 == 1 {
                crc = 0xedb88320 ^ (crc >> 1)
            } else {
                crc >>= 1
            }
        }
        return crc
    }

    static func checksum(_ data: Data) -> UInt32 {
        var crc: UInt32 = 0xffffffff
        for byte in data {
            crc = table[Int((crc ^ UInt32(byte)) & 0xff)] ^ (crc >> 8)
        }
        return crc ^ 0xffffffff
    }
}

private extension Array where Element == String {
    func uniquedSorted() -> [String] {
        Array(Set(self)).sorted { $0.localizedStandardCompare($1) == .orderedAscending }
    }
}

private extension String {
    var utf8Data: Data { Data(utf8) }
}

private extension Data {
    mutating func appendUInt16LE(_ value: UInt16) {
        append(UInt8(value & 0xff))
        append(UInt8((value >> 8) & 0xff))
    }

    mutating func appendUInt32LE(_ value: UInt32) {
        append(UInt8(value & 0xff))
        append(UInt8((value >> 8) & 0xff))
        append(UInt8((value >> 16) & 0xff))
        append(UInt8((value >> 24) & 0xff))
    }
}
