import Foundation

struct FileStore {
    static func copyIntoDocuments(_ source: URL) throws -> URL {
        let hasAccess = source.startAccessingSecurityScopedResource()
        defer {
            if hasAccess { source.stopAccessingSecurityScopedResource() }
        }
        let folder = try documentsSubfolder("ImportedVideos")
        let destination = folder.appendingPathComponent(source.lastPathComponent)
        if FileManager.default.fileExists(atPath: destination.path) {
            try FileManager.default.removeItem(at: destination)
        }
        try FileManager.default.copyItem(at: source, to: destination)
        return destination
    }

    static func outputURL(prefix: String = "tracked_wall_text", ext: String = "mp4") throws -> URL {
        let folder = try documentsSubfolder("Exports")
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyyMMdd_HHmmss"
        return folder.appendingPathComponent("\(prefix)_\(formatter.string(from: Date())).\(ext)")
    }

    private static func documentsSubfolder(_ name: String) throws -> URL {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let folder = docs.appendingPathComponent(name, isDirectory: true)
        if !FileManager.default.fileExists(atPath: folder.path) {
            try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        }
        return folder
    }
}
