import SwiftUI
import AVFoundation
import UniformTypeIdentifiers
import PhotosUI
import AVKit
import UIKit

private enum ActiveSheet: Identifiable {
    case fileImporter
    case photoImporter
    case shareOutput

    var id: Int {
        switch self {
        case .fileImporter: return 1
        case .photoImporter: return 2
        case .shareOutput: return 3
        }
    }
}

struct ContentView: View {
    @State private var inputURL: URL?
    @State private var firstFrame: UIImage?
    @State private var selectedQuad: [CGPoint] = []
    @State private var activeSheet: ActiveSheet?
    @State private var overlayText = "By LaoDeng666"
    @State private var status = "从文件或相册导入视频，拖动视频条选文字出现帧，再按顺序点 4 个角。选完后可微调角点和文字位置。"
    @State private var progress: Double = 0
    @State private var isRendering = false
    @State private var outputURL: URL?
    @State private var trackedPreviewFrames: [UIImage] = []
    @State private var trackingQuality = TrackingQuality.high
    @State private var outputProfile = OutputProfile.h264Compatibility
    @State private var preserveAudio = true
    @State private var exportCameraSolve = true
    @State private var videoDuration: Double = 0
    @State private var previewTime: Double = 0
    @State private var isLoadingPreview = false
    @State private var previewRequestID = 0
    @State private var livePreviewTask: Task<Void, Never>?
    @State private var textScale: Double = 1.0
    @State private var textPlaneCenter = CGPoint(x: 0.5, y: 0.5)
    @State private var frameGrabber: FastFrameGrabber?
    @State private var errorLog = ""

    var body: some View {
        NavigationStack {
            ScrollView(.vertical, showsIndicators: true) {
                VStack(spacing: 14) {
                    header
                    videoArea
                    controls
                    statusBar
                }
                .padding()
                .padding(.bottom, inputURL == nil ? 12 : 104)
                .frame(maxWidth: .infinity)
            }
            .scrollDismissesKeyboard(.interactively)
            .navigationTitle("3D Plane Tracker v14")
            .safeAreaInset(edge: .bottom) { bottomActionBar }
            .sheet(item: $activeSheet) { sheet in
                switch sheet {
                case .fileImporter:
                    FileVideoPicker(
                        onPick: { url in
                            activeSheet = nil
                            importPickedVideo(url)
                        },
                        onCancel: {
                            activeSheet = nil
                            status = "已取消文件导入。"
                        },
                        onError: { message in
                            activeSheet = nil
                            status = "文件导入失败：\(message)"
                        }
                    )
                case .photoImporter:
                    PhotoVideoPicker(
                        onPick: { url in
                            activeSheet = nil
                            importPickedVideo(url)
                        },
                        onCancel: {
                            activeSheet = nil
                            status = "已取消相册导入。"
                        },
                        onError: { message in
                            activeSheet = nil
                            status = "相册导入失败：\(message)"
                        }
                    )
                case .shareOutput:
                    if let outputURL {
                        ShareSheet(items: [outputURL])
                    } else {
                        Text("没有可分享的导出文件")
                    }
                }
            }
        }
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("本地视频平面 3D 追踪 v14")
                .font(.title2.bold())
            Text("v14 加入可复制错误日志；预览帧读取改成类似补帧 App 的缓存抽帧逻辑，拖动时间条会直接刷新画面；预览追踪改用生成器抽帧，绕开部分 AVAssetReader 预览失败。")
                .font(.footnote)
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private var videoArea: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 18)
                .fill(.thinMaterial)
            if let image = firstFrame {
                QuadSelectionView(
                    image: image,
                    points: $selectedQuad,
                    textPlaneCenter: $textPlaneCenter,
                    overlayText: overlayText,
                    textScale: textScale
                )
                .clipShape(RoundedRectangle(cornerRadius: 18))
                .onChange(of: selectedQuad) { _ in clearGeneratedPreview() }
                .onChange(of: textPlaneCenter) { _ in clearGeneratedPreview() }
                if isLoadingPreview {
                    VStack(spacing: 8) {
                        ProgressView()
                        Text("正在更新预览帧")
                            .font(.caption)
                    }
                    .padding(14)
                    .background(.ultraThinMaterial)
                    .clipShape(RoundedRectangle(cornerRadius: 14))
                }
            } else {
                VStack(spacing: 12) {
                    Image(systemName: "video.badge.plus")
                        .font(.system(size: 48))
                    Text("还没有导入视频")
                        .font(.headline)
                    Text("点下面的“从文件导入”或“从相册导入”开始")
                        .foregroundStyle(.secondary)
                }
            }
        }
        .frame(maxWidth: .infinity)
        .frame(height: 420)
    }

    private var controls: some View {
        VStack(spacing: 12) {
            HStack(spacing: 10) {
                Button("从文件导入") { activeSheet = .fileImporter }
                    .buttonStyle(.borderedProminent)
                    .disabled(isRendering)

                Button("从相册导入") { activeSheet = .photoImporter }
                    .buttonStyle(.bordered)
                    .disabled(isRendering)

                Button("重选四点") {
                    selectedQuad.removeAll()
                    textPlaneCenter = CGPoint(x: 0.5, y: 0.5)
                    clearGeneratedPreview()
                }
                .buttonStyle(.bordered)
                .disabled(firstFrame == nil || isRendering)
            }

            if inputURL != nil { videoScrubber }

            TextField("贴在墙上的文字", text: $overlayText)
                .textFieldStyle(.roundedBorder)
                .disabled(isRendering)
                .onChange(of: overlayText) { _ in clearGeneratedPreview() }

            textControls

            Picker("追踪质量", selection: $trackingQuality) {
                ForEach(TrackingQuality.allCases, id: \.self) { q in Text(q.title).tag(q) }
            }
            .pickerStyle(.segmented)
            .disabled(isRendering)
            .onChange(of: trackingQuality) { _ in clearGeneratedPreview() }

            Picker("导出格式", selection: $outputProfile) {
                ForEach(OutputProfile.allCases, id: \.self) { p in Text(p.title).tag(p) }
            }
            .pickerStyle(.segmented)
            .disabled(isRendering)

            Toggle("保留原视频音频", isOn: $preserveAudio)
                .disabled(isRendering)
            Toggle("导出平面相机位姿 JSON", isOn: $exportCameraSolve)
                .disabled(isRendering)

            renderMainButton

            if isRendering { ProgressView(value: progress) }

            trackedPreviewSection

            if outputURL != nil {
                Button("分享 / 保存导出视频") { activeSheet = .shareOutput }
                    .buttonStyle(.bordered)
            }

            errorLogSection
        }
    }

    private var errorLogSection: some View {
        Group {
            if !errorLog.isEmpty {
                VStack(alignment: .leading, spacing: 8) {
                    HStack {
                        Text("错误日志")
                            .font(.headline)
                        Spacer()
                        Button("复制错误日志") {
                            UIPasteboard.general.string = errorLog
                            status = "错误日志已复制。"
                        }
                        .buttonStyle(.borderedProminent)
                    }
                    TextEditor(text: $errorLog)
                        .font(.system(.caption, design: .monospaced))
                        .frame(minHeight: 180)
                        .overlay(RoundedRectangle(cornerRadius: 10).stroke(.secondary.opacity(0.25)))
                    Text("把上面整段复制发我，我就能看到具体失败阶段、错误 domain/code、视频参数和当前设置。")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                .padding(10)
                .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 14))
            }
        }
    }

    private var canBuildPreview: Bool {
        inputURL != nil && selectedQuad.count == 4 && !overlayText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty && !isRendering && !isLoadingPreview
    }

    private var canExportFinal: Bool { !trackedPreviewFrames.isEmpty && canBuildPreview }
    private var canStartRender: Bool { canBuildPreview }

    private var renderMainButton: some View {
        VStack(spacing: 8) {
            Button { renderProxyPreview() } label: {
                HStack {
                    if isRendering { ProgressView().scaleEffect(0.8) }
                    Text(isRendering ? "处理中..." : "生成 720p 内存预览")
                }
                .frame(maxWidth: .infinity)
            }
            .buttonStyle(.borderedProminent)
            .disabled(!canBuildPreview)

            Button { renderFinal() } label: {
                Text("确认效果，导出原片")
                    .frame(maxWidth: .infinity)
            }
            .buttonStyle(.bordered)
            .disabled(!canExportFinal)
        }
    }

    private var trackedPreviewSection: some View {
        Group {
            if !trackedPreviewFrames.isEmpty {
                VStack(alignment: .leading, spacing: 8) {
                    Text("跟踪预览")
                        .font(.headline)
                    PreviewFramesPlayer(frames: trackedPreviewFrames)
                        .frame(height: 320)
                        .clipShape(RoundedRectangle(cornerRadius: 16))
                    Text("这是内存预览，不写入视频文件；确认效果没问题后，再点“导出原片”。")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
            }
        }
    }

    @ViewBuilder
    private var bottomActionBar: some View {
        if inputURL != nil {
            VStack(spacing: 8) {
                if isRendering { ProgressView(value: progress) }
                HStack(spacing: 10) {
                    VStack(alignment: .leading, spacing: 2) {
                        Text(bottomStatusTitle)
                            .font(.caption.bold())
                        Text(isLoadingPreview ? "正在更新预览帧" : status)
                            .font(.caption2)
                            .lineLimit(1)
                            .foregroundStyle(.secondary)
                    }
                    Spacer(minLength: 10)
                    Button {
                        if trackedPreviewFrames.isEmpty { renderProxyPreview() } else { renderFinal() }
                    } label: {
                        HStack(spacing: 6) {
                            if isRendering { ProgressView().scaleEffect(0.75) }
                            Text(isRendering ? "处理中" : (trackedPreviewFrames.isEmpty ? "生成预览" : "导出原片"))
                                .font(.callout.bold())
                        }
                    }
                    .buttonStyle(.borderedProminent)
                    .disabled(trackedPreviewFrames.isEmpty ? !canBuildPreview : !canExportFinal)
                }
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 10)
            .background(.regularMaterial)
        }
    }

    private var bottomStatusTitle: String {
        if selectedQuad.count == 4 {
            return trackedPreviewFrames.isEmpty ? "四点已选，先生成预览" : "预览已生成，可导出原片"
        }
        return "先选四点：\(selectedQuad.count)/4"
    }

    private var videoScrubber: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack {
                Text("文字出现帧")
                    .font(.footnote.bold())
                Spacer()
                Text("\(formatTime(previewTime)) / \(formatTime(videoDuration))")
                    .font(.caption.monospacedDigit())
                    .foregroundStyle(.secondary)
            }
            Slider(value: $previewTime, in: 0...max(videoDuration, 0.01), onEditingChanged: { editing in
                if !editing { scheduleLivePreviewFrame(at: previewTime, clearPoints: false, delay: 0) }
            })
            .disabled(isRendering || videoDuration <= 0)
            .onChange(of: previewTime) { newValue in
                scheduleLivePreviewFrame(at: newValue, clearPoints: false, delay: 0.015)
            }
            HStack(spacing: 10) {
                Button("-1s") { jumpPreview(by: -1) }.buttonStyle(.bordered)
                Button("+1s") { jumpPreview(by: 1) }.buttonStyle(.bordered)
                Button("刷新当前帧") { loadPreviewFrame(at: previewTime, clearPoints: false) }.buttonStyle(.bordered)
            }
            .disabled(isRendering || isLoadingPreview)
        }
    }

    private var textControls: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text("文字大小")
                Spacer()
                Text(String(format: "%.2fx", textScale))
                    .foregroundStyle(.secondary)
                    .monospacedDigit()
            }
            Slider(value: $textScale, in: 0.35...2.50)
                .disabled(isRendering)
                .onChange(of: textScale) { _ in clearGeneratedPreview() }

            HStack {
                Text("文字位置")
                Spacer()
                Text("直接在预览里拖动")
                    .foregroundStyle(.secondary)
            }

            Button("文字回到框选中心") {
                textPlaneCenter = CGPoint(x: 0.5, y: 0.5)
                clearGeneratedPreview()
            }
            .buttonStyle(.bordered)
            .disabled(isRendering || selectedQuad.count != 4)
        }
        .font(.footnote)
    }

    private var statusBar: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(status)
                .font(.footnote)
                .foregroundStyle(.secondary)
            Text("提示：四点顺序建议为 左上 → 右上 → 右下 → 左下。视频条选的是文字开始出现的帧；导出会保留完整视频，不会裁掉前面。四点选完后可以拖动小黄点微调，也可以拖动画面里的文字定位。")
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private func clearGeneratedPreview() {
        trackedPreviewFrames.removeAll()
    }

    private func scheduleLivePreviewFrame(at seconds: Double, clearPoints: Bool, delay: Double) {
        guard inputURL != nil, !isRendering else { return }
        livePreviewTask?.cancel()
        livePreviewTask = Task { @MainActor in
            if delay > 0 {
                try? await Task.sleep(nanoseconds: UInt64(delay * 1_000_000_000))
            }
            guard !Task.isCancelled else { return }
            loadPreviewFrame(at: seconds, clearPoints: clearPoints)
        }
    }

    private func importPickedVideo(_ pickedURL: URL) {
        do {
            let localURL = try FileStore.copyIntoDocuments(pickedURL)
            inputURL = localURL
            let grabber = FastFrameGrabber(url: localURL)
            frameGrabber = grabber
            errorLog = ""
            firstFrame = nil
            selectedQuad.removeAll()
            outputURL = nil
            clearGeneratedPreview()
            progress = 0
            previewTime = 0
            videoDuration = 0
            textPlaneCenter = CGPoint(x: 0.5, y: 0.5)
            status = "已导入：\(localURL.lastPathComponent)。初始化 1/3：读取视频信息..."
            Task {
                do {
                    let duration = grabber.duration
                    let image = try await grabber.image(at: 0)
                    await MainActor.run {
                        videoDuration = duration
                        firstFrame = image
                        status = "初始化完成。拖动视频条选择文字出现帧，然后在平面上点 4 个角。"
                    }
                } catch {
                    await MainActor.run { status = "读取视频失败：\(error.localizedDescription)" }
                }
            }
        } catch {
            status = "导入失败：\(error.localizedDescription)"
        }
    }

    private func jumpPreview(by delta: Double) {
        let next = min(max(previewTime + delta, 0), max(videoDuration, 0))
        previewTime = next
        loadPreviewFrame(at: next, clearPoints: false)
    }

    private func loadPreviewFrame(at seconds: Double, clearPoints: Bool) {
        guard let inputURL else { return }
        previewRequestID += 1
        let requestID = previewRequestID
        let clampedSeconds = min(max(seconds, 0), max(videoDuration, 0))
        isLoadingPreview = true
        clearGeneratedPreview()
        status = "实时预览：正在抽取 \(formatTime(clampedSeconds)) 的当前帧..."
        Task {
            do {
                let grabber = frameGrabber ?? FastFrameGrabber(url: inputURL)
                let image = try await grabber.image(at: clampedSeconds)
                await MainActor.run {
                    guard requestID == previewRequestID else { return }
                    firstFrame = image
                    previewTime = clampedSeconds
                    if clearPoints {
                        selectedQuad.removeAll()
                        textPlaneCenter = CGPoint(x: 0.5, y: 0.5)
                    }
                    isLoadingPreview = false
                    status = "当前帧已实时刷新。可在当前帧上点选四点或微调。"
                }
            } catch {
                await MainActor.run {
                    guard requestID == previewRequestID else { return }
                    isLoadingPreview = false
                    errorLog = makeErrorLog(error: error, stage: "实时拖动抽帧预览失败", isPreview: true, inputURL: inputURL, startTime: clampedSeconds, quality: trackingQuality, profile: outputProfile, preserveAudio: preserveAudio, exportJSON: exportCameraSolve)
                    status = "预览帧读取失败：\(error.localizedDescription)。错误日志已生成，可直接复制。"
                }
            }
        }
    }

    private func renderProxyPreview() { startRender(isPreview: true) }
    private func renderFinal() { startRender(isPreview: false) }
    private func render() { renderFinal() }

    private func startRender(isPreview: Bool) {
        guard let inputURL, selectedQuad.count == 4 else { return }
        isRendering = true
        progress = 0
        errorLog = ""
        if isPreview { clearGeneratedPreview() }
        outputURL = nil
        status = isPreview ? "初始化：准备生成 720p 内存预览..." : "初始化：准备导出原片..."

        let text = overlayText
        let quad = selectedQuad
        let quality = trackingQuality
        let profile = isPreview ? OutputProfile.h264Compatibility : outputProfile
        let keepAudio = isPreview ? false : preserveAudio
        let solveCamera = isPreview ? false : exportCameraSolve
        let startTime = previewTime
        let overlaySettings = TextOverlaySettings(scale: textScale, planeCenterX: textPlaneCenter.x, planeCenterY: textPlaneCenter.y)
        let outputMaxDimension: Int? = isPreview ? 720 : nil
        let prefix = isPreview ? "tracked_preview_memory_v14" : "tracked_final_v14"

        Task {
            do {
                await setRenderProgress(0.02, isPreview ? "初始化 1/6：准备 720p 内存预览..." : "初始化 1/6：准备原片导出...")
                try await Task.sleep(nanoseconds: 160_000_000)
                await setRenderProgress(0.04, "初始化 2/6：准备视频读取器...")
                try await Task.sleep(nanoseconds: 160_000_000)
                await setRenderProgress(0.06, "初始化 3/6：准备编码器...")
                try await Task.sleep(nanoseconds: 160_000_000)
                await setRenderProgress(0.08, "初始化 4/6：准备文字贴图...")
                try await Task.sleep(nanoseconds: 160_000_000)
                await setRenderProgress(0.10, "初始化 5/6：启动追踪模块...")
                try await Task.sleep(nanoseconds: 160_000_000)
                await setRenderProgress(0.12, "初始化 6/6：开始逐帧处理...")

                if isPreview {
                    let frames = try await VideoPlaneCompositor.buildPreviewFrames(
                        inputURL: inputURL,
                        normalizedQuad: quad,
                        overlayText: text,
                        overlaySettings: overlaySettings,
                        startTimeSeconds: startTime,
                        quality: quality,
                        outputMaxDimension: outputMaxDimension ?? 720
                    ) { value, message in
                        Task { @MainActor in
                            progress = value
                            status = message
                        }
                    }

                    await MainActor.run {
                        isRendering = false
                        progress = 1
                        trackedPreviewFrames = frames
                        outputURL = nil
                        status = "720p 内存预览生成完成。确认效果后再导出原片。"
                    }
                } else {
                    let url: URL
                    do {
                        url = try await VideoPlaneCompositor.render(
                            inputURL: inputURL,
                            normalizedQuad: quad,
                            overlayText: text,
                            overlaySettings: overlaySettings,
                            startTimeSeconds: startTime,
                            quality: quality,
                            outputProfile: profile,
                            preserveAudio: keepAudio,
                            exportCameraSolve: solveCamera,
                            outputMaxDimension: outputMaxDimension,
                            outputPrefix: prefix
                        ) { value, message in
                            Task { @MainActor in
                                progress = value
                                status = message
                            }
                        }
                    } catch {
                        let firstError = error
                        await MainActor.run {
                            errorLog = makeErrorLog(error: firstError, stage: "常规原片导出失败，准备自动安全模式", isPreview: false, inputURL: inputURL, startTime: startTime, quality: quality, profile: profile, preserveAudio: keepAudio, exportJSON: solveCamera)
                        }
                        await setRenderProgress(0.05, "常规导出失败，自动切换安全模式：H.264 / 无音频 / 无 JSON...")
                        do {
                            url = try await VideoPlaneCompositor.render(
                                inputURL: inputURL,
                                normalizedQuad: quad,
                                overlayText: text,
                                overlaySettings: overlaySettings,
                                startTimeSeconds: startTime,
                                quality: quality,
                                outputProfile: .h264Compatibility,
                                preserveAudio: false,
                                exportCameraSolve: false,
                                outputMaxDimension: nil,
                                outputPrefix: "tracked_final_safe_v14"
                            ) { value, message in
                                Task { @MainActor in
                                    progress = value
                                    status = "安全模式：" + message
                                }
                            }
                        } catch {
                            let fallbackError = error
                            await MainActor.run {
                                isRendering = false
                                progress = 0
                                outputURL = nil
                                errorLog = makeErrorLog(error: firstError, stage: "常规原片导出失败", isPreview: false, inputURL: inputURL, startTime: startTime, quality: quality, profile: profile, preserveAudio: keepAudio, exportJSON: solveCamera)
                                    + "\n\n===== 安全模式也失败 =====\n\n"
                                    + makeErrorLog(error: fallbackError, stage: "安全模式导出失败", isPreview: false, inputURL: inputURL, startTime: startTime, quality: quality, profile: .h264Compatibility, preserveAudio: false, exportJSON: false)
                                status = "导出失败：已生成可复制错误日志。"
                            }
                            return
                        }
                    }

                    await MainActor.run {
                        isRendering = false
                        progress = 1
                        outputURL = url
                        status = "原片导出完成：\(url.lastPathComponent)"
                    }
                }
            } catch {
                await MainActor.run {
                    isRendering = false
                    progress = 0
                    errorLog = makeErrorLog(error: error, stage: isPreview ? "生成 720p 内存预览失败" : "导出流程失败", isPreview: isPreview, inputURL: inputURL, startTime: startTime, quality: quality, profile: profile, preserveAudio: keepAudio, exportJSON: solveCamera)
                    status = (isPreview ? "预览生成失败：" : "导出失败：") + error.localizedDescription + "。错误日志已生成，可直接复制。"
                }
            }
        }
    }

    @MainActor
    private func setRenderProgress(_ value: Double, _ message: String) {
        progress = value
        status = message
    }


    private func makeErrorLog(
        error: Error,
        stage: String,
        isPreview: Bool,
        inputURL: URL,
        startTime: Double,
        quality: TrackingQuality,
        profile: OutputProfile,
        preserveAudio: Bool,
        exportJSON: Bool
    ) -> String {
        let attributes = try? FileManager.default.attributesOfItem(atPath: inputURL.path)
        let fileSize = (attributes?[.size] as? NSNumber)?.int64Value ?? -1
        let quadText = selectedQuad.enumerated().map { idx, p in
            "P\(idx + 1)=(\(String(format: "%.5f", p.x)), \(String(format: "%.5f", p.y)))"
        }.joined(separator: ", ")
        let appVersion = Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "unknown"
        var lines: [String] = []
        lines.append("Track3DTool Error Log")
        lines.append("app_version: \(appVersion)")
        lines.append("ui_version: v14")
        lines.append("time: \(ISO8601DateFormatter().string(from: Date()))")
        lines.append("device: \(UIDevice.current.model) / \(UIDevice.current.systemName) \(UIDevice.current.systemVersion)")
        lines.append("stage: \(stage)")
        lines.append("mode: \(isPreview ? "720p_memory_preview" : "final_export")")
        lines.append("input: \(inputURL.lastPathComponent)")
        lines.append("input_path: \(inputURL.path)")
        lines.append("input_file_size_bytes: \(fileSize)")
        lines.append("video_duration_seconds: \(String(format: "%.3f", videoDuration))")
        lines.append("text_start_seconds: \(String(format: "%.3f", startTime))")
        lines.append("selected_points: \(quadText)")
        lines.append("text: \(overlayText)")
        lines.append("text_scale: \(String(format: "%.3f", textScale))")
        lines.append("text_plane_center: (\(String(format: "%.5f", textPlaneCenter.x)), \(String(format: "%.5f", textPlaneCenter.y)))")
        lines.append("tracking_quality: \(quality.rawValue)")
        lines.append("output_profile: \(profile.rawValue)")
        lines.append("preserve_audio: \(preserveAudio)")
        lines.append("export_json: \(exportJSON)")
        lines.append("progress: \(String(format: "%.3f", progress))")
        lines.append("status_text: \(status)")
        lines.append("")
        lines.append("error_detail:")
        lines.append(describeError(error))
        return lines.joined(separator: "\n")
    }

    private func describeError(_ error: Error, indent: String = "") -> String {
        let ns = error as NSError
        var lines: [String] = []
        lines.append("\(indent)localizedDescription: \(ns.localizedDescription)")
        lines.append("\(indent)domain: \(ns.domain)")
        lines.append("\(indent)code: \(ns.code)")
        if let reason = ns.localizedFailureReason { lines.append("\(indent)failureReason: \(reason)") }
        if let suggestion = ns.localizedRecoverySuggestion { lines.append("\(indent)recoverySuggestion: \(suggestion)") }
        if !ns.userInfo.isEmpty {
            let safeUserInfo = ns.userInfo.map { key, value in "\(key)=\(value)" }.joined(separator: "; ")
            lines.append("\(indent)userInfo: \(safeUserInfo)")
        }
        if let underlying = ns.userInfo[NSUnderlyingErrorKey] as? Error {
            lines.append("\(indent)underlyingError:")
            lines.append(describeError(underlying, indent: indent + "  "))
        }
        return lines.joined(separator: "\n")
    }


    private func formatTime(_ seconds: Double) -> String {
        guard seconds.isFinite else { return "0:00" }
        let total = max(0, Int(seconds.rounded()))
        let minutes = total / 60
        let secs = total % 60
        return String(format: "%d:%02d", minutes, secs)
    }
}


struct PreviewFramesPlayer: View {
    let frames: [UIImage]
    @State private var index: Int = 0
    private let timer = Timer.publish(every: 1.0 / 12.0, on: .main, in: .common).autoconnect()

    var body: some View {
        ZStack {
            Color.black.opacity(0.05)
            if frames.isEmpty {
                Text("暂无预览")
                    .foregroundStyle(.secondary)
            } else {
                Image(uiImage: frames[min(index, frames.count - 1)])
                    .resizable()
                    .scaledToFit()
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
        }
        .onReceive(timer) { _ in
            guard !frames.isEmpty else { return }
            index = (index + 1) % frames.count
        }
        .onChange(of: frames.count) { _ in
            index = 0
        }
    }
}

struct TrackedVideoPlayer: View {
    let url: URL
    @State private var player: AVPlayer?

    var body: some View {
        VideoPlayer(player: player)
            .onAppear {
                player = AVPlayer(url: url)
                player?.play()
            }
            .onDisappear {
                player?.pause()
                player = nil
            }
            .id(url)
    }
}

struct ShareSheet: UIViewControllerRepresentable {
    let items: [Any]
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: items, applicationActivities: nil)
    }
    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}
