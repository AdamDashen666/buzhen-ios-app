import Foundation
import CoreGraphics

struct Affine2D {
    let a: CGFloat
    let b: CGFloat
    let c: CGFloat
    let d: CGFloat
    let tx: CGFloat
    let ty: CGFloat

    static let identity = Affine2D(a: 1, b: 0, c: 0, d: 1, tx: 0, ty: 0)

    func apply(_ p: CGPoint) -> CGPoint {
        CGPoint(x: a * p.x + b * p.y + tx, y: c * p.x + d * p.y + ty)
    }
}

struct AffineEstimator {
    static func estimate(from src: [CGPoint], to dst: [CGPoint]) -> Affine2D? {
        guard src.count == dst.count, src.count >= 3 else { return nil }
        var normal = Array(repeating: Array(repeating: 0.0, count: 6), count: 6)
        var rhs = Array(repeating: 0.0, count: 6)

        for i in 0..<src.count {
            let x = Double(src[i].x)
            let y = Double(src[i].y)
            let u = Double(dst[i].x)
            let v = Double(dst[i].y)
            let row1 = [x, y, 0, 0, 1, 0]
            let row2 = [0, 0, x, y, 0, 1]
            accumulate(row: row1, value: u, normal: &normal, rhs: &rhs)
            accumulate(row: row2, value: v, normal: &normal, rhs: &rhs)
        }

        guard let sol = solve(normal, rhs) else { return nil }
        return Affine2D(
            a: CGFloat(sol[0]), b: CGFloat(sol[1]),
            c: CGFloat(sol[2]), d: CGFloat(sol[3]),
            tx: CGFloat(sol[4]), ty: CGFloat(sol[5])
        )
    }

    private static func accumulate(row: [Double], value: Double, normal: inout [[Double]], rhs: inout [Double]) {
        for r in 0..<6 {
            rhs[r] += row[r] * value
            for c in 0..<6 {
                normal[r][c] += row[r] * row[c]
            }
        }
    }

    private static func solve(_ a: [[Double]], _ b: [Double]) -> [Double]? {
        let n = b.count
        var m = a
        var x = b
        for i in 0..<n {
            var pivot = i
            var maxVal = abs(m[i][i])
            for r in i..<n where abs(m[r][i]) > maxVal {
                maxVal = abs(m[r][i])
                pivot = r
            }
            guard maxVal > 1e-9 else { return nil }
            if pivot != i {
                m.swapAt(i, pivot)
                x.swapAt(i, pivot)
            }
            let div = m[i][i]
            for c in i..<n { m[i][c] /= div }
            x[i] /= div
            for r in 0..<n where r != i {
                let factor = m[r][i]
                for c in i..<n { m[r][c] -= factor * m[i][c] }
                x[r] -= factor * x[i]
            }
        }
        return x
    }
}
