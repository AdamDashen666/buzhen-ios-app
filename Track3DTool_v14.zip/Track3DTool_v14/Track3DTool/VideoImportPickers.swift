import SwiftUI
import UniformTypeIdentifiers
import PhotosUI

struct FileVideoPicker: UIViewControllerRepresentable {
    let onPick: (URL) -> Void
    let onCancel: () -> Void
    let onError: (String) -> Void

    func makeCoordinator() -> Coordinator {
        Coordinator(onPick: onPick, onCancel: onCancel, onError: onError)
    }

    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        // Keep .item as a fallback because some third-party file managers report videos with incomplete UTType metadata.
        let types: [UTType] = [
            .movie,
            .video,
            .mpeg4Movie,
            .quickTimeMovie,
            .audiovisualContent,
            .item
        ]
        let controller = UIDocumentPickerViewController(forOpeningContentTypes: types, asCopy: true)
        controller.allowsMultipleSelection = false
        controller.shouldShowFileExtensions = true
        controller.delegate = context.coordinator
        controller.modalPresentationStyle = .formSheet
        return controller
    }

    func updateUIViewController(_ uiViewController: UIDocumentPickerViewController, context: Context) {}

    final class Coordinator: NSObject, UIDocumentPickerDelegate {
        let onPick: (URL) -> Void
        let onCancel: () -> Void
        let onError: (String) -> Void

        init(onPick: @escaping (URL) -> Void,
             onCancel: @escaping () -> Void,
             onError: @escaping (String) -> Void) {
            self.onPick = onPick
            self.onCancel = onCancel
            self.onError = onError
        }

        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            guard let url = urls.first else {
                onError("没有拿到文件地址")
                return
            }
            onPick(url)
        }

        func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
            onCancel()
        }
    }
}

struct PhotoVideoPicker: UIViewControllerRepresentable {
    let onPick: (URL) -> Void
    let onCancel: () -> Void
    let onError: (String) -> Void

    func makeCoordinator() -> Coordinator {
        Coordinator(onPick: onPick, onCancel: onCancel, onError: onError)
    }

    func makeUIViewController(context: Context) -> PHPickerViewController {
        var configuration = PHPickerConfiguration(photoLibrary: .shared())
        configuration.filter = .videos
        configuration.selectionLimit = 1
        configuration.preferredAssetRepresentationMode = .current
        let controller = PHPickerViewController(configuration: configuration)
        controller.delegate = context.coordinator
        return controller
    }

    func updateUIViewController(_ uiViewController: PHPickerViewController, context: Context) {}

    final class Coordinator: NSObject, PHPickerViewControllerDelegate {
        let onPick: (URL) -> Void
        let onCancel: () -> Void
        let onError: (String) -> Void

        init(onPick: @escaping (URL) -> Void,
             onCancel: @escaping () -> Void,
             onError: @escaping (String) -> Void) {
            self.onPick = onPick
            self.onCancel = onCancel
            self.onError = onError
        }

        func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
            picker.dismiss(animated: true)
            guard let provider = results.first?.itemProvider else {
                onCancel()
                return
            }

            let preferredTypes = [
                UTType.movie.identifier,
                UTType.video.identifier,
                UTType.mpeg4Movie.identifier,
                UTType.quickTimeMovie.identifier,
                "public.mpeg-4",
                "com.apple.quicktime-movie"
            ]

            let selectedType = preferredTypes.first { provider.hasItemConformingToTypeIdentifier($0) }
                ?? provider.registeredTypeIdentifiers.first

            guard let typeIdentifier = selectedType else {
                onError("没有识别到视频类型")
                return
            }

            provider.loadFileRepresentation(forTypeIdentifier: typeIdentifier) { sourceURL, error in
                if let error {
                    DispatchQueue.main.async { self.onError(error.localizedDescription) }
                    return
                }
                guard let sourceURL else {
                    DispatchQueue.main.async { self.onError("相册没有返回可读取的视频文件") }
                    return
                }

                do {
                    let ext = Self.preferredExtension(for: sourceURL, typeIdentifier: typeIdentifier)
                    let tempURL = FileManager.default.temporaryDirectory
                        .appendingPathComponent("picked_video_\(UUID().uuidString)")
                        .appendingPathExtension(ext)
                    if FileManager.default.fileExists(atPath: tempURL.path) {
                        try FileManager.default.removeItem(at: tempURL)
                    }
                    try FileManager.default.copyItem(at: sourceURL, to: tempURL)
                    DispatchQueue.main.async { self.onPick(tempURL) }
                } catch {
                    DispatchQueue.main.async { self.onError(error.localizedDescription) }
                }
            }
        }

        private static func preferredExtension(for url: URL, typeIdentifier: String) -> String {
            let pathExt = url.pathExtension.lowercased()
            if !pathExt.isEmpty { return pathExt }
            if typeIdentifier.contains("mpeg") || typeIdentifier.contains("mp4") { return "mp4" }
            return "mov"
        }
    }
}
