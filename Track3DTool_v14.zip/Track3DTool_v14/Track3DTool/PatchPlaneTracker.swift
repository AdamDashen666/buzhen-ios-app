import Foundation
import CoreGraphics

struct PatchTrackResult {
    let quadOriginalPixels: [CGPoint]
    let confidence: Double
    let inlierCount: Int
    let status: String
}

final class PatchPlaneTracker {
    private struct TrackPoint {
        let initial: CGPoint
        var current: CGPoint
        let template: [UInt8]
        var lostFrames: Int
    }

    private var points: [TrackPoint] = []
    private let initialQuad: [CGPoint]
    private let quality: TrackingQuality
    private var lastHomography: Homography2D = .identity
    private var lastGoodQuad: [CGPoint]
    private var frameCounter = 0

    init?(initialImage: ImageGray, quadInOriginalPixels: [CGPoint], quality: TrackingQuality) {
        guard quadInOriginalPixels.count == 4 else { return nil }
        self.quality = quality
        let s = initialImage.scaleFromOriginal
        self.initialQuad = quadInOriginalPixels.map { CGPoint(x: $0.x * s, y: $0.y * s) }
        self.lastGoodQuad = self.initialQuad
        let radius = quality.patchRadius
        var created: [TrackPoint] = []

        for gy in 0..<quality.gridY {
            for gx in 0..<quality.gridX {
                let u = CGFloat(gx + 1) / CGFloat(quality.gridX + 1)
                let v = CGFloat(gy + 1) / CGFloat(quality.gridY + 1)
                let p = bilinear(initialQuad, u: u, v: v)
                if let patch = initialImage.patch(center: p, radius: radius), textureEnergy(patch) > 7.0 {
                    created.append(TrackPoint(initial: p, current: p, template: patch, lostFrames: 0))
                }
            }
        }
        guard created.count >= 8 else { return nil }
        self.points = created
    }

    func track(nextImage: ImageGray) -> PatchTrackResult {
        frameCounter += 1
        let radius = quality.patchRadius
        let baseSearch = quality.searchRadius
        var src: [CGPoint] = []
        var dst: [CGPoint] = []
        var pointIndices: [Int] = []
        var newPoints = points
        var scores: [Double] = []

        for i in 0..<newPoints.count {
            let predicted = lastHomography.apply(newPoints[i].initial)
            let backupPredicted = newPoints[i].current
            let search = min(baseSearch * 2, baseSearch + newPoints[i].lostFrames * 5)
            let first = bestMatch(image: nextImage, template: newPoints[i].template, predicted: predicted, radius: radius, search: search)
            let second = bestMatch(image: nextImage, template: newPoints[i].template, predicted: backupPredicted, radius: radius, search: max(8, baseSearch / 2))

            let candidate: (CGPoint, Double)?
            if let first, let second {
                candidate = first.1 >= second.1 ? first : second
            } else {
                candidate = first ?? second
            }

            if let candidate, candidate.1 >= quality.minNCC {
                src.append(newPoints[i].initial)
                dst.append(candidate.0)
                pointIndices.append(i)
                scores.append(candidate.1)
                newPoints[i].current = candidate.0
                newPoints[i].lostFrames = 0
            } else {
                newPoints[i].lostFrames += 1
            }
        }

        if src.count >= 4,
           let robust = HomographyEstimator.robust(from: src, to: dst, threshold: quality.ransacError) {
            var inlierScores: [Double] = []
            for inlier in robust.inliers {
                if inlier < scores.count { inlierScores.append(scores[inlier]) }
                if inlier < pointIndices.count {
                    let idx = pointIndices[inlier]
                    newPoints[idx].current = robust.model.apply(newPoints[idx].initial)
                    newPoints[idx].lostFrames = 0
                }
            }

            lastHomography = robust.model
            let q = initialQuad.map { robust.model.apply($0) }
            lastGoodQuad = q
            self.points = newPoints

            let rawScore = inlierScores.isEmpty ? 0 : inlierScores.reduce(0, +) / Double(inlierScores.count)
            let coverage = min(1.0, Double(robust.inliers.count) / Double(max(1, points.count / 2)))
            let confidence = max(0.0, min(1.0, rawScore * coverage))
            let status: String
            if confidence > 0.70 {
                status = "稳定"
            } else if confidence > 0.45 {
                status = "可用，轻微漂移风险"
            } else {
                status = "低置信度，已启用重定位"
            }
            return result(quad: q, scale: nextImage.scaleFromOriginal, confidence: confidence, inliers: robust.inliers.count, status: status)
        }

        // Relocalization fallback: keep the last good plane instead of snapping back to frame 0.
        self.points = newPoints
        let decayedConfidence = max(0.05, 0.25 - Double(min(frameCounter, 20)) * 0.004)
        return result(quad: lastGoodQuad, scale: nextImage.scaleFromOriginal, confidence: decayedConfidence, inliers: src.count, status: "遮挡/低纹理：使用上一帧预测")
    }

    private func result(quad: [CGPoint], scale: CGFloat, confidence: Double, inliers: Int, status: String) -> PatchTrackResult {
        let inv = 1 / scale
        let originalQ = quad.map { CGPoint(x: $0.x * inv, y: $0.y * inv) }
        return PatchTrackResult(quadOriginalPixels: originalQ, confidence: confidence, inlierCount: inliers, status: status)
    }

    private func bestMatch(image: ImageGray, template: [UInt8], predicted: CGPoint, radius: Int, search: Int) -> (CGPoint, Double)? {
        var bestScore = -Double.greatestFiniteMagnitude
        var best = predicted
        let centerX = Int(round(predicted.x))
        let centerY = Int(round(predicted.y))
        let step = search > 24 ? 2 : 1

        for dy in stride(from: -search, through: search, by: step) {
            for dx in stride(from: -search, through: search, by: step) {
                let candidate = CGPoint(x: CGFloat(centerX + dx), y: CGFloat(centerY + dy))
                guard let patch = image.patch(center: candidate, radius: radius) else { continue }
                let score = ncc(template, patch)
                if score > bestScore {
                    bestScore = score
                    best = candidate
                }
            }
        }

        // Fine pass around coarse winner.
        if step > 1 {
            let coarse = best
            for dy in -2...2 {
                for dx in -2...2 {
                    let candidate = CGPoint(x: coarse.x + CGFloat(dx), y: coarse.y + CGFloat(dy))
                    guard let patch = image.patch(center: candidate, radius: radius) else { continue }
                    let score = ncc(template, patch)
                    if score > bestScore {
                        bestScore = score
                        best = candidate
                    }
                }
            }
        }

        return bestScore.isFinite ? (best, bestScore) : nil
    }

    private func bilinear(_ q: [CGPoint], u: CGFloat, v: CGFloat) -> CGPoint {
        let top = CGPoint(x: q[0].x + (q[1].x - q[0].x) * u, y: q[0].y + (q[1].y - q[0].y) * u)
        let bottom = CGPoint(x: q[3].x + (q[2].x - q[3].x) * u, y: q[3].y + (q[2].y - q[3].y) * u)
        return CGPoint(x: top.x + (bottom.x - top.x) * v, y: top.y + (bottom.y - top.y) * v)
    }

    private func textureEnergy(_ patch: [UInt8]) -> Double {
        guard !patch.isEmpty else { return 0 }
        let mean = patch.reduce(0.0) { $0 + Double($1) } / Double(patch.count)
        let variance = patch.reduce(0.0) { acc, px in
            let d = Double(px) - mean
            return acc + d * d
        } / Double(patch.count)
        return sqrt(variance)
    }

    private func ncc(_ a: [UInt8], _ b: [UInt8]) -> Double {
        guard a.count == b.count, !a.isEmpty else { return -1 }
        let n = Double(a.count)
        var meanA = 0.0
        var meanB = 0.0
        for i in 0..<a.count {
            meanA += Double(a[i])
            meanB += Double(b[i])
        }
        meanA /= n
        meanB /= n
        var num = 0.0
        var da = 0.0
        var db = 0.0
        for i in 0..<a.count {
            let x = Double(a[i]) - meanA
            let y = Double(b[i]) - meanB
            num += x * y
            da += x * x
            db += y * y
        }
        let denom = sqrt(da * db)
        guard denom > 1e-6 else { return -1 }
        return num / denom
    }
}
