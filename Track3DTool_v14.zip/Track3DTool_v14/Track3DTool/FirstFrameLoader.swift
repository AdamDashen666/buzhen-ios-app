import UIKit
import AVFoundation
import Dispatch

struct FirstFrameLoader {
    static func duration(url: URL) async throws -> Double {
        try await Task.detached(priority: .userInitiated) {
            let asset = AVAsset(url: url)
            let seconds = asset.duration.seconds
            return seconds.isFinite ? max(0, seconds) : 0
        }.value
    }

    static func load(url: URL, at seconds: Double = 0) async throws -> UIImage {
        try await Task.detached(priority: .userInitiated) {
            let asset = AVAsset(url: url)
            let generator = AVAssetImageGenerator(asset: asset)
            generator.appliesPreferredTrackTransform = false // Keep coordinates aligned with AVAssetReader pixel buffers.
            generator.maximumSize = CGSize(width: 1920, height: 1920)
            generator.requestedTimeToleranceBefore = CMTime(seconds: 0.025, preferredTimescale: 600)
            generator.requestedTimeToleranceAfter = CMTime(seconds: 0.025, preferredTimescale: 600)
            let clamped = min(max(seconds, 0), max(asset.duration.seconds.isFinite ? asset.duration.seconds : 0, 0))
            let time = CMTime(seconds: clamped, preferredTimescale: 600)
            let cg = try generator.copyCGImage(at: time, actualTime: nil)
            return UIImage(cgImage: cg)
        }.value
    }
}


final class FastFrameGrabber {
    private let asset: AVAsset
    private let generator: AVAssetImageGenerator
    private let queue = DispatchQueue(label: "Track3DTool.FastFrameGrabber")

    init(url: URL, maximumSize: CGSize = CGSize(width: 1600, height: 1600)) {
        self.asset = AVAsset(url: url)
        self.generator = AVAssetImageGenerator(asset: asset)
        self.generator.appliesPreferredTrackTransform = false
        self.generator.maximumSize = maximumSize
        self.generator.requestedTimeToleranceBefore = CMTime(seconds: 0.015, preferredTimescale: 600)
        self.generator.requestedTimeToleranceAfter = CMTime(seconds: 0.015, preferredTimescale: 600)
    }

    var duration: Double {
        let seconds = asset.duration.seconds
        return seconds.isFinite ? max(0, seconds) : 0
    }

    func image(at seconds: Double) async throws -> UIImage {
        try await withCheckedThrowingContinuation { continuation in
            queue.async {
                let maxDuration = self.duration
                let clamped = min(max(seconds, 0), max(maxDuration, 0))
                let time = CMTime(seconds: clamped, preferredTimescale: 600)
                do {
                    let cg = try self.generator.copyCGImage(at: time, actualTime: nil)
                    continuation.resume(returning: UIImage(cgImage: cg))
                } catch {
                    continuation.resume(throwing: error)
                }
            }
        }
    }
}
