import SwiftUI

@main
struct Track3DToolApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
