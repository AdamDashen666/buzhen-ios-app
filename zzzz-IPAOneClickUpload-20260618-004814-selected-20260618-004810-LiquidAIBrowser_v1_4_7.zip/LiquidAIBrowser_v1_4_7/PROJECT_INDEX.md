# LiquidAIBrowser v1.4.7 Project Index

## Main package

- `LiquidAIBrowser_v1_4_7.zip`：完整 Xcode Project。

## Important files

- `LiquidAIBrowser/WebViewPool.swift`：WKWebView 池、浏览器兼容性、URL 过滤、外部 App scheme 静默拦截、Agent Bridge JS。
- `LiquidAIBrowser/BrowserStore.swift`：分组/页面/任务状态、队列、重试任务、会话保存。
- `LiquidAIBrowser/AgentEngine.swift`：AI 规划、执行、重规划、计时器、用户询问、原生 navigate。
- `LiquidAIBrowser/Panels.swift`：任务管理 UI、重试按钮、设置页。
- `LiquidAIBrowser/PDFReportExporter.swift`：PDF 报告导出。
- `QA_V14_7_BROWSER_RETRY_FIX_REPORT.md`：本次浏览器/外部跳转/重试功能修复报告。

## Version

- Version: 1.4.7
- Build: 14
