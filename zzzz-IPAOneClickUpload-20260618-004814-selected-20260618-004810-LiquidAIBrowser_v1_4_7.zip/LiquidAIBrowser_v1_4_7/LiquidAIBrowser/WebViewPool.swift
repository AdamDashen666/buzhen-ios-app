import Foundation
import WebKit
import UIKit

final class WebViewPool: NSObject, WKNavigationDelegate, WKUIDelegate {
    weak var store: BrowserStore?
    private var webViews: [UUID: WKWebView] = [:]
    private var tabIDsByWebView: [ObjectIdentifier: UUID] = [:]
    private var progressObservers: [UUID: NSKeyValueObservation] = [:]

    static let desktopSafariUserAgent = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Safari/605.1.15"

    func webView(for tabID: UUID, initialURL: String) -> WKWebView {
        if let existing = webViews[tabID] { return existing }
        let configuration = WKWebViewConfiguration()
        configuration.defaultWebpagePreferences.allowsContentJavaScript = true
        configuration.defaultWebpagePreferences.preferredContentMode = .desktop
        configuration.preferences.javaScriptCanOpenWindowsAutomatically = true
        configuration.allowsInlineMediaPlayback = true
        configuration.mediaTypesRequiringUserActionForPlayback = []
        configuration.applicationNameForUserAgent = "Version/18.0 Safari/605.1.15"
        configuration.websiteDataStore = .default()
        let controller = WKUserContentController()
        controller.addUserScript(WKUserScript(source: Self.agentBridgeScript, injectionTime: .atDocumentEnd, forMainFrameOnly: false))
        configuration.userContentController = controller

        let webView = WKWebView(frame: .zero, configuration: configuration)
        webView.customUserAgent = Self.desktopSafariUserAgent
        webView.navigationDelegate = self
        webView.uiDelegate = self
        webView.allowsBackForwardNavigationGestures = true
        webView.allowsLinkPreview = false
        if #available(iOS 16.4, *) { webView.isInspectable = true }
        webView.scrollView.contentInsetAdjustmentBehavior = .never
        webView.scrollView.keyboardDismissMode = .interactive
        webViews[tabID] = webView
        tabIDsByWebView[ObjectIdentifier(webView)] = tabID
        observeProgress(webView: webView, tabID: tabID)
        load(tabID: tabID, urlString: initialURL)
        return webView
    }

    func destroy(tabID: UUID) {
        progressObservers[tabID]?.invalidate()
        progressObservers.removeValue(forKey: tabID)
        if let webView = webViews.removeValue(forKey: tabID) {
            tabIDsByWebView.removeValue(forKey: ObjectIdentifier(webView))
            webView.stopLoading()
            webView.navigationDelegate = nil
            webView.uiDelegate = nil
        }
    }

    func load(tabID: UUID, urlString: String) {
        guard let webView = webViews[tabID], let url = URL(string: urlString) else { return }
        guard Self.shouldLoadInsideBrowser(url) else {
            // 静默拦截外部 App scheme，避免打断用户视野。Agent/网页只能留在内置浏览器里。
            return
        }
        DispatchQueue.main.async {
            webView.load(URLRequest(url: url))
        }
    }

    static func shouldLoadInsideBrowser(_ url: URL) -> Bool {
        guard let scheme = url.scheme?.lowercased() else { return false }
        if ["http", "https", "about", "file"].contains(scheme) { return true }
        return false
    }

    func goBack(tabID: UUID) { DispatchQueue.main.async { self.webViews[tabID]?.goBack() } }
    func goForward(tabID: UUID) { DispatchQueue.main.async { self.webViews[tabID]?.goForward() } }
    func reload(tabID: UUID) { DispatchQueue.main.async { self.webViews[tabID]?.reload() } }
    func stopLoading(tabID: UUID) { DispatchQueue.main.async { self.webViews[tabID]?.stopLoading() } }

    func refreshProgress(tabID: UUID) {
        guard let webView = webViews[tabID] else { return }
        DispatchQueue.main.async {
            self.store?.updateTab(tabID) { tab in
                tab.estimatedProgress = webView.estimatedProgress
                tab.isLoading = webView.isLoading
                tab.urlString = webView.url?.absoluteString ?? tab.urlString
                tab.title = webView.title ?? tab.title
            }
        }
    }

    private func observeProgress(webView: WKWebView, tabID: UUID) {
        progressObservers[tabID] = webView.observe(\.estimatedProgress, options: [.new]) { [weak self] webView, _ in
            DispatchQueue.main.async {
                self?.store?.updateTab(tabID) { tab in
                    tab.estimatedProgress = webView.estimatedProgress
                    tab.isLoading = webView.isLoading
                }
            }
        }
    }

    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        guard let tabID = tabIDsByWebView[ObjectIdentifier(webView)] else { return }
        DispatchQueue.main.async {
            self.store?.updateTab(tabID) { tab in
                tab.isLoading = true
                tab.estimatedProgress = 0.05
                tab.updatedAt = Date()
            }
        }
    }

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        guard let tabID = tabIDsByWebView[ObjectIdentifier(webView)] else { return }
        DispatchQueue.main.async {
            self.store?.updateTab(tabID) { tab in
                tab.title = webView.title ?? tab.title
                tab.urlString = webView.url?.absoluteString ?? tab.urlString
                tab.isLoading = false
                tab.estimatedProgress = 1
                tab.updatedAt = Date()
            }
            self.captureThumbnail(tabID: tabID)
        }
    }

    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        updateFailure(webView: webView, error: error)
    }

    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        updateFailure(webView: webView, error: error)
    }

    private func updateFailure(webView: WKWebView, error: Error) {
        guard let tabID = tabIDsByWebView[ObjectIdentifier(webView)] else { return }
        DispatchQueue.main.async {
            self.store?.updateTab(tabID) { tab in
                tab.isLoading = false
                tab.updatedAt = Date()
            }
        }
    }

    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = navigationAction.request.url else {
            decisionHandler(.allow)
            return
        }
        guard Self.shouldLoadInsideBrowser(url) else {
            // 静默拦截外部 App scheme，例如 douyin://、snssdk://、bitbrowser://、itms-apps://。
            // 不弹窗，只取消导航，避免遮挡网页和任务。
            decisionHandler(.cancel)
            return
        }
        decisionHandler(.allow)
    }

    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        if navigationAction.targetFrame == nil, let url = navigationAction.request.url {
            if Self.shouldLoadInsideBrowser(url) {
                webView.load(navigationAction.request)
            } else {
                // 外部 App scheme 直接静默取消。
            }
        }
        return nil
    }

    func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping () -> Void) {
        guard let presenter = topViewController() else { completionHandler(); return }
        let alert = UIAlertController(title: frame.securityOrigin.host.isEmpty ? "网页提示" : frame.securityOrigin.host, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default) { _ in completionHandler() })
        presenter.present(alert, animated: true)
    }

    func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (Bool) -> Void) {
        guard let presenter = topViewController() else { completionHandler(false); return }
        let alert = UIAlertController(title: frame.securityOrigin.host.isEmpty ? "网页确认" : frame.securityOrigin.host, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "取消", style: .cancel) { _ in completionHandler(false) })
        alert.addAction(UIAlertAction(title: "确定", style: .default) { _ in completionHandler(true) })
        presenter.present(alert, animated: true)
    }

    func webView(_ webView: WKWebView, runJavaScriptTextInputPanelWithPrompt prompt: String, defaultText: String?, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (String?) -> Void) {
        guard let presenter = topViewController() else { completionHandler(nil); return }
        let alert = UIAlertController(title: frame.securityOrigin.host.isEmpty ? "网页输入" : frame.securityOrigin.host, message: prompt, preferredStyle: .alert)
        alert.addTextField { field in field.text = defaultText }
        alert.addAction(UIAlertAction(title: "取消", style: .cancel) { _ in completionHandler(nil) })
        alert.addAction(UIAlertAction(title: "确定", style: .default) { _ in completionHandler(alert.textFields?.first?.text) })
        presenter.present(alert, animated: true)
    }

    private func topViewController(base: UIViewController? = UIApplication.shared.connectedScenes.compactMap { ($0 as? UIWindowScene)?.keyWindow }.first?.rootViewController) -> UIViewController? {
        if let nav = base as? UINavigationController { return topViewController(base: nav.visibleViewController) }
        if let tab = base as? UITabBarController { return topViewController(base: tab.selectedViewController) }
        if let presented = base?.presentedViewController { return topViewController(base: presented) }
        return base
    }

    func captureThumbnail(tabID: UUID) {
        guard let webView = webViews[tabID] else { return }
        let config = WKSnapshotConfiguration()
        config.rect = CGRect(origin: .zero, size: CGSize(width: max(webView.bounds.width, 320), height: max(webView.bounds.height, 480)))
        config.snapshotWidth = NSNumber(value: 260)
        webView.takeSnapshot(with: config) { [weak self] image, error in
            guard error == nil, image != nil else { return }
            DispatchQueue.main.async {
                self?.store?.updateThumbnail(tabID: tabID, image: image)
            }
        }
    }

    func collectPageState(tabID: UUID) async throws -> String {
        try await evaluateJSON(tabID: tabID, script: "window.__liquidAgent && window.__liquidAgent.collectState ? window.__liquidAgent.collectState() : JSON.stringify({title:document.title,url:location.href,text:document.body ? document.body.innerText.slice(0,12000) : '', elements:[]});")
    }

    func describeActionTarget(tabID: UUID, action: AgentAction) async throws -> String {
        let data = try JSONEncoder().encode(action)
        let json = String(data: data, encoding: .utf8) ?? "{}"
        let script = "window.__liquidAgent && window.__liquidAgent.describeActionTarget ? window.__liquidAgent.describeActionTarget(\(json)) : JSON.stringify({ok:false,message:'Agent bridge not ready'});"
        return try await evaluateJSON(tabID: tabID, script: script)
    }

    func performAction(tabID: UUID, action: AgentAction) async throws -> String {
        let data = try JSONEncoder().encode(action)
        let json = String(data: data, encoding: .utf8) ?? "{}"
        let script = "window.__liquidAgent && window.__liquidAgent.performAction ? window.__liquidAgent.performAction(\(json)) : JSON.stringify({ok:false,message:'Agent bridge not ready'});"
        return try await evaluateJSON(tabID: tabID, script: script)
    }

    func screenshotJPEGData(tabID: UUID, maxWidth: CGFloat = 1440) async throws -> Data {
        try await withCheckedThrowingContinuation { continuation in
            DispatchQueue.main.async {
                guard let webView = self.webViews[tabID] else {
                    continuation.resume(throwing: NSError(domain: "LiquidAIBrowser", code: 404, userInfo: [NSLocalizedDescriptionKey: "找不到页面 WebView"]))
                    return
                }
                let config = WKSnapshotConfiguration()
                let bounds = webView.bounds.isEmpty ? CGRect(x: 0, y: 0, width: 390, height: 844) : webView.bounds
                config.rect = bounds
                config.snapshotWidth = NSNumber(value: Double(maxWidth))
                webView.takeSnapshot(with: config) { image, error in
                    if let error = error {
                        continuation.resume(throwing: error)
                        return
                    }
                    guard let image, let data = image.jpegData(compressionQuality: 0.90) else {
                        continuation.resume(throwing: NSError(domain: "LiquidAIBrowser", code: 500, userInfo: [NSLocalizedDescriptionKey: "截图失败"]))
                        return
                    }
                    continuation.resume(returning: data)
                }
            }
        }
    }

    private func evaluateJSON(tabID: UUID, script: String) async throws -> String {
        try await withCheckedThrowingContinuation { continuation in
            DispatchQueue.main.async {
                guard let webView = self.webViews[tabID] else {
                    continuation.resume(throwing: NSError(domain: "LiquidAIBrowser", code: 404, userInfo: [NSLocalizedDescriptionKey: "找不到页面 WebView"]))
                    return
                }
                webView.evaluateJavaScript(script) { result, error in
                    if let error = error {
                        continuation.resume(throwing: error)
                        return
                    }
                    if let string = result as? String {
                        continuation.resume(returning: string)
                    } else if let result = result {
                        continuation.resume(returning: "\(result)")
                    } else {
                        continuation.resume(returning: "{}")
                    }
                }
            }
        }
    }
}

extension WebViewPool {
    static let agentBridgeScript = #"""
(function() {
  if (window.__liquidAgent) return;
  function norm(s) { return (s || '').replace(/\s+/g, ' ').trim(); }
  function sanitizeAgentURL(raw) {
    let value = norm(raw || 'about:blank');
    if (!value) return 'about:blank';
    if (/^(douyin|snssdk|aweme|itms-apps|itms-services):\/\//i.test(value)) {
      const m = value.match(/(?:keyword|query|q|search|word)=([^&]+)/i);
      const keyword = m ? decodeURIComponent(m[1]).replace(/\+/g, ' ') : '';
      return keyword ? 'https://www.douyin.com/search/' + encodeURIComponent(keyword) : 'https://www.douyin.com/';
    }
    if (/抖音/.test(value) && /(搜索|搜|查找)/.test(value)) {
      const keyword = value.replace(/.*?(搜索|搜|查找)/, '').replace(/抖音/g, '').trim();
      return keyword ? 'https://www.douyin.com/search/' + encodeURIComponent(keyword) : 'https://www.douyin.com/';
    }
    if (!/^https?:\/\//i.test(value) && !value.startsWith('/') && value.includes('.')) return 'https://' + value;
    return value;
  }
  const cssEscape = (window.CSS && CSS.escape) ? CSS.escape.bind(CSS) : function(value) {
    return String(value).replace(/[^a-zA-Z0-9_-]/g, function(ch) { return '\\' + ch.codePointAt(0).toString(16) + ' '; });
  };
  const interactiveSelector = 'a,button,input,textarea,select,[role="button"],[role="link"],[contenteditable],summary,label,[onclick],[tabindex]';
  function isSensitiveInput(el) {
    const joined = norm([
      el.getAttribute('type'), el.getAttribute('name'), el.getAttribute('id'), el.getAttribute('autocomplete'),
      el.getAttribute('placeholder'), el.getAttribute('aria-label'), el.getAttribute('title')
    ].filter(Boolean).join(' ')).toLowerCase();
    return /(password|passcode|token|secret|api.?key|credit|card|cc-|cvc|cvv|otp|2fa|verification|验证码|密码|银行卡|信用卡|动态码)/i.test(joined);
  }
  function safeValue(el) {
    if (!('value' in el)) return '';
    if (isSensitiveInput(el)) return '[REDACTED]';
    return String(el.value || '').slice(0, 120);
  }
  function cssPath(el) {
    if (!el || el.nodeType !== 1) return '';
    if (el.id) return '#' + cssEscape(el.id);
    const parts = [];
    let node = el;
    while (node && node.nodeType === 1 && parts.length < 5) {
      let part = node.nodeName.toLowerCase();
      if (node.className && typeof node.className === 'string') {
        const cls = node.className.split(/\s+/).filter(Boolean).slice(0, 2).map(c => '.' + cssEscape(c)).join('');
        part += cls;
      }
      const parent = node.parentElement;
      if (parent) {
        const siblings = Array.from(parent.children).filter(x => x.nodeName === node.nodeName);
        if (siblings.length > 1) part += ':nth-of-type(' + (siblings.indexOf(node) + 1) + ')';
      }
      parts.unshift(part);
      node = parent;
    }
    return parts.join(' > ');
  }
  function labelText(el) {
    if (!el) return '';
    if (el.id) {
      const label = document.querySelector('label[for="' + cssEscape(el.id) + '"]');
      if (label) return norm(label.innerText || label.textContent || '');
    }
    const wrap = el.closest('label');
    return wrap ? norm(wrap.innerText || wrap.textContent || '') : '';
  }
  function elementSearchText(el) {
    return norm([
      el.innerText, el.textContent, el.value, el.getAttribute('aria-label'), el.getAttribute('placeholder'),
      el.getAttribute('name'), el.getAttribute('title'), el.getAttribute('href'), el.getAttribute('id'),
      typeof el.className === 'string' ? el.className : '', labelText(el)
    ].filter(Boolean).join(' '));
  }
  function visible(el) {
    const rect = el.getBoundingClientRect();
    const style = window.getComputedStyle(el);
    return rect.width > 0 && rect.height > 0 && style.visibility !== 'hidden' && style.display !== 'none' && style.opacity !== '0';
  }
  function describeElement(el, index) {
    const rect = el.getBoundingClientRect();
    const style = window.getComputedStyle(el);
    const form = el.form || el.closest('form');
    const centerX = Math.round(rect.left + rect.width / 2);
    const centerY = Math.round(rect.top + rect.height / 2);
    return {
      index,
      tag: el.tagName.toLowerCase(),
      type: el.getAttribute('type') || '',
      role: el.getAttribute('role') || '',
      text: norm(el.innerText || el.textContent || el.getAttribute('aria-label') || el.getAttribute('title') || labelText(el) || '').slice(0, 180),
      placeholder: el.getAttribute('placeholder') || '',
      name: el.getAttribute('name') || '',
      value: safeValue(el),
      href: el.href || el.getAttribute('href') || '',
      title: el.getAttribute('title') || '',
      id: el.getAttribute('id') || '',
      label: labelText(el).slice(0, 180),
      formAction: form ? (form.action || form.getAttribute('action') || '') : '',
      selector: cssPath(el),
      visible: visible(el),
      rect: {
        x: Math.round(rect.x), y: Math.round(rect.y), width: Math.round(rect.width), height: Math.round(rect.height),
        centerX, centerY, pageX: Math.round(rect.x + scrollX), pageY: Math.round(rect.y + scrollY)
      },
      style: { cursor: style.cursor, pointerEvents: style.pointerEvents }
    };
  }
  function interactiveElements() {
    return Array.from(document.querySelectorAll(interactiveSelector))
      .filter(visible)
      .slice(0, 280)
      .map(describeElement);
  }
  function findElement(action) {
    if (!action) return null;
    if (action.selector) {
      try { const direct = document.querySelector(action.selector); if (direct) return direct; } catch(e) {}
    }
    if (typeof action.x === 'number' && typeof action.y === 'number') {
      const byPoint = document.elementFromPoint(action.x, action.y);
      if (byPoint) return byPoint.closest(interactiveSelector) || byPoint;
    }
    const candidates = Array.from(document.querySelectorAll(interactiveSelector)).filter(visible);
    const target = norm(action.text || action.value || '').toLowerCase();
    if (target) {
      let best = candidates.find(el => elementSearchText(el).toLowerCase() === target);
      if (best) return best;
      best = candidates.find(el => elementSearchText(el).toLowerCase().includes(target));
      if (best) return best;
    }
    if (typeof action.stepIndex === 'number' && candidates[action.stepIndex]) return candidates[action.stepIndex];
    return null;
  }
  function nativeSetValue(el, value) {
    if (!el) return;
    const text = String(value || '');
    if (el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement) {
      const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      const descriptor = Object.getOwnPropertyDescriptor(proto, 'value');
      const setter = descriptor && descriptor.set;
      if (setter) setter.call(el, text); else el.value = text;
    } else if ('value' in el) {
      el.value = text;
    } else {
      el.textContent = text;
    }
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }
  function firePointer(el, name, x, y) {
    const init = { bubbles: true, cancelable: true, clientX: x, clientY: y, screenX: x, screenY: y };
    if (typeof PointerEvent !== 'undefined') {
      el.dispatchEvent(new PointerEvent(name, Object.assign({ pointerId: 1, pointerType: 'touch', isPrimary: true, buttons: name === 'pointerup' ? 0 : 1 }, init)));
    }
  }
  function fireMouse(el, name, x, y, detail) {
    el.dispatchEvent(new MouseEvent(name, { bubbles: true, cancelable: true, clientX: x, clientY: y, screenX: x, screenY: y, detail: detail || 1 }));
  }
  function clickAt(x, y, detail) {
    const el = document.elementFromPoint(x, y) || document.body;
    const target = el.closest ? (el.closest(interactiveSelector) || el) : el;
    try {
      firePointer(target, 'pointerdown', x, y);
      fireMouse(target, 'mousedown', x, y, detail || 1);
      firePointer(target, 'pointerup', x, y);
      fireMouse(target, 'mouseup', x, y, detail || 1);
      fireMouse(target, 'click', x, y, detail || 1);
      target.focus && target.focus();
    } catch (_) {
      target.click && target.click();
    }
    return { target, x: Math.round(x), y: Math.round(y) };
  }
  function realClick(el) {
    el.scrollIntoView({ block: 'center', inline: 'center', behavior: 'smooth' });
    const rect = el.getBoundingClientRect();
    const x = rect.left + rect.width / 2;
    const y = rect.top + rect.height / 2;
    return clickAt(x, y, 1);
  }
  function doubleClickAt(x, y) {
    const first = clickAt(x, y, 1);
    clickAt(x, y, 2);
    const target = first.target || document.elementFromPoint(x, y) || document.body;
    fireMouse(target, 'dblclick', x, y, 2);
    return first;
  }
  function swipeOrDrag(action, shouldScroll) {
    const sx = Number(action.startX ?? action.x ?? Math.round(innerWidth / 2));
    const sy = Number(action.startY ?? action.y ?? Math.round(innerHeight / 2));
    const ex = Number(action.endX ?? sx);
    const ey = Number(action.endY ?? (String(action.direction || 'down').toLowerCase() === 'up' ? sy + 420 : sy - 420));
    const startEl = document.elementFromPoint(sx, sy) || document.body;
    const target = startEl.closest ? (startEl.closest(interactiveSelector) || startEl) : startEl;
    firePointer(target, 'pointerdown', sx, sy);
    fireMouse(target, 'mousedown', sx, sy, 1);
    const steps = 6;
    for (let i = 1; i <= steps; i++) {
      const x = sx + (ex - sx) * i / steps;
      const y = sy + (ey - sy) * i / steps;
      firePointer(target, 'pointermove', x, y);
      fireMouse(target, 'mousemove', x, y, 1);
    }
    firePointer(target, 'pointerup', ex, ey);
    fireMouse(target, 'mouseup', ex, ey, 1);
    if (shouldScroll) window.scrollBy({ top: sy - ey, left: sx - ex, behavior: 'smooth' });
    return { target, x: Math.round(sx), y: Math.round(sy), endX: Math.round(ex), endY: Math.round(ey) };
  }

  function keyCodeFor(key) {
    const k = String(key || '').toLowerCase();
    const map = { enter: 'Enter', return: 'Enter', tab: 'Tab', escape: 'Escape', esc: 'Escape', backspace: 'Backspace', delete: 'Delete', space: ' ', arrowup: 'ArrowUp', arrowdown: 'ArrowDown', arrowleft: 'ArrowLeft', arrowright: 'ArrowRight' };
    return map[k] || key || '';
  }
  function keyboardTarget(action) {
    return findElement(action) || document.activeElement || document.body;
  }
  function dispatchKeyboard(el, key, modifiers) {
    const code = keyCodeFor(key);
    const mods = (modifiers || []).map(x => String(x).toLowerCase());
    const init = {
      bubbles: true,
      cancelable: true,
      key: code,
      code: code.length === 1 ? 'Key' + code.toUpperCase() : code,
      metaKey: mods.includes('cmd') || mods.includes('command') || mods.includes('meta'),
      ctrlKey: mods.includes('ctrl') || mods.includes('control'),
      altKey: mods.includes('alt') || mods.includes('option'),
      shiftKey: mods.includes('shift')
    };
    el.focus && el.focus();
    el.dispatchEvent(new KeyboardEvent('keydown', init));
    el.dispatchEvent(new KeyboardEvent('keypress', init));
    if (code === 'Enter') {
      const form = el.form || (el.closest && el.closest('form'));
      if (form && !init.shiftKey) { try { form.requestSubmit ? form.requestSubmit() : form.submit(); } catch (_) {} }
    }
    if (code === 'Tab') {
      const focusables = Array.from(document.querySelectorAll('a,button,input,textarea,select,[contenteditable],[tabindex]')).filter(visible);
      const idx = focusables.indexOf(el);
      const next = focusables[(idx + (init.shiftKey ? -1 : 1) + focusables.length) % focusables.length];
      next && next.focus && next.focus();
    }
    el.dispatchEvent(new KeyboardEvent('keyup', init));
    return { target: el, key: code };
  }
  function insertTextLikeKeyboard(el, text) {
    const value = String(text || '');
    el.focus && el.focus();
    if (el.isContentEditable) {
      for (const ch of value) {
        dispatchKeyboard(el, ch, []);
        el.textContent = (el.textContent || '') + ch;
        try { el.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: ch })); }
        catch (_) { el.dispatchEvent(new Event('input', { bubbles: true })); }
      }
    } else if (el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement || 'value' in el) {
      let current = String(el.value || '');
      for (const ch of value) {
        dispatchKeyboard(el, ch, []);
        current += ch;
        nativeSetValue(el, current);
      }
    } else {
      for (const ch of value) dispatchKeyboard(el, ch, []);
    }
    return { target: el };
  }

  function describeTarget(action) {
    let el = findElement(action);
    if (!el && typeof action.x === 'number' && typeof action.y === 'number') el = document.elementFromPoint(action.x, action.y);
    if (!el) return { ok: false, message: '没有找到目标元素', action };
    const info = describeElement(el, -1);
    const around = norm((el.closest('section,article,form,main,div') || el).innerText || '').slice(0, 500);
    info.nearbyText = around;
    return { ok: true, target: info, action };
  }
  function coordinateString(action) {
    if (typeof action.x === 'number' && typeof action.y === 'number') return '(' + Math.round(action.x) + ',' + Math.round(action.y) + ')';
    if (typeof action.startX === 'number' && typeof action.startY === 'number') return '(' + Math.round(action.startX) + ',' + Math.round(action.startY) + ')→(' + Math.round(action.endX || 0) + ',' + Math.round(action.endY || 0) + ')';
    return '';
  }
  window.__liquidAgent = {
    collectState: function() {
      const text = document.body ? norm(document.body.innerText).slice(0, 18000) : '';
      const selection = norm(String(window.getSelection ? window.getSelection() : '')).slice(0, 2000);
      return JSON.stringify({
        title: document.title,
        url: location.href,
        lang: document.documentElement.lang || '',
        description: (document.querySelector('meta[name="description"]') || {}).content || '',
        viewport: { width: innerWidth, height: innerHeight, scrollX: Math.round(scrollX), scrollY: Math.round(scrollY), fullHeight: Math.round(document.documentElement.scrollHeight || document.body.scrollHeight || 0) },
        coordinateSystem: 'viewport/client coordinates. Use rect.centerX/centerY for coordinateClick/doubleClick/swipe/drag.',
        selection,
        text,
        headings: Array.from(document.querySelectorAll('h1,h2,h3')).slice(0, 60).map(h => norm(h.innerText || h.textContent || '')).filter(Boolean),
        elements: interactiveElements()
      });
    },
    describeActionTarget: function(action) {
      try { return JSON.stringify(describeTarget(action)); }
      catch (e) { return JSON.stringify({ ok: false, message: String(e && e.message ? e.message : e) }); }
    },
    performAction: function(action) {
      try {
        const type = String(action.type || '').toLowerCase();
        if (type === 'navigate') {
          return JSON.stringify({ ok: false, category: 'native_navigation_required', message: 'navigate 必须由 App 原生 WKWebView.load 执行，避免触发外部 App scheme。' });
        }
        if (type === 'back') { history.back(); return JSON.stringify({ ok: true, category: 'back', message: '已返回上一页' }); }
        if (type === 'wait') { return JSON.stringify({ ok: true, category: 'wait', message: '已等待' }); }
        if (type === 'scroll') {
          const amount = action.amount || Math.round(innerHeight * 0.78);
          const direction = String(action.direction || 'down').toLowerCase();
          window.scrollBy({ top: direction === 'up' ? -amount : amount, behavior: 'smooth' });
          return JSON.stringify({ ok: true, category: 'scroll', message: '已滚动 ' + direction });
        }
        if (type === 'coordinateclick' || type === 'tap') {
          if (typeof action.x !== 'number' || typeof action.y !== 'number') return JSON.stringify({ ok: false, category: 'missing_coordinates', message: 'coordinateClick 缺少 x/y' });
          const hit = clickAt(action.x, action.y, 1);
          return JSON.stringify({ ok: true, category: 'coordinate_click', message: '已在坐标点击 ' + coordinateString(action), x: hit.x, y: hit.y, targetText: norm(elementSearchText(hit.target)).slice(0, 120) });
        }
        if (type === 'doubleclick') {
          const x = Number(action.x ?? Math.round(innerWidth / 2));
          const y = Number(action.y ?? Math.round(innerHeight / 2));
          const hit = doubleClickAt(x, y);
          return JSON.stringify({ ok: true, category: 'double_click', message: '已双击 ' + coordinateString({x:x,y:y}), x: Math.round(x), y: Math.round(y), targetText: norm(elementSearchText(hit.target)).slice(0, 120) });
        }
        if (type === 'swipe') {
          const hit = swipeOrDrag(action, true);
          return JSON.stringify({ ok: true, category: 'swipe', message: '已滑动/滚动', x: hit.x, y: hit.y, targetText: norm(elementSearchText(hit.target)).slice(0, 120) });
        }
        if (type === 'drag') {
          const hit = swipeOrDrag(action, false);
          return JSON.stringify({ ok: true, category: 'drag', message: '已拖动', x: hit.x, y: hit.y, targetText: norm(elementSearchText(hit.target)).slice(0, 120) });
        }
        if (type === 'keypress' || type === 'pressenter' || type === 'presstab' || type === 'keyboardshortcut') {
          const key = type === 'pressenter' ? 'Enter' : (type === 'presstab' ? 'Tab' : (action.key || action.value || action.text || 'Enter'));
          const target = keyboardTarget(action);
          const hit = dispatchKeyboard(target, key, action.modifiers || []);
          const info = describeElement(hit.target, -1);
          return JSON.stringify({ ok: true, category: 'keyboard', message: '已发送键盘按键：' + keyCodeFor(key), x: info.rect.centerX, y: info.rect.centerY, targetText: norm(elementSearchText(hit.target)).slice(0, 120) });
        }
        if (type === 'typetext') {
          const target = keyboardTarget(action);
          const hit = insertTextLikeKeyboard(target, action.value || action.text || '');
          const info = describeElement(hit.target, -1);
          return JSON.stringify({ ok: true, category: 'type_text', message: '已模拟键盘输入文本', x: info.rect.centerX, y: info.rect.centerY, targetText: norm(elementSearchText(hit.target)).slice(0, 120) });
        }
        if (type === 'settext' || type === 'modifypage') {
          const el = findElement(action) || document.body;
          const text = action.value || action.text || '';
          if (!el) return JSON.stringify({ ok: false, category: 'target_not_found', message: '没有找到可修改区域' });
          if (el === document.body && action.selector) return JSON.stringify({ ok: false, category: 'target_not_found', message: '没有找到 selector 对应元素' });
          el.textContent = text;
          el.dispatchEvent(new Event('input', { bubbles: true }));
          el.dispatchEvent(new Event('change', { bubbles: true }));
          const info = describeElement(el, -1);
          return JSON.stringify({ ok: true, category: 'set_text', message: '已修改网页文本', x: info.rect.centerX, y: info.rect.centerY, targetText: norm(elementSearchText(el)).slice(0, 120) });
        }
        if (type === 'sethtml') {
          const el = findElement(action);
          if (!el) return JSON.stringify({ ok: false, category: 'target_not_found', message: '没有找到可修改元素' });
          el.innerHTML = action.value || action.text || '';
          const info = describeElement(el, -1);
          return JSON.stringify({ ok: true, category: 'set_html', message: '已修改网页 HTML', x: info.rect.centerX, y: info.rect.centerY, targetText: norm(elementSearchText(el)).slice(0, 120) });
        }
        if (type === 'setstyle') {
          const el = findElement(action);
          if (!el) return JSON.stringify({ ok: false, category: 'target_not_found', message: '没有找到可修改元素' });
          el.style.cssText += ';' + (action.value || action.text || '');
          const info = describeElement(el, -1);
          return JSON.stringify({ ok: true, category: 'set_style', message: '已修改网页样式', x: info.rect.centerX, y: info.rect.centerY, targetText: norm(elementSearchText(el)).slice(0, 120) });
        }
        const el = findElement(action);
        if (!el) return JSON.stringify({ ok: false, category: 'target_not_found', message: '没有找到目标元素', action });
        if (type === 'click') {
          const hit = realClick(el);
          return JSON.stringify({ ok: true, category: 'click', message: '已点击：' + norm(elementSearchText(el) || el.tagName).slice(0, 100), x: hit.x, y: hit.y, targetText: norm(elementSearchText(el)).slice(0, 120) });
        }
        if (type === 'input') {
          el.focus();
          if (el.isContentEditable) {
            el.textContent = action.value || '';
            try {
              el.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: action.value || '' }));
            } catch (_) {
              el.dispatchEvent(new Event('input', { bubbles: true }));
            }
          } else {
            nativeSetValue(el, action.value || '');
          }
          const info = describeElement(el, -1);
          return JSON.stringify({ ok: true, category: 'input', message: '已输入内容', x: info.rect.centerX, y: info.rect.centerY, targetText: norm(elementSearchText(el)).slice(0, 120) });
        }
        if (type === 'select') {
          if (!(el instanceof HTMLSelectElement)) return JSON.stringify({ ok: false, category: 'wrong_target', message: '目标不是 select 元素' });
          const value = String(action.value || action.text || '').trim();
          let option = Array.from(el.options).find(o => String(o.value).trim() === value);
          if (!option) option = Array.from(el.options).find(o => norm(o.textContent || '').toLowerCase() === value.toLowerCase());
          if (!option) option = Array.from(el.options).find(o => norm(o.textContent || '').toLowerCase().includes(value.toLowerCase()));
          if (!option) return JSON.stringify({ ok: false, category: 'option_not_found', message: '没有找到匹配选项：' + value });
          el.value = option.value;
          el.dispatchEvent(new Event('input', { bubbles: true }));
          el.dispatchEvent(new Event('change', { bubbles: true }));
          const info = describeElement(el, -1);
          return JSON.stringify({ ok: true, category: 'select', message: '已选择选项：' + norm(option.textContent || option.value), x: info.rect.centerX, y: info.rect.centerY, targetText: norm(option.textContent || option.value) });
        }
        if (type === 'submit') {
          const form = el.form || el.closest('form');
          const info = describeElement(el, -1);
          if (form) { form.requestSubmit ? form.requestSubmit() : form.submit(); return JSON.stringify({ ok: true, category: 'submit', message: '已提交表单', x: info.rect.centerX, y: info.rect.centerY, targetText: norm(elementSearchText(el)).slice(0, 120) }); }
          const hit = realClick(el);
          return JSON.stringify({ ok: true, category: 'submit_click', message: '没有表单，已点击目标', x: hit.x, y: hit.y, targetText: norm(elementSearchText(el)).slice(0, 120) });
        }
        return JSON.stringify({ ok: false, category: 'unknown_action', message: '未知动作：' + type });
      } catch (e) {
        return JSON.stringify({ ok: false, category: 'exception', message: String(e && e.message ? e.message : e) });
      }
    }
  };
})();
"""#
}
