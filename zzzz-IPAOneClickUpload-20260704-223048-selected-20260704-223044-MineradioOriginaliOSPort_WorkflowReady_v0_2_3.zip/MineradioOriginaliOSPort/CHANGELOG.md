# Changelog

## 0.2.3 - Swift raw string compile fix
- Fixed `ContentView.swift` raw string terminator for the injected Mineradio iOS bridge script.
- Keeps the original Mineradio Web/WKWebView direction unchanged.

## 0.2.2

- 修复 GitHub Actions / Xcode 26.6 编译失败：`WKOpenPanelParameters` 在 iOS 18.4+ 才公开可用。
- 给 WebKit 文件选择代理加 `@available(iOS 18.4, *)`，保持 iOS 17 deployment target 可编译。
- 不改变原版 Mineradio Web 前端移植方向；视觉层仍走原 `public/index.html`。

## 0.2.0

- 彻底停止 SwiftUI 仿版方向。
- 改为 WKWebView 原版前端移植：构建时下载并打包 `XxHuberrr/Mineradio/public`。
- 加入 Electron `window.desktopWindow` 兼容桥，让原版桌面 shell / fullscreen 相关逻辑能走。
- 保留原版 `three.js / gsap / music-tempo / index.html` 视觉链路。
- 加入 iOS 文件选择桥，兼容原版 `<input type="file">` 导入音乐 / 封面。
- `/api/...` 请求桥接到可配置 API Base，默认 `http://127.0.0.1:3000`。

## 0.1.4

- 旧 SwiftUI 仿版，已废弃。
