import SwiftUI
import WebKit
import UIKit
import UniformTypeIdentifiers

struct MineradioWebShellView: UIViewRepresentable {
    func makeCoordinator() -> Coordinator {
        Coordinator()
    }

    func makeUIView(context: Context) -> WKWebView {
        let configuration = WKWebViewConfiguration()
        configuration.allowsInlineMediaPlayback = true
        configuration.mediaTypesRequiringUserActionForPlayback = []
        configuration.preferences.javaScriptCanOpenWindowsAutomatically = true
        if #available(iOS 14.0, *) {
            configuration.defaultWebpagePreferences.allowsContentJavaScript = true
        }

        let contentController = WKUserContentController()
        contentController.addUserScript(WKUserScript(source: Self.bridgeScript, injectionTime: .atDocumentStart, forMainFrameOnly: false))
        contentController.add(context.coordinator, name: "mineradioIOS")
        configuration.userContentController = contentController

        let webView = WKWebView(frame: .zero, configuration: configuration)
        context.coordinator.webView = webView
        webView.navigationDelegate = context.coordinator
        webView.uiDelegate = context.coordinator
        webView.isOpaque = false
        webView.backgroundColor = .black
        webView.scrollView.backgroundColor = .black
        webView.scrollView.bounces = false
        webView.scrollView.isScrollEnabled = false
        webView.scrollView.contentInsetAdjustmentBehavior = .never
        webView.allowsBackForwardNavigationGestures = false
        webView.customUserAgent = "Mozilla/5.0 (iPad; CPU OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) MineradioElectronCompat/1.0 Mobile/15E148 Safari/604.1"

        loadOriginalMineradio(in: webView)
        return webView
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {}

    private func loadOriginalMineradio(in webView: WKWebView) {
        guard let resourceURL = Bundle.main.resourceURL else {
            webView.loadHTMLString(Self.failureHTML("Bundle resourceURL 不可用"), baseURL: nil)
            return
        }
        let webRoot = resourceURL.appendingPathComponent("MineradioWeb", isDirectory: true)
        let indexURL = webRoot.appendingPathComponent("index.html")
        if FileManager.default.fileExists(atPath: indexURL.path) {
            webView.loadFileURL(indexURL, allowingReadAccessTo: webRoot)
        } else {
            webView.loadHTMLString(Self.failureHTML("未找到原版 Mineradio public/index.html。请确认 GitHub Actions 构建阶段已联网下载原仓库 public 目录。"), baseURL: nil)
        }
    }

    private static func failureHTML(_ message: String) -> String {
        """
        <!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'><style>
        html,body{margin:0;height:100%;background:#000;color:#fff;font-family:-apple-system,BlinkMacSystemFont,'PingFang SC',sans-serif;overflow:hidden}
        body{display:grid;place-items:center}.box{max-width:720px;padding:34px;border:1px solid rgba(255,255,255,.14);border-radius:22px;background:rgba(255,255,255,.055);box-shadow:0 28px 90px rgba(0,0,0,.6)}
        h1{font-size:26px;margin:0 0 14px}p{line-height:1.6;color:rgba(255,255,255,.72)}code{color:#ffd98a}
        </style></head><body><div class='box'><h1>Mineradio 原版前端未加载</h1><p>\(message)</p><p>这个包的目标是加载原版 <code>XxHuberrr/Mineradio/public</code>，不是 SwiftUI 仿版。</p></div></body></html>
        """
    }

    private static let bridgeScript = #"""
    (function(){
      if (window.__mineradioIOSBridgeInstalled) return;
      window.__mineradioIOSBridgeInstalled = true;

      function post(name, payload) {
        try { window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.mineradioIOS && window.webkit.messageHandlers.mineradioIOS.postMessage({ name: name, payload: payload || {} }); } catch (e) {}
      }
      function resolved(value) { return Promise.resolve(value || { ok: true }); }

      // Electron desktopWindow compatibility layer.
      // Keep visual behavior close to desktop by exposing isDesktop=true,
      // but leave unsupported login methods absent so the original fallback paths still run.
      window.desktopWindow = window.desktopWindow || {
        isDesktop: true,
        getState: function(){ return resolved({ isVisible: true, isFocused: true, isFullScreen: true, isWindowFullScreen: true, isHtmlFullScreen: true, isNativeFullScreen: false, isMinimized: false }); },
        onStateChange: function(cb){
          try { if (typeof cb === 'function') setTimeout(function(){ cb({ isVisible: true, isFocused: true, isFullScreen: true, isWindowFullScreen: true, isHtmlFullScreen: true, isNativeFullScreen: false, isMinimized: false }); }, 0); } catch (e) {}
        },
        minimizeWindow: function(){ return resolved({ ok: true }); },
        maximizeWindow: function(){ return resolved({ ok: true }); },
        closeWindow: function(){ post('closeWindow'); return resolved({ ok: true }); },
        toggleFullscreen: function(){ post('toggleFullscreen'); return resolved({ ok: true }); },
        restartApp: function(){ post('restartApp'); return resolved({ ok: false, error: 'iOS does not restart apps programmatically' }); },
        openUpdateInstaller: function(){ return resolved({ ok: false, error: 'iOS build does not use Windows update installers' }); },
        setIgnoreMouseEvents: function(){ return resolved({ ok: true }); },
        clearQQMusicLogin: function(){ return resolved({ ok: true }); }
      };

      // Route original relative /api calls to a user-provided music API host when one is configured.
      // In Safari/WebKit console/localStorage you can set:
      // localStorage.setItem('mineradio-ios-api-base', 'http://YOUR-LAN-IP:3000')
      var nativeFetch = window.fetch ? window.fetch.bind(window) : null;
      if (nativeFetch && !window.__mineradioFetchWrapped) {
        window.__mineradioFetchWrapped = true;
        window.fetch = function(input, init) {
          try {
            var raw = (typeof input === 'string') ? input : (input && input.url ? input.url : '');
            if (raw && raw.indexOf('/api/') === 0) {
              var base = localStorage.getItem('mineradio-ios-api-base') || localStorage.getItem('mineradio-api-base') || 'http://127.0.0.1:3000';
              input = base.replace(/\/$/, '') + raw;
            }
          } catch (e) {}
          return nativeFetch(input, init);
        };
      }

      window.addEventListener('error', function(e){ post('jsError', { message: e.message || '', source: e.filename || '', line: e.lineno || 0 }); });
      window.addEventListener('unhandledrejection', function(e){ post('promiseError', { message: String((e.reason && (e.reason.message || e.reason)) || '') }); });
    })();
    """#

    final class Coordinator: NSObject, WKNavigationDelegate, WKUIDelegate, WKScriptMessageHandler, UIDocumentPickerDelegate {
        weak var webView: WKWebView?
        private var openPanelCompletion: (([URL]?) -> Void)?

        func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
            #if DEBUG
            print("Mineradio iOS bridge:", message.body)
            #endif
        }

        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            webView.evaluateJavaScript("document.body && document.body.classList.add('ios-wkwebview-shell')", completionHandler: nil)
        }

        @available(iOS 18.4, *)
        func webView(_ webView: WKWebView, runOpenPanelWith parameters: WKOpenPanelParameters, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping ([URL]?) -> Void) {
            openPanelCompletion?(nil)
            openPanelCompletion = completionHandler

            var contentTypes: [UTType] = [.audio, .image, .movie, .data]
            for ext in ["mp3", "flac", "wav", "ogg", "m4a", "aac", "aiff", "opus", "jpg", "jpeg", "png", "webp", "mp4", "webm", "mov"] {
                if let type = UTType(filenameExtension: ext) { contentTypes.append(type) }
            }
            let picker = UIDocumentPickerViewController(forOpeningContentTypes: contentTypes, asCopy: true)
            picker.delegate = self
            picker.allowsMultipleSelection = parameters.allowsMultipleSelection
            picker.modalPresentationStyle = .formSheet
            topViewController()?.present(picker, animated: true)
        }

        func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
            openPanelCompletion?(nil)
            openPanelCompletion = nil
        }

        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            let copied = copyToReadableTemporaryFiles(urls)
            openPanelCompletion?(copied.isEmpty ? urls : copied)
            openPanelCompletion = nil
        }

        private func copyToReadableTemporaryFiles(_ urls: [URL]) -> [URL] {
            let fm = FileManager.default
            let dir = fm.temporaryDirectory.appendingPathComponent("MineradioImports", isDirectory: true)
            try? fm.createDirectory(at: dir, withIntermediateDirectories: true)
            var results: [URL] = []
            for url in urls {
                let scoped = url.startAccessingSecurityScopedResource()
                defer { if scoped { url.stopAccessingSecurityScopedResource() } }
                let safeName = UUID().uuidString + "-" + url.lastPathComponent
                let dest = dir.appendingPathComponent(safeName)
                try? fm.removeItem(at: dest)
                do {
                    try fm.copyItem(at: url, to: dest)
                    results.append(dest)
                } catch {
                    results.append(url)
                }
            }
            return results
        }

        private func topViewController(base: UIViewController? = UIApplication.shared.connectedScenes
            .compactMap { $0 as? UIWindowScene }
            .flatMap { $0.windows }
            .first { $0.isKeyWindow }?.rootViewController) -> UIViewController? {
            if let nav = base as? UINavigationController { return topViewController(base: nav.visibleViewController) }
            if let tab = base as? UITabBarController { return topViewController(base: tab.selectedViewController) }
            if let presented = base?.presentedViewController { return topViewController(base: presented) }
            return base
        }
    }
}
