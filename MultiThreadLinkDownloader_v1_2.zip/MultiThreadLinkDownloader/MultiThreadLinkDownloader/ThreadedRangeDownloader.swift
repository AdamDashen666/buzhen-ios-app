import Foundation

struct DownloadConfig: Sendable {
    let url: URL
    let connections: Int
    let sliceBytes: Int64
    let outputDirectory: URL
}

struct SegmentProgress: Identifiable, Sendable, Equatable {
    let index: Int
    let downloadedBytes: Int64
    let totalBytes: Int64
    let speedBytesPerSecond: Double

    var id: Int { index }

    var progress: Double {
        guard totalBytes > 0 else { return 0 }
        return min(1, max(0, Double(downloadedBytes) / Double(totalBytes)))
    }
}

struct DownloadUpdate: Sendable {
    let phase: String
    let downloadedBytes: Int64
    let totalBytes: Int64
    let currentSpeedBytesPerSecond: Double
    let averageSpeedBytesPerSecond: Double
    let peakSpeedBytesPerSecond: Double
    let elapsedSeconds: TimeInterval
    let estimatedRemainingSeconds: TimeInterval?
    let requestedConnections: Int
    let actualConnections: Int
    let supportsRanges: Bool
    let isMultiThreaded: Bool
    let segments: [SegmentProgress]
}

struct DownloadResult: Sendable {
    let fileURL: URL
    let sourceURL: URL
    let fileName: String
    let fileSize: Int64
    let startedAt: Date
    let endedAt: Date
    let durationSeconds: TimeInterval
    let averageSpeedBytesPerSecond: Double
    let peakSpeedBytesPerSecond: Double
    let requestedConnections: Int
    let actualConnections: Int
    let supportsRanges: Bool
    let usedMultiThreading: Bool
    let segmentCount: Int
}

enum DownloaderError: LocalizedError {
    case invalidHTTPStatus(Int)
    case cannotCreateOutputFile
    case serverDoesNotSupportRange

    var errorDescription: String? {
        switch self {
        case .invalidHTTPStatus(let code):
            return "服务器返回状态码 \(code)"
        case .cannotCreateOutputFile:
            return "无法创建输出文件"
        case .serverDoesNotSupportRange:
            return "服务器不支持 Range 分段下载"
        }
    }
}

actor ProgressTracker {
    private var downloadedBytes: Int64 = 0
    private let totalBytes: Int64
    private let requestedConnections: Int
    private let actualConnections: Int
    private let supportsRanges: Bool
    private let isMultiThreaded: Bool
    private let startTime: Date
    private var lastEmitTime: Date
    private var lastEmitBytes: Int64 = 0
    private var peakSpeedBytesPerSecond: Double = 0
    private var segmentBytes: [Int: Int64] = [:]
    private let segmentTotals: [Int: Int64]

    init(
        totalBytes: Int64,
        requestedConnections: Int,
        actualConnections: Int,
        supportsRanges: Bool,
        isMultiThreaded: Bool,
        segmentTotals: [Int: Int64]
    ) {
        self.totalBytes = max(0, totalBytes)
        self.requestedConnections = requestedConnections
        self.actualConnections = actualConnections
        self.supportsRanges = supportsRanges
        self.isMultiThreaded = isMultiThreaded
        self.segmentTotals = segmentTotals
        self.startTime = Date()
        self.lastEmitTime = self.startTime
        for key in segmentTotals.keys {
            self.segmentBytes[key] = 0
        }
    }

    func add(_ byteCount: Int64, segmentIndex: Int?, phase: String, force: Bool = false) -> DownloadUpdate? {
        let safeBytes = max(0, byteCount)
        downloadedBytes += safeBytes
        if let segmentIndex {
            segmentBytes[segmentIndex, default: 0] += safeBytes
        }

        let now = Date()
        let deltaSeconds = now.timeIntervalSince(lastEmitTime)
        let shouldEmit = force || deltaSeconds >= 0.15 || (totalBytes > 0 && downloadedBytes >= totalBytes)
        guard shouldEmit else { return nil }

        let emittedByteDelta = downloadedBytes - lastEmitBytes
        let currentSpeed = deltaSeconds > 0 ? Double(emittedByteDelta) / deltaSeconds : 0
        peakSpeedBytesPerSecond = max(peakSpeedBytesPerSecond, currentSpeed)
        lastEmitTime = now
        lastEmitBytes = downloadedBytes

        return makeUpdate(phase: phase, now: now, currentSpeed: currentSpeed)
    }

    func snapshot(phase: String) -> DownloadUpdate {
        makeUpdate(phase: phase, now: Date(), currentSpeed: 0)
    }

    func peakSpeed() -> Double {
        peakSpeedBytesPerSecond
    }

    private func makeUpdate(phase: String, now: Date, currentSpeed: Double) -> DownloadUpdate {
        let elapsed = max(now.timeIntervalSince(startTime), 0.001)
        let averageSpeed = Double(downloadedBytes) / elapsed
        let remainingBytes = totalBytes > 0 ? max(0, totalBytes - downloadedBytes) : 0
        let eta = averageSpeed > 1 && totalBytes > 0 ? Double(remainingBytes) / averageSpeed : nil

        let segments = segmentTotals.keys.sorted().map { index in
            let bytes = segmentBytes[index, default: 0]
            let total = segmentTotals[index, default: 0]
            let segmentSpeed = elapsed > 0 ? Double(bytes) / elapsed : 0
            return SegmentProgress(
                index: index,
                downloadedBytes: min(bytes, total > 0 ? total : bytes),
                totalBytes: total,
                speedBytesPerSecond: segmentSpeed
            )
        }

        return DownloadUpdate(
            phase: phase,
            downloadedBytes: downloadedBytes,
            totalBytes: totalBytes,
            currentSpeedBytesPerSecond: currentSpeed,
            averageSpeedBytesPerSecond: averageSpeed,
            peakSpeedBytesPerSecond: peakSpeedBytesPerSecond,
            elapsedSeconds: elapsed,
            estimatedRemainingSeconds: eta,
            requestedConnections: requestedConnections,
            actualConnections: actualConnections,
            supportsRanges: supportsRanges,
            isMultiThreaded: isMultiThreaded,
            segments: segments
        )
    }
}

struct ThreadedRangeDownloader {
    private static let session: URLSession = {
        let configuration = URLSessionConfiguration.default
        configuration.waitsForConnectivity = true
        configuration.timeoutIntervalForRequest = 60
        configuration.timeoutIntervalForResource = 24 * 60 * 60
        configuration.httpMaximumConnectionsPerHost = 128
        configuration.requestCachePolicy = .reloadIgnoringLocalAndRemoteCacheData
        return URLSession(configuration: configuration)
    }()

    static func download(
        config: DownloadConfig,
        onUpdate: @escaping @Sendable (DownloadUpdate) async -> Void
    ) async throws -> DownloadResult {
        try Task.checkCancellation()
        let startedAt = Date()
        let requestedConnections = max(1, min(config.connections, 128))

        try FileManager.default.createDirectory(at: config.outputDirectory, withIntermediateDirectories: true)

        await onUpdate(emptyUpdate(phase: "读取服务器信息", requestedConnections: requestedConnections))

        let info = try await fetchFileInfo(url: config.url)
        let filename = safeFilename(from: config.url, suggested: info.suggestedFilename)
        let finalURL = uniqueURL(in: config.outputDirectory, filename: filename)

        let canUseMultiThreading = info.supportsRanges && info.contentLength > 0 && requestedConnections > 1
        guard canUseMultiThreading else {
            return try await singleConnectionDownload(
                config: config,
                finalURL: finalURL,
                totalBytes: max(0, info.contentLength),
                requestedConnections: requestedConnections,
                supportsRanges: info.supportsRanges,
                startedAt: startedAt,
                onUpdate: onUpdate
            )
        }

        let totalBytes = info.contentLength
        let tempRoot = FileManager.default.temporaryDirectory
            .appendingPathComponent("ThreadedRangeDownload-\(UUID().uuidString)", isDirectory: true)
        try FileManager.default.createDirectory(at: tempRoot, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: tempRoot) }

        let ranges = makeRanges(totalBytes: totalBytes, connections: requestedConnections)
        let segmentTotals = Dictionary(uniqueKeysWithValues: ranges.map { ($0.index, $0.length) })
        let progress = ProgressTracker(
            totalBytes: totalBytes,
            requestedConnections: requestedConnections,
            actualConnections: ranges.count,
            supportsRanges: true,
            isMultiThreaded: true,
            segmentTotals: segmentTotals
        )

        await onUpdate(await progress.snapshot(phase: "并发下载中"))

        try await withThrowingTaskGroup(of: Void.self) { group in
            for range in ranges {
                group.addTask {
                    let partURL = tempRoot.appendingPathComponent("part-\(range.index)")
                    try await downloadPart(
                        url: config.url,
                        range: range,
                        sliceBytes: config.sliceBytes,
                        partURL: partURL,
                        progress: progress,
                        onUpdate: onUpdate
                    )
                }
            }
            try await group.waitForAll()
        }

        await onUpdate(await progress.snapshot(phase: "合并文件中"))
        try mergeParts(partCount: ranges.count, tempRoot: tempRoot, destinationURL: finalURL)

        let endedAt = Date()
        let duration = max(endedAt.timeIntervalSince(startedAt), 0.001)
        let averageSpeed = Double(totalBytes) / duration
        let peakSpeed = await progress.peakSpeed()
        await onUpdate(await progress.snapshot(phase: "下载完成"))

        return DownloadResult(
            fileURL: finalURL,
            sourceURL: config.url,
            fileName: finalURL.lastPathComponent,
            fileSize: totalBytes,
            startedAt: startedAt,
            endedAt: endedAt,
            durationSeconds: duration,
            averageSpeedBytesPerSecond: averageSpeed,
            peakSpeedBytesPerSecond: peakSpeed,
            requestedConnections: requestedConnections,
            actualConnections: ranges.count,
            supportsRanges: true,
            usedMultiThreading: true,
            segmentCount: ranges.count
        )
    }

    private static func fetchFileInfo(url: URL) async throws -> (contentLength: Int64, supportsRanges: Bool, suggestedFilename: String?) {
        var request = URLRequest(url: url)
        request.httpMethod = "HEAD"
        request.cachePolicy = .reloadIgnoringLocalAndRemoteCacheData

        do {
            let (_, response) = try await session.data(for: request)
            guard let http = response as? HTTPURLResponse else {
                return (response.expectedContentLength, false, response.suggestedFilename)
            }
            let rangeHeader = http.value(forHTTPHeaderField: "Accept-Ranges")?.lowercased() ?? ""
            let length = response.expectedContentLength
            if (200...299).contains(http.statusCode) {
                if rangeHeader.contains("bytes") {
                    return (length, true, response.suggestedFilename)
                }
                // Some CDNs support Range but do not advertise it in HEAD.
                // Probe once before falling back to single connection.
                if length > 0 {
                    return try await fetchFileInfoWithProbe(url: url)
                }
                return (length, false, response.suggestedFilename)
            }
        } catch {
            // Some servers reject HEAD. Fall back to a tiny Range probe below.
        }

        return try await fetchFileInfoWithProbe(url: url)
    }

    private static func fetchFileInfoWithProbe(url: URL) async throws -> (contentLength: Int64, supportsRanges: Bool, suggestedFilename: String?) {
        var request = URLRequest(url: url)
        request.setValue("bytes=0-0", forHTTPHeaderField: "Range")
        request.cachePolicy = .reloadIgnoringLocalAndRemoteCacheData

        let (_, response) = try await session.data(for: request)
        guard let http = response as? HTTPURLResponse else {
            return (max(0, response.expectedContentLength), false, response.suggestedFilename)
        }

        if http.statusCode == 206,
           let contentRange = http.value(forHTTPHeaderField: "Content-Range"),
           let slash = contentRange.lastIndex(of: "/") {
            let totalText = contentRange[contentRange.index(after: slash)...]
            let total = Int64(totalText) ?? -1
            return (total, total > 0, response.suggestedFilename)
        }

        if (200...299).contains(http.statusCode) {
            return (max(0, response.expectedContentLength), false, response.suggestedFilename)
        }

        throw DownloaderError.invalidHTTPStatus(http.statusCode)
    }

    private static func singleConnectionDownload(
        config: DownloadConfig,
        finalURL: URL,
        totalBytes: Int64,
        requestedConnections: Int,
        supportsRanges: Bool,
        startedAt: Date,
        onUpdate: @escaping @Sendable (DownloadUpdate) async -> Void
    ) async throws -> DownloadResult {
        let progress = ProgressTracker(
            totalBytes: totalBytes,
            requestedConnections: requestedConnections,
            actualConnections: 1,
            supportsRanges: supportsRanges,
            isMultiThreaded: false,
            segmentTotals: [0: totalBytes]
        )

        let phase = supportsRanges ? "单连接下载中" : "服务器不支持分段，普通下载中"
        await onUpdate(await progress.snapshot(phase: phase))

        var request = URLRequest(url: config.url)
        request.cachePolicy = .reloadIgnoringLocalAndRemoteCacheData
        let (bytes, response) = try await session.bytes(for: request)
        if let http = response as? HTTPURLResponse, !(200...299).contains(http.statusCode) {
            throw DownloaderError.invalidHTTPStatus(http.statusCode)
        }

        FileManager.default.createFile(atPath: finalURL.path, contents: nil)
        guard let handle = FileHandle(forWritingAtPath: finalURL.path) else {
            throw DownloaderError.cannotCreateOutputFile
        }
        defer { try? handle.close() }

        var buffer = Data()
        buffer.reserveCapacity(256 * 1024)

        for try await byte in bytes {
            try Task.checkCancellation()
            buffer.append(byte)
            if buffer.count >= 256 * 1024 {
                handle.write(buffer)
                if let update = await progress.add(Int64(buffer.count), segmentIndex: 0, phase: phase) {
                    await onUpdate(update)
                }
                buffer.removeAll(keepingCapacity: true)
            }
        }

        if !buffer.isEmpty {
            handle.write(buffer)
            if let update = await progress.add(Int64(buffer.count), segmentIndex: 0, phase: phase, force: true) {
                await onUpdate(update)
            }
        }

        let size = (try? FileManager.default.attributesOfItem(atPath: finalURL.path)[.size] as? NSNumber)?.int64Value ?? totalBytes
        let endedAt = Date()
        let duration = max(endedAt.timeIntervalSince(startedAt), 0.001)
        let averageSpeed = Double(max(size, 0)) / duration
        let peakSpeed = await progress.peakSpeed()
        await onUpdate(await progress.snapshot(phase: "下载完成"))

        return DownloadResult(
            fileURL: finalURL,
            sourceURL: config.url,
            fileName: finalURL.lastPathComponent,
            fileSize: max(size, totalBytes),
            startedAt: startedAt,
            endedAt: endedAt,
            durationSeconds: duration,
            averageSpeedBytesPerSecond: averageSpeed,
            peakSpeedBytesPerSecond: peakSpeed,
            requestedConnections: requestedConnections,
            actualConnections: 1,
            supportsRanges: supportsRanges,
            usedMultiThreading: false,
            segmentCount: 1
        )
    }

    private static func downloadPart(
        url: URL,
        range: ByteRange,
        sliceBytes: Int64,
        partURL: URL,
        progress: ProgressTracker,
        onUpdate: @escaping @Sendable (DownloadUpdate) async -> Void
    ) async throws {
        FileManager.default.createFile(atPath: partURL.path, contents: nil)
        let handle = try FileHandle(forWritingTo: partURL)
        defer { try? handle.close() }

        var offset = range.start
        while offset <= range.end {
            try Task.checkCancellation()
            let end = min(offset + sliceBytes - 1, range.end)
            var request = URLRequest(url: url)
            request.cachePolicy = .reloadIgnoringLocalAndRemoteCacheData
            request.setValue("bytes=\(offset)-\(end)", forHTTPHeaderField: "Range")

            let (data, response) = try await session.data(for: request)
            if let http = response as? HTTPURLResponse, http.statusCode != 206 {
                throw DownloaderError.invalidHTTPStatus(http.statusCode)
            }

            handle.write(data)
            offset = end + 1

            if let update = await progress.add(Int64(data.count), segmentIndex: range.index, phase: "并发下载中") {
                await onUpdate(update)
            }
        }
    }

    private static func mergeParts(partCount: Int, tempRoot: URL, destinationURL: URL) throws {
        FileManager.default.createFile(atPath: destinationURL.path, contents: nil)
        guard let output = FileHandle(forWritingAtPath: destinationURL.path) else {
            throw DownloaderError.cannotCreateOutputFile
        }
        defer { try? output.close() }

        for index in 0..<partCount {
            let partURL = tempRoot.appendingPathComponent("part-\(index)")
            let input = try FileHandle(forReadingFrom: partURL)
            defer { try? input.close() }

            while true {
                let data = input.readData(ofLength: 4 * 1024 * 1024)
                if data.isEmpty { break }
                output.write(data)
            }
        }
    }

    private static func makeRanges(totalBytes: Int64, connections: Int) -> [ByteRange] {
        let count = max(1, min(connections, Int(totalBytes)))
        let base = totalBytes / Int64(count)
        var ranges: [ByteRange] = []
        var start: Int64 = 0

        for index in 0..<count {
            let isLast = index == count - 1
            let end = isLast ? totalBytes - 1 : start + base - 1
            ranges.append(ByteRange(index: index, start: start, end: end))
            start = end + 1
        }
        return ranges
    }

    private static func safeFilename(from url: URL, suggested: String?) -> String {
        let raw = suggested?.isEmpty == false ? suggested! : (url.lastPathComponent.isEmpty ? "downloaded-file" : url.lastPathComponent)
        let cleaned = raw
            .replacingOccurrences(of: "/", with: "-")
            .replacingOccurrences(of: ":", with: "-")
            .replacingOccurrences(of: "?", with: "-")
            .replacingOccurrences(of: "&", with: "-")
        return cleaned.isEmpty ? "downloaded-file" : cleaned
    }

    private static func uniqueURL(in directory: URL, filename: String) -> URL {
        let base = (filename as NSString).deletingPathExtension
        let ext = (filename as NSString).pathExtension
        var candidate = directory.appendingPathComponent(filename)
        var index = 1

        while FileManager.default.fileExists(atPath: candidate.path) {
            let name = ext.isEmpty ? "\(base)-\(index)" : "\(base)-\(index).\(ext)"
            candidate = directory.appendingPathComponent(name)
            index += 1
        }
        return candidate
    }

    private static func emptyUpdate(phase: String, requestedConnections: Int) -> DownloadUpdate {
        DownloadUpdate(
            phase: phase,
            downloadedBytes: 0,
            totalBytes: 0,
            currentSpeedBytesPerSecond: 0,
            averageSpeedBytesPerSecond: 0,
            peakSpeedBytesPerSecond: 0,
            elapsedSeconds: 0,
            estimatedRemainingSeconds: nil,
            requestedConnections: requestedConnections,
            actualConnections: 0,
            supportsRanges: false,
            isMultiThreaded: false,
            segments: []
        )
    }
}

struct ByteRange: Sendable {
    let index: Int
    let start: Int64
    let end: Int64

    var length: Int64 {
        max(0, end - start + 1)
    }
}
