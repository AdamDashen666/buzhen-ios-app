# MultiThreadLinkDownloader

A SwiftUI iOS/iPadOS app that downloads files from a direct HTTP/HTTPS link with optional multi-threaded HTTP Range downloading.

## Features

- Paste a direct download link.
- Choose 1-128 concurrent connections.
- Automatically detects whether the server supports HTTP Range.
- Uses segmented multi-thread downloading when possible.
- Falls back to single-connection streaming download when Range is unavailable.
- Shows real-time progress, downloaded size, total size, current speed, average speed, peak speed, elapsed time, and ETA.
- Shows per-segment progress for Range downloads.
- Generates a completed download report.
- Saves the report as a `.txt` file next to the downloaded file.
- Shares both the downloaded file and report using the iOS share sheet.

## Notes

- Multi-thread downloading only works when the server supports `Accept-Ranges: bytes` or responds correctly to Range probes.
- Some servers/CDNs limit each connection or block Range requests, so the app may fall back to single connection.
- iOS may still limit background execution if the app is closed or suspended.
- Very high connection counts can increase server rejection risk and may not always improve speed.

## Build

1. Open `MultiThreadLinkDownloader.xcodeproj` in Xcode.
2. Select your Team and change the Bundle Identifier if needed.
3. Build and run on iPhone or iPad.

## Version

Current version: v1.2
