# Changelog

## v1.2 - Higher Thread Limit

- Increased the maximum selectable connection count from 32 to 128.
- Added quick presets for 64 aggressive mode and 128 test mode.
- Raised `URLSessionConfiguration.httpMaximumConnectionsPerHost` to 128.
- Added an in-app warning that 64/128 connections may be throttled by the server or iOS and may increase failure risk.

## v1.1 - Progress, Speed, and Download Report

- Fixed the type mismatch between `DownloadManager` and `ThreadedRangeDownloader` so the project can build correctly.
- Added real-time download progress with percentage and downloaded/total size.
- Added current speed, average speed, peak speed, elapsed time, and estimated remaining time.
- Added connection status display: requested connections, actual connections, Range support, and whether multi-threading is actually used.
- Added per-segment progress list for multi-threaded Range downloads.
- Improved fallback single-connection mode so it still shows live progress and speed while downloading.
- Added a completed download report with source URL, filename, file size, duration, speed, Range support, and segment count.
- Added report preview inside the app.
- Added report export as a `.txt` file next to the downloaded file.
- Updated share action to share both the downloaded file and the report.

## v1.0 - Initial Version

- Input a download URL.
- Choose 1-32 concurrent connections.
- Use HTTP Range requests for segmented parallel downloading when supported.
- Fall back to normal single-connection downloading when Range is not supported.
- Save or share the downloaded file through the iOS share sheet.
