# VERSION_NOTES v6.0

本版重点修复：工作流页面不应有明显边界，连线或模块超出现有边界后不应消失。

## 问题原因
旧逻辑里 Canvas frame 只按持久化节点坐标和有限路线点估算；拖拽中节点、整理后的视觉坐标、线条局部绕线路径一旦超过 frame，就会被 SwiftUI Canvas 裁切。

## 处理
1. 扩大基础画布尺寸到 9600 × 7600。
2. `dynamicCanvasSize` 计算时同时纳入：
   - 持久化节点坐标
   - 当前视觉节点坐标 `visualPosition`
   - 所有连线路由点 `edgeRoutePoints`
   - 当前可见区域
3. 根据缩放和视口追加更大的动态扩展 buffer。
4. 可见区域预渲染范围扩大。
5. 连线路由点进入安全内边距，避免负坐标裁切。
6. 新增/拖拽模块保持输入口不落到 Canvas 左上边界外。

## 检查
- 已确认旧的固定 5200 × 4200 基础尺寸被替换。
- 已确认 `dynamicCanvasSize` 使用 `visualPosition` 和 `edgeRoutePoints`。
- 已确认 ZIP 内含本文件和 CHANGELOG.md。
