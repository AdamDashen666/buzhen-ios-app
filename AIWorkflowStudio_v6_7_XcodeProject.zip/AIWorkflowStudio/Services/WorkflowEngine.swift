import Foundation

enum WorkflowEngineError: Error, LocalizedError {
    case emptyPrompt
    case noStartNode
    case cancelled
    case safetyLimitReached
    case dependencyDeadlock(String)
    case apiTimeout(String)
    case missingModelConfiguration(String)

    var errorDescription: String? {
        switch self {
        case .emptyPrompt: return "开始模块提示词为空。"
        case .noStartNode: return "工作流缺少开始模块。"
        case .cancelled: return "运行已被停止。"
        case .safetyLimitReached: return "返工循环次数过多，已自动停止以避免卡死。可检查检查者的不合格连线。"
        case .dependencyDeadlock(let message): return message
        case .apiTimeout(let message): return message
        case .missingModelConfiguration(let message): return message
        }
    }
}

final class WorkflowEngine {
    private struct ParallelNodeResult {
        var node: WorkflowNode
        var inputContext: String
        var response: AITextResponse?
        var error: Error?
    }

    func run(runID: UUID = UUID(), project: WorkflowProject, apiConfigs: [APIProviderConfig], settings: AppSettings, aiClient: AIClient, onUpdate: @escaping @MainActor (RunRecord) -> Void) async throws -> RunRecord {
        guard !project.userPrompt.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { throw WorkflowEngineError.emptyPrompt }
        guard let start = project.nodes.first(where: { $0.kind == .start }) else { throw WorkflowEngineError.noStartNode }

        var record = RunRecord(projectID: project.id, projectTitle: project.title)
        record.id = runID
        var contextByNode: [UUID: String] = [:]
        // 节点可能被检查者打回重复执行。旧输出不能被下游当成“最新完成结果”使用，
        // 否则会出现：某个检查者还在运行，但日志/汇总/输出等后续模块已经开始。
        // dirtyNodeIDs 表示该节点及其下游输出已过期，必须等重新执行完成后才能作为依赖。
        var dirtyNodeIDs = Set<UUID>()
        var runningNodeIDs = Set<UUID>()
        var queue: [UUID] = [start.id]
        var visitCounts: [UUID: Int] = [:]
        var returnCounts: [UUID: Int] = [:]
        var waitCounts: [UUID: Int] = [:]
        var waitStartDates: [UUID: Date] = [:]
        var executed = 0
        let safetyLimit = max(project.nodes.count * 30, 120)

        func markDirtyCascade(from rootID: UUID) {
            var stack = [rootID]
            var seen = Set<UUID>()
            while let id = stack.popLast() {
                guard seen.insert(id).inserted else { continue }
                dirtyNodeIDs.insert(id)

                // 只沿“前进线”扩散 dirty。失败/低分返工线是回路；如果也跟着扩散，
                // worker 刚准备给 reviewer 新输出，reviewer 的返工线又会把 worker 标成 dirty，
                // 最终造成两个并行代码检查者一直等待/来回跳。
                let forwardDownstream = project.edges
                    .filter { $0.from == id && $0.condition != .failed && $0.condition != .scoreLow }
                    .map(\.to)
                stack.append(contentsOf: forwardDownstream)
            }
        }

        func appendQueue(_ id: UUID, into targetQueue: inout [UUID]) {
            if !targetQueue.contains(id) { targetQueue.append(id) }
        }

        func deduplicated(_ ids: [UUID]) -> [UUID] {
            var seen = Set<UUID>()
            return ids.filter { seen.insert($0).inserted }
        }

        func syncDependencyState(waitingIDs: [UUID] = []) {
            record.currentNodeIDs = Array(runningNodeIDs)
            let waiting = deduplicated(waitingIDs.filter { !runningNodeIDs.contains($0) })
            record.waitingNodeIDs = waiting.isEmpty ? nil : waiting
            // dirty 节点表示“旧输出已失效，必须等上游返工完成后重新执行”。
            // UI 里不再显示成“待返工”紫色状态，而是作为等待上游/预备重跑处理，
            // 防止下游在上游还没完成时看起来像已经开始返工。
            let stale = Array(dirtyNodeIDs.subtracting(runningNodeIDs))
            record.staleNodeIDs = stale.isEmpty ? nil : stale
        }

        appendLog(&record, .info, nil, "开始运行工作流：\(project.title)")
        record.currentNodeIDs = [start.id]
        record.waitingNodeIDs = nil
        record.staleNodeIDs = nil
        record.currentStage = "准备并行调度"
        record.diagnosticMessage = "同一批满足上游条件的模块会并行运行；失败/不合格返工线不会作为首次启动依赖，只在检查者失败后触发返工。"
        await onUpdate(record)

        if let configurationError = missingModelConfigurationMessage(project: project, apiConfigs: apiConfigs, settings: settings) {
            appendLog(&record, .error, nil, configurationError)
            record.status = .failed
            record.endedAt = Date()
            record.currentNodeIDs = []
            record.currentStage = "模型配置缺失"
            record.diagnosticMessage = configurationError
            await onUpdate(record)
            throw WorkflowEngineError.missingModelConfiguration(configurationError)
        }

        while !queue.isEmpty {
            try Task.checkCancellation()

            let candidates = queue
            queue.removeAll()

            var readyNodes: [WorkflowNode] = []
            var stillWaiting: [UUID] = []
            var seenThisWave = Set<UUID>()

            for nodeID in candidates {
                guard !seenThisWave.contains(nodeID), let node = project.nodes.first(where: { $0.id == nodeID }) else { continue }
                seenThisWave.insert(nodeID)

                if node.kind != .start,
                   let blockedReason = blockedConditionalInputReason(for: node, project: project, contextByNode: contextByNode, dirtyNodeIDs: dirtyNodeIDs, runningNodeIDs: runningNodeIDs) {
                    appendLog(&record, .info, node.title, "条件分支未命中，已跳过本轮执行：\(blockedReason)")
                    var skippedRecord = NodeRunRecord(nodeID: node.id, nodeTitle: node.title, kind: node.kind, status: .skipped)
                    skippedRecord.output = "条件分支未命中：\(blockedReason)"
                    skippedRecord.endedAt = Date()
                    record.nodeRecords.append(skippedRecord)
                    continue
                }

                let missingInputs = missingRequiredInputTitles(
                    for: node,
                    project: project,
                    contextByNode: contextByNode,
                    dirtyNodeIDs: dirtyNodeIDs,
                    runningNodeIDs: runningNodeIDs
                )
                if node.kind != .start && !missingInputs.isEmpty {
                    waitCounts[nodeID, default: 0] += 1
                    waitStartDates[nodeID] = waitStartDates[nodeID] ?? Date()
                    stillWaiting.append(nodeID)
                    record.currentNodeTitle = node.title
                    syncDependencyState(waitingIDs: stillWaiting)
                    record.currentStage = "等待上游：\(node.title)"
                    let waitedSeconds = Int(Date().timeIntervalSince(waitStartDates[nodeID] ?? Date()))
                    record.diagnosticMessage = "正在等待上游完成：\(missingInputs.joined(separator: "、"))。等待上游时间不计入 \(node.title) 的模块/API 超时时间；该模块会显示为等待/预备，不会显示为运行中。"
                    if waitCounts[nodeID, default: 0] == 1 || waitCounts[nodeID, default: 0] % 10 == 0 {
                        appendLog(&record, .info, node.title, "等待上游：\(missingInputs.joined(separator: "、"))。已等待约 \(waitedSeconds) 秒；这段等待不计入模块/API timeout，模块计时只会在真正开始执行后启动。")
                    }
                    await onUpdate(record)
                    continue
                }

                if let started = waitStartDates[nodeID] {
                    let waitedSeconds = Int(Date().timeIntervalSince(started))
                    if waitedSeconds > 0 {
                        appendLog(&record, .info, node.title, "上游已齐，结束等待约 \(waitedSeconds) 秒；现在才开始计算 \(node.title) 的执行超时。")
                    }
                }
                waitStartDates[nodeID] = nil
                waitCounts[nodeID] = nil
                readyNodes.append(node)
            }

            if readyNodes.isEmpty {
                syncDependencyState(waitingIDs: stillWaiting)
                queue = stillWaiting
                if queue.isEmpty { break }

                // v6.7：这里已经没有正在执行的并行任务；如果仍然只剩等待节点，
                // 就不是“正常等待上游”，而是依赖死锁/未命中分支/坏连线。
                // 不能无限循环刷新 UI，看起来像进度消失或永远等待。
                if runningNodeIDs.isEmpty {
                    let waitingTitles = stillWaiting.compactMap { id in project.nodes.first(where: { $0.id == id })?.title }
                    let message = "没有可继续执行的模块，但仍有模块在等待上游：\(waitingTitles.joined(separator: "、"))。可能原因：条件分支未命中、返工线连错、某个上游模块没有被触发，或存在循环依赖。"
                    appendLog(&record, .error, nil, message)
                    record.status = .failed
                    record.endedAt = Date()
                    record.currentNodeIDs = []
                    record.waitingNodeIDs = stillWaiting
                    record.currentStage = "依赖等待死锁"
                    record.diagnosticMessage = message
                    await onUpdate(record)
                    throw WorkflowEngineError.dependencyDeadlock(message)
                }

                await onUpdate(record)
                try await Task.sleep(nanoseconds: 120_000_000)
                continue
            }

            if executed > safetyLimit {
                appendLog(&record, .error, nil, "检测到可能的无限返工循环，已停止。")
                record.status = .failed
                record.endedAt = Date()
                record.currentStage = "循环保护停止"
                record.diagnosticMessage = WorkflowEngineError.safetyLimitReached.localizedDescription
                await onUpdate(record)
                throw WorkflowEngineError.safetyLimitReached
            }

            let batchTitles = readyNodes.map(\.title).joined(separator: "、")
            runningNodeIDs.formUnion(readyNodes.map(\.id))
            syncDependencyState(waitingIDs: stillWaiting)
            record.currentNodeTitle = readyNodes.count == 1 ? readyNodes[0].title : "\(readyNodes.count) 个模块并行运行"
            record.currentStage = readyNodes.count == 1 ? "正在执行：\(readyNodes[0].title)" : "并行执行：\(batchTitles)"
            record.diagnosticMessage = readyNodes.count == 1 ? "当前模块正在运行。" : "已同时启动 \(readyNodes.count) 个可并行模块；仍缺上游的节点保持等待/预备状态。"
            appendLog(&record, .info, nil, readyNodes.count == 1 ? "启动模块：\(batchTitles)" : "并行启动模块：\(batchTitles)")

            var inputContexts: [UUID: String] = [:]
            for node in readyNodes {
                visitCounts[node.id, default: 0] += 1
                executed += 1
                let inputContext = inputContextFor(node: node, project: project, contextByNode: contextByNode)
                inputContexts[node.id] = inputContext
                var nodeRecord = NodeRunRecord(nodeID: node.id, nodeTitle: node.title, kind: node.kind, status: .running)
                nodeRecord.inputPreview = inputAuditPreview(for: node, inputContext: inputContext, project: project)
                nodeRecord.returnCount = returnCounts[node.id] ?? 0
                record.nodeRecords.append(nodeRecord)
                let estimatedInputTokens = TokenEstimator.roughCount(inputContext)
                let effectiveTimeoutForLog = node.kind == .codeWorker ? max(node.timeoutSeconds, 180) : max(node.timeoutSeconds + 10, 20)
                appendLog(&record, .info, node.title, "开始执行模块。预计发送输入约 \(estimatedInputTokens) Token，字符 \(inputContext.count)。模块/API timeout 从现在开始计算：\(effectiveTimeoutForLog) 秒。")
                if node.kind.isReviewer {
                    appendLog(&record, .info, node.title, "检查者输入审计：已把已连接上游模块的完整输出放入请求体；输出详情里显示的是预览，不代表真实请求被截断。")
                }
                if node.kind == .dispatcher {
                    let targetCount = dispatchTargets(for: node, project: project).count
                    appendLog(&record, targetCount == 0 ? .warning : .info, node.title, targetCount == 0 ? "任务分配者没有检测到已连接工作者，请先从输出接口连接到工作者。" : "任务分配者已读取 \(targetCount) 个已连接下游工作者，并会按这些连接关系分配任务。")
                }
            }
            record.progress = min(0.95, max(record.progress, (Double(executed) - 0.35) / Double(max(project.nodes.count, 1))))
            await onUpdate(record)

            var fatalError: Error?

            func handleParallelResult(_ result: ParallelNodeResult) {
                let node = result.node
                runningNodeIDs.remove(node.id)
                syncDependencyState(waitingIDs: stillWaiting)

                if let error = result.error {
                    if let index = record.nodeRecords.lastIndex(where: { $0.nodeID == node.id && $0.status == .running }) {
                        record.nodeRecords[index].status = .failed
                        record.nodeRecords[index].endedAt = Date()
                        record.nodeRecords[index].errorMessage = error.localizedDescription
                    }
                    if error is CancellationError {
                        appendLog(&record, .warning, node.title, "运行被用户停止。")
                        record.status = .cancelled
                        record.endedAt = Date()
                        record.currentStage = "已停止"
                        record.diagnosticMessage = "用户点击停止运行。"
                        fatalError = error
                    } else {
                        appendLog(&record, .error, node.title, error.localizedDescription)
                        record.status = .failed
                        record.endedAt = Date()
                        record.currentStage = "失败：\(node.title)"
                        record.diagnosticMessage = error.localizedDescription
                        fatalError = error
                    }
                    return
                }

                guard let response = result.response else { return }
                let decision = reviewerDecision(node: node, output: response.text)
                let output = (node.kind.isReviewer && decision.passed == true) ? "{\"passed\":true,\"feedback\":\"\"}" : response.text
                contextByNode[node.id] = output
                dirtyNodeIDs.remove(node.id)
                syncDependencyState(waitingIDs: stillWaiting)
                record.output = latestCombinedOutput(project: project, contextByNode: contextByNode)
                record.tokenUsage = record.tokenUsage + response.tokenUsage

                if let index = record.nodeRecords.lastIndex(where: { $0.nodeID == node.id && $0.status == .running }) {
                    let reviewerPassed = node.kind.isReviewer ? (decision.passed ?? false) : true
                    record.nodeRecords[index].status = reviewerPassed ? .passed : .returned
                    record.nodeRecords[index].endedAt = Date()
                    record.nodeRecords[index].output = output
                    record.nodeRecords[index].tokenUsage = response.tokenUsage
                    let effectiveProvider = effectiveProviderID(for: node, settings: settings)
                    record.nodeRecords[index].providerName = effectiveProvider.flatMap { id in apiConfigs.first(where: { $0.id == id })?.name }
                    record.nodeRecords[index].modelID = effectiveModelID(for: node, settings: settings)
                }

                let passed = node.kind.isReviewer ? (decision.passed ?? false) : true
                appendLog(&record, passed ? .success : .warning, node.title, passed ? "模块完成，Token：\(response.tokenUsage.total)" : "模块完成但检查未通过，Token：\(response.tokenUsage.total)")
                if node.kind.isReviewer {
                    if passed {
                        appendLog(&record, .success, node.title, "检查通过：已清空修改建议，继续走通过出口。")
                    } else {
                        let feedback = decision.feedback?.trimmingCharacters(in: .whitespacesAndNewlines)
                        appendLog(&record, .warning, node.title, "检查未通过：走不合格出口。\(feedback?.isEmpty == false ? " 返工意见：\(feedback!)" : "")")
                    }
                }

                let next = nextEdges(from: node, passed: passed, project: project)
                if next.isEmpty && node.kind != .output {
                    appendLog(&record, .warning, node.title, "该模块没有后续连线，流程在这里结束。")
                }
                for edge in next {
                    if edge.condition == .failed || edge.condition == .scoreLow {
                        returnCounts[edge.to, default: 0] += 1
                        let count = returnCounts[edge.to, default: 0]
                        let maxBlockingReturns = 3
                        if count > maxBlockingReturns {
                            appendLog(&record, .error, node.title, "检查者已连续打回同一模块 \(maxBlockingReturns) 次，仍判定存在阻塞问题。已停止返工循环，避免无限运行；请手动查看检查意见或放宽检查标准。")
                            record.status = .failed
                            record.endedAt = Date()
                            record.currentStage = "返工循环保护停止"
                            record.diagnosticMessage = WorkflowEngineError.safetyLimitReached.localizedDescription
                            fatalError = WorkflowEngineError.safetyLimitReached
                            break
                        }
                    }
                    markDirtyCascade(from: edge.to)
                    syncDependencyState(waitingIDs: stillWaiting)
                    appendQueue(edge.to, into: &queue)
                }
            }

            await withTaskGroup(of: ParallelNodeResult.self) { group in
                for node in readyNodes {
                    let inputContext = inputContexts[node.id] ?? ""
                    let effectiveTimeout = node.kind == .codeWorker ? max(node.timeoutSeconds, 180) : max(node.timeoutSeconds + 10, 20)
                    group.addTask {
                        do {
                            try Task.checkCancellation()
                            let response = try await self.withTimeout(seconds: effectiveTimeout) {
                                try await self.execute(node: node, project: project, context: inputContext, apiConfigs: apiConfigs, settings: settings, aiClient: aiClient)
                            }
                            try Task.checkCancellation()
                            return ParallelNodeResult(node: node, inputContext: inputContext, response: response, error: nil)
                        } catch {
                            return ParallelNodeResult(node: node, inputContext: inputContext, response: nil, error: error)
                        }
                    }
                }

                for await result in group {
                    if fatalError == nil {
                        handleParallelResult(result)
                        record.progress = min(0.98, Double(executed) / Double(max(project.nodes.count, 1)))
                        await onUpdate(record)
                    }
                    if fatalError != nil { group.cancelAll() }
                }
            }

            if let fatalError {
                await onUpdate(record)
                if fatalError is CancellationError { throw CancellationError() }
                throw fatalError
            }

            queue = deduplicated(stillWaiting + queue)
            record.progress = min(0.98, Double(executed) / Double(max(project.nodes.count, 1)))
            await onUpdate(record)
        }

        record.status = .completed
        record.endedAt = Date()
        record.progress = 1
        record.currentNodeTitle = nil
        record.currentNodeIDs = []
        record.waitingNodeIDs = nil
        record.staleNodeIDs = nil
        record.currentStage = "运行完成"
        record.diagnosticMessage = "全部可达模块已执行完成。并行分支已按依赖关系合并。"
        record.output = latestCombinedOutput(project: project, contextByNode: contextByNode)
        appendLog(&record, .success, nil, "工作流运行完成")
        return record
    }

    private func execute(node: WorkflowNode, project: WorkflowProject, context: String, apiConfigs: [APIProviderConfig], settings: AppSettings, aiClient: AIClient) async throws -> AITextResponse {
        switch node.kind {
        case .start:
            let imageNote = project.resources.contains(where: { $0.kind == .image }) ? "\n已检测到图片资源；图片内容将交给图片理解模块处理。" : ""
            let text = "已接收需求。\n\n\(project.userPrompt)\(imageNote)"
            return AITextResponse(text: text, tokenUsage: TokenUsage(input: TokenEstimator.roughCount(project.userPrompt), output: TokenEstimator.roughCount(text)))
        case .logger:
            let text = "日志记录模块已记录当前上下文、模块输出、Token 与状态。"
            return AITextResponse(text: text, tokenUsage: TokenUsage(input: 0, output: TokenEstimator.roughCount(text)))
        case .versionSnapshot:
            let text = "版本快照模块已保存工作流结构、提示词、模型配置和当前输出。"
            return AITextResponse(text: text, tokenUsage: TokenUsage(input: 0, output: TokenEstimator.roughCount(text)))
        case .output:
            let text = context.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? "输出模块没有收到上游内容。请把项目打包者、格式转换者或汇总者连接到输出模块的输入口。" : context
            return AITextResponse(text: text, tokenUsage: TokenUsage(input: TokenEstimator.roughCount(context), output: TokenEstimator.roughCount(text)))
        default:
            guard let providerID = effectiveProviderID(for: node, settings: settings),
                  let config = apiConfigs.first(where: { $0.id == providerID }),
                  let model = effectiveModelID(for: node, settings: settings),
                  !model.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
                throw WorkflowEngineError.missingModelConfiguration("\(node.title) 未配置可用模型。请先在设置页配置全局默认模型，或在模块详情里单独选择模型，然后在工作流页点击“一键应用默认模型”。")
            }
            let apiKey = try KeychainService.read(account: config.keychainAccount)
            let system = systemPrompt(for: node)
            let outputRule: String
            if node.kind.isReviewer {
                outputRule = "输出要求：只能输出 JSON。你必须完整检查所有已连接上游输出，特别是完整代码块和 file path 文件块，不能只看摘要或开头。只有发现阻塞/严重问题才允许不通过。通过时 {\"passed\":true,\"severity\":\"pass\",\"feedback\":\"\",\"blockingIssues\":[]}；不通过时 {\"passed\":false,\"severity\":\"blocking\",\"feedback\":\"必须返工的阻塞问题\",\"blockingIssues\":[\"具体阻塞问题\"]}。普通优化建议、风格偏好、可选重构必须通过，不要为了找问题而找问题。不要泄露 API Key。"
            } else if node.kind == .dispatcher {
                outputRule = "输出要求：必须按已连接工作者逐个分配任务。优先输出 JSON：{\"assignments\":[{\"targetNodeID\":\"节点ID\",\"targetTitle\":\"工作者标题\",\"task\":\"具体任务\",\"inputsNeeded\":\"需要读取的上游资料\",\"expectedOutput\":\"期望输出\",\"acceptanceCriteria\":\"验收标准\"}],\"parallelPlan\":\"哪些任务可以并行\"}。必须使用下面给出的真实 targetNodeID，不要编造不存在的模块。"
            } else if node.kind == .formatter {
                outputRule = "输出要求：你是格式转换者，只负责把多个上游结果智能转换成最终文件内容，不要再做质量检查。若有多条上游线，你必须逐个读取每个上游模块的输出，判断它应该变成什么文件格式；如果上游内容已明确文件名/语言/用途，按它输出；如果不明确，先根据用户目标和上游内容智能推断。输出开头必须给出 FILE_FORMAT_PLAN，列出 来源模块 -> 文件路径 -> 格式 -> 理由。然后必须输出真实文件块，格式为 ```file path=\"snake.py\" 或 ```file path=\"README.md\"，代码内容放在代码块内。不要只给说明而不给文件内容。不要泄露 API Key。"
            } else if node.kind == .filePackager {
                outputRule = "输出要求：你是项目打包者 / 文件结构整理者，不是普通 ZIP 按钮。你要读取上游所有文件块和用户目标，智能决定项目目录结构；必要时补充 README.md、requirements.txt、package.json、配置文件、assets 目录、运行脚本或说明。必须输出 PROJECT_PACKAGE_PLAN，列出目录树、每个文件来源、为什么这样组织。然后输出最终文件块，格式为 ```file path=\"ProjectName/main.py\" ... ```。不要随意重写核心业务代码；如果只需移动/补说明，保留原代码内容。不要泄露 API Key。"
            } else if node.kind == .optimizer {
                outputRule = "输出要求：你是意见提出者 / 优化者，但不能只提出意见。必须先用极短列表说明你发现的关键问题/优化动作，然后直接给出优化后的完整版本。不要输出 passed JSON，不要走检查者逻辑；如果输入是代码或文件块，必须输出修改后的完整文件块。不要泄露 API Key。"
            } else {
                outputRule = "输出要求：结构化、可执行、指出不确定内容和风险。不要泄露 API Key。"
            }
            let dispatchGuide = node.kind == .dispatcher ? """

            # 已连接工作者 / 可分配目标
            你必须只向下面这些真实连接的下游模块分配任务：
            \(connectedDispatchTargetSummary(for: node, project: project))

            分配要求：
            - 读取上面的连接关系，而不是按想象添加工作者。
            - 每个 assignment 必须对应一个真实连接的 targetNodeID。
            - 如果多个工作者从任务分配者并行连出，要把可并行任务拆开，后续运行引擎会同时启动它们。
            - 如果某个连接目标不是工作者，也要说明为什么需要给它什么输入。
            """ : ""
            let workerGuide = node.kind.isAssignableWorker ? """

            # 本模块身份
            当前模块 ID：\(node.id.uuidString)
            当前模块标题：\(node.title)
            当前模块类型：\(node.kind.title)
            如果上游包含任务分配者输出，请只执行分配给本模块 ID 或本模块标题的任务；如果没有明确匹配，则执行与本模块类型最相关的部分。
            """ : ""
            let user = """
            当前模块输入（包含用户原始需求 + 上游 AI 模块真实输出）：
            \(context)
            \(dispatchGuide)
            \(workerGuide)

            当前模块职责：
            \(node.kind == .custom ? node.prompt : node.kind.defaultPrompt)

            交流要求：必须明确参考上游模块输出继续工作；如果上游给了修改意见、识别结果、代码、方案或任务分配表，要把它作为本模块输入的一部分处理，不要从零开始。
            模块间追问规则：如果本模块确实缺少关键信息，可以写 ASK_UPSTREAM: <问题>。运行引擎会把上游已有输出作为回复上下文再次交给你生成最终结果；但不能因为小问题空等，能根据上游内容合理推断时必须继续完成。

            \(outputRule)
            """

            if node.kind == .imageUnderstanding, let image = project.resources.first(where: { $0.kind == .image })?.base64Preview {
                return try await aiClient.completeVision(baseURL: config.baseURL, apiKey: apiKey, model: model, prompt: user, imageBase64: image, maxTokens: node.maxTokens, temperature: node.temperature, timeoutSeconds: node.kind == .codeWorker ? max(node.timeoutSeconds, 180) : max(node.timeoutSeconds + 10, 20))
            } else {
                let messages = [AIMessage(role: "system", content: system), AIMessage(role: "user", content: user)]
                let initial = try await aiClient.completeText(baseURL: config.baseURL, apiKey: apiKey, model: model, messages: messages, maxTokens: node.maxTokens, temperature: node.temperature, timeoutSeconds: node.kind == .codeWorker ? max(node.timeoutSeconds, 180) : max(node.timeoutSeconds + 10, 20))
                return try await resolveUpstreamQuestionsIfNeeded(node: node, initial: initial, context: context, system: system, config: config, apiKey: apiKey, model: model, aiClient: aiClient)
            }
        }
    }

    private func packageSummary(from context: String) -> String {
        let files = ZipArchiveService.detectGeneratedFilePaths(in: context)
        if files.isEmpty {
            return """
            # 项目打包者 / 文件结构整理者

            暂未在上游内容中识别到明确文件块。

            请让“格式转换者”先输出文件块；项目打包者会在此基础上整理目录结构，例如：

            ```file path="snake.py"
            # Python 代码
            ```

            如果没有可识别文件块，项目打包者无法整理项目目录；当前上游内容仍会进入输出模块。
            """
        }
        let list = files.map { "- `\($0)`" }.joined(separator: "\n")
        return """
        # 项目打包者 / 文件结构整理者

        已识别到以下文件块。项目打包者应把它们组织为合理的项目目录：

        \(list)

        ## 整理规则
        - 简单单文件可直接交给输出模块导出，不必使用项目打包者。
        - 多文件/项目任务应补齐 README、依赖文件、目录结构和运行说明。
        - 输出模块只负责展示和导出，不会重新整理这些文件。
        """
    }

    private func missingModelConfigurationMessage(project: WorkflowProject, apiConfigs: [APIProviderConfig], settings: AppSettings) -> String? {
        let reachableIDs = reachableNodeIDs(fromStartIn: project)
        let missing = project.nodes
            .filter { reachableIDs.contains($0.id) && requiresAIModel($0.kind) }
            .filter { node in
                guard let providerID = effectiveProviderID(for: node, settings: settings),
                      apiConfigs.contains(where: { $0.id == providerID }),
                      let modelID = effectiveModelID(for: node, settings: settings),
                      !modelID.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
                    return true
                }
                return false
            }

        guard !missing.isEmpty else { return nil }
        let names = missing.map { "• \($0.title)（\($0.kind.title)）" }.joined(separator: "\n")
        return "以下可达 AI 模块没有可用模型，已阻止运行，避免出现假完成/占位输出：\n\(names)\n\n请到设置页配置全局默认模型，或在模块详情中单独选择模型，然后点击工作流页“一键应用默认模型”。"
    }

    private func reachableNodeIDs(fromStartIn project: WorkflowProject) -> Set<UUID> {
        guard let start = project.nodes.first(where: { $0.kind == .start }) else { return [] }
        var visited = Set<UUID>()
        var queue: [UUID] = [start.id]
        while let id = queue.first {
            queue.removeFirst()
            guard !visited.contains(id) else { continue }
            visited.insert(id)
            let next = project.edges.filter { $0.from == id }.map(\.to)
            queue.append(contentsOf: next)
        }
        return visited
    }

    private func requiresAIModel(_ kind: WorkflowNodeKind) -> Bool {
        switch kind {
        case .start, .output, .logger, .versionSnapshot:
            return false
        default:
            return true
        }
    }

    private func effectiveProviderID(for node: WorkflowNode, settings: AppSettings) -> UUID? {
        if let providerID = node.providerID { return providerID }
        switch node.kind {
        case .codeWorker:
            return settings.defaultCodeProviderID ?? settings.defaultTextProviderID
        case .codeReviewer, .qualityReviewer:
            return settings.defaultReviewerProviderID ?? settings.defaultTextProviderID
        case .visualReviewer, .imageUnderstanding:
            return settings.defaultVisionProviderID ?? settings.defaultReviewerProviderID ?? settings.defaultTextProviderID
        case .imageGenerator:
            return settings.defaultImageProviderID ?? settings.defaultTextProviderID
        default:
            return settings.defaultTextProviderID
        }
    }

    private func effectiveModelID(for node: WorkflowNode, settings: AppSettings) -> String? {
        if let modelID = node.modelID, !modelID.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { return modelID }
        switch node.kind {
        case .codeWorker:
            return settings.defaultCodeModelID ?? settings.defaultTextModelID
        case .codeReviewer, .qualityReviewer:
            return settings.defaultReviewerModelID ?? settings.defaultTextModelID
        case .visualReviewer, .imageUnderstanding:
            return settings.defaultVisionModelID ?? settings.defaultReviewerModelID ?? settings.defaultTextModelID
        case .imageGenerator:
            return settings.defaultImageModelID ?? settings.defaultTextModelID
        default:
            return settings.defaultTextModelID
        }
    }

    private func systemPrompt(for node: WorkflowNode) -> String {
        switch node.kind {
        case .codeReviewer:
            return "你是代码检查者。你不是意见收集器，只能检查会导致代码不可用的阻塞问题。必须通过：普通优化、风格建议、命名偏好、可选重构、轻微体验问题。只有编译失败、缺少关键文件/入口、依赖明显错误、API Key 泄露、严重安全风险、核心需求未实现这类阻塞问题才不通过。必须只输出 JSON：{\"passed\":true,\"severity\":\"pass\",\"feedback\":\"\",\"blockingIssues\":[]} 或 {\"passed\":false,\"severity\":\"blocking\",\"feedback\":\"必须返工的阻塞问题\",\"blockingIssues\":[\"具体阻塞问题\"]}。通过时 feedback 必须为空，不要给修改建议。"
        case .qualityReviewer:
            return "你是质量评估者。你只能因为阻塞质量问题打回，例如严重偏离用户要求、缺少核心内容、明显事实/逻辑错误、输出格式完全错误。普通改进建议必须通过。必须只输出 JSON：{\"passed\":true,\"severity\":\"pass\",\"feedback\":\"\",\"blockingIssues\":[]} 或 {\"passed\":false,\"severity\":\"blocking\",\"feedback\":\"必须返工的问题\",\"blockingIssues\":[\"具体阻塞问题\"]}。通过时 feedback 必须为空。"
        case .visualReviewer:
            return "你是视觉检查者。只有严重影响使用的视觉/UI问题才不通过，例如文字看不清、关键按钮不可见、布局遮挡、尺寸严重不适配。普通美化建议必须通过。必须只输出 JSON：{\"passed\":true,\"severity\":\"pass\",\"feedback\":\"\",\"blockingIssues\":[]} 或 {\"passed\":false,\"severity\":\"blocking\",\"feedback\":\"必须返工的严重视觉问题\",\"blockingIssues\":[\"具体阻塞问题\"]}。通过时 feedback 必须为空。"
        case .codeWorker:
            return "你是代码工作者。必须读取上游计划和检查者 review_notes；如果有上一轮代码输出，必须基于上一轮完整修改，不要只复述建议。输出可直接使用的完整代码/文件结构/运行说明。"
        case .optimizer:
            return "你是意见提出者 / 优化者。你不是检查者，不负责通过/不通过；你需要阅读上游结果，简短指出关键改进点，然后直接生成优化后的完整版本。不要只输出建议。"
        case .filePackager:
            return "你是项目打包者 / 文件结构整理者。你的价值不是把文件压缩成 ZIP，而是把上游散乱文件整理成可交付项目：目录树、文件命名、README、依赖文件、资源目录和运行说明。"
        case .imageUnderstanding:
            return "你是图片理解模块。输出图片摘要、关键文字、可操作信息、不确定内容。"
        case .multiModelVote:
            return "你是裁判模型。比较多个答案，选择更可靠结果，并解释理由。"
        default:
            return "你是 AI Workflow Studio 的 \(node.kind.title)。你必须读取上游模块传来的内容，并在此基础上继续处理，形成真实多 AI 协作链。"
        }
    }

    private func localFallbackOutput(for node: WorkflowNode, context: String, project: WorkflowProject) -> String {
        switch node.kind {
        case .planner:
            return "未配置模型，使用本地占位计划：1. 拆解需求；2. 执行核心任务；3. 检查质量；4. 导出结果。"
        case .dispatcher:
            return localDispatcherFallback(for: node, project: project)
        case .codeReviewer, .qualityReviewer, .visualReviewer:
            return "{\"passed\":false,\"feedback\":\"未配置检查者模型，无法确认质量。请配置检查者模型后重新运行，或手动调整连线。\"}"
        case .imageUnderstanding:
            return "未配置图片理解模型，无法识别图片。请在设置中添加支持图片输入的模型。"
        default:
            return "未配置模型，\(node.kind.title) 已跳过真实 AI 调用，仅生成占位输出。"
        }
    }

    private func localDispatcherFallback(for node: WorkflowNode, project: WorkflowProject) -> String {
        let targets = dispatchTargets(for: node, project: project)
        guard !targets.isEmpty else {
            return "任务分配者没有检测到已连接的下游工作者。请从任务分配者输出接口连接到通用工作者、代码工作者、图片生成者等模块后再运行。"
        }
        let assignments = targets.map { target in
            """
            {
              \"targetNodeID\": \"\(target.id.uuidString)\",
              \"targetTitle\": \"\(target.title)\",
              \"task\": \"根据用户需求和上游计划，完成适合 \(target.kind.title) 的子任务。\",
              \"inputsNeeded\": \"用户原始需求、计划者输出、相关上游资料。\",
              \"expectedOutput\": \"\(target.kind.outputDescription)\",
              \"acceptanceCriteria\": \"输出必须可被后续模块直接使用，并说明不确定内容。\"
            }
            """
        }.joined(separator: ",\n")
        return """
        {
          \"assignments\": [
        \(assignments)
          ],
          \"parallelPlan\": \"以上已连接工作者可以按依赖关系并行执行；多个下游同时连接时会同时启动。\"
        }
        """
    }

    private func inputContextFor(node: WorkflowNode, project: WorkflowProject, contextByNode: [UUID: String]) -> String {
        if node.kind == .start { return "# 用户原始需求\n\(project.userPrompt)" }
        let incoming = project.edges.filter { $0.to == node.id }
        let formatterSourceList = incoming.compactMap { edge -> String? in
            guard let source = project.nodes.first(where: { $0.id == edge.from }) else { return nil }
            return "- 来源模块：\(source.title)｜类型：\(source.kind.title)｜连线条件：\(edge.condition.title)"
        }.joined(separator: "\n")
        let dispatcherConnectionContext: String = node.kind == .dispatcher ? """

        # 任务分配者实际连接的下游模块
        下面是当前画布上从“任务分配者”直接连出去的真实模块。任务分配必须基于这个列表：
        \(connectedDispatchTargetSummary(for: node, project: project))
        """ : ""
        let formatterConnectionContext: String = node.kind == .formatter ? """

        # 格式转换者多上游输入清单
        你当前连接了 \(incoming.count) 条上游线。必须逐个读取这些上游输出，智能判断每个来源应转换成什么文件格式；如果多个上游内容属于同一项目，可以合并成同一个文件或拆分成多个文件，并在 FILE_FORMAT_PLAN 说明原因。
        \(formatterSourceList)
        """ : ""
        let upstream = incoming.compactMap { edge -> String? in
            guard !isFeedbackReturnEdge(edge, in: project),
                  let source = project.nodes.first(where: { $0.id == edge.from }),
                  let output = contextByNode[source.id] else { return nil }
            if source.kind.isReviewer {
                let decision = reviewerDecision(node: source, output: output)
                if (edge.condition == .passed || edge.condition == .scoreHigh) && decision.passed != true { return nil }
                if (edge.condition == .failed || edge.condition == .scoreLow) && decision.passed == true { return nil }
            }
            return """
            ## 来自上游 AI：\(source.title)
            连线条件：\(edge.condition.title)
            上游输出：
            \(output)
            """
        }
        let reviewerCompletenessNote: String = node.kind.isReviewer ? """

        # 检查完整性要求
        你是检查者。必须检查上方每一个已连接上游模块的完整输出，尤其是所有代码块和 file path 文件块。
        如果上游输出很长，不要只检查开头；必须从结构、语法、依赖、运行入口、安全风险和用户需求匹配度整体判断。
        只有阻塞/严重问题才判定不通过；普通优化建议必须通过。
        """ : ""

        let previousOwnOutput = contextByNode[node.id].map { previous in
            """

            # 本模块上一轮输出
            \(previous)
            """
        } ?? ""

        let reviewerFeedback = incoming.compactMap { edge -> String? in
            guard edge.condition == .failed || edge.condition == .scoreLow,
                  let source = project.nodes.first(where: { $0.id == edge.from }),
                  source.kind.isReviewer,
                  let output = contextByNode[source.id] else { return nil }
            return "来自检查者 \(source.title) 的不合格返工意见：\n\(output)"
        }.joined(separator: "\n\n")

        if upstream.isEmpty {
            return """
            # 用户原始需求
            \(project.userPrompt)

            # 上游 AI 交流上下文
            暂无上游输出；此模块会直接基于用户需求工作。
            \(dispatcherConnectionContext)
            \(formatterConnectionContext)
            \(previousOwnOutput)
            """
        }
        return """
        # 用户原始需求
        \(project.userPrompt)

        # 上游 AI 交流上下文
        \(upstream.joined(separator: "\n\n"))
        \(dispatcherConnectionContext)
        \(formatterConnectionContext)
        \(reviewerCompletenessNote)
        \(previousOwnOutput)

        # 返工意见 / review_notes
        \(reviewerFeedback.isEmpty ? "无" : reviewerFeedback)

        # 执行要求
        当前模块必须基于以上上游输出继续处理，不要忽略上游结果。
        如果本次是检查者打回，请对照 review_notes 和本模块上一轮输出，直接产出修复后的完整版本。
        """
    }

    private func inputAuditPreview(for node: WorkflowNode, inputContext: String, project: WorkflowProject) -> String {
        let incoming = project.edges.filter { $0.to == node.id }
        let upstreamSummary = incoming.compactMap { edge -> String? in
            guard let source = project.nodes.first(where: { $0.id == edge.from }) else { return nil }
            return "- \(source.title) → \(node.title)（\(edge.condition.title)）"
        }.joined(separator: "\n")
        let maxVisibleCharacters = 6000
        let preview = String(inputContext.prefix(maxVisibleCharacters))
        let truncatedNote = inputContext.count > maxVisibleCharacters ? "\n\n……这里之后还有 \(inputContext.count - maxVisibleCharacters) 个字符未在界面展示，但运行请求会发送完整 inputContext。" : ""
        return """
        【输入审计】
        实际发送给模型的输入约 \(TokenEstimator.roughCount(inputContext)) Token，字符数 \(inputContext.count)。
        注意：这里是界面预览，不是请求截断；如果 API 自己返回的 prompt_tokens 更低，通常是模型/供应商计数方式不同。
        上游连接：
        \(upstreamSummary.isEmpty ? "无" : upstreamSummary)

        【输入预览】
        \(preview)\(truncatedNote)
        """
    }

    private func isFeedbackReturnEdge(_ edge: WorkflowEdge, in project: WorkflowProject) -> Bool {
        guard let source = project.nodes.first(where: { $0.id == edge.from }) else { return false }

        // Only reviewer -> ancestor return lines are feedback triggers.
        // A failed edge to a downstream auto-fixer/worker is still a real conditional dependency and must not
        // be ignored while checking required inputs.
        guard source.kind.isReviewer else { return false }
        return hasPath(from: edge.to, to: edge.from, in: project, ignoring: edge.id)
    }

    private func hasPath(from start: UUID, to target: UUID, in project: WorkflowProject, ignoring ignoredEdgeID: UUID? = nil) -> Bool {
        if start == target { return true }
        var visited = Set<UUID>()
        var queue: [UUID] = [start]
        while let id = queue.first {
            queue.removeFirst()
            guard visited.insert(id).inserted else { continue }
            let next = project.edges
                .filter { $0.id != ignoredEdgeID && $0.from == id }
                .map(\.to)
            if next.contains(target) { return true }
            queue.append(contentsOf: next)
        }
        return false
    }

    private func blockedConditionalInputReason(
        for node: WorkflowNode,
        project: WorkflowProject,
        contextByNode: [UUID: String],
        dirtyNodeIDs: Set<UUID>,
        runningNodeIDs: Set<UUID>
    ) -> String? {
        let incoming = project.edges.filter { $0.to == node.id }
        for edge in incoming {
            guard !isFeedbackReturnEdge(edge, in: project),
                  let source = project.nodes.first(where: { $0.id == edge.from }),
                  !runningNodeIDs.contains(source.id),
                  !dirtyNodeIDs.contains(source.id),
                  let sourceOutput = contextByNode[source.id] else { continue }

            if source.kind.isReviewer {
                let decision = reviewerDecision(node: source, output: sourceOutput)
                if (edge.condition == .passed || edge.condition == .scoreHigh) && decision.passed != true {
                    return "\(source.title) 没有通过，但当前输入线要求通过。"
                }
                if (edge.condition == .failed || edge.condition == .scoreLow) && decision.passed == true {
                    return "\(source.title) 已通过，但当前输入线要求失败/低分。"
                }
            }
        }
        return nil
    }

    private func missingRequiredInputTitles(
        for node: WorkflowNode,
        project: WorkflowProject,
        contextByNode: [UUID: String],
        dirtyNodeIDs: Set<UUID>,
        runningNodeIDs: Set<UUID>
    ) -> [String] {
        let incoming = project.edges.filter { $0.to == node.id }
        return incoming.compactMap { edge in
            guard let source = project.nodes.first(where: { $0.id == edge.from }) else { return nil }

            // 返工/反馈线不是普通启动依赖。
            // 例如：汇总者 -> 综合检查者，不合格 -> 计划者/任务分配者。
            // 计划者第一次运行时不能等待“未来才会产生”的检查者失败输出；
            // 只有检查者真的失败后，这条线才作为触发线重新把计划者/任务分配者加入队列。
            if isFeedbackReturnEdge(edge, in: project) {
                return nil
            }

            if runningNodeIDs.contains(source.id) {
                return "\(source.title)（正在运行）"
            }
            if dirtyNodeIDs.contains(source.id) {
                return "\(source.title)（等待最新输出）"
            }

            guard let sourceOutput = contextByNode[source.id] else {
                return source.title
            }

            if source.kind.isReviewer {
                let decision = reviewerDecision(node: source, output: sourceOutput)
                if (edge.condition == .passed || edge.condition == .scoreHigh) && decision.passed != true {
                    return "\(source.title)（通过条件未满足）"
                }
                if (edge.condition == .failed || edge.condition == .scoreLow) && decision.passed == true {
                    return "\(source.title)（失败/低分条件未满足）"
                }
            }

            return nil
        }
    }

    private func nextEdges(from node: WorkflowNode, passed: Bool, project: WorkflowProject) -> [WorkflowEdge] {
        let outgoing = project.edges.filter { $0.from == node.id }
        if node.kind.isReviewer {
            if passed {
                let passEdges = outgoing.filter { $0.condition == .passed || $0.condition == .scoreHigh }
                if !passEdges.isEmpty { return passEdges }

                // If a reviewer passes and has only generic outgoing lines, do not follow obvious
                // feedback-return lines back to an ancestor. This prevents a successful review from
                // restarting the planner/dispatcher loop.
                return outgoing.filter { $0.condition == .always && !isFeedbackReturnEdge($0, in: project) }
            } else {
                let failEdges = outgoing.filter { $0.condition == .failed || $0.condition == .scoreLow }
                if !failEdges.isEmpty { return failEdges }

                // Fallback for workflows where the user connected the reviewer back to a planner/dispatcher
                // with a normal output port by mistake. Treat reviewer -> ancestor lines as return lines
                // only when the reviewer fails.
                let feedbackEdges = outgoing.filter { isFeedbackReturnEdge($0, in: project) }
                if !feedbackEdges.isEmpty { return feedbackEdges }

                return outgoing.filter { $0.condition == .always }
            }
        }
        return outgoing.filter { $0.condition == .always || $0.condition == .passed || $0.condition == .scoreHigh }
    }

    private func dispatchTargets(for dispatcher: WorkflowNode, project: WorkflowProject) -> [WorkflowNode] {
        let directTargetIDs = project.edges
            .filter { $0.from == dispatcher.id && ($0.condition == .always || $0.condition == .passed || $0.condition == .scoreHigh) }
            .map(\.to)
        return directTargetIDs.compactMap { targetID in
            project.nodes.first { $0.id == targetID }
        }
    }

    private func connectedDispatchTargetSummary(for dispatcher: WorkflowNode, project: WorkflowProject) -> String {
        let targets = dispatchTargets(for: dispatcher, project: project)
        guard !targets.isEmpty else {
            return "未检测到从任务分配者输出接口连接出去的工作者。请先连线，否则无法知道要把任务分给谁。"
        }
        return targets.map { target in
            let apiText: String
            if let modelID = target.modelID, !modelID.isEmpty {
                apiText = "模型：\(modelID)"
            } else {
                apiText = "模型：未设置，将使用本地占位或提示配置默认模型"
            }
            return """
            - targetNodeID: \(target.id.uuidString)
              标题：\(target.title)
              类型：\(target.kind.title)
              能力说明：\(target.kind.summary)
              输入能力：\(target.kind.inputDescription)
              期望输出：\(target.kind.outputDescription)
              \(apiText)
            """
        }.joined(separator: "\n")
    }

    private struct ReviewerDecision: Decodable {
        var passed: Bool?
        var severity: String?
        var feedback: String?
        var blockingIssues: [String]?
    }

    private func reviewerDecision(node: WorkflowNode, output: String) -> (passed: Bool?, feedback: String?) {
        guard node.kind.isReviewer else { return (true, nil) }
        if let jsonText = extractJSONObject(from: output),
           let data = jsonText.data(using: .utf8),
           let decoded = try? JSONDecoder().decode(ReviewerDecision.self, from: data) {
            let feedback = decoded.feedback?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
            let blockingIssues = decoded.blockingIssues?.map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }.filter { !$0.isEmpty } ?? []
            if decoded.passed == true { return (true, nil) }
            if isBlockingSeverity(decoded.severity) || !blockingIssues.isEmpty || isBlockingFeedback(feedback, for: node.kind) {
                let merged = (blockingIssues + (feedback.isEmpty ? [] : [feedback])).joined(separator: "\n")
                return (false, merged.isEmpty ? output : merged)
            }
            return (true, nil)
        }
        let lower = output.lowercased()
        if lower.contains("\"passed\":true") || lower.contains("passed: true") || lower.contains("通过") || lower.contains("合格") {
            return (true, nil)
        }
        if lower.contains("\"passed\":false") || lower.contains("passed: false") || lower.contains("不通过") || lower.contains("不合格") || lower.contains("failed") {
            return isBlockingFeedback(output, for: node.kind) ? (false, output) : (true, nil)
        }
        return (true, nil)
    }

    private func isBlockingSeverity(_ severity: String?) -> Bool {
        let text = (severity ?? "").lowercased()
        return text.contains("blocking") || text.contains("critical") || text.contains("fatal") || text.contains("blocker") || text.contains("严重") || text.contains("阻塞")
    }

    private func isBlockingFeedback(_ feedback: String, for kind: WorkflowNodeKind) -> Bool {
        let lower = feedback.lowercased()
        let sharedKeywords = [
            "blocking", "critical", "fatal", "cannot", "can't", "unable", "missing required", "not implemented",
            "阻塞", "严重", "无法", "不能", "缺少核心", "未实现核心", "完全错误", "必须返工"
        ]
        let codeKeywords = [
            "compile", "build failed", "syntax error", "type error", "cannot find", "no such module", "crash",
            "api key", "secret", "security", "xcode build", "编译", "构建失败", "语法错误", "类型错误", "找不到", "闪退", "泄露", "安全风险"
        ]
        let visualKeywords = [
            "unreadable", "invisible", "overlap", "blocked", "clipped", "看不清", "不可见", "遮挡", "重叠", "被裁切"
        ]
        var keywords = sharedKeywords
        if kind == .codeReviewer { keywords += codeKeywords }
        if kind == .visualReviewer { keywords += visualKeywords }
        return keywords.contains { lower.contains($0) }
    }

    private func extractJSONObject(from text: String) -> String? {
        guard let start = text.firstIndex(of: "{"), let end = text.lastIndex(of: "}"), start <= end else { return nil }
        return String(text[start...end])
    }

    private func resolveUpstreamQuestionsIfNeeded(
        node: WorkflowNode,
        initial: AITextResponse,
        context: String,
        system: String,
        config: APIProviderConfig,
        apiKey: String,
        model: String,
        aiClient: AIClient
    ) async throws -> AITextResponse {
        guard !node.kind.isReviewer, outputRequestsUpstreamAnswer(initial.text) else { return initial }

        let clarificationPrompt = """
        当前模块第一次输出中包含对上游的追问。下面提供的是运行引擎整理出的上游回复上下文。

        # 当前模块
        \(node.title)（\(node.kind.title)）

        # 当前模块第一次输出 / 追问
        \(initial.text)

        # 上游回复上下文
        上游模块不会重新运行；请根据下面这些已完成的上游输出回答追问并继续完成当前模块任务：
        \(context)

        # 最终输出要求
        - 不要只重复问题。
        - 先用一小段“上游回复摘要”说明你如何理解上游回复。
        - 然后给出当前模块的最终完整输出。
        - 如果你是格式转换者，多上游输入必须输出 FILE_FORMAT_PLAN，并输出真实 ```file path="..." 文件块。
        - 如果仍有不确定内容，给出合理默认选择，不要让工作流空等。
        """
        let messages = [
            AIMessage(role: "system", content: system),
            AIMessage(role: "user", content: clarificationPrompt)
        ]
        let reply = try await aiClient.completeText(
            baseURL: config.baseURL,
            apiKey: apiKey,
            model: model,
            messages: messages,
            maxTokens: node.maxTokens,
            temperature: min(node.temperature, 0.4),
            timeoutSeconds: node.kind == .codeWorker ? max(node.timeoutSeconds, 180) : max(node.timeoutSeconds, 60)
        )
        return AITextResponse(text: reply.text, tokenUsage: initial.tokenUsage + reply.tokenUsage)
    }

    private func outputRequestsUpstreamAnswer(_ text: String) -> Bool {
        let lower = text.lowercased()
        let markers = [
            "ask_upstream", "ask upstream", "upstream question", "question for upstream",
            "向上游询问", "询问上游", "需要上游", "上游问题", "请上游", "需要确认上游"
        ]
        return markers.contains { lower.contains($0) }
    }

    private func withTimeout<T>(seconds: Int, operation: @escaping () async throws -> T) async throws -> T {
        try await withThrowingTaskGroup(of: T.self) { group in
            group.addTask { try await operation() }
            group.addTask {
                try await Task.sleep(nanoseconds: UInt64(max(seconds, 1)) * 1_000_000_000)
                throw WorkflowEngineError.apiTimeout("实际 AI 调用/模块执行超过 \(seconds) 秒没有返回，已自动停止。上游等待时间不会计入这个 timeout；请检查网络、Base URL、模型名或把该模块超时时间调大。")
            }
            guard let result = try await group.next() else { throw WorkflowEngineError.cancelled }
            group.cancelAll()
            return result
        }
    }

    private func latestCombinedOutput(project: WorkflowProject, contextByNode: [UUID: String]) -> String {
        project.nodes.compactMap { node in
            guard let output = contextByNode[node.id] else { return nil }
            return "## \(node.title)\n\(output)"
        }.joined(separator: "\n\n")
    }

    private func appendLog(_ record: inout RunRecord, _ level: LogLevel, _ nodeTitle: String?, _ message: String) {
        record.logs.append(RunLogEntry(level: level, nodeTitle: nodeTitle, message: message))
        record.lastLogAt = Date()
        record.diagnosticMessage = message
    }
}
