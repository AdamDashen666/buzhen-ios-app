import Foundation

struct RunRecord: Identifiable, Codable, Hashable {
    var id: UUID = UUID()
    var projectID: UUID
    var projectTitle: String
    var startedAt: Date = Date()
    var endedAt: Date?
    var status: RunStatus = .running
    var progress: Double = 0
    var nodeRecords: [NodeRunRecord] = []
    var output: String = ""
    var tokenUsage: TokenUsage = .zero
    var logs: [RunLogEntry] = []
    var currentNodeTitle: String? = nil
    /// 正在真实执行/API 调用的节点。等待上游的节点不能放在这里，否则 UI 会误显示“运行中”。
    var currentNodeIDs: [UUID] = []
    /// 正在等待上游完成的节点。Optional 是为了兼容旧版本运行记录解码。
    var waitingNodeIDs: [UUID]? = nil
    /// 已被返工链路标记为旧输出/待重新执行的节点。Optional 是为了兼容旧版本运行记录解码。
    var staleNodeIDs: [UUID]? = nil
    var currentStage: String = "等待开始"
    var diagnosticMessage: String = ""
    var lastLogAt: Date = Date()

    var displayDate: String {
        startedAt.formatted(date: .abbreviated, time: .shortened)
    }
}

enum RunStatus: String, Codable, CaseIterable, Identifiable {
    case running
    case completed
    case failed
    case cancelled

    var id: String { rawValue }
    var title: String {
        switch self {
        case .running: return "运行中"
        case .completed: return "完成"
        case .failed: return "失败"
        case .cancelled: return "已取消"
        }
    }
}

struct NodeRunRecord: Identifiable, Codable, Hashable {
    var id: UUID = UUID()
    var nodeID: UUID
    var nodeTitle: String
    var kind: WorkflowNodeKind
    var status: NodeStatus
    var startedAt: Date = Date()
    var endedAt: Date?
    var inputPreview: String = ""
    var output: String = ""
    var errorMessage: String?
    var tokenUsage: TokenUsage = .zero
    var providerName: String?
    var modelID: String?
    var returnCount: Int = 0
}

struct RunLogEntry: Identifiable, Codable, Hashable {
    var id: UUID = UUID()
    var date: Date = Date()
    var level: LogLevel
    var nodeTitle: String?
    var message: String
}

enum LogLevel: String, Codable, CaseIterable, Identifiable {
    case info
    case warning
    case error
    case success

    var id: String { rawValue }
    var symbol: String {
        switch self {
        case .info: return "ℹ️"
        case .warning: return "⚠️"
        case .error: return "❌"
        case .success: return "✅"
        }
    }
}

struct TokenUsage: Codable, Hashable {
    var input: Int
    var output: Int

    var total: Int { input + output }

    static let zero = TokenUsage(input: 0, output: 0)

    static func + (lhs: TokenUsage, rhs: TokenUsage) -> TokenUsage {
        TokenUsage(input: lhs.input + rhs.input, output: lhs.output + rhs.output)
    }
}

struct VersionSnapshot: Identifiable, Codable, Hashable {
    var id: UUID = UUID()
    var projectID: UUID
    var createdAt: Date = Date()
    var title: String
    var project: WorkflowProject
    var output: String
    var note: String
}

enum TokenLimitMode: String, Codable, CaseIterable, Identifiable {
    case none
    case daily
    case singleWorkflow

    var id: String { rawValue }
    var title: String {
        switch self {
        case .none: return "不限制"
        case .daily: return "每日总量限制"
        case .singleWorkflow: return "单次工作流限制"
        }
    }

    var detail: String {
        switch self {
        case .none: return "不拦截运行，只记录 Token 使用。"
        case .daily: return "只检查当天全部运行累计 Token。"
        case .singleWorkflow: return "只检查本次工作流预估 Token。"
        }
    }
}

struct AppSettings: Codable, Hashable {
    var tokenLimitMode: TokenLimitMode = .none
    var dailyTokenLimit: Int = 300_000
    var singleWorkflowTokenLimit: Int = 80_000
    var singleModuleTokenLimit: Int = 128_000
    /// 0 表示多模型投票不限制模型数量。
    var maxVoteModels: Int = 0
    /// 0 表示默认无限返工。
    var maxReturnCount: Int = 0
    /// 新模块默认超时时间。单个模块仍可在模块详情里单独覆盖。
    var defaultModuleTimeoutSeconds: Int = 150
    /// 新模块默认最大输出 Token。0 表示不发送 max_tokens，由模型/供应商自己的上下文限制决定。
    var defaultModuleMaxTokens: Int = 0
    /// 默认是否为支持 Thinking Mode 的模型开启思考模式。单个模块可在模块详情中覆盖。
    var defaultUseThinkingMode: Bool = false
    var confirmWhenEstimatedCostOver: Double = 1.0
    var forceDarkMode: Bool = true
    var privacyModeForLogs: Bool = false

    /// 全局默认模型：不再放在单个 API 配置里。
    /// 工作流页“一键应用全局默认模型”会按模块类型读取这些值。
    var defaultTextProviderID: UUID? = nil
    var defaultTextModelID: String? = nil
    var defaultVisionProviderID: UUID? = nil
    var defaultVisionModelID: String? = nil
    var defaultImageProviderID: UUID? = nil
    var defaultImageModelID: String? = nil
    var defaultCodeProviderID: UUID? = nil
    var defaultCodeModelID: String? = nil
    var defaultReviewerProviderID: UUID? = nil
    var defaultReviewerModelID: String? = nil

    enum CodingKeys: String, CodingKey {
        case tokenLimitMode, dailyTokenLimit, singleWorkflowTokenLimit, singleModuleTokenLimit
        case maxVoteModels, maxReturnCount, defaultModuleTimeoutSeconds, defaultModuleMaxTokens, defaultUseThinkingMode
        case confirmWhenEstimatedCostOver, forceDarkMode, privacyModeForLogs
        case defaultTextProviderID, defaultTextModelID, defaultVisionProviderID, defaultVisionModelID
        case defaultImageProviderID, defaultImageModelID, defaultCodeProviderID, defaultCodeModelID
        case defaultReviewerProviderID, defaultReviewerModelID
    }

    init() {}

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        tokenLimitMode = try container.decodeIfPresent(TokenLimitMode.self, forKey: .tokenLimitMode) ?? .none
        dailyTokenLimit = try container.decodeIfPresent(Int.self, forKey: .dailyTokenLimit) ?? 300_000
        singleWorkflowTokenLimit = try container.decodeIfPresent(Int.self, forKey: .singleWorkflowTokenLimit) ?? 80_000
        singleModuleTokenLimit = try container.decodeIfPresent(Int.self, forKey: .singleModuleTokenLimit) ?? 128_000
        maxVoteModels = try container.decodeIfPresent(Int.self, forKey: .maxVoteModels) ?? 0
        maxReturnCount = try container.decodeIfPresent(Int.self, forKey: .maxReturnCount) ?? 0
        defaultModuleTimeoutSeconds = try container.decodeIfPresent(Int.self, forKey: .defaultModuleTimeoutSeconds) ?? 150
        defaultModuleMaxTokens = try container.decodeIfPresent(Int.self, forKey: .defaultModuleMaxTokens) ?? 0
        defaultUseThinkingMode = try container.decodeIfPresent(Bool.self, forKey: .defaultUseThinkingMode) ?? false
        confirmWhenEstimatedCostOver = try container.decodeIfPresent(Double.self, forKey: .confirmWhenEstimatedCostOver) ?? 1.0
        forceDarkMode = try container.decodeIfPresent(Bool.self, forKey: .forceDarkMode) ?? true
        privacyModeForLogs = try container.decodeIfPresent(Bool.self, forKey: .privacyModeForLogs) ?? false
        defaultTextProviderID = try container.decodeIfPresent(UUID.self, forKey: .defaultTextProviderID)
        defaultTextModelID = try container.decodeIfPresent(String.self, forKey: .defaultTextModelID)
        defaultVisionProviderID = try container.decodeIfPresent(UUID.self, forKey: .defaultVisionProviderID)
        defaultVisionModelID = try container.decodeIfPresent(String.self, forKey: .defaultVisionModelID)
        defaultImageProviderID = try container.decodeIfPresent(UUID.self, forKey: .defaultImageProviderID)
        defaultImageModelID = try container.decodeIfPresent(String.self, forKey: .defaultImageModelID)
        defaultCodeProviderID = try container.decodeIfPresent(UUID.self, forKey: .defaultCodeProviderID)
        defaultCodeModelID = try container.decodeIfPresent(String.self, forKey: .defaultCodeModelID)
        defaultReviewerProviderID = try container.decodeIfPresent(UUID.self, forKey: .defaultReviewerProviderID)
        defaultReviewerModelID = try container.decodeIfPresent(String.self, forKey: .defaultReviewerModelID)
    }

    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(tokenLimitMode, forKey: .tokenLimitMode)
        try container.encode(dailyTokenLimit, forKey: .dailyTokenLimit)
        try container.encode(singleWorkflowTokenLimit, forKey: .singleWorkflowTokenLimit)
        try container.encode(singleModuleTokenLimit, forKey: .singleModuleTokenLimit)
        try container.encode(maxVoteModels, forKey: .maxVoteModels)
        try container.encode(maxReturnCount, forKey: .maxReturnCount)
        try container.encode(defaultModuleTimeoutSeconds, forKey: .defaultModuleTimeoutSeconds)
        try container.encode(defaultModuleMaxTokens, forKey: .defaultModuleMaxTokens)
        try container.encode(defaultUseThinkingMode, forKey: .defaultUseThinkingMode)
        try container.encode(confirmWhenEstimatedCostOver, forKey: .confirmWhenEstimatedCostOver)
        try container.encode(forceDarkMode, forKey: .forceDarkMode)
        try container.encode(privacyModeForLogs, forKey: .privacyModeForLogs)
        try container.encodeIfPresent(defaultTextProviderID, forKey: .defaultTextProviderID)
        try container.encodeIfPresent(defaultTextModelID, forKey: .defaultTextModelID)
        try container.encodeIfPresent(defaultVisionProviderID, forKey: .defaultVisionProviderID)
        try container.encodeIfPresent(defaultVisionModelID, forKey: .defaultVisionModelID)
        try container.encodeIfPresent(defaultImageProviderID, forKey: .defaultImageProviderID)
        try container.encodeIfPresent(defaultImageModelID, forKey: .defaultImageModelID)
        try container.encodeIfPresent(defaultCodeProviderID, forKey: .defaultCodeProviderID)
        try container.encodeIfPresent(defaultCodeModelID, forKey: .defaultCodeModelID)
        try container.encodeIfPresent(defaultReviewerProviderID, forKey: .defaultReviewerProviderID)
        try container.encodeIfPresent(defaultReviewerModelID, forKey: .defaultReviewerModelID)
    }
}

