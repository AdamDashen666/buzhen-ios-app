import SwiftUI
import UIKit

struct APIConfigEditorView: View {
    @EnvironmentObject private var store: AppStore
    @Environment(\.dismiss) private var dismiss
    @State var config: APIProviderConfig
    var isNew: Bool
    @State private var apiKey = ""
    @State private var refreshMessage = ""
    @State private var errorLog = ""
    @State private var showingErrorLog = false
    @State private var modelSearch = ""
    @State private var selectedPresetID = APIBaseURLPreset.custom.id
    @State private var useAutoName = true
    @State private var didPrepareInitialState = false

    var body: some View {
        NavigationStack {
            Form {
                Section("API 名称") {
                    Toggle("自动读取 / 推断名称", isOn: $useAutoName)
                        .onChange(of: useAutoName) { enabled in
                            if enabled { applyAutoName() }
                        }

                    if useAutoName {
                        HStack {
                            Text("当前名称")
                            Spacer()
                            Text(inferredProviderName())
                                .foregroundStyle(.secondary)
                        }
                        Text("默认根据常用接口或 Base URL 自动推断名称；如果识别不准，可以关闭上面的开关并自定义。")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    } else {
                        TextField("自定义配置名称", text: $config.name)
                    }
                }

                Section("API 地址") {
                    Picker("常用 API Base URL", selection: $selectedPresetID) {
                        ForEach(APIBaseURLPreset.presets) { preset in
                            Text(preset.title).tag(preset.id)
                        }
                        Text(APIBaseURLPreset.custom.title).tag(APIBaseURLPreset.custom.id)
                    }
                    .onChange(of: selectedPresetID) { id in
                        guard let preset = APIBaseURLPreset.preset(id: id), !preset.baseURL.isEmpty else { return }
                        config.baseURL = preset.baseURL
                        config.interfaceTypes = preset.defaultInterfaceTypes
                        if useAutoName { config.name = preset.title }
                    }

                    TextField("API Base URL", text: Binding(
                        get: { config.baseURL },
                        set: { newValue in
                            config.baseURL = newValue.trimmingCharacters(in: .whitespacesAndNewlines)
                            selectedPresetID = APIBaseURLPreset.bestMatchID(for: config.baseURL)
                            if useAutoName { applyAutoName() }
                        }
                    ))
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .keyboardType(.URL)

                    SecureField(isNew ? "API Key" : "新 API Key（不填则保留）", text: $apiKey)
                    Text("可以从常用接口中选择，也可以手动输入 OpenAI-compatible Base URL。")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                Section("接口类型") {
                    ForEach(AIInterfaceType.allCases) { type in
                        Toggle(isOn: Binding(
                            get: { config.interfaceTypes.contains(type) },
                            set: { enabled in
                                if enabled { config.interfaceTypes.insert(type) } else { config.interfaceTypes.remove(type) }
                            }
                        )) {
                            VStack(alignment: .leading, spacing: 2) {
                                Text(type.title)
                                Text(type.detail)
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                        }
                    }
                }

                Section("模型") {
                    Text("模型列表请在设置页的“多 API 配置”区域点击“刷新全部模型”统一刷新。")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    if !refreshMessage.isEmpty { Text(refreshMessage).font(.caption).foregroundStyle(.secondary) }
                    TextField("搜索模型", text: $modelSearch)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                    Text("当前显示：\(filteredModels.count) / \(config.models.count) 个模型")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    Text("这里不再设置默认模型。默认文本 / 图片理解 / 图片生成 / 代码 / 检查者模型，请到设置页的“全局默认模型”里统一选择。")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    ForEach(filteredModels) { model in
                        VStack(alignment: .leading, spacing: 2) {
                            Text(model.id).font(.caption)
                            Text("图片理解：\(model.supportsVision ? "可能支持" : "未识别") · 图片生成：\(model.supportsImageGeneration ? "可能支持" : "未识别")")
                                .font(.caption2)
                                .foregroundStyle(.secondary)
                        }
                    }
                }

                Section("价格 / Token") {
                    TextField("输入 Token 每百万价格", value: $config.inputPricePerMillionTokens, format: .number)
                        .keyboardType(.decimalPad)
                    TextField("输出 Token 每百万价格", value: $config.outputPricePerMillionTokens, format: .number)
                        .keyboardType(.decimalPad)
                    Text("只用于费用估算，不会影响 API 真实计费。")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
            .scrollContentBackground(.hidden)
            .studioBackground()
            .navigationTitle(isNew ? "添加 API" : "编辑 API")
            .onAppear(perform: prepareInitialState)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("取消") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("保存") {
                        let finalConfig = preparedConfigForSave()
                        if isNew { store.addAPIConfig(finalConfig, apiKey: apiKey) }
                        else { store.updateAPIConfig(finalConfig, apiKey: apiKey.isEmpty ? nil : apiKey) }
                        dismiss()
                    }
                }
            }
            .alert("刷新模型失败", isPresented: $showingErrorLog) {
                Button("复制错误日志") { UIPasteboard.general.string = errorLog }
                Button("关闭", role: .cancel) { }
            } message: {
                Text(errorLog)
            }
        }
    }

    private var filteredModels: [AIModelInfo] {
        let query = modelSearch.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        guard !query.isEmpty else { return config.models }
        return config.models.filter { $0.id.lowercased().contains(query) || $0.name.lowercased().contains(query) }
    }

    private func prepareInitialState() {
        guard !didPrepareInitialState else { return }
        didPrepareInitialState = true
        selectedPresetID = APIBaseURLPreset.bestMatchID(for: config.baseURL)
        let inferred = inferredProviderName()
        useAutoName = isNew || config.name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || config.name == inferred || config.name == "OpenAI 兼容接口"
        if useAutoName { config.name = inferred }
    }

    private func inferredProviderName() -> String {
        APIBaseURLPreset.inferredName(for: config.baseURL)
    }

    private func applyAutoName() {
        config.name = inferredProviderName()
    }

    private func preparedConfigForSave() -> APIProviderConfig {
        var final = config
        if useAutoName || final.name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            final.name = APIBaseURLPreset.inferredName(for: final.baseURL)
        }
        final.baseURL = final.baseURL.trimmingCharacters(in: .whitespacesAndNewlines)
        return final
    }
}

private struct APIBaseURLPreset: Identifiable, Hashable {
    var id: String
    var title: String
    var baseURL: String
    var defaultInterfaceTypes: Set<AIInterfaceType> = [.chat]

    static let custom = APIBaseURLPreset(id: "custom", title: "自定义", baseURL: "")

    static let presets: [APIBaseURLPreset] = [
        APIBaseURLPreset(id: "openai", title: "OpenAI", baseURL: "https://api.openai.com/v1", defaultInterfaceTypes: [.chat, .responses, .vision, .imageGeneration]),
        APIBaseURLPreset(id: "deepseek", title: "DeepSeek", baseURL: "https://api.deepseek.com", defaultInterfaceTypes: [.chat]),
        APIBaseURLPreset(id: "doubao", title: "豆包 / 火山方舟", baseURL: "https://ark.cn-beijing.volces.com/api/v3", defaultInterfaceTypes: [.chat, .vision]),
        APIBaseURLPreset(id: "gemini", title: "Gemini OpenAI 兼容", baseURL: "https://generativelanguage.googleapis.com/v1beta/openai", defaultInterfaceTypes: [.chat, .vision]),
        APIBaseURLPreset(id: "openrouter", title: "OpenRouter", baseURL: "https://openrouter.ai/api/v1", defaultInterfaceTypes: [.chat, .responses, .vision]),
        APIBaseURLPreset(id: "kimi", title: "Kimi / Moonshot", baseURL: "https://api.moonshot.ai/v1", defaultInterfaceTypes: [.chat, .vision]),
        APIBaseURLPreset(id: "siliconflow", title: "硅基流动 SiliconFlow", baseURL: "https://api.siliconflow.cn/v1", defaultInterfaceTypes: [.chat, .vision]),
        APIBaseURLPreset(id: "groq", title: "Groq", baseURL: "https://api.groq.com/openai/v1", defaultInterfaceTypes: [.chat])
    ]

    static func preset(id: String) -> APIBaseURLPreset? {
        if id == custom.id { return custom }
        return presets.first { $0.id == id }
    }

    static func bestMatchID(for baseURL: String) -> String {
        let normalizedValue = normalized(baseURL)
        return presets.first { normalized($0.baseURL) == normalizedValue }?.id ?? custom.id
    }

    static func inferredName(for baseURL: String) -> String {
        let normalizedValue = normalized(baseURL)
        if let preset = presets.first(where: { normalized($0.baseURL) == normalizedValue }) {
            return preset.title
        }
        guard let host = URL(string: baseURL.trimmingCharacters(in: .whitespacesAndNewlines))?.host else {
            return "OpenAI 兼容接口"
        }
        let cleaned = host
            .replacingOccurrences(of: "api.", with: "")
            .replacingOccurrences(of: "www.", with: "")
            .split(separator: ".")
            .first
            .map(String.init) ?? host
        return cleaned.isEmpty ? "OpenAI 兼容接口" : cleaned.prefix(1).uppercased() + String(cleaned.dropFirst())
    }

    private static func normalized(_ value: String) -> String {
        value.trimmingCharacters(in: .whitespacesAndNewlines)
            .trimmingCharacters(in: CharacterSet(charactersIn: "/"))
            .lowercased()
    }
}
