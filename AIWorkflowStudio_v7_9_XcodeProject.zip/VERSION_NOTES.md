# Version Notes - v7.9 / Build 70

本版本主要加入 DeepSeek Thinking Mode 支持。

## 用户可见变化
- 设置 → 全局默认参数：新增“支持时默认启用 Thinking Mode”。
- 模块详情 → 模型设置：如果当前模型支持 Thinking Mode，会显示单模块开关。
- 单模块开关可覆盖全局设置，也可点击“跟随设置页默认”。

## 技术实现
- `AIModelInfo` 新增 `supportsThinkingMode`。
- `WorkflowNode` 新增 `useThinkingMode`，nil 表示跟随全局默认。
- `AppSettings` 新增 `defaultUseThinkingMode`。
- `AIClient.completeText` / `completeVision` 支持 `thinkingModeType`。
- DeepSeek 类模型启用时发送：
  - `thinking: { "type": "enabled" }`
  - `reasoning_effort: "high"`
- DeepSeek 类模型关闭时发送：
  - `thinking: { "type": "disabled" }`
- 启用 Thinking Mode 时省略 `temperature`。

## 检查
- ZIP 完整性 OK
- 全项目 Swift parse OK
- Info.plist = 7.9 / Build 70
