# AIWorkflowStudio Changelog

## v7.9 / Build 70

### 新增
- 设置页新增“支持时默认启用 Thinking Mode”开关。
- 模块详情页新增“启用 Thinking Mode”开关，并支持“跟随设置页默认”。
- 模型列表刷新后会自动识别 DeepSeek / Reasoning 类模型是否支持 Thinking Mode。
- AI 请求支持发送 `thinking: { type: enabled/disabled }`。
- Thinking Mode 开启时自动发送 `reasoning_effort: high`。

### 修复 / 优化
- 对支持思考模式的模型，关闭开关时会显式发送 `thinking.disabled`，避免 DeepSeek 默认开启思考模式造成用户误解。
- Thinking Mode 开启时不再发送 `temperature`，避免无效参数混淆。
- AI 响应解析兼容 `reasoning_content` 字段，但 App 仍只把最终 `content` 作为模块输出，避免把思考内容混入下游。

### 风险 / 注意
- `0 = 不限制 max_tokens` 只代表 App 不主动限制，模型供应商仍可能有输出上限。
- Thinking Mode 只在识别为支持的模型上生效；如果第三方代理模型名不标准，可能需要刷新模型列表或手动确认模型名。
