# IPAOneClickBuilder-iOS

iPadOS / iOS 端 GitHub Actions 一键打包器。当前版本已经按你的仓库适配：

```text
Repo: AdamDashen666/buzhen-ios-app
Reference run: https://github.com/AdamDashen666/buzhen-ios-app/actions/runs/27696458167/workflow
Job style: Build newest source zip
Output artifacts: Built-IPA-Newest-* / Build-Diagnostics-Newest-*
```

## 它现在的工作流程

```text
选择 Xcode Project ZIP
→ App 把 ZIP 提交到 buzhen-ios-app 仓库根目录
→ 触发你给的同一个 GitHub Actions workflow
→ 等待 macOS runner 打包
→ 成功：下载 Built-IPA artifact ZIP 和 Diagnostics artifact ZIP
→ 失败：自动下载 GitHub run logs ZIP、job 摘要、diagnostics artifact
→ 可选删除刚上传的 ZIP / 旧 artifacts / 旧根目录 ZIP
```

> 注意：GitHub Actions 的 artifact 下载接口返回的是 ZIP，所以 App 下载的是 `Built-IPA-xxx.zip`。这个 ZIP 里面包含 `.ipa`。在“文件”App 里解压即可拿到 IPA。

## 打开方式

1. 解压本项目。
2. 用 Xcode 打开 `IPAOneClickBuilder.xcodeproj`。
3. 修改 Signing Team / Bundle ID。
4. 跑到 iPad 或 iPhone。
5. 在 App 里填 GitHub Token。
6. 选择 Xcode 项目 ZIP。
7. 点“开始打包”。

## GitHub Token 权限

Token 至少需要：

```text
Contents: Read and Write
Actions: Read and Write / Workflow
Metadata: Read
```

Fine-grained token 建议只授权 `AdamDashen666/buzhen-ios-app` 这个仓库。

## 默认适配点

App 默认会从这个链接解析 workflow id：

```text
https://github.com/AdamDashen666/buzhen-ios-app/actions/runs/27696458167/workflow
```

因此 `Workflow ID/文件` 可以留空。如果你以后换 workflow，也可以直接填：

```text
workflow id
或 xxx.yml
```

## 重要限制

GitHub Contents API 上传单文件不适合超过约 95 MB 的 ZIP。超过时 App 会阻止上传，并提示改用 Release 上传模式或压缩项目。

你的现有 workflow 是在仓库根目录执行：

```bash
find . -maxdepth 1 -type f -name "*.zip" | sort -V | tail -n 1
```

所以本 App 会默认把上传文件命名为：

```text
zzzz-IPAOneClickUpload-时间戳-原文件名.zip
```

这样基本可以保证 workflow 选中新上传的 ZIP。

## 失败自动日志

如果 workflow 失败，App 会自动：

```text
1. 查询 jobs
2. 标出失败 job / 失败 step
3. 下载 GitHub run logs ZIP
4. 下载 Build-Diagnostics artifact ZIP
5. 保存 Failure-Summary txt
```

## 版本

当前版本：v1.1.0
