import Foundation
import SwiftUI

@MainActor
final class CompressorViewModel: ObservableObject {
    @Published var selectedURLs: [URL] = []
    @Published var summary: ScanSummary = .empty
    @Published var estimates: [EstimateResult] = []
    @Published var selectedProfile: CompressionProfile = .zipCompatible
    @Published var options = CompressionOptions()
    @Published var isBusy = false
    @Published var statusText = "未选择文件"
    @Published var outputURL: URL?
    @Published var errorText: String?

    var selectedEstimate: EstimateResult? {
        estimates.first { $0.profile == selectedProfile }
    }

    func handlePickedURLs(_ urls: [URL]) {
        guard !urls.isEmpty else {
            handlePickerCancel()
            return
        }

        outputURL = nil
        errorText = nil
        statusText = "已选择 \(urls.count) 项，正在获取权限并扫描…"
        Task { await scan(urls: urls) }
    }

    func handlePickerCancel() {
        if selectedURLs.isEmpty {
            statusText = "未选择文件"
        }
    }

    func handlePickerError(_ error: Error) {
        errorText = "文件选择失败：\(error.localizedDescription)"
        if selectedURLs.isEmpty {
            statusText = "未选择文件"
        }
    }

    func scan(urls: [URL]) async {
        selectedURLs = urls
        outputURL = nil
        errorText = nil
        isBusy = true
        statusText = "正在扫描文件大小…"
        defer { isBusy = false }

        do {
            let scanResult = try await Task.detached(priority: .userInitiated) {
                try FileScanner.scan(urls: urls)
            }.value
            summary = scanResult
            estimates = CompressionEstimator.estimates(for: scanResult)
            statusText = "已扫描：\(scanResult.fileCount) 个文件，\(scanResult.folderCount) 个文件夹"
        } catch {
            summary = .empty
            estimates = []
            statusText = "扫描失败"
            errorText = error.localizedDescription
        }
    }

    func compress() async {
        guard !selectedURLs.isEmpty else { return }
        outputURL = nil
        errorText = nil
        isBusy = true
        statusText = "正在压缩…"
        defer { isBusy = false }

        do {
            let profile = selectedProfile
            let currentOptions = options
            let urls = selectedURLs
            let output = try await Task.detached(priority: .userInitiated) {
                try CompressionService.compress(urls: urls, profile: profile, options: currentOptions)
            }.value
            outputURL = output
            let size = (try? output.resourceValues(forKeys: [.fileSizeKey]).fileSize).map(Int64.init) ?? 0
            statusText = "压缩完成：\(Formatters.byteString(size))"
        } catch {
            statusText = "压缩失败"
            errorText = error.localizedDescription
        }
    }
}
