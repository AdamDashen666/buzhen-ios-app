import SwiftUI
import UIKit
import UniformTypeIdentifiers

struct ContentView: View {
    @StateObject private var model = CompressorViewModel()
    @State private var showImporter = false

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    HeaderCard()
                    InputSelectionCard(
                        statusText: model.statusText,
                        isBusy: model.isBusy,
                        items: model.summary.items,
                        onSelect: { showImporter = true }
                    )

                    if model.summary.totalBytes > 0 {
                        EstimateListCard(
                            totalBytes: model.summary.totalBytes,
                            estimates: model.estimates,
                            selectedProfile: $model.selectedProfile
                        )
                        CompressionOptionsCard(
                            outputName: $model.options.outputName,
                            skipHiddenFiles: $model.options.skipHiddenFiles,
                            warning: warningText(for: model.selectedProfile)
                        )
                        CompressionActionCard(
                            isBusy: model.isBusy,
                            hasInput: model.summary.totalBytes > 0,
                            outputURL: model.outputURL,
                            onCompress: { Task { await model.compress() } }
                        )
                        FileCategoryCard(categoryBytes: model.summary.categoryBytes)
                    }

                    if let errorText = model.errorText {
                        ErrorMessageCard(message: errorText)
                    }
                }
                .padding()
                .frame(maxWidth: 1000, alignment: .center)
                .frame(maxWidth: .infinity)
            }
            .navigationTitle("Local Compressor")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        showImporter = true
                    } label: {
                        Label("选择", systemImage: "plus")
                    }
                    .disabled(model.isBusy)
                }
            }
            .sheet(isPresented: $showImporter) {
                MultiDocumentPicker(
                    onPick: { urls in
                        showImporter = false
                        model.handlePickedURLs(urls)
                    },
                    onCancel: {
                        showImporter = false
                        model.handlePickerCancel()
                    },
                    onError: { error in
                        showImporter = false
                        model.handlePickerError(error)
                    }
                )
                .ignoresSafeArea()
            }
        }
    }

    private func warningText(for profile: CompressionProfile) -> String {
        switch profile {
        case .zipCompatible:
            return "ZIP 兼容性最好，但压缩率通常不是最高。"
        case .appleLZFSE:
            return "LZFSE 输出为本 App 的 .lcz 本地包，更适合 Apple 设备之间保存。"
        case .appleLZMA:
            return "LZMA 可能最小，但对超大文件会更慢、更吃内存。"
        }
    }
}

private let adaptiveColumns = [GridItem(.adaptive(minimum: 260), spacing: 14)]

private struct HeaderCard: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 12) {
                Image(systemName: "archivebox.fill")
                    .font(.system(size: 36))
                    .symbolRenderingMode(.hierarchical)

                VStack(alignment: .leading, spacing: 4) {
                    Text("本地 iPadOS 压缩工具")
                        .font(.title2.bold())
                    Text("多选文件/文件夹 → 扫描原始大小 → 选择压缩模式 → 输出到本地")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
            }

            Text("注意：MP4、JPG、HEIC、ZIP、MP3 这类本来就压缩过的文件，很难再压小；想极小通常需要转码/降画质。")
                .font(.footnote)
                .foregroundStyle(.secondary)
        }
        .padding(18)
        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 24, style: .continuous))
    }
}

private struct InputSelectionCard: View {
    let statusText: String
    let isBusy: Bool
    let items: [SelectedItem]
    let onSelect: () -> Void

    var body: some View {
        CardContainer {
            VStack(alignment: .leading, spacing: 14) {
                HStack {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("输入文件")
                            .font(.headline)
                        Text(statusText)
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                    }
                    Spacer()
                    Button(action: onSelect) {
                        Label("选择文件/文件夹", systemImage: "folder.badge.plus")
                    }
                    .buttonStyle(.borderedProminent)
                    .disabled(isBusy)
                }

                if isBusy {
                    ProgressView()
                }

                if !items.isEmpty {
                    LazyVGrid(columns: adaptiveColumns, alignment: .leading, spacing: 12) {
                        ForEach(items) { item in
                            SelectedItemRow(item: item)
                        }
                    }
                }
            }
        }
    }
}

private struct SelectedItemRow: View {
    let item: SelectedItem

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: item.isDirectory ? "folder.fill" : "doc.fill")
                .font(.title3)
                .frame(width: 28)

            VStack(alignment: .leading, spacing: 3) {
                Text(item.displayName)
                    .font(.subheadline.weight(.semibold))
                    .lineLimit(1)
                Text("\(Formatters.byteString(item.byteSize)) · \(item.fileCount) 文件")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Spacer()
        }
        .padding(12)
        .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
    }
}

private struct EstimateListCard: View {
    let totalBytes: Int64
    let estimates: [EstimateResult]
    @Binding var selectedProfile: CompressionProfile

    var body: some View {
        CardContainer {
            VStack(alignment: .leading, spacing: 14) {
                VStack(alignment: .leading, spacing: 3) {
                    Text("压缩预估")
                        .font(.headline)
                    Text("原始大小：\(Formatters.byteString(totalBytes))")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }

                LazyVGrid(columns: adaptiveColumns, alignment: .leading, spacing: 12) {
                    ForEach(estimates) { estimate in
                        EstimateOptionButton(
                            estimate: estimate,
                            isSelected: selectedProfile == estimate.profile,
                            onSelect: { selectedProfile = estimate.profile }
                        )
                    }
                }
            }
        }
    }
}

private struct EstimateOptionButton: View {
    let estimate: EstimateResult
    let isSelected: Bool
    let onSelect: () -> Void

    private var title: String { estimate.profile.title }
    private var subtitle: String { estimate.profile.subtitle }
    private var estimatedSize: String { Formatters.byteString(estimate.estimatedBytes) }
    private var ratioText: String { "约为原来的 \(Formatters.percent(estimate.ratio))" }

    var body: some View {
        Button(action: onSelect) {
            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    Text(title)
                        .font(.headline)
                    Spacer()
                    if isSelected {
                        Image(systemName: "checkmark.circle.fill")
                    }
                }

                Text(subtitle)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.leading)

                HStack(alignment: .firstTextBaseline) {
                    Text(estimatedSize)
                        .font(.title3.bold())
                    Text(ratioText)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
            .padding(14)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
            .overlay(selectionBorder)
        }
        .buttonStyle(.plain)
    }

    private var selectionBorder: some View {
        let color: Color = isSelected ? Color.primary.opacity(0.55) : Color.secondary.opacity(0.2)
        return RoundedRectangle(cornerRadius: 18, style: .continuous)
            .stroke(color, lineWidth: 1)
    }
}

private struct CompressionOptionsCard: View {
    @Binding var outputName: String
    @Binding var skipHiddenFiles: Bool
    let warning: String

    var body: some View {
        CardContainer {
            VStack(alignment: .leading, spacing: 14) {
                Text("压缩选项")
                    .font(.headline)

                TextField("输出文件名", text: $outputName)
                    .textFieldStyle(.roundedBorder)

                Toggle("跳过隐藏文件（.DS_Store、隐藏缓存等）", isOn: $skipHiddenFiles)

                Text(warning)
                    .font(.footnote)
                    .foregroundStyle(.secondary)
            }
        }
    }
}

private struct CompressionActionCard: View {
    let isBusy: Bool
    let hasInput: Bool
    let outputURL: URL?
    let onCompress: () -> Void

    var body: some View {
        CardContainer {
            VStack(alignment: .leading, spacing: 12) {
                Button(action: onCompress) {
                    Label(isBusy ? "处理中…" : "开始压缩", systemImage: "arrow.down.doc.fill")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)
                .controlSize(.large)
                .disabled(isBusy || !hasInput)

                if let outputURL {
                    OutputCard(outputURL: outputURL)
                }
            }
        }
    }
}

private struct OutputCard: View {
    let outputURL: URL

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("输出完成")
                .font(.headline)
            Text(outputURL.lastPathComponent)
                .font(.footnote.monospaced())
                .lineLimit(2)
            ShareLink(item: outputURL) {
                Label("分享 / 存到文件", systemImage: "square.and.arrow.up")
                    .frame(maxWidth: .infinity)
            }
            .buttonStyle(.bordered)
        }
        .padding(14)
        .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
    }
}

private struct FileCategoryCard: View {
    let categoryBytes: [FileCategory: Int64]

    var body: some View {
        CardContainer {
            VStack(alignment: .leading, spacing: 12) {
                Text("文件类型分析")
                    .font(.headline)

                ForEach(FileCategory.allCases, id: \.self) { category in
                    let bytes = categoryBytes[category, default: 0]
                    if bytes > 0 {
                        HStack {
                            Text(category.title)
                            Spacer()
                            Text(Formatters.byteString(bytes))
                                .foregroundStyle(.secondary)
                        }
                        .font(.subheadline)
                    }
                }
            }
        }
    }
}

private struct ErrorMessageCard: View {
    let message: String

    var body: some View {
        HStack(alignment: .top, spacing: 10) {
            Image(systemName: "exclamationmark.triangle.fill")
            Text(message)
                .font(.footnote)
        }
        .foregroundStyle(.red)
        .padding(14)
        .background(.red.opacity(0.08), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
    }
}

private struct CardContainer<Content: View>: View {
    private let content: Content

    init(@ViewBuilder content: () -> Content) {
        self.content = content()
    }

    var body: some View {
        content
            .padding(18)
            .background(.background, in: RoundedRectangle(cornerRadius: 24, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 24, style: .continuous)
                    .stroke(Color.secondary.opacity(0.2), lineWidth: 1)
            )
    }
}


private struct MultiDocumentPicker: UIViewControllerRepresentable {
    let onPick: ([URL]) -> Void
    let onCancel: () -> Void
    let onError: (Error) -> Void

    func makeCoordinator() -> Coordinator {
        Coordinator(onPick: onPick, onCancel: onCancel, onError: onError)
    }

    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        let picker = UIDocumentPickerViewController(
            forOpeningContentTypes: [.data, .folder, .package],
            asCopy: false
        )
        picker.delegate = context.coordinator
        picker.allowsMultipleSelection = true
        picker.shouldShowFileExtensions = true
        picker.modalPresentationStyle = .formSheet
        return picker
    }

    func updateUIViewController(_ uiViewController: UIDocumentPickerViewController, context: Context) {}

    final class Coordinator: NSObject, UIDocumentPickerDelegate {
        let onPick: ([URL]) -> Void
        let onCancel: () -> Void
        let onError: (Error) -> Void

        init(
            onPick: @escaping ([URL]) -> Void,
            onCancel: @escaping () -> Void,
            onError: @escaping (Error) -> Void
        ) {
            self.onPick = onPick
            self.onCancel = onCancel
            self.onError = onError
        }

        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            let usableURLs = urls.filter { url in
                let accessed = url.startAccessingSecurityScopedResource()
                if accessed { url.stopAccessingSecurityScopedResource() }
                return true
            }
            onPick(usableURLs)
        }

        func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
            onCancel()
        }
    }
}
