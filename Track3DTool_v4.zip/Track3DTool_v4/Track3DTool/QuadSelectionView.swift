import SwiftUI

struct QuadSelectionView: View {
    let image: UIImage
    @Binding var points: [CGPoint]   // normalized, image-space, 0...1

    var body: some View {
        GeometryReader { geo in
            let imageRect = fittedRect(imageSize: image.size, container: geo.size)
            ZStack(alignment: .topLeading) {
                Image(uiImage: image)
                    .resizable()
                    .scaledToFit()
                    .frame(width: geo.size.width, height: geo.size.height)

                Path { path in
                    let display = points.map { toViewPoint($0, in: imageRect) }
                    if let first = display.first {
                        path.move(to: first)
                        for p in display.dropFirst() { path.addLine(to: p) }
                        if display.count == 4 { path.closeSubpath() }
                    }
                }
                .stroke(.yellow, lineWidth: 3)

                ForEach(Array(points.enumerated()), id: \.offset) { index, p in
                    let vp = toViewPoint(p, in: imageRect)
                    ZStack {
                        Circle().fill(.yellow).frame(width: 24, height: 24)
                        Text("\(index + 1)")
                            .font(.caption.bold())
                            .foregroundStyle(.black)
                    }
                    .position(vp)
                }

                if points.count == 4 {
                    let display = points.map { toViewPoint($0, in: imageRect) }
                    PerspectiveTextPreview(text: "TEXT", quad: display)
                }
            }
            .contentShape(Rectangle())
            .gesture(
                SpatialTapGesture().onEnded { value in
                    let normalized = toNormalized(value.location, in: imageRect)
                    guard normalized.x >= 0, normalized.x <= 1, normalized.y >= 0, normalized.y <= 1 else { return }
                    if points.count >= 4 { points.removeAll() }
                    points.append(normalized)
                }
            )
        }
    }

    private func fittedRect(imageSize: CGSize, container: CGSize) -> CGRect {
        guard imageSize.width > 0, imageSize.height > 0 else { return CGRect(origin: .zero, size: container) }
        let imageAspect = imageSize.width / imageSize.height
        let containerAspect = container.width / container.height
        if imageAspect > containerAspect {
            let width = container.width
            let height = width / imageAspect
            return CGRect(x: 0, y: (container.height - height) / 2, width: width, height: height)
        } else {
            let height = container.height
            let width = height * imageAspect
            return CGRect(x: (container.width - width) / 2, y: 0, width: width, height: height)
        }
    }

    private func toNormalized(_ p: CGPoint, in rect: CGRect) -> CGPoint {
        CGPoint(x: (p.x - rect.minX) / rect.width, y: (p.y - rect.minY) / rect.height)
    }

    private func toViewPoint(_ p: CGPoint, in rect: CGRect) -> CGPoint {
        CGPoint(x: rect.minX + p.x * rect.width, y: rect.minY + p.y * rect.height)
    }
}

struct PerspectiveTextPreview: View {
    let text: String
    let quad: [CGPoint]

    var body: some View {
        if quad.count == 4 {
            let center = CGPoint(
                x: quad.map(\.x).reduce(CGFloat(0), +) / 4,
                y: quad.map(\.y).reduce(CGFloat(0), +) / 4
            )
            Text(text)
                .font(.headline.bold())
                .foregroundStyle(.white)
                .shadow(radius: 4)
                .position(center)
                .allowsHitTesting(false)
        }
    }
}
