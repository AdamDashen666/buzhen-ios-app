import UIKit
import CoreImage

struct TextOverlayFactory {
    static func make(text: String, videoSize: CGSize) -> CIImage? {
        let width = max(512, Int(videoSize.width * 0.55))
        let height = max(160, Int(CGFloat(width) * 0.28))
        let format = UIGraphicsImageRendererFormat()
        format.scale = 1
        format.opaque = false
        let renderer = UIGraphicsImageRenderer(size: CGSize(width: CGFloat(width), height: CGFloat(height)), format: format)
        let image = renderer.image { ctx in
            UIColor.clear.setFill()
            ctx.fill(CGRect(x: 0, y: 0, width: CGFloat(width), height: CGFloat(height)))

            let paragraph = NSMutableParagraphStyle()
            paragraph.alignment = .center
            paragraph.lineBreakMode = .byWordWrapping
            let fontSize = CGFloat(width) * 0.095
            let attrs: [NSAttributedString.Key: Any] = [
                .font: UIFont.systemFont(ofSize: fontSize, weight: .heavy),
                .foregroundColor: UIColor.white,
                .paragraphStyle: paragraph,
                .strokeColor: UIColor.black,
                .strokeWidth: -3.0
            ]
            let rect = CGRect(x: 24, y: 20, width: CGFloat(width - 48), height: CGFloat(height - 40))
            text.draw(with: rect, options: [.usesLineFragmentOrigin, .usesFontLeading], attributes: attrs, context: nil)
        }
        guard let cg = image.cgImage else { return nil }
        return CIImage(cgImage: cg)
    }
}
