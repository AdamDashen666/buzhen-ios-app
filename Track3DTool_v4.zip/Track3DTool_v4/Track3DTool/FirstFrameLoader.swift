import UIKit
import AVFoundation

struct FirstFrameLoader {
    static func load(url: URL) async throws -> UIImage {
        try await Task.detached(priority: .userInitiated) {
            let asset = AVAsset(url: url)
            let generator = AVAssetImageGenerator(asset: asset)
            generator.appliesPreferredTrackTransform = false // Keep coordinates aligned with AVAssetReader pixel buffers.
            generator.maximumSize = CGSize(width: 1920, height: 1920)
            let cg = try generator.copyCGImage(at: .zero, actualTime: nil)
            return UIImage(cgImage: cg)
        }.value
    }
}
