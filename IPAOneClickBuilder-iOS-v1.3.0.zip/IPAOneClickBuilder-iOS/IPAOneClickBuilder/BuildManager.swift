import Foundation
import SwiftUI

@MainActor
final class BuildManager: ObservableObject {
    @Published var settings: BuilderSettings = SavedSettingsStore.load()
    @Published var githubToken: String = KeychainStore.loadToken()
    @Published var selectedFileURL: URL?
    @Published var phase: BuildPhase = .idle
    @Published var progress: Double = 0
    @Published var logs: [BuildLogEntry] = []
    @Published var downloadedIPAURL: URL?
    @Published var downloadedReportURL: URL?
    @Published var downloadedLogsURL: URL?
    @Published var downloadedArtifactURLs: [URL] = []
    @Published var outputURLs: [URL] = []
    @Published var activeRunURL: URL?
    @Published var isRunning = false

    private let temporaryTagPrefix = "ipa-builder-upload-"
    private let githubZipHardLimitBytes = 95 * 1024 * 1024

    var canStart: Bool {
        !isRunning &&
        selectedFileURL != nil &&
        !githubToken.trimmed.isEmpty &&
        !settings.owner.trimmed.isEmpty &&
        !settings.repo.trimmed.isEmpty &&
        !settings.branch.trimmed.isEmpty &&
        (!settings.workflowIdentifier.trimmed.isEmpty || parseRunID(from: settings.referenceRunURL) != nil)
    }

    func saveSettings() {
        SavedSettingsStore.save(settings)
        try? KeychainStore.saveToken(githubToken)
    }

    func refreshOutputs() {
        do {
            let directory = try outputsDirectory()
            try migrateLegacyOutputsIfNeeded(to: directory)
            let files = try FileManager.default.contentsOfDirectory(
                at: directory,
                includingPropertiesForKeys: [.contentModificationDateKey, .fileSizeKey],
                options: [.skipsHiddenFiles]
            )
            outputURLs = files
                .filter { !$0.hasDirectoryPath }
                .sorted { lhs, rhs in
                    let lDate = (try? lhs.resourceValues(forKeys: [.contentModificationDateKey]).contentModificationDate) ?? .distantPast
                    let rDate = (try? rhs.resourceValues(forKeys: [.contentModificationDateKey]).contentModificationDate) ?? .distantPast
                    return lDate > rDate
                }
        } catch {
            append("刷新输出目录失败：\(error.localizedDescription)")
        }
    }

    func clearLocalOutputs() {
        do {
            let directory = try outputsDirectory()
            let files = try FileManager.default.contentsOfDirectory(at: directory, includingPropertiesForKeys: nil, options: [.skipsHiddenFiles])
            for file in files where !file.hasDirectoryPath {
                try FileManager.default.removeItem(at: file)
            }
            outputURLs.removeAll()
            downloadedIPAURL = nil
            downloadedReportURL = nil
            downloadedLogsURL = nil
            downloadedArtifactURLs.removeAll()
            append("已清空本地输出目录。")
        } catch {
            append("清空输出目录失败：\(error.localizedDescription)")
        }
    }

    func startBuild() async {
        guard canStart, let fileURL = selectedFileURL else {
            append("请先选择 ZIP，并填好 GitHub Token、仓库、分支，以及 workflow id/文件名或参考 run 链接。")
            return
        }

        saveSettings()
        isRunning = true
        phase = .preparing
        downloadedIPAURL = nil
        downloadedReportURL = nil
        downloadedLogsURL = nil
        downloadedArtifactURLs.removeAll()
        refreshOutputs()
        activeRunURL = nil
        logs.removeAll()
        progress = 0

        let token = githubToken.trimmed
        let api = GitHubAPI(token: token)
        let owner = settings.owner.trimmed
        let repo = settings.repo.trimmed
        let branch = settings.branch.trimmed
        let dispatchDate = Date().addingTimeInterval(-10)
        var uploadedZipPath: String?
        var uploadedZipSHA: String?
        var finishedRun: GitHubWorkflowRun?

        do {
            try validateSelectedFile(fileURL)
            progress = 0.05
            append("目标仓库：\(owner)/\(repo)")
            append("准备使用你给的 workflow：\(settings.referenceRunURL.trimmed.isEmpty ? settings.workflowIdentifier.trimmed : settings.referenceRunURL.trimmed)")

            let workflowIdentifier = try await resolveWorkflowIdentifier(api: api, owner: owner, repo: repo)
            append("已锁定 workflow：\(workflowIdentifier)")
            progress = 0.12

            if settings.deletePreviousBuildArtifacts {
                phase = .cleaning
                append("清理旧 Built-IPA / Build-Diagnostics artifacts...")
                await deletePreviousBuildArtifacts(api: api, owner: owner, repo: repo)
            }

            if settings.useReleaseUploadMode {
                try await startReleaseModeBuild(api: api, owner: owner, repo: repo, branch: branch, fileURL: fileURL)
                isRunning = false
                return
            }

            if settings.uploadSourceZipToRepoRoot {
                phase = .uploading
                if settings.deletePreviousRootZipsBeforeUpload {
                    append("删除仓库根目录旧 zip...")
                    try await deleteRootZipFiles(api: api, owner: owner, repo: repo, branch: branch, except: nil)
                }

                let uploadResult = try await uploadZipToRepoRoot(api: api, owner: owner, repo: repo, branch: branch, fileURL: fileURL)
                uploadedZipPath = uploadResult.path
                uploadedZipSHA = uploadResult.sha
                append("ZIP 已提交到仓库根目录：\(uploadResult.path)")
                progress = 0.32
            }

            phase = .dispatching
            append("触发 GitHub Actions...")
            try await api.dispatchWorkflow(owner: owner, repo: repo, workflowIdentifier: workflowIdentifier, branch: branch)
            progress = 0.42

            if settings.deleteUploadedZipAfterDispatch, let path = uploadedZipPath, let sha = uploadedZipSHA {
                append("已触发，删除刚上传的 ZIP，保持仓库干净：\(path)")
                do {
                    try await api.deleteContentFile(owner: owner, repo: repo, path: path, sha: sha, branch: branch, message: "Clean source zip after dispatch")
                } catch {
                    append("删除刚上传 ZIP 失败，但不影响已触发的构建：\(error.localizedDescription)")
                }
            }

            phase = .building
            append("开始等待新的 workflow run...")
            finishedRun = try await pollWorkflow(api: api, owner: owner, repo: repo, workflowIdentifier: workflowIdentifier, branch: branch, after: dispatchDate)
            progress = 0.72

            guard let finishedRun else { throw BuildError.timeout }
            if finishedRun.conclusion == "success" {
                append("GitHub Actions 构建成功。")
                if settings.downloadArtifactsAfterBuild {
                    phase = .downloading
                    try await downloadArtifacts(api: api, owner: owner, repo: repo, runID: finishedRun.id, requireIPA: true)
                }
                phase = .finished
                progress = 1
                refreshOutputs()
                append("完成。IPA artifact / diagnostics 已保存到 Documents/IPABuilderOutputs。可在输出文件区域直接分享/保存。")
            } else {
                throw BuildError.workflowFailed(finishedRun.conclusion ?? "unknown", runID: finishedRun.id)
            }
        } catch {
            phase = .failed
            append("失败：\(error.localizedDescription)")

            let runID: Int64? = {
                if let finishedRun { return finishedRun.id }
                return extractRunIDFromError(error)
            }()

            if let runID {
                await autoDownloadFailureLogs(api: api, owner: owner, repo: repo, runID: runID)
            }
        }

        isRunning = false
    }

    private func validateSelectedFile(_ url: URL) throws {
        let ext = url.pathExtension.lowercased()
        guard ext == "zip" else { throw BuildError.needZip }

        let attributes = try? FileManager.default.attributesOfItem(atPath: url.path)
        if let size = attributes?[.size] as? NSNumber,
           size.intValue > githubZipHardLimitBytes,
           settings.uploadSourceZipToRepoRoot {
            throw BuildError.zipTooLargeForContentsAPI(size.intValue)
        }
    }

    private func resolveWorkflowIdentifier(api: GitHubAPI, owner: String, repo: String) async throws -> String {
        let manual = settings.workflowIdentifier.trimmed
        if !manual.isEmpty { return manual }

        guard let runID = parseRunID(from: settings.referenceRunURL) else {
            throw BuildError.noWorkflowIdentifier
        }

        let run = try await api.getWorkflowRun(owner: owner, repo: repo, runID: runID)
        if let workflowID = run.workflowID {
            let workflow = try? await api.getWorkflow(owner: owner, repo: repo, workflowID: workflowID)
            if let workflowName = workflow?.name { append("参考 run 对应 workflow：\(workflowName)") }
            if let workflowPath = workflow?.path { append("workflow 文件：\(workflowPath)") }
            return String(workflowID)
        }

        if let path = run.path?.split(separator: "/").last.map(String.init) {
            return path
        }

        throw BuildError.noWorkflowIdentifier
    }

    private func uploadZipToRepoRoot(api: GitHubAPI, owner: String, repo: String, branch: String, fileURL: URL) async throws -> (path: String, sha: String?) {
        let originalName = sanitizeFilename(fileURL.lastPathComponent)
        let timestamp = timestampForFilename()
        let prefix = sanitizeFilename(settings.uploadedZipPrefix.trimmed.isEmpty ? "zzzz-IPAOneClickUpload" : settings.uploadedZipPrefix.trimmed)
        let uploadName = "\(prefix)-\(timestamp)-\(originalName)"
        let data = try Data(contentsOf: fileURL)
        let rootFiles = try await api.listDirectory(owner: owner, repo: repo, branch: branch)
        let existingSHA = rootFiles.first(where: { $0.path == uploadName })?.sha
        let response = try await api.uploadOrUpdateFile(
            owner: owner,
            repo: repo,
            path: uploadName,
            branch: branch,
            data: data,
            message: "Upload source zip for IPA one-click build",
            existingSHA: existingSHA
        )
        return (uploadName, response.content?.sha ?? existingSHA)
    }

    private func deleteRootZipFiles(api: GitHubAPI, owner: String, repo: String, branch: String, except: String?) async throws {
        let rootFiles = try await api.listDirectory(owner: owner, repo: repo, branch: branch)
        for item in rootFiles where item.type == "file" && item.name.lowercased().hasSuffix(".zip") && item.path != except {
            append("删除旧 zip：\(item.path)")
            try await api.deleteContentFile(owner: owner, repo: repo, path: item.path, sha: item.sha, branch: branch, message: "Clean old source zip")
        }
    }

    private func deletePreviousBuildArtifacts(api: GitHubAPI, owner: String, repo: String) async {
        do {
            let artifacts = try await api.listRepositoryArtifacts(owner: owner, repo: repo)
            let targets = artifacts.filter { artifact in
                let lower = artifact.name.lowercased()
                return lower.contains("built-ipa") || lower.contains("build-diagnostics") || lower.contains("diagnostic")
            }
            for artifact in targets {
                append("删除旧 artifact：\(artifact.name)")
                await api.deleteArtifact(owner: owner, repo: repo, artifactID: artifact.id)
            }
        } catch {
            append("清理旧 artifact 失败：\(error.localizedDescription)")
        }
    }

    private func pollWorkflow(api: GitHubAPI, owner: String, repo: String, workflowIdentifier: String, branch: String, after dispatchDate: Date) async throws -> GitHubWorkflowRun {
        var matchedRunID: Int64?
        for attempt in 1...240 {
            try Task.checkCancellation()
            let runs = try await api.listWorkflowRuns(owner: owner, repo: repo, workflowIdentifier: workflowIdentifier, branch: branch)
            let newRuns = runs.filter { run in
                guard let created = run.createdDate else { return true }
                return created >= dispatchDate
            }
            let matched = newRuns.sorted { lhs, rhs in
                (lhs.createdDate ?? .distantPast) > (rhs.createdDate ?? .distantPast)
            }.first

            if let run = matched {
                if matchedRunID != run.id {
                    matchedRunID = run.id
                    if let html = run.htmlURL, let url = URL(string: html) { activeRunURL = url }
                    append("找到新构建任务 #\(run.id)：\(run.readableStatus)")
                }
                progress = min(0.70, 0.42 + Double(attempt) * 0.002)
                if attempt % 6 == 0 {
                    append("GitHub 状态：\(run.readableStatus)")
                }
                if run.status == "completed" {
                    return run
                }
            } else if attempt % 6 == 0 {
                append("还没看到新的 workflow run，继续等待...")
            }
            try await Task.sleep(nanoseconds: 5_000_000_000)
        }
        throw BuildError.timeout
    }

    private func downloadArtifacts(api: GitHubAPI, owner: String, repo: String, runID: Int64, requireIPA: Bool) async throws {
        append("查找 workflow artifacts...")
        let artifacts = try await api.listWorkflowRunArtifacts(owner: owner, repo: repo, runID: runID)
        if artifacts.isEmpty { throw BuildError.noArtifacts(runID) }

        let sorted = artifacts.sorted { lhs, rhs in
            priority(forArtifactName: lhs.name) < priority(forArtifactName: rhs.name)
        }

        var foundIPAArtifact = false
        for artifact in sorted {
            let lower = artifact.name.lowercased()
            let shouldDownload = lower.contains("ipa") || lower.contains("diagnostic") || lower.contains("log") || lower.contains("report") || settings.downloadDiagnosticsArtifact
            guard shouldDownload else { continue }

            let zipName = uniqueDownloadName(base: "\(artifact.name).zip")
            let url = try await api.downloadArtifact(owner: owner, repo: repo, artifact: artifact, destinationName: zipName)
            registerOutput(url)
            append("已下载 artifact：\(url.lastPathComponent)")

            if lower.contains("ipa") {
                downloadedIPAURL = url
                foundIPAArtifact = true
            } else if lower.contains("diagnostic") || lower.contains("report") || lower.contains("log") {
                downloadedReportURL = url
            }
        }

        if requireIPA && !foundIPAArtifact {
            throw BuildError.noIPAArtifact(artifacts.map(\.name).joined(separator: ", "))
        }
        progress = 0.9
    }

    private func autoDownloadFailureLogs(api: GitHubAPI, owner: String, repo: String, runID: Int64) async {
        phase = .downloading
        append("自动下载失败日志，run #\(runID)...")

        do {
            let jobs = try await api.listWorkflowRunJobs(owner: owner, repo: repo, runID: runID)
            for job in jobs {
                let status = job.conclusion ?? job.status ?? "unknown"
                append("Job：\(job.name) → \(status)")
                if let failedStep = job.steps?.first(where: { ($0.conclusion ?? "") == "failure" }) {
                    append("失败步骤：\(failedStep.name)")
                }
            }
        } catch {
            append("读取 job 摘要失败：\(error.localizedDescription)")
        }

        if settings.downloadLogsOnFailure {
            do {
                let logsURL = try await api.downloadWorkflowRunLogs(owner: owner, repo: repo, runID: runID, destinationName: uniqueDownloadName(base: "GitHub-Run-\(runID)-Logs.zip"))
                downloadedLogsURL = logsURL
                registerOutput(logsURL)
                append("失败日志已下载：\(logsURL.lastPathComponent)")
            } catch {
                append("下载失败日志失败：\(error.localizedDescription)")
            }
        }

        do {
            try await downloadArtifacts(api: api, owner: owner, repo: repo, runID: runID, requireIPA: false)
        } catch {
            append("失败时没有可下载的 diagnostics artifact：\(error.localizedDescription)")
        }

        if let summaryURL = saveLocalText(name: uniqueDownloadName(base: "Failure-Summary-\(runID).txt"), text: plainLogText()) {
            downloadedReportURL = downloadedReportURL ?? summaryURL
            registerOutput(summaryURL)
            append("失败摘要已保存：\(summaryURL.lastPathComponent)")
        }
    }

    // MARK: - Old generic Release workflow mode

    private func startReleaseModeBuild(api: GitHubAPI, owner: String, repo: String, branch: String, fileURL: URL) async throws {
        let workflowFile = settings.workflowFile.trimmed
        let tag = temporaryTagPrefix + UUID().uuidString.lowercased()
        let sourceAssetName = "source.zip"
        var createdRelease: GitHubRelease?

        phase = .uploading
        append("兼容模式：创建临时 Release：\(tag)")
        let release = try await api.createTemporaryRelease(owner: owner, repo: repo, tag: tag)
        createdRelease = release
        _ = try await api.uploadReleaseAsset(uploadURL: release.uploadURL, fileURL: fileURL, assetName: sourceAssetName)
        progress = 0.35

        phase = .dispatching
        let inputs = workflowInputs(uploadTag: tag, sourceAssetName: sourceAssetName)
        try await api.dispatchWorkflow(owner: owner, repo: repo, workflowIdentifier: workflowFile, branch: branch, inputs: inputs)
        progress = 0.45

        phase = .building
        let run = try await pollWorkflow(api: api, owner: owner, repo: repo, workflowIdentifier: workflowFile, branch: branch, after: Date().addingTimeInterval(-10))
        if run.conclusion != "success" { throw BuildError.workflowFailed(run.conclusion ?? "unknown", runID: run.id) }

        phase = .downloading
        let finishedRelease = try await waitForReleaseAssets(api: api, owner: owner, repo: repo, tag: tag)
        guard let assets = finishedRelease.assets else { throw BuildError.noAssets }
        guard let ipa = assets.first(where: { $0.name.lowercased().hasSuffix(".ipa") }) else {
            throw BuildError.noIPAAsset(assets.map(\.name).joined(separator: ", "))
        }
        downloadedIPAURL = try await api.downloadReleaseAsset(owner: owner, repo: repo, asset: ipa, destinationName: uniqueDownloadName(base: ipa.name))
        if let downloadedIPAURL { registerOutput(downloadedIPAURL) }
        append("IPA 已下载：\(downloadedIPAURL?.lastPathComponent ?? "")")

        if settings.deleteTemporaryReleaseAfterDownload, let release = createdRelease {
            phase = .cleaning
            await api.deleteReleaseAndTag(owner: owner, repo: repo, releaseID: release.id, tag: tag)
        }

        phase = .finished
        progress = 1
        append("兼容模式完成。")
    }

    private func workflowInputs(uploadTag: String, sourceAssetName: String) -> [String: String] {
        [
            "upload_tag": uploadTag,
            "source_asset_name": sourceAssetName,
            "scheme": settings.scheme.trimmed,
            "configuration": settings.configuration.trimmed.isEmpty ? "Release" : settings.configuration.trimmed,
            "export_method": settings.exportMethod.rawValue,
            "project_path": settings.projectPath.trimmed,
            "workspace_path": settings.workspacePath.trimmed,
            "team_id": settings.teamID.trimmed
        ]
    }

    private func waitForReleaseAssets(api: GitHubAPI, owner: String, repo: String, tag: String) async throws -> GitHubRelease {
        for attempt in 1...60 {
            try Task.checkCancellation()
            let release = try await api.getReleaseByTag(owner: owner, repo: repo, tag: tag)
            if let assets = release.assets, assets.contains(where: { $0.name.lowercased().hasSuffix(".ipa") }) {
                return release
            }
            if attempt % 5 == 0 { append("等待 IPA 上传到 Release...") }
            try await Task.sleep(nanoseconds: 3_000_000_000)
        }
        throw BuildError.noIPAAsset("未在 Release assets 中找到 .ipa")
    }

    // MARK: - Utilities

    private func parseRunID(from text: String) -> Int64? {
        let parts = text.split(separator: "/")
        guard let index = parts.firstIndex(of: "runs"), parts.indices.contains(parts.index(after: index)) else { return nil }
        return Int64(parts[parts.index(after: index)])
    }

    private func extractRunIDFromError(_ error: Error) -> Int64? {
        if case BuildError.workflowFailed(_, let runID) = error { return runID }
        return nil
    }

    private func priority(forArtifactName name: String) -> Int {
        let lower = name.lowercased()
        if lower.contains("ipa") { return 0 }
        if lower.contains("diagnostic") { return 1 }
        if lower.contains("log") { return 2 }
        return 9
    }

    private func sanitizeFilename(_ name: String) -> String {
        let allowed = CharacterSet(charactersIn: "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789._-")
        let scalars = name.unicodeScalars.map { allowed.contains($0) ? Character($0) : Character("-") }
        let result = String(scalars)
        return result.isEmpty ? "Source.zip" : result
    }

    private func timestampForFilename() -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyyMMdd-HHmmss"
        formatter.locale = Locale(identifier: "en_US_POSIX")
        return formatter.string(from: Date())
    }

    private func uniqueDownloadName(base: String) -> String {
        let timestamp = ISO8601DateFormatter().string(from: Date()).replacingOccurrences(of: ":", with: "-")
        let name = base.isEmpty ? "IPAOneClickBuilder-Result.zip" : base
        return "\(timestamp)-\(name)"
    }

    private func saveLocalText(name: String, text: String) -> URL? {
        do {
            let directory = try outputsDirectory()
            let destination = directory.appendingPathComponent(name)
            try text.data(using: .utf8)?.write(to: destination, options: .atomic)
            return destination
        } catch {
            append("保存本地摘要失败：\(error.localizedDescription)")
            return nil
        }
    }

    private func plainLogText() -> String {
        logs.map { entry in
            "[\(entry.date)] \(entry.message)"
        }.joined(separator: "\n")
    }

    private func registerOutput(_ url: URL) {
        if !downloadedArtifactURLs.contains(url) {
            downloadedArtifactURLs.append(url)
        }
        refreshOutputs()
    }

    private func outputsDirectory() throws -> URL {
        let documents = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let directory = documents.appendingPathComponent("IPABuilderOutputs", isDirectory: true)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        return directory
    }

    private func migrateLegacyOutputsIfNeeded(to directory: URL) throws {
        let documents = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let legacyFiles = try FileManager.default.contentsOfDirectory(at: documents, includingPropertiesForKeys: nil, options: [.skipsHiddenFiles])
        for file in legacyFiles where !file.hasDirectoryPath && isOutputLike(file) {
            let destination = directory.appendingPathComponent(file.lastPathComponent)
            if !FileManager.default.fileExists(atPath: destination.path) {
                try FileManager.default.moveItem(at: file, to: destination)
            }
        }
    }

    private func isOutputLike(_ url: URL) -> Bool {
        let name = url.lastPathComponent.lowercased()
        return name.contains("built-ipa") ||
            name.contains("build-diagnostics") ||
            name.contains("diagnostic") ||
            name.contains("github-run") ||
            name.contains("failure-summary") ||
            name.hasSuffix(".ipa")
    }

    private func append(_ message: String) {
        logs.append(BuildLogEntry(message: message))
    }
}

private extension String {
    var trimmed: String { trimmingCharacters(in: .whitespacesAndNewlines) }
}

enum BuildError: LocalizedError {
    case needZip
    case timeout
    case noAssets
    case noArtifacts(Int64)
    case noIPAAsset(String)
    case noIPAArtifact(String)
    case workflowFailed(String, runID: Int64)
    case noWorkflowIdentifier
    case zipTooLargeForContentsAPI(Int)

    var errorDescription: String? {
        switch self {
        case .needZip:
            return "当前版本请先选择 .zip。把 Xcode 项目文件夹压缩后再导入。"
        case .timeout:
            return "等待 GitHub Actions 超时。可以打开 Actions 页面查看是否还在运行。"
        case .noAssets:
            return "Release 没有 assets。"
        case .noArtifacts(let runID):
            return "workflow run #\(runID) 没有 artifacts。"
        case .noIPAAsset(let assets):
            return "没有找到 .ipa。当前 assets：\(assets)"
        case .noIPAArtifact(let artifacts):
            return "没有找到 IPA artifact。当前 artifacts：\(artifacts)"
        case .workflowFailed(let conclusion, let runID):
            return "GitHub Actions 失败：\(conclusion)，run #\(runID)。正在自动下载日志。"
        case .noWorkflowIdentifier:
            return "没有 workflow id/文件名，也无法从参考 run 链接解析。"
        case .zipTooLargeForContentsAPI(let size):
            let mb = Double(size) / 1024.0 / 1024.0
            return String(format: "ZIP 太大：%.1f MB。GitHub Contents API 不适合超过约 95 MB 的文件，请改用 Release 上传模式或压缩项目。", mb)
        }
    }
}
