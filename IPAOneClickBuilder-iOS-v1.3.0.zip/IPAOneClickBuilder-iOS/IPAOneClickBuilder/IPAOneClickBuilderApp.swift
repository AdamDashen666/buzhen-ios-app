import SwiftUI

@main
struct IPAOneClickBuilderApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
