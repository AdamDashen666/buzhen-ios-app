import Foundation

struct BuilderSettings: Codable, Equatable {
    var owner: String = "AdamDashen666"
    var repo: String = "buzhen-ios-app"
    var branch: String = "main"

    /// 可以填 workflow 文件名、workflow id，也可以留空让 App 从 referenceRunURL 自动解析。
    var workflowIdentifier: String = ""
    var referenceRunURL: String = "https://github.com/AdamDashen666/buzhen-ios-app/actions/runs/27696458167/workflow"

    /// 你的现有 workflow 会在仓库根目录寻找最新 zip，所以默认把选中的 zip 提交到仓库根目录。
    var uploadSourceZipToRepoRoot: Bool = true
    var uploadedZipPrefix: String = "zzzz-IPAOneClickUpload"
    var deletePreviousRootZipsBeforeUpload: Bool = false
    var deleteUploadedZipAfterDispatch: Bool = true

    /// 成功时下载 Built-IPA / Diagnostics artifacts；失败时自动下载 logs zip。
    var downloadArtifactsAfterBuild: Bool = true
    var downloadDiagnosticsArtifact: Bool = true
    var downloadLogsOnFailure: Bool = true
    var deletePreviousBuildArtifacts: Bool = false

    /// 兼容旧版 Release-asset workflow 的字段，默认不使用。
    var useReleaseUploadMode: Bool = false
    var workflowFile: String = "ios-ipa-builder.yml"
    var scheme: String = ""
    var configuration: String = "Release"
    var exportMethod: ExportMethod = .adHoc
    var projectPath: String = ""
    var workspacePath: String = ""
    var teamID: String = ""
    var deleteTemporaryReleaseAfterDownload: Bool = false
    var deletePreviousTemporaryReleases: Bool = true

    var repoSlug: String {
        "\(owner.trimmingCharacters(in: .whitespacesAndNewlines))/\(repo.trimmingCharacters(in: .whitespacesAndNewlines))"
    }
}

enum ExportMethod: String, Codable, CaseIterable, Identifiable {
    case development = "development"
    case adHoc = "ad-hoc"
    case appStore = "app-store"
    case enterprise = "enterprise"

    var id: String { rawValue }

    var title: String {
        switch self {
        case .development: return "Development"
        case .adHoc: return "Ad Hoc"
        case .appStore: return "App Store"
        case .enterprise: return "Enterprise"
        }
    }
}

struct BuildLogEntry: Identifiable, Equatable {
    let id = UUID()
    let date = Date()
    let message: String
}

enum BuildPhase: String {
    case idle = "空闲"
    case preparing = "准备中"
    case cleaning = "清理中"
    case uploading = "上传中"
    case dispatching = "触发中"
    case building = "GitHub 打包中"
    case downloading = "下载中"
    case finished = "完成"
    case failed = "失败"
}

struct GitHubRelease: Decodable {
    let id: Int64
    let tagName: String
    let uploadURL: String
    let assets: [GitHubAsset]?

    enum CodingKeys: String, CodingKey {
        case id
        case tagName = "tag_name"
        case uploadURL = "upload_url"
        case assets
    }
}

struct GitHubAsset: Decodable, Identifiable, Equatable {
    let id: Int64
    let name: String
    let size: Int?
    let contentType: String?
    let browserDownloadURL: String?

    enum CodingKeys: String, CodingKey {
        case id, name, size
        case contentType = "content_type"
        case browserDownloadURL = "browser_download_url"
    }
}

struct GitHubWorkflowRunsResponse: Decodable {
    let workflowRuns: [GitHubWorkflowRun]

    enum CodingKeys: String, CodingKey {
        case workflowRuns = "workflow_runs"
    }
}

struct GitHubWorkflowRun: Decodable, Identifiable, Equatable {
    let id: Int64
    let name: String?
    let displayTitle: String?
    let status: String?
    let conclusion: String?
    let createdAt: String?
    let updatedAt: String?
    let htmlURL: String?

    enum CodingKeys: String, CodingKey {
        case id, name, status, conclusion
        case displayTitle = "display_title"
        case createdAt = "created_at"
        case updatedAt = "updated_at"
        case htmlURL = "html_url"
    }

    var readableStatus: String {
        if status == "completed" {
            return conclusion ?? "completed"
        }
        return status ?? "unknown"
    }

    var createdDate: Date? {
        guard let createdAt else { return nil }
        return ISO8601DateFormatter.githubFormatter.githubDate(from: createdAt)
    }
}

struct GitHubWorkflowRunDetail: Decodable {
    let id: Int64
    let workflowID: Int64?
    let name: String?
    let path: String?
    let status: String?
    let conclusion: String?
    let htmlURL: String?

    enum CodingKeys: String, CodingKey {
        case id, name, path, status, conclusion
        case workflowID = "workflow_id"
        case htmlURL = "html_url"
    }
}

struct GitHubWorkflow: Decodable {
    let id: Int64
    let name: String?
    let path: String?
    let state: String?
    let htmlURL: String?

    enum CodingKeys: String, CodingKey {
        case id, name, path, state
        case htmlURL = "html_url"
    }
}

struct GitHubArtifactsResponse: Decodable {
    let artifacts: [GitHubArtifact]
}

struct GitHubArtifact: Decodable, Identifiable, Equatable {
    let id: Int64
    let name: String
    let sizeInBytes: Int?
    let archiveDownloadURL: String?
    let expired: Bool?
    let createdAt: String?
    let expiresAt: String?

    enum CodingKeys: String, CodingKey {
        case id, name, expired
        case sizeInBytes = "size_in_bytes"
        case archiveDownloadURL = "archive_download_url"
        case createdAt = "created_at"
        case expiresAt = "expires_at"
    }
}

struct GitHubJobsResponse: Decodable {
    let jobs: [GitHubJob]
}

struct GitHubJob: Decodable, Identifiable, Equatable {
    let id: Int64
    let name: String
    let status: String?
    let conclusion: String?
    let htmlURL: String?
    let steps: [GitHubJobStep]?

    enum CodingKeys: String, CodingKey {
        case id, name, status, conclusion, steps
        case htmlURL = "html_url"
    }
}

struct GitHubJobStep: Decodable, Equatable {
    let name: String
    let status: String?
    let conclusion: String?
    let number: Int?
}

struct GitHubContentItem: Decodable, Identifiable, Equatable {
    let name: String
    let path: String
    let sha: String
    let type: String
    let size: Int?

    var id: String { path }
}

struct GitHubContentWriteResponse: Decodable {
    let content: WrittenContent?
    let commit: WrittenCommit?

    struct WrittenContent: Decodable {
        let path: String?
        let sha: String?
    }

    struct WrittenCommit: Decodable {
        let sha: String?
    }
}

struct SavedSettingsStore {
    static let key = "builder.settings.v2"

    static func load() -> BuilderSettings {
        guard let data = UserDefaults.standard.data(forKey: key),
              let decoded = try? JSONDecoder().decode(BuilderSettings.self, from: data) else {
            return BuilderSettings()
        }
        return decoded
    }

    static func save(_ settings: BuilderSettings) {
        guard let data = try? JSONEncoder().encode(settings) else { return }
        UserDefaults.standard.set(data, forKey: key)
    }
}

extension ISO8601DateFormatter {
    static let githubFormatter: ISO8601DateFormatter = {
        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        return formatter
    }()

    static let githubFormatterNoFraction: ISO8601DateFormatter = {
        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = [.withInternetDateTime]
        return formatter
    }()
}

extension ISO8601DateFormatter {
    func githubDate(from string: String) -> Date? {
        date(from: string) ?? ISO8601DateFormatter.githubFormatterNoFraction.date(from: string)
    }
}
