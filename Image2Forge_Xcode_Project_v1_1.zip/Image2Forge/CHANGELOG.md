# Changelog

## v1.1 - Build Fix

- 修复 `Image2Forge.xcodeproj/project.pbxproj` 里错误的双大括号，解决 Xcode 报 “project is damaged / parse error”。
- 新增共享 Scheme：`Image2Forge.xcscheme`，解决自动构建时 “No shared scheme found”。
- 给 `AppSettings.swift`、`HistoryStore.swift` 补充 `import Combine`，避免 `ObservableObject` / `@Published` 相关编译失败。
- 保留 v1.0 的 APIYI 默认 Base URL、模型刷新、4K 分辨率、文生图与参考图上传功能。

## v1.0

- 默认 Base URL: `https://api.apiyi.com/v1`
- 默认模型: `gpt-image-2-vip`
- 支持刷新模型 `/models`
- 支持文生图 `/images/generations`
- 支持图片编辑 `/images/edits`
- 支持 1K / 2K / 4K 尺寸预设与自定义尺寸
- 支持相册 / 文件上传参考图
- 支持历史记录、分享、保存到相册
