import Foundation
import AVFoundation
import CoreImage
import UIKit
import VideoToolbox

// v4 renderer:
// - Homography + RANSAC tracking for lower drift.
// - Optional original audio passthrough.
// - HEVC/HDR-priority export path with source color metadata copy when possible.
// - Plane-pose JSON export for AE / NodeVideo-style downstream workflows.

enum RenderError: LocalizedError {
    case missingVideoTrack
    case readerFailed
    case writerFailed
    case cannotCreateBuffer
    case invalidQuad
    case trackerInitFailed
    case audioCopyFailed

    var errorDescription: String? {
        switch self {
        case .missingVideoTrack: return "找不到视频轨道"
        case .readerFailed: return "读取视频失败"
        case .writerFailed: return "写入视频失败"
        case .cannotCreateBuffer: return "创建输出帧失败"
        case .invalidQuad: return "四点选择无效"
        case .trackerInitFailed: return "追踪初始化失败：选四点区域需要更清晰纹理"
        case .audioCopyFailed: return "音频复制失败"
        }
    }
}

struct VideoPlaneCompositor {
    static func render(
        inputURL: URL,
        normalizedQuad: [CGPoint],
        overlayText: String,
        quality: TrackingQuality,
        outputProfile: OutputProfile,
        preserveAudio: Bool,
        exportCameraSolve: Bool,
        progress: @escaping @Sendable (Double, String) -> Void
    ) async throws -> URL {
        try await Task.detached(priority: .userInitiated) {
            try renderSync(
                inputURL: inputURL,
                normalizedQuad: normalizedQuad,
                overlayText: overlayText,
                quality: quality,
                outputProfile: outputProfile,
                preserveAudio: preserveAudio,
                exportCameraSolve: exportCameraSolve,
                progress: progress
            )
        }.value
    }

    private static func renderSync(
        inputURL: URL,
        normalizedQuad: [CGPoint],
        overlayText: String,
        quality: TrackingQuality,
        outputProfile: OutputProfile,
        preserveAudio: Bool,
        exportCameraSolve: Bool,
        progress: @escaping @Sendable (Double, String) -> Void
    ) throws -> URL {
        guard normalizedQuad.count == 4 else { throw RenderError.invalidQuad }
        let asset = AVAsset(url: inputURL)
        guard let videoTrack = asset.tracks(withMediaType: .video).first else { throw RenderError.missingVideoTrack }

        let naturalSize = videoTrack.naturalSize
        let width = max(2, Int(abs(naturalSize.width)))
        let height = max(2, Int(abs(naturalSize.height)))
        let videoSize = CGSize(width: CGFloat(width), height: CGFloat(height))
        let durationSeconds = max(0.1, asset.duration.seconds.isFinite ? asset.duration.seconds : 0.1)
        let outputURL = try FileStore.outputURL(prefix: "tracked_wall_text_v4", ext: outputProfile.fileExtension)
        if FileManager.default.fileExists(atPath: outputURL.path) {
            try FileManager.default.removeItem(at: outputURL)
        }

        let reader = try AVAssetReader(asset: asset)
        let readerOutput = AVAssetReaderTrackOutput(track: videoTrack, outputSettings: [
            kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA
        ])
        readerOutput.alwaysCopiesSampleData = false
        guard reader.canAdd(readerOutput) else { throw RenderError.readerFailed }
        reader.add(readerOutput)

        let fileType: AVFileType = outputProfile == .hevcHDRPriority ? .mov : .mp4
        let writer = try AVAssetWriter(outputURL: outputURL, fileType: fileType)
        let videoSettings = makeVideoSettings(videoTrack: videoTrack, width: width, height: height, outputProfile: outputProfile)
        let writerInput = AVAssetWriterInput(mediaType: .video, outputSettings: videoSettings)
        writerInput.expectsMediaDataInRealTime = false
        writerInput.transform = videoTrack.preferredTransform

        let outputPixelFormat: OSType = outputProfile == .hevcHDRPriority ? kCVPixelFormatType_64RGBAHalf : kCVPixelFormatType_32BGRA
        let adaptor = AVAssetWriterInputPixelBufferAdaptor(
            assetWriterInput: writerInput,
            sourcePixelBufferAttributes: [
                kCVPixelBufferPixelFormatTypeKey as String: outputPixelFormat,
                kCVPixelBufferWidthKey as String: width,
                kCVPixelBufferHeightKey as String: height,
                kCVPixelBufferIOSurfacePropertiesKey as String: [:]
            ]
        )
        guard writer.canAdd(writerInput) else { throw RenderError.writerFailed }
        writer.add(writerInput)

        var audioOutput: AVAssetReaderTrackOutput?
        var audioInput: AVAssetWriterInput?
        if preserveAudio, let audioTrack = asset.tracks(withMediaType: .audio).first {
            let out = AVAssetReaderTrackOutput(track: audioTrack, outputSettings: nil)
            out.alwaysCopiesSampleData = false
            let input = AVAssetWriterInput(mediaType: .audio, outputSettings: nil)
            input.expectsMediaDataInRealTime = false
            if reader.canAdd(out), writer.canAdd(input) {
                reader.add(out)
                writer.add(input)
                audioOutput = out
                audioInput = input
            }
        }

        guard reader.startReading() else { throw reader.error ?? RenderError.readerFailed }
        guard writer.startWriting() else { throw writer.error ?? RenderError.writerFailed }
        writer.startSession(atSourceTime: .zero)

        let workingColorSpace: CGColorSpace = outputProfile == .hevcHDRPriority
            ? (CGColorSpace(name: CGColorSpace.extendedLinearDisplayP3) ?? CGColorSpaceCreateDeviceRGB())
            : CGColorSpaceCreateDeviceRGB()
        let ciContext = CIContext(options: [.cacheIntermediates: false, .workingColorSpace: workingColorSpace])
        let videoExtent = CGRect(x: 0, y: 0, width: CGFloat(width), height: CGFloat(height))
        guard let overlay = TextOverlayFactory.make(text: overlayText, videoSize: videoSize) else {
            throw RenderError.writerFailed
        }

        var tracker: PatchPlaneTracker?
        var frameIndex = 0
        var trackingRecords: [TrackedFrame] = []
        var audioWasCopied = false

        while let sample = readerOutput.copyNextSampleBuffer() {
            while !writerInput.isReadyForMoreMediaData {
                Thread.sleep(forTimeInterval: 0.002)
            }

            guard let srcBuffer = CMSampleBufferGetImageBuffer(sample) else { continue }
            let time = CMSampleBufferGetPresentationTimeStamp(sample)
            let timeSeconds = time.seconds.isFinite ? time.seconds : 0

            if frameIndex == 0 {
                progress(0.01, "初始化 Homography/RANSAC 追踪点...")
            }

            guard let gray = ImageGray.from(pixelBuffer: srcBuffer, maxWidth: quality.maxTrackWidth) else { continue }
            let selectedQuadPixels = normalizedQuad.map { CGPoint(x: $0.x * CGFloat(width), y: $0.y * CGFloat(height)) }

            if tracker == nil {
                tracker = PatchPlaneTracker(initialImage: gray, quadInOriginalPixels: selectedQuadPixels, quality: quality)
                if tracker == nil { throw RenderError.trackerInitFailed }
            }

            let tracked = tracker?.track(nextImage: gray) ?? PatchTrackResult(quadOriginalPixels: selectedQuadPixels, confidence: 0, inlierCount: 0, status: "未初始化")
            let confidence = tracked.confidence
            let currentQuad = clampQuad(tracked.quadOriginalPixels, width: width, height: height)
            let pose = exportCameraSolve ? PlanePoseSolver.solve(imageQuad: currentQuad, videoSize: videoSize) : nil
            trackingRecords.append(TrackedFrame(
                frameIndex: frameIndex,
                timeSeconds: timeSeconds,
                quad: currentQuad.map(CGPointCodable.init),
                confidence: confidence,
                inlierCount: tracked.inlierCount,
                trackerStatus: tracked.status,
                planePose: pose
            ))

            let sourceImage = CIImage(cvPixelBuffer: srcBuffer).cropped(to: videoExtent)
            let warpedOverlay = warp(overlay: overlay, to: currentQuad, frameHeight: CGFloat(height))
            let composited = warpedOverlay.composited(over: sourceImage).cropped(to: videoExtent)

            guard let pool = adaptor.pixelBufferPool else { throw RenderError.cannotCreateBuffer }
            var outBufferOptional: CVPixelBuffer?
            CVPixelBufferPoolCreatePixelBuffer(nil, pool, &outBufferOptional)
            guard let outBuffer = outBufferOptional else { throw RenderError.cannotCreateBuffer }

            ciContext.render(composited, to: outBuffer, bounds: videoExtent, colorSpace: workingColorSpace)
            if !adaptor.append(outBuffer, withPresentationTime: time) {
                throw writer.error ?? RenderError.writerFailed
            }

            frameIndex += 1
            if frameIndex % 10 == 0 {
                let p = min(0.93, max(0.01, timeSeconds / durationSeconds * 0.93))
                progress(p, "第 \(frameIndex) 帧：\(tracked.status)，置信度 \(String(format: "%.2f", confidence))，内点 \(tracked.inlierCount)")
            }
        }

        writerInput.markAsFinished()

        if let audioOutput, let audioInput {
            progress(0.96, "正在保留原视频音频...")
            while let audioSample = audioOutput.copyNextSampleBuffer() {
                while !audioInput.isReadyForMoreMediaData {
                    Thread.sleep(forTimeInterval: 0.002)
                }
                if !audioInput.append(audioSample) {
                    throw writer.error ?? RenderError.audioCopyFailed
                }
                audioWasCopied = true
            }
            audioInput.markAsFinished()
        }

        writer.finishWriting {}
        while writer.status == .writing { Thread.sleep(forTimeInterval: 0.03) }
        if writer.status != .completed { throw writer.error ?? RenderError.writerFailed }
        if reader.status == .failed { throw reader.error ?? RenderError.readerFailed }

        try exportTrackingJSON(records: trackingRecords, beside: outputURL)
        let audioText = preserveAudio ? (audioWasCopied ? "，已保留音频" : "，未检测到可复制音频") : ""
        let hdrText = outputProfile == .hevcHDRPriority ? "，HEVC/HDR 优先" : ""
        progress(1.0, "导出完成\(audioText)\(hdrText)")
        return outputURL
    }

    private static func makeVideoSettings(videoTrack: AVAssetTrack, width: Int, height: Int, outputProfile: OutputProfile) -> [String: Any] {
        let bitrate = max(12_000_000, width * height * (outputProfile == .hevcHDRPriority ? 10 : 7))
        var settings: [String: Any] = [
            AVVideoCodecKey: outputProfile == .hevcHDRPriority ? AVVideoCodecType.hevc : AVVideoCodecType.h264,
            AVVideoWidthKey: width,
            AVVideoHeightKey: height,
            AVVideoCompressionPropertiesKey: outputProfile == .hevcHDRPriority ? [
                AVVideoAverageBitRateKey: bitrate,
                AVVideoProfileLevelKey: kVTProfileLevel_HEVC_Main10_AutoLevel as String
            ] : [
                AVVideoAverageBitRateKey: bitrate,
                AVVideoProfileLevelKey: AVVideoProfileLevelH264HighAutoLevel
            ]
        ]

        if outputProfile == .hevcHDRPriority {
            var colorProps = HDRMetadataReader.colorProperties(from: videoTrack)
            if colorProps.isEmpty {
                colorProps = [
                    AVVideoColorPrimariesKey: AVVideoColorPrimaries_P3_D65,
                    AVVideoTransferFunctionKey: AVVideoTransferFunction_ITU_R_709_2,
                    AVVideoYCbCrMatrixKey: AVVideoYCbCrMatrix_ITU_R_709_2
                ]
            }
            settings[AVVideoColorPropertiesKey] = colorProps
            settings[AVVideoAllowWideColorKey] = true
        }
        return settings
    }

    private static func warp(overlay: CIImage, to quad: [CGPoint], frameHeight: CGFloat) -> CIImage {
        func ci(_ p: CGPoint) -> CIVector { CIVector(x: p.x, y: frameHeight - p.y) }
        return overlay.applyingFilter("CIPerspectiveTransform", parameters: [
            "inputTopLeft": ci(quad[0]),
            "inputTopRight": ci(quad[1]),
            "inputBottomRight": ci(quad[2]),
            "inputBottomLeft": ci(quad[3])
        ])
    }

    private static func clampQuad(_ q: [CGPoint], width: Int, height: Int) -> [CGPoint] {
        q.map { p in
            CGPoint(
                x: min(max(p.x, 0), CGFloat(width - 1)),
                y: min(max(p.y, 0), CGFloat(height - 1))
            )
        }
    }

    private static func exportTrackingJSON(records: [TrackedFrame], beside videoURL: URL) throws {
        let jsonURL = videoURL.deletingPathExtension().appendingPathExtension("json")
        let data = try JSONEncoder.pretty.encode(records)
        try data.write(to: jsonURL)
    }
}

private enum HDRMetadataReader {
    static func colorProperties(from track: AVAssetTrack) -> [String: Any] {
        guard let description = track.formatDescriptions.first else {
            return [:]
        }
        guard let extensions = CMFormatDescriptionGetExtensions(description) as? [String: Any] else {
            return [:]
        }

        var props: [String: Any] = [:]
        let colorPrimaries = value(for: kCMFormatDescriptionExtension_ColorPrimaries as String, in: extensions)
        let transfer = value(for: kCMFormatDescriptionExtension_TransferFunction as String, in: extensions)
        let matrix = value(for: kCMFormatDescriptionExtension_YCbCrMatrix as String, in: extensions)

        props[AVVideoColorPrimariesKey] = mapColorPrimaries(colorPrimaries)
        props[AVVideoTransferFunctionKey] = mapTransfer(transfer)
        props[AVVideoYCbCrMatrixKey] = mapMatrix(matrix)
        return props
    }

    private static func value(for key: String, in dict: [String: Any]) -> String? {
        if let v = dict[key] as? String { return v }
        if let v = dict[key] { return "\(v)" }
        return nil
    }

    private static func mapColorPrimaries(_ value: String?) -> String {
        guard let value else { return AVVideoColorPrimaries_P3_D65 }
        if value.contains("2020") { return AVVideoColorPrimaries_ITU_R_2020 }
        if value.lowercased().contains("p3") { return AVVideoColorPrimaries_P3_D65 }
        return AVVideoColorPrimaries_ITU_R_709_2
    }

    private static func mapTransfer(_ value: String?) -> String {
        guard let value else { return AVVideoTransferFunction_ITU_R_709_2 }
        let lower = value.lowercased()
        if lower.contains("2084") || lower.contains("pq") { return AVVideoTransferFunction_SMPTE_ST_2084_PQ }
        if lower.contains("hlg") || lower.contains("2100") { return AVVideoTransferFunction_ITU_R_2100_HLG }
        return AVVideoTransferFunction_ITU_R_709_2
    }

    private static func mapMatrix(_ value: String?) -> String {
        guard let value else { return AVVideoYCbCrMatrix_ITU_R_709_2 }
        if value.contains("2020") { return AVVideoYCbCrMatrix_ITU_R_2020 }
        return AVVideoYCbCrMatrix_ITU_R_709_2
    }
}

private extension JSONEncoder {
    static var pretty: JSONEncoder {
        let e = JSONEncoder()
        e.outputFormatting = [.prettyPrinted, .sortedKeys]
        return e
    }
}
