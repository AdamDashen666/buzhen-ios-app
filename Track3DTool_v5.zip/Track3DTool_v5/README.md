# Track3DTool v5

iOS / iPadOS 原生 SwiftUI 工程，用于把普通视频 / 游戏视频里的文字、贴图、字幕透视贴到墙面、地面、屏幕等平面上。

## v5 改动

- 抗漂移增强：从 v3 的 Affine 估计升级为 Homography + RANSAC。
- 低置信度保护：遮挡或低纹理时不会直接跳回第一帧，会使用上一帧预测并尝试重定位。
- 保留音频：默认复制原视频音频轨道到导出文件。
- HEVC/HDR 优先：新增 HEVC `.mov` 导出路径，复制源视频色彩元数据并使用 16-bit half-float Core Image 工作流。
- 本地平面相机解算：导出的 JSON 里包含每帧 quad、confidence、inlierCount、trackerStatus、planePose。

## 使用方法

1. 用 Xcode 打开 `Track3DTool.xcodeproj`
2. Signing & Capabilities 里换成自己的 Team
3. 选择真机 iPhone / iPad 运行
4. 点“导入视频”
5. 在第一帧按顺序点四点：左上 → 右上 → 右下 → 左下
6. 输入要贴墙的文字
7. 选择追踪质量、导出格式
8. 点“开始追踪并导出 v5”

## 技术路线

- Patch Tracking：在你选中的平面内采样多个纹理点
- NCC 匹配：逐帧匹配纹理点
- Homography：估计真实平面透视变化
- RANSAC：过滤误匹配，降低漂移
- CI Perspective Transform：把文字透视变换到追踪平面
- AVAssetWriter：导出合成视频
- Audio Passthrough：复制原视频音频轨道
- Plane Pose Solver：根据平面 Homography 估算相机相对位姿

## 仍需注意

- 纯色墙如果没有任何纹理，任何本地追踪都会不稳；建议选四点时包含边缘、贴图、墙角、砖纹、屏幕边框等特征。
- HEVC/HDR 优先模式已经尽量保留色彩信息，但叠字合成会重新编码，不等于无损 HDR passthrough。
- 完整 AE Camera Solver 是全场景多点三维重建；v5 做的是“平面相机解算”，更适合贴墙文字和屏幕替换。
- 超长 4K/高帧率视频会慢、发热、耗电。

## 导出文件

- 视频：`tracked_wall_text_v5_时间.mov` 或 `.mp4`
- 追踪数据：同名 `.json`

JSON 字段包括：

- `frameIndex`
- `timeSeconds`
- `quad`
- `confidence`
- `inlierCount`
- `trackerStatus`
- `planePose`


## v5 build fix
- Fixed Xcode 26.2 Swift compiler error in `HDRMetadataReader.colorProperties`: removed redundant conditional downcast from `track.formatDescriptions.first as? CMFormatDescription`.
