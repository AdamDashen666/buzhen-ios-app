#include <metal_stdlib>
using namespace metal;

struct FlowParams {
    float alpha;
    float blendStrength;
    float sharpenAmount;
    float consistencyStrength;
};

inline float lumaValue(float3 color) {
    return dot(color, float3(0.2126, 0.7152, 0.0722));
}

inline float colorConflict(float3 a, float3 b) {
    float lumaDelta = fabs(lumaValue(a) - lumaValue(b));
    float chromaDelta = length(a - b) * 0.35;
    return lumaDelta + chromaDelta;
}

inline float flowEdgeRisk(texture2d<float, access::sample> flow,
                          sampler s,
                          float2 flowUV,
                          float2 texel,
                          float2 centerMotion) {
    float2 left = flow.sample(s, clamp(flowUV - float2(texel.x, 0.0), float2(0.0), float2(1.0))).xy;
    float2 right = flow.sample(s, clamp(flowUV + float2(texel.x, 0.0), float2(0.0), float2(1.0))).xy;
    float2 up = flow.sample(s, clamp(flowUV - float2(0.0, texel.y), float2(0.0), float2(1.0))).xy;
    float2 down = flow.sample(s, clamp(flowUV + float2(0.0, texel.y), float2(0.0), float2(1.0))).xy;

    float localJump = (length(right - left) + length(down - up)) * 0.5;
    float normalizedJump = localJump / (length(centerMotion) + 1.0);
    return smoothstep(0.16, 1.25, normalizedJump);
}

kernel void flowWarpBlend(
    texture2d<float, access::sample> previous [[texture(0)]],
    texture2d<float, access::sample> next [[texture(1)]],
    texture2d<float, access::sample> flow [[texture(2)]],
    texture2d<float, access::write> output [[texture(3)]],
    constant FlowParams &params [[buffer(0)]],
    uint2 gid [[thread_position_in_grid]]
) {
    if (gid.x >= output.get_width() || gid.y >= output.get_height()) {
        return;
    }

    constexpr sampler s(address::clamp_to_edge, filter::linear);

    float alpha = clamp(params.alpha, 0.0, 1.0);
    float baseBlendStrength = clamp(params.blendStrength, 0.0, 1.0);
    float sharpenAmount = clamp(params.sharpenAmount, 0.0, 0.45);
    float ghostProtection = clamp(params.consistencyStrength, 0.0, 1.0);

    float2 size = float2(output.get_width(), output.get_height());
    float2 texel = 1.0 / size;
    float2 uv = (float2(gid) + 0.5) / size;

    float2 flowSize = float2(flow.get_width(), flow.get_height());
    float2 flowTexel = 1.0 / flowSize;
    float2 flowUV = (float2(gid) + 0.5) / flowSize;
    float2 motion = flow.sample(s, flowUV).xy;

    // previous 按 alpha 往 next 方向推，next 按 1-alpha 往 previous 方向拉。
    float2 prevUV = uv - (motion * alpha) / size;
    float2 nextUV = uv + (motion * (1.0 - alpha)) / size;

    float4 a = previous.sample(s, prevUV);
    float4 b = next.sample(s, nextUV);
    float4 rawA = previous.sample(s, uv);
    float4 rawB = next.sample(s, uv);

    // v135：单向光流也加残影保护。
    // 颜色冲突、运动边缘、原始帧大变化都说明这里可能是遮挡/显露区域，减少双帧混合。
    float warpedConflict = smoothstep(0.045, 0.235, colorConflict(a.rgb, b.rgb));
    float rawConflict = smoothstep(0.075, 0.355, colorConflict(rawA.rgb, rawB.rgb));
    float edgeConflict = flowEdgeRisk(flow, s, flowUV, flowTexel, motion);
    float motionRisk = smoothstep(10.0, 88.0, length(motion));
    float temporalRisk = rawConflict * motionRisk;
    float antiGhost = max(max(warpedConflict, edgeConflict), temporalRisk) * ghostProtection;
    antiGhost = clamp(antiGhost, 0.0, 1.0);

    float4 warpedBlend = mix(a, b, alpha);
    float4 dominant = alpha < 0.5 ? a : b;

    // 抗残影核心：风险越高，混合越少，越偏向主导帧。
    float adaptiveBlendStrength = baseBlendStrength * (1.0 - antiGhost * 0.92);
    float4 stableBlend = mix(dominant, warpedBlend, adaptiveBlendStrength);
    float4 result = mix(stableBlend, dominant, antiGhost * 0.62);

    if (sharpenAmount > 0.001) {
        float2 dx = float2(texel.x, 0.0);
        float2 dy = float2(0.0, texel.y);

        float4 left = mix(previous.sample(s, prevUV - dx), next.sample(s, nextUV - dx), alpha);
        float4 right = mix(previous.sample(s, prevUV + dx), next.sample(s, nextUV + dx), alpha);
        float4 up = mix(previous.sample(s, prevUV - dy), next.sample(s, nextUV - dy), alpha);
        float4 down = mix(previous.sample(s, prevUV + dy), next.sample(s, nextUV + dy), alpha);
        float4 blur = (left + right + up + down) * 0.25;

        float edge = clamp(length(result.rgb - blur.rgb) * 2.2, 0.0, 1.0);
        float adaptiveSharpen = sharpenAmount * mix(0.18, 1.0, 1.0 - antiGhost) * mix(0.70, 1.0, edge);
        result.rgb = clamp(result.rgb + (result.rgb - blur.rgb) * adaptiveSharpen, 0.0, 1.0);
    }

    output.write(result, gid);
}


kernel void flowWarpBlendBidirectional(
    texture2d<float, access::sample> previous [[texture(0)]],
    texture2d<float, access::sample> next [[texture(1)]],
    texture2d<float, access::sample> forwardFlow [[texture(2)]],
    texture2d<float, access::sample> reverseFlow [[texture(3)]],
    texture2d<float, access::write> output [[texture(4)]],
    constant FlowParams &params [[buffer(0)]],
    uint2 gid [[thread_position_in_grid]]
) {
    if (gid.x >= output.get_width() || gid.y >= output.get_height()) {
        return;
    }

    constexpr sampler s(address::clamp_to_edge, filter::linear);

    float alpha = clamp(params.alpha, 0.0, 1.0);
    float baseBlendStrength = clamp(params.blendStrength, 0.0, 1.0);
    float sharpenAmount = clamp(params.sharpenAmount, 0.0, 0.45);
    float consistencyStrength = clamp(params.consistencyStrength, 0.0, 1.0);

    float2 size = float2(output.get_width(), output.get_height());
    float2 texel = 1.0 / size;
    float2 uv = (float2(gid) + 0.5) / size;

    float2 flowSize = float2(forwardFlow.get_width(), forwardFlow.get_height());
    float2 flowTexel = 1.0 / flowSize;
    float2 flowUV = (float2(gid) + 0.5) / flowSize;

    float2 fwd = forwardFlow.sample(s, flowUV).xy;
    float2 rev = reverseFlow.sample(s, flowUV).xy;

    // 双向 veryHigh 光流：前一帧往后一帧推，后一帧往前一帧拉。
    float2 prevUV = uv - (fwd * alpha) / size;
    float2 nextUV = uv - (rev * (1.0 - alpha)) / size;

    float4 a = previous.sample(s, prevUV);
    float4 b = next.sample(s, nextUV);
    float4 rawA = previous.sample(s, uv);
    float4 rawB = next.sample(s, uv);

    float4 warpedBlend = mix(a, b, alpha);
    float4 dominant = alpha < 0.5 ? a : b;

    // v135：更强遮挡/残影检测。
    // 1. 双向光流无法互相抵消：很可能是遮挡或错误匹配。
    float2 fwdAtPrev = forwardFlow.sample(s, clamp(prevUV, float2(0.0), float2(1.0))).xy;
    float2 revAtNext = reverseFlow.sample(s, clamp(nextUV, float2(0.0), float2(1.0))).xy;
    float consistencyError = length(fwdAtPrev + revAtNext) / (length(fwdAtPrev) + length(revAtNext) + 1.0);
    float consistencyRisk = smoothstep(0.055, 0.36, consistencyError);

    // 2. warp 后前后帧颜色/亮度对不上：混合会出现双影。
    float warpedConflict = smoothstep(0.040, 0.220, colorConflict(a.rgb, b.rgb));

    // 3. 光流突变边缘：人物边缘、手臂、字幕边缘最容易拖尾。
    float forwardEdge = flowEdgeRisk(forwardFlow, s, flowUV, flowTexel, fwd);
    float reverseEdge = flowEdgeRisk(reverseFlow, s, flowUV, flowTexel, rev);
    float edgeRisk = max(forwardEdge, reverseEdge);

    // 4. 原始帧变化大并且运动大：多半是显露/遮挡区域。
    float rawConflict = smoothstep(0.070, 0.340, colorConflict(rawA.rgb, rawB.rgb));
    float motionRisk = smoothstep(8.0, 82.0, max(length(fwd), length(rev)));
    float temporalRisk = rawConflict * motionRisk;

    float antiGhost = max(max(consistencyRisk, warpedConflict), max(edgeRisk, temporalRisk));
    antiGhost = clamp(antiGhost * consistencyStrength, 0.0, 1.0);

    // 风险越高，越少做 A/B 混合，避免半透明残影。
    float adaptiveBlendStrength = baseBlendStrength * (1.0 - antiGhost * 0.96);
    float4 stableBlend = mix(dominant, warpedBlend, adaptiveBlendStrength);
    float4 result = mix(stableBlend, dominant, antiGhost * 0.74);

    if (sharpenAmount > 0.001) {
        float2 dx = float2(texel.x, 0.0);
        float2 dy = float2(0.0, texel.y);

        float4 left = mix(previous.sample(s, prevUV - dx), next.sample(s, nextUV - dx), alpha);
        float4 right = mix(previous.sample(s, prevUV + dx), next.sample(s, nextUV + dx), alpha);
        float4 up = mix(previous.sample(s, prevUV - dy), next.sample(s, nextUV - dy), alpha);
        float4 down = mix(previous.sample(s, prevUV + dy), next.sample(s, nextUV + dy), alpha);
        float4 blur = (left + right + up + down) * 0.25;

        float edge = clamp(length(result.rgb - blur.rgb) * 2.2, 0.0, 1.0);
        float adaptiveSharpen = sharpenAmount * mix(0.16, 1.0, 1.0 - antiGhost) * mix(0.68, 1.0, edge);
        result.rgb = clamp(result.rgb + (result.rgb - blur.rgb) * adaptiveSharpen, 0.0, 1.0);
    }

    output.write(result, gid);
}
