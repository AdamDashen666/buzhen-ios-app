# Mineradio iOS Original Web Port

目标：**不要仿版，不重画 UI，不阉割粒子 / 3D / 歌词舞台**。

这个工程是一个 iOS WKWebView 壳，构建时会下载原仓库：

`https://github.com/XxHuberrr/Mineradio`

并把原版 `public/` 目录整体复制进 App Bundle：

`MineradioWeb/index.html`

App 启动后直接加载原版 `index.html`，视觉层走原项目的 HTML/CSS/JS/Three.js/GSAP/music-tempo。

## 结构

- `MineradioiOSApp.swift`：iOS App 入口。
- `ContentView.swift`：WKWebView 原版前端加载器 + iOS/Electron 兼容桥。
- `Run Script Phase: Fetch Original Mineradio Web`：GitHub Actions / Xcode build 时下载原 `public/`。

## 注意

1. 构建机器必须能访问 GitHub，否则 `Fetch Original Mineradio Web` 会失败。
2. 视觉层不使用之前的 SwiftUI 卡片界面。
3. iOS 只桥接底层能力：文件导入、WebView、Electron `desktopWindow` 兼容、`/api` 转发。
4. 原版里 Windows/Electron 独有能力无法 1:1 保证，比如窗口控制、桌面歌词穿透、Windows 安装器更新。它们会被 iOS 桥接为 no-op 或 fallback，但视觉代码不重写。

## API Base

原前端里的 `/api/...` 请求会被桥接到：

`http://127.0.0.1:3000`

也可以在 WebView localStorage 里改：

```js
localStorage.setItem('mineradio-ios-api-base', 'http://你的电脑局域网IP:3000')
```

## GitHub Workflow 参数

```text
FILE=MineradioiOS.xcodeproj
SCHEME=MineradioiOS
CONFIGURATION=Release
SDK=iphoneos
```
