# GitHub Workflow Ready

这个包适配一键 GitHub Actions unsigned IPA workflow。

## Build 参数

```text
FILE=MineradioiOS.xcodeproj
SCHEME=MineradioiOS
CONFIGURATION=Release
SDK=iphoneos
```

## 关键要求

构建阶段需要访问 GitHub，因为 Xcode Run Script 会拉取原 Mineradio 仓库的 `public/` 目录：

```text
https://github.com/XxHuberrr/Mineradio/archive/refs/heads/main.zip
```

如果 GitHub 访问失败，构建会失败，不会悄悄输出阉割版。
