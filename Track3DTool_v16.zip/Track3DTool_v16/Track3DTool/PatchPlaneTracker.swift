import Foundation
import CoreGraphics

struct PatchTrackResult {
    let quadOriginalPixels: [CGPoint]
    let confidence: Double
    let inlierCount: Int
    let status: String
}

final class PatchPlaneTracker {
    private struct TrackPoint {
        let initial: CGPoint
        var current: CGPoint
        let template: [UInt8]
        let texture: Double
        var lostFrames: Int
    }

    private var points: [TrackPoint] = []
    private let initialQuad: [CGPoint]
    private let quality: TrackingQuality
    private var lastHomography: Homography2D = .identity
    private var lastGoodQuad: [CGPoint]
    private var frameCounter = 0
    private var lockMode = false

    init(initialImage: ImageGray, quadInOriginalPixels: [CGPoint], quality: TrackingQuality) {
        self.quality = quality
        let ordered = QuadNormalizer.canonical(quadInOriginalPixels)
        let s = initialImage.scaleFromOriginal
        self.initialQuad = ordered.map { CGPoint(x: $0.x * s, y: $0.y * s) }
        self.lastGoodQuad = self.initialQuad
        self.points = Self.makeTrackPoints(image: initialImage, quad: self.initialQuad, quality: quality)
        self.lockMode = self.points.count < 4
    }

    func track(nextImage: ImageGray) -> PatchTrackResult {
        frameCounter += 1
        if lockMode || points.count < 4 {
            return result(quad: lastGoodQuad, scale: nextImage.scaleFromOriginal, confidence: 0.14, inliers: points.count, status: "剪映式平面跟踪：低纹理锁定")
        }

        let radius = quality.patchRadius
        let baseSearch = quality.searchRadius
        var src: [CGPoint] = []
        var dst: [CGPoint] = []
        var pointIndices: [Int] = []
        var newPoints = points
        var scores: [Double] = []

        for i in 0..<newPoints.count {
            let predicted = lastHomography.apply(newPoints[i].initial)
            let backupPredicted = newPoints[i].current
            let search = min(baseSearch + 10, baseSearch + newPoints[i].lostFrames * 3)
            let first = bestMatch(image: nextImage, template: newPoints[i].template, predicted: predicted, radius: radius, search: search)
            let second = bestMatch(image: nextImage, template: newPoints[i].template, predicted: backupPredicted, radius: radius, search: max(7, baseSearch / 2))

            let candidate: (CGPoint, Double)?
            if let first, let second {
                candidate = first.1 >= second.1 ? first : second
            } else {
                candidate = first ?? second
            }

            let relaxedThreshold = max(0.32, quality.minNCC - 0.12)
            if let candidate, candidate.1 >= relaxedThreshold {
                src.append(newPoints[i].initial)
                dst.append(candidate.0)
                pointIndices.append(i)
                scores.append(candidate.1)
                newPoints[i].current = candidate.0
                newPoints[i].lostFrames = 0
            } else {
                newPoints[i].lostFrames += 1
            }
        }

        let minUsefulInliers = max(4, min(10, max(4, points.count / 4)))

        if src.count >= 4,
           let robust = HomographyEstimator.robust(from: src, to: dst, threshold: quality.ransacError * 0.95) {
            let proposedQuad = initialQuad.map { robust.model.apply($0) }
            let rawScore = averageScore(indices: robust.inliers, scores: scores)
            let coverage = min(1.0, Double(robust.inliers.count) / Double(max(minUsefulInliers, min(points.count, 28))))
            let confidence = max(0.0, min(1.0, rawScore * coverage))

            if robust.inliers.count >= minUsefulInliers,
               confidence >= 0.34,
               isSaneQuad(proposedQuad, image: nextImage) {
                for inlier in robust.inliers where inlier < pointIndices.count {
                    let idx = pointIndices[inlier]
                    newPoints[idx].current = robust.model.apply(newPoints[idx].initial)
                    newPoints[idx].lostFrames = 0
                }
                return accept(proposedQuad: proposedQuad, confidence: confidence, inliers: robust.inliers.count, points: newPoints, scale: nextImage.scaleFromOriginal, statusPrefix: "剪映式 Homography")
            }
        }

        if src.count >= 3, let affine = AffineEstimator.estimate(from: src, to: dst) {
            let proposedQuad = initialQuad.map { affine.apply($0) }
            let rawScore = scores.isEmpty ? 0 : scores.reduce(0, +) / Double(scores.count)
            let coverage = min(1.0, Double(src.count) / Double(max(minUsefulInliers, min(points.count, 24))))
            let confidence = min(0.58, rawScore * coverage * 0.78)
            if src.count >= max(3, minUsefulInliers - 2), confidence >= 0.28, isSaneQuad(proposedQuad, image: nextImage) {
                return accept(proposedQuad: proposedQuad, confidence: confidence, inliers: src.count, points: newPoints, scale: nextImage.scaleFromOriginal, statusPrefix: "剪映式 Affine")
            }
        }

        self.points = newPoints
        return result(quad: lastGoodQuad, scale: nextImage.scaleFromOriginal, confidence: 0.18, inliers: src.count, status: "剪映式平面跟踪：低置信度锁定防漂移")
    }

    private func accept(proposedQuad: [CGPoint], confidence: Double, inliers: Int, points newPoints: [TrackPoint], scale: CGFloat, statusPrefix: String) -> PatchTrackResult {
        let alpha: CGFloat
        if confidence > 0.78 { alpha = 0.62 }
        else if confidence > 0.58 { alpha = 0.44 }
        else { alpha = 0.26 }

        let smoothed = blendQuad(from: lastGoodQuad, to: proposedQuad, alpha: alpha)
        lastGoodQuad = smoothed
        lastHomography = HomographyEstimator.estimate(from: initialQuad, to: smoothed) ?? lastHomography
        self.points = newPoints

        let status: String
        if confidence > 0.70 { status = "\(statusPrefix)：稳定贴墙" }
        else if confidence > 0.45 { status = "\(statusPrefix)：平滑跟踪" }
        else { status = "\(statusPrefix)：保守跟随" }
        return result(quad: smoothed, scale: scale, confidence: confidence, inliers: inliers, status: status)
    }

    private func result(quad: [CGPoint], scale: CGFloat, confidence: Double, inliers: Int, status: String) -> PatchTrackResult {
        let inv = 1 / scale
        let originalQ = QuadNormalizer.canonical(quad.map { CGPoint(x: $0.x * inv, y: $0.y * inv) })
        return PatchTrackResult(quadOriginalPixels: originalQ, confidence: confidence, inlierCount: inliers, status: status)
    }

    private static func makeTrackPoints(image: ImageGray, quad: [CGPoint], quality: TrackingQuality) -> [TrackPoint] {
        let radius = quality.patchRadius
        var all: [TrackPoint] = []
        var candidates: [TrackPoint] = []

        func add(_ p: CGPoint, threshold: Double) {
            guard let patch = image.patch(center: p, radius: radius) else { return }
            let energy = textureEnergy(patch)
            let tp = TrackPoint(initial: p, current: p, template: patch, texture: energy, lostFrames: 0)
            all.append(tp)
            if energy >= threshold { candidates.append(tp) }
        }

        let gxCount = max(quality.gridX + 2, 9)
        let gyCount = max(quality.gridY + 2, 7)
        for gy in 0..<gyCount {
            for gx in 0..<gxCount {
                let u = CGFloat(gx + 1) / CGFloat(gxCount + 1)
                let v = CGFloat(gy + 1) / CGFloat(gyCount + 1)
                add(bilinear(quad, u: u, v: v), threshold: 1.15)
            }
        }

        // CapCut-style plane tracking should follow the selected plane, not nearby moving hands/HUD.
        // Add points on/near the four edges, but avoid searching far outside the selected area.
        let edgeSamples = max(8, quality.gridX + 2)
        for i in 0..<edgeSamples {
            let t = CGFloat(i) / CGFloat(max(1, edgeSamples - 1))
            for offset in [-0.035, 0.0, 0.035] {
                let o = CGFloat(offset)
                add(bilinear(quad, u: t, v: o), threshold: 1.05)
                add(bilinear(quad, u: t, v: 1 + o), threshold: 1.05)
                add(bilinear(quad, u: o, v: t), threshold: 1.05)
                add(bilinear(quad, u: 1 + o, v: t), threshold: 1.05)
            }
        }

        for p in quad { add(p, threshold: 0.65) }

        if candidates.count < 4 {
            candidates = all.sorted(by: { $0.texture > $1.texture }).filter { $0.texture > 0.30 }
        }

        var unique: [TrackPoint] = []
        for c in candidates.sorted(by: { $0.texture > $1.texture }) {
            if unique.contains(where: { hypot($0.initial.x - c.initial.x, $0.initial.y - c.initial.y) < CGFloat(max(4, radius * 2)) }) { continue }
            unique.append(c)
            if unique.count >= 96 { break }
        }
        return unique
    }

    private func isSaneQuad(_ q: [CGPoint], image: ImageGray) -> Bool {
        guard q.count == 4 else { return false }
        if q.contains(where: { !$0.x.isFinite || !$0.y.isFinite }) { return false }
        let margin = CGFloat(max(image.width, image.height)) * 0.12
        for p in q {
            if p.x < -margin || p.y < -margin || p.x > CGFloat(image.width) + margin || p.y > CGFloat(image.height) + margin { return false }
        }
        let initialArea = abs(polygonArea(initialQuad))
        let proposedArea = abs(polygonArea(q))
        if initialArea > 1 {
            if proposedArea < initialArea * 0.32 || proposedArea > initialArea * 2.75 { return false }
        }
        let jumpLimit = CGFloat(max(image.width, image.height)) * 0.16
        let maxJump = zip(q, lastGoodQuad).map { pair in hypot(pair.0.x - pair.1.x, pair.0.y - pair.1.y) }.max() ?? 0
        return maxJump <= jumpLimit
    }

    private func bestMatch(image: ImageGray, template: [UInt8], predicted: CGPoint, radius: Int, search: Int) -> (CGPoint, Double)? {
        var bestScore = -Double.greatestFiniteMagnitude
        var best = predicted
        let centerX = Int(round(predicted.x))
        let centerY = Int(round(predicted.y))
        let step = search > 26 ? 2 : 1

        for dy in stride(from: -search, through: search, by: step) {
            for dx in stride(from: -search, through: search, by: step) {
                let candidate = CGPoint(x: CGFloat(centerX + dx), y: CGFloat(centerY + dy))
                guard let patch = image.patch(center: candidate, radius: radius) else { continue }
                let score = ncc(template, patch)
                if score > bestScore {
                    bestScore = score
                    best = candidate
                }
            }
        }

        if step > 1 {
            let coarse = best
            for dy in -2...2 {
                for dx in -2...2 {
                    let candidate = CGPoint(x: coarse.x + CGFloat(dx), y: coarse.y + CGFloat(dy))
                    guard let patch = image.patch(center: candidate, radius: radius) else { continue }
                    let score = ncc(template, patch)
                    if score > bestScore {
                        bestScore = score
                        best = candidate
                    }
                }
            }
        }
        return bestScore.isFinite ? (best, bestScore) : nil
    }

    private func averageScore(indices: [Int], scores: [Double]) -> Double {
        var values: [Double] = []
        for i in indices where i < scores.count { values.append(scores[i]) }
        return values.isEmpty ? 0 : values.reduce(0, +) / Double(values.count)
    }

    private func blendQuad(from old: [CGPoint], to new: [CGPoint], alpha: CGFloat) -> [CGPoint] {
        guard old.count == new.count else { return new }
        return zip(old, new).map { a, b in
            CGPoint(x: a.x + (b.x - a.x) * alpha, y: a.y + (b.y - a.y) * alpha)
        }
    }

    private static func bilinear(_ q: [CGPoint], u: CGFloat, v: CGFloat) -> CGPoint {
        let top = CGPoint(x: q[0].x + (q[1].x - q[0].x) * u, y: q[0].y + (q[1].y - q[0].y) * u)
        let bottom = CGPoint(x: q[3].x + (q[2].x - q[3].x) * u, y: q[3].y + (q[2].y - q[3].y) * u)
        return CGPoint(x: top.x + (bottom.x - top.x) * v, y: top.y + (bottom.y - top.y) * v)
    }

    private static func textureEnergy(_ patch: [UInt8]) -> Double {
        guard !patch.isEmpty else { return 0 }
        let mean = patch.reduce(0.0) { $0 + Double($1) } / Double(patch.count)
        let variance = patch.reduce(0.0) { acc, px in
            let d = Double(px) - mean
            return acc + d * d
        } / Double(patch.count)
        return sqrt(variance)
    }

    private func ncc(_ a: [UInt8], _ b: [UInt8]) -> Double {
        guard a.count == b.count, !a.isEmpty else { return -1 }
        let n = Double(a.count)
        var meanA = 0.0
        var meanB = 0.0
        for i in 0..<a.count {
            meanA += Double(a[i])
            meanB += Double(b[i])
        }
        meanA /= n
        meanB /= n
        var num = 0.0
        var da = 0.0
        var db = 0.0
        for i in 0..<a.count {
            let x = Double(a[i]) - meanA
            let y = Double(b[i]) - meanB
            num += x * y
            da += x * x
            db += y * y
        }
        let denom = sqrt(da * db)
        guard denom > 1e-6 else { return -1 }
        return num / denom
    }

    private func polygonArea(_ q: [CGPoint]) -> CGFloat {
        guard q.count >= 3 else { return 0 }
        var a: CGFloat = 0
        for i in 0..<q.count {
            let j = (i + 1) % q.count
            a += q[i].x * q[j].y - q[j].x * q[i].y
        }
        return a * 0.5
    }
}
