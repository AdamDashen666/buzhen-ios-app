# AI Comic Studio iPadOS Xcode Project

一个 SwiftUI iPadOS / iOS 漫画制作 App 原型：用户输入故事或提示词，文本模型自动完善故事、提取角色、生成分镜和页面规划；图片模型按页面生成完整漫画页。

## 主要功能

- 两种创作模式：
  - 已有故事：粘贴完整故事，AI 直接拆角色、分镜、页面。
  - AI 写故事：输入关键词/世界观/人物想法，AI 先扩写故事，再做漫画规划。
- 文本 API 和图片 API 分离配置。
- 内置主流 API Base URL 预设。
- 输入 API Key 后可刷新可用模型。
- 自动提取角色：名字、定位、性格、外观、服装、色彩、角色一致性 Prompt Anchor。
- 自动规划页面：页标题、摘要、整页 Prompt、连续性备注、每格分镜。
- 每格分镜包含：镜头、场景、动作、视觉 Prompt、旁白、dialogue、角色、camera、mood。
- 可以单独生成某一页，也可以一键生成全部页。
- 支持编辑角色、页面 Prompt、分镜、dialogue。
- 图片生成后会保存到本地项目 JSON 内。
- 有运行日志，可复制排查 API 错误。
- 没有文本 API Key 时会使用本地兜底规划，方便先测试 UI。

## 内置文本 API 预设

- OpenAI：`https://api.openai.com/v1`
- OpenRouter：`https://openrouter.ai/api/v1`
- DeepSeek：`https://api.deepseek.com`
- Anthropic Claude：`https://api.anthropic.com/v1`
- Google Gemini：`https://generativelanguage.googleapis.com/v1beta`
- SiliconFlow：`https://api.siliconflow.cn/v1`
- 火山方舟 / Doubao：`https://ark.cn-beijing.volces.com/api/v3`
- 阿里云 DashScope OpenAI 兼容：`https://dashscope.aliyuncs.com/compatible-mode/v1`
- Moonshot / Kimi：`https://api.moonshot.cn/v1`
- 智谱 GLM：`https://open.bigmodel.cn/api/paas/v4`
- 自定义 OpenAI 兼容

## 内置图片 API 预设

- OpenAI Images：`https://api.openai.com/v1`
- Stability AI：`https://api.stability.ai`
- Replicate：`https://api.replicate.com/v1`
- fal.ai：`https://fal.run`
- SiliconFlow Images：`https://api.siliconflow.cn/v1`
- 自定义 OpenAI 图片兼容

## 模型刷新逻辑

- OpenAI 兼容：`GET /models`
- Gemini：`GET /models?key=...`
- Anthropic：`GET /models`
- Replicate：`GET /models`
- Stability：优先尝试 legacy engines list，失败时用内置列表兜底
- fal.ai：没有统一稳定的模型列表接口，本版用内置常用模型列表

## 使用方法

1. 用 Xcode 打开 `AIComicStudio.xcodeproj`。
2. 在 Signing & Capabilities 里选择你的 Team。
3. 运行到 iPad 或模拟器。
4. 打开 App → API 与模型。
5. 选择文本 API 预设，填 API Key，点刷新模型，选文本模型。
6. 选择图片 API 预设，填 API Key，点刷新模型，选图片模型。
7. 回到创作页，输入故事或提示词。
8. 点“自动规划漫画”。
9. 到页面页查看每页规划。
10. 点“生成本页”或“一键生成所有页”。

## 注意 / 风险

- 图片模型生成文字气泡可能会乱码；可以在设置里关闭“把 dialogue 写进图片 prompt”，只生成空白气泡，后期再加文字。
- 不同 API 的图片接口参数差异很大，本版做了主流兼容，但某些第三方模型可能需要你按服务商文档改字段。
- Replicate 某些模型需要版本号或不同输入字段；本版优先支持官方模型路径 `owner/name` 的 prediction 方式。
- 火山方舟模型名通常是 Endpoint ID，需要填你后台的接入点 ID。
- 该项目是前端直连 API。正式上架时不要把 API Key 明文放客户端，建议改成自己的后端代理。
