import Foundation

enum ModelListService {
    static func fetchModels(for config: ModelEndpointConfig, fallback: [String]) async throws -> [String] {
        switch config.transport {
        case .openAICompatible, .openAIImages:
            return try await fetchOpenAICompatibleModels(config: config, fallback: fallback)
        case .gemini:
            return try await fetchGeminiModels(config: config, fallback: fallback)
        case .anthropic:
            return try await fetchAnthropicModels(config: config, fallback: fallback)
        case .stability:
            return try await fetchStabilityModels(config: config, fallback: fallback)
        case .replicate:
            return try await fetchReplicateModels(config: config, fallback: fallback)
        case .fal:
            return fallback
        }
    }

    private static func fetchOpenAICompatibleModels(config: ModelEndpointConfig, fallback: [String]) async throws -> [String] {
        let url = try NetworkTools.url(base: config.baseURL, path: "/models")
        var request = NetworkTools.request(url: url, apiKey: config.apiKey, headers: ["Content-Type": "application/json"], timeout: config.timeoutSeconds)
        if config.presetID == "openrouter" {
            request.setValue("AIComicStudio", forHTTPHeaderField: "X-Title")
        }
        let data = try await NetworkTools.perform(request)
        let json = try NetworkTools.jsonObject(from: data)
        let models = NetworkTools.stringsFromModelListJSON(json).sorted()
        return models.isEmpty ? fallback : models
    }

    private static func fetchGeminiModels(config: ModelEndpointConfig, fallback: [String]) async throws -> [String] {
        guard !config.apiKey.isEmpty else { return fallback }
        let urlString = NetworkTools.normalizedBase(config.baseURL) + "/models?key=" + config.apiKey
        guard let url = URL(string: urlString) else { throw AppError.invalidURL(urlString) }
        let request = NetworkTools.request(url: url, timeout: config.timeoutSeconds)
        let data = try await NetworkTools.perform(request)
        let json = try NetworkTools.jsonObject(from: data)
        let models = NetworkTools.stringsFromModelListJSON(json).sorted()
        return models.isEmpty ? fallback : models
    }

    private static func fetchAnthropicModels(config: ModelEndpointConfig, fallback: [String]) async throws -> [String] {
        guard !config.apiKey.isEmpty else { return fallback }
        let url = try NetworkTools.url(base: config.baseURL, path: "/models")
        let request = NetworkTools.request(url: url, headers: [
            "x-api-key": config.apiKey,
            "anthropic-version": "2023-06-01",
            "Content-Type": "application/json"
        ], timeout: config.timeoutSeconds)
        let data = try await NetworkTools.perform(request)
        let json = try NetworkTools.jsonObject(from: data)
        let models = NetworkTools.stringsFromModelListJSON(json).sorted()
        return models.isEmpty ? fallback : models
    }

    private static func fetchStabilityModels(config: ModelEndpointConfig, fallback: [String]) async throws -> [String] {
        // Stability's current image endpoints do not expose a universal v2beta model list for every account.
        // This legacy endpoint may work for some keys; otherwise use the maintained built-in list.
        guard !config.apiKey.isEmpty else { return fallback }
        let url = try NetworkTools.url(base: config.baseURL, path: "/v1/engines/list")
        let request = NetworkTools.request(url: url, apiKey: config.apiKey, timeout: config.timeoutSeconds)
        let data = try await NetworkTools.perform(request)
        let json = try NetworkTools.jsonObject(from: data)
        let models = NetworkTools.stringsFromModelListJSON(json).sorted()
        return models.isEmpty ? fallback : models
    }

    private static func fetchReplicateModels(config: ModelEndpointConfig, fallback: [String]) async throws -> [String] {
        guard !config.apiKey.isEmpty else { return fallback }
        let url = try NetworkTools.url(base: config.baseURL, path: "/models")
        let request = NetworkTools.request(url: url, apiKey: config.apiKey, bearerPrefix: "Token", timeout: config.timeoutSeconds)
        let data = try await NetworkTools.perform(request)
        let json = try NetworkTools.jsonObject(from: data)
        let models = NetworkTools.stringsFromModelListJSON(json).sorted()
        return models.isEmpty ? fallback : models
    }
}
