import SwiftUI

@main
struct AIComicStudioApp: App {
    @StateObject private var projectStore = ProjectStore()
    @StateObject private var apiSettings = APISettings()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(projectStore)
                .environmentObject(apiSettings)
                .task {
                    projectStore.load()
                    apiSettings.load()
                }
        }
    }
}
