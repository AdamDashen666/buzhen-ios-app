import Foundation
import SwiftUI

@MainActor
final class ProjectStore: ObservableObject {
    @Published var project: ComicProject = .empty
    @Published var selectedPageID: ComicPage.ID?
    @Published var logs: [String] = []
    @Published var isBusy: Bool = false

    private let saveURL: URL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent("AIComicStudioProject.json")

    func newProject() {
        project = .empty
        selectedPageID = nil
        logs.removeAll()
        log("已创建新项目。")
        save()
    }

    func loadSample() {
        project = .sample
        selectedPageID = project.pages.first?.id
        log("已载入示例项目。")
        save()
    }

    func load() {
        guard let data = try? Data(contentsOf: saveURL), let decoded = try? JSONDecoder.iso.decode(ComicProject.self, from: data) else { return }
        project = decoded
        selectedPageID = project.pages.first?.id
    }

    func save() {
        project.updatedAt = Date()
        do {
            let encoded = try JSONEncoder.pretty.encode(project)
            try encoded.write(to: saveURL, options: .atomic)
        } catch {
            log("保存失败：\(error.localizedDescription)")
        }
    }

    func log(_ message: String) {
        let time = DateFormatter.logFormatter.string(from: Date())
        logs.append("[\(time)] \(message)")
    }

    func logsText() -> String { logs.joined(separator: "\n") }

    func pageBinding(for pageID: ComicPage.ID) -> Binding<ComicPage>? {
        guard let index = project.pages.firstIndex(where: { $0.id == pageID }) else { return nil }
        return Binding(
            get: { self.project.pages[index] },
            set: { self.project.pages[index] = $0; self.save() }
        )
    }

    func selectedPageBinding() -> Binding<ComicPage>? {
        guard let selectedPageID else { return nil }
        return pageBinding(for: selectedPageID)
    }

    func updatePage(_ page: ComicPage) {
        guard let index = project.pages.firstIndex(where: { $0.id == page.id }) else { return }
        project.pages[index] = page
        save()
    }

    func planComic(settings: APISettings) async {
        let trimmedInput = project.sourceInput.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmedInput.isEmpty else {
            log("请输入故事或提示词。")
            return
        }

        isBusy = true
        project.status = .planning
        log("开始自动规划：角色 → 故事 → 分镜 → 页面。")
        defer { isBusy = false; save() }

        do {
            let planned = try await ComicPlanningService.plan(project: project, settings: settings, logger: { [weak self] message in
                Task { @MainActor in self?.log(message) }
            })
            project = planned
            selectedPageID = project.pages.first?.id
            project.status = .planned
            log("规划完成：\(project.characters.count) 个角色，\(project.pages.count) 页。")
        } catch {
            project.status = .failed
            log("规划失败：\(error.localizedDescription)")
        }
    }

    func generateSelectedPage(settings: APISettings) async {
        guard let selectedPageID, let index = project.pages.firstIndex(where: { $0.id == selectedPageID }) else {
            log("请先选择页面。")
            return
        }
        await generatePage(at: index, settings: settings)
    }

    func generateAllPages(settings: APISettings) async {
        guard !project.pages.isEmpty else {
            log("请先自动规划页面。")
            return
        }
        isBusy = true
        defer { isBusy = false; save() }
        for index in project.pages.indices {
            await generatePage(at: index, settings: settings, manageBusy: false)
        }
        log("全部页面生成流程结束。")
    }

    private func generatePage(at index: Int, settings: APISettings, manageBusy: Bool = true) async {
        if manageBusy { isBusy = true }
        defer { if manageBusy { isBusy = false; save() } }

        guard !settings.imageConfig.apiKey.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            project.pages[index].status = .failed
            project.pages[index].errorMessage = "未填写图片 API Key"
            log("第 \(project.pages[index].pageNumber) 页生成失败：未填写图片 API Key。")
            return
        }

        project.pages[index].status = .generating
        project.pages[index].errorMessage = nil
        let page = project.pages[index]
        log("开始生成第 \(page.pageNumber) 页图片：\(page.title)")

        do {
            let prompt = ImagePromptBuilder.build(project: project, page: page, settings: settings)
            let data = try await ImageGenerationService.generateImage(prompt: prompt, config: settings.imageConfig, imageSize: settings.imageSize)
            project.pages[index].imageData = data
            project.pages[index].generatedAt = Date()
            project.pages[index].status = .generated
            log("第 \(page.pageNumber) 页图片生成完成。")
        } catch {
            project.pages[index].status = .failed
            project.pages[index].errorMessage = error.localizedDescription
            log("第 \(page.pageNumber) 页图片生成失败：\(error.localizedDescription)")
        }
    }
}

extension JSONEncoder {
    static var pretty: JSONEncoder {
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        encoder.dateEncodingStrategy = .iso8601
        return encoder
    }
}

extension JSONDecoder {
    static var iso: JSONDecoder {
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        return decoder
    }
}

extension DateFormatter {
    static let logFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm:ss"
        return formatter
    }()
}
