import SwiftUI

struct LogsView: View {
    @EnvironmentObject private var store: ProjectStore
    @State private var copied = false

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack {
                SectionHeader(title: "运行日志", subtitle: "记录规划、刷新模型、生成图片时的关键状态，方便排查 API 问题。")
                Spacer()
                Button {
                    copyLogs()
                } label: {
                    Label(copied ? "已复制" : "复制日志", systemImage: copied ? "checkmark" : "doc.on.doc")
                }
                .buttonStyle(.bordered)
            }

            ScrollView {
                Text(store.logsText().isEmpty ? "暂无日志。" : store.logsText())
                    .font(.system(.body, design: .monospaced))
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(16)
            }
            .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
        }
        .padding(24)
    }

    private func copyLogs() {
        #if canImport(UIKit)
        UIPasteboard.general.string = store.logsText()
        #endif
        copied = true
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) { copied = false }
    }
}
