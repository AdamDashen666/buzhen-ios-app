import Foundation

enum ProviderTransport: String, Codable, CaseIterable, Identifiable {
    case openAICompatible
    case gemini
    case anthropic
    case openAIImages
    case stability
    case replicate
    case fal

    var id: String { rawValue }

    var title: String {
        switch self {
        case .openAICompatible: return "OpenAI 兼容"
        case .gemini: return "Gemini 原生"
        case .anthropic: return "Anthropic 原生"
        case .openAIImages: return "OpenAI 图片"
        case .stability: return "Stability 图片"
        case .replicate: return "Replicate 图片"
        case .fal: return "fal.ai 图片"
        }
    }
}

struct ProviderPreset: Identifiable, Codable, Hashable {
    var id: String
    var name: String
    var transport: ProviderTransport
    var baseURL: String
    var defaultModel: String
    var fallbackModels: [String]
    var notes: String
}

struct ModelEndpointConfig: Codable, Equatable {
    var presetID: String
    var providerName: String
    var transport: ProviderTransport
    var baseURL: String
    var apiKey: String
    var model: String
    var availableModels: [String]
    var temperature: Double
    var maxTokens: Int
    var timeoutSeconds: Double

    static let defaultText = ModelEndpointConfig(
        presetID: TextProviderPresets.openAI.id,
        providerName: TextProviderPresets.openAI.name,
        transport: .openAICompatible,
        baseURL: TextProviderPresets.openAI.baseURL,
        apiKey: "",
        model: TextProviderPresets.openAI.defaultModel,
        availableModels: TextProviderPresets.openAI.fallbackModels,
        temperature: 0.7,
        maxTokens: 12000,
        timeoutSeconds: 180
    )

    static let defaultImage = ModelEndpointConfig(
        presetID: ImageProviderPresets.openAI.id,
        providerName: ImageProviderPresets.openAI.name,
        transport: .openAIImages,
        baseURL: ImageProviderPresets.openAI.baseURL,
        apiKey: "",
        model: ImageProviderPresets.openAI.defaultModel,
        availableModels: ImageProviderPresets.openAI.fallbackModels,
        temperature: 0.0,
        maxTokens: 0,
        timeoutSeconds: 240
    )
}

struct TextProviderPresets {
    static let openAI = ProviderPreset(
        id: "openai",
        name: "OpenAI",
        transport: .openAICompatible,
        baseURL: "https://api.openai.com/v1",
        defaultModel: "gpt-4.1-mini",
        fallbackModels: ["gpt-4.1-mini", "gpt-4.1", "gpt-4o", "gpt-4o-mini"],
        notes: "官方 OpenAI API，支持 /models 与 /chat/completions。"
    )

    static let openRouter = ProviderPreset(
        id: "openrouter",
        name: "OpenRouter",
        transport: .openAICompatible,
        baseURL: "https://openrouter.ai/api/v1",
        defaultModel: "openai/gpt-4o-mini",
        fallbackModels: ["openai/gpt-4o-mini", "openai/gpt-4.1-mini", "anthropic/claude-sonnet-4", "google/gemini-2.5-flash"],
        notes: "统一入口，模型较多，刷新模型会拉 /models。"
    )

    static let deepSeek = ProviderPreset(
        id: "deepseek",
        name: "DeepSeek",
        transport: .openAICompatible,
        baseURL: "https://api.deepseek.com",
        defaultModel: "deepseek-chat",
        fallbackModels: ["deepseek-chat", "deepseek-reasoner"],
        notes: "OpenAI 兼容格式，适合文本规划。"
    )

    static let anthropic = ProviderPreset(
        id: "anthropic",
        name: "Anthropic Claude",
        transport: .anthropic,
        baseURL: "https://api.anthropic.com/v1",
        defaultModel: "claude-sonnet-4-5",
        fallbackModels: ["claude-sonnet-4-5", "claude-3-7-sonnet-latest", "claude-3-5-haiku-latest"],
        notes: "原生 Messages API。"
    )

    static let gemini = ProviderPreset(
        id: "gemini",
        name: "Google Gemini",
        transport: .gemini,
        baseURL: "https://generativelanguage.googleapis.com/v1beta",
        defaultModel: "gemini-2.5-flash",
        fallbackModels: ["gemini-2.5-flash", "gemini-2.5-pro", "gemini-2.0-flash"],
        notes: "原生 Gemini API，刷新模型走 models.list。"
    )

    static let siliconFlow = ProviderPreset(
        id: "siliconflow",
        name: "SiliconFlow",
        transport: .openAICompatible,
        baseURL: "https://api.siliconflow.cn/v1",
        defaultModel: "deepseek-ai/DeepSeek-V3",
        fallbackModels: ["deepseek-ai/DeepSeek-V3", "deepseek-ai/DeepSeek-R1", "Qwen/Qwen2.5-72B-Instruct"],
        notes: "国内常见 OpenAI 兼容聚合。"
    )

    static let volcArk = ProviderPreset(
        id: "volcark",
        name: "火山方舟 / Doubao",
        transport: .openAICompatible,
        baseURL: "https://ark.cn-beijing.volces.com/api/v3",
        defaultModel: "输入你的 Endpoint ID",
        fallbackModels: ["输入你的 Endpoint ID", "doubao-seed-1-6", "doubao-pro-32k"],
        notes: "模型名常用接入点 Endpoint ID。"
    )

    static let dashScope = ProviderPreset(
        id: "dashscope",
        name: "阿里云 DashScope",
        transport: .openAICompatible,
        baseURL: "https://dashscope.aliyuncs.com/compatible-mode/v1",
        defaultModel: "qwen-plus",
        fallbackModels: ["qwen-plus", "qwen-max", "qwen-turbo"],
        notes: "OpenAI 兼容模式。"
    )

    static let moonshot = ProviderPreset(
        id: "moonshot",
        name: "Moonshot / Kimi",
        transport: .openAICompatible,
        baseURL: "https://api.moonshot.cn/v1",
        defaultModel: "moonshot-v1-8k",
        fallbackModels: ["moonshot-v1-8k", "moonshot-v1-32k", "moonshot-v1-128k"],
        notes: "OpenAI 兼容文本接口。"
    )

    static let zhipu = ProviderPreset(
        id: "zhipu",
        name: "智谱 GLM",
        transport: .openAICompatible,
        baseURL: "https://open.bigmodel.cn/api/paas/v4",
        defaultModel: "glm-4-flash",
        fallbackModels: ["glm-4-flash", "glm-4-plus", "glm-4-air"],
        notes: "OpenAI 兼容文本接口。"
    )

    static let custom = ProviderPreset(
        id: "custom-text",
        name: "自定义 OpenAI 兼容",
        transport: .openAICompatible,
        baseURL: "https://your-api-base-url/v1",
        defaultModel: "your-model-name",
        fallbackModels: ["your-model-name"],
        notes: "填自己的 Base URL / Key / Model。"
    )

    static let all: [ProviderPreset] = [openAI, openRouter, deepSeek, anthropic, gemini, siliconFlow, volcArk, dashScope, moonshot, zhipu, custom]
}

struct ImageProviderPresets {
    static let openAI = ProviderPreset(
        id: "openai-image",
        name: "OpenAI Images",
        transport: .openAIImages,
        baseURL: "https://api.openai.com/v1",
        defaultModel: "gpt-image-1",
        fallbackModels: ["gpt-image-1", "dall-e-3", "dall-e-2"],
        notes: "官方图片生成，支持 /images/generations。"
    )

    static let stability = ProviderPreset(
        id: "stability",
        name: "Stability AI",
        transport: .stability,
        baseURL: "https://api.stability.ai",
        defaultModel: "stable-image-core",
        fallbackModels: ["stable-image-core", "stable-image-ultra", "sd3.5-large", "sd3.5-medium"],
        notes: "图片服务通常不完整支持列模型，刷新失败时用内置模型。"
    )

    static let replicate = ProviderPreset(
        id: "replicate",
        name: "Replicate",
        transport: .replicate,
        baseURL: "https://api.replicate.com/v1",
        defaultModel: "black-forest-labs/flux-schnell",
        fallbackModels: ["black-forest-labs/flux-schnell", "black-forest-labs/flux-dev", "ideogram-ai/ideogram-v3-turbo", "stability-ai/sdxl"],
        notes: "适合接 FLUX / SDXL 等公开模型，部分模型需要版本或官方模型入口。"
    )

    static let fal = ProviderPreset(
        id: "fal",
        name: "fal.ai",
        transport: .fal,
        baseURL: "https://fal.run",
        defaultModel: "fal-ai/flux/schnell",
        fallbackModels: ["fal-ai/flux/schnell", "fal-ai/flux/dev", "fal-ai/imagen4/preview", "fal-ai/recraft-v3"],
        notes: "速度快，很多图片模型直接用模型路径。"
    )

    static let siliconFlow = ProviderPreset(
        id: "siliconflow-image",
        name: "SiliconFlow Images",
        transport: .openAIImages,
        baseURL: "https://api.siliconflow.cn/v1",
        defaultModel: "Kwai-Kolors/Kolors",
        fallbackModels: ["Kwai-Kolors/Kolors", "black-forest-labs/FLUX.1-schnell"],
        notes: "OpenAI 风格图片接口，实际可用模型以刷新/后台为准。"
    )

    static let custom = ProviderPreset(
        id: "custom-image",
        name: "自定义 OpenAI 图片兼容",
        transport: .openAIImages,
        baseURL: "https://your-api-base-url/v1",
        defaultModel: "your-image-model",
        fallbackModels: ["your-image-model"],
        notes: "填自己的图片 Base URL / Key / Model。"
    )

    static let all: [ProviderPreset] = [openAI, stability, replicate, fal, siliconFlow, custom]
}
