import SwiftUI

struct CharacterListView: View {
    @EnvironmentObject private var store: ProjectStore

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                SectionHeader(title: "角色设定", subtitle: "AI 会自动提取角色，并生成用于保持一致性的外观锚点。你也可以手动改。")

                if store.project.characters.isEmpty {
                    ContentUnavailableView("还没有角色", systemImage: "person.crop.circle.badge.questionmark", description: Text("先在创作页点击“自动规划漫画”。"))
                } else {
                    ForEach($store.project.characters) { $character in
                        GlassCard(title: character.name.isEmpty ? "未命名角色" : character.name) {
                            TextField("名字", text: $character.name)
                                .textFieldStyle(.roundedBorder)
                            TextField("角色定位", text: $character.role)
                                .textFieldStyle(.roundedBorder)
                            EditableTextBlock(title: "性格", text: $character.personality, minHeight: 58)
                            EditableTextBlock(title: "外观描述", text: $character.visualDescription, minHeight: 70)
                            EditableTextBlock(title: "服装", text: $character.outfit, minHeight: 58)
                            EditableTextBlock(title: "色彩", text: $character.colorPalette, minHeight: 58)
                            EditableTextBlock(title: "角色一致性 Prompt Anchor", text: $character.promptAnchor, minHeight: 90)
                        }
                    }
                }
            }
            .padding(24)
        }
        .onChange(of: store.project.characters) { _ in store.save() }
    }
}
