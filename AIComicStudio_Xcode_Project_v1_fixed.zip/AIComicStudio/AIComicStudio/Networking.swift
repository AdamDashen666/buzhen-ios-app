import Foundation

enum AppError: LocalizedError {
    case invalidURL(String)
    case emptyAPIKey(String)
    case badResponse(Int, String)
    case missingContent(String)
    case jsonParseFailed(String)
    case unsupportedProvider(String)

    var errorDescription: String? {
        switch self {
        case .invalidURL(let url): return "URL 无效：\(url)"
        case .emptyAPIKey(let provider): return "\(provider) 未填写 API Key"
        case .badResponse(let code, let body): return "HTTP \(code)：\(body.prefix(400))"
        case .missingContent(let message): return "返回内容为空：\(message)"
        case .jsonParseFailed(let message): return "JSON 解析失败：\(message)"
        case .unsupportedProvider(let message): return "暂不支持：\(message)"
        }
    }
}

enum NetworkTools {
    static func normalizedBase(_ baseURL: String) -> String {
        var text = baseURL.trimmingCharacters(in: .whitespacesAndNewlines)
        while text.hasSuffix("/") { text.removeLast() }
        return text
    }

    static func url(base: String, path: String) throws -> URL {
        let cleanBase = normalizedBase(base)
        let cleanPath = path.hasPrefix("/") ? path : "/\(path)"
        guard let url = URL(string: cleanBase + cleanPath) else { throw AppError.invalidURL(cleanBase + cleanPath) }
        return url
    }

    static func request(url: URL, method: String = "GET", apiKey: String? = nil, bearerPrefix: String = "Bearer", headers: [String: String] = [:], body: Data? = nil, timeout: Double = 120) -> URLRequest {
        var request = URLRequest(url: url, timeoutInterval: timeout)
        request.httpMethod = method
        if let apiKey, !apiKey.isEmpty {
            request.setValue("\(bearerPrefix) \(apiKey)", forHTTPHeaderField: "Authorization")
        }
        for (key, value) in headers { request.setValue(value, forHTTPHeaderField: key) }
        request.httpBody = body
        return request
    }

    static func perform(_ request: URLRequest) async throws -> Data {
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse else { return data }
        guard (200..<300).contains(http.statusCode) else {
            let body = String(data: data, encoding: .utf8) ?? ""
            throw AppError.badResponse(http.statusCode, body)
        }
        return data
    }

    static func jsonData(_ object: [String: Any]) throws -> Data {
        try JSONSerialization.data(withJSONObject: object, options: [])
    }

    static func jsonObject(from data: Data) throws -> Any {
        try JSONSerialization.jsonObject(with: data, options: [])
    }

    static func extractString(_ json: Any, paths: [[String]]) -> String? {
        for path in paths {
            if let value = valueAtPath(json, path: path) as? String, !value.isEmpty { return value }
        }
        return nil
    }

    static func valueAtPath(_ object: Any, path: [String]) -> Any? {
        var current: Any? = object
        for component in path {
            if let index = Int(component), let array = current as? [Any], array.indices.contains(index) {
                current = array[index]
            } else if let dict = current as? [String: Any] {
                current = dict[component]
            } else {
                return nil
            }
        }
        return current
    }

    static func stringsFromModelListJSON(_ json: Any) -> [String] {
        if let dict = json as? [String: Any] {
            if let data = dict["data"] as? [[String: Any]] {
                return data.compactMap { ($0["id"] as? String) ?? ($0["name"] as? String) }
            }
            if let models = dict["models"] as? [[String: Any]] {
                return models.compactMap { model in
                    if let name = model["name"] as? String {
                        return name.replacingOccurrences(of: "models/", with: "")
                    }
                    return model["id"] as? String
                }
            }
            if let results = dict["results"] as? [[String: Any]] {
                return results.compactMap { model in
                    if let owner = model["owner"] as? String, let name = model["name"] as? String { return "\(owner)/\(name)" }
                    return (model["id"] as? String) ?? (model["name"] as? String)
                }
            }
            if let engines = dict["engines"] as? [[String: Any]] {
                return engines.compactMap { $0["id"] as? String }
            }
        }
        if let array = json as? [[String: Any]] {
            return array.compactMap { ($0["id"] as? String) ?? ($0["name"] as? String) }
        }
        return []
    }

    static func extractFirstJSONObject(from text: String) throws -> Data {
        let cleaned = text
            .replacingOccurrences(of: "```json", with: "")
            .replacingOccurrences(of: "```", with: "")
            .trimmingCharacters(in: .whitespacesAndNewlines)

        if let data = cleaned.data(using: .utf8), (try? JSONSerialization.jsonObject(with: data)) != nil {
            return data
        }

        guard let start = cleaned.firstIndex(of: "{") else { throw AppError.jsonParseFailed("没有找到 JSON 开始符号。") }
        var depth = 0
        var end: String.Index?
        var isInsideString = false
        var previous: Character?

        var index = start
        while index < cleaned.endIndex {
            let ch = cleaned[index]
            if ch == "\"" && previous != "\\" { isInsideString.toggle() }
            if !isInsideString {
                if ch == "{" { depth += 1 }
                if ch == "}" {
                    depth -= 1
                    if depth == 0 { end = cleaned.index(after: index); break }
                }
            }
            previous = ch
            index = cleaned.index(after: index)
        }

        guard let end else { throw AppError.jsonParseFailed("JSON 结尾不完整。") }
        let jsonText = String(cleaned[start..<end])
        guard let data = jsonText.data(using: .utf8) else { throw AppError.jsonParseFailed("无法编码 JSON。") }
        return data
    }

    static func multipartFormData(fields: [String: String], boundary: String) -> Data {
        var data = Data()
        for (key, value) in fields {
            data.appendString("--\(boundary)\r\n")
            data.appendString("Content-Disposition: form-data; name=\"\(key)\"\r\n\r\n")
            data.appendString("\(value)\r\n")
        }
        data.appendString("--\(boundary)--\r\n")
        return data
    }
}

extension Data {
    mutating func appendString(_ string: String) {
        if let data = string.data(using: .utf8) { append(data) }
    }
}
