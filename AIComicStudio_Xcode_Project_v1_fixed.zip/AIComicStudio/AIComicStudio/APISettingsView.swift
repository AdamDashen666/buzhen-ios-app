import SwiftUI

struct APISettingsView: View {
    @EnvironmentObject private var settings: APISettings

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                SectionHeader(
                    title: "API 与模型",
                    subtitle: "文本模型负责写故事/角色/分镜；图片模型负责生成漫画页。先选预设，再填 Key，最后刷新可用模型。"
                )

                APIConfigCard(
                    title: "文本 API 模型",
                    presets: TextProviderPresets.all,
                    config: $settings.textConfig,
                    isRefreshing: settings.isRefreshingTextModels,
                    refreshAction: { Task { await settings.refreshTextModels() } },
                    applyPreset: { settings.applyTextPreset($0) }
                )

                APIConfigCard(
                    title: "图片生成 API 模型",
                    presets: ImageProviderPresets.all,
                    config: $settings.imageConfig,
                    isRefreshing: settings.isRefreshingImageModels,
                    refreshAction: { Task { await settings.refreshImageModels() } },
                    applyPreset: { settings.applyImagePreset($0) }
                )

                GlassCard(title: "生成选项") {
                    Picker("图片尺寸", selection: $settings.imageSize) {
                        Text("竖版漫画页 1024×1536").tag("1024x1536")
                        Text("方图 1024×1024").tag("1024x1024")
                        Text("横版 1536×1024").tag("1536x1024")
                        Text("高清竖版 1024×1792").tag("1024x1792")
                    }
                    Toggle("把 dialogue 写进图片 prompt", isOn: $settings.includeDialogueInImagePrompt)
                    Text("提示：大部分图片模型对中文文字气泡不稳定；如果文字变形，可以关闭这个开关，只生成空白气泡，后期再手动加字。")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }

                if !settings.lastRefreshMessage.isEmpty {
                    Text(settings.lastRefreshMessage)
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                        .padding(.horizontal, 4)
                }
            }
            .padding(24)
        }
        .onChange(of: settings.textConfig) { _ in settings.save() }
        .onChange(of: settings.imageConfig) { _ in settings.save() }
        .onChange(of: settings.imageSize) { _ in settings.save() }
        .onChange(of: settings.includeDialogueInImagePrompt) { _ in settings.save() }
    }
}

struct APIConfigCard: View {
    let title: String
    let presets: [ProviderPreset]
    @Binding var config: ModelEndpointConfig
    let isRefreshing: Bool
    let refreshAction: () -> Void
    let applyPreset: (ProviderPreset) -> Void

    var body: some View {
        GlassCard(title: title) {
            Picker("预设", selection: Binding(
                get: { config.presetID },
                set: { newID in
                    if let preset = presets.first(where: { $0.id == newID }) {
                        applyPreset(preset)
                    }
                }
            )) {
                ForEach(presets) { preset in
                    Text(preset.name).tag(preset.id)
                }
            }

            HStack {
                Label(config.transport.title, systemImage: "point.3.connected.trianglepath.dotted")
                    .font(.caption.weight(.semibold))
                    .padding(.horizontal, 10)
                    .padding(.vertical, 6)
                    .background(.ultraThinMaterial, in: Capsule())
                Spacer()
                LoadingButton(isLoading: isRefreshing, action: refreshAction) {
                    Label("刷新模型", systemImage: "arrow.clockwise")
                }
                .buttonStyle(.bordered)
            }

            TextField("API Base URL", text: $config.baseURL)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .textFieldStyle(.roundedBorder)

            SecureField("API Key", text: $config.apiKey)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .textFieldStyle(.roundedBorder)

            Picker("模型", selection: $config.model) {
                ForEach(config.availableModels, id: \.self) { model in
                    Text(model).tag(model)
                }
                if !config.availableModels.contains(config.model) {
                    Text(config.model).tag(config.model)
                }
            }

            TextField("模型名（可手动输入）", text: $config.model)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .textFieldStyle(.roundedBorder)

            if config.transport == .openAICompatible || config.transport == .gemini || config.transport == .anthropic {
                HStack {
                    VStack(alignment: .leading) {
                        Text("Temperature：\(config.temperature, specifier: "%.2f")")
                            .font(.caption.weight(.semibold))
                        Slider(value: $config.temperature, in: 0...1.5)
                    }
                    Stepper("Max Tokens：\(config.maxTokens)", value: $config.maxTokens, in: 1000...30000, step: 1000)
                        .frame(maxWidth: 260)
                }
            }

            Stepper("超时：\(Int(config.timeoutSeconds)) 秒", value: $config.timeoutSeconds, in: 30...600, step: 30)

            if let preset = presets.first(where: { $0.id == config.presetID }) {
                Text(preset.notes)
                    .font(.footnote)
                    .foregroundStyle(.secondary)
            }
        }
    }
}
