import Foundation

@MainActor
enum ComicPlanningService {
    static func plan(project: ComicProject, settings: APISettings, logger: @escaping (String) -> Void) async throws -> ComicProject {
        if settings.textConfig.apiKey.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            logger("未填写文本 API Key，使用本地兜底规划，方便先看 UI 流程。")
            return fallbackPlan(from: project)
        }

        let systemPrompt = """
        You are a professional AI comic showrunner, manga storyboard artist, character designer, and prompt engineer. Create production-ready comic planning JSON. Always keep character consistency. Output JSON only. No markdown.
        """

        let userPrompt = buildPlanningPrompt(project: project)
        let text = try await TextGenerationService.generateText(prompt: userPrompt, systemPrompt: systemPrompt, config: settings.textConfig)
        let jsonData = try NetworkTools.extractFirstJSONObject(from: text)
        let decoded = try JSONDecoder.iso.decode(AIComicPlanResponse.self, from: jsonData)
        return decoded.toComicProject(previous: project)
    }

    private static func buildPlanningPrompt(project: ComicProject) -> String {
        let modeInstruction: String
        switch project.mode {
        case .story:
            modeInstruction = "The user provided an existing story. Preserve the core plot. Improve clarity only where needed."
        case .idea:
            modeInstruction = "The user provided rough ideas or keywords. First expand them into a complete short comic story, then plan the comic."
        }

        return """
        Create an AI comic project plan from the user's input.

        Mode: \(project.mode.title)
        Instruction: \(modeInstruction)
        Target style: \(project.style.displayName)
        Style prompt: \(project.style.promptStyle)
        Page count: exactly \(project.pageCount)
        Panels per page: about \(project.panelsPerPage), unless story pacing requires a small change.

        User input:
        \(project.sourceInput)

        Requirements:
        1. Extract main characters and make stable visual descriptions.
        2. Create a generatedStory string.
        3. Plan exactly \(project.pageCount) pages.
        4. Each page must include: title, summary, pagePrompt, continuityNotes, panels.
        5. Each panel must include: shotType, setting, action, visualPrompt, narration, dialogue, characters, camera, mood.
        6. Dialogue must be short and usable inside speech bubbles.
        7. pagePrompt must describe the full comic page layout, including panel count and panel flow.
        8. Avoid copyrighted characters, real celebrity likenesses, and explicit adult content.
        9. All JSON string values may be English or Chinese, matching the user's input language when natural.

        Return exactly this JSON shape:
        {
          "title": "",
          "logline": "",
          "generatedStory": "",
          "characters": [
            {
              "name": "",
              "role": "",
              "personality": "",
              "visualDescription": "",
              "outfit": "",
              "colorPalette": "",
              "promptAnchor": ""
            }
          ],
          "pages": [
            {
              "pageNumber": 1,
              "title": "",
              "summary": "",
              "pagePrompt": "",
              "continuityNotes": "",
              "panels": [
                {
                  "panelNumber": 1,
                  "shotType": "",
                  "setting": "",
                  "action": "",
                  "visualPrompt": "",
                  "narration": "",
                  "dialogue": [
                    {"speaker":"", "text":"", "emotion":""}
                  ],
                  "characters": [""],
                  "camera": "",
                  "mood": ""
                }
              ]
            }
          ]
        }
        """
    }

    static func fallbackPlan(from project: ComicProject) -> ComicProject {
        let base = project.sourceInput.isEmpty ? "一个少年发现一本会自动画出未来的漫画书。" : project.sourceInput
        let characters = [
            CharacterProfile(
                name: "主角",
                role: "Protagonist",
                personality: "curious, brave, slightly nervous",
                visualDescription: "young protagonist with expressive eyes and a clear silhouette",
                outfit: "simple jacket, sneakers, small backpack",
                colorPalette: "blue, white, warm yellow",
                promptAnchor: "young protagonist, expressive eyes, simple jacket, small backpack, consistent face and hairstyle"
            ),
            CharacterProfile(
                name: "伙伴",
                role: "Companion",
                personality: "smart, funny, loyal",
                visualDescription: "supporting friend with round glasses and lively expression",
                outfit: "hoodie, short hair, small notebook",
                colorPalette: "green, gray, orange",
                promptAnchor: "supporting friend, round glasses, hoodie, small notebook, lively expression"
            )
        ]

        var pages: [ComicPage] = []
        for pageIndex in 1...max(1, project.pageCount) {
            var panels: [ComicPanel] = []
            for panelIndex in 1...max(1, project.panelsPerPage) {
                let action: String
                if pageIndex == 1 { action = "主角发现异常线索，故事开始推进" }
                else if pageIndex == project.pageCount { action = "主角面对最后选择，情绪达到高潮" }
                else { action = "主角和伙伴追查线索，冲突逐渐升级" }

                panels.append(ComicPanel(
                    panelNumber: panelIndex,
                    shotType: panelIndex == 1 ? "Wide establishing shot" : (panelIndex % 2 == 0 ? "Medium shot" : "Close-up"),
                    setting: pageIndex == 1 ? "ordinary room turning mysterious" : "story location from the user idea",
                    action: action,
                    visualPrompt: "comic panel showing \(action), clear readable composition, expressive character acting",
                    narration: panelIndex == 1 ? "事情从这里开始变得不对劲。" : "",
                    dialogue: [DialogueLine(speaker: panelIndex % 2 == 0 ? "主角" : "伙伴", text: panelIndex % 2 == 0 ? "这不可能只是巧合。" : "你看这里！", emotion: "surprised")],
                    characters: panelIndex % 2 == 0 ? ["主角"] : ["主角", "伙伴"],
                    camera: panelIndex == 1 ? "cinematic wide angle" : "dynamic manga angle",
                    mood: pageIndex == project.pageCount ? "dramatic" : "mysterious"
                ))
            }

            pages.append(ComicPage(
                pageNumber: pageIndex,
                title: "第 \(pageIndex) 页",
                summary: pageIndex == 1 ? "故事开场，主角遇到引发剧情的事件。" : (pageIndex == project.pageCount ? "故事高潮与结尾。" : "冲突升级，角色继续推进目标。"),
                pagePrompt: "Full comic page, \(project.panelsPerPage) panels, \(project.style.promptStyle), based on: \(base)",
                continuityNotes: "保持主角外观一致；同一角色的发型、服装、颜色不要变化。",
                panels: panels
            ))
        }

        return ComicProject(
            id: project.id,
            title: project.title.isEmpty ? "AI 漫画项目" : project.title,
            sourceInput: project.sourceInput,
            generatedStory: base,
            mode: project.mode,
            style: project.style,
            pageCount: project.pageCount,
            panelsPerPage: project.panelsPerPage,
            createdAt: project.createdAt,
            updatedAt: Date(),
            logline: "一个普通设定被意外事件打破，主角必须做出选择。",
            characters: characters,
            pages: pages,
            status: .planned
        )
    }
}

struct AIComicPlanResponse: Codable {
    var title: String
    var logline: String
    var generatedStory: String
    var characters: [AICharacter]
    var pages: [AIPage]

    func toComicProject(previous: ComicProject) -> ComicProject {
        ComicProject(
            id: previous.id,
            title: title.isEmpty ? previous.title : title,
            sourceInput: previous.sourceInput,
            generatedStory: generatedStory,
            mode: previous.mode,
            style: previous.style,
            pageCount: previous.pageCount,
            panelsPerPage: previous.panelsPerPage,
            createdAt: previous.createdAt,
            updatedAt: Date(),
            logline: logline,
            characters: characters.map { $0.toDomain() },
            pages: pages.sorted(by: { $0.pageNumber < $1.pageNumber }).map { $0.toDomain() },
            status: .planned
        )
    }
}

struct AICharacter: Codable {
    var name: String
    var role: String
    var personality: String
    var visualDescription: String
    var outfit: String
    var colorPalette: String
    var promptAnchor: String

    func toDomain() -> CharacterProfile {
        CharacterProfile(name: name, role: role, personality: personality, visualDescription: visualDescription, outfit: outfit, colorPalette: colorPalette, promptAnchor: promptAnchor)
    }
}

struct AIPage: Codable {
    var pageNumber: Int
    var title: String
    var summary: String
    var pagePrompt: String
    var continuityNotes: String
    var panels: [AIPanel]

    func toDomain() -> ComicPage {
        ComicPage(pageNumber: pageNumber, title: title, summary: summary, pagePrompt: pagePrompt, continuityNotes: continuityNotes, panels: panels.sorted(by: { $0.panelNumber < $1.panelNumber }).map { $0.toDomain() })
    }
}

struct AIPanel: Codable {
    var panelNumber: Int
    var shotType: String
    var setting: String
    var action: String
    var visualPrompt: String
    var narration: String
    var dialogue: [AIDialogue]
    var characters: [String]
    var camera: String
    var mood: String

    func toDomain() -> ComicPanel {
        ComicPanel(panelNumber: panelNumber, shotType: shotType, setting: setting, action: action, visualPrompt: visualPrompt, narration: narration, dialogue: dialogue.map { $0.toDomain() }, characters: characters, camera: camera, mood: mood)
    }
}

struct AIDialogue: Codable {
    var speaker: String
    var text: String
    var emotion: String

    func toDomain() -> DialogueLine {
        DialogueLine(speaker: speaker, text: text, emotion: emotion)
    }
}
