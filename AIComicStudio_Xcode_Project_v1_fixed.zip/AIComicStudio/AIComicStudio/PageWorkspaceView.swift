import SwiftUI

struct PageWorkspaceView: View {
    @EnvironmentObject private var store: ProjectStore
    @EnvironmentObject private var apiSettings: APISettings

    var body: some View {
        HStack(spacing: 0) {
            pageList
                .frame(minWidth: 260, idealWidth: 300, maxWidth: 340)
                .background(.thinMaterial)

            Divider()

            if let pageBinding = store.selectedPageBinding() {
                PageDetailView(page: pageBinding)
            } else {
                ContentUnavailableView("还没有页面", systemImage: "square.grid.2x2", description: Text("先点击“自动规划漫画”，或者载入示例项目。"))
            }
        }
        .navigationTitle("页面分镜")
    }

    private var pageList: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text("页面")
                    .font(.title2.bold())
                Spacer()
                Button {
                    Task { await store.generateAllPages(settings: apiSettings) }
                } label: {
                    Image(systemName: "photo.stack")
                }
                .disabled(store.project.pages.isEmpty || store.isBusy)
            }
            .padding([.top, .horizontal], 16)

            if store.project.pages.isEmpty {
                Spacer()
                ContentUnavailableView("无页面", systemImage: "doc.badge.plus")
                Spacer()
            } else {
                ScrollView {
                    LazyVStack(spacing: 10) {
                        ForEach(store.project.pages) { page in
                            Button {
                                store.selectedPageID = page.id
                            } label: {
                                PageListRow(page: page, isSelected: page.id == store.selectedPageID)
                            }
                            .buttonStyle(.plain)
                        }
                    }
                    .padding(12)
                }
            }
        }
    }
}

struct PageListRow: View {
    let page: ComicPage
    let isSelected: Bool

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text("第 \(page.pageNumber) 页")
                    .font(.headline)
                Spacer()
                StatusPill(status: page.status)
            }
            Text(page.title)
                .font(.subheadline.weight(.semibold))
            Text(page.summary)
                .font(.caption)
                .foregroundStyle(.secondary)
                .lineLimit(2)
        }
        .padding(12)
        .background(isSelected ? Color.blue.opacity(0.18) : Color(.secondarySystemBackground).opacity(0.55), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 16).strokeBorder(isSelected ? Color.blue.opacity(0.4) : Color.secondary.opacity(0.12)))
    }
}

struct PageDetailView: View {
    @EnvironmentObject private var store: ProjectStore
    @EnvironmentObject private var apiSettings: APISettings
    @Binding var page: ComicPage

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                HStack(alignment: .top) {
                    SectionHeader(title: "第 \(page.pageNumber) 页 · \(page.title)", subtitle: "查看和修改这一页的规划，也可以单独生成这一页。")
                    Spacer()
                    VStack(alignment: .trailing, spacing: 8) {
                        StatusPill(status: page.status)
                        LoadingButton(isLoading: store.isBusy) {
                            Task { await store.generateSelectedPage(settings: apiSettings) }
                        } label: {
                            Label("生成本页", systemImage: "photo")
                        }
                        .buttonStyle(.borderedProminent)
                    }
                }

                if let error = page.errorMessage, !error.isEmpty {
                    Text(error)
                        .font(.footnote)
                        .foregroundStyle(.red)
                        .padding(12)
                        .background(.red.opacity(0.08), in: RoundedRectangle(cornerRadius: 12))
                }

                if let data = page.imageData {
                    GlassCard(title: "生成结果") {
                        PlatformImageView(data: data)
                            .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                    }
                }

                GlassCard(title: "页面规划") {
                    TextField("页面标题", text: $page.title)
                        .textFieldStyle(.roundedBorder)
                    EditableTextBlock(title: "摘要", text: $page.summary, minHeight: 70)
                    EditableTextBlock(title: "整页图片 Prompt", text: $page.pagePrompt, minHeight: 120)
                    EditableTextBlock(title: "连续性备注", text: $page.continuityNotes, minHeight: 80)
                }

                GlassCard(title: "分镜 / Dialogue") {
                    ForEach($page.panels) { $panel in
                        PanelEditor(panel: $panel)
                        if panel.id != page.panels.last?.id { Divider() }
                    }
                }
            }
            .padding(24)
        }
    }
}

struct PanelEditor: View {
    @Binding var panel: ComicPanel

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text("Panel \(panel.panelNumber)")
                    .font(.headline)
                Spacer()
                Text(panel.shotType)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            TextField("镜头类型", text: $panel.shotType)
                .textFieldStyle(.roundedBorder)
            TextField("场景", text: $panel.setting)
                .textFieldStyle(.roundedBorder)
            EditableTextBlock(title: "动作", text: $panel.action, minHeight: 58)
            EditableTextBlock(title: "视觉 Prompt", text: $panel.visualPrompt, minHeight: 80)
            HStack {
                TextField("Camera", text: $panel.camera)
                    .textFieldStyle(.roundedBorder)
                TextField("Mood", text: $panel.mood)
                    .textFieldStyle(.roundedBorder)
            }
            EditableTextBlock(title: "旁白", text: $panel.narration, minHeight: 58)
            TextField("出现角色，用逗号分隔", text: Binding(
                get: { panel.characters.joined(separator: ", ") },
                set: { panel.characters = $0.split(separator: ",").map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }.filter { !$0.isEmpty } }
            ))
            .textFieldStyle(.roundedBorder)

            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    Text("Dialogue")
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(.secondary)
                    Spacer()
                    Button {
                        panel.dialogue.append(DialogueLine(speaker: "", text: "", emotion: ""))
                    } label: {
                        Label("添加台词", systemImage: "plus.bubble")
                    }
                    .font(.caption)
                }
                ForEach($panel.dialogue) { $line in
                    HStack {
                        TextField("角色", text: $line.speaker)
                            .textFieldStyle(.roundedBorder)
                            .frame(maxWidth: 130)
                        TextField("台词", text: $line.text)
                            .textFieldStyle(.roundedBorder)
                        TextField("情绪", text: $line.emotion)
                            .textFieldStyle(.roundedBorder)
                            .frame(maxWidth: 120)
                    }
                }
            }
        }
        .padding(.vertical, 8)
    }
}
