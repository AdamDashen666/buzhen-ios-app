#!/usr/bin/env python3
"""Small deterministic iOS compatibility patch for the downloaded original Mineradio public bundle.
This does not redesign the UI; it only expands iPad-safe limits before the bundle is copied into the IPA.
"""
from __future__ import annotations
import sys
import re
from pathlib import Path

root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path.cwd()
index = root / "index.html"
if not index.exists():
    print(f"[Mineradio iOS Patch] index.html not found: {index}", file=sys.stderr)
    sys.exit(1)

s = index.read_text(encoding="utf-8")
# Prefer an iPad-stable viewport so keyboard/safe-area changes do not make the original desktop UI jump.
s2, n = re.subn(r'<meta name="viewport" content="[^"]*">', '<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">', s, count=1)
if n:
    s = s2

replacements = {
    'id="fx-coverres" type="range" min="0.75" max="1.55" step="0.01"':
    'id="fx-coverres" type="range" min="0.75" max="4.91" step="0.01"',
    'function normalizeCoverResolution(v) {\n  return clampRange(Number(v) || 1, 0.75, 1.55);\n}':
    'function normalizeCoverResolution(v) {\n  return clampRange(Number(v) || 1, 0.75, 4.91);\n}',
    'function coverParticleGridForResolution(v) {\n  var grid = Math.round(118 * normalizeCoverResolution(v));\n  grid = Math.max(88, Math.min(183, grid));\n  return grid % 2 ? grid : grid + 1;\n}':
    'function coverParticleGridForResolution(v) {\n  var grid = Math.round(118 * normalizeCoverResolution(v));\n  grid = Math.max(88, Math.min(579, grid));\n  return grid % 2 ? grid : grid + 1;\n}',
    'function coverTextureSizeForResolution(v) {\n  v = normalizeCoverResolution(v);\n  if (v >= 1.32) return 512;\n  if (v >= 1.10) return 384;\n  return 256;\n}':
    'function coverTextureSizeForResolution(v) {\n  v = normalizeCoverResolution(v);\n  if (v >= 3.20) return 1024;\n  if (v >= 1.32) return 512;\n  if (v >= 1.10) return 384;\n  return 256;\n}',
}
changed = 0
for old, new in replacements.items():
    if old in s:
        s = s.replace(old, new)
        changed += 1
    else:
        print(f"[Mineradio iOS Patch] exact pattern not found; trying regex fallback: {old[:80]}...", file=sys.stderr)

# Regex fallback keeps the patch stable if upstream only changes whitespace / current limits.
regex_replacements = [
    (r'id="fx-coverres"\s+type="range"\s+min="0\.75"\s+max="[0-9.]+"\s+step="0\.01"',
     'id="fx-coverres" type="range" min="0.75" max="4.91" step="0.01"'),
    (r'function\s+normalizeCoverResolution\s*\(v\)\s*\{\s*return\s+clampRange\(Number\(v\)\s*\|\|\s*1,\s*0\.75,\s*[0-9.]+\);\s*\}',
     'function normalizeCoverResolution(v) {\n  return clampRange(Number(v) || 1, 0.75, 4.91);\n}'),
    (r'function\s+coverParticleGridForResolution\s*\(v\)\s*\{\s*var\s+grid\s*=\s*Math\.round\(118\s*\*\s*normalizeCoverResolution\(v\)\);\s*grid\s*=\s*Math\.max\(88,\s*Math\.min\([0-9]+,\s*grid\)\);\s*return\s+grid\s*%\s*2\s*\?\s*grid\s*:\s*grid\s*\+\s*1;\s*\}',
     'function coverParticleGridForResolution(v) {\n  var grid = Math.round(118 * normalizeCoverResolution(v));\n  grid = Math.max(88, Math.min(579, grid));\n  return grid % 2 ? grid : grid + 1;\n}'),
    (r'function\s+coverTextureSizeForResolution\s*\(v\)\s*\{\s*v\s*=\s*normalizeCoverResolution\(v\);\s*(?:if\s*\(v\s*>=\s*[0-9.]+\)\s*return\s*[0-9]+;\s*)+return\s+256;\s*\}',
     'function coverTextureSizeForResolution(v) {\n  v = normalizeCoverResolution(v);\n  if (v >= 3.20) return 1024;\n  if (v >= 1.32) return 512;\n  if (v >= 1.10) return 384;\n  return 256;\n}'),
]
for pattern, repl in regex_replacements:
    s2, n = re.subn(pattern, repl, s, count=1, flags=re.S)
    if n:
        s = s2
        changed += n

# Prevent iOS text-selection artifacts at the source layer as well as in the bridge.
css = """
<style id="mineradio-ios-static-fixes">
html,body,#desktop-window-shell,#canvas-container,canvas{-webkit-user-select:none!important;user-select:none!important;-webkit-touch-callout:none!important;touch-action:none!important;overscroll-behavior:none!important}
img,svg,canvas{-webkit-user-drag:none!important;user-drag:none!important}
input,textarea,[contenteditable="true"]{-webkit-user-select:text!important;user-select:text!important;touch-action:manipulation!important}
</style>
""".strip()
if "mineradio-ios-static-fixes" not in s:
    s = s.replace("</head>", css + "\n</head>")
    changed += 1



# iOS startup splash should never trap the user. The original desktop splash waits until
# a 5s ready flag before click enters; WKWebView + our touch prevention can make the
# first click/touch unreliable. Patch the original source so any iOS tap/mouse release
# can enter, and add a timed auto-enter fallback.
splash_click_patch_old = """  function requestSplashEnter() {\n    playMineradioIntroSound();\n    if (splashReadyToEnter) dismissSplash();\n  }\n  s.addEventListener('click', requestSplashEnter);"""
splash_click_patch_new = """  function requestSplashEnter(e) {\n    if (e && e.cancelable) e.preventDefault();\n    playMineradioIntroSound();\n    splashReadyToEnter = true;\n    dismissSplash();\n  }\n  s.addEventListener('click', requestSplashEnter, { passive: false });\n  s.addEventListener('pointerdown', requestSplashEnter, { passive: false });\n  s.addEventListener('pointerup', requestSplashEnter, { passive: false });\n  s.addEventListener('touchend', requestSplashEnter, { passive: false });\n  s.addEventListener('mouseup', requestSplashEnter, { passive: false });"""
if splash_click_patch_old in s:
    s = s.replace(splash_click_patch_old, splash_click_patch_new)
    changed += 1
else:
    s2, n = re.subn(
        r"  function requestSplashEnter\(\) \{\s*playMineradioIntroSound\(\);\s*if \(splashReadyToEnter\) dismissSplash\(\);\s*\}\s*  s\.addEventListener\('click', requestSplashEnter\);",
        splash_click_patch_new,
        s,
        count=1,
        flags=re.S,
    )
    if n:
        s = s2
        changed += n
    else:
        print('[Mineradio iOS Patch] splash request patch pattern not found', file=sys.stderr)

splash_timer_old = """  splashTimer = setTimeout(markSplashReadyToEnter, 5000);"""
splash_timer_new = """  splashTimer = setTimeout(markSplashReadyToEnter, 1200);\n  setTimeout(function(){\n    try {\n      if (document.body && document.body.classList.contains('splash-active')) {\n        splashReadyToEnter = true;\n        dismissSplash();\n      }\n    } catch (_) {}\n  }, 2600);"""
if splash_timer_old in s:
    s = s.replace(splash_timer_old, splash_timer_new)
    changed += 1
else:
    s2, n = re.subn(r"  splashTimer\s*=\s*setTimeout\(markSplashReadyToEnter,\s*5000\);", splash_timer_new, s, count=1)
    if n:
        s = s2
        changed += n
    else:
        print('[Mineradio iOS Patch] splash timer patch pattern not found', file=sys.stderr)

# Add iOS-only audio terrain visual preset. It is injected into the downloaded original
# frontend at build time so the effect lives inside the original WebGL visual layer,
# while remaining removable/upstream-safe.
audio_terrain = r"""
<style id="mineradio-ios-audio-terrain-style">
#mineradio-ios-terrain-root{position:fixed;inset:0;z-index:2;opacity:0;visibility:hidden;pointer-events:none;transition:opacity .55s cubic-bezier(.16,1,.3,1),visibility 0s linear .55s;background:radial-gradient(circle at 50% 38%,rgba(255,210,168,.13),rgba(24,66,94,.12) 26%,rgba(0,0,0,.78) 72%,rgba(0,0,0,.94));overflow:hidden;touch-action:none;-webkit-user-select:none;user-select:none;-webkit-touch-callout:none}
body.ios-audio-terrain-active #mineradio-ios-terrain-root{opacity:1;visibility:visible;pointer-events:auto;transition:opacity .55s cubic-bezier(.16,1,.3,1)}
#mineradio-ios-terrain-canvas{position:absolute;inset:0;width:100%;height:100%;display:block;touch-action:none;-webkit-user-select:none;user-select:none}
#mineradio-ios-terrain-root::before{content:'';position:absolute;inset:-8%;z-index:2;pointer-events:none;background:radial-gradient(ellipse at 50% 44%,rgba(255,214,172,.12),transparent 24%),radial-gradient(ellipse at 50% 50%,transparent 32%,rgba(7,24,38,.38) 58%,rgba(0,0,0,.85) 92%);mix-blend-mode:screen;opacity:.92}
#mineradio-ios-terrain-root::after{content:'';position:absolute;inset:0;z-index:3;pointer-events:none;background:linear-gradient(180deg,rgba(0,0,0,.02),rgba(0,0,0,.34)),radial-gradient(ellipse at center,transparent 42%,rgba(0,0,0,.70) 100%)}
#mineradio-ios-terrain-title{position:absolute;z-index:4;left:50%;top:58%;transform:translate(-50%,-50%);font-family:var(--font-sans,"PingFang SC",system-ui,sans-serif;font-size:clamp(30px,5.2vw,70px);line-height:1.05;font-weight:900;letter-spacing:.01em;white-space:nowrap;color:#eaf6ff;text-shadow:0 3px 0 rgba(0,0,0,.58),0 0 12px rgba(154,215,255,.42),0 0 38px rgba(117,189,255,.34);opacity:.92;pointer-events:none;max-width:88vw;overflow:hidden;text-overflow:ellipsis}
#mineradio-ios-terrain-hint{position:absolute;z-index:4;left:50%;top:calc(58% + clamp(42px,7vw,86px));transform:translateX(-50%);font-family:var(--font-sans,"PingFang SC",system-ui,sans-serif;font-size:12px;font-weight:700;letter-spacing:.18em;text-transform:uppercase;color:rgba(190,226,255,.58);text-shadow:0 0 18px rgba(86,170,255,.38);opacity:.72;pointer-events:none}
body.ios-audio-terrain-active #empty-home,body.ios-audio-terrain-active #visualizer,body.ios-audio-terrain-active #stage-lyrics{opacity:0!important;pointer-events:none!important}
body.ios-audio-terrain-active #canvas-container canvas{opacity:.08!important}
.ios-audio-terrain-preset-card{cursor:pointer!important;position:relative!important;overflow:hidden!important}
.ios-audio-terrain-preset-card::after{content:'3D';position:absolute;right:14px;top:12px;font-size:10px;font-weight:900;letter-spacing:.16em;color:rgba(159,218,255,.75);text-shadow:0 0 14px rgba(95,185,255,.72)}
.ios-audio-terrain-preset-card.active{border-color:rgba(142,214,255,.62)!important;box-shadow:0 0 0 1px rgba(142,214,255,.25),0 18px 60px rgba(61,151,255,.14),inset 0 1px 0 rgba(255,255,255,.12)!important;background:linear-gradient(145deg,rgba(75,116,138,.24),rgba(9,12,18,.76))!important}
#mineradio-ios-terrain-chip{position:fixed;right:22px;bottom:92px;z-index:45;width:48px;height:48px;border-radius:50%;border:1px solid rgba(165,217,255,.22);background:rgba(18,24,32,.45);color:rgba(231,247,255,.78);display:flex;align-items:center;justify-content:center;font:900 11px/1 var(--font-sans,"PingFang SC",system-ui);letter-spacing:.04em;box-shadow:0 14px 42px rgba(0,0,0,.32),inset 0 1px 0 rgba(255,255,255,.09);backdrop-filter:blur(18px);-webkit-backdrop-filter:blur(18px);opacity:.72;transition:opacity .18s,transform .18s,box-shadow .18s}
#mineradio-ios-terrain-chip:hover,#mineradio-ios-terrain-chip.active{opacity:1;transform:translateY(-1px);box-shadow:0 18px 54px rgba(66,160,255,.22),inset 0 1px 0 rgba(255,255,255,.16)}
body.controls-visible #mineradio-ios-terrain-chip{bottom:126px}
</style>
<script id="mineradio-ios-audio-terrain-script">
(function(){
  if (window.__mineradioIOSAudioTerrainInstalled) return;
  window.__mineradioIOSAudioTerrainInstalled = true;
  var state = { enabled:false, ready:false, renderer:null, scene:null, camera:null, group:null, points:null, positions:null, colors:null, grid:168, freq:null, raf:0, yaw:0, pitch:0.72, zoom:1, pointer:false, lastX:0, lastY:0, energy:0, root:null, canvas:null, title:null };
  function clamp(v,a,b){ return Math.max(a, Math.min(b, v)); }
  function cleanTitle(t){ return String(t||'').replace(/^[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12}[-_\s]*/,'').replace(/\s*[-—–]\s*(本地文件|本地|local file)\s*$/i,'').replace(/\s*\|\s*(本地文件|本地|local file)\s*$/i,'').trim(); }
  function currentTitle(){ try { if (window.currentSong && currentSong.name) return cleanTitle(currentSong.name); } catch(e){} try { if (window.currentLocalSong && currentLocalSong.name) return cleanTitle(currentLocalSong.name); } catch(e){} var el=document.getElementById('thumb-title')||document.getElementById('control-title'); return cleanTitle(el&&el.textContent) || 'Mineradio'; }
  function isUiAt(x,y){ var el=document.elementFromPoint(x,y); return !!(el&&el.closest&&el.closest('button,input,textarea,select,a,[role="button"],#bottom-bar,#controls,#top-right,#search-area,#fx-panel,#fx-fab,#login-modal,.icon-btn,.home-card,.home-tile')); }
  function ensureDom(){
    if (state.root) return;
    var root=document.createElement('div'); root.id='mineradio-ios-terrain-root';
    var canvas=document.createElement('canvas'); canvas.id='mineradio-ios-terrain-canvas';
    var title=document.createElement('div'); title.id='mineradio-ios-terrain-title'; title.textContent=currentTitle();
    var hint=document.createElement('div'); hint.id='mineradio-ios-terrain-hint'; hint.textContent='Audio Terrain';
    root.appendChild(canvas); root.appendChild(title); root.appendChild(hint); document.body.appendChild(root);
    state.root=root; state.canvas=canvas; state.title=title;
    canvas.addEventListener('pointerdown',function(e){ if(isUiAt(e.clientX,e.clientY)) return; state.pointer=true; state.lastX=e.clientX; state.lastY=e.clientY; try{canvas.setPointerCapture(e.pointerId)}catch(_){} e.preventDefault(); },{passive:false});
    canvas.addEventListener('pointermove',function(e){ if(!state.pointer) return; var dx=e.clientX-state.lastX, dy=e.clientY-state.lastY; state.lastX=e.clientX; state.lastY=e.clientY; state.yaw += dx*0.0045; state.pitch=clamp(state.pitch+dy*0.0032,0.18,1.32); e.preventDefault(); },{passive:false});
    canvas.addEventListener('pointerup',function(e){ state.pointer=false; e.preventDefault(); },{passive:false});
    canvas.addEventListener('pointercancel',function(){ state.pointer=false; },{passive:false});
    canvas.addEventListener('wheel',function(e){ state.zoom=clamp(state.zoom+e.deltaY*0.0012,0.62,1.72); e.preventDefault(); },{passive:false});
    var chip=document.createElement('button'); chip.id='mineradio-ios-terrain-chip'; chip.type='button'; chip.textContent='音域'; chip.title='音域回响'; chip.addEventListener('click',function(){ window.mineradioIOSAudioTerrain.toggle(); }); document.body.appendChild(chip);
  }
  function buildScene(){
    if (state.ready || !window.THREE) return !!state.ready;
    ensureDom();
    var THREE=window.THREE, canvas=state.canvas;
    var renderer=new THREE.WebGLRenderer({ canvas:canvas, alpha:true, antialias:false, powerPreference:'high-performance' });
    renderer.setClearColor(0x000000,0); renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,1.45));
    var scene=new THREE.Scene(); scene.fog=new THREE.FogExp2(0x06131d,0.055);
    var camera=new THREE.PerspectiveCamera(48,innerWidth/innerHeight,0.1,110);
    var group=new THREE.Group(); scene.add(group);
    var n=state.grid, total=n*n, span=34;
    var positions=new Float32Array(total*3), colors=new Float32Array(total*3); var k=0;
    for(var z=0;z<n;z++) for(var x=0;x<n;x++){ var px=(x/(n-1)-0.5)*span, pz=(z/(n-1)-0.5)*span; positions[k*3]=px; positions[k*3+1]=0; positions[k*3+2]=pz; colors[k*3]=0.28; colors[k*3+1]=0.70; colors[k*3+2]=1.00; k++; }
    var geo=new THREE.BufferGeometry(); geo.setAttribute('position',new THREE.BufferAttribute(positions,3)); geo.setAttribute('color',new THREE.BufferAttribute(colors,3));
    var mat=new THREE.PointsMaterial({ size:0.072, vertexColors:true, transparent:true, opacity:0.94, depthWrite:false, blending:THREE.AdditiveBlending, fog:true });
    var points=new THREE.Points(geo,mat); group.add(points);
    var ringGeo=new THREE.RingGeometry(6.3,6.55,192); var ringMat=new THREE.MeshBasicMaterial({ color:0x88d9ff, transparent:true, opacity:.10, side:THREE.DoubleSide, blending:THREE.AdditiveBlending });
    var ring=new THREE.Mesh(ringGeo,ringMat); ring.rotation.x=-Math.PI/2; ring.position.y=.03; group.add(ring);
    state.renderer=renderer; state.scene=scene; state.camera=camera; state.group=group; state.points=points; state.positions=positions; state.colors=colors; state.ring=ring; state.ready=true; resize(); return true;
  }
  function resize(){ if(!state.renderer||!state.camera) return; var w=innerWidth,h=innerHeight; state.renderer.setSize(w,h,false); state.camera.aspect=w/h; state.camera.updateProjectionMatrix(); }
  window.addEventListener('resize',resize,{passive:true});
  function getAnalyser(){ try { if (window.beatAnalyser && beatAnalyser.getByteFrequencyData) return beatAnalyser; } catch(e){} try { if (window.analyser && analyser.getByteFrequencyData) return analyser; } catch(e){} return null; }
  function updateTerrain(t){
    var n=state.grid, span=34, pos=state.positions, col=state.colors, freq=state.freq || (state.freq=new Uint8Array(1024));
    var an=getAnalyser(); if(an){ try{ if(freq.length !== an.frequencyBinCount) freq=new Uint8Array(an.frequencyBinCount); an.getByteFrequencyData(freq); state.freq=freq; }catch(e){} }
    var energy=0; for(var i=3;i<Math.min(freq.length,96);i++) energy+=freq[i]||0; energy/=Math.max(1,Math.min(freq.length,96)-3); energy/=255; state.energy=state.energy*.88+energy*.12;
    var k=0, time=t*0.001, centerBoost=1+state.energy*1.8;
    for(var z=0;z<n;z++) for(var x=0;x<n;x++){
      var px=(x/(n-1)-0.5)*span, pz=(z/(n-1)-0.5)*span; var r=Math.sqrt(px*px+pz*pz), a=Math.atan2(pz,px);
      var bin=clamp(Math.floor((r/24)*freq.length),0,freq.length-1); var f=(freq[bin]||0)/255;
      var island=Math.exp(-r*r/82); var ring=Math.exp(-Math.pow(r-8.4,2)/7.2)*0.55 + Math.exp(-Math.pow(r-14.0,2)/11)*0.25; var wave=(Math.sin(r*1.45-time*2.2+a*2.0)+1)*0.5;
      var spike=Math.pow(f,1.55)*(0.8+island*3.8+ring*1.6); var y=(island*2.2*centerBoost + ring*(0.7+wave*.8) + spike*4.6 + Math.sin(px*2.0+pz*.7+time)*0.10); if(r>18.5) y*=Math.max(0,1-(r-18.5)/5.5);
      pos[k*3+1]=y; var warm=clamp(island*1.2 + f*0.55,0,1), blue=clamp(0.38+ring+wave*.25,0,1), fade=clamp(1-r/22,0,1);
      col[k*3]=0.18+warm*.92+f*.20; col[k*3+1]=0.42+warm*.46+blue*.28; col[k*3+2]=0.62+blue*.48-fade*.16; k++;
    }
    state.points.geometry.attributes.position.needsUpdate=true; state.points.geometry.attributes.color.needsUpdate=true;
    var radius=26*state.zoom, yaw=state.yaw+time*.035, pitch=state.pitch; state.camera.position.set(Math.sin(yaw)*radius, Math.sin(pitch)*19+4, Math.cos(yaw)*radius); state.camera.lookAt(0,1.6,0); state.group.rotation.y=time*.025;
    if(state.ring){ state.ring.scale.setScalar(1+state.energy*.32+Math.sin(time*1.8)*.025); state.ring.material.opacity=.06+state.energy*.16; }
    if(state.title) state.title.textContent=currentTitle();
  }
  function loop(t){ if(!state.enabled) return; if(!buildScene()){ state.raf=requestAnimationFrame(loop); return; } updateTerrain(t||performance.now()); state.renderer.render(state.scene,state.camera); state.raf=requestAnimationFrame(loop); }
  function setEnabled(on){ ensureDom(); state.enabled=!!on; document.body.classList.toggle('ios-audio-terrain-active',state.enabled); var chip=document.getElementById('mineradio-ios-terrain-chip'); if(chip) chip.classList.toggle('active',state.enabled); var cards=document.querySelectorAll('.ios-audio-terrain-preset-card'); for(var i=0;i<cards.length;i++) cards[i].classList.toggle('active',state.enabled); try{ localStorage.setItem('mineradio-ios-audio-terrain-enabled',state.enabled?'1':'0'); }catch(e){} if(state.enabled){ if(state.title) state.title.textContent=currentTitle(); cancelAnimationFrame(state.raf); state.raf=requestAnimationFrame(loop); try{ if(typeof showToast==='function') showToast('音域回响已开启'); }catch(e){} } else { cancelAnimationFrame(state.raf); try{ if(typeof showToast==='function') showToast('音域回响已关闭'); }catch(e){} } }
  function installPresetCard(){ if(document.querySelector('.ios-audio-terrain-preset-card')) return; var candidates=Array.prototype.slice.call(document.querySelectorAll('button,div')); var sample=null; for(var i=0;i<candidates.length;i++){ var el=candidates[i], text=(el.textContent||'').trim(); if(text.indexOf('星河')>=0 && el.getBoundingClientRect && el.getBoundingClientRect().width>90 && el.getBoundingClientRect().height>45){ sample=el; break; } } if(!sample) return; var card=sample.cloneNode(true); card.classList.add('ios-audio-terrain-preset-card'); card.setAttribute('data-ios-preset','audio-terrain'); card.innerHTML='<div style="font-weight:850;font-size:15px;margin-bottom:8px">音域回响</div><div style="font-size:12px;color:rgba(255,255,255,.55);line-height:1.45">3D声场地形 · 频谱城市</div>'; card.addEventListener('click',function(e){ e.preventDefault(); e.stopPropagation(); setEnabled(true); },true); sample.parentNode.insertBefore(card,sample.nextSibling); }
  window.mineradioIOSAudioTerrain={ enable:function(){setEnabled(true)}, disable:function(){setEnabled(false)}, toggle:function(){setEnabled(!state.enabled)}, state:state };
  function boot(){ ensureDom(); installPresetCard(); if(localStorage.getItem('mineradio-ios-audio-terrain-enabled')==='1') setEnabled(true); }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',boot,{once:true}); else boot();
  var mo=new MutationObserver(function(){ installPresetCard(); }); mo.observe(document.documentElement,{childList:true,subtree:true});
})();
</script>
""".strip()
if 'mineradio-ios-audio-terrain-script' not in s:
    s = s.replace('</body>', audio_terrain + '\n</body>')
    changed += 1

index.write_text(s, encoding="utf-8")
print(f"[Mineradio iOS Patch] applied {changed} compatibility edits to {index}")
