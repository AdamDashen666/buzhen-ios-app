import SwiftUI
import WebKit
import UIKit
import UniformTypeIdentifiers
import AVFoundation

struct MineradioWebShellView: UIViewRepresentable {
    func makeCoordinator() -> Coordinator {
        Coordinator()
    }

    func makeUIView(context: Context) -> WKWebView {
        let configuration = WKWebViewConfiguration()
        configuration.allowsInlineMediaPlayback = true
        configuration.mediaTypesRequiringUserActionForPlayback = []
        configuration.preferences.javaScriptCanOpenWindowsAutomatically = true
        if #available(iOS 14.0, *) {
            configuration.defaultWebpagePreferences.allowsContentJavaScript = true
        }

        let contentController = WKUserContentController()
        contentController.addUserScript(WKUserScript(source: Self.bridgeScript, injectionTime: .atDocumentStart, forMainFrameOnly: false))
        contentController.add(context.coordinator, name: "mineradioIOS")
        configuration.userContentController = contentController

        let webView = WKWebView(frame: .zero, configuration: configuration)
        context.coordinator.webView = webView
        webView.navigationDelegate = context.coordinator
        webView.uiDelegate = context.coordinator
        webView.isOpaque = false
        webView.backgroundColor = .black
        webView.scrollView.backgroundColor = .black
        webView.scrollView.bounces = false
        webView.scrollView.isScrollEnabled = false
        webView.scrollView.contentInsetAdjustmentBehavior = .never
        webView.allowsBackForwardNavigationGestures = false
        Self.configureAudioSessionForBackgroundPlayback()

        webView.customUserAgent = "Mozilla/5.0 (iPad; CPU OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) MineradioElectronCompat/1.0 Mobile/15E148 Safari/604.1"

        loadOriginalMineradio(in: webView)
        return webView
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {}

    private static func configureAudioSessionForBackgroundPlayback() {
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default, options: [.allowAirPlay, .allowBluetoothHFP])
            try AVAudioSession.sharedInstance().setActive(true)
        } catch {
            #if DEBUG
            print("Mineradio audio session error:", error)
            #endif
        }
    }

    private func loadOriginalMineradio(in webView: WKWebView) {
        guard let resourceURL = Bundle.main.resourceURL else {
            webView.loadHTMLString(Self.failureHTML("Bundle resourceURL 不可用"), baseURL: nil)
            return
        }
        let webRoot = resourceURL.appendingPathComponent("MineradioWeb", isDirectory: true)
        let indexURL = webRoot.appendingPathComponent("index.html")
        if FileManager.default.fileExists(atPath: indexURL.path) {
            webView.loadFileURL(indexURL, allowingReadAccessTo: webRoot)
        } else {
            webView.loadHTMLString(Self.failureHTML("未找到原版 Mineradio public/index.html。请确认 GitHub Actions 构建阶段已联网下载原仓库 public 目录。"), baseURL: nil)
        }
    }

    private static func failureHTML(_ message: String) -> String {
        """
        <!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'><style>
        html,body{margin:0;height:100%;background:#000;color:#fff;font-family:-apple-system,BlinkMacSystemFont,'PingFang SC',sans-serif;overflow:hidden}
        body{display:grid;place-items:center}.box{max-width:720px;padding:34px;border:1px solid rgba(255,255,255,.14);border-radius:22px;background:rgba(255,255,255,.055);box-shadow:0 28px 90px rgba(0,0,0,.6)}
        h1{font-size:26px;margin:0 0 14px}p{line-height:1.6;color:rgba(255,255,255,.72)}code{color:#ffd98a}
        </style></head><body><div class='box'><h1>Mineradio 原版前端未加载</h1><p>\(message)</p><p>这个包的目标是加载原版 <code>XxHuberrr/Mineradio/public</code>，不是 SwiftUI 仿版。</p></div></body></html>
        """
    }

    private static let bridgeScript = #"""
    (function(){
      if (window.__mineradioIOSBridgeInstalled) return;
      window.__mineradioIOSBridgeInstalled = true;

      // iOS 原版移植默认打开 DIY / FX 模式，避免只停留在简约模式看不到原版效果面板。
      try {
        if (localStorage.getItem('mineradio-ios-keep-simple-mode') !== '1') {
          localStorage.setItem('mineradio-diy-player-mode-v1', '1');
          localStorage.setItem('mineradio-fx-fab-auto-hide-v1', '0');
        }
      } catch (e) {}

      function post(name, payload) {
        try { window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.mineradioIOS && window.webkit.messageHandlers.mineradioIOS.postMessage({ name: name, payload: payload || {} }); } catch (e) {}
      }
      function resolved(value) { return Promise.resolve(value || { ok: true }); }

      // Electron desktopWindow compatibility layer.
      // Keep desktop visual branches enabled, but do not claim support for Windows-only login windows.
      window.desktopWindow = window.desktopWindow || {
        isDesktop: true,
        getState: function(){ return resolved({ isVisible: true, isFocused: true, isFullScreen: true, isWindowFullScreen: true, isHtmlFullScreen: true, isNativeFullScreen: false, isMinimized: false }); },
        onStateChange: function(cb){
          try { if (typeof cb === 'function') setTimeout(function(){ cb({ isVisible: true, isFocused: true, isFullScreen: true, isWindowFullScreen: true, isHtmlFullScreen: true, isNativeFullScreen: false, isMinimized: false }); }, 0); } catch (e) {}
        },
        minimizeWindow: function(){ return resolved({ ok: true }); },
        maximizeWindow: function(){ return resolved({ ok: true }); },
        closeWindow: function(){ post('closeWindow'); return resolved({ ok: true }); },
        toggleFullscreen: function(){ post('toggleFullscreen'); return resolved({ ok: true }); },
        restartApp: function(){ post('restartApp'); return resolved({ ok: false, error: 'iOS does not restart apps programmatically' }); },
        openUpdateInstaller: function(){ return resolved({ ok: false, error: 'iOS build does not use Windows update installers' }); },
        setIgnoreMouseEvents: function(){ return resolved({ ok: true }); },
        clearQQMusicLogin: function(){ return resolved({ ok: true }); }
      };

      var MINERADIO_IOS_API_PANEL_ENABLED = false; // v0.2.6: no visible API modal/button; keep stored API support only.
      var API_KEYS = ['mineradio-ios-api-base', 'mineradio-api-base'];
      function getStoredApiBase() {
        for (var i = 0; i < API_KEYS.length; i++) {
          try {
            var value = String(localStorage.getItem(API_KEYS[i]) || '').trim();
            if (value) return value.replace(/\/+$/, '');
          } catch (e) {}
        }
        return '';
      }
      function setStoredApiBase(value) {
        value = String(value || '').trim().replace(/\/+$/, '');
        try {
          if (value) {
            localStorage.setItem('mineradio-ios-api-base', value);
            localStorage.setItem('mineradio-api-base', value);
          } else {
            localStorage.removeItem('mineradio-ios-api-base');
            localStorage.removeItem('mineradio-api-base');
          }
        } catch (e) {}
        return value;
      }
      function looksLikeApiBase(value) { return /^https?:\/\/[^\s/$.?#].*/i.test(String(value || '').trim()); }
      function apiTargetFor(path) {
        var base = getStoredApiBase();
        if (!base) return '';
        return base + String(path || '');
      }

      function installApiPanel() {
        if (!MINERADIO_IOS_API_PANEL_ENABLED) return;
        if (document.getElementById('mineradio-ios-api-panel')) return;
        var style = document.createElement('style');
        style.id = 'mineradio-ios-api-style';
        style.textContent = [
          '#mineradio-ios-api-button{position:fixed;left:18px;bottom:18px;z-index:99998;height:34px;padding:0 14px;border-radius:999px;border:1px solid rgba(244,210,138,.30);background:rgba(12,12,16,.58);color:rgba(255,240,190,.92);font:700 12px/1 -apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif;letter-spacing:.08em;backdrop-filter:blur(18px);-webkit-backdrop-filter:blur(18px);box-shadow:0 14px 38px rgba(0,0,0,.32);opacity:.74}',
          '#mineradio-ios-api-button.has-base{border-color:rgba(0,245,212,.26);color:rgba(205,255,246,.90)}',
          '#mineradio-ios-api-panel{position:fixed;inset:0;z-index:99999;display:none;align-items:center;justify-content:center;background:rgba(0,0,0,.48);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);font-family:-apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif;color:#fff}',
          '#mineradio-ios-api-panel.show{display:flex}',
          '#mineradio-ios-api-card{width:min(560px,calc(100vw - 42px));border-radius:24px;border:1px solid rgba(255,255,255,.16);background:linear-gradient(145deg,rgba(38,38,44,.94),rgba(10,10,14,.96));box-shadow:0 28px 90px rgba(0,0,0,.62),inset 0 1px 0 rgba(255,255,255,.12);padding:22px}',
          '#mineradio-ios-api-card h3{margin:0 0 10px;font-size:20px;letter-spacing:.02em}',
          '#mineradio-ios-api-card p{margin:8px 0;color:rgba(255,255,255,.68);font-size:13px;line-height:1.55}',
          '#mineradio-ios-api-card code{color:#ffe2a3}',
          '#mineradio-ios-api-input{width:100%;height:44px;border-radius:14px;border:1px solid rgba(255,255,255,.14);background:rgba(255,255,255,.06);color:#fff;padding:0 13px;font-size:14px;outline:none;margin-top:12px}',
          '#mineradio-ios-api-input:focus{border-color:rgba(244,210,138,.52);box-shadow:0 0 0 3px rgba(244,210,138,.10)}',
          '#mineradio-ios-api-actions{display:flex;gap:10px;justify-content:flex-end;margin-top:16px;flex-wrap:wrap}',
          '#mineradio-ios-api-actions button{height:38px;padding:0 14px;border-radius:12px;border:1px solid rgba(255,255,255,.13);background:rgba(255,255,255,.06);color:rgba(255,255,255,.86);font-weight:650}',
          '#mineradio-ios-api-actions button.primary{border-color:rgba(244,210,138,.42);background:rgba(244,210,138,.14);color:#fff1c0}',
          '#mineradio-ios-api-status{min-height:18px;margin-top:10px;font-size:12px;color:rgba(255,255,255,.62)}',
          '#mineradio-ios-api-status.ok{color:#9cffdf}#mineradio-ios-api-status.fail{color:#ff8ea1}'
        ].join('\n');
        document.documentElement.appendChild(style);
        var btn = document.createElement('button');
        btn.id = 'mineradio-ios-api-button';
        btn.type = 'button';
        btn.textContent = 'API';
        var panel = document.createElement('div');
        panel.id = 'mineradio-ios-api-panel';
        panel.innerHTML = '<div id="mineradio-ios-api-card"><h3>连接 Mineradio API</h3><p>二维码登录需要连接你电脑或服务器上运行的 <code>Mineradio server.js</code>。真机/iPad 不能填 127.0.0.1，要填电脑局域网 IP。</p><p>例子：<code>http://192.168.1.23:3000</code></p><input id="mineradio-ios-api-input" placeholder="http://电脑局域网IP:3000" autocapitalize="off" autocomplete="off" spellcheck="false"><div id="mineradio-ios-api-status"></div><div id="mineradio-ios-api-actions"><button type="button" data-action="clear">清空</button><button type="button" data-action="test">测试</button><button type="button" data-action="close">关闭</button><button class="primary" type="button" data-action="save">保存</button></div></div>';
        document.documentElement.appendChild(btn);
        document.documentElement.appendChild(panel);
        function syncButton() {
          var base = getStoredApiBase();
          btn.classList.toggle('has-base', !!base);
          btn.textContent = base ? 'API ✓' : 'API';
        }
        function status(text, cls) {
          var el = document.getElementById('mineradio-ios-api-status');
          if (!el) return;
          el.textContent = text || '';
          el.className = cls || '';
        }
        function open(reason) {
          var input = document.getElementById('mineradio-ios-api-input');
          if (input) input.value = getStoredApiBase();
          panel.classList.add('show');
          status(reason || '保存后重新点“刷新二维码”。', '');
          setTimeout(function(){ try { input && input.focus(); } catch (e) {} }, 80);
        }
        function close() { panel.classList.remove('show'); syncButton(); }
        function save() {
          var input = document.getElementById('mineradio-ios-api-input');
          var value = input ? String(input.value || '').trim() : '';
          if (value && !looksLikeApiBase(value)) { status('地址格式不对，要以 http:// 或 https:// 开头。', 'fail'); return ''; }
          value = setStoredApiBase(value);
          syncButton();
          status(value ? ('已保存：' + value) : '已清空 API 地址。', value ? 'ok' : '');
          return value;
        }
        async function test() {
          var base = save();
          if (!base) return;
          status('正在测试 ' + base + ' ...', '');
          try {
            var res = await fetch(base.replace(/\/+$/, '') + '/api/app/version?_=' + Date.now(), { cache: 'no-store' });
            if (!res.ok) throw new Error('HTTP ' + res.status);
            status('连接成功。关闭后重新刷新二维码。', 'ok');
          } catch (e) {
            status('连接失败：' + ((e && e.message) || e) + '。检查电脑服务、防火墙、IP、端口。', 'fail');
          }
        }
        btn.addEventListener('click', function(){ open('这里配置二维码登录用的 API Base。'); });
        panel.addEventListener('click', function(e){ if (e.target === panel) close(); });
        panel.querySelector('[data-action="close"]').addEventListener('click', close);
        panel.querySelector('[data-action="save"]').addEventListener('click', save);
        panel.querySelector('[data-action="test"]').addEventListener('click', test);
        panel.querySelector('[data-action="clear"]').addEventListener('click', function(){ var input = document.getElementById('mineradio-ios-api-input'); if (input) input.value=''; save(); });
        window.mineradioIOSOpenApiPanel = open;
        window.mineradioIOSSyncApiButton = syncButton;
        syncButton();
      }
      function showApiPanel(reason) {
        // v0.2.6+: API config UI was intentionally removed at user's request.
        // Keep only a non-blocking toast so the app never throws an input modal over the original UI.
        try { if (typeof showToast === 'function') showToast(reason || '需要 Mineradio API 服务'); } catch (e) {}
      }
      // API panel hidden; preserve localStorage API Base support for users who already configured it.

      function isTypingTarget(target) {
        try {
          var el = target && target.nodeType === 3 ? target.parentElement : target;
          if (!el || !el.closest) return false;
          return !!el.closest('input,textarea,select,[contenteditable="true"],.allow-text-select');
        } catch (e) { return false; }
      }
      function isPointerOverUi(pointOrEvent) {
        try {
          var x = pointOrEvent && (pointOrEvent.clientX != null ? pointOrEvent.clientX : (pointOrEvent.touches && pointOrEvent.touches[0] && pointOrEvent.touches[0].clientX));
          var y = pointOrEvent && (pointOrEvent.clientY != null ? pointOrEvent.clientY : (pointOrEvent.touches && pointOrEvent.touches[0] && pointOrEvent.touches[0].clientY));
          if (x == null || y == null) return false;
          var el = document.elementFromPoint(x, y);
          if (!el || !el.closest) return false;
          return !!el.closest('input,textarea,select,button,a,[role="button"],#bottom-bar,#controls,#top-right,#search-area,#fx-panel,#fx-fab,#desktop-titlebar,#login-modal,#mineradio-ios-api-panel,.icon-btn,.control-cluster,.glass-saved-panel,.mini-queue-popover,.home-card,.home-tile');
        } catch (e) { return false; }
      }

      // Route original relative /api calls to the original Mineradio Node API host.
      // This keeps the original frontend untouched while making QR/search/playback/cover proxies work on iOS.
      function rewriteApiURL(value, reason) {
        var raw = String(value || '');
        if (raw.indexOf('/api/') !== 0) return value;
        var target = apiTargetFor(raw);
        if (!target) {
          showApiPanel((reason || '当前操作') + '需要先配置 API Base，例如 http://电脑局域网IP:3000。');
          return raw;
        }
        return target;
      }

      var nativeFetch = window.fetch ? window.fetch.bind(window) : null;
      if (nativeFetch && !window.__mineradioFetchWrapped) {
        window.__mineradioFetchWrapped = true;
        window.fetch = function(input, init) {
          var raw = '';
          try { raw = (typeof input === 'string') ? input : (input && input.url ? input.url : ''); } catch (e) {}
          if (raw && raw.indexOf('/api/') === 0) {
            var target = apiTargetFor(raw);
            if (!target) {
              showApiPanel('二维码/搜索需要先配置 API Base，例如 http://电脑局域网IP:3000。');
              return Promise.reject(new TypeError('未配置 Mineradio API 服务地址'));
            }
            input = target;
          }
          return nativeFetch(input, init).catch(function(err){
            try {
              if (raw && raw.indexOf('/api/') === 0) showApiPanel('API 连接失败：' + ((err && err.message) || err) + '。检查电脑服务、防火墙、IP、端口。');
            } catch (e) {}
            throw err;
          });
        };
      }

      if (window.XMLHttpRequest && !window.__mineradioXHRWrapped) {
        window.__mineradioXHRWrapped = true;
        var nativeOpen = XMLHttpRequest.prototype.open;
        XMLHttpRequest.prototype.open = function(method, url) {
          if (typeof url === 'string' && url.indexOf('/api/') === 0) url = rewriteApiURL(url, 'XHR API');
          return nativeOpen.apply(this, arguments.length >= 2 ? [method, url].concat(Array.prototype.slice.call(arguments, 2)) : arguments);
        };
      }

      function patchURLProperty(proto, prop, label) {
        try {
          var desc = Object.getOwnPropertyDescriptor(proto, prop);
          if (!desc || !desc.set || desc.__mineradioIOSPatched) return;
          Object.defineProperty(proto, prop, {
            configurable: true,
            enumerable: desc.enumerable,
            get: desc.get,
            set: function(value) {
              if (typeof value === 'string' && value.indexOf('/api/') === 0) value = rewriteApiURL(value, label);
              return desc.set.call(this, value);
            }
          });
        } catch (e) {}
      }
      patchURLProperty(HTMLImageElement && HTMLImageElement.prototype, 'src', '图片/封面代理');
      patchURLProperty(HTMLMediaElement && HTMLMediaElement.prototype, 'src', '音频代理');
      patchURLProperty(HTMLSourceElement && HTMLSourceElement.prototype, 'src', '媒体代理');
      if (!Element.prototype.__mineradioSetAttributePatched) {
        Element.prototype.__mineradioSetAttributePatched = true;
        var nativeSetAttribute = Element.prototype.setAttribute;
        Element.prototype.setAttribute = function(name, value) {
          if (String(name || '').toLowerCase() === 'src' && typeof value === 'string' && value.indexOf('/api/') === 0) {
            value = rewriteApiURL(value, '资源代理');
          }
          return nativeSetAttribute.call(this, name, value);
        };
      }

      function enableFullFxMode() {
        try {
          document.documentElement.classList.remove('simple-mode-preload');
          document.documentElement.classList.add('diy-mode-preload');
          if (document.body) {
            document.body.classList.remove('simple-mode');
            document.body.classList.add('diy-mode');
            document.body.classList.remove('fx-fab-auto-hide');
          }
          if (typeof window.applyDiyMode === 'function') window.applyDiyMode(true, { save: true, toast: false, animate: false });
          if (typeof window.applyFxFabAutoHideState === 'function') window.applyFxFabAutoHideState(false);
        } catch (e) {}
      }
      var fxTries = 0;
      var fxTimer = setInterval(function(){
        enableFullFxMode();
        fxTries++;
        if (fxTries > 40 || (typeof window.applyDiyMode === 'function' && document.getElementById('fx-fab'))) clearInterval(fxTimer);
      }, 250);
      if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', enableFullFxMode, { once: true });
      else enableFullFxMode();

      window.mineradioIOSApplyEmbeddedArtwork = function(payload) {
        payload = payload || {};
        var attempts = 0;
        var dataUrl = payload.dataUrl || '';
        if (!dataUrl) return false;
        function apply() {
          attempts++;
          try {
            var song = (typeof currentCoverSong === 'function') ? currentCoverSong() : (window.currentLocalSong || null);
            if (song && song.type === 'local' && typeof setCustomCoverForCurrent === 'function') {
              setCustomCoverForCurrent(dataUrl, { deferHeavy: false, delay: 0, timeout: 1800 });
              if (typeof showToast === 'function') showToast('已读取音频内嵌封面');
              return true;
            }
          } catch (e) {}
          return false;
        }
        if (apply()) return true;
        var timer = setInterval(function(){
          if (apply() || attempts > 80) clearInterval(timer);
        }, 180);
        return true;
      };

      function installIOSRuntimeFixes() {
        if (window.__mineradioIOSRuntimeFixesInstalled) return;
        window.__mineradioIOSRuntimeFixesInstalled = true;

        // Prevent iPad mouse / touch drags from selecting the whole page.
        var style = document.createElement('style');
        style.id = 'mineradio-ios-runtime-fixes';
        style.textContent = [
          'html,body,#desktop-window-shell,#canvas-container,canvas{user-select:none!important;-webkit-user-select:none!important;-webkit-touch-callout:none!important;touch-action:none!important;overscroll-behavior:none!important}',
          'input,textarea,[contenteditable="true"]{user-select:text!important;-webkit-user-select:text!important;touch-action:manipulation!important}',
          '.control-title,.control-artist,#thumb-title,#thumb-artist,.stage-lyric-line,.stage-lyric-word{user-select:none!important;-webkit-user-select:none!important}',
          '#mineradio-ios-api-button,#mineradio-ios-api-panel{display:none!important;pointer-events:none!important}',
          'body.ios-wkwebview-shell #thumb-artist,body.ios-wkwebview-shell .control-artist{font-size:0!important}',
          'body.ios-wkwebview-shell #thumb-artist::before,body.ios-wkwebview-shell .control-artist::before{content:attr(data-ios-clean-artist);font-size:11.5px;color:rgba(255,255,255,.48)}',
          'body.ios-wkwebview-shell img,body.ios-wkwebview-shell svg,body.ios-wkwebview-shell canvas{-webkit-user-drag:none!important;user-drag:none!important}',
          '#api-btn,#api-button,.api-btn,.api-button,[data-action="api"],[data-role="api"]{display:none!important;pointer-events:none!important}',
          '#splash,#splash *{touch-action:manipulation!important;pointer-events:auto!important;-webkit-user-select:none!important;user-select:none!important;-webkit-touch-callout:none!important}'
        ].join('\n');
        document.documentElement.appendChild(style);

        // v0.3.0: hard iPad splash unlock. The original desktop splash waits for a
        // ready flag and iPadOS can suppress the click after touch-selection fixes.
        // While splash-active is present, any tap/click/trackpad press enters, with
        // an auto-enter fallback so the app can never get stuck on the first screen.
        function hardDismissSplashFromIOS(reason) {
          try {
            var splash = document.getElementById('splash');
            if (!splash) return false;
            try { if (typeof playMineradioIntroSound === 'function') playMineradioIntroSound(); } catch (_) {}
            try { window.splashReadyToEnter = true; } catch (_) {}
            try { if (typeof markSplashReadyToEnter === 'function') markSplashReadyToEnter(); } catch (_) {}
            try {
              if (typeof dismissSplash === 'function') dismissSplash();
            } catch (_) {}
            setTimeout(function(){
              try {
                var s2 = document.getElementById('splash');
                if (!s2) return;
                if (document.body && document.body.classList.contains('splash-active')) {
                  s2.classList.add('hide');
                  s2.classList.remove('ready', 'exiting');
                  s2.style.setProperty('display', 'none', 'important');
                  s2.style.setProperty('pointer-events', 'none', 'important');
                  document.body.classList.remove('splash-active', 'splash-revealing');
                  if (typeof updateEmptyHomeVisibility === 'function') updateEmptyHomeVisibility({ forceLoad: true });
                  if (typeof maybeRunStartupVisualGuide === 'function') maybeRunStartupVisualGuide('ios-splash-hard-dismiss');
                }
              } catch (_) {}
            }, 900);
            return true;
          } catch (_) { return false; }
        }
        function forceDismissSplashFromIOSGesture(e) {
          try {
            if (!document.body || !document.body.classList.contains('splash-active')) return;
            if (e && isTypingTarget(e.target)) return;
            if (e && e.cancelable) e.preventDefault();
            // Do not stop propagation. Let original Mineradio's own click/touch logic run too.
            hardDismissSplashFromIOS('gesture');
          } catch (_) {}
        }
        function installSplashUnlocker() {
          try {
            var splash = document.getElementById('splash');
            if (splash && !splash.__mineradioIOSUnlockPatched) {
              splash.__mineradioIOSUnlockPatched = true;
              splash.style.setProperty('pointer-events', 'auto', 'important');
              splash.style.setProperty('touch-action', 'manipulation', 'important');
              splash.addEventListener('touchstart', forceDismissSplashFromIOSGesture, { passive:false, capture:true });
              splash.addEventListener('touchend', forceDismissSplashFromIOSGesture, { passive:false, capture:true });
              splash.addEventListener('pointerdown', forceDismissSplashFromIOSGesture, { passive:false, capture:true });
              splash.addEventListener('pointerup', forceDismissSplashFromIOSGesture, { passive:false, capture:true });
              splash.addEventListener('mousedown', forceDismissSplashFromIOSGesture, { passive:false, capture:true });
              splash.addEventListener('mouseup', forceDismissSplashFromIOSGesture, { passive:false, capture:true });
              splash.addEventListener('click', forceDismissSplashFromIOSGesture, { passive:false, capture:true });
            }
          } catch (_) {}
        }
        ['touchstart','touchend','pointerdown','pointerup','mousedown','mouseup','click'].forEach(function(type){
          try { document.addEventListener(type, forceDismissSplashFromIOSGesture, { passive:false, capture:true }); } catch (_) {}
        });
        installSplashUnlocker();
        setTimeout(installSplashUnlocker, 80);
        setTimeout(installSplashUnlocker, 250);
        setTimeout(installSplashUnlocker, 700);
        setTimeout(function(){
          try { if (document.body && document.body.classList.contains('splash-active')) hardDismissSplashFromIOS('timer-2200'); } catch (_) {}
        }, 2200);
        setTimeout(function(){
          try { if (document.body && document.body.classList.contains('splash-active')) hardDismissSplashFromIOS('timer-4200'); } catch (_) {}
        }, 4200);

        document.addEventListener('selectstart', function(e){ if (!isTypingTarget(e.target)) e.preventDefault(); }, true);
        document.addEventListener('dragstart', function(e){ if (!isTypingTarget(e.target)) e.preventDefault(); }, true);
        document.addEventListener('gesturestart', function(e){ if (!isTypingTarget(e.target)) e.preventDefault(); }, true);
        document.addEventListener('gesturechange', function(e){ if (!isTypingTarget(e.target)) e.preventDefault(); }, true);
        document.addEventListener('contextmenu', function(e){ if (!isTypingTarget(e.target)) e.preventDefault(); }, true);
        document.addEventListener('click', function(e){
          try {
            var el = e.target && e.target.closest && e.target.closest('input[type="file"]');
            if (el) post('pickerKind', { id: String(el.id || ''), accept: String(el.getAttribute('accept') || '') });
          } catch (_) {}
        }, true);
        document.addEventListener('touchend', function(e){
          try {
            var el = e.target && e.target.closest && e.target.closest('input[type="file"]');
            if (el) post('pickerKind', { id: String(el.id || ''), accept: String(el.getAttribute('accept') || '') });
          } catch (_) {}
        }, true);

        // Tell native side what kind of file input is about to open so the document picker can filter correctly.
        try {
          var oldClick = HTMLInputElement.prototype.click;
          HTMLInputElement.prototype.click = function(){
            try {
              if (this && String(this.type || '').toLowerCase() === 'file') {
                var id = String(this.id || '');
                var accept = String(this.getAttribute('accept') || '');
                post('pickerKind', { id: id, accept: accept });
              }
            } catch (e) {}
            return oldClick.apply(this, arguments);
          };
        } catch (e) {}

        // Increase cover particle resolution upper bound: previous max 183x183; new max about 579x579 (~10x particles).
        function patchParticleResolution() {
          try {
            var slider = document.getElementById('fx-coverres');
            if (slider) slider.max = '4.91';
            window.normalizeCoverResolution = function(v){ return clampRange(Number(v) || 1, 0.75, 4.91); };
            window.coverParticleGridForResolution = function(v){
              var grid = Math.round(118 * window.normalizeCoverResolution(v));
              grid = Math.max(88, Math.min(579, grid));
              return grid % 2 ? grid : grid + 1;
            };
            window.coverParticleCountLabel = function(v){ var g = window.coverParticleGridForResolution(v); return g + 'x' + g; };
            window.coverTextureSizeForResolution = function(v){
              v = window.normalizeCoverResolution(v);
              if (v >= 3.2) return 1024;
              if (v >= 1.32) return 512;
              if (v >= 1.10) return 384;
              return 256;
            };
            if (window.fx) {
              if (!localStorage.getItem('mineradio-ios-user-cover-resolution-touched')) {
                window.fx.coverResolution = Math.max(Number(window.fx.coverResolution) || 1.55, 2.45);
              }
              if (typeof applyCoverParticleResolution === 'function') applyCoverParticleResolution(window.fx.coverResolution, { reload: true });
              if (typeof updateFxInputs === 'function') updateFxInputs();
            }
          } catch (e) {}
        }

        // Keep background audio/render state alive as much as WebKit allows.
        function keepPlaybackAlive() {
          try {
            if (window.fx) {
              window.fx.performanceBackground = 'keep';
              window.fx.liveBackgroundKeep = true;
              window.fx.performanceQuality = window.fx.performanceQuality || 'high';
            }
            if (typeof setPerformanceBackgroundMode === 'function') setPerformanceBackgroundMode('keep', true);
            if (typeof updatePerformanceControls === 'function') updatePerformanceControls();
            document.body && document.body.classList.remove('render-deep-sleep');
          } catch (e) {}
        }
        var iosWasPlayingBeforeHide = false;
        function getMainAudioElement() {
          try { return (typeof audio !== 'undefined' && audio) || document.querySelector('audio'); } catch (e) { return document.querySelector('audio'); }
        }
        function rememberPlaybackState() {
          try { var a = getMainAudioElement(); iosWasPlayingBeforeHide = !!(a && !a.paused && !a.ended); } catch (e) {}
        }
        function resumePlaybackIfNeeded() {
          keepPlaybackAlive();
          try {
            var a = getMainAudioElement();
            if (!a) return;
            a.muted = false;
            if (iosWasPlayingBeforeHide || (a.currentTime > 0 && a.paused && document.visibilityState === 'visible')) {
              var p = a.play && a.play();
              if (p && p.catch) p.catch(function(){});
            }
          } catch (e) {}
        }
        document.addEventListener('visibilitychange', function(){
          if (document.visibilityState === 'hidden') rememberPlaybackState();
          else resumePlaybackIfNeeded();
        }, true);
        window.addEventListener('pagehide', rememberPlaybackState, true);
        window.addEventListener('pageshow', resumePlaybackIfNeeded, true);
        window.addEventListener('focus', resumePlaybackIfNeeded, true);

        // Clean local titles/subtitles. Original UI appends “- 本地文件”; iOS local view should show only the song name.
        function cleanTextValue(t) {
          return String(t || '')
            .replace(/^[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12}[-_\s]*/,'')
            .replace(/\s*[-—–]\s*(本地文件|本地|local file)\s*$/i,'')
            .replace(/\s*\|\s*(本地文件|本地|local file)\s*$/i,'')
            .trim();
        }
        var lastLocalTextDeepCleanAt = 0;
        function cleanVisibleLocalTitleTextNodes() {
          try {
            var now = Date.now();
            if (now - lastLocalTextDeepCleanAt < 350) return;
            lastLocalTextDeepCleanAt = now;
            if (!document.body || !document.createTreeWalker) return;
            var filter = {
              acceptNode: function(node) {
                var raw = node && node.nodeValue || '';
                if (!/([0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12}|[-—–]\s*(本地文件|本地|local file)\s*$|\|\s*(本地文件|本地|local file)\s*$)/i.test(raw)) return NodeFilter.FILTER_REJECT;
                var parent = node.parentElement;
                if (!parent || (parent.closest && parent.closest('script,style,input,textarea,select,[contenteditable="true"]'))) return NodeFilter.FILTER_REJECT;
                return NodeFilter.FILTER_ACCEPT;
              }
            };
            var walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, filter);
            var nodes = [], node;
            while ((node = walker.nextNode()) && nodes.length < 80) nodes.push(node);
            nodes.forEach(function(n){ var c = cleanTextValue(n.nodeValue); if (c && c !== n.nodeValue) n.nodeValue = c; });
          } catch (_) {}
        }
        function cleanLocalLabels() {
          try {
            ['thumb-title','control-title'].forEach(function(id){
              var el = document.getElementById(id);
              if (el && el.textContent) {
                var c = cleanTextValue(el.textContent);
                if (c && c !== el.textContent) el.textContent = c;
              }
            });
            ['thumb-artist','control-artist'].forEach(function(id){
              var el = document.getElementById(id);
              if (el) {
                var text = cleanTextValue(el.textContent || '');
                if (!text || /^本地文件$/i.test(text)) text = '';
                el.setAttribute('data-ios-clean-artist', text);
              }
            });
            if (window.currentLocalSong) {
              if (window.currentLocalSong.name) window.currentLocalSong.name = cleanTextValue(window.currentLocalSong.name);
              if (window.currentLocalSong.artist === '本地文件' || window.currentLocalSong.artist === '本地') window.currentLocalSong.artist = '';
            }
            if (window.currentSong) {
              if (window.currentSong.name) window.currentSong.name = cleanTextValue(window.currentSong.name);
              if (window.currentSong.artist === '本地文件' || window.currentSong.artist === '本地') window.currentSong.artist = '';
            }
            cleanVisibleLocalTitleTextNodes();
          } catch (e) {}
        }
        function hideApiEntrypoints() {
          try {
            var candidates = Array.prototype.slice.call(document.querySelectorAll('button,a,div'));
            candidates.forEach(function(el){
              var text = String(el.textContent || '').trim().toUpperCase();
              if (text !== 'API') return;
              var r = el.getBoundingClientRect && el.getBoundingClientRect();
              if (!r || r.width > 90 || r.height > 60) return;
              if (r.left < 120 && r.top > window.innerHeight - 140) {
                el.style.setProperty('display','none','important');
                el.style.setProperty('pointer-events','none','important');
              }
            });
          } catch (_) {}
        }
        var labelObserver = new MutationObserver(cleanLocalLabels);
        labelObserver.observe(document.documentElement, { childList:true, subtree:true, characterData:true });
        setInterval(cleanLocalLabels, 900);

        // Touch adapter: one-finger drag acts like mouse drag / camera look; pinch acts like wheel zoom.
        function installTouchAdapter() {
          var canvas = (window.renderer && renderer.domElement) || document.querySelector('#canvas-container canvas, canvas');
          if (!canvas || canvas.__mineradioIOSTouchPatched) return;
          canvas.__mineradioIOSTouchPatched = true;
          var active = false, last = null, pinch = null;
          function touchPoint(t){ return { clientX:t.clientX, clientY:t.clientY, screenX:t.screenX||t.clientX, screenY:t.screenY||t.clientY }; }
          function mouse(type, p, target) {
            var evt = new MouseEvent(type, { bubbles:true, cancelable:true, view:window, clientX:p.clientX, clientY:p.clientY, screenX:p.screenX, screenY:p.screenY, button:0, buttons:type === 'mouseup' ? 0 : 1 });
            (target || canvas).dispatchEvent(evt);
          }
          function pointer(type, p, target) {
            try {
              if (!window.PointerEvent) return;
              var evt = new PointerEvent(type, { bubbles:true, cancelable:true, view:window, pointerId:771, pointerType:'touch', isPrimary:true, clientX:p.clientX, clientY:p.clientY, screenX:p.screenX, screenY:p.screenY, button:0, buttons:type === 'pointerup' ? 0 : 1 });
              (target || canvas).dispatchEvent(evt);
            } catch (_) {}
          }
          function dispatchMove(p) {
            pointer('pointermove', p, canvas); pointer('pointermove', p, document); pointer('pointermove', p, window);
            mouse('mousemove', p, canvas); mouse('mousemove', p, document); mouse('mousemove', p, window);
          }
          function wheel(deltaY, p) {
            var evt = new WheelEvent('wheel', { bubbles:true, cancelable:true, view:window, clientX:p.clientX, clientY:p.clientY, deltaY:deltaY, deltaMode:0 });
            canvas.dispatchEvent(evt);
          }
          canvas.addEventListener('touchstart', function(e){
            if (!e.touches || !e.touches.length) return;
            if (isPointerOverUi(e.touches[0])) return;
            e.preventDefault();
            if (e.touches.length === 1) {
              active = true; last = touchPoint(e.touches[0]); pinch = null;
              pointer('pointerdown', last, canvas);
              mouse('mousedown', last, canvas);
              dispatchMove(last);
            } else if (e.touches.length >= 2) {
              active = false;
              var a = touchPoint(e.touches[0]), b = touchPoint(e.touches[1]);
              pinch = { dist: Math.hypot(a.clientX-b.clientX, a.clientY-b.clientY), mid: { clientX:(a.clientX+b.clientX)/2, clientY:(a.clientY+b.clientY)/2, screenX:(a.screenX+b.screenX)/2, screenY:(a.screenY+b.screenY)/2 } };
            }
          }, { passive:false });
          canvas.addEventListener('touchmove', function(e){
            if (!e.touches || !e.touches.length) return;
            if (isPointerOverUi(e.touches[0])) return;
            e.preventDefault();
            if (e.touches.length === 1 && active) {
              var p = touchPoint(e.touches[0]);
              dispatchMove(p);
              last = p;
            } else if (e.touches.length >= 2 && pinch) {
              var a = touchPoint(e.touches[0]), b = touchPoint(e.touches[1]);
              var d = Math.hypot(a.clientX-b.clientX, a.clientY-b.clientY);
              var delta = (pinch.dist - d) * 0.9;
              pinch.dist = d;
              wheel(delta, pinch.mid);
            }
          }, { passive:false });
          canvas.addEventListener('touchend', function(e){
            if (active && last) { pointer('pointerup', last, canvas); mouse('mouseup', last, window); }
            active = false; last = null; pinch = null;
          }, { passive:false });
          canvas.addEventListener('touchcancel', function(e){
            if (active && last) { pointer('pointerup', last, canvas); mouse('mouseup', last, window); }
            active = false; last = null; pinch = null;
          }, { passive:false });
        }
        try {
          var touchObserver = new MutationObserver(function(){ installTouchAdapter(); hideApiEntrypoints(); cleanLocalLabels(); });
          touchObserver.observe(document.documentElement, { childList:true, subtree:true });
        } catch (_) {}
        document.addEventListener('pointerdown', function(e){ if (!isTypingTarget(e.target) && !isPointerOverUi(e)) document.body && document.body.classList.add('ios-touching-stage'); }, true);
        document.addEventListener('pointerup', function(){ document.body && document.body.classList.remove('ios-touching-stage'); }, true);

        // “安魂” preset can become too dark on iPad; lift minimum visibility without changing preset identity.
        function patchSkullVisibility() {
          try {
            if (typeof SKULL_PRESET_INDEX !== 'undefined' && window.fx && window.fx.preset === SKULL_PRESET_INDEX) {
              window.fx.intensity = Math.max(Number(window.fx.intensity) || 0, 0.72);
              window.fx.depth = Math.max(Number(window.fx.depth) || 0, 0.92);
              window.fx.bloomStrength = Math.max(Number(window.fx.bloomStrength) || 0, 0.42);
              window.fx.backgroundOpacity = Math.min(Number(window.fx.backgroundOpacity == null ? 1 : window.fx.backgroundOpacity), 0.82);
              if (typeof syncFxUniforms === 'function') syncFxUniforms();
            }
          } catch (e) {}
        }
        var tries = 0;
        var timer = setInterval(function(){
          tries++;
          patchParticleResolution();
          keepPlaybackAlive();
          cleanLocalLabels();
          hideApiEntrypoints();
          installTouchAdapter();
          patchSkullVisibility();
          if (tries > 80) clearInterval(timer);
        }, 250);
      }
      if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', installIOSRuntimeFixes, { once:true });
      else installIOSRuntimeFixes();

      window.addEventListener('error', function(e){ post('jsError', { message: e.message || '', source: e.filename || '', line: e.lineno || 0 }); });
      window.addEventListener('unhandledrejection', function(e){ post('promiseError', { message: String((e.reason && (e.reason.message || e.reason)) || '') }); });
    })();
    """#

    final class Coordinator: NSObject, WKNavigationDelegate, WKUIDelegate, WKScriptMessageHandler, UIDocumentPickerDelegate {
        weak var webView: WKWebView?
        private var openPanelCompletion: (([URL]?) -> Void)?
        private var pendingPickerId: String = ""
        private var pendingPickerAccept: String = ""

        func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
            if let dict = message.body as? [String: Any], let name = dict["name"] as? String {
                let payload = dict["payload"] as? [String: Any]
                if name == "pickerKind" {
                    pendingPickerId = payload?["id"] as? String ?? ""
                    pendingPickerAccept = payload?["accept"] as? String ?? ""
                    return
                }
            }
            #if DEBUG
            print("Mineradio iOS bridge:", message.body)
            #endif
        }

        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            webView.evaluateJavaScript("document.body && document.body.classList.add('ios-wkwebview-shell')", completionHandler: nil)
        }

        @available(iOS 18.4, *)
        func webView(_ webView: WKWebView, runOpenPanelWith parameters: WKOpenPanelParameters, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping ([URL]?) -> Void) {
            openPanelCompletion?(nil)
            openPanelCompletion = completionHandler

            let contentTypes = pickerContentTypes()
            let picker = UIDocumentPickerViewController(forOpeningContentTypes: contentTypes, asCopy: true)
            picker.delegate = self
            picker.allowsMultipleSelection = parameters.allowsMultipleSelection
            picker.modalPresentationStyle = .formSheet
            topViewController()?.present(picker, animated: true)
        }

        private func pickerContentTypes() -> [UTType] {
            let id = pendingPickerId.lowercased()
            let accept = pendingPickerAccept.lowercased()
            let imageOrVideo = id.contains("background") || accept.contains("image/") || accept.contains("video/")
            let exts = imageOrVideo
                ? ["jpg", "jpeg", "png", "webp", "mp4", "webm", "mov"]
                : ["mp3", "flac", "wav", "ogg", "m4a", "aac", "aiff", "aif", "opus"]
            var types: [UTType] = imageOrVideo ? [.image, .movie] : [.audio]
            for ext in exts {
                if let type = UTType(filenameExtension: ext) { types.append(type) }
            }
            // De-duplicate while preserving order.
            var seen = Set<String>()
            return types.filter { type in
                let key = type.identifier
                if seen.contains(key) { return false }
                seen.insert(key)
                return true
            }
        }

        func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
            openPanelCompletion?(nil)
            openPanelCompletion = nil
            pendingPickerId = ""
            pendingPickerAccept = ""
        }

        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            let imported = prepareReadableImports(urls)
            let outputURLs = imported.map { $0.url }
            openPanelCompletion?(outputURLs.isEmpty ? urls : outputURLs)
            openPanelCompletion = nil
            pendingPickerId = ""
            pendingPickerAccept = ""

            if let artwork = imported.first(where: { $0.artworkDataURL != nil })?.artworkDataURL {
                injectEmbeddedArtwork(artwork)
            }
        }

        private struct PreparedImport {
            let url: URL
            let artworkDataURL: String?
        }

        private func prepareReadableImports(_ urls: [URL]) -> [PreparedImport] {
            let fm = FileManager.default
            let dir = fm.temporaryDirectory.appendingPathComponent("MineradioImports", isDirectory: true)
            try? fm.createDirectory(at: dir, withIntermediateDirectories: true)
            var results: [PreparedImport] = []
            var usedNames = Set<String>()
            for sourceURL in urls {
                let scoped = sourceURL.startAccessingSecurityScopedResource()
                defer { if scoped { sourceURL.stopAccessingSecurityScopedResource() } }

                let artwork = extractArtworkDataURL(from: sourceURL)
                let preferredName = preferredImportFileName(for: sourceURL)
                let safeName = uniqueSafeFileName(preferredName, usedNames: &usedNames)
                let dest = dir.appendingPathComponent(safeName)
                try? fm.removeItem(at: dest)
                do {
                    try fm.copyItem(at: sourceURL, to: dest)
                    results.append(PreparedImport(url: dest, artworkDataURL: artwork))
                } catch {
                    results.append(PreparedImport(url: sourceURL, artworkDataURL: artwork))
                }
            }
            return results
        }

        private func preferredImportFileName(for url: URL) -> String {
            let original = url.lastPathComponent
            let ext = url.pathExtension
            let asset = AVURLAsset(url: url)
            let title = metadataString(from: asset, identifier: .commonIdentifierTitle)
            if let title, !title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                let base = sanitizeFileName(title)
                if !base.isEmpty { return ext.isEmpty ? base : base + "." + ext }
            }
            return sanitizeFileName(original).isEmpty ? UUID().uuidString + (ext.isEmpty ? "" : "." + ext) : sanitizeFileName(original)
        }

        private func sanitizeFileName(_ value: String) -> String {
            let invalid = CharacterSet(charactersIn: "/:\\?%*|\"<>")
            let parts = value.components(separatedBy: invalid).joined(separator: "-")
            return parts.trimmingCharacters(in: .whitespacesAndNewlines)
        }

        private func uniqueSafeFileName(_ name: String, usedNames: inout Set<String>) -> String {
            let safe = sanitizeFileName(name)
            let url = URL(fileURLWithPath: safe.isEmpty ? UUID().uuidString : safe)
            let ext = url.pathExtension
            let base = url.deletingPathExtension().lastPathComponent
            var candidate = safe.isEmpty ? UUID().uuidString : safe
            var index = 2
            while usedNames.contains(candidate.lowercased()) {
                candidate = ext.isEmpty ? "\(base) (\(index))" : "\(base) (\(index)).\(ext)"
                index += 1
            }
            usedNames.insert(candidate.lowercased())
            return candidate
        }

        private func metadataString(from asset: AVURLAsset, identifier: AVMetadataIdentifier) -> String? {
            AVMetadataItem.metadataItems(from: asset.commonMetadata, filteredByIdentifier: identifier).first?.stringValue
        }

        private func extractArtworkDataURL(from url: URL) -> String? {
            let asset = AVURLAsset(url: url)
            let items = asset.commonMetadata + asset.metadata
            for item in items {
                let isArtwork = item.commonKey?.rawValue == "artwork" || item.identifier == .commonIdentifierArtwork
                guard isArtwork else { continue }
                if let data = item.dataValue {
                    return "data:\(imageMimeType(for: data));base64," + data.base64EncodedString()
                }
                if let dict = item.value as? [String: Any], let data = dict["data"] as? Data {
                    return "data:\(imageMimeType(for: data));base64," + data.base64EncodedString()
                }
            }
            return nil
        }

        private func imageMimeType(for data: Data) -> String {
            if data.count >= 4 {
                let bytes = [UInt8](data.prefix(4))
                if bytes[0] == 0x89 && bytes[1] == 0x50 { return "image/png" }
                if bytes[0] == 0xff && bytes[1] == 0xd8 { return "image/jpeg" }
                if bytes[0] == 0x47 && bytes[1] == 0x49 { return "image/gif" }
                if bytes[0] == 0x52 && bytes[1] == 0x49 && bytes[2] == 0x46 && bytes[3] == 0x46 { return "image/webp" }
            }
            return "image/jpeg"
        }

        private func injectEmbeddedArtwork(_ dataURL: String) {
            guard let webView else { return }
            let payload = ["dataUrl": dataURL]
            guard let jsonData = try? JSONSerialization.data(withJSONObject: payload),
                  let json = String(data: jsonData, encoding: .utf8) else { return }
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) { [weak webView] in
                webView?.evaluateJavaScript("window.mineradioIOSApplyEmbeddedArtwork && window.mineradioIOSApplyEmbeddedArtwork(\(json));", completionHandler: nil)
            }
        }

        private func topViewController(base: UIViewController? = UIApplication.shared.connectedScenes
            .compactMap { $0 as? UIWindowScene }
            .flatMap { $0.windows }
            .first { $0.isKeyWindow }?.rootViewController) -> UIViewController? {
            if let nav = base as? UINavigationController { return topViewController(base: nav.visibleViewController) }
            if let tab = base as? UITabBarController { return topViewController(base: tab.selectedViewController) }
            if let presented = base?.presentedViewController { return topViewController(base: presented) }
            return base
        }
    }
}
