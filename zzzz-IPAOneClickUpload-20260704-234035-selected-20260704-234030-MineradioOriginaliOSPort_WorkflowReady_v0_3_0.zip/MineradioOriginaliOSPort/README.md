# Mineradio iOS Original Web Port

目标：**不要仿版，不重画 UI，不阉割粒子 / 3D / 歌词舞台**。

这个工程是一个 iOS WKWebView 壳，构建时会下载原仓库：

`https://github.com/XxHuberrr/Mineradio`

并把原版 `public/` 目录整体复制进 App Bundle：

`MineradioWeb/index.html`

App 启动后直接加载原版 `index.html`，视觉层走原项目的 HTML/CSS/JS/Three.js/GSAP/music-tempo。

## 结构

- `MineradioiOSApp.swift`：iOS App 入口。
- `ContentView.swift`：WKWebView 原版前端加载器 + iOS/Electron 兼容桥。
- `Run Script Phase: Fetch Original Mineradio Web`：GitHub Actions / Xcode build 时下载原 `public/`。

## 这版的重点

- 视觉层不使用之前的 SwiftUI 卡片界面。
- 修复 iPad/WKWebView 启动页点击被吞导致卡在开始界面的问题。
- 原版 `/api/...` 请求仍支持转发到已保存的 Mineradio API Base。
- 按用户要求隐藏 API 配置入口，不再显示左下角 API 弹窗。

## API Base

真机 / iPad 不能使用：

`http://127.0.0.1:3000`

因为那代表 iPad 自己，不是你的电脑。

推荐在电脑上运行原 Mineradio 后端：

```bash
git clone https://github.com/XxHuberrr/Mineradio.git
cd Mineradio
npm install
HOST=0.0.0.0 PORT=3000 node server.js
```

Windows PowerShell 可用：

```powershell
$env:HOST="0.0.0.0"
$env:PORT="3000"
node server.js
```

如果需要二维码/在线 API，请在上一个保留 API 设置入口的版本中保存过 API Base，或后续改成配置文件/内置地址。示例 API Base：

```text
http://电脑局域网IP:3000
```

例子：

```text
http://192.168.1.23:3000
```

## 注意

1. 构建机器必须能访问 GitHub，否则 `Fetch Original Mineradio Web` 会失败。
2. iOS 只桥接底层能力：文件导入、WebView、Electron `desktopWindow` 兼容、`/api` 转发。
3. 原版里 Windows/Electron 独有能力无法 1:1 保证，比如窗口控制、桌面歌词穿透、Windows 安装器更新。它们会被 iOS 桥接为 no-op 或 fallback，但视觉代码不重写。
4. 电脑防火墙需要允许 3000 端口，否则 iPad 会连不上。

## GitHub Workflow 参数

```text
FILE=MineradioiOS.xcodeproj
SCHEME=MineradioiOS
CONFIGURATION=Release
SDK=iphoneos
```


## v0.3.0 Splash Unlock

Hardens iPad splash entry: tap/click enters immediately and a timed fallback prevents the first screen from trapping the user.
