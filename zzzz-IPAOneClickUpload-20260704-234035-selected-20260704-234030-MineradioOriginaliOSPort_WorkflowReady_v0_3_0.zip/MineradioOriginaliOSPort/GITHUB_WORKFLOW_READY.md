# GitHub Workflow Ready

Version: `0.3.0`

Use these workflow inputs:

```text
FILE=MineradioiOS.xcodeproj
SCHEME=MineradioiOS
CONFIGURATION=Release
SDK=iphoneos
```

This package builds an unsigned IPA with the original Mineradio Web frontend loaded through WKWebView.

## Runtime notes

- v0.3.0 hardens iPad splash entry: tap/click should enter immediately, and a timed fallback prevents being trapped on the start screen.
- The visible API configuration panel remains hidden per user request.
- If a Mineradio API Base was already saved in localStorage, `/api/...` bridge routing still uses it.
- Do not use `127.0.0.1` on iPad for a PC backend; use the PC LAN IP such as `http://192.168.1.23:3000`.
