# Changelog

## v1.0

- 新增 SwiftUI iOS/iPadOS Xcode Project。
- 新增输入链接下载。
- 新增 1–32 并发连接设置。
- 新增 HTTP Range 多线程分段下载。
- 新增服务器不支持 Range 时自动退回普通单连接下载。
- 新增下载进度、大小、平均速度显示。
- 新增完成后系统分享/保存到文件。
- 新增 README 与基础注意事项。
