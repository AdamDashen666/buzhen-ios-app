import SwiftUI
import UIKit

struct ContentView: View {
    @StateObject private var manager = DownloadManager()
    @State private var showShareSheet = false

    var body: some View {
        NavigationStack {
            Form {
                Section("下载链接") {
                    TextField("https://example.com/file.zip", text: $manager.urlText, axis: .vertical)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .keyboardType(.URL)
                        .lineLimit(2...4)

                    Stepper(value: $manager.connectionCount, in: 1...32) {
                        HStack {
                            Text("并发连接数")
                            Spacer()
                            Text("\(manager.connectionCount)")
                                .foregroundStyle(.secondary)
                        }
                    }

                    Picker("快速预设", selection: $manager.connectionCount) {
                        Text("保守 4").tag(4)
                        Text("推荐 8").tag(8)
                        Text("高速 16").tag(16)
                        Text("极限 32").tag(32)
                    }
                    .pickerStyle(.segmented)
                }

                Section("状态") {
                    VStack(alignment: .leading, spacing: 10) {
                        HStack {
                            Text(manager.statusText)
                                .font(.headline)
                            Spacer()
                            Text(manager.speedText)
                                .foregroundStyle(.secondary)
                        }

                        ProgressView(value: manager.progress)

                        HStack {
                            Text(manager.progressText)
                            Spacer()
                            Text(manager.sizeText)
                        }
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                    }
                    .padding(.vertical, 4)
                }

                Section("操作") {
                    Button {
                        manager.startDownload()
                    } label: {
                        Label("开始多线程下载", systemImage: "arrow.down.circle.fill")
                    }
                    .disabled(manager.isDownloading)

                    Button(role: .destructive) {
                        manager.cancelDownload()
                    } label: {
                        Label("取消下载", systemImage: "xmark.circle")
                    }
                    .disabled(!manager.isDownloading)

                    if manager.completedFile != nil {
                        Button {
                            showShareSheet = true
                        } label: {
                            Label("保存 / 分享到文件", systemImage: "square.and.arrow.up")
                        }
                    }
                }

                Section("说明") {
                    Text("支持 Range 的服务器会自动分段并发下载；不支持 Range 或无法获取大小时，会自动退回普通单连接下载。")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
            }
            .navigationTitle("多线程下载器")
            .sheet(isPresented: $showShareSheet) {
                if let file = manager.completedFile {
                    ActivityView(activityItems: [file.url])
                }
            }
        }
    }
}

struct ActivityView: UIViewControllerRepresentable {
    let activityItems: [Any]

    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: activityItems, applicationActivities: nil)
    }

    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) { }
}
