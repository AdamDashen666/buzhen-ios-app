import Foundation
import SwiftUI

struct CompletedDownload: Identifiable {
    let id = UUID()
    let url: URL
}

@MainActor
final class DownloadManager: ObservableObject {
    @Published var urlText = ""
    @Published var connectionCount = 8
    @Published var isDownloading = false
    @Published var statusText = "等待输入链接"
    @Published var progress: Double = 0
    @Published var downloadedBytes: Int64 = 0
    @Published var totalBytes: Int64 = 0
    @Published var speedBytesPerSecond: Double = 0
    @Published var completedFile: CompletedDownload?

    private var task: Task<Void, Never>?

    var progressText: String {
        guard totalBytes > 0 else { return progress > 0 ? "下载中" : "0%" }
        return "\(Int(progress * 100))%"
    }

    var sizeText: String {
        if totalBytes <= 0 {
            return ByteFormatter.string(from: downloadedBytes)
        }
        return "\(ByteFormatter.string(from: downloadedBytes)) / \(ByteFormatter.string(from: totalBytes))"
    }

    var speedText: String {
        guard isDownloading else { return "" }
        return "\(ByteFormatter.string(from: Int64(speedBytesPerSecond)))/s"
    }

    func startDownload() {
        let trimmed = urlText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard let url = URL(string: trimmed), ["http", "https"].contains(url.scheme?.lowercased()) else {
            statusText = "链接格式不正确"
            return
        }

        task?.cancel()
        completedFile = nil
        isDownloading = true
        statusText = "准备下载"
        progress = 0
        downloadedBytes = 0
        totalBytes = 0
        speedBytesPerSecond = 0

        let safeConnections = max(1, min(connectionCount, 32))

        task = Task.detached(priority: .userInitiated) { [safeConnections] in
            do {
                let outputDirectory = try FileManager.default.url(
                    for: .documentDirectory,
                    in: .userDomainMask,
                    appropriateFor: nil,
                    create: true
                )

                let config = DownloadConfig(
                    url: url,
                    connections: safeConnections,
                    sliceBytes: 4 * 1024 * 1024,
                    outputDirectory: outputDirectory
                )

                let fileURL = try await ThreadedRangeDownloader.download(config: config) { update in
                    await MainActor.run {
                        self.statusText = update.phase
                        self.downloadedBytes = update.downloadedBytes
                        self.totalBytes = update.totalBytes
                        self.speedBytesPerSecond = update.speedBytesPerSecond
                        self.progress = update.totalBytes > 0 ? Double(update.downloadedBytes) / Double(update.totalBytes) : 0
                    }
                }

                await MainActor.run {
                    self.isDownloading = false
                    self.statusText = "下载完成"
                    self.progress = 1
                    self.completedFile = CompletedDownload(url: fileURL)
                }
            } catch is CancellationError {
                await MainActor.run {
                    self.isDownloading = false
                    self.statusText = "已取消"
                }
            } catch {
                await MainActor.run {
                    self.isDownloading = false
                    self.statusText = "失败：\(error.localizedDescription)"
                }
            }
        }
    }

    func cancelDownload() {
        task?.cancel()
        task = nil
        isDownloading = false
        statusText = "正在取消"
    }
}

enum ByteFormatter {
    static func string(from bytes: Int64) -> String {
        let units = ["B", "KB", "MB", "GB", "TB"]
        var value = Double(max(bytes, 0))
        var index = 0
        while value >= 1024, index < units.count - 1 {
            value /= 1024
            index += 1
        }
        if index == 0 { return "\(Int(value)) B" }
        return String(format: "%.2f %@", value, units[index])
    }
}
