import Foundation

struct DownloadConfig: Sendable {
    let url: URL
    let connections: Int
    let sliceBytes: Int64
    let outputDirectory: URL
}

struct DownloadUpdate: Sendable {
    let phase: String
    let downloadedBytes: Int64
    let totalBytes: Int64
    let speedBytesPerSecond: Double
}

enum DownloaderError: LocalizedError {
    case invalidHTTPStatus(Int)
    case missingFileSize
    case cannotCreateOutputFile

    var errorDescription: String? {
        switch self {
        case .invalidHTTPStatus(let code):
            return "服务器返回状态码 \(code)"
        case .missingFileSize:
            return "无法读取文件大小"
        case .cannotCreateOutputFile:
            return "无法创建输出文件"
        }
    }
}

actor ProgressCounter {
    private var downloadedBytes: Int64 = 0
    private let totalBytes: Int64
    private let startTime = Date()
    private var lastEmitTime = Date.distantPast

    init(totalBytes: Int64) {
        self.totalBytes = totalBytes
    }

    func add(_ byteCount: Int64, phase: String, force: Bool = false) -> DownloadUpdate? {
        downloadedBytes += byteCount
        let now = Date()
        guard force || now.timeIntervalSince(lastEmitTime) >= 0.12 || downloadedBytes >= totalBytes else {
            return nil
        }
        lastEmitTime = now
        let elapsed = max(now.timeIntervalSince(startTime), 0.001)
        return DownloadUpdate(
            phase: phase,
            downloadedBytes: downloadedBytes,
            totalBytes: totalBytes,
            speedBytesPerSecond: Double(downloadedBytes) / elapsed
        )
    }
}

struct ThreadedRangeDownloader {
    private static let session: URLSession = {
        let configuration = URLSessionConfiguration.default
        configuration.waitsForConnectivity = true
        configuration.timeoutIntervalForRequest = 60
        configuration.timeoutIntervalForResource = 24 * 60 * 60
        configuration.httpMaximumConnectionsPerHost = 32
        return URLSession(configuration: configuration)
    }()

    static func download(
        config: DownloadConfig,
        onUpdate: @escaping @Sendable (DownloadUpdate) async -> Void
    ) async throws -> URL {
        try Task.checkCancellation()
        try FileManager.default.createDirectory(at: config.outputDirectory, withIntermediateDirectories: true)

        await onUpdate(DownloadUpdate(phase: "读取服务器信息", downloadedBytes: 0, totalBytes: 0, speedBytesPerSecond: 0))

        let info = try await fetchFileInfo(url: config.url)
        let filename = safeFilename(from: config.url, suggested: info.suggestedFilename)
        let finalURL = uniqueURL(in: config.outputDirectory, filename: filename)

        guard info.supportsRanges, info.contentLength > 0, config.connections > 1 else {
            return try await singleConnectionDownload(config: config, finalURL: finalURL, totalBytes: info.contentLength, onUpdate: onUpdate)
        }

        let totalBytes = info.contentLength
        let tempRoot = FileManager.default.temporaryDirectory
            .appendingPathComponent("ThreadedRangeDownload-\(UUID().uuidString)", isDirectory: true)
        try FileManager.default.createDirectory(at: tempRoot, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: tempRoot) }

        let ranges = makeRanges(totalBytes: totalBytes, connections: config.connections)
        let progress = ProgressCounter(totalBytes: totalBytes)

        await onUpdate(DownloadUpdate(phase: "并发下载中", downloadedBytes: 0, totalBytes: totalBytes, speedBytesPerSecond: 0))

        try await withThrowingTaskGroup(of: Void.self) { group in
            for range in ranges {
                group.addTask {
                    let partURL = tempRoot.appendingPathComponent("part-\(range.index)")
                    try await downloadPart(
                        url: config.url,
                        range: range,
                        sliceBytes: config.sliceBytes,
                        partURL: partURL,
                        progress: progress,
                        onUpdate: onUpdate
                    )
                }
            }
            try await group.waitForAll()
        }

        await onUpdate(DownloadUpdate(phase: "合并文件中", downloadedBytes: totalBytes, totalBytes: totalBytes, speedBytesPerSecond: 0))
        try mergeParts(partCount: ranges.count, tempRoot: tempRoot, destinationURL: finalURL)

        return finalURL
    }

    private static func fetchFileInfo(url: URL) async throws -> (contentLength: Int64, supportsRanges: Bool, suggestedFilename: String?) {
        var request = URLRequest(url: url)
        request.httpMethod = "HEAD"
        request.cachePolicy = .reloadIgnoringLocalAndRemoteCacheData

        do {
            let (_, response) = try await session.data(for: request)
            guard let http = response as? HTTPURLResponse else {
                return (response.expectedContentLength, false, response.suggestedFilename)
            }
            let rangeHeader = http.value(forHTTPHeaderField: "Accept-Ranges")?.lowercased() ?? ""
            let length = response.expectedContentLength
            return (length, rangeHeader.contains("bytes"), response.suggestedFilename)
        } catch {
            return try await fetchFileInfoWithProbe(url: url)
        }
    }

    private static func fetchFileInfoWithProbe(url: URL) async throws -> (contentLength: Int64, supportsRanges: Bool, suggestedFilename: String?) {
        var request = URLRequest(url: url)
        request.setValue("bytes=0-0", forHTTPHeaderField: "Range")
        request.cachePolicy = .reloadIgnoringLocalAndRemoteCacheData

        let (_, response) = try await session.data(for: request)
        guard let http = response as? HTTPURLResponse else {
            return (response.expectedContentLength, false, response.suggestedFilename)
        }

        if http.statusCode == 206,
           let contentRange = http.value(forHTTPHeaderField: "Content-Range"),
           let slash = contentRange.lastIndex(of: "/") {
            let totalText = contentRange[contentRange.index(after: slash)...]
            let total = Int64(totalText) ?? -1
            return (total, total > 0, response.suggestedFilename)
        }

        return (response.expectedContentLength, false, response.suggestedFilename)
    }

    private static func singleConnectionDownload(
        config: DownloadConfig,
        finalURL: URL,
        totalBytes: Int64,
        onUpdate: @escaping @Sendable (DownloadUpdate) async -> Void
    ) async throws -> URL {
        await onUpdate(DownloadUpdate(phase: "服务器不支持分段，普通下载中", downloadedBytes: 0, totalBytes: totalBytes, speedBytesPerSecond: 0))
        let (tempURL, response) = try await session.download(from: config.url)
        if let http = response as? HTTPURLResponse, !(200...299).contains(http.statusCode) {
            throw DownloaderError.invalidHTTPStatus(http.statusCode)
        }
        try? FileManager.default.removeItem(at: finalURL)
        try FileManager.default.moveItem(at: tempURL, to: finalURL)
        let size = (try? FileManager.default.attributesOfItem(atPath: finalURL.path)[.size] as? NSNumber)?.int64Value ?? totalBytes
        await onUpdate(DownloadUpdate(phase: "下载完成", downloadedBytes: max(size, 0), totalBytes: max(size, totalBytes), speedBytesPerSecond: 0))
        return finalURL
    }

    private static func downloadPart(
        url: URL,
        range: ByteRange,
        sliceBytes: Int64,
        partURL: URL,
        progress: ProgressCounter,
        onUpdate: @escaping @Sendable (DownloadUpdate) async -> Void
    ) async throws {
        FileManager.default.createFile(atPath: partURL.path, contents: nil)
        let handle = try FileHandle(forWritingTo: partURL)
        defer { try? handle.close() }

        var offset = range.start
        while offset <= range.end {
            try Task.checkCancellation()
            let end = min(offset + sliceBytes - 1, range.end)
            var request = URLRequest(url: url)
            request.cachePolicy = .reloadIgnoringLocalAndRemoteCacheData
            request.setValue("bytes=\(offset)-\(end)", forHTTPHeaderField: "Range")

            let (data, response) = try await session.data(for: request)
            if let http = response as? HTTPURLResponse, http.statusCode != 206 {
                throw DownloaderError.invalidHTTPStatus(http.statusCode)
            }

            handle.write(data)
            offset = end + 1

            if let update = await progress.add(Int64(data.count), phase: "并发下载中") {
                await onUpdate(update)
            }
        }
    }

    private static func mergeParts(partCount: Int, tempRoot: URL, destinationURL: URL) throws {
        FileManager.default.createFile(atPath: destinationURL.path, contents: nil)
        guard let output = FileHandle(forWritingAtPath: destinationURL.path) else {
            throw DownloaderError.cannotCreateOutputFile
        }
        defer { try? output.close() }

        for index in 0..<partCount {
            let partURL = tempRoot.appendingPathComponent("part-\(index)")
            let input = try FileHandle(forReadingFrom: partURL)
            defer { try? input.close() }

            while true {
                let data = input.readData(ofLength: 4 * 1024 * 1024)
                if data.isEmpty { break }
                output.write(data)
            }
        }
    }

    private static func makeRanges(totalBytes: Int64, connections: Int) -> [ByteRange] {
        let count = max(1, min(connections, Int(totalBytes)))
        let base = totalBytes / Int64(count)
        var ranges: [ByteRange] = []
        var start: Int64 = 0

        for index in 0..<count {
            let isLast = index == count - 1
            let end = isLast ? totalBytes - 1 : start + base - 1
            ranges.append(ByteRange(index: index, start: start, end: end))
            start = end + 1
        }
        return ranges
    }

    private static func safeFilename(from url: URL, suggested: String?) -> String {
        let raw = suggested?.isEmpty == false ? suggested! : (url.lastPathComponent.isEmpty ? "downloaded-file" : url.lastPathComponent)
        let cleaned = raw
            .replacingOccurrences(of: "/", with: "-")
            .replacingOccurrences(of: ":", with: "-")
            .replacingOccurrences(of: "?", with: "-")
            .replacingOccurrences(of: "&", with: "-")
        return cleaned.isEmpty ? "downloaded-file" : cleaned
    }

    private static func uniqueURL(in directory: URL, filename: String) -> URL {
        let base = (filename as NSString).deletingPathExtension
        let ext = (filename as NSString).pathExtension
        var candidate = directory.appendingPathComponent(filename)
        var index = 1

        while FileManager.default.fileExists(atPath: candidate.path) {
            let name = ext.isEmpty ? "\(base)-\(index)" : "\(base)-\(index).\(ext)"
            candidate = directory.appendingPathComponent(name)
            index += 1
        }
        return candidate
    }
}

struct ByteRange: Sendable {
    let index: Int
    let start: Int64
    let end: Int64
}
