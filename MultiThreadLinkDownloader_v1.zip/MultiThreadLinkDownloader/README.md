# MultiThreadLinkDownloader

一个 SwiftUI iOS/iPadOS 多线程链接下载器 Xcode Project。

## 功能

- 输入 HTTP/HTTPS 下载链接
- 设置并发连接数：1–32
- 支持 `Accept-Ranges: bytes` 的服务器会使用 Range 分段并发下载
- 每个线程按 4 MB 小片下载，避免单个大分段一次性占用大量内存
- 实时显示进度、已下载/总大小、平均速度
- 下载完成后通过系统分享面板保存到“文件”或转发到其他 App
- 不依赖第三方库

## 运行

1. 用 Xcode 打开 `MultiThreadLinkDownloader.xcodeproj`
2. 选择你的 Team / Bundle Identifier
3. 连接 iPhone 或 iPad
4. Run

## 注意

- 只有服务器支持 Range 分段时，才会真正并发下载。
- 部分网盘、登录态链接、临时签名链接、反爬链接可能会失败。
- `Info.plist` 里开启了 `NSAllowsArbitraryLoads`，方便测试 HTTP 链接；正式上架前建议改成更严格的域名白名单。
- 这个版本没有做断点续传数据库，取消后需要重新下载。
