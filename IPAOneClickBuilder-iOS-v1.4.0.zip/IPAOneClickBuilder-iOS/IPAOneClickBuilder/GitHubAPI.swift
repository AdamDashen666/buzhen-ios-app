import Foundation

final class GitHubAPI {
    private let token: String
    private let session: URLSession
    private let apiRoot = "https://api.github.com"

    init(token: String, session: URLSession? = nil) {
        self.token = token.trimmingCharacters(in: .whitespacesAndNewlines)
        self.session = session ?? GitHubAPI.makeDownloadSafeSession()
    }

    private static func makeDownloadSafeSession() -> URLSession {
        let configuration = URLSessionConfiguration.ephemeral
        configuration.waitsForConnectivity = true
        configuration.requestCachePolicy = .reloadIgnoringLocalAndRemoteCacheData
        configuration.urlCache = nil
        configuration.timeoutIntervalForRequest = 900
        configuration.timeoutIntervalForResource = 3600
        return URLSession(configuration: configuration)
    }

    // MARK: - Workflow resolving / dispatch

    func getWorkflowRun(owner: String, repo: String, runID: Int64) async throws -> GitHubWorkflowRunDetail {
        let url = endpoint("repos/\(owner)/\(repo)/actions/runs/\(runID)")
        return try await sendJSON(url: url, method: "GET", jsonBody: nil, decode: GitHubWorkflowRunDetail.self)
    }

    func getWorkflow(owner: String, repo: String, workflowID: Int64) async throws -> GitHubWorkflow {
        let url = endpoint("repos/\(owner)/\(repo)/actions/workflows/\(workflowID)")
        return try await sendJSON(url: url, method: "GET", jsonBody: nil, decode: GitHubWorkflow.self)
    }

    func dispatchWorkflow(owner: String, repo: String, workflowIdentifier: String, branch: String, inputs: [String: String] = [:]) async throws {
        let encodedWorkflow = workflowIdentifier.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? workflowIdentifier
        let url = endpoint("repos/\(owner)/\(repo)/actions/workflows/\(encodedWorkflow)/dispatches")
        var body: [String: Any] = ["ref": branch]
        if !inputs.isEmpty { body["inputs"] = inputs }
        _ = try await sendJSON(url: url, method: "POST", jsonBody: body, decode: EmptyResponse.self, allowEmpty: true)
    }

    func listWorkflowRuns(owner: String, repo: String, workflowIdentifier: String, branch: String) async throws -> [GitHubWorkflowRun] {
        let encodedWorkflow = workflowIdentifier.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? workflowIdentifier
        var components = URLComponents(url: endpoint("repos/\(owner)/\(repo)/actions/workflows/\(encodedWorkflow)/runs"), resolvingAgainstBaseURL: false)!
        components.queryItems = [
            URLQueryItem(name: "event", value: "workflow_dispatch"),
            URLQueryItem(name: "branch", value: branch),
            URLQueryItem(name: "per_page", value: "30")
        ]
        let response = try await sendJSON(url: components.url!, method: "GET", jsonBody: nil, decode: GitHubWorkflowRunsResponse.self)
        return response.workflowRuns
    }

    // MARK: - Repository content upload / cleanup

    func listDirectory(owner: String, repo: String, path: String = "", branch: String) async throws -> [GitHubContentItem] {
        let cleanPath = path.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        let encoded = cleanPath.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? cleanPath
        let suffix = encoded.isEmpty ? "contents" : "contents/\(encoded)"
        var components = URLComponents(url: endpoint("repos/\(owner)/\(repo)/\(suffix)"), resolvingAgainstBaseURL: false)!
        components.queryItems = [URLQueryItem(name: "ref", value: branch)]
        return try await sendJSON(url: components.url!, method: "GET", jsonBody: nil, decode: [GitHubContentItem].self)
    }

    func uploadOrUpdateFile(owner: String, repo: String, path: String, branch: String, data: Data, message: String, existingSHA: String? = nil) async throws -> GitHubContentWriteResponse {
        let encodedPath = path.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? path
        let url = endpoint("repos/\(owner)/\(repo)/contents/\(encodedPath)")
        var body: [String: Any] = [
            "message": message,
            "content": data.base64EncodedString(),
            "branch": branch
        ]
        if let existingSHA { body["sha"] = existingSHA }
        return try await sendJSON(url: url, method: "PUT", jsonBody: body, decode: GitHubContentWriteResponse.self)
    }

    func deleteContentFile(owner: String, repo: String, path: String, sha: String, branch: String, message: String) async throws {
        let encodedPath = path.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? path
        let url = endpoint("repos/\(owner)/\(repo)/contents/\(encodedPath)")
        let body: [String: Any] = [
            "message": message,
            "sha": sha,
            "branch": branch
        ]
        _ = try await sendJSON(url: url, method: "DELETE", jsonBody: body, decode: GitHubContentWriteResponse.self)
    }

    // MARK: - Actions jobs, artifacts and logs

    func listWorkflowRunArtifacts(owner: String, repo: String, runID: Int64) async throws -> [GitHubArtifact] {
        var components = URLComponents(url: endpoint("repos/\(owner)/\(repo)/actions/runs/\(runID)/artifacts"), resolvingAgainstBaseURL: false)!
        components.queryItems = [URLQueryItem(name: "per_page", value: "100")]
        let response = try await sendJSON(url: components.url!, method: "GET", jsonBody: nil, decode: GitHubArtifactsResponse.self)
        return response.artifacts
    }

    func listRepositoryArtifacts(owner: String, repo: String) async throws -> [GitHubArtifact] {
        var components = URLComponents(url: endpoint("repos/\(owner)/\(repo)/actions/artifacts"), resolvingAgainstBaseURL: false)!
        components.queryItems = [URLQueryItem(name: "per_page", value: "100")]
        let response = try await sendJSON(url: components.url!, method: "GET", jsonBody: nil, decode: GitHubArtifactsResponse.self)
        return response.artifacts
    }

    func downloadArtifact(owner: String, repo: String, artifact: GitHubArtifact, destinationName: String) async throws -> URL {
        let url = endpoint("repos/\(owner)/\(repo)/actions/artifacts/\(artifact.id)/zip")
        return try await downloadVerified(
            url: url,
            destinationName: destinationName,
            accept: "application/zip",
            expectedSize: artifact.sizeInBytes,
            expectedKind: .zip,
            retries: 3
        )
    }

    func deleteArtifact(owner: String, repo: String, artifactID: Int64) async {
        do {
            let url = endpoint("repos/\(owner)/\(repo)/actions/artifacts/\(artifactID)")
            _ = try await sendRaw(url: url, method: "DELETE", body: nil, contentType: nil)
        } catch { }
    }

    func downloadWorkflowRunLogs(owner: String, repo: String, runID: Int64, destinationName: String) async throws -> URL {
        let url = endpoint("repos/\(owner)/\(repo)/actions/runs/\(runID)/logs")
        return try await downloadVerified(
            url: url,
            destinationName: destinationName,
            accept: "application/zip",
            expectedSize: nil,
            expectedKind: .zip,
            retries: 3
        )
    }

    func listWorkflowRunJobs(owner: String, repo: String, runID: Int64) async throws -> [GitHubJob] {
        var components = URLComponents(url: endpoint("repos/\(owner)/\(repo)/actions/runs/\(runID)/jobs"), resolvingAgainstBaseURL: false)!
        components.queryItems = [URLQueryItem(name: "per_page", value: "100")]
        let response = try await sendJSON(url: components.url!, method: "GET", jsonBody: nil, decode: GitHubJobsResponse.self)
        return response.jobs
    }

    // MARK: - Release mode kept for old generic workflow

    func createTemporaryRelease(owner: String, repo: String, tag: String) async throws -> GitHubRelease {
        let url = endpoint("repos/\(owner)/\(repo)/releases")
        let body: [String: Any] = [
            "tag_name": tag,
            "name": "IPA Builder Temporary Upload \(tag)",
            "body": "Temporary upload created by IPA OneClick Builder.",
            "draft": false,
            "prerelease": true
        ]
        return try await sendJSON(url: url, method: "POST", jsonBody: body, decode: GitHubRelease.self)
    }

    func listReleases(owner: String, repo: String, perPage: Int = 30) async throws -> [GitHubRelease] {
        var components = URLComponents(url: endpoint("repos/\(owner)/\(repo)/releases"), resolvingAgainstBaseURL: false)!
        components.queryItems = [URLQueryItem(name: "per_page", value: String(perPage))]
        return try await sendJSON(url: components.url!, method: "GET", jsonBody: nil, decode: [GitHubRelease].self)
    }

    func deleteReleaseAndTag(owner: String, repo: String, releaseID: Int64, tag: String) async {
        do {
            let releaseURL = endpoint("repos/\(owner)/\(repo)/releases/\(releaseID)")
            _ = try await sendRaw(url: releaseURL, method: "DELETE", body: nil, contentType: nil)
        } catch { }

        do {
            let encodedTag = tag.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? tag
            let tagURL = endpoint("repos/\(owner)/\(repo)/git/refs/tags/\(encodedTag)")
            _ = try await sendRaw(url: tagURL, method: "DELETE", body: nil, contentType: nil)
        } catch { }
    }

    func uploadReleaseAsset(uploadURL: String, fileURL: URL, assetName: String) async throws -> GitHubAsset {
        guard let base = uploadURL.components(separatedBy: "{").first,
              var components = URLComponents(string: base) else {
            throw APIError.invalidURL
        }
        components.queryItems = [URLQueryItem(name: "name", value: assetName)]
        guard let url = components.url else { throw APIError.invalidURL }
        var request = makeRequest(url: url, method: "POST")
        request.setValue("application/zip", forHTTPHeaderField: "Content-Type")
        let (data, response) = try await session.upload(for: request, fromFile: fileURL)
        try validate(response: response, data: data)
        return try JSONDecoder().decode(GitHubAsset.self, from: data)
    }

    func getReleaseByTag(owner: String, repo: String, tag: String) async throws -> GitHubRelease {
        let encodedTag = tag.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? tag
        let url = endpoint("repos/\(owner)/\(repo)/releases/tags/\(encodedTag)")
        return try await sendJSON(url: url, method: "GET", jsonBody: nil, decode: GitHubRelease.self)
    }

    func downloadReleaseAsset(owner: String, repo: String, asset: GitHubAsset, destinationName: String) async throws -> URL {
        let url = endpoint("repos/\(owner)/\(repo)/releases/assets/\(asset.id)")
        let lower = destinationName.lowercased()
        let kind: DownloadKind = (lower.hasSuffix(".ipa") || lower.hasSuffix(".zip")) ? .zip : .any
        return try await downloadVerified(
            url: url,
            destinationName: destinationName,
            accept: "application/octet-stream",
            expectedSize: asset.size,
            expectedKind: kind,
            retries: 3
        )
    }

    func deleteAsset(owner: String, repo: String, assetID: Int64) async {
        do {
            let url = endpoint("repos/\(owner)/\(repo)/releases/assets/\(assetID)")
            _ = try await sendRaw(url: url, method: "DELETE", body: nil, contentType: nil)
        } catch { }
    }

    // MARK: - Core request helpers

    private enum DownloadKind {
        case any
        case zip
    }

    private func downloadVerified(
        url: URL,
        destinationName: String,
        accept: String,
        expectedSize: Int?,
        expectedKind: DownloadKind,
        retries: Int
    ) async throws -> URL {
        var lastError: Error?

        for attempt in 1...max(1, retries) {
            let safeName = destinationName.replacingOccurrences(of: "/", with: "-")
            let destination = try outputsDirectory().appendingPathComponent(safeName)

            do {
                if FileManager.default.fileExists(atPath: destination.path) {
                    try FileManager.default.removeItem(at: destination)
                }

                let tempURL = try await downloadOnce(url: url, accept: accept)
                try FileManager.default.moveItem(at: tempURL, to: destination)

                try validateDownloadedFile(destination, expectedSize: expectedSize, expectedKind: expectedKind)
                return destination
            } catch {
                lastError = error
                let badName = "\(safeName).bad-attempt-\(attempt)"
                let badURL = try? outputsDirectory().appendingPathComponent(badName)
                if FileManager.default.fileExists(atPath: destination.path), let badURL {
                    try? FileManager.default.removeItem(at: badURL)
                    try? FileManager.default.moveItem(at: destination, to: badURL)
                }

                if attempt < max(1, retries) {
                    try? await Task.sleep(nanoseconds: 2_000_000_000)
                    continue
                }
            }
        }

        throw lastError ?? APIError.invalidDownload("下载失败：没有拿到完整文件。")
    }

    private func downloadOnce(url: URL, accept: String) async throws -> URL {
        var request = makeRequest(url: url, method: "GET")
        request.setValue(accept, forHTTPHeaderField: "Accept")
        request.setValue("no-cache", forHTTPHeaderField: "Cache-Control")
        request.timeoutInterval = 900

        let (tempURL, response) = try await session.download(for: request)
        try validate(response: response, data: nil)
        return tempURL
    }

    private func outputsDirectory() throws -> URL {
        let documents = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let outputs = documents.appendingPathComponent("IPABuilderOutputs", isDirectory: true)
        try FileManager.default.createDirectory(at: outputs, withIntermediateDirectories: true)
        return outputs
    }

    private func validateDownloadedFile(_ url: URL, expectedSize: Int?, expectedKind: DownloadKind) throws {
        let values = try url.resourceValues(forKeys: [.fileSizeKey])
        let actualSize = values.fileSize ?? 0

        guard actualSize > 0 else {
            throw APIError.invalidDownload("下载到的是空文件。")
        }

        if let expectedSize, expectedSize > 0 {
            let minimumAcceptable = max(1, Int(Double(expectedSize) * 0.98))
            if actualSize < minimumAcceptable {
                throw APIError.invalidDownload("下载文件疑似不完整：实际 \(actualSize) bytes，GitHub 显示约 \(expectedSize) bytes。")
            }
        }

        if expectedKind == .zip {
            guard Self.looksLikeCompleteZip(url) else {
                throw APIError.invalidDownload("下载的 ZIP 不完整或损坏：没有找到 ZIP 结束目录 EOCD。已自动重试；如果仍失败，不会再把坏 ZIP 当成成功结果。")
            }
        }
    }

    private static func looksLikeCompleteZip(_ url: URL) -> Bool {
        guard let handle = try? FileHandle(forReadingFrom: url) else { return false }
        defer { try? handle.close() }

        let size = (try? handle.seekToEnd()) ?? 0
        guard size >= 22 else { return false }

        let tailLength = min(UInt64(70_000), size)
        do {
            try handle.seek(toOffset: size - tailLength)
            let tail = try handle.readToEnd() ?? Data()
            guard tail.count >= 4 else { return false }

            let signature: [UInt8] = [0x50, 0x4b, 0x05, 0x06]
            let bytes = [UInt8](tail)
            if bytes.count < signature.count { return false }

            for index in stride(from: bytes.count - signature.count, through: 0, by: -1) {
                if bytes[index] == signature[0],
                   bytes[index + 1] == signature[1],
                   bytes[index + 2] == signature[2],
                   bytes[index + 3] == signature[3] {
                    return true
                }
            }
            return false
        } catch {
            return false
        }
    }

    private func sendJSON<T: Decodable>(url: URL, method: String, jsonBody: [String: Any]?, decode: T.Type, allowEmpty: Bool = false) async throws -> T {
        let body = try jsonBody.map { try JSONSerialization.data(withJSONObject: $0, options: []) }
        return try await sendJSON(url: url, method: method, body: body, contentType: body == nil ? nil : "application/json", decode: decode, allowEmpty: allowEmpty)
    }

    private func sendJSON<T: Decodable>(url: URL, method: String, body: Data?, contentType: String?, decode: T.Type, allowEmpty: Bool = false) async throws -> T {
        let (data, _) = try await sendRaw(url: url, method: method, body: body, contentType: contentType)
        if allowEmpty && data.isEmpty {
            return EmptyResponse() as! T
        }
        do {
            return try JSONDecoder().decode(T.self, from: data)
        } catch {
            let text = String(data: data, encoding: .utf8) ?? ""
            throw APIError.decodingFailed(text)
        }
    }

    private func sendRaw(url: URL, method: String, body: Data?, contentType: String?) async throws -> (Data, URLResponse) {
        var request = makeRequest(url: url, method: method)
        if let contentType { request.setValue(contentType, forHTTPHeaderField: "Content-Type") }
        request.httpBody = body
        let (data, response) = try await session.data(for: request)
        try validate(response: response, data: data)
        return (data, response)
    }

    private func endpoint(_ path: String) -> URL {
        URL(string: "\(apiRoot)/\(path)")!
    }

    private func makeRequest(url: URL, method: String) -> URLRequest {
        var request = URLRequest(url: url)
        request.httpMethod = method
        request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        request.setValue("application/vnd.github+json", forHTTPHeaderField: "Accept")
        request.setValue("2022-11-28", forHTTPHeaderField: "X-GitHub-Api-Version")
        request.timeoutInterval = 900
        return request
    }

    private func validate(response: URLResponse, data: Data?) throws {
        guard let http = response as? HTTPURLResponse else { return }
        guard (200...299).contains(http.statusCode) else {
            let message = data.flatMap { String(data: $0, encoding: .utf8) } ?? HTTPURLResponse.localizedString(forStatusCode: http.statusCode)
            throw APIError.httpStatus(http.statusCode, message)
        }
    }
}

struct EmptyResponse: Decodable { }

enum APIError: LocalizedError {
    case invalidURL
    case httpStatus(Int, String)
    case decodingFailed(String)
    case invalidDownload(String)

    var errorDescription: String? {
        switch self {
        case .invalidURL:
            return "Invalid URL"
        case .httpStatus(let code, let message):
            return "GitHub API error \(code): \(message)"
        case .decodingFailed(let body):
            return "Cannot decode GitHub response: \(body.prefix(500))"
        case .invalidDownload(let message):
            return message
        }
    }
}
