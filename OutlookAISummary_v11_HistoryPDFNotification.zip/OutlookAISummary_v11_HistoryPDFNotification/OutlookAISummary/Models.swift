import Foundation

struct AppSettings: Codable, Equatable {
    var enabled: Bool = true
    var frequency: SummaryFrequency = .daily
    var language: String = "zh-CN"
    var includeJunkUnread: Bool = true
    var autoDeleteEnabled: Bool = true
    var deleteAfterDays: Int = 30
    var permanentDeleteAfterDays: Int = 7
}

enum SummaryFrequency: String, Codable, CaseIterable, Identifiable {
    case daily
    case sixHours
    case monthly

    var id: String { rawValue }

    var title: String {
        switch self {
        case .daily: return "每天"
        case .sixHours: return "每 6 小时"
        case .monthly: return "每月"
        }
    }

    var windowHours: Int {
        switch self {
        case .sixHours: return 6
        case .daily: return 24
        case .monthly: return 720
        }
    }

    var scheduleDescription: String {
        switch self {
        case .sixHours: return "每次只总结最近 6 小时内的邮件。"
        case .daily: return "每次只总结最近 24 小时内的邮件。"
        case .monthly: return "每次只总结最近 30 天内的邮件。"
        }
    }
}

struct AuthStatusResponse: Codable {
    let linked: Bool
    let user: LinkedUser?
}

struct LinkedUser: Codable {
    let displayName: String?
    let email: String?
    let settings: AppSettings?
    let lastRunAt: String?
}

struct SummaryItem: Codable, Identifiable, Equatable {
    let id: String
    let title: String
    let content: String
    let unreadCount: Int
    let junkUnreadCount: Int
    let createdAt: String
}

struct SummariesResponse: Codable {
    let summaries: [SummaryItem]
}

struct DeviceRegisterResponse: Codable {
    let deviceId: String
    let deviceToken: String?
    let platform: String?
    let updatedAt: String?
}

struct RunSummaryResponse: Decodable {
    let ok: Bool
    let mode: String?
    let processed: Int?
    let processedCount: Int?
    let summary: SummaryItem?
    let summaryText: String?
    let message: String?
    let error: String?
    let hasMore: Bool?
    let startTime: String?
    let endTime: String?
    let importantCount: Int?
    let spamCount: Int?
    let pdfFileName: String?
    let pdfURL: String?
    let pdfPath: String?

    enum CodingKeys: String, CodingKey {
        case ok
        case mode
        case processed
        case processedCount
        case processed_count
        case summary
        case message
        case error
        case hasMore
        case startTime
        case endTime
        case importantCount
        case spamCount
        case pdfFileName
        case pdfURL
        case pdfUrl
        case pdfPath
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.ok = (try? container.decode(Bool.self, forKey: .ok)) ?? false
        self.mode = try? container.decode(String.self, forKey: .mode)
        self.processed = try? container.decode(Int.self, forKey: .processed)
        self.processedCount = (try? container.decode(Int.self, forKey: .processedCount))
            ?? (try? container.decode(Int.self, forKey: .processed_count))
        self.message = try? container.decode(String.self, forKey: .message)
        self.error = try? container.decode(String.self, forKey: .error)
        self.hasMore = try? container.decode(Bool.self, forKey: .hasMore)
        self.startTime = try? container.decode(String.self, forKey: .startTime)
        self.endTime = try? container.decode(String.self, forKey: .endTime)
        self.importantCount = try? container.decode(Int.self, forKey: .importantCount)
        self.spamCount = try? container.decode(Int.self, forKey: .spamCount)
        self.pdfFileName = try? container.decode(String.self, forKey: .pdfFileName)
        self.pdfURL = (try? container.decode(String.self, forKey: .pdfURL))
            ?? (try? container.decode(String.self, forKey: .pdfUrl))
        self.pdfPath = try? container.decode(String.self, forKey: .pdfPath)

        if let item = try? container.decode(SummaryItem.self, forKey: .summary) {
            self.summary = item
            self.summaryText = item.content
        } else if let text = try? container.decode(String.self, forKey: .summary) {
            self.summary = nil
            self.summaryText = text
        } else if let object = try? container.decode(SummaryTextObject.self, forKey: .summary) {
            self.summary = nil
            self.summaryText = object.content ?? object.text ?? object.result ?? object.message
        } else {
            self.summary = nil
            self.summaryText = nil
        }
    }

    var effectiveProcessedCount: Int? {
        processed ?? processedCount ?? summary?.unreadCount
    }

    var displaySummaryText: String? {
        summaryText ?? summary?.content ?? message
    }

    var backendPDFInfo: String? {
        pdfFileName ?? pdfURL ?? pdfPath
    }
}

private struct SummaryTextObject: Decodable {
    let content: String?
    let text: String?
    let result: String?
    let message: String?
}

struct LocalSummaryRecord: Codable, Identifiable, Equatable {
    let id: String
    var title: String
    var content: String
    var createdAt: Date
    var startTime: String?
    var endTime: String?
    var processedCount: Int
    var importantCount: Int
    var spamCount: Int
    var pdfFileName: String?
    var backendPDFInfo: String?

    var dateTitle: String {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter.string(from: createdAt)
    }

    var timeTitle: String {
        createdAt.formatted(date: .omitted, time: .shortened)
    }

    var createdAtDisplay: String {
        createdAt.formatted(date: .abbreviated, time: .shortened)
    }

    var timeRangeDisplay: String {
        let start = startTime?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        let end = endTime?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        if !start.isEmpty && !end.isEmpty { return "\(start) - \(end)" }
        if !start.isEmpty { return start }
        if !end.isEmpty { return end }
        return "后端未返回"
    }
}

struct LocalSummaryDayGroup: Identifiable, Equatable {
    let id: String
    let dateTitle: String
    let records: [LocalSummaryRecord]
}

struct SettingsResponse: Codable {
    let ok: Bool
    let settings: AppSettings
}

struct BackendHealthResponse: Codable, Equatable {
    let ok: Bool
    let time: String?
    let provider: String?
}

struct IMAPTestResponse: Codable, Equatable {
    let ok: Bool
    let account: String?
    let host: String?
    let inboxMailbox: String?
    let messages: Int?
    let unseen: Int?
    let error: String?
}

struct AITestResponse: Codable, Equatable {
    let ok: Bool
    let reply: String?
    let error: String?
}
