import SwiftUI
import QuickLook

struct DashboardView: View {
    @EnvironmentObject private var state: AppState

    var body: some View {
        ZStack {
            LiquidBackground()
            ScrollView {
                VStack(spacing: 18) {
                    header
                    if let warning = state.backendValidationMessage {
                        backendWarningCard(warning)
                    }
                    statusCard
                    connectionCheckCard
                    if state.linkedUser != nil {
                        controlCard
                    } else {
                        loginCard
                    }
                    historyList
                    if let error = state.lastError, !error.isEmpty {
                        errorCard(error)
                    }
                }
                .padding()
                .frame(maxWidth: 860)
                .frame(maxWidth: .infinity)
            }
            .refreshable { await state.refreshAll() }
        }
        .navigationTitle("总览")
        .toolbar {
            Button("刷新") { Task { await state.refreshAll() } }
        }
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Mail AI Summary")
                .font(.largeTitle.bold())
            Text("QQ IMAP + Render 后端；AI 密钥和模型只由后端环境变量控制。")
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private func backendWarningCard(_ message: String) -> some View {
        GlassCard {
            VStack(alignment: .leading, spacing: 10) {
                Label("需要先配置后端", systemImage: "server.rack")
                    .font(.headline)
                Text(message)
                    .font(.footnote)
                    .textSelection(.enabled)
                Text("设置 → 后端地址：填 Render/Railway/Vercel/自建服务器的 HTTPS 地址。")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
            }
            .foregroundStyle(.orange.opacity(0.95))
        }
    }

    private var statusCard: some View {
        GlassCard {
            VStack(alignment: .leading, spacing: 14) {
                HStack {
                    Image(systemName: state.linkedUser == nil ? "link.badge.plus" : "checkmark.seal.fill")
                        .font(.title2)
                    VStack(alignment: .leading, spacing: 3) {
                        Text(state.linkedUser == nil ? "未连接邮箱" : "邮箱已连接")
                            .font(.headline)
                        Text(state.statusText)
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                    }
                    Spacer()
                    if state.isLoading { ProgressView().tint(.white) }
                }
                HStack(spacing: 8) {
                    CapsuleTag(text: state.settings.frequency.title, systemImage: "clock")
                    CapsuleTag(text: "中文", systemImage: "textformat")
                    CapsuleTag(text: state.imapStatus?.ok == true ? "imap" : (state.backendHealth?.provider ?? "后端未检查"), systemImage: "server.rack")
                    CapsuleTag(text: state.imapStatus?.ok == true ? "IMAP 正常" : "IMAP 未检查", systemImage: "envelope.badge")
                }
            }
        }
    }

    private var connectionCheckCard: some View {
        GlassCard {
            VStack(alignment: .leading, spacing: 14) {
                HStack {
                    SectionTitle(title: "后端连接检查", subtitle: "检查 Render 后端是否在线，以及 QQ 邮箱 IMAP 是否可读取。")
                    Spacer()
                    Button {
                        Task { await state.refreshBackendConnection() }
                    } label: {
                        Image(systemName: "arrow.clockwise")
                            .font(.headline)
                    }
                }

                VStack(alignment: .leading, spacing: 8) {
                    connectionRow("后端服务", state.backendHealth?.ok == true ? "正常" : "未连接", ok: state.backendHealth?.ok == true)
                    connectionRow("邮件模式", state.backendHealth?.provider ?? "未读取", ok: state.backendHealth?.provider == "imap")
                    connectionRow("QQ IMAP", state.imapStatus?.ok == true ? "正常" : (state.imapStatus?.error ?? "未检查"), ok: state.imapStatus?.ok == true)
                    if let imap = state.imapStatus, imap.ok {
                        infoRow("邮箱", imap.account ?? "未返回")
                        infoRow("IMAP", imap.host ?? "未返回")
                        infoRow("未读", "\(imap.unseen ?? 0) / 总邮件 \(imap.messages ?? 0)")
                    }
                    Text(state.connectionStatus)
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
                .textSelection(.enabled)
            }
        }
    }

    private func connectionRow(_ title: String, _ value: String, ok: Bool) -> some View {
        HStack(alignment: .top, spacing: 8) {
            Image(systemName: ok ? "checkmark.circle.fill" : "exclamationmark.triangle.fill")
                .foregroundStyle(ok ? .green : .orange)
            infoRow(title, value)
        }
        .font(.footnote)
    }

    private func infoRow(_ title: String, _ value: String) -> some View {
        HStack(alignment: .top, spacing: 8) {
            Text(title)
                .foregroundStyle(.secondary)
                .frame(width: 72, alignment: .leading)
            Text(value)
                .frame(maxWidth: .infinity, alignment: .leading)
        }
        .font(.footnote)
    }

    private var loginCard: some View {
        GlassCard {
            VStack(alignment: .leading, spacing: 14) {
                SectionTitle(title: "QQ IMAP 状态", subtitle: "QQ IMAP 模式不需要 Microsoft 登录；在 Render 环境变量配置 QQ 邮箱后检查状态。")
                Button {
                    Task { await state.refreshAll() }
                } label: {
                    Label("检查 IMAP 状态", systemImage: "arrow.clockwise")
                }
                .buttonStyle(PrimaryButtonStyle())
                .disabled(state.backendValidationMessage != nil)
                .opacity(state.backendValidationMessage == nil ? 1 : 0.45)
            }
        }
    }

    private var controlCard: some View {
        GlassCard {
            VStack(alignment: .leading, spacing: 14) {
                SectionTitle(title: "测试 AI 总结", subtitle: "仅测试最新 3 封邮件，不会处理全部历史邮件。")
                Button {
                    Task { await state.runTestSummary() }
                } label: {
                    Label("测试总结当前邮件", systemImage: "sparkles")
                }
                .buttonStyle(PrimaryButtonStyle())
                .disabled(state.imapStatus?.ok != true || state.isLoading)
                .opacity((state.imapStatus?.ok == true && !state.isLoading) ? 1 : 0.45)

                Text("仅测试最新 3 封邮件，不会处理全部历史邮件。")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
                    .textSelection(.enabled)

                MarkdownSummaryText(text: state.testSummaryStatus)
                    .font(.footnote)
                    .foregroundStyle(.secondary)
                    .textSelection(.enabled)

                Divider().opacity(0.25)

                Button {
                    Task { await state.runScheduledSummaryNow() }
                } label: {
                    Label("立即总结", systemImage: "tray.full")
                }
                .buttonStyle(PrimaryButtonStyle())
                .disabled(state.imapStatus?.ok != true || state.isLoading)
                .opacity((state.imapStatus?.ok == true && !state.isLoading) ? 1 : 0.45)

                Text("按当前频率执行：\(state.settings.frequency.scheduleDescription)")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
                    .textSelection(.enabled)

                Divider().opacity(0.25)

                Button {
                    state.sendTestNotification()
                } label: {
                    Label("测试通知", systemImage: "bell.badge.fill")
                }
                .buttonStyle(PrimaryButtonStyle())

                Text(state.notificationStatus)
                    .font(.footnote)
                    .foregroundStyle(.secondary)
                    .textSelection(.enabled)
            }
        }
    }

    private var historyList: some View {
        VStack(alignment: .leading, spacing: 12) {
            SectionTitle(title: "历史总结", subtitle: state.historySummaries.isEmpty ? "暂无总结。文字保留 60 天，PDF 保留 15 天。" : "按日期倒序分组；PDF 保留 15 天，文字保留 60 天。")
            ForEach(state.historyGroups) { group in
                VStack(alignment: .leading, spacing: 10) {
                    Text(group.dateTitle)
                        .font(.headline)
                        .foregroundStyle(.secondary)
                        .padding(.horizontal, 4)
                    ForEach(group.records) { record in
                        NavigationLink {
                            SummaryDetailView(recordId: record.id)
                        } label: {
                            HistorySummaryCard(record: record)
                                .environmentObject(state)
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
        }
    }

    private func errorCard(_ message: String) -> some View {
        GlassCard {
            VStack(alignment: .leading, spacing: 8) {
                Label("错误", systemImage: "exclamationmark.triangle.fill")
                    .font(.headline)
                Text(message)
                    .font(.footnote)
                    .textSelection(.enabled)
            }
            .foregroundStyle(.red.opacity(0.9))
        }
    }
}

private struct HistorySummaryCard: View {
    @EnvironmentObject private var state: AppState
    let record: LocalSummaryRecord

    var body: some View {
        GlassCard {
            VStack(alignment: .leading, spacing: 12) {
                HStack(alignment: .top) {
                    VStack(alignment: .leading, spacing: 4) {
                        Text(record.title)
                            .font(.headline)
                        Text(record.timeTitle)
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    Spacer()
                    CapsuleTag(text: state.hasPDF(for: record) ? "有 PDF" : "无 PDF", systemImage: state.hasPDF(for: record) ? "doc.richtext" : "doc.badge.plus")
                }
                VStack(alignment: .leading, spacing: 6) {
                    Text("时间范围：\(record.timeRangeDisplay)")
                        .lineLimit(2)
                    HStack(spacing: 8) {
                        CapsuleTag(text: "处理 \(record.processedCount)", systemImage: "envelope")
                        CapsuleTag(text: "重要 \(record.importantCount)", systemImage: "exclamationmark.circle")
                        CapsuleTag(text: "低价值 \(record.spamCount)", systemImage: "trash")
                    }
                }
                .font(.footnote)
                .foregroundStyle(.secondary)
            }
        }
    }
}

private struct SummaryDetailView: View {
    @EnvironmentObject private var state: AppState
    let recordId: String
    @State private var previewItem: PDFPreviewItem?

    private var record: LocalSummaryRecord? {
        state.historySummaries.first { $0.id == recordId }
    }

    var body: some View {
        ZStack {
            LiquidBackground()
            ScrollView {
                if let record {
                    VStack(alignment: .leading, spacing: 18) {
                        GlassCard {
                            VStack(alignment: .leading, spacing: 12) {
                                Text(record.title)
                                    .font(.title2.bold())
                                Text("总结时间：\(record.createdAtDisplay)")
                                    .font(.footnote)
                                    .foregroundStyle(.secondary)
                                Text("时间范围：\(record.timeRangeDisplay)")
                                    .font(.footnote)
                                    .foregroundStyle(.secondary)
                                HStack(spacing: 8) {
                                    CapsuleTag(text: "处理 \(record.processedCount)", systemImage: "envelope")
                                    CapsuleTag(text: "重要 \(record.importantCount)", systemImage: "exclamationmark.circle")
                                    CapsuleTag(text: "低价值 \(record.spamCount)", systemImage: "trash")
                                }
                                if let backendPDFInfo = record.backendPDFInfo {
                                    Text("后端返回 PDF 信息：\(backendPDFInfo)")
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                        .textSelection(.enabled)
                                }
                            }
                        }

                        GlassCard {
                            VStack(alignment: .leading, spacing: 12) {
                                SectionTitle(title: "完整文字总结", subtitle: "保留段落、编号和基础 Markdown。")
                                MarkdownSummaryText(text: record.content)
                                    .font(.body)
                                    .textSelection(.enabled)
                            }
                        }

                        GlassCard {
                            VStack(spacing: 12) {
                                if let url = state.pdfURL(for: record) {
                                    Button {
                                        previewItem = PDFPreviewItem(url: url)
                                    } label: {
                                        Label("打开 PDF", systemImage: "doc.richtext")
                                    }
                                    .buttonStyle(PrimaryButtonStyle())

                                    ShareLink(item: url) {
                                        Label("分享 PDF", systemImage: "square.and.arrow.up")
                                            .font(.headline)
                                            .frame(maxWidth: .infinity)
                                            .padding(.vertical, 14)
                                            .background(.white.opacity(0.25), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                                            .overlay {
                                                RoundedRectangle(cornerRadius: 18, style: .continuous)
                                                    .strokeBorder(.white.opacity(0.18), lineWidth: 1)
                                            }
                                    }
                                } else {
                                    Text("PDF 已删除或不存在，但文字总结仍保留。")
                                        .font(.footnote)
                                        .foregroundStyle(.secondary)
                                    Button {
                                        state.regeneratePDF(for: record.id)
                                    } label: {
                                        Label("重新生成 PDF", systemImage: "doc.badge.plus")
                                    }
                                    .buttonStyle(PrimaryButtonStyle())
                                }
                            }
                        }
                    }
                    .padding()
                    .frame(maxWidth: 860)
                    .frame(maxWidth: .infinity)
                } else {
                    Text("历史总结不存在或已被清理。")
                        .foregroundStyle(.secondary)
                        .padding()
                }
            }
        }
        .navigationTitle("总结详情")
        .sheet(item: $previewItem) { item in
            PDFPreviewController(url: item.url)
        }
    }
}

private struct PDFPreviewItem: Identifiable {
    let id = UUID()
    let url: URL
}

private struct PDFPreviewController: UIViewControllerRepresentable {
    let url: URL

    func makeUIViewController(context: Context) -> QLPreviewController {
        let controller = QLPreviewController()
        controller.dataSource = context.coordinator
        return controller
    }

    func updateUIViewController(_ controller: QLPreviewController, context: Context) {}

    func makeCoordinator() -> Coordinator {
        Coordinator(url: url)
    }

    final class Coordinator: NSObject, QLPreviewControllerDataSource {
        let url: URL

        init(url: URL) {
            self.url = url
        }

        func numberOfPreviewItems(in controller: QLPreviewController) -> Int { 1 }

        func previewController(_ controller: QLPreviewController, previewItemAt index: Int) -> QLPreviewItem {
            url as NSURL
        }
    }
}
