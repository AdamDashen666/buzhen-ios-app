import Photos
import PhotosUI
import SwiftUI
import UniformTypeIdentifiers

private enum AppTab: Hashable { case dashboard, newJob, jobs, settings }

struct ContentView: View {
    @ObservedObject var pairing: PairingSettings
    @State private var capabilities: CapabilityResponse?
    @State private var jobs: [Job] = []
    @State private var selectedTab: AppTab = .dashboard
    @State private var reusableSource: RemoteVideoSource?
    @State private var error: String?

    var body: some View {
        TabView(selection: $selectedTab) {
            NavigationStack { dashboard }.tabItem { Label("Dashboard", systemImage: "gauge.with.dots.needle.50percent") }.tag(AppTab.dashboard)
            NavigationStack { NewJobView(settings: pairing.agentSettings, capabilities: capabilities, reusableSource: $reusableSource, submitted: refresh) }.tabItem { Label("New Job", systemImage: "plus.circle.fill") }.tag(AppTab.newJob)
            NavigationStack { jobsView }.tabItem { Label("Jobs", systemImage: "list.bullet.rectangle") }.tag(AppTab.jobs)
            NavigationStack { SettingsView(pairing: pairing, refresh: refresh) }.tabItem { Label("Settings", systemImage: "gearshape") }.tag(AppTab.settings)
        }
        .task { await refresh() }
        .alert("Connection problem", isPresented: Binding(get: { error != nil }, set: { if !$0 { error = nil } })) { Button("OK", role: .cancel) {} } message: { Text(error ?? "") }
    }

    private var dashboard: some View {
        List {
            Section("Your PC") {
                LabeledContent("Address", value: pairing.host.isEmpty ? "Not paired" : pairing.host)
                LabeledContent("Topaz", value: capabilities?.agentVersion ?? "Connect to load")
            }
            Section("Active Jobs") {
                if jobs.isEmpty { ContentUnavailableView("No jobs yet", systemImage: "film", description: Text("Choose New Job to upload a video.")) }
                else { ForEach(jobs.prefix(3)) { JobRow(job: $0, settings: pairing.agentSettings, cancel: cancel, reuse: reuse) } }
            }
        }
        .navigationTitle("Topaz Remote")
        .toolbar { Button("Refresh", systemImage: "arrow.clockwise") { Task { await refresh() } }.accessibilityLabel("Refresh PC status") }
    }

    private var jobsView: some View {
        List(jobs) { JobRow(job: $0, settings: pairing.agentSettings, cancel: cancel, reuse: reuse) }
            .navigationTitle("Jobs")
    }

    @MainActor private func refresh() async {
        let settings = pairing.agentSettings
        guard !settings.host.isEmpty, !settings.token.isEmpty else { return }
        do {
            async let loadedCapabilities = AgentClient(settings: settings).capabilities()
            async let loadedJobs = AgentClient(settings: settings).jobs()
            capabilities = try await loadedCapabilities
            jobs = try await loadedJobs
        } catch { self.error = error.localizedDescription }
    }

    @MainActor private func cancel(_ job: Job) async {
        do { _ = try await AgentClient(settings: pairing.agentSettings).cancelJob(id: job.id); await refresh() }
        catch { self.error = error.localizedDescription }
    }

    private func reuse(_ job: Job) {
        guard let filename = job.outputFilename else { return }
        reusableSource = RemoteVideoSource(filename: filename)
        selectedTab = .newJob
    }
}

struct JobRow: View {
    let job: Job
    let settings: AgentSettings
    let cancel: (Job) async -> Void
    let reuse: (Job) -> Void
    @ObservedObject private var downloads = DownloadCoordinator.shared
    @State private var downloadError: String?

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(job.sourceFilename ?? "Video job").font(.headline)
            Text(job.status.replacingOccurrences(of: "_", with: " ").capitalized).foregroundStyle(.secondary)
            if let progress = job.progress?.overallProgress { ProgressView(value: progress) }
            if let failureReason = job.failureReason, job.status == "failed" { Text(failureReason).font(.footnote).foregroundStyle(.red).lineLimit(3) }
            if ["created", "processing"].contains(job.status) { Button("Cancel", role: .destructive) { Task { await cancel(job) } } }
            if job.status == "completed" {
                if let delivery = job.delivery {
                    if delivery.state == "sent" { Label("Sent to File Transfer Assistant", systemImage: "checkmark.circle.fill").foregroundStyle(.green) }
                    else if delivery.state == "sending" || delivery.state == "pending" { ProgressView("Sending to File Transfer Assistant...") }
                    else {
                        Text(delivery.error ?? "WeChat send failed.").font(.footnote).foregroundStyle(.red)
                        Button("Retry WeChat Send") { Task { await retryWeChat(job) } }
                    }
                }
                if job.outputFilename != nil {
                    Button("Use as Source for Next Step", systemImage: "arrow.triangle.2.circlepath") { reuse(job) }
                }
                downloadControls
            }
        }
        .accessibilityElement(children: .combine)
        .alert("Unable to save video", isPresented: Binding(get: { downloadError != nil }, set: { if !$0 { downloadError = nil } })) { Button("OK", role: .cancel) {} } message: { Text(downloadError ?? "") }
    }

    @MainActor private func retryWeChat(_ job: Job) async {
        do { _ = try await AgentClient(settings: settings).retryWeChatDelivery(jobID: job.id) }
        catch { downloadError = error.localizedDescription }
    }

    @ViewBuilder private var downloadControls: some View {
        switch downloads.downloadState(for: job.id) {
        case .idle:
            Button("Save Video") { startDownload() }
        case .downloading(let progress):
            Button(downloadButtonTitle(for: progress)) {}.disabled(true)
            if let progress {
                ProgressView(value: progress) { Text("Downloading \(Int((progress * 100).rounded()))%") }
                    .accessibilityLabel("Video download progress")
                    .accessibilityValue("\(Int((progress * 100).rounded())) percent")
            } else {
                ProgressView("Downloading video...").accessibilityLabel("Downloading video")
            }
            Text("Continues when Topaz Remote is in the background.")
                .font(.footnote)
                .foregroundStyle(.secondary)
        case .completed(let savedURL):
            Label("Downloaded on this iPad", systemImage: "checkmark.circle.fill").foregroundStyle(.green)
            ShareLink(item: savedURL) { Label("Share", systemImage: "square.and.arrow.up") }
            Button("Save to Photos") { Task { await saveToPhotos(savedURL) } }
        case .failed(let message):
            Button("Retry Download") { startDownload() }
            Text(message).font(.footnote).foregroundStyle(.red).lineLimit(2)
        }
    }

    private func startDownload() {
        do { try downloads.startDownload(jobID: job.id, client: AgentClient(settings: settings)) }
        catch { downloadError = error.localizedDescription }
    }

    private func downloadButtonTitle(for progress: Double?) -> String {
        guard let progress else { return "Downloading..." }
        return "Downloading \(Int((progress * 100).rounded()))%"
    }

    @MainActor private func saveToPhotos(_ url: URL) async {
        do { try await PHPhotoLibrary.shared().performChanges { PHAssetChangeRequest.creationRequestForAssetFromVideo(atFileURL: url) } }
        catch { downloadError = error.localizedDescription }
    }
}

struct NewJobView: View {
    let settings: AgentSettings
    let capabilities: CapabilityResponse?
    @Binding var reusableSource: RemoteVideoSource?
    let submitted: () async -> Void
    @State private var importerPresented = false
    @State private var photoItem: PhotosPickerItem?
    @State private var enhancementEnabled = true
    @State private var selectedModel = ""
    @State private var denoiseEnabled = false
    @State private var selectedDenoiseModel = ""
    @State private var interpolationEnabled = false
    @State private var selectedInterpolationModel = ""
    @State private var outputFPS = 60
    @State private var scale = 1
    @State private var parameterValues: [String: ParameterValue] = [:]
    @State private var selectedURL: URL?
    @State private var sourceRoute: SourceRoute = .tailscale
    @State private var isReadingWeChat = false
    @State private var videoInfo: VideoInfo?
    @State private var uploadProgress = 0.0
    @State private var isSubmitting = false
    @State private var error: String?

    var body: some View {
        Form {
            sourceSection
            if let videoInfo { mediaInformationSection(videoInfo) }
            processingSection
            if let estimate = outputEstimate { outputInformationSection(estimate) }
            if isSubmitting { Section("Upload") { ProgressView(value: uploadProgress) { Text(reusableSource == nil ? "Uploading" : "Queueing on PC") } } }
            Section {
                Button(queueButtonTitle) { Task { await uploadAndQueue() } }
                    .disabled(!canSubmit)
            }
        }
        .navigationTitle("New Job")
        .fileImporter(isPresented: $importerPresented, allowedContentTypes: [.movie]) { result in
            switch result {
            case .success(let url): Task { await selectLocalVideo(url) }
            case .failure(let error): self.error = error.localizedDescription
            }
        }
        .onChange(of: photoItem) { _, item in
            guard let item else { return }
            Task { await importPhotoVideo(item) }
        }
        .onChange(of: reusableSource) { _, source in
            guard let source else { return }
            selectedURL = nil
            sourceRoute = source.deliveryRoute ?? .tailscale
            videoInfo = source.videoInfo
        }
        .onChange(of: enhancementEnabled) { _, enabled in if enabled { denoiseEnabled = false } }
        .onChange(of: denoiseEnabled) { _, enabled in if enabled { enhancementEnabled = false } }
        .onChange(of: capabilities?.enhancementModels) { _, models in
            if selectedModel.isEmpty { selectedModel = models?.first(where: { $0.available != false })?.id ?? "" }
        }
        .onChange(of: capabilities?.denoiseModels) { _, models in
            if selectedDenoiseModel.isEmpty { selectedDenoiseModel = models?.first(where: { $0.available != false })?.id ?? "" }
        }
        .onChange(of: capabilities?.interpolationModels) { _, models in
            if selectedInterpolationModel.isEmpty { selectedInterpolationModel = models?.first(where: { $0.available != false })?.id ?? "" }
        }
        .alert("Unable to queue job", isPresented: Binding(get: { error != nil }, set: { if !$0 { error = nil } })) { Button("OK", role: .cancel) {} } message: { Text(error ?? "") }
    }

    @ViewBuilder private var sourceSection: some View {
        Section("Source") {
            Picker("Transfer", selection: $sourceRoute) { Text("Tailscale").tag(SourceRoute.tailscale); Text("WeChat").tag(SourceRoute.wechat) }
                .pickerStyle(.segmented)
                .disabled(reusableSource?.deliveryRoute != nil)
            if let reusableSource {
                Label(reusableSource.filename, systemImage: "desktopcomputer")
                    .lineLimit(1)
                Text("Already on your PC. This next operation will not upload or download the video.")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
                Button("Choose a Video from Files Instead") { importerPresented = true }
            } else if sourceRoute == .tailscale {
                Button(selectedURL == nil ? "Choose Video from Files" : "Change Selected Video") { importerPresented = true }
                PhotosPicker(selection: $photoItem, matching: .videos) { Text("Choose Video from Photos") }
                if let selectedURL { Text(selectedURL.lastPathComponent).lineLimit(1).foregroundStyle(.secondary) }
                Text("Uploads stream in chunks and do not load the full video into memory.").font(.footnote).foregroundStyle(.secondary)
            } else {
                Button(isReadingWeChat ? "Reading latest WeChat video..." : "Read latest WeChat video") { Task { await readWeChatVideo() } }.disabled(isReadingWeChat)
                Text("The PC reads File Transfer Assistant only after you tap this button. Existing automatic downloads are reused; otherwise WeChat downloads the latest video.").font(.footnote).foregroundStyle(.secondary)
            }
        }
    }

    @ViewBuilder private func mediaInformationSection(_ info: VideoInfo) -> some View {
        Section("Video Information") {
            LabeledContent("Format", value: info.fileExtension.isEmpty ? "Video" : info.fileExtension)
            LabeledContent("Codec", value: info.codec)
            LabeledContent("Resolution", value: info.resolutionText)
            LabeledContent("Frame Rate", value: info.frameRateText)
            LabeledContent("Duration", value: info.durationText)
            LabeledContent("File Size", value: info.fileSizeText)
        }
    }

    @ViewBuilder private var processingSection: some View {
        Section("Processing") {
            Toggle("Enhancement", isOn: $enhancementEnabled)
            if enhancementEnabled { enhancementControls }
            Toggle("Denoise", isOn: $denoiseEnabled)
            if denoiseEnabled { denoiseControls }
            Toggle("Frame Interpolation", isOn: $interpolationEnabled)
            if interpolationEnabled { interpolationControls }
        }
    }

    @ViewBuilder private var enhancementControls: some View {
        if let capabilities {
            let models = capabilities.enhancementModels.filter { $0.available != false }
            if models.isEmpty { ContentUnavailableView("No verified enhancement model", systemImage: "exclamationmark.triangle", description: Text("Install a Topaz model locally, then refresh the Agent.")) }
            else {
                Picker("Model", selection: $selectedModel) { ForEach(models) { Text($0.displayName).tag($0.id) } }
                Stepper("Scale: \(scale)x", value: $scale, in: 1...4)
                if let model = models.first(where: { $0.id == selectedModel }) { DynamicParameterForm(parameters: model.parameters.filter { $0.id != "scale" }, values: $parameterValues) }
            }
        } else {
            ContentUnavailableView("Connect to your PC", systemImage: "wifi.exclamationmark", description: Text("Available models appear after pairing."))
        }
    }

    @ViewBuilder private var denoiseControls: some View {
        let models = capabilities?.denoiseModels.filter { $0.available != false } ?? []
        if models.isEmpty {
            ContentUnavailableView("Nyx denoise is unavailable", systemImage: "waveform.badge.exclamationmark", description: Text("Topaz Remote enables this only after the Nyx 3 model is verified on your PC."))
        } else {
            Picker("Denoise Model", selection: $selectedDenoiseModel) { ForEach(models) { Text("\($0.displayName) — High Quality").tag($0.id) } }
            Text("Uses Topaz Nyx 3 at its quality-focused default noise reduction strength.")
                .font(.footnote)
                .foregroundStyle(.secondary)
        }
    }

    @ViewBuilder private var interpolationControls: some View {
        if let capabilities {
            let models = capabilities.interpolationModels.filter { $0.available != false }
            if models.isEmpty { ContentUnavailableView("No verified interpolation model", systemImage: "exclamationmark.triangle", description: Text("Install a Topaz model locally, then refresh the Agent.")) }
            else {
                Picker("Interpolation Model", selection: $selectedInterpolationModel) { ForEach(models) { Text($0.displayName).tag($0.id) } }
                LabeledContent("Output FPS") {
                    TextField("FPS", value: $outputFPS, format: .number)
                        .keyboardType(.numberPad)
                        .multilineTextAlignment(.trailing)
                        .frame(width: 92)
                        .accessibilityLabel("Output frames per second")
                }
                Text("Enter \(fpsRange.lowerBound)–\(fpsRange.upperBound) FPS directly.")
                    .font(.footnote)
                    .foregroundStyle(outputFPSIsValid ? Color.secondary : Color.red)
            }
        } else {
            ContentUnavailableView("Connect to your PC", systemImage: "wifi.exclamationmark", description: Text("Available models appear after pairing."))
        }
    }

    @ViewBuilder private func outputInformationSection(_ estimate: OutputEstimate) -> some View {
        Section("Expected Output") {
            LabeledContent("Resolution", value: estimate.resolutionText)
            LabeledContent("Frame Rate", value: estimate.frameRateText)
            Text("This is a processing estimate; the final file format is Topaz Remote H.264 High, 4:2:0.")
                .font(.footnote)
                .foregroundStyle(.secondary)
        }
    }

    private var hasSource: Bool { selectedURL != nil || reusableSource != nil }
    private var hasProcessingStage: Bool {
        (enhancementEnabled && !selectedModel.isEmpty) ||
        (denoiseEnabled && !selectedDenoiseModel.isEmpty) ||
        (interpolationEnabled && !selectedInterpolationModel.isEmpty)
    }
    private var fpsRange: ClosedRange<Int> {
        let parameter = capabilities?.interpolationModels.first(where: { $0.id == selectedInterpolationModel })?.parameters.first(where: { $0.id == "fps" })
        return Int(parameter?.min ?? 1)...Int(parameter?.max ?? 480)
    }
    private var outputFPSIsValid: Bool { fpsRange.contains(outputFPS) }
    private var outputEstimate: OutputEstimate? {
        guard let videoInfo else { return nil }
        return OutputEstimate(source: videoInfo, scale: enhancementEnabled ? scale : 1, frameRate: interpolationEnabled ? outputFPS : Int(videoInfo.frameRate.rounded()))
    }
    private var canSubmit: Bool { hasSource && hasProcessingStage && (!interpolationEnabled || outputFPSIsValid) && !settings.host.isEmpty && !settings.token.isEmpty && !isSubmitting }
    private var queueButtonTitle: String {
        if isSubmitting { return reusableSource == nil ? "Submitting..." : "Queueing..." }
        return reusableSource == nil ? "Upload & Queue" : "Queue on PC"
    }

    @MainActor private func uploadAndQueue() async {
        guard hasSource else { return }
        isSubmitting = true
        uploadProgress = 0
        defer { isSubmitting = false }
        do {
            let client = AgentClient(settings: settings)
            let sourceFilename: String
            if let reusableSource {
                sourceFilename = reusableSource.filename
            } else if let selectedURL {
                sourceFilename = try await UploadCoordinator.upload(url: selectedURL, client: client) { value in self.uploadProgress = value }
            } else {
                return
            }
            var processing: [String: Any] = [:]
            if enhancementEnabled {
                var enhancement: [String: Any] = ["model": selectedModel, "scale": scale]
                for parameter in capabilities?.enhancementModels.first(where: { $0.id == selectedModel })?.parameters ?? [] {
                    if let value = parameterValues[parameter.id] { enhancement[parameter.id] = parameterJSON(parameter, value: value) }
                }
                processing["enhancement"] = enhancement
            }
            if denoiseEnabled, let model = capabilities?.denoiseModels.first(where: { $0.id == selectedDenoiseModel }) {
                var denoise: [String: Any] = ["model": model.id, "scale": 1]
                for parameter in model.parameters where parameter.id != "scale" {
                    if let value = parameter.default { denoise[parameter.id] = parameterJSON(parameter, value: value) }
                }
                processing["denoise"] = denoise
            }
            if interpolationEnabled { processing["interpolation"] = ["model": selectedInterpolationModel, "fps": Double(outputFPS)] }
            let deliveryRoute = reusableSource?.deliveryRoute ?? (selectedURL == nil ? sourceRoute : .tailscale)
            _ = try await client.createJob(sourceFilename: sourceFilename, settings: processing, deliveryRoute: deliveryRoute == .wechat ? "wechat" : nil)
            reusableSource = nil
            selectedURL = nil
            videoInfo = nil
            await submitted()
        } catch { self.error = error.localizedDescription }
    }

    @MainActor private func selectLocalVideo(_ url: URL) async {
        selectedURL = url
        reusableSource = nil
        sourceRoute = .tailscale
        do { videoInfo = try await VideoInspector.inspect(url: url) }
        catch { videoInfo = nil; self.error = "Could not read video information: \(error.localizedDescription)" }
    }

    @MainActor private func readWeChatVideo() async {
        isReadingWeChat = true
        defer { isReadingWeChat = false }
        do {
            let client = AgentClient(settings: settings)
            var ticket = try await client.startWeChatImport()
            while ticket.state == "downloading" {
                try await Task.sleep(for: .seconds(1))
                ticket = try await client.weChatImport(id: ticket.id)
            }
            guard ticket.state == "ready", let filename = ticket.sourceFilename, let info = ticket.videoInfo else { throw WeChatImportError(message: ticket.failureDescription) }
            reusableSource = RemoteVideoSource(filename: filename, deliveryRoute: .wechat, videoInfo: info)
        } catch { self.error = error.localizedDescription }
    }

    @MainActor private func importPhotoVideo(_ item: PhotosPickerItem) async {
        do {
            guard let video = try await item.loadTransferable(type: VideoTransferable.self) else { return }
            await selectLocalVideo(video.url)
        } catch { self.error = error.localizedDescription }
    }
}

private struct WeChatImportError: LocalizedError {
    let message: String
    var errorDescription: String? { message }
}

struct DynamicParameterForm: View {
    let parameters: [CapabilityParameter]
    @Binding var values: [String: ParameterValue]

    var body: some View {
        ForEach(parameters) { parameter in
            switch parameter.type {
            case "boolean":
                Toggle(parameter.displayName ?? parameter.id, isOn: Binding(get: { boolValue(parameter) }, set: { values[parameter.id] = .bool($0) }))
            case "enum":
                Picker(parameter.displayName ?? parameter.id, selection: Binding(get: { stringValue(parameter) }, set: { values[parameter.id] = .string($0) })) {
                    ForEach(parameter.options ?? [], id: \.value) { Text($0.label).tag($0.value) }
                }
            case "number", "integer":
                Stepper(value: Binding(get: { numberValue(parameter) }, set: { values[parameter.id] = .number($0) }), in: (parameter.min ?? 0)...(parameter.max ?? 100), step: parameter.step ?? 1) { Text("\(parameter.displayName ?? parameter.id): \(numberValue(parameter), specifier: "%.2f")") }
            default: EmptyView()
            }
        }
    }

    private func boolValue(_ parameter: CapabilityParameter) -> Bool { if case .bool(let value) = values[parameter.id] ?? parameter.default { return value }; return false }
    private func stringValue(_ parameter: CapabilityParameter) -> String { if case .string(let value) = values[parameter.id] ?? parameter.default { return value }; return parameter.options?.first?.value ?? "" }
    private func numberValue(_ parameter: CapabilityParameter) -> Double { if case .number(let value) = values[parameter.id] ?? parameter.default { return value }; return parameter.min ?? 0 }
}

struct SettingsView: View {
    @ObservedObject var pairing: PairingSettings
    let refresh: () async -> Void

    var body: some View {
        Form {
            Section("Computer") {
                TextField("Tailscale address", text: $pairing.host).textInputAutocapitalization(.never).autocorrectionDisabled().keyboardType(.URL)
                Stepper("Port: \(pairing.port)", value: $pairing.port, in: 1024...65535)
                SecureField("Pairing token", text: $pairing.token)
                Button("Test Connection") { Task { await refresh() } }.disabled(pairing.host.isEmpty || pairing.token.isEmpty)
            }
            Section("Privacy") { Text("Topaz Remote never changes Tailscale, VPN, proxy, DNS, routing, or firewall settings.").font(.footnote).foregroundStyle(.secondary) }
        }.navigationTitle("Settings")
    }
}
