# Outlook AI Summary v16 - Cached Connection & Nonblocking Startup

## Changes

- App startup no longer blocks on `/health` + `/imap/test`.
- Last successful backend + QQ IMAP status is cached locally.
- Re-entering the app immediately shows the last connected state, then refreshes in the background.
- If the background check times out but the last IMAP status was OK, the app keeps the connected state instead of disabling summary controls.
- Manual test summary and immediate scheduled summary no longer perform a separate preflight IMAP check before calling `/summarize/run`.
- After any successful summary run, the app marks the connection as valid and stores it for the next launch.
- Settings page clarifies that auto summary is executed by the Render backend, not by waiting for the app to re-check connection every time.

## Kept unchanged

- No `/config` request.
- No frontend AI model/base URL/API key fields.
- No `aiModel`, `aiBaseUrl`, or `aiApiKey` sent to `/settings`.
- QQ IMAP manual check still uses `/imap/test` when the user taps refresh/check.
- “测试 AI 模型” still uses `POST /ai/test`.

## Note

Automatic summary depends on the backend process being awake. If the Render instance sleeps, use Render cron / external uptime monitor to wake it regularly.
