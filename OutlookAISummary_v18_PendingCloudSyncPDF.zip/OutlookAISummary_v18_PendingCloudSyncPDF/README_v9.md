# v9 Test Summary Limit + Scheduled Window

## iOS frontend

- “测试总结当前邮件” now calls `POST /summarize/run` with:
  - `mode: "test"`
  - `limit: 3`
- Test summary UI clearly says: “仅测试最近 3 封未读邮件，不会处理全部历史邮件。”
- Test success displays the tested message count, the AI summary content, and a partial-test notice when `hasMore: true`.
- Timeout text is user-facing: “邮件较多或 AI 响应较慢，请稍后重试。测试模式只会处理最近 3 封。”
- Added/kept “立即总结” to call `POST /summarize/run` with scheduled mode:
  - every 6 hours: `windowHours: 6`, `maxMessages: 30`
  - daily: `windowHours: 24`, `maxMessages: 30`
  - monthly: `windowHours: 720`, `maxMessages: 50`
- Schedule explanations now match the selected frequency.
- `POST /ai/test` remains the AI model test endpoint.
- No `/config` request is used.
- No frontend AI key/base/model fields are restored.

## Backend compatibility

- `/summarize/run` now respects `mode`, `limit`, `windowHours`, and `maxMessages`.
- Test mode only fetches/summarizes up to the recent limited messages instead of parsing all unread mail.
- Scheduled mode uses a bounded time window and max message count.
- Scheduler also uses the same frequency-based windows.
