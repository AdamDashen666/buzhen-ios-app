import Foundation

struct AppSettings: Codable, Equatable {
    var enabled: Bool = true
    var frequency: SummaryFrequency = .daily
    var language: String = "zh-CN"
    var includeJunkUnread: Bool = true
    var autoDeleteEnabled: Bool = true
    var deleteAfterDays: Int = 30
    var permanentDeleteAfterDays: Int = 7
}

enum SummaryFrequency: String, Codable, CaseIterable, Identifiable {
    case daily
    case sixHours
    case monthly

    var id: String { rawValue }

    var title: String {
        switch self {
        case .daily: return "每天"
        case .sixHours: return "每 6 小时"
        case .monthly: return "每月"
        }
    }

    var windowHours: Int {
        switch self {
        case .sixHours: return 6
        case .daily: return 24
        case .monthly: return 720
        }
    }

    var scheduleDescription: String {
        switch self {
        case .sixHours: return "每次只总结最近 6 小时内的邮件。"
        case .daily: return "每次只总结最近 24 小时内的邮件。"
        case .monthly: return "每次只总结最近 30 天内的邮件。"
        }
    }
}

struct AuthStatusResponse: Codable {
    let linked: Bool
    let user: LinkedUser?
}

struct LinkedUser: Codable {
    let displayName: String?
    let email: String?
    let settings: AppSettings?
    let lastRunAt: String?
}

struct SummaryItem: Codable, Identifiable, Equatable {
    let id: String
    let title: String
    let content: String
    let unreadCount: Int
    let junkUnreadCount: Int
    let createdAt: String
}

struct SummariesResponse: Codable {
    let summaries: [SummaryItem]
}

struct DeviceRegisterResponse: Codable {
    let deviceId: String
    let deviceToken: String?
    let platform: String?
    let updatedAt: String?
}

struct RunSummaryResponse: Decodable {
    let ok: Bool
    let mode: String?
    let processed: Int?
    let processedCount: Int?
    let summary: SummaryItem?
    let summaryText: String?
    let message: String?
    let error: String?
    let hasMore: Bool?
    let startTime: String?
    let endTime: String?
    let importantCount: Int?
    let spamCount: Int?
    let pdfFileName: String?
    let pdfURL: String?
    let pdfPath: String?
    let id: String?
    let summaryId: String?
    let title: String?
    let createdAt: String?
    let structured: StructuredSummary?

    enum CodingKeys: String, CodingKey {
        case ok
        case mode
        case processed
        case processedCount
        case processed_count
        case summary
        case message
        case error
        case hasMore
        case startTime
        case endTime
        case importantCount
        case spamCount
        case pdfFileName
        case pdfURL
        case pdfUrl
        case pdfPath
        case id
        case summaryId
        case title
        case createdAt
        case structured
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.ok = (try? container.decode(Bool.self, forKey: .ok)) ?? false
        self.mode = try? container.decode(String.self, forKey: .mode)
        self.processed = try? container.decode(Int.self, forKey: .processed)
        self.processedCount = (try? container.decode(Int.self, forKey: .processedCount))
            ?? (try? container.decode(Int.self, forKey: .processed_count))
        self.message = try? container.decode(String.self, forKey: .message)
        self.error = try? container.decode(String.self, forKey: .error)
        self.hasMore = try? container.decode(Bool.self, forKey: .hasMore)
        self.startTime = try? container.decode(String.self, forKey: .startTime)
        self.endTime = try? container.decode(String.self, forKey: .endTime)
        self.importantCount = try? container.decode(Int.self, forKey: .importantCount)
        self.spamCount = try? container.decode(Int.self, forKey: .spamCount)
        self.pdfFileName = try? container.decode(String.self, forKey: .pdfFileName)
        self.pdfURL = (try? container.decode(String.self, forKey: .pdfURL))
            ?? (try? container.decode(String.self, forKey: .pdfUrl))
        self.pdfPath = try? container.decode(String.self, forKey: .pdfPath)
        self.id = try? container.decode(String.self, forKey: .id)
        self.summaryId = try? container.decode(String.self, forKey: .summaryId)
        self.title = try? container.decode(String.self, forKey: .title)
        self.createdAt = try? container.decode(String.self, forKey: .createdAt)
        self.structured = try? container.decode(StructuredSummary.self, forKey: .structured)

        if let item = try? container.decode(SummaryItem.self, forKey: .summary) {
            self.summary = item
            self.summaryText = item.content
        } else if let text = try? container.decode(String.self, forKey: .summary) {
            self.summary = nil
            self.summaryText = text
        } else if let object = try? container.decode(SummaryTextObject.self, forKey: .summary) {
            self.summary = nil
            self.summaryText = object.content ?? object.text ?? object.result ?? object.message
        } else {
            self.summary = nil
            self.summaryText = nil
        }
    }

    var effectiveProcessedCount: Int? {
        processed ?? processedCount ?? summary?.unreadCount
    }

    var displaySummaryText: String? {
        summaryText ?? summary?.content ?? message
    }

    var backendPDFInfo: String? {
        pdfFileName ?? pdfURL ?? pdfPath
    }

    var summaryIdentifier: String? {
        id ?? summaryId ?? summary?.id
    }

    var effectiveTitle: String? {
        title ?? summary?.title
    }

    var effectiveCreatedAt: String? {
        createdAt ?? summary?.createdAt
    }
}

private struct SummaryTextObject: Decodable {
    let content: String?
    let text: String?
    let result: String?
    let message: String?
}

struct StructuredSummary: Codable, Equatable {
    var title: String?
    var timeRange: String?
    var startTime: String?
    var endTime: String?
    var processedCount: Int?
    var importantCount: Int?
    var spamCount: Int?
    var reminders: [String]?
    var importantEmails: [StructuredEmailItem]?
    var normalSummary: [String]?
    var spamSummary: [String]?
    var risks: [String]?
    var nextSteps: [String]?
}

struct StructuredEmailItem: Codable, Equatable {
    var sender: String?
    var subject: String?
    var time: String?
    var summary: String?
    var action: String?
    var deadline: String?
    var priority: String?
}

struct PendingSummariesResponse: Decodable {
    let ok: Bool?
    let summaries: [PendingSummaryRecord]
    let message: String?
    let error: String?
}

struct MarkSummariesSyncedResponse: Decodable {
    let ok: Bool
    let synced: Int?
    let message: String?
    let error: String?
}

struct PendingSummaryRecord: Decodable, Identifiable, Equatable {
    let id: String
    let title: String?
    let summary: String?
    let content: String?
    let message: String?
    let createdAt: String?
    let mode: String?
    let processed: Int?
    let processedCount: Int?
    let startTime: String?
    let endTime: String?
    let importantCount: Int?
    let spamCount: Int?
    let hasMore: Bool?
    let structured: StructuredSummary?
    let pdfFileName: String?
    let pdfURL: String?
    let pdfPath: String?

    enum CodingKeys: String, CodingKey {
        case id, title, summary, content, message, createdAt, mode, processed, processedCount
        case startTime, endTime, importantCount, spamCount, hasMore, structured
        case pdfFileName, pdfURL, pdfUrl, pdfPath
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.id = (try? container.decode(String.self, forKey: .id)) ?? UUID().uuidString
        self.title = try? container.decode(String.self, forKey: .title)
        if let text = try? container.decode(String.self, forKey: .summary) {
            self.summary = text
        } else if let object = try? container.decode(SummaryTextObject.self, forKey: .summary) {
            self.summary = object.content ?? object.text ?? object.result ?? object.message
        } else {
            self.summary = nil
        }
        self.content = try? container.decode(String.self, forKey: .content)
        self.message = try? container.decode(String.self, forKey: .message)
        self.createdAt = try? container.decode(String.self, forKey: .createdAt)
        self.mode = try? container.decode(String.self, forKey: .mode)
        self.processed = try? container.decode(Int.self, forKey: .processed)
        self.processedCount = try? container.decode(Int.self, forKey: .processedCount)
        self.startTime = try? container.decode(String.self, forKey: .startTime)
        self.endTime = try? container.decode(String.self, forKey: .endTime)
        self.importantCount = try? container.decode(Int.self, forKey: .importantCount)
        self.spamCount = try? container.decode(Int.self, forKey: .spamCount)
        self.hasMore = try? container.decode(Bool.self, forKey: .hasMore)
        self.structured = try? container.decode(StructuredSummary.self, forKey: .structured)
        self.pdfFileName = try? container.decode(String.self, forKey: .pdfFileName)
        self.pdfURL = (try? container.decode(String.self, forKey: .pdfURL)) ?? (try? container.decode(String.self, forKey: .pdfUrl))
        self.pdfPath = try? container.decode(String.self, forKey: .pdfPath)
    }

    var summaryText: String {
        (summary ?? content ?? message ?? "后端未返回总结内容。").trimmingCharacters(in: .whitespacesAndNewlines)
    }

    var effectiveProcessedCount: Int {
        processed ?? processedCount ?? structured?.processedCount ?? 0
    }

    var backendPDFInfo: String? {
        pdfFileName ?? pdfURL ?? pdfPath
    }
}

struct LocalSummaryRecord: Codable, Identifiable, Equatable {
    let id: String
    var title: String
    var content: String
    var createdAt: Date
    var startTime: String?
    var endTime: String?
    var processedCount: Int
    var importantCount: Int
    var spamCount: Int
    var structured: StructuredSummary?
    var pdfFileName: String?
    var backendPDFInfo: String?

    var dateTitle: String {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter.string(from: createdAt)
    }

    var timeTitle: String {
        createdAt.formatted(date: .omitted, time: .shortened)
    }

    var createdAtDisplay: String {
        createdAt.formatted(date: .abbreviated, time: .shortened)
    }

    var timeRangeDisplay: String {
        let start = startTime?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        let end = endTime?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        if !start.isEmpty && !end.isEmpty { return "\(start) - \(end)" }
        if !start.isEmpty { return start }
        if !end.isEmpty { return end }
        return "后端未返回"
    }
}

struct LocalSummaryDayGroup: Identifiable, Equatable {
    let id: String
    let dateTitle: String
    let records: [LocalSummaryRecord]
}

struct SettingsResponse: Codable {
    let ok: Bool
    let settings: AppSettings
}

struct BackendHealthResponse: Codable, Equatable {
    let ok: Bool
    let time: String?
    let provider: String?
}

struct IMAPTestResponse: Codable, Equatable {
    let ok: Bool
    let account: String?
    let host: String?
    let inboxMailbox: String?
    let messages: Int?
    let unseen: Int?
    let error: String?
}

struct AITestResponse: Codable, Equatable {
    let ok: Bool
    let reply: String?
    let error: String?
}


struct SchedulerStatusResponse: Codable, Equatable {
    let ok: Bool
    let schedulerEnabled: Bool?
    let schedulerIntervalMinutes: Int?
    let renderSleepNote: String?
    let scheduler: SchedulerRuntimeStatus?
    let users: [SchedulerUserStatus]?
}

struct SchedulerRuntimeStatus: Codable, Equatable {
    let enabled: Bool?
    let intervalMinutes: Int?
    let running: Bool?
    let lastTickAt: String?
    let lastCompletedAt: String?
    let lastRunAt: String?
    let lastRunUserId: String?
    let lastRunProcessed: Int?
    let lastError: String?
    let lastErrorAt: String?
}

struct SchedulerUserStatus: Codable, Equatable, Identifiable {
    let id: String
    let provider: String?
    let email: String?
    let enabled: Bool?
    let frequency: String?
    let lastRunAt: String?
    let lastTestRunAt: String?
    let nextDueAt: String?
    let due: Bool?
}


struct ParsedSummary: Equatable {
    var title: String
    var timeRange: String
    var processedCount: Int
    var importantCount: Int
    var spamCount: Int
    var reminders: [String]
    var importantEmails: [ParsedEmailItem]
    var importantFallback: [String]
    var normalSummary: [String]
    var spamSummary: [String]
    var risks: [String]
    var nextSteps: [String]
    var fallbackParagraphs: [String]

    var hasRisk: Bool {
        let joined = risks.joined(separator: " ").trimmingCharacters(in: .whitespacesAndNewlines)
        if joined.isEmpty { return false }
        let safeWords = ["暂无", "无明显", "没有明显", "无风险", "未发现", "无"]
        return !safeWords.contains { joined.contains($0) }
    }
}

struct ParsedEmailItem: Identifiable, Equatable {
    var id = UUID().uuidString
    var sender: String = ""
    var subject: String = ""
    var time: String = ""
    var summary: String = ""
    var action: String = ""
    var deadline: String = ""
    var priority: String = ""

    var hasAnyContent: Bool {
        [sender, subject, time, summary, action, deadline, priority]
            .contains { !$0.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
    }
}

enum SummaryParser {
    static func parse(_ record: LocalSummaryRecord) -> ParsedSummary {
        if let structured = record.structured {
            return parseStructured(
                structured,
                fallbackContent: record.content,
                fallbackTitle: record.title,
                fallbackTimeRange: record.timeRangeDisplay,
                fallbackProcessedCount: record.processedCount,
                fallbackImportantCount: record.importantCount,
                fallbackSpamCount: record.spamCount
            )
        }
        return parse(
            record.content,
            fallbackTitle: record.title,
            fallbackTimeRange: record.timeRangeDisplay,
            fallbackProcessedCount: record.processedCount,
            fallbackImportantCount: record.importantCount,
            fallbackSpamCount: record.spamCount
        )
    }

    private static func parseStructured(
        _ structured: StructuredSummary,
        fallbackContent: String,
        fallbackTitle: String,
        fallbackTimeRange: String,
        fallbackProcessedCount: Int,
        fallbackImportantCount: Int,
        fallbackSpamCount: Int
    ) -> ParsedSummary {
        let emails = (structured.importantEmails ?? []).map {
            ParsedEmailItem(
                sender: $0.sender ?? "",
                subject: $0.subject ?? "",
                time: $0.time ?? "",
                summary: $0.summary ?? "",
                action: $0.action ?? "",
                deadline: $0.deadline ?? "",
                priority: $0.priority ?? ""
            )
        }.filter { $0.hasAnyContent }
        let timeRange = structured.timeRange
            ?? ([structured.startTime, structured.endTime].compactMap { $0?.isEmpty == false ? $0 : nil }.joined(separator: " - "))
        return ParsedSummary(
            title: structured.title ?? fallbackTitle,
            timeRange: timeRange.isEmpty ? fallbackTimeRange : timeRange,
            processedCount: structured.processedCount ?? fallbackProcessedCount,
            importantCount: structured.importantCount ?? fallbackImportantCount,
            spamCount: structured.spamCount ?? fallbackSpamCount,
            reminders: structured.reminders ?? [],
            importantEmails: emails,
            importantFallback: [],
            normalSummary: structured.normalSummary ?? [],
            spamSummary: structured.spamSummary ?? [],
            risks: structured.risks ?? [],
            nextSteps: structured.nextSteps ?? [],
            fallbackParagraphs: makeFallbackParagraphs(from: cleanMarkdownForPlainText(fallbackContent))
        )
    }

    static func parse(
        _ rawText: String,
        fallbackTitle: String = "邮件总结",
        fallbackTimeRange: String = "后端未返回",
        fallbackProcessedCount: Int = 0,
        fallbackImportantCount: Int = 0,
        fallbackSpamCount: Int = 0
    ) -> ParsedSummary {
        let cleaned = cleanMarkdownForPlainText(rawText)
        let lines = cleaned.components(separatedBy: .newlines)
        let title = firstTitle(in: lines) ?? fallbackTitle
        let timeRange = firstValue(in: lines, labels: ["时间范围"]) ?? fallbackTimeRange
        let processed = firstNumber(in: lines, labels: ["处理邮件"]) ?? fallbackProcessedCount
        let important = firstNumber(in: lines, labels: ["重要邮件"]) ?? fallbackImportantCount
        let spam = firstNumber(in: lines, labels: ["垃圾/低价值邮件", "低价值邮件", "垃圾邮件"]) ?? fallbackSpamCount
        let sections = splitSections(lines)
        let importantSection = normalizeListLines(sections[.important] ?? [])
        let importantEmails = parseImportantEmails(from: importantSection)
        let importantFallback = importantEmails.isEmpty ? importantSection : []
        let fallbackParagraphs = makeFallbackParagraphs(from: cleaned)

        return ParsedSummary(
            title: title,
            timeRange: timeRange,
            processedCount: processed,
            importantCount: important,
            spamCount: spam,
            reminders: normalizeListLines(sections[.reminders] ?? []),
            importantEmails: importantEmails,
            importantFallback: importantFallback,
            normalSummary: normalizeListLines(sections[.normal] ?? []),
            spamSummary: normalizeListLines(sections[.spam] ?? []),
            risks: normalizeListLines(sections[.risks] ?? []),
            nextSteps: normalizeListLines(sections[.nextSteps] ?? []),
            fallbackParagraphs: fallbackParagraphs
        )
    }

    private enum SectionKey: Hashable {
        case reminders
        case important
        case normal
        case spam
        case risks
        case nextSteps
    }

    private static func splitSections(_ lines: [String]) -> [SectionKey: [String]] {
        var result: [SectionKey: [String]] = [:]
        var current: SectionKey?
        for line in lines {
            let normalized = normalizeHeadingLine(line)
            if let key = sectionKey(for: normalized) {
                current = key
                result[key, default: []] = []
                continue
            }
            guard let current else { continue }
            result[current, default: []].append(line)
        }
        return result
    }

    private static func sectionKey(for heading: String) -> SectionKey? {
        let value = heading.replacingOccurrences(of: " ", with: "")
        if value.contains("重点提醒") { return .reminders }
        if value.contains("重要邮件") { return .important }
        if value.contains("普通邮件") { return .normal }
        if value.contains("垃圾邮件") || value.contains("可忽略邮件") { return .spam }
        if value.contains("风险提醒") { return .risks }
        if value.contains("下一步建议") { return .nextSteps }
        return nil
    }

    private static func normalizeHeadingLine(_ line: String) -> String {
        stripListPrefix(line)
            .replacingOccurrences(of: "#", with: "")
            .replacingOccurrences(of: "*", with: "")
            .trimmingCharacters(in: .whitespacesAndNewlines)
    }

    private static func firstTitle(in lines: [String]) -> String? {
        for line in lines {
            let trimmed = normalizeHeadingLine(line)
            if trimmed.isEmpty { continue }
            if trimmed.contains("时间范围：") || trimmed.contains("处理邮件：") { continue }
            return trimmed
        }
        return nil
    }

    private static func firstValue(in lines: [String], labels: [String]) -> String? {
        for line in lines {
            for label in labels {
                if let value = fieldValue(in: line, labels: [label]) { return value }
            }
        }
        return nil
    }

    private static func firstNumber(in lines: [String], labels: [String]) -> Int? {
        guard let value = firstValue(in: lines, labels: labels) else { return nil }
        let digits = value.compactMap { $0.isNumber ? String($0) : nil }.joined()
        return Int(digits)
    }

    private static func normalizeListLines(_ lines: [String]) -> [String] {
        lines
            .map { cleanMarkdownForPlainText($0).trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty }
    }

    private static func makeFallbackParagraphs(from text: String) -> [String] {
        text.components(separatedBy: .newlines)
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty }
    }

    private static func parseImportantEmails(from lines: [String]) -> [ParsedEmailItem] {
        var items: [ParsedEmailItem] = []
        var current = ParsedEmailItem()

        func flush() {
            if current.hasAnyContent {
                items.append(current)
                current = ParsedEmailItem()
            }
        }

        for rawLine in lines {
            let line = stripListPrefix(rawLine)
            if let value = fieldValue(in: line, labels: ["发件人", "发件人邮箱", "From", "Sender"]) {
                if current.hasAnyContent { flush() }
                current.sender = value
            } else if let value = fieldValue(in: line, labels: ["主题", "Subject"]) {
                current.subject = value
            } else if let value = fieldValue(in: line, labels: ["时间", "Time", "日期"]) {
                current.time = value
            } else if let value = fieldValue(in: line, labels: ["摘要", "Summary", "内容摘要"]) {
                current.summary = append(current.summary, value)
            } else if let value = fieldValue(in: line, labels: ["需要操作", "操作", "Action", "待办"]) {
                current.action = append(current.action, value)
            } else if let value = fieldValue(in: line, labels: ["截止时间", "Deadline", "截止日期"]) {
                current.deadline = value
            } else if let value = fieldValue(in: line, labels: ["优先级", "Priority"]) {
                current.priority = value
            } else if current.hasAnyContent {
                current.summary = append(current.summary, line)
            }
        }
        flush()
        return items
    }

    private static func fieldValue(in rawLine: String, labels: [String]) -> String? {
        let line = stripListPrefix(cleanMarkdownForPlainText(rawLine))
        for label in labels {
            let candidates = ["\(label)：", "\(label):"]
            for candidate in candidates where line.hasPrefix(candidate) {
                let value = String(line.dropFirst(candidate.count)).trimmingCharacters(in: .whitespacesAndNewlines)
                return value.isEmpty ? "未填写" : value
            }
        }
        return nil
    }

    private static func stripListPrefix(_ value: String) -> String {
        value
            .replacingOccurrences(of: #"^\s*[-•*]\s*"#, with: "", options: .regularExpression)
            .replacingOccurrences(of: #"^\s*\d+[\.、)]\s*"#, with: "", options: .regularExpression)
            .trimmingCharacters(in: .whitespacesAndNewlines)
    }

    private static func append(_ existing: String, _ newValue: String) -> String {
        let old = existing.trimmingCharacters(in: .whitespacesAndNewlines)
        let new = newValue.trimmingCharacters(in: .whitespacesAndNewlines)
        if old.isEmpty { return new }
        if new.isEmpty { return old }
        return old + "\n" + new
    }
}
