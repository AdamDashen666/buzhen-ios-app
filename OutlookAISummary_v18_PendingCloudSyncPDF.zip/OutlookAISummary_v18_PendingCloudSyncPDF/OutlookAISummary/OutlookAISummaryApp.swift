import SwiftUI

@main
struct OutlookAISummaryApp: App {
    @UIApplicationDelegateAdaptor(AppDelegate.self) private var appDelegate
    @StateObject private var state = AppState()
    @Environment(\.scenePhase) private var scenePhase

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(state)
                .task { await state.bootstrap() }
                .onReceive(NotificationCenter.default.publisher(for: .didReceivePushToken)) { notification in
                    if let token = notification.object as? String { state.updatePushToken(token) }
                }
                .onReceive(NotificationCenter.default.publisher(for: .didFailPushToken)) { notification in
                    if let message = notification.object as? String { state.lastError = message }
                }
                .onChange(of: scenePhase) { phase in
                    if phase == .active {
                        Task { await state.syncPendingSummaries(showNoNew: false) }
                    }
                }
        }
    }
}
