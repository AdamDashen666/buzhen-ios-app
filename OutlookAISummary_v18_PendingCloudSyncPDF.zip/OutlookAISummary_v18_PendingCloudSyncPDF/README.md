# Outlook AI Summary v8 QQ IMAP

QQ IMAP + Render 后端模式：

Outlook 转发/重定向 → QQ 邮箱 → Render 后端 IMAP 读取 → AI 中文总结 → iOS 推送/App 历史记录。

## v8 修改

- iOS 前端不再保存、显示或上传 `aiModel`、`aiBaseUrl`、`aiApiKey`。
- 设置页只保留后端地址、总结频率、自动总结、转发邮件解析、自动清理相关开关。
- 前端不再请求旧配置接口。
- QQ IMAP 邮箱连接状态只看 `GET /imap/test`。
- 新增“测试 AI 模型”按钮，调用 `POST /ai/test`，不读取邮件、不标记已读。
- 后端 `/settings` 会过滤旧 AI 字段，AI 配置只从 Render 环境变量读取。

## Render 环境变量

```text
MAIL_PROVIDER=qq
IMAP_HOST=imap.qq.com
IMAP_PORT=993
IMAP_SECURE=true
IMAP_USER=your_qq_email@qq.com
IMAP_PASS=your_qq_mail_authorization_code
AI_API_KEY=your_ai_key
AI_BASE_URL=https://your-ai-provider.example.com/v1/chat/completions
AI_MODEL=your-model-name
```

## 测试接口

```text
GET  https://your-render-service.onrender.com/health
GET  https://your-render-service.onrender.com/imap/test
POST https://your-render-service.onrender.com/ai/test
```

## 风险提醒

- `IMAP_PASS` 是 QQ 邮箱授权码，泄露后别人可能读取邮箱。
- 开启并配置 `IMAP_TRASH_MAILBOX` 后，自动清理会影响真实邮箱，建议先用小号测试。


## v9 更新：测试总结限制与正式总结窗口

- “测试总结当前邮件”只处理最近 3 封未读邮件：`mode: "test"`, `limit: 3`。
- UI 明确提示测试总结不会处理全部历史邮件。
- “立即总结”按当前频率传 `windowHours` 和 `maxMessages`。
- 后端 `/summarize/run` 已兼容 `mode / limit / windowHours / maxMessages`，避免测试时扫几百封未读邮件。
- “测试 AI 模型”仍调用 `POST /ai/test`。


## v10 更新：总结接口解析容错

- `POST /summarize/run` 返回解析改为容错结构。
- 支持 `ok / mode / processed / processedCount / summary / message / error / hasMore`。
- `summary` 支持字符串、完整总结对象、以及只包含 `content/text/result/message` 的简单对象。
- JSON decode 失败时显示：`接口返回格式不正确`，并展示原始 response body 前 500 字。
- 不再只显示系统错误：`The data couldn’t be read because it isn’t in the correct format.`
