# Outlook AI Summary v7

## Changes

- QQ IMAP mode no longer depends on `/auth/status`.
- If `/imap/test` returns `ok: true`, the app displays the mailbox as connected.
- Removed the false red error caused by old Graph-style status parsing.
- Added an in-app test summary button.
- The test summary button calls existing backend endpoint `POST /summarize/run`.
- No new backend endpoint is required.
- The backend will mark summarized unread messages as read.

## Checked endpoints

- `GET /health`
- `GET /imap/test`
- `GET /summaries`
- `POST /summarize/run`

No `/config` request is used.
