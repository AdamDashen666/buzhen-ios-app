# v17 自动总结加固

本版本重点修复“App 重进才检查连接，自动总结不可靠”的问题。

## 改动

- 后端自动总结由 Render 后端定时器执行，不依赖 App 是否打开。
- 后端启动时会自动创建 QQ IMAP 默认用户，不再必须等 App 每次打开后重新检查连接。
- 测试总结不再更新正式总结的 `lastRunAt`，避免点击测试后推迟自动总结。
- 新增后端接口：
  - `GET /scheduler/status`：查看自动总结状态、上次检查、上次正式总结、下次预计执行时间。
  - `GET/POST /scheduler/tick`：手动触发一次调度检查，适合 Render Cron / UptimeRobot / cron-job.org 定时唤醒。
- 设置页新增“自动总结状态”卡片。

## Render 免费实例注意

如果 Render 实例睡眠，后端内部 `setInterval` 不能自己唤醒服务器。建议配置外部定时请求：

```text
https://你的后端域名/scheduler/tick
```

建议 10-15 分钟请求一次。

如果设置了 `CRON_SECRET`，请求改成：

```text
https://你的后端域名/scheduler/tick?token=你的CRON_SECRET
```

## 环境变量

```text
SCHEDULER_ENABLED=true
SCHEDULER_INTERVAL_MINUTES=15
CRON_SECRET=
```

## 保持不变

- 不请求 `/config`
- 不在 App 设置 AI Key / Base URL / Model
- 不向后端发送 `aiModel / aiBaseUrl / aiApiKey`
- QQ IMAP 连接继续以 `/imap/test ok:true` 为准
