# v8 Frontend AI Settings Cleanup + AI Model Test

## iOS App changes
- Removed legacy AI settings from `AppSettings`: `aiModel`, `aiBaseUrl`, `aiApiKey`.
- App no longer sends AI settings to `POST /settings`.
- App removes legacy `UserDefaults` keys on launch.
- Settings page only keeps backend URL, schedule, auto summary, forwarded-mail parsing, and cleanup switches.
- Removed frontend `/config` usage.
- Removed frontend `/auth/status` mailbox-state fallback for QQ IMAP mode.
- Mailbox connection status now uses `GET /imap/test` only.
- Added a non-destructive “测试 AI 模型” button.

## Backend support added
- Added `POST /ai/test` for checking whether Render AI environment variables work.
- Backend AI calls now require `AI_API_KEY`, `AI_BASE_URL`, and `AI_MODEL` from environment variables.
- Backend ignores legacy AI settings and sanitizes `/settings` input.
- Removed backend `/config` endpoint from this package to avoid stale configuration reads.

## Required backend env
```env
AI_API_KEY=your-key
AI_BASE_URL=your-openai-compatible-chat-completions-url
AI_MODEL=your-model-name
```
