# OutlookAISummary v14

Fixes v13 Xcode compile failure caused by `@MainActor`-isolated PDF helper functions being called inside the `UIGraphicsPDFRenderer` nonisolated rendering closure.

Changes:
- Moves PDF text attributes and measurement helpers to file-level nonisolated helpers.
- Keeps v13 structured summary detail page and redesigned PDF report logic.
- No `/config` request.
- No frontend AI key/base URL/model settings.
- IMAP status still uses `/imap/test`.
