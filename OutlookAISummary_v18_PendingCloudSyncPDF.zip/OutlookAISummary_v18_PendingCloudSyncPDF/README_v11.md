# Outlook AI Summary v11

本版本重点修改前端总结测试、正式总结窗口、本地通知、历史总结和 PDF 报告。

## 前端

- “测试总结当前邮件”调用 `POST /summarize/run`，body 为：

```json
{
  "mode": "test",
  "latestCount": 3
}
```

- 测试总结固定只测试最新 3 封邮件，不要求未读。
- UI 提示：“仅测试最新 3 封邮件，不会处理全部历史邮件。”
- “立即总结”按频率传：
  - 每 6 小时：`windowHours: 6`
  - 每天：`windowHours: 24`
  - 每月：`windowHours: 720`
- 不请求 `/config`。
- 不在 App 里设置或上传 `AI_MODEL`、`AI_BASE_URL`、`AI_API_KEY`。
- QQ 邮箱连接状态继续只看 `/imap/test`。
- “测试 AI 模型”继续调用 `POST /ai/test`。

## 历史总结与 PDF

- 总结成功后保存本地历史记录。
- App 本地生成 PDF 报告。
- PDF 文件名格式：`mail_summary_yyyy-MM-dd_HH-mm_xxxxxx.pdf`。
- 文字历史保留 60 天。
- PDF 保留 15 天。
- PDF 删除后，详情页可用本地文字总结重新生成 PDF。
- 历史总结按日期倒序分组，小卡片显示时间范围、处理数量、重要数量、PDF 状态。

## 通知

- 新增“测试通知”按钮。
- 请求本地通知权限。
- 3 秒后发送本地通知：
  - 标题：Mail AI 测试通知
  - 内容：如果你看到这条通知，说明推送通知功能正常。

## 后端兼容

- `/summarize/run` 支持 `mode: test` + `latestCount: 3`。
- 测试模式读取最新邮件，不强制未读。
- 测试模式不会把邮件标记为已读/已总结。
