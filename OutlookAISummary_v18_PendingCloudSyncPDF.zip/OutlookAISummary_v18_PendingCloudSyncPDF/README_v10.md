# v10 Summarize Response Tolerant Decode

## iOS frontend

- `POST /summarize/run` no longer assumes only one response structure.
- Supported response fields:
  - `ok: Bool`
  - `mode: String?`
  - `processed: Int?`
  - `processedCount: Int?`
  - `summary: String?` or summary object
  - `message: String?`
  - `error: String?`
  - `hasMore: Bool?`
- `summary` can now be:
  - a full `SummaryItem` object
  - a plain string
  - a simple object containing `content`, `text`, `result`, or `message`
- If JSON decoding fails, the app shows:
  - `接口返回格式不正确`
  - raw response body preview, limited to the first 500 characters
- Timeout wording remains unchanged.
- No `/config` request is restored.
- No frontend AI model/base/key settings are restored.
- `POST /ai/test` still handles only the AI model test button.
