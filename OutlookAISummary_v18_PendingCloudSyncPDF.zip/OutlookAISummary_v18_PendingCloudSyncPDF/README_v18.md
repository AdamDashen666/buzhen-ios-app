# v18 - Pending Cloud Summary Sync

## iOS App

- Added automatic cloud summary sync on app launch, foreground activation, and manual refresh.
- Added `GET /summaries/pending` client call.
- Saves pending backend summaries into local history.
- Generates local PDF for each synced summary.
- Keeps text history for 60 days and PDF files for 15 days.
- If PDF generation fails, the text summary is still saved and the detail page can regenerate the PDF.
- Added cloud sync status UI with loading/progress text such as `正在同步云端总结...` and `已同步 1 / 3`.
- History remains grouped by date and opens the structured detail page.
- Detail page prefers `structured` summary data when available, otherwise parses the summary text.

## Backend

- Added `GET /summaries/pending`.
- Added `POST /summaries/mark-synced`.
- `/summarize/run` now stores summaries as pending until the app syncs them.
- `/summarize/run` response includes summary id, title, createdAt, counts, time range, and structured placeholder.
- Shortcut-triggered backend summaries can be synced later when the app opens.

## Preserved

- No `/config` request.
- No frontend AI key/model/base URL settings.
- No `aiModel`, `aiBaseUrl`, or `aiApiKey` sent to `/settings`.
- QQ IMAP status still uses `/imap/test`.
- AI model test still uses `POST /ai/test`.
- Test summary still uses `/summarize/run` with `mode=test` and `latestCount=3`.
