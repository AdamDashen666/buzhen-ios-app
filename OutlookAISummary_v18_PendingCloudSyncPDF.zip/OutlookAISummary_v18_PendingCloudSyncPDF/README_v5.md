# Outlook AI Summary v5

Changes:
- Removed all `/config` backend configuration reads from the iOS app.
- Added backend connection checking in Dashboard and Settings.
- The app now checks only:
  - `GET /health`
  - `GET /imap/test`
- QQ IMAP connection status is based on `/imap/test` returning `ok: true`.
- AI key/model/base URL remain managed by Render environment variables; the app does not read or display secrets.

Default backend URL:

```text
https://outlook-ai-backend.onrender.com
```

Note: This package updates the app only. Render backend does not need changes for this version.
