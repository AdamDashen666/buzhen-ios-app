# Outlook AI Summary v15

## 修复

- 首页「测试 AI 总结」卡片不再直接显示完整 summary 长文本。
- 测试总结成功后只显示简短状态：已测试数量、已保存到历史总结、是否只测试部分邮件。
- 立即总结成功后也只显示简短状态，不再把完整总结塞进首页。
- 完整报告继续保存在「历史总结」中，点击卡片进入结构化详情页查看。

## 保持不变

- 不请求 `/config`。
- 不在 App 里设置 AI_MODEL、AI_BASE_URL、AI_API_KEY。
- 不向后端发送 aiModel、aiBaseUrl、aiApiKey。
- QQ IMAP 连接状态继续以 `/imap/test` 的 `ok:true` 为准。
- 测试 AI 模型继续调用 `POST /ai/test`。
