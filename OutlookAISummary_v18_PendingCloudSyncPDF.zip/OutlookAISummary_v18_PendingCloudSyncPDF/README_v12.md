# OutlookAISummary v12 - PDF Draw Compile Fix

修复 v11 Xcode 编译错误：

- `AppState.swift` PDF 渲染中 `NSAttributedString.draw(with:)` 在当前 SDK 下需要传入 `options` 与 `context`。
- 已改为 `draw(with:options:context:)`，保留 PDF 分页和 Markdown 清理逻辑。

保持 v11 功能不变：

- 测试总结最新 3 封邮件
- 正式总结按时间窗口
- 测试通知
- 历史总结
- 本地 PDF 生成 / 打开 / 分享 / 重新生成
- 不请求 `/config`
- 不在前端保存或上传 AI Key / Base URL / Model
- QQ IMAP 状态继续使用 `/imap/test`
