# Outlook AI Summary Backend v8

Node.js Render backend for QQ Mail IMAP reading, AI summary generation, and iOS push/app history.

## Install

```bash
npm install
npm start
```

## Required environment variables

```text
MAIL_PROVIDER=qq
IMAP_HOST=imap.qq.com
IMAP_PORT=993
IMAP_SECURE=true
IMAP_USER=your_qq_email@qq.com
IMAP_PASS=your_qq_mail_authorization_code
AI_BASE_URL=https://your-ai-provider.example.com/v1/chat/completions
AI_API_KEY=your_ai_key
AI_MODEL=your-model-name
DELETE_AFTER_DAYS=30
PERMANENT_DELETE_AFTER_DAYS=7
AUTO_DELETE_ENABLED=true
```

Do not commit real QQ authorization codes, AI keys, APNs keys, or `.env` files.

## Health / test endpoints

```text
GET  /health
GET  /imap/test
POST /ai/test
```

`POST /ai/test` only checks whether the Render AI environment variables can call the configured model. It does not read mailbox content and does not mark emails as read.

## iOS app flow

1. Put the Render backend URL in Settings.
2. Tap “检查后端连接”.
3. If `/imap/test` returns `ok:true`, the app shows the mailbox as connected.
4. Tap “测试 AI 模型” to check AI connectivity.
5. Tap “测试总结当前邮件” only when you want to read unread mail and mark summarized mail as read.

## Security notes

- Keep `IMAP_PASS` and `AI_API_KEY` only in Render environment variables.
- Revoke the QQ Mail authorization code if it is exposed.
- Automatic cleanup can affect the real mailbox when `IMAP_TRASH_MAILBOX` is configured.
