import "dotenv/config";
import express from "express";
import crypto from "node:crypto";
import {
  buildMicrosoftAuthUrl,
  exchangeCodeForToken,
  refreshToken,
  getMe,
  getUnreadMessages,
  getReadOlderThan,
  markMessageSummarized,
  moveToDeletedItems,
  permanentDelete
} from "./graph.js";
import {
  isImapConfigured,
  getImapAccountInfo,
  testImapConnection,
  getUnreadImapMessages,
  getLatestImapMessages,
  markImapMessageSummarized,
  cleanupImapMessages
} from "./imapMail.js";
import { summarizeMessages, testAIModel } from "./ai.js";
import { sendSummaryPush } from "./push.js";
import { loadStore, saveStore, updateStore, nowIso, isDue } from "./store.js";

const app = express();
app.use(express.json({ limit: "1mb" }));

const PORT = Number(process.env.PORT || 3000);
const DELETE_AFTER_DAYS = Number(process.env.DELETE_AFTER_DAYS || 30);
const PERMANENT_DELETE_AFTER_DAYS = Number(process.env.PERMANENT_DELETE_AFTER_DAYS || 7);
const AUTO_DELETE_ENABLED = String(process.env.AUTO_DELETE_ENABLED ?? "true").toLowerCase() === "true";
const MAIL_PROVIDER = String(process.env.MAIL_PROVIDER || "graph").toLowerCase();
const USE_IMAP = MAIL_PROVIDER === "qq" || MAIL_PROVIDER === "imap";
const SCHEDULER_ENABLED = String(process.env.SCHEDULER_ENABLED ?? "true").toLowerCase() === "true";
const SCHEDULER_INTERVAL_MINUTES = Math.max(1, Number(process.env.SCHEDULER_INTERVAL_MINUTES || 15));
const CRON_SECRET = process.env.CRON_SECRET || "";
let schedulerRunning = false;

function makeId(prefix) {
  return `${prefix}_${crypto.randomBytes(12).toString("hex")}`;
}

function trimPushBody(text) {
  return text.replace(/[#*`>\-]/g, "").replace(/\s+/g, " ").slice(0, 160);
}

function clampPositiveInt(value, fallback, min = 1, max = 100) {
  const n = Number(value);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, Math.floor(n)));
}

function frequencyRunOptions(frequency = "daily") {
  if (frequency === "sixHours") return { windowHours: 6, maxMessages: 30 };
  if (frequency === "monthly") return { windowHours: 720, maxMessages: 50 };
  return { windowHours: 24, maxMessages: 30 };
}

function normalizeRunOptions(input = {}, settings = {}) {
  const mode = input.mode === "test" ? "test" : "scheduled";
  if (mode === "test") {
    const latestCount = clampPositiveInt(input.latestCount ?? input.limit, 3, 1, 10);
    return {
      mode,
      latestCount,
      limit: latestCount,
      maxMessages: latestCount,
      includeJunkUnread: settings.includeJunkUnread !== false
    };
  }

  const defaults = frequencyRunOptions(settings.frequency);
  const windowHours = clampPositiveInt(input.windowHours, defaults.windowHours, 1, 24 * 31);
  const inferredMaxMessages = windowHours >= 720 ? 50 : 30;
  return {
    mode,
    windowHours,
    maxMessages: clampPositiveInt(input.maxMessages, inferredMaxMessages, 1, 100),
    includeJunkUnread: settings.includeJunkUnread !== false
  };
}


async function getFreshAccessToken(user, store) {
  const expiresAt = user.tokens?.expiresAt ? new Date(user.tokens.expiresAt) : new Date(0);
  if (Date.now() < expiresAt.getTime() - 5 * 60 * 1000) return user.tokens.accessToken;

  const refreshed = await refreshToken(user.tokens.refreshToken);
  user.tokens.accessToken = refreshed.access_token;
  user.tokens.refreshToken = refreshed.refresh_token || user.tokens.refreshToken;
  user.tokens.expiresAt = new Date(Date.now() + refreshed.expires_in * 1000).toISOString();
  store.users[user.id] = user;
  return user.tokens.accessToken;
}

app.get("/health", (_, res) => {
  const store = loadStore();
  res.json({
    ok: true,
    time: nowIso(),
    provider: USE_IMAP ? "imap" : "graph",
    schedulerEnabled: SCHEDULER_ENABLED,
    schedulerIntervalMinutes: SCHEDULER_INTERVAL_MINUTES,
    scheduler: store.scheduler || null
  });
});

app.get("/imap/test", async (_, res) => {
  try {
    if (!USE_IMAP) return res.json({ ok: false, error: "MAIL_PROVIDER is not qq/imap" });
    const result = await testImapConnection();
    res.json(result);
  } catch (err) {
    console.error("IMAP test failed", err);
    res.status(500).json({ ok: false, error: err.message });
  }
});

app.post("/ai/test", async (_, res) => {
  try {
    const result = await testAIModel();
    res.json(result);
  } catch (err) {
    console.error("AI test failed", err);
    res.status(500).json({ ok: false, error: err.message });
  }
});

function sanitizeSettings(input = {}, current = {}) {
  const allowedFrequency = ["daily", "sixHours", "monthly"];
  return {
    enabled: input.enabled ?? current.enabled ?? true,
    frequency: allowedFrequency.includes(input.frequency) ? input.frequency : (current.frequency || "daily"),
    language: "zh-CN",
    includeJunkUnread: input.includeJunkUnread ?? current.includeJunkUnread ?? true,
    autoDeleteEnabled: input.autoDeleteEnabled ?? current.autoDeleteEnabled ?? true,
    deleteAfterDays: Number(input.deleteAfterDays || current.deleteAfterDays || DELETE_AFTER_DAYS),
    permanentDeleteAfterDays: Number(input.permanentDeleteAfterDays || current.permanentDeleteAfterDays || PERMANENT_DELETE_AFTER_DAYS)
  };
}

app.post("/devices/register", (req, res) => {
  const { deviceId = makeId("device"), deviceToken = "", platform = "iOS" } = req.body || {};
  const result = updateStore(store => {
    const baseDevice = {
      ...(store.devices[deviceId] || {}),
      deviceId,
      deviceToken,
      platform,
      updatedAt: nowIso()
    };

    // QQ/IMAP mode does not need Microsoft OAuth. If IMAP is configured in Render,
    // the first registered iOS device is automatically linked to this mailbox.
    if (USE_IMAP && isImapConfigured()) {
      const info = getImapAccountInfo();
      const userId = "imap_default_user";
      baseDevice.userId = userId;
      store.users[userId] = {
        ...(store.users[userId] || {}),
        id: userId,
        deviceId,
        provider: info.provider,
        imap: {
          email: info.email,
          host: info.host,
          inboxMailbox: info.inboxMailbox,
          junkMailbox: info.junkMailbox
        },
        settings: sanitizeSettings(store.users[userId]?.settings || {}, {
          enabled: true,
          frequency: "daily",
          language: "zh-CN",
          includeJunkUnread: Boolean(info.junkMailbox),
          autoDeleteEnabled: true,
          deleteAfterDays: DELETE_AFTER_DAYS,
          permanentDeleteAfterDays: PERMANENT_DELETE_AFTER_DAYS
        }),
        updatedAt: nowIso()
      };
    }

    store.devices[deviceId] = baseDevice;
    return store.devices[deviceId];
  });
  res.json(result);
});

app.get("/auth/start", (req, res) => {
  const deviceId = String(req.query.deviceId || "");
  if (!deviceId) return res.status(400).send("Missing deviceId");

  if (USE_IMAP) {
    return res.send(`<!doctype html><meta name="viewport" content="width=device-width, initial-scale=1"><body style="font-family:-apple-system;padding:28px;background:#101827;color:white"><h2>QQ 邮箱模式</h2><p>此版本不需要 Microsoft 登录。请在 Render 环境变量里配置 IMAP_USER 和 IMAP_PASS，然后回到 App 点击刷新状态。</p></body>`);
  }

  const state = crypto.randomBytes(16).toString("hex");
  updateStore(store => {
    store.authStates[state] = { deviceId, createdAt: nowIso() };
  });
  res.redirect(buildMicrosoftAuthUrl({ deviceId, state }));
});

app.get("/auth/callback", async (req, res) => {
  try {
    const { code, state: rawState } = req.query;
    const [deviceId, state] = String(rawState || "").split(":");
    if (!code || !deviceId || !state) return res.status(400).send("Invalid callback");

    const tokens = await exchangeCodeForToken(String(code));
    const me = await getMe(tokens.access_token);
    const userId = me.id || makeId("user");

    updateStore(store => {
      const authState = store.authStates[state];
      if (!authState || authState.deviceId !== deviceId) throw new Error("Auth state mismatch");
      delete store.authStates[state];

      store.devices[deviceId] = {
        ...(store.devices[deviceId] || {}),
        deviceId,
        userId,
        updatedAt: nowIso()
      };
      store.users[userId] = {
        ...(store.users[userId] || {}),
        id: userId,
        deviceId,
        microsoft: me,
        tokens: {
          accessToken: tokens.access_token,
          refreshToken: tokens.refresh_token,
          expiresAt: new Date(Date.now() + tokens.expires_in * 1000).toISOString()
        },
        settings: {
          enabled: true,
          frequency: "daily",
          language: "zh-CN",
          includeJunkUnread: true,
          autoDeleteEnabled: true,
          deleteAfterDays: DELETE_AFTER_DAYS,
          permanentDeleteAfterDays: PERMANENT_DELETE_AFTER_DAYS
        },
        updatedAt: nowIso()
      };
    });

    res.send(`<!doctype html><meta name="viewport" content="width=device-width, initial-scale=1"><body style="font-family:-apple-system;padding:28px;background:#101827;color:white"><h2>登录完成</h2><p>Outlook 已授权，可以回到 App。</p></body>`);
  } catch (err) {
    console.error(err);
    res.status(500).send(`Login failed: ${err.message}`);
  }
});

app.get("/auth/status", (req, res) => {
  const deviceId = String(req.query.deviceId || "");
  const store = loadStore();
  const device = store.devices[deviceId];
  const user = device?.userId ? store.users[device.userId] : null;
  res.json({
    linked: Boolean(user),
    user: user ? {
      displayName: user.microsoft?.displayName || (user.provider === "qq" ? "QQ 邮箱" : user.imap?.email),
      email: user.microsoft?.mail || user.microsoft?.userPrincipalName || user.imap?.email,
      settings: sanitizeSettings(user.settings || {}),
      lastRunAt: user.lastRunAt
    } : null
  });
});

app.post("/settings", (req, res) => {
  const { deviceId, settings = {} } = req.body || {};
  const result = updateStore(store => {
    const device = store.devices[deviceId];
    if (!device?.userId || !store.users[device.userId]) throw new Error("Device not linked");
    const current = store.users[device.userId].settings || {};
    store.users[device.userId].settings = sanitizeSettings(settings, current);
    store.users[device.userId].settingsUpdatedAt = nowIso();
    store.users[device.userId].updatedAt = nowIso();
    return store.users[device.userId].settings;
  });
  res.json({ ok: true, settings: result });
});

app.get("/summaries", (req, res) => {
  const deviceId = String(req.query.deviceId || "");
  const store = loadStore();
  const { user } = resolveRunTarget(store, deviceId);
  const list = Object.values(store.summaries)
    .filter(s => s.userId === user?.id)
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    .slice(0, 30);
  res.json({ summaries: list });
});

app.get("/summaries/pending", (req, res) => {
  try {
    const deviceId = String(req.query.deviceId || "");
    const store = loadStore();
    const { user } = resolveRunTarget(store, deviceId);
    if (!user) return res.json({ ok: true, summaries: [] });

    const summaries = Object.values(store.summaries)
      .filter(s => s.userId === user.id && !s.syncedAt)
      .sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt))
      .slice(0, 50)
      .map(s => ({
        id: s.id,
        title: s.title,
        summary: s.content,
        content: s.content,
        createdAt: s.createdAt,
        mode: s.mode || "scheduled",
        processed: s.processedCount ?? s.unreadCount ?? 0,
        processedCount: s.processedCount ?? s.unreadCount ?? 0,
        startTime: s.startTime || null,
        endTime: s.endTime || null,
        importantCount: s.importantCount ?? 0,
        spamCount: s.spamCount ?? s.junkUnreadCount ?? 0,
        hasMore: Boolean(s.hasMore),
        structured: s.structured || null
      }));
    res.json({ ok: true, summaries });
  } catch (err) {
    console.error("Pending summaries failed", err);
    res.status(500).json({ ok: false, error: err.message });
  }
});

app.post("/summaries/mark-synced", (req, res) => {
  try {
    const ids = Array.isArray(req.body?.ids) ? req.body.ids.map(String) : [];
    const syncedAt = nowIso();
    const synced = updateStore(store => {
      let count = 0;
      for (const id of ids) {
        if (store.summaries[id]) {
          store.summaries[id].syncedAt = syncedAt;
          count += 1;
        }
      }
      return count;
    });
    res.json({ ok: true, synced });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});


app.get("/scheduler/status", (req, res) => {
  const store = loadStore();
  if (USE_IMAP) ensureDefaultImapUser(store);
  const users = Object.values(store.users).map(user => ({
    id: user.id,
    provider: user.provider || (USE_IMAP ? "imap" : "graph"),
    email: user.imap?.email || user.microsoft?.mail || user.microsoft?.userPrincipalName || null,
    enabled: user.settings?.enabled !== false,
    frequency: user.settings?.frequency || "daily",
    lastRunAt: user.lastRunAt || null,
    lastTestRunAt: user.lastTestRunAt || null,
    nextDueAt: nextDueAt(user),
    due: isDue(user)
  }));
  saveStore(store);
  res.json({
    ok: true,
    schedulerEnabled: SCHEDULER_ENABLED,
    schedulerIntervalMinutes: SCHEDULER_INTERVAL_MINUTES,
    renderSleepNote: "If Render sleeps, use GET or POST /scheduler/tick from Render Cron, cron-job.org, or UptimeRobot.",
    scheduler: store.scheduler || null,
    users
  });
});

async function handleSchedulerTickRequest(req, res) {
  if (CRON_SECRET) {
    const supplied = req.get("x-cron-secret") || req.query.token || req.body?.token || "";
    if (supplied !== CRON_SECRET) return res.status(401).json({ ok: false, error: "Invalid CRON_SECRET" });
  }
  try {
    const result = await schedulerTick("manual");
    res.json({ ok: true, ...result });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
}

app.get("/scheduler/tick", handleSchedulerTickRequest);
app.post("/scheduler/tick", handleSchedulerTickRequest);

function ensureDefaultImapUser(store) {
  if (!USE_IMAP || !isImapConfigured()) return null;
  const info = getImapAccountInfo();
  const userId = "imap_default_user";
  const deviceId = "imap_default_device";
  store.users[userId] = {
    ...(store.users[userId] || {}),
    id: userId,
    deviceId: store.users[userId]?.deviceId || deviceId,
    provider: info.provider,
    imap: {
      email: info.email,
      host: info.host,
      inboxMailbox: info.inboxMailbox,
      junkMailbox: info.junkMailbox
    },
    settings: sanitizeSettings(store.users[userId]?.settings || {}, {
      enabled: true,
      frequency: "daily",
      language: "zh-CN",
      includeJunkUnread: Boolean(info.junkMailbox),
      autoDeleteEnabled: true,
      deleteAfterDays: DELETE_AFTER_DAYS,
      permanentDeleteAfterDays: PERMANENT_DELETE_AFTER_DAYS
    }),
    updatedAt: nowIso()
  };
  store.devices[deviceId] = {
    ...(store.devices[deviceId] || {}),
    deviceId,
    platform: "iOS",
    userId,
    updatedAt: nowIso()
  };
  return { device: store.devices[deviceId], user: store.users[userId] };
}

function resolveRunTarget(store, requestedDeviceId) {
  const deviceId = String(requestedDeviceId || "");
  if (deviceId && store.devices[deviceId]?.userId) {
    const device = store.devices[deviceId];
    return { device, user: store.users[device.userId] };
  }
  if (USE_IMAP) {
    const existing = Object.values(store.devices).find(d => d.userId === "imap_default_user");
    if (existing?.userId && store.users[existing.userId]) return { device: existing, user: store.users[existing.userId] };
    if (store.users.imap_default_user) {
      return { device: { deviceId: "imap_default_device", userId: "imap_default_user" }, user: store.users.imap_default_user };
    }
    return ensureDefaultImapUser(store) || {};
  }
  return {};
}

app.post("/summarize/run", async (req, res) => {
  try {
    const { deviceId } = req.body || {};
    const store = loadStore();
    const { device, user } = resolveRunTarget(store, deviceId);
    if (!device?.userId || !user) return res.status(400).json({ ok: false, error: "Device not linked" });
    const runOptions = normalizeRunOptions(req.body || {}, user.settings || {});
    const result = await runSummaryForUser(user, device, store, runOptions);
    saveStore(store);
    res.json({
      ok: true,
      id: result.summary.id,
      summaryId: result.summary.id,
      title: result.summary.title,
      createdAt: result.summary.createdAt,
      mode: runOptions.mode,
      processed: result.processedCount,
      processedCount: result.processedCount,
      summary: result.summary.content,
      hasMore: result.hasMore,
      startTime: result.startTime,
      endTime: result.endTime,
      importantCount: result.importantCount,
      spamCount: result.spamCount,
      structured: result.summary.structured || null
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ ok: false, error: err.message });
  }
});

async function loadMessagesForRun(user, store, options) {
  if (USE_IMAP) {
    if (options.mode === "test") return getLatestImapMessages(options);
    return getUnreadImapMessages(options);
  }
  const accessToken = await getFreshAccessToken(user, store);
  return getUnreadMessages(accessToken, options);
}

async function runSummaryForUser(user, device, store, runOptions = {}) {
  const mailResult = await loadMessagesForRun(user, store, runOptions);
  const messages = Array.isArray(mailResult) ? mailResult : (mailResult.messages || []);
  const hasMore = Boolean(mailResult?.hasMore);
  const summaryId = makeId("summary");
  let content = runOptions.mode === "test" ? "没有可测试的邮件。" : "当前时间窗口内没有新的未读邮件。";

  if (messages.length > 0) {
    content = await summarizeMessages(messages);
    if (runOptions.mode !== "test") {
      for (const message of messages) {
        try {
          if (USE_IMAP) {
            await markImapMessageSummarized(message);
          } else {
            const accessToken = await getFreshAccessToken(user, store);
            await markMessageSummarized(accessToken, message);
          }

          store.summarizedMessages[message.id] = {
            userId: user.id,
            messageId: message.id,
            uid: message.uid,
            mailbox: message.mailbox,
            subject: message.subject,
            webLink: message.webLink || "",
            summarizedAt: nowIso(),
            sourceFolder: message.sourceFolder,
            provider: USE_IMAP ? "imap" : "graph"
          };
        } catch (err) {
          console.warn("Failed to mark summarized", message.id, err.message);
        }
      }
    }
  }

  const dates = messages
    .map(m => new Date(m.receivedDateTime).getTime())
    .filter(Number.isFinite)
    .sort((a, b) => a - b);
  const startTime = dates.length ? new Date(dates[0]).toISOString() : null;
  const endTime = dates.length ? new Date(dates[dates.length - 1]).toISOString() : null;
  const spamCount = messages.filter(m => m.sourceFolder === "junkemail").length;
  const importantCount = 0;
  const createdAt = nowIso();

  const titlePrefix = USE_IMAP ? "QQ 邮箱" : "Outlook";
  const title = runOptions.mode === "test" ? `${titlePrefix}测试总结` : `${titlePrefix}邮件总结`;
  const summary = {
    id: summaryId,
    userId: user.id,
    title,
    content,
    unreadCount: messages.length,
    junkUnreadCount: spamCount,
    processedCount: messages.length,
    importantCount,
    spamCount,
    startTime,
    endTime,
    mode: runOptions.mode || "scheduled",
    hasMore,
    structured: null,
    syncedAt: null,
    createdAt
  };
  store.summaries[summaryId] = summary;
  if (runOptions.mode === "scheduled") {
    user.lastRunAt = nowIso();
  } else {
    user.lastTestRunAt = nowIso();
  }
  store.users[user.id] = user;

  await sendSummaryPush(device.deviceToken, title, trimPushBody(content), summaryId);
  return { summary, hasMore, processedCount: messages.length, startTime, endTime, importantCount, spamCount };
}

async function cleanupForUser(user, store) {
  if (!AUTO_DELETE_ENABLED || user.settings?.autoDeleteEnabled === false) return { skipped: true };
  const deleteAfter = Number(user.settings?.deleteAfterDays || DELETE_AFTER_DAYS);

  if (USE_IMAP) {
    return cleanupImapMessages(store, user, deleteAfter);
  }

  const accessToken = await getFreshAccessToken(user, store);
  const keepDeletedDays = Number(user.settings?.permanentDeleteAfterDays || PERMANENT_DELETE_AFTER_DAYS);
  const cutoff = Date.now() - deleteAfter * 24 * 60 * 60 * 1000;
  const moved = [];

  const oldRead = await getReadOlderThan(accessToken, deleteAfter);
  for (const message of oldRead) {
    try {
      await moveToDeletedItems(accessToken, message.id);
      store.deletedMessages[message.id] = { userId: user.id, messageId: message.id, deletedAt: nowIso(), reason: "read_older_than_retention_days" };
      moved.push(message.id);
    } catch (err) {
      console.warn("Move read message failed", message.id, err.message);
    }
  }

  for (const record of Object.values(store.summarizedMessages).filter(r => r.userId === user.id)) {
    if (new Date(record.summarizedAt).getTime() > cutoff) continue;
    if (store.deletedMessages[record.messageId]) continue;
    try {
      await moveToDeletedItems(accessToken, record.messageId);
      store.deletedMessages[record.messageId] = { userId: user.id, messageId: record.messageId, deletedAt: nowIso(), reason: "summarized_older_than_retention_days" };
      moved.push(record.messageId);
    } catch (err) {
      console.warn("Move summarized message failed", record.messageId, err.message);
    }
  }

  const permanentCutoff = Date.now() - keepDeletedDays * 24 * 60 * 60 * 1000;
  const permanentlyDeleted = [];
  for (const record of Object.values(store.deletedMessages).filter(r => r.userId === user.id)) {
    if (new Date(record.deletedAt).getTime() > permanentCutoff) continue;
    try {
      await permanentDelete(accessToken, record.messageId);
      permanentlyDeleted.push(record.messageId);
      delete store.deletedMessages[record.messageId];
    } catch (err) {
      console.warn("Permanent delete failed", record.messageId, err.message);
    }
  }

  return { moved: moved.length, permanentlyDeleted: permanentlyDeleted.length };
}

function nextDueAt(user) {
  if (!user?.settings?.enabled) return null;
  const last = user.lastRunAt ? new Date(user.lastRunAt) : new Date(0);
  if (!user.lastRunAt) return nowIso();
  const freq = user.settings.frequency || "daily";
  if (freq === "sixHours") return new Date(last.getTime() + 6 * 60 * 60 * 1000).toISOString();
  if (freq === "monthly") {
    const next = new Date(last);
    next.setUTCMonth(next.getUTCMonth() + 1);
    return next.toISOString();
  }
  return new Date(last.getTime() + 24 * 60 * 60 * 1000).toISOString();
}

async function schedulerTick(reason = "interval") {
  if (!SCHEDULER_ENABLED) return { skipped: true, reason: "SCHEDULER_ENABLED=false" };
  if (schedulerRunning) return { skipped: true, reason: "scheduler already running" };

  schedulerRunning = true;
  const store = loadStore();
  store.scheduler = {
    ...(store.scheduler || {}),
    enabled: true,
    intervalMinutes: SCHEDULER_INTERVAL_MINUTES,
    running: true,
    lastTickAt: nowIso(),
    lastReason: reason
  };

  const runs = [];
  try {
    if (USE_IMAP) ensureDefaultImapUser(store);

    for (const user of Object.values(store.users)) {
      const device = store.devices[user.deviceId] || Object.values(store.devices).find(d => d.userId === user.id) || {};
      try {
        if (isDue(user)) {
          const runOptions = {
            mode: "scheduled",
            ...frequencyRunOptions(user.settings?.frequency),
            includeJunkUnread: user.settings?.includeJunkUnread !== false
          };
          const result = await runSummaryForUser(user, device, store, runOptions);
          runs.push({ userId: user.id, processed: result.processedCount, summaryId: result.summary.id, mode: "scheduled" });
          store.scheduler.lastRunAt = nowIso();
          store.scheduler.lastRunUserId = user.id;
          store.scheduler.lastRunProcessed = result.processedCount;
        } else {
          runs.push({ userId: user.id, skipped: true, reason: "not due", nextDueAt: nextDueAt(user) });
        }
        await cleanupForUser(user, store);
      } catch (err) {
        const message = err?.message || String(err);
        console.error("Scheduled job failed", user.id, message);
        runs.push({ userId: user.id, error: message });
        store.scheduler.lastError = message;
        store.scheduler.lastErrorAt = nowIso();
      }
    }

    store.scheduler.running = false;
    store.scheduler.lastCompletedAt = nowIso();
    store.scheduler.lastRuns = runs.slice(-10);
    saveStore(store);
    return { scheduler: store.scheduler, runs };
  } finally {
    schedulerRunning = false;
  }
}

if (SCHEDULER_ENABLED) {
  setInterval(() => schedulerTick("interval").catch(err => console.error("Scheduler tick failed", err)), SCHEDULER_INTERVAL_MINUTES * 60 * 1000);
  setTimeout(() => schedulerTick("startup").catch(err => console.error("Scheduler startup failed", err)), 2000);
}

app.listen(PORT, () => {
  console.log(`Outlook AI Summary backend running on port ${PORT}`);
  console.log(`Scheduler ${SCHEDULER_ENABLED ? "enabled" : "disabled"}; interval ${SCHEDULER_INTERVAL_MINUTES} min`);
});
