function getAIConfig() {
  const apiKey = process.env.AI_API_KEY;
  const baseUrl = process.env.AI_BASE_URL;
  const model = process.env.AI_MODEL;

  if (!apiKey) throw new Error("Missing AI_API_KEY in Render environment variables");
  if (!baseUrl) throw new Error("Missing AI_BASE_URL in Render environment variables");
  if (!model) throw new Error("Missing AI_MODEL in Render environment variables");

  return { apiKey, baseUrl, model };
}

async function callChatCompletions(messages, options = {}) {
  const { apiKey, baseUrl, model } = getAIConfig();
  const res = await fetch(baseUrl, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      model,
      messages,
      temperature: options.temperature ?? 0.2,
      max_tokens: options.max_tokens
    })
  });

  const text = await res.text();
  if (!res.ok) throw new Error(`AI request failed: ${res.status} ${text}`);

  let data;
  try {
    data = JSON.parse(text);
  } catch {
    throw new Error("AI response is not valid JSON");
  }

  return data.choices?.[0]?.message?.content?.trim() || "";
}

export async function testAIModel() {
  const reply = await callChatCompletions([
    { role: "system", content: "You are a connectivity checker. Reply with OK only." },
    { role: "user", content: "Reply OK." }
  ], { temperature: 0, max_tokens: 8 });

  return { ok: true, reply: reply || "OK" };
}

export async function summarizeMessages(messages) {
  const compactMessages = messages.map((m, index) => ({
    index: index + 1,
    id: m.id,
    folder: m.sourceFolder === "junkemail" ? "垃圾邮件" : "收件箱",
    subject: m.subject || "无标题",
    from: m.from?.emailAddress?.name || m.from?.emailAddress?.address || "未知发件人",
    email: m.from?.emailAddress?.address || "",
    receivedDateTime: m.receivedDateTime,
    forwardedFromOutlook: Boolean(m.originalForwarded),
    originalHeaders: m.originalHeaders || undefined,
    preview: m.bodyPreview || ""
  }));

  const prompt = `你是一个邮件助理。请用中文总结下面的邮件。部分邮件可能是 Outlook 转发到 QQ 邮箱后读取到的，请优先使用 originalHeaders 里的原始发件人和主题。要求：\n` +
    `1. 先给总览：重要邮件数量、普通邮件数量、垃圾邮件数量。\n` +
    `2. 列出最重要的 3-8 封邮件，每封包含：标题、发件人、重点、建议操作。\n` +
    `3. 垃圾邮件要单独标注，不要当成可信信息。\n` +
    `4. 如果邮件是转发邮件，要说明原始发件人，不要把转发邮箱误认为发件人。\n` +
    `5. 不要编造邮件里没有的信息。\n` +
    `6. 输出简洁，适合手机通知点开后阅读。\n\n` +
    JSON.stringify(compactMessages, null, 2);

  const content = await callChatCompletions([
    { role: "system", content: "你是严谨、简洁的中文邮件总结助手。" },
    { role: "user", content: prompt }
  ], { temperature: 0.2 });

  return content || "没有生成总结。";
}
