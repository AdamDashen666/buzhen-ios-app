# FileZipPad v1

一个本地 iPadOS SwiftUI 压缩工具 Xcode Project。

## 功能

- 选择多个文件或文件夹
- 自动统计压缩前大小
- 自动切换 KB / MB / GB / TB 等单位
- 多种压缩选项：
  - 仅打包，不压缩
  - 最快压缩
  - 平衡压缩
  - 较小体积
  - 最小体积
  - 智能最小体积
- 显示预估压缩后大小
- 压缩完成后显示实际压缩包大小和节省比例
- 输出标准 `.zip` 文件
- 压缩完成后可选择保存位置：iPad 本地、iCloud Drive 或其他文件 App 位置

## 工程信息

- App：FileZipPad
- UI：SwiftUI
- 平台：iPadOS
- 最低系统：iPadOS 16.0
- 压缩格式：ZIP Store / ZIP Deflate
- 原生依赖：libz，不需要第三方库

## 注意

- 视频、照片、音乐、PDF、已有 ZIP/RAR/7z 等文件本来就已经压缩过，继续压缩通常不会明显变小。
- “智能最小体积”会自动跳过这些难压缩文件，避免浪费时间。
- 工程实现了 ZIP64 元数据，支持大文件结构；但实际速度和内存表现仍取决于 iPad 型号、文件来源和文件 App 权限。
