import SwiftUI

struct ContentView: View {
    @StateObject private var viewModel = AppViewModel()
    @State private var showingPicker = false
    @State private var showingExporter = false

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 18) {
                    summaryCard
                    optionsCard
                    selectedItemsCard
                    actionCard
                }
                .padding()
                .frame(maxWidth: 900)
                .frame(maxWidth: .infinity)
            }
            .navigationTitle("iPad 压缩工具")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("清空") { viewModel.clearAll() }
                        .disabled(viewModel.isCompressing || viewModel.pickedInputs.isEmpty)
                }
            }
            .sheet(isPresented: $showingPicker) {
                FileAndFolderPicker { urls in
                    viewModel.addPickedURLs(urls)
                }
            }
            .sheet(isPresented: $showingExporter) {
                if let outputURL = viewModel.outputURL {
                    ExportDocumentPicker(url: outputURL)
                }
            }
            .alert("错误", isPresented: Binding(
                get: { viewModel.errorMessage != nil },
                set: { if !$0 { viewModel.errorMessage = nil } }
            )) {
                Button("好", role: .cancel) { viewModel.errorMessage = nil }
            } message: {
                Text(viewModel.errorMessage ?? "未知错误")
            }
        }
    }

    private var summaryCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                Label("压缩概览", systemImage: "archivebox")
                    .font(.title2.bold())
                Spacer()
                Text(viewModel.statusText)
                    .font(.callout)
                    .foregroundStyle(.secondary)
            }

            LazyVGrid(columns: [GridItem(.adaptive(minimum: 180), spacing: 12)], spacing: 12) {
                MetricBox(title: "已选项目", value: "\(viewModel.pickedInputs.count)", icon: "doc.on.doc")
                MetricBox(title: "压缩前大小", value: ByteSizeFormatter.string(viewModel.originalSize), icon: "internaldrive")
                MetricBox(title: "预估压缩后", value: ByteSizeFormatter.string(viewModel.estimatedCompressedSize), icon: "sparkles")
                MetricBox(
                    title: "实际压缩后",
                    value: viewModel.compressedSize.map { ByteSizeFormatter.string($0) } ?? "未生成",
                    icon: "checkmark.seal"
                )
            }

            if let compressed = viewModel.compressedSize, viewModel.originalSize > 0 {
                Text("实际节省：\(ByteSizeFormatter.ratioText(original: viewModel.originalSize, compressed: compressed))")
                    .font(.headline)
            }

            if viewModel.isScanning || viewModel.isCompressing {
                ProgressView(value: viewModel.progress)
                    .progressViewStyle(.linear)
            }
        }
        .cardStyle()
    }

    private var optionsCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            Label("压缩选项", systemImage: "slider.horizontal.3")
                .font(.title2.bold())

            TextField("压缩包名称", text: $viewModel.archiveName)
                .textFieldStyle(.roundedBorder)
                .textInputAutocapitalization(.never)

            Picker("压缩模式", selection: $viewModel.preset) {
                ForEach(CompressionPreset.allCases) { preset in
                    Text(preset.title).tag(preset)
                }
            }
            .pickerStyle(.inline)

            Text(viewModel.preset.subtitle)
                .font(.callout)
                .foregroundStyle(.secondary)

            Toggle("保留顶层文件夹结构", isOn: $viewModel.keepTopFolders)
            Toggle("包含隐藏文件", isOn: $viewModel.includeHiddenFiles)

            VStack(alignment: .leading, spacing: 6) {
                Text("说明")
                    .font(.headline)
                Text("输出为标准 .zip 文件；“智能最小体积”会自动跳过视频、图片、已有压缩包等很难继续压小的文件，避免浪费时间。")
                    .font(.callout)
                    .foregroundStyle(.secondary)
            }
        }
        .disabled(viewModel.isCompressing)
        .cardStyle()
    }

    private var selectedItemsCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                Label("已选择", systemImage: "folder")
                    .font(.title2.bold())
                Spacer()
                Button {
                    showingPicker = true
                } label: {
                    Label("选择文件/文件夹", systemImage: "plus")
                }
                .buttonStyle(.borderedProminent)
                .disabled(viewModel.isScanning || viewModel.isCompressing)
            }

            if viewModel.pickedInputs.isEmpty {
                VStack(spacing: 10) {
                    Image(systemName: "tray")
                        .font(.system(size: 44))
                        .foregroundStyle(.secondary)
                    Text("还没有选择文件")
                        .font(.headline)
                    Text("可以一次选择多个文件，也可以选择整个文件夹。")
                        .font(.callout)
                        .foregroundStyle(.secondary)
                }
                .frame(maxWidth: .infinity, minHeight: 180)
            } else {
                VStack(spacing: 8) {
                    ForEach(viewModel.pickedInputs) { item in
                        HStack(spacing: 12) {
                            Image(systemName: item.isDirectory ? "folder.fill" : "doc.fill")
                                .foregroundStyle(item.isDirectory ? .blue : .secondary)
                                .frame(width: 24)
                            VStack(alignment: .leading, spacing: 2) {
                                Text(item.displayName)
                                    .font(.headline)
                                    .lineLimit(1)
                                Text(item.isDirectory ? "文件夹" : item.url.pathExtension.uppercased().isEmpty ? "文件" : item.url.pathExtension.uppercased())
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                            Spacer()
                            Text(ByteSizeFormatter.string(item.size))
                                .font(.callout.monospacedDigit())
                                .foregroundStyle(.secondary)
                        }
                        .padding(10)
                        .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 12))
                    }
                }
            }
        }
        .cardStyle()
    }

    private var actionCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Button {
                viewModel.createArchive()
            } label: {
                Label(viewModel.isCompressing ? "正在压缩…" : "开始压缩", systemImage: "archivebox.fill")
                    .frame(maxWidth: .infinity)
            }
            .buttonStyle(.borderedProminent)
            .controlSize(.large)
            .disabled(viewModel.pickedInputs.isEmpty || viewModel.isScanning || viewModel.isCompressing)

            Button {
                showingExporter = true
            } label: {
                Label("选择保存位置", systemImage: "square.and.arrow.down")
                    .frame(maxWidth: .infinity)
            }
            .buttonStyle(.bordered)
            .controlSize(.large)
            .disabled(viewModel.outputURL == nil || viewModel.isCompressing)

            Text("压缩完成后点“选择保存位置”，系统文件选择器会让你保存到 iPad 本地、iCloud Drive 或其他文件 App 支持的位置。")
                .font(.footnote)
                .foregroundStyle(.secondary)
        }
        .cardStyle()
    }
}

private struct MetricBox: View {
    let title: String
    let value: String
    let icon: String

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Image(systemName: icon)
                .font(.title2)
            Text(title)
                .font(.caption)
                .foregroundStyle(.secondary)
            Text(value)
                .font(.headline.monospacedDigit())
                .minimumScaleFactor(0.7)
                .lineLimit(1)
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 16))
    }
}

private extension View {
    func cardStyle() -> some View {
        self
            .padding()
            .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 22, style: .continuous)
                    .strokeBorder(.quaternary, lineWidth: 1)
            )
    }
}

#Preview {
    ContentView()
}
