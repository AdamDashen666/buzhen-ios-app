#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface DeflateResult : NSObject
@property (nonatomic, assign) uint64_t uncompressedSize;
@property (nonatomic, assign) uint64_t compressedSize;
@property (nonatomic, assign) uint32_t crc32;
@end

@interface CompressionCodec : NSObject
+ (nullable DeflateResult *)deflateRawFileAtURL:(NSURL *)inputURL
                                      toURL:(NSURL *)outputURL
                                      level:(int32_t)level;

+ (nullable DeflateResult *)scanFileAtURL:(NSURL *)inputURL;
@end

NS_ASSUME_NONNULL_END
