#import "CompressionCodec.h"
#import <zlib.h>

@implementation DeflateResult
@end

@implementation CompressionCodec

+ (nullable DeflateResult *)scanFileAtURL:(NSURL *)inputURL {
    NSInputStream *input = [NSInputStream inputStreamWithURL:inputURL];
    if (!input) { return nil; }
    [input open];
    if (input.streamStatus == NSStreamStatusError) { return nil; }

    const NSUInteger chunkSize = 256 * 1024;
    uint8_t *buffer = malloc(chunkSize);
    if (!buffer) {
        [input close];
        return nil;
    }

    uint64_t total = 0;
    uint32_t crc = (uint32_t)crc32(0L, Z_NULL, 0);

    while (true) {
        NSInteger read = [input read:buffer maxLength:chunkSize];
        if (read < 0) {
            free(buffer);
            [input close];
            return nil;
        }
        if (read == 0) { break; }
        crc = (uint32_t)crc32(crc, buffer, (uInt)read);
        total += (uint64_t)read;
    }

    free(buffer);
    [input close];

    DeflateResult *result = [DeflateResult new];
    result.uncompressedSize = total;
    result.compressedSize = total;
    result.crc32 = crc;
    return result;
}

+ (nullable DeflateResult *)deflateRawFileAtURL:(NSURL *)inputURL
                                      toURL:(NSURL *)outputURL
                                      level:(int32_t)level {
    NSInputStream *input = [NSInputStream inputStreamWithURL:inputURL];
    NSOutputStream *output = [NSOutputStream outputStreamWithURL:outputURL append:NO];
    if (!input || !output) { return nil; }

    [input open];
    [output open];
    if (input.streamStatus == NSStreamStatusError || output.streamStatus == NSStreamStatusError) {
        [input close];
        [output close];
        return nil;
    }

    const NSUInteger chunkSize = 256 * 1024;
    uint8_t *inBuffer = malloc(chunkSize);
    uint8_t *outBuffer = malloc(chunkSize);
    if (!inBuffer || !outBuffer) {
        if (inBuffer) free(inBuffer);
        if (outBuffer) free(outBuffer);
        [input close];
        [output close];
        return nil;
    }

    z_stream stream;
    memset(&stream, 0, sizeof(stream));
    int initStatus = deflateInit2(&stream, level, Z_DEFLATED, -MAX_WBITS, 8, Z_DEFAULT_STRATEGY);
    if (initStatus != Z_OK) {
        free(inBuffer);
        free(outBuffer);
        [input close];
        [output close];
        return nil;
    }

    uint64_t totalIn = 0;
    uint64_t totalOut = 0;
    uint32_t crc = (uint32_t)crc32(0L, Z_NULL, 0);
    BOOL success = YES;
    BOOL reachedEOF = NO;

    while (!reachedEOF && success) {
        NSInteger read = [input read:inBuffer maxLength:chunkSize];
        if (read < 0) {
            success = NO;
            break;
        }

        reachedEOF = (read == 0);
        if (read > 0) {
            crc = (uint32_t)crc32(crc, inBuffer, (uInt)read);
            totalIn += (uint64_t)read;
        }

        stream.next_in = inBuffer;
        stream.avail_in = (uInt)read;
        int flush = reachedEOF ? Z_FINISH : Z_NO_FLUSH;

        do {
            stream.next_out = outBuffer;
            stream.avail_out = (uInt)chunkSize;
            int status = deflate(&stream, flush);
            if (status == Z_STREAM_ERROR) {
                success = NO;
                break;
            }

            NSUInteger produced = chunkSize - stream.avail_out;
            if (produced > 0) {
                NSInteger written = [output write:outBuffer maxLength:produced];
                if (written != (NSInteger)produced) {
                    success = NO;
                    break;
                }
                totalOut += (uint64_t)produced;
            }

            if (status == Z_STREAM_END) { break; }
        } while (stream.avail_out == 0 || stream.avail_in > 0 || (reachedEOF && success));
    }

    deflateEnd(&stream);
    free(inBuffer);
    free(outBuffer);
    [input close];
    [output close];

    if (!success) { return nil; }

    DeflateResult *result = [DeflateResult new];
    result.uncompressedSize = totalIn;
    result.compressedSize = totalOut;
    result.crc32 = crc;
    return result;
}

@end
