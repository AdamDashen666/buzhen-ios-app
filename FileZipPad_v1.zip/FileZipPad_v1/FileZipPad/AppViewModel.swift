import Foundation
import SwiftUI

@MainActor
final class AppViewModel: ObservableObject {
    @Published var pickedInputs: [PickedInput] = []
    @Published var preset: CompressionPreset = .balanced
    @Published var includeHiddenFiles = false
    @Published var keepTopFolders = true
    @Published var archiveName = "CompressedArchive"

    @Published var isScanning = false
    @Published var isCompressing = false
    @Published var progress: Double = 0
    @Published var statusText = "未选择文件"
    @Published var errorMessage: String?

    @Published var outputURL: URL?
    @Published var compressedSize: UInt64?

    var originalSize: UInt64 {
        pickedInputs.reduce(0) { $0 + $1.size }
    }

    var estimatedCompressedSize: UInt64 {
        guard originalSize > 0 else { return 0 }
        var total = 0.0
        for item in pickedInputs {
            if item.isDirectory {
                total += Double(item.size) * preset.estimatedRatioForGenericFile
            } else {
                total += Double(item.size) * FileKindHeuristics.estimatedRatio(for: item.url, preset: preset)
            }
        }
        return UInt64(max(0, total.rounded()))
    }

    func clearAll() {
        pickedInputs.removeAll()
        outputURL = nil
        compressedSize = nil
        progress = 0
        statusText = "未选择文件"
        errorMessage = nil
    }

    func addPickedURLs(_ urls: [URL]) {
        Task {
            await scan(urls: urls)
        }
    }

    private func scan(urls: [URL]) async {
        isScanning = true
        statusText = "正在统计原始大小…"
        errorMessage = nil
        outputURL = nil
        compressedSize = nil

        let result = await Task.detached(priority: .userInitiated) { [includeHiddenFiles] in
            let scanner = FileScanner(includeHiddenFiles: includeHiddenFiles)
            return scanner.scanInputs(urls: urls)
        }.value

        switch result {
        case .success(let inputs):
            let merged = mergeExistingAndNew(existing: pickedInputs, new: inputs)
            pickedInputs = merged
            statusText = merged.isEmpty ? "未选择文件" : "已选择 \(merged.count) 个项目"
        case .failure(let error):
            errorMessage = error.localizedDescription
            statusText = "扫描失败"
        }
        isScanning = false
    }

    func createArchive() {
        guard !pickedInputs.isEmpty else { return }
        isCompressing = true
        progress = 0
        outputURL = nil
        compressedSize = nil
        errorMessage = nil
        statusText = "正在准备压缩…"

        let selectedInputs = pickedInputs
        let selectedPreset = preset
        let selectedKeepTopFolders = keepTopFolders
        let selectedIncludeHiddenFiles = includeHiddenFiles
        let selectedName = sanitizedArchiveName(archiveName)

        Task.detached(priority: .userInitiated) {
            let accessTokens = selectedInputs.map { input in
                (input.url, input.url.startAccessingSecurityScopedResource())
            }
            defer {
                for (url, didAccess) in accessTokens where didAccess {
                    url.stopAccessingSecurityScopedResource()
                }
            }

            do {
                let tempFolder = FileManager.default.temporaryDirectory.appendingPathComponent("FileZipPad", isDirectory: true)
                try FileManager.default.createDirectory(at: tempFolder, withIntermediateDirectories: true)
                let output = tempFolder.appendingPathComponent("\(selectedName)-\(Int(Date().timeIntervalSince1970)).zip")
                if FileManager.default.fileExists(atPath: output.path) {
                    try FileManager.default.removeItem(at: output)
                }

                let collector = FileCollector(includeHiddenFiles: selectedIncludeHiddenFiles, keepTopFolders: selectedKeepTopFolders)
                let entries = try collector.collect(from: selectedInputs.map { $0.url })

                let writer = ZipArchiveWriter()
                try writer.writeZip(
                    entries: entries,
                    to: output,
                    preset: selectedPreset,
                    progress: { current, total, path in
                        Task { @MainActor in
                            self.progress = total == 0 ? 0 : Double(current) / Double(total)
                            self.statusText = "正在压缩：\(path)"
                        }
                    }
                )

                let size = try FileManager.default.attributesOfItem(atPath: output.path)[.size] as? NSNumber
                await MainActor.run {
                    self.outputURL = output
                    self.compressedSize = size?.uint64Value ?? 0
                    self.progress = 1
                    self.statusText = "压缩完成"
                    self.isCompressing = false
                }
            } catch {
                await MainActor.run {
                    self.errorMessage = error.localizedDescription
                    self.statusText = "压缩失败"
                    self.isCompressing = false
                }
            }
        }
    }

    private func sanitizedArchiveName(_ name: String) -> String {
        let trimmed = name.trimmingCharacters(in: .whitespacesAndNewlines)
        let base = trimmed.isEmpty ? "CompressedArchive" : trimmed
        let invalid = CharacterSet(charactersIn: "/\\?%*|\"<>:")
        return base.components(separatedBy: invalid).joined(separator: "-")
    }
}

private func mergeExistingAndNew(existing: [PickedInput], new: [PickedInput]) -> [PickedInput] {
    var seen = Set(existing.map { $0.url.standardizedFileURL.path })
    var merged = existing
    for item in new {
        let key = item.url.standardizedFileURL.path
        if !seen.contains(key) {
            merged.append(item)
            seen.insert(key)
        }
    }
    return merged
}

