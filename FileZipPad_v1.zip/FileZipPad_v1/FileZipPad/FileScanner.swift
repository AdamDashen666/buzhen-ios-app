import Foundation

struct FileScanner {
    let includeHiddenFiles: Bool

    func scanInputs(urls: [URL]) -> Result<[PickedInput], Error> {
        do {
            var inputs: [PickedInput] = []
            for url in urls {
                let access = url.startAccessingSecurityScopedResource()
                defer {
                    if access { url.stopAccessingSecurityScopedResource() }
                }

                let values = try url.resourceValues(forKeys: [.isDirectoryKey, .isHiddenKey, .fileSizeKey, .totalFileAllocatedSizeKey])
                if values.isHidden == true && !includeHiddenFiles { continue }
                let isDirectory = values.isDirectory == true
                let size = try sizeOfItem(at: url, isDirectory: isDirectory)
                inputs.append(PickedInput(url: url, displayName: url.lastPathComponent, isDirectory: isDirectory, size: size))
            }
            return .success(inputs)
        } catch {
            return .failure(error)
        }
    }

    private func sizeOfItem(at url: URL, isDirectory: Bool) throws -> UInt64 {
        if !isDirectory {
            let attributes = try FileManager.default.attributesOfItem(atPath: url.path)
            return (attributes[.size] as? NSNumber)?.uint64Value ?? 0
        }

        var total: UInt64 = 0
        let options: FileManager.DirectoryEnumerationOptions = includeHiddenFiles ? [] : [.skipsHiddenFiles]
        let keys: [URLResourceKey] = [.isRegularFileKey, .fileSizeKey, .totalFileAllocatedSizeKey]
        let enumerator = FileManager.default.enumerator(at: url, includingPropertiesForKeys: keys, options: options)
        while let fileURL = enumerator?.nextObject() as? URL {
            let values = try? fileURL.resourceValues(forKeys: Set(keys))
            guard values?.isRegularFile == true else { continue }
            if let allocated = values?.totalFileAllocatedSize, allocated > 0 {
                total += UInt64(allocated)
            } else if let logical = values?.fileSize, logical > 0 {
                total += UInt64(logical)
            } else if let attributes = try? FileManager.default.attributesOfItem(atPath: fileURL.path),
                      let size = attributes[.size] as? NSNumber {
                total += size.uint64Value
            }
        }
        return total
    }
}

struct FileCollector {
    let includeHiddenFiles: Bool
    let keepTopFolders: Bool

    func collect(from urls: [URL]) throws -> [ArchiveEntryCandidate] {
        var entries: [ArchiveEntryCandidate] = []
        var usedPaths = Set<String>()

        for url in urls {
            let access = url.startAccessingSecurityScopedResource()
            defer {
                if access { url.stopAccessingSecurityScopedResource() }
            }

            let values = try url.resourceValues(forKeys: [.isDirectoryKey, .contentModificationDateKey, .isHiddenKey])
            if values.isHidden == true && !includeHiddenFiles { continue }

            if values.isDirectory == true {
                let topName = sanitizedPathComponent(url.lastPathComponent)
                let rootPrefix: String
                if keepTopFolders {
                    let archivePath = uniquePath(topName + "/", used: &usedPaths)
                    entries.append(ArchiveEntryCandidate(sourceURL: url, archivePath: archivePath, isDirectory: true, uncompressedSize: 0, modificationDate: values.contentModificationDate))
                    rootPrefix = String(archivePath.dropLast())
                } else {
                    rootPrefix = ""
                }
                try collectDirectory(url, rootPrefix: rootPrefix, entries: &entries, usedPaths: &usedPaths)
            } else {
                let archivePath = uniquePath(sanitizedPathComponent(url.lastPathComponent), used: &usedPaths)
                let size = try logicalFileSize(url)
                entries.append(ArchiveEntryCandidate(sourceURL: url, archivePath: archivePath, isDirectory: false, uncompressedSize: size, modificationDate: values.contentModificationDate))
            }
        }

        return entries.sorted { lhs, rhs in
            if lhs.isDirectory != rhs.isDirectory { return lhs.isDirectory && !rhs.isDirectory }
            return lhs.archivePath.localizedStandardCompare(rhs.archivePath) == .orderedAscending
        }
    }

    private func collectDirectory(_ rootURL: URL, rootPrefix: String, entries: inout [ArchiveEntryCandidate], usedPaths: inout Set<String>) throws {
        let options: FileManager.DirectoryEnumerationOptions = includeHiddenFiles ? [] : [.skipsHiddenFiles]
        let keys: [URLResourceKey] = [.isDirectoryKey, .isRegularFileKey, .fileSizeKey, .contentModificationDateKey, .isHiddenKey]
        let enumerator = FileManager.default.enumerator(at: rootURL, includingPropertiesForKeys: keys, options: options)

        while let itemURL = enumerator?.nextObject() as? URL {
            let values = try itemURL.resourceValues(forKeys: Set(keys))
            if values.isHidden == true && !includeHiddenFiles { continue }

            let relative = relativePath(from: rootURL, to: itemURL)
            let cleanedRelative = relative.split(separator: "/").map { sanitizedPathComponent(String($0)) }.joined(separator: "/")
            let base = rootPrefix.isEmpty ? cleanedRelative : "\(rootPrefix)/\(cleanedRelative)"

            if values.isDirectory == true {
                let archivePath = uniquePath(base + "/", used: &usedPaths)
                entries.append(ArchiveEntryCandidate(sourceURL: itemURL, archivePath: archivePath, isDirectory: true, uncompressedSize: 0, modificationDate: values.contentModificationDate))
            } else if values.isRegularFile == true {
                let archivePath = uniquePath(base, used: &usedPaths)
                let size = try logicalFileSize(itemURL)
                entries.append(ArchiveEntryCandidate(sourceURL: itemURL, archivePath: archivePath, isDirectory: false, uncompressedSize: size, modificationDate: values.contentModificationDate))
            }
        }
    }

    private func relativePath(from root: URL, to child: URL) -> String {
        let rootPath = root.standardizedFileURL.path
        let childPath = child.standardizedFileURL.path
        if childPath.hasPrefix(rootPath) {
            let index = childPath.index(childPath.startIndex, offsetBy: rootPath.count)
            return String(childPath[index...]).trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        }
        return child.lastPathComponent
    }

    private func logicalFileSize(_ url: URL) throws -> UInt64 {
        let attributes = try FileManager.default.attributesOfItem(atPath: url.path)
        return (attributes[.size] as? NSNumber)?.uint64Value ?? 0
    }

    private func sanitizedPathComponent(_ component: String) -> String {
        let invalid = CharacterSet(charactersIn: ":\\")
        let cleaned = component.components(separatedBy: invalid).joined(separator: "-")
        return cleaned.isEmpty ? "Untitled" : cleaned
    }

    private func uniquePath(_ path: String, used: inout Set<String>) -> String {
        if !used.contains(path) {
            used.insert(path)
            return path
        }

        let isDirectory = path.hasSuffix("/")
        let trimmed = isDirectory ? String(path.dropLast()) : path
        let ns = trimmed as NSString
        let dir = ns.deletingLastPathComponent
        let base = ns.deletingPathExtension
        let ext = ns.pathExtension
        let leafBase = (base as NSString).lastPathComponent

        var counter = 2
        while true {
            let suffix = ext.isEmpty ? "_\(counter)" : "_\(counter).\(ext)"
            let fileName = "\(leafBase)\(suffix)"
            let candidateBase = dir.isEmpty || dir == "." ? fileName : "\(dir)/\(fileName)"
            let candidate = isDirectory ? candidateBase + "/" : candidateBase
            if !used.contains(candidate) {
                used.insert(candidate)
                return candidate
            }
            counter += 1
        }
    }
}
