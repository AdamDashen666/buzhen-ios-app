import SwiftUI

@main
struct FileZipPadApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
