import Foundation

enum ZipArchiveError: LocalizedError {
    case cannotOpenOutput
    case fileNameTooLong(String)
    case codecFailed(String)

    var errorDescription: String? {
        switch self {
        case .cannotOpenOutput:
            return "无法创建压缩文件。"
        case .fileNameTooLong(let path):
            return "文件名过长，ZIP 不支持：\(path)"
        case .codecFailed(let path):
            return "压缩失败：\(path)"
        }
    }
}

final class ZipArchiveWriter {
    typealias ProgressHandler = (_ current: Int, _ total: Int, _ path: String) -> Void

    func writeZip(entries: [ArchiveEntryCandidate], to outputURL: URL, preset: CompressionPreset, progress: ProgressHandler?) throws {
        _ = FileManager.default.createFile(atPath: outputURL.path, contents: nil)
        guard let handle = try? FileHandle(forWritingTo: outputURL) else {
            throw ZipArchiveError.cannotOpenOutput
        }
        defer { try? handle.close() }

        var writer = CountingFileWriter(handle: handle)
        var centralEntries: [CentralDirectoryEntry] = []
        let tempFolder = FileManager.default.temporaryDirectory.appendingPathComponent("FileZipPadWorking", isDirectory: true)
        try FileManager.default.createDirectory(at: tempFolder, withIntermediateDirectories: true)

        for (index, entry) in entries.enumerated() {
            progress?(index + 1, entries.count, entry.archivePath)
            if entry.isDirectory {
                let metadata = ZipEntryMetadata(
                    archivePath: entry.archivePath.hasSuffix("/") ? entry.archivePath : entry.archivePath + "/",
                    method: 0,
                    crc32: 0,
                    compressedSize: 0,
                    uncompressedSize: 0,
                    modificationDate: entry.modificationDate,
                    externalAttributes: 0x10
                )
                let offset = writer.offset
                try writeLocalHeader(metadata, writer: &writer, forceZip64: false)
                centralEntries.append(CentralDirectoryEntry(metadata: metadata, localHeaderOffset: offset))
                continue
            }

            let storeOnly = FileKindHeuristics.shouldStoreWithoutDeflate(entry.sourceURL, preset: preset)
            if storeOnly {
                let scan = try scanFile(entry.sourceURL)
                let metadata = ZipEntryMetadata(
                    archivePath: entry.archivePath,
                    method: 0,
                    crc32: scan.crc32,
                    compressedSize: scan.uncompressedSize,
                    uncompressedSize: scan.uncompressedSize,
                    modificationDate: entry.modificationDate,
                    externalAttributes: 0
                )
                let offset = writer.offset
                try writeLocalHeader(metadata, writer: &writer, forceZip64: needsZip64(metadata, offset: offset))
                try writer.copyFile(from: entry.sourceURL)
                centralEntries.append(CentralDirectoryEntry(metadata: metadata, localHeaderOffset: offset))
            } else {
                let tempURL = tempFolder.appendingPathComponent(UUID().uuidString + ".deflate")
                defer { try? FileManager.default.removeItem(at: tempURL) }
                guard let result = CompressionCodec.deflateRawFile(at: entry.sourceURL, to: tempURL, level: preset.zlibLevel) else {
                    throw ZipArchiveError.codecFailed(entry.archivePath)
                }

                let deflatedSize = result.compressedSize
                let useDeflated = deflatedSize < result.uncompressedSize
                let metadata = ZipEntryMetadata(
                    archivePath: entry.archivePath,
                    method: useDeflated ? 8 : 0,
                    crc32: result.crc32,
                    compressedSize: useDeflated ? deflatedSize : result.uncompressedSize,
                    uncompressedSize: result.uncompressedSize,
                    modificationDate: entry.modificationDate,
                    externalAttributes: 0
                )
                let offset = writer.offset
                try writeLocalHeader(metadata, writer: &writer, forceZip64: needsZip64(metadata, offset: offset))
                if useDeflated {
                    try writer.copyFile(from: tempURL)
                } else {
                    try writer.copyFile(from: entry.sourceURL)
                }
                centralEntries.append(CentralDirectoryEntry(metadata: metadata, localHeaderOffset: offset))
            }
        }

        try writeCentralDirectory(centralEntries, writer: &writer)
    }

    private func scanFile(_ url: URL) throws -> DeflateResult {
        if let result = CompressionCodec.scanFile(at: url) {
            return result
        }
        throw ZipArchiveError.codecFailed(url.lastPathComponent)
    }

    private func needsZip64(_ metadata: ZipEntryMetadata, offset: UInt64) -> Bool {
        metadata.uncompressedSize > UInt64(UInt32.max) ||
        metadata.compressedSize > UInt64(UInt32.max) ||
        offset > UInt64(UInt32.max)
    }

    private func writeLocalHeader(_ metadata: ZipEntryMetadata, writer: inout CountingFileWriter, forceZip64: Bool) throws {
        let nameData = try utf8NameData(metadata.archivePath)
        let useZip64 = forceZip64 || metadata.uncompressedSize > UInt64(UInt32.max) || metadata.compressedSize > UInt64(UInt32.max)
        let extra = useZip64 ? zip64Extra(uncompressedSize: metadata.uncompressedSize, compressedSize: metadata.compressedSize, localHeaderOffset: nil) : Data()
        let dos = DosDateTime(date: metadata.modificationDate ?? Date())

        writer.writeUInt32(0x04034b50)
        writer.writeUInt16(useZip64 ? 45 : 20)
        writer.writeUInt16(0x0800) // UTF-8 file names
        writer.writeUInt16(metadata.method)
        writer.writeUInt16(dos.time)
        writer.writeUInt16(dos.date)
        writer.writeUInt32(metadata.crc32)
        writer.writeUInt32(useZip64 ? UInt32.max : UInt32(metadata.compressedSize))
        writer.writeUInt32(useZip64 ? UInt32.max : UInt32(metadata.uncompressedSize))
        writer.writeUInt16(UInt16(nameData.count))
        writer.writeUInt16(UInt16(extra.count))
        writer.write(nameData)
        writer.write(extra)
    }

    private func writeCentralDirectory(_ entries: [CentralDirectoryEntry], writer: inout CountingFileWriter) throws {
        let centralStart = writer.offset
        for entry in entries {
            let metadata = entry.metadata
            let nameData = try utf8NameData(metadata.archivePath)
            let needsSize64 = metadata.uncompressedSize > UInt64(UInt32.max) || metadata.compressedSize > UInt64(UInt32.max)
            let needsOffset64 = entry.localHeaderOffset > UInt64(UInt32.max)
            let useZip64 = needsSize64 || needsOffset64
            let extra = useZip64 ? zip64Extra(
                uncompressedSize: needsSize64 ? metadata.uncompressedSize : nil,
                compressedSize: needsSize64 ? metadata.compressedSize : nil,
                localHeaderOffset: needsOffset64 ? entry.localHeaderOffset : nil
            ) : Data()
            let dos = DosDateTime(date: metadata.modificationDate ?? Date())

            writer.writeUInt32(0x02014b50)
            writer.writeUInt16(45) // version made by
            writer.writeUInt16(useZip64 ? 45 : 20)
            writer.writeUInt16(0x0800)
            writer.writeUInt16(metadata.method)
            writer.writeUInt16(dos.time)
            writer.writeUInt16(dos.date)
            writer.writeUInt32(metadata.crc32)
            writer.writeUInt32(needsSize64 ? UInt32.max : UInt32(metadata.compressedSize))
            writer.writeUInt32(needsSize64 ? UInt32.max : UInt32(metadata.uncompressedSize))
            writer.writeUInt16(UInt16(nameData.count))
            writer.writeUInt16(UInt16(extra.count))
            writer.writeUInt16(0)
            writer.writeUInt16(0)
            writer.writeUInt16(0)
            writer.writeUInt32(metadata.externalAttributes)
            writer.writeUInt32(needsOffset64 ? UInt32.max : UInt32(entry.localHeaderOffset))
            writer.write(nameData)
            writer.write(extra)
        }
        let centralSize = writer.offset - centralStart
        let totalEntries = UInt64(entries.count)
        let hasZip64Entry = entries.contains { entry in
            entry.metadata.uncompressedSize > UInt64(UInt32.max) ||
            entry.metadata.compressedSize > UInt64(UInt32.max) ||
            entry.localHeaderOffset > UInt64(UInt32.max)
        }
        let requiresZip64End = hasZip64Entry || totalEntries > UInt64(UInt16.max) || centralStart > UInt64(UInt32.max) || centralSize > UInt64(UInt32.max)

        var zip64EndOffset: UInt64 = 0
        if requiresZip64End {
            zip64EndOffset = writer.offset
            writer.writeUInt32(0x06064b50)
            writer.writeUInt64(44)
            writer.writeUInt16(45)
            writer.writeUInt16(45)
            writer.writeUInt32(0)
            writer.writeUInt32(0)
            writer.writeUInt64(totalEntries)
            writer.writeUInt64(totalEntries)
            writer.writeUInt64(centralSize)
            writer.writeUInt64(centralStart)

            writer.writeUInt32(0x07064b50)
            writer.writeUInt32(0)
            writer.writeUInt64(zip64EndOffset)
            writer.writeUInt32(1)
        }

        writer.writeUInt32(0x06054b50)
        writer.writeUInt16(0)
        writer.writeUInt16(0)
        writer.writeUInt16(totalEntries > UInt64(UInt16.max) ? UInt16.max : UInt16(totalEntries))
        writer.writeUInt16(totalEntries > UInt64(UInt16.max) ? UInt16.max : UInt16(totalEntries))
        writer.writeUInt32(centralSize > UInt64(UInt32.max) ? UInt32.max : UInt32(centralSize))
        writer.writeUInt32(centralStart > UInt64(UInt32.max) ? UInt32.max : UInt32(centralStart))
        writer.writeUInt16(0)
    }

    private func utf8NameData(_ path: String) throws -> Data {
        guard let data = path.data(using: .utf8), data.count <= Int(UInt16.max) else {
            throw ZipArchiveError.fileNameTooLong(path)
        }
        return data
    }

    private func zip64Extra(uncompressedSize: UInt64?, compressedSize: UInt64?, localHeaderOffset: UInt64?) -> Data {
        var data = Data()
        data.appendLittleEndianUInt16(0x0001)
        let sizePosition = data.count
        data.appendLittleEndianUInt16(0)
        let start = data.count
        if let uncompressedSize { data.appendLittleEndianUInt64(uncompressedSize) }
        if let compressedSize { data.appendLittleEndianUInt64(compressedSize) }
        if let localHeaderOffset { data.appendLittleEndianUInt64(localHeaderOffset) }
        let payloadSize = UInt16(data.count - start)
        data.replaceSubrange(sizePosition..<(sizePosition + 2), with: Data(littleEndian: payloadSize))
        return data
    }
}

private struct ZipEntryMetadata {
    let archivePath: String
    let method: UInt16
    let crc32: UInt32
    let compressedSize: UInt64
    let uncompressedSize: UInt64
    let modificationDate: Date?
    let externalAttributes: UInt32
}

private struct CentralDirectoryEntry {
    let metadata: ZipEntryMetadata
    let localHeaderOffset: UInt64
}

private struct DosDateTime {
    let time: UInt16
    let date: UInt16

    init(date sourceDate: Date) {
        var calendar = Calendar(identifier: .gregorian)
        calendar.timeZone = TimeZone.current
        let components = calendar.dateComponents([.year, .month, .day, .hour, .minute, .second], from: sourceDate)
        let year = min(max((components.year ?? 1980), 1980), 2107)
        let month = min(max(components.month ?? 1, 1), 12)
        let day = min(max(components.day ?? 1, 1), 31)
        let hour = min(max(components.hour ?? 0, 0), 23)
        let minute = min(max(components.minute ?? 0, 0), 59)
        let second = min(max(components.second ?? 0, 0), 59)
        self.time = UInt16((hour << 11) | (minute << 5) | (second / 2))
        self.date = UInt16(((year - 1980) << 9) | (month << 5) | day)
    }
}

private struct CountingFileWriter {
    let handle: FileHandle
    private(set) var offset: UInt64 = 0

    mutating func write(_ data: Data) {
        handle.write(data)
        offset += UInt64(data.count)
    }

    mutating func writeUInt16(_ value: UInt16) { write(Data(littleEndian: value)) }
    mutating func writeUInt32(_ value: UInt32) { write(Data(littleEndian: value)) }
    mutating func writeUInt64(_ value: UInt64) { write(Data(littleEndian: value)) }

    mutating func copyFile(from url: URL) throws {
        let source = try FileHandle(forReadingFrom: url)
        defer { try? source.close() }
        while true {
            let data = source.readData(ofLength: 1024 * 1024)
            if data.isEmpty { break }
            write(data)
        }
    }
}

private extension Data {
    init<T: FixedWidthInteger>(littleEndian value: T) {
        var little = value.littleEndian
        self = Swift.withUnsafeBytes(of: &little) { Data($0) }
    }

    mutating func appendLittleEndianUInt16(_ value: UInt16) { append(Data(littleEndian: value)) }
    mutating func appendLittleEndianUInt64(_ value: UInt64) { append(Data(littleEndian: value)) }
}
