import Foundation

enum CompressionPreset: String, CaseIterable, Identifiable {
    case store
    case fastest
    case balanced
    case smaller
    case smallest
    case smartSmallest

    var id: String { rawValue }

    var title: String {
        switch self {
        case .store: return "仅打包，不压缩"
        case .fastest: return "最快压缩"
        case .balanced: return "平衡压缩"
        case .smaller: return "较小体积"
        case .smallest: return "最小体积"
        case .smartSmallest: return "智能最小体积"
        }
    }

    var subtitle: String {
        switch self {
        case .store: return "速度最快，体积基本不变，适合已压缩文件"
        case .fastest: return "Deflate 1，速度优先"
        case .balanced: return "Deflate 5，速度和体积平衡"
        case .smaller: return "Deflate 7，更小但更慢"
        case .smallest: return "Deflate 9，尽量压小"
        case .smartSmallest: return "Deflate 9，并自动跳过视频/图片/压缩包等难压缩文件"
        }
    }

    var zlibLevel: Int32 {
        switch self {
        case .store: return 0
        case .fastest: return 1
        case .balanced: return 5
        case .smaller: return 7
        case .smallest, .smartSmallest: return 9
        }
    }

    var usesCompression: Bool { self != .store }

    var skipsAlreadyCompressed: Bool { self == .smartSmallest }

    var estimatedRatioForGenericFile: Double {
        switch self {
        case .store: return 1.00
        case .fastest: return 0.72
        case .balanced: return 0.58
        case .smaller: return 0.50
        case .smallest: return 0.46
        case .smartSmallest: return 0.44
        }
    }
}

struct PickedInput: Identifiable, Hashable {
    let id = UUID()
    let url: URL
    let displayName: String
    let isDirectory: Bool
    let size: UInt64
}

struct ArchiveEntryCandidate: Hashable {
    let sourceURL: URL
    let archivePath: String
    let isDirectory: Bool
    let uncompressedSize: UInt64
    let modificationDate: Date?
}

enum ByteSizeFormatter {
    static func string(_ bytes: UInt64) -> String {
        let formatter = ByteCountFormatter()
        formatter.allowedUnits = [.useAll]
        formatter.countStyle = .file
        formatter.includesUnit = true
        formatter.includesCount = true
        return formatter.string(fromByteCount: Int64(bytes))
    }

    static func string(_ bytes: Int64) -> String {
        string(UInt64(max(0, bytes)))
    }

    static func ratioText(original: UInt64, compressed: UInt64) -> String {
        guard original > 0 else { return "0%" }
        let percent = (1.0 - Double(compressed) / Double(original)) * 100.0
        return String(format: "%.1f%%", percent)
    }
}

enum FileKindHeuristics {
    static let alreadyCompressedExtensions: Set<String> = [
        "zip", "rar", "7z", "gz", "bz2", "xz", "lzma", "zst", "tar", "tgz",
        "jpg", "jpeg", "png", "heic", "heif", "webp", "gif", "avif",
        "mp4", "mov", "m4v", "avi", "mkv", "webm", "mp3", "m4a", "aac", "flac", "wav",
        "pdf", "docx", "xlsx", "pptx", "pages", "numbers", "key"
    ]

    static let textLikeExtensions: Set<String> = [
        "txt", "md", "json", "xml", "html", "css", "js", "ts", "swift", "py", "java", "c", "cpp", "h", "hpp",
        "csv", "log", "yaml", "yml", "plist", "rtf", "sql"
    ]

    static func estimatedRatio(for url: URL, preset: CompressionPreset) -> Double {
        let ext = url.pathExtension.lowercased()
        if preset == .store { return 1.0 }
        if alreadyCompressedExtensions.contains(ext) {
            return preset.skipsAlreadyCompressed ? 1.0 : 0.98
        }
        if textLikeExtensions.contains(ext) {
            switch preset {
            case .fastest: return 0.40
            case .balanced: return 0.28
            case .smaller: return 0.24
            case .smallest, .smartSmallest: return 0.22
            default: return 1.0
            }
        }
        return preset.estimatedRatioForGenericFile
    }

    static func shouldStoreWithoutDeflate(_ url: URL, preset: CompressionPreset) -> Bool {
        preset == .store || (preset.skipsAlreadyCompressed && alreadyCompressedExtensions.contains(url.pathExtension.lowercased()))
    }
}
