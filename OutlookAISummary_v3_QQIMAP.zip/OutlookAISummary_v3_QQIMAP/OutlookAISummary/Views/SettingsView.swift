import SwiftUI

struct SettingsView: View {
    @EnvironmentObject private var state: AppState

    var body: some View {
        ZStack {
            LiquidBackground()
            ScrollView {
                VStack(spacing: 18) {
                    SectionTitle(title: "设置", subtitle: "默认中文总结；后端从 QQ 邮箱 IMAP 读取 Outlook 转发邮件。")

                    backendCard
                    scheduleCard
                    cleanupCard
                    aiCard
                    saveCard
                }
                .padding()
                .frame(maxWidth: 860)
                .frame(maxWidth: .infinity)
            }
        }
        .navigationTitle("设置")
    }

    private var backendCard: some View {
        GlassCard {
            VStack(alignment: .leading, spacing: 12) {
                SectionTitle(title: "后端地址", subtitle: "真机不能用 localhost。推荐填部署后的 HTTPS 地址。")
                TextField("https://your-backend.example.com", text: $state.backendURL)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .keyboardType(.URL)
                    .padding(14)
                    .background(.white.opacity(0.10), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                if let warning = state.backendValidationMessage {
                    Text(warning)
                        .font(.footnote)
                        .foregroundStyle(.orange)
                        .textSelection(.enabled)
                }
            }
        }
    }

    private var scheduleCard: some View {
        GlassCard {
            VStack(alignment: .leading, spacing: 12) {
                SectionTitle(title: "总结频率", subtitle: "后端定时执行，完成后推送到 App。")
                Picker("频率", selection: $state.settings.frequency) {
                    ForEach(SummaryFrequency.allCases) { frequency in
                        Text(frequency.title).tag(frequency)
                    }
                }
                .pickerStyle(.segmented)

                Toggle("启用自动总结", isOn: $state.settings.enabled)
                    .toggleStyle(.switch)
                Toggle("包含转发邮件解析", isOn: $state.settings.includeJunkUnread)
                    .disabled(true)
                HStack {
                    Text("总结语言")
                    Spacer()
                    Text("中文")
                        .foregroundStyle(.secondary)
                }
            }
        }
    }

    private var cleanupCard: some View {
        GlassCard {
            VStack(alignment: .leading, spacing: 12) {
                SectionTitle(title: "自动清理", subtitle: "默认仅标记已读；如配置 IMAP_TRASH_MAILBOX 才会移动旧邮件。")
                Toggle("清理 QQ 邮箱已总结邮件", isOn: $state.settings.autoDeleteEnabled)
                    .toggleStyle(.switch)
                Stepper("已读/已总结超过 \(state.settings.deleteAfterDays) 天后删除", value: $state.settings.deleteAfterDays, in: 7...365)
                Stepper("删除邮件中保留 \(state.settings.permanentDeleteAfterDays) 天", value: $state.settings.permanentDeleteAfterDays, in: 1...60)

                Text("风险：开启并配置 IMAP_TRASH_MAILBOX 后会影响真实 QQ 邮箱。建议先用小号测试。")
                    .font(.footnote)
                    .foregroundStyle(.orange)
            }
        }
    }

    private var aiCard: some View {
        GlassCard {
            VStack(alignment: .leading, spacing: 12) {
                SectionTitle(title: "AI API", subtitle: "支持 OpenAI-compatible chat completions 接口。")
                SecureField("AI API Key", text: $state.settings.aiApiKey)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .padding(14)
                    .background(.white.opacity(0.10), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                TextField("接口地址", text: $state.settings.aiBaseUrl)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .keyboardType(.URL)
                    .padding(14)
                    .background(.white.opacity(0.10), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                TextField("模型", text: $state.settings.aiModel)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .padding(14)
                    .background(.white.opacity(0.10), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
            }
        }
    }

    private var saveCard: some View {
        VStack(spacing: 12) {
            Button {
                Task { await state.saveSettings() }
            } label: {
                Label("保存设置", systemImage: "checkmark.circle.fill")
            }
            .buttonStyle(PrimaryButtonStyle())

            Button {
                Task { await state.refreshAll() }
            } label: {
                Label("刷新状态", systemImage: "arrow.clockwise")
            }
            .buttonStyle(PrimaryButtonStyle())
        }
    }
}
