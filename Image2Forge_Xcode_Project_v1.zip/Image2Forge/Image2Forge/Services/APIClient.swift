import Foundation
import UIKit

final class APIClient {
    struct GenerationRequest {
        let baseURL: String
        let apiKey: String
        let model: String
        let prompt: String
        let size: String
        let quality: ImageQuality
        let sendQuality: Bool
        let preferB64JSON: Bool
        let references: [SelectedReferenceImage]
        let timeout: TimeInterval
    }

    func refreshModels(baseURL: String, apiKey: String, timeout: TimeInterval) async throws -> [APIModel] {
        let url = try endpoint(baseURL: baseURL, path: "models")
        var request = URLRequest(url: url, timeoutInterval: timeout)
        request.httpMethod = "GET"
        request.addValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")

        let (data, response) = try await URLSession.shared.data(for: request)
        try validate(data: data, response: response)
        let decoded = try JSONDecoder().decode(OpenAIModelListResponse.self, from: data)
        return decoded.data
            .map { APIModel(id: $0.id, ownedBy: $0.owned_by) }
            .sorted { scoreModel($0.id) > scoreModel($1.id) }
    }

    func generate(_ payload: GenerationRequest) async throws -> (Data, String?) {
        if payload.references.isEmpty {
            return try await generateTextToImage(payload)
        } else {
            return try await editImage(payload)
        }
    }

    private func generateTextToImage(_ payload: GenerationRequest) async throws -> (Data, String?) {
        let url = try endpoint(baseURL: payload.baseURL, path: "images/generations")
        var request = URLRequest(url: url, timeoutInterval: payload.timeout)
        request.httpMethod = "POST"
        request.addValue("Bearer \(payload.apiKey)", forHTTPHeaderField: "Authorization")
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")

        var json: [String: Any] = [
            "model": payload.model,
            "prompt": payload.prompt,
            "size": payload.size,
            "n": 1
        ]
        if payload.preferB64JSON {
            json["response_format"] = "b64_json"
        }
        if payload.sendQuality, payload.quality != .auto {
            json["quality"] = payload.quality.rawValue
        }
        request.httpBody = try JSONSerialization.data(withJSONObject: json, options: [])

        let (data, response) = try await URLSession.shared.data(for: request)
        try validate(data: data, response: response)
        return try await parseImageResponse(data)
    }

    private func editImage(_ payload: GenerationRequest) async throws -> (Data, String?) {
        let url = try endpoint(baseURL: payload.baseURL, path: "images/edits")
        let boundary = "Boundary-\(UUID().uuidString)"
        var request = URLRequest(url: url, timeoutInterval: payload.timeout)
        request.httpMethod = "POST"
        request.addValue("Bearer \(payload.apiKey)", forHTTPHeaderField: "Authorization")
        request.addValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")

        var body = Data()
        body.appendMultipartField(name: "model", value: payload.model, boundary: boundary)
        body.appendMultipartField(name: "prompt", value: payload.prompt, boundary: boundary)
        body.appendMultipartField(name: "size", value: payload.size, boundary: boundary)
        body.appendMultipartField(name: "n", value: "1", boundary: boundary)
        if payload.preferB64JSON {
            body.appendMultipartField(name: "response_format", value: "b64_json", boundary: boundary)
        }
        if payload.sendQuality, payload.quality != .auto {
            body.appendMultipartField(name: "quality", value: payload.quality.rawValue, boundary: boundary)
        }

        for (index, image) in payload.references.enumerated() {
            let fieldName = payload.references.count == 1 ? "image" : "image[]"
            let filename = image.fileName.isEmpty ? "reference_\(index + 1).png" : image.fileName
            body.appendMultipartFile(name: fieldName, filename: filename, mimeType: "image/png", fileData: normalizedPNGData(image.data), boundary: boundary)
        }

        body.append("--\(boundary)--\r\n")
        request.httpBody = body

        let (data, response) = try await URLSession.shared.data(for: request)
        try validate(data: data, response: response)
        return try await parseImageResponse(data)
    }

    private func parseImageResponse(_ data: Data) async throws -> (Data, String?) {
        let decoded = try JSONDecoder().decode(ImageAPIResponse.self, from: data)
        if let apiError = decoded.error?.message {
            throw NSError(domain: "API", code: -1, userInfo: [NSLocalizedDescriptionKey: apiError])
        }
        guard let item = decoded.data?.first else {
            throw NSError(domain: "API", code: -2, userInfo: [NSLocalizedDescriptionKey: "API 返回为空，没有图片数据。"])
        }

        if let b64 = item.b64_json, let imageData = Data(base64Encoded: b64) {
            return (imageData, item.revised_prompt)
        }

        if let urlString = item.url, let url = URL(string: urlString) {
            let (imageData, response) = try await URLSession.shared.data(from: url)
            try validate(data: imageData, response: response)
            return (imageData, item.revised_prompt)
        }

        throw NSError(domain: "API", code: -3, userInfo: [NSLocalizedDescriptionKey: "API 没有返回 url 或 b64_json。"])
    }

    private func endpoint(baseURL: String, path: String) throws -> URL {
        let cleaned = baseURL.trimmingCharacters(in: .whitespacesAndNewlines).trimmedTrailingSlash()
        guard var components = URLComponents(string: cleaned) else {
            throw NSError(domain: "API", code: -10, userInfo: [NSLocalizedDescriptionKey: "Base URL 无效。"])
        }
        let currentPath = components.path.trimmedTrailingSlash()
        components.path = currentPath + "/" + path
        guard let url = components.url else {
            throw NSError(domain: "API", code: -11, userInfo: [NSLocalizedDescriptionKey: "无法生成 API 地址。"])
        }
        return url
    }

    private func validate(data: Data, response: URLResponse) throws {
        guard let http = response as? HTTPURLResponse else { return }
        guard (200..<300).contains(http.statusCode) else {
            if let decoded = try? JSONDecoder().decode(APIErrorResponse.self, from: data) {
                throw NSError(domain: "API", code: http.statusCode, userInfo: [NSLocalizedDescriptionKey: decoded.message])
            }
            let text = String(data: data, encoding: .utf8) ?? "HTTP \(http.statusCode)"
            throw NSError(domain: "API", code: http.statusCode, userInfo: [NSLocalizedDescriptionKey: text])
        }
    }

    private func normalizedPNGData(_ data: Data) -> Data {
        guard let image = UIImage(data: data), let png = image.pngData() else { return data }
        return png
    }
}

private func scoreModel(_ id: String) -> Int {
    let lower = id.lowercased()
    if lower == "gpt-image-2-vip" { return 1000 }
    if lower == "gpt-image-2" { return 900 }
    if lower.contains("image") { return 500 }
    return 0
}

private extension Data {
    mutating func append(_ string: String) {
        append(Data(string.utf8))
    }

    mutating func appendMultipartField(name: String, value: String, boundary: String) {
        append("--\(boundary)\r\n")
        append("Content-Disposition: form-data; name=\"\(name)\"\r\n\r\n")
        append("\(value)\r\n")
    }

    mutating func appendMultipartFile(name: String, filename: String, mimeType: String, fileData: Data, boundary: String) {
        append("--\(boundary)\r\n")
        append("Content-Disposition: form-data; name=\"\(name)\"; filename=\"\(filename)\"\r\n")
        append("Content-Type: \(mimeType)\r\n\r\n")
        append(fileData)
        append("\r\n")
    }
}
