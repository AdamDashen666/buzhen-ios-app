import SwiftUI
import PhotosUI
import UniformTypeIdentifiers
import UIKit

struct GenerationView: View {
    @EnvironmentObject private var settings: AppSettings
    @EnvironmentObject private var historyStore: HistoryStore

    @State private var prompt = ""
    @State private var selectedPreset = ImageSizePreset.auto
    @State private var customSize = ""
    @State private var quality = ImageQuality.auto
    @State private var references: [SelectedReferenceImage] = []
    @State private var photoItems: [PhotosPickerItem] = []
    @State private var showingFileImporter = false
    @State private var isGenerating = false
    @State private var progressText = ""
    @State private var alertMessage: String?
    @State private var latestRecord: GeneratedImageRecord?

    private let client = APIClient()

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 18) {
                    headerCard
                    promptCard
                    referenceCard
                    outputCard
                    generateCard
                    if let latestRecord {
                        ResultCard(record: latestRecord)
                    }
                }
                .padding()
            }
            .navigationTitle("Image2Forge")
            .toolbar {
                NavigationLink(destination: SettingsView()) {
                    Label("设置", systemImage: "gearshape")
                }
            }
            .fileImporter(isPresented: $showingFileImporter, allowedContentTypes: [.image], allowsMultipleSelection: true) { result in
                Task { await importFiles(result) }
            }
            .onChange(of: photoItems.count) { _, _ in
                Task { await importPhotoItems(photoItems) }
            }
            .alert("提示", isPresented: Binding(get: { alertMessage != nil }, set: { if !$0 { alertMessage = nil } })) {
                Button("好", role: .cancel) { alertMessage = nil }
            } message: {
                Text(alertMessage ?? "")
            }
        }
    }

    private var headerCard: some View {
        CardView {
            VStack(alignment: .leading, spacing: 10) {
                HStack {
                    Image(systemName: "sparkles.rectangle.stack.fill")
                        .font(.largeTitle)
                        .foregroundStyle(.blue)
                    VStack(alignment: .leading, spacing: 4) {
                        Text("GPT Image 2 API 生成器")
                            .font(.title2.bold())
                        Text("默认 APIYI：\(settings.normalizedBaseURL())")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                            .lineLimit(1)
                    }
                    Spacer()
                }

                HStack(spacing: 8) {
                    Badge(text: settings.selectedModel.isEmpty ? "未选模型" : settings.selectedModel, systemImage: "cpu")
                    Badge(text: resolvedSize(), systemImage: "rectangle.compress.vertical")
                }
            }
        }
    }

    private var promptCard: some View {
        CardView {
            VStack(alignment: .leading, spacing: 12) {
                Label("提示词", systemImage: "text.alignleft")
                    .font(.headline)
                TextEditor(text: $prompt)
                    .frame(minHeight: 160)
                    .padding(8)
                    .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 14))
                    .overlay(alignment: .topLeading) {
                        if prompt.isEmpty {
                            Text("输入图片描述，例如：电影级真实城市街拍，雨后地面反光，清新通透，细节丰富...")
                                .foregroundStyle(.secondary)
                                .padding(.top, 16)
                                .padding(.leading, 14)
                                .allowsHitTesting(false)
                        }
                    }
            }
        }
    }

    private var referenceCard: some View {
        CardView {
            VStack(alignment: .leading, spacing: 12) {
                HStack {
                    Label("参考图片 / 上传图片", systemImage: "photo.on.rectangle")
                        .font(.headline)
                    Spacer()
                    if !references.isEmpty {
                        Button("清空") { references.removeAll() }
                            .buttonStyle(.borderless)
                    }
                }

                HStack {
                    PhotosPicker(selection: $photoItems, maxSelectionCount: 8, matching: .images) {
                        Label("从相册选择", systemImage: "photo")
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.borderedProminent)

                    Button {
                        showingFileImporter = true
                    } label: {
                        Label("从文件选择", systemImage: "folder")
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.bordered)
                }

                if references.isEmpty {
                    Text("不上传图片就是文生图；上传图片后会走图片编辑 / 参考图模式。")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                } else {
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 10) {
                            ForEach(references) { item in
                                ZStack(alignment: .topTrailing) {
                                    if let uiImage = item.uiImage {
                                        Image(uiImage: uiImage)
                                            .resizable()
                                            .scaledToFill()
                                            .frame(width: 96, height: 96)
                                            .clipShape(RoundedRectangle(cornerRadius: 14))
                                    } else {
                                        RoundedRectangle(cornerRadius: 14)
                                            .fill(.secondary.opacity(0.15))
                                            .frame(width: 96, height: 96)
                                            .overlay(Image(systemName: "photo"))
                                    }

                                    Button {
                                        references.removeAll { $0.id == item.id }
                                    } label: {
                                        Image(systemName: "xmark.circle.fill")
                                            .symbolRenderingMode(.palette)
                                            .foregroundStyle(.white, .black.opacity(0.65))
                                    }
                                    .padding(6)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    private var outputCard: some View {
        CardView {
            VStack(alignment: .leading, spacing: 14) {
                Label("输出设置", systemImage: "slider.horizontal.3")
                    .font(.headline)

                Picker("分辨率", selection: $selectedPreset) {
                    ForEach(ImageSizePreset.presets) { preset in
                        Text(preset.displayTitle).tag(preset)
                    }
                }
                .pickerStyle(.navigationLink)

                HStack {
                    Text("自定义尺寸")
                    TextField("例如 3840x2160", text: $customSize)
                        .textInputAutocapitalization(.never)
                        .keyboardType(.numbersAndPunctuation)
                        .multilineTextAlignment(.trailing)
                }

                Picker("质量参数", selection: $quality) {
                    ForEach(ImageQuality.allCases) { item in
                        Text(item.title).tag(item)
                    }
                }
                .disabled(!settings.sendQualityParameter)

                Text("当前实际 size：\(resolvedSize())。留空自定义时，自动按图片比例适配；无图片默认 3840x2160。")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
            }
        }
    }

    private var generateCard: some View {
        CardView {
            VStack(alignment: .leading, spacing: 12) {
                Button(action: { Task { await generate() } }) {
                    HStack {
                        if isGenerating { ProgressView().tint(.white) }
                        Text(isGenerating ? "生成中..." : "开始生成")
                            .fontWeight(.semibold)
                    }
                    .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)
                .controlSize(.large)
                .disabled(isGenerating || prompt.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || settings.apiKey.isEmpty || settings.selectedModel.isEmpty)

                if settings.apiKey.isEmpty {
                    Text("还没填 API Key：去设置页输入后再生成。")
                        .foregroundStyle(.orange)
                        .font(.footnote)
                }
                if !progressText.isEmpty {
                    Text(progressText)
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
            }
        }
    }

    private func resolvedSize() -> String {
        let custom = customSize.trimmingCharacters(in: .whitespacesAndNewlines)
        if isValidSize(custom) { return custom }
        if let size = selectedPreset.size { return size }
        guard let ratio = references.first?.aspectRatio else { return "3840x2160" }
        if ratio > 1.55 { return "3840x2160" }
        if ratio < 0.70 { return "2160x3840" }
        if ratio > 1.20 { return "3520x2336" }
        if ratio < 0.88 { return "2336x3520" }
        return "2880x2880"
    }

    private func isValidSize(_ value: String) -> Bool {
        let parts = value.lowercased().split(separator: "x")
        guard parts.count == 2, let width = Int(parts[0]), let height = Int(parts[1]) else { return false }
        return width > 0 && height > 0 && width % 16 == 0 && height % 16 == 0
    }

    private func generate() async {
        let cleanPrompt = prompt.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleanPrompt.isEmpty else { return }
        guard !settings.apiKey.isEmpty else {
            alertMessage = "请先在设置里输入 API Key。"
            return
        }

        isGenerating = true
        progressText = references.isEmpty ? "正在调用 /images/generations ..." : "正在上传参考图并调用 /images/edits ..."
        defer {
            isGenerating = false
            progressText = ""
        }

        do {
            let request = APIClient.GenerationRequest(
                baseURL: settings.normalizedBaseURL(),
                apiKey: settings.apiKey,
                model: settings.selectedModel,
                prompt: cleanPrompt,
                size: resolvedSize(),
                quality: quality,
                sendQuality: settings.sendQualityParameter,
                preferB64JSON: settings.preferB64JSON,
                references: references,
                timeout: settings.timeoutSeconds
            )
            let (imageData, revisedPrompt) = try await client.generate(request)
            let record = try historyStore.add(imageData: imageData, prompt: cleanPrompt, model: settings.selectedModel, size: resolvedSize(), revisedPrompt: revisedPrompt)
            latestRecord = record
            progressText = "完成"
        } catch {
            alertMessage = error.localizedDescription
        }
    }

    private func importPhotoItems(_ items: [PhotosPickerItem]) async {
        guard !items.isEmpty else { return }
        var imported: [SelectedReferenceImage] = []
        for (index, item) in items.enumerated() {
            if let data = try? await item.loadTransferable(type: Data.self) {
                imported.append(SelectedReferenceImage(data: data, fileName: "photo_\(index + 1).png"))
            }
        }
        references.append(contentsOf: imported)
        photoItems = []
    }

    private func importFiles(_ result: Result<[URL], Error>) async {
        switch result {
        case .success(let urls):
            var imported: [SelectedReferenceImage] = []
            for url in urls {
                let didStart = url.startAccessingSecurityScopedResource()
                defer { if didStart { url.stopAccessingSecurityScopedResource() } }
                if let data = try? Data(contentsOf: url) {
                    imported.append(SelectedReferenceImage(data: data, fileName: url.lastPathComponent))
                }
            }
            references.append(contentsOf: imported)
        case .failure(let error):
            alertMessage = error.localizedDescription
        }
    }
}
