import SwiftUI
import UIKit

struct HistoryView: View {
    @EnvironmentObject private var historyStore: HistoryStore
    @State private var showClearConfirm = false

    var body: some View {
        NavigationStack {
            Group {
                if historyStore.records.isEmpty {
                    ContentUnavailableView("暂无历史", systemImage: "photo.stack", description: Text("生成完成后会自动保存到这里，可分享或导出。"))
                } else {
                    List {
                        ForEach(historyStore.records) { record in
                            NavigationLink {
                                HistoryDetailView(record: record)
                            } label: {
                                HistoryRow(record: record)
                            }
                        }
                        .onDelete { offsets in
                            for index in offsets {
                                historyStore.delete(historyStore.records[index])
                            }
                        }
                    }
                }
            }
            .navigationTitle("历史")
            .toolbar {
                if !historyStore.records.isEmpty {
                    Button("清空", role: .destructive) { showClearConfirm = true }
                }
            }
            .confirmationDialog("确定清空所有历史图片？", isPresented: $showClearConfirm, titleVisibility: .visible) {
                Button("清空", role: .destructive) { historyStore.clear() }
                Button("取消", role: .cancel) {}
            }
        }
    }
}

struct HistoryRow: View {
    let record: GeneratedImageRecord

    var body: some View {
        HStack(spacing: 12) {
            if let image = UIImage(contentsOfFile: record.fileURL.path) {
                Image(uiImage: image)
                    .resizable()
                    .scaledToFill()
                    .frame(width: 72, height: 72)
                    .clipShape(RoundedRectangle(cornerRadius: 12))
            } else {
                RoundedRectangle(cornerRadius: 12)
                    .fill(.secondary.opacity(0.15))
                    .frame(width: 72, height: 72)
                    .overlay(Image(systemName: "photo"))
            }

            VStack(alignment: .leading, spacing: 6) {
                Text(record.prompt)
                    .font(.headline)
                    .lineLimit(2)
                Text("\(record.model) · \(record.size)")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                Text(record.createdAt, style: .date)
                    .font(.caption2)
                    .foregroundStyle(.secondary)
            }
        }
        .padding(.vertical, 4)
    }
}

struct HistoryDetailView: View {
    let record: GeneratedImageRecord

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                if let image = UIImage(contentsOfFile: record.fileURL.path) {
                    Image(uiImage: image)
                        .resizable()
                        .scaledToFit()
                        .clipShape(RoundedRectangle(cornerRadius: 20))

                    HStack {
                        Button {
                            UIImageWriteToSavedPhotosAlbum(image, nil, nil, nil)
                        } label: {
                            Label("保存到相册", systemImage: "square.and.arrow.down")
                        }
                        .buttonStyle(.bordered)

                        ShareLink(item: record.fileURL) {
                            Label("分享 / 导出", systemImage: "square.and.arrow.up")
                        }
                        .buttonStyle(.borderedProminent)
                    }
                }

                CardView {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("提示词")
                            .font(.headline)
                        Text(record.prompt)
                            .textSelection(.enabled)
                    }
                }

                CardView {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("参数")
                            .font(.headline)
                        Text("模型：\(record.model)")
                        Text("尺寸：\(record.size)")
                        Text("时间：\(record.createdAt.formatted())")
                    }
                }

                if let revised = record.revisedPrompt, !revised.isEmpty {
                    CardView {
                        VStack(alignment: .leading, spacing: 8) {
                            Text("Revised prompt")
                                .font(.headline)
                            Text(revised)
                                .textSelection(.enabled)
                        }
                    }
                }
            }
            .padding()
        }
        .navigationTitle("详情")
        .navigationBarTitleDisplayMode(.inline)
    }
}
