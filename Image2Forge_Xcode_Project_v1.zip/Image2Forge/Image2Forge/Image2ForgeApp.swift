import SwiftUI

@main
struct Image2ForgeApp: App {
    @StateObject private var settings = AppSettings()
    @StateObject private var historyStore = HistoryStore()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(settings)
                .environmentObject(historyStore)
                .task {
                    historyStore.load()
                }
        }
    }
}
