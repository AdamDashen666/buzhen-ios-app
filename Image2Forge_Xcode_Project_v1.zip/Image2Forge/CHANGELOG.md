# Changelog

## v1.0.0

- 新增 SwiftUI Xcode Project：Image2Forge
- 内置 APIYI Base URL：`https://api.apiyi.com/v1`
- 默认模型设为 `gpt-image-2-vip`
- 新增 API Key 输入与 Keychain 保存
- 新增「刷新模型」按钮，通过 `/models` 拉取可用模型
- 新增模型列表与模型选择器
- 新增文生图调用：`/images/generations`
- 新增参考图 / 图片编辑调用：`/images/edits`
- 新增相册多选图片与文件多选图片
- 新增 1K / 2K / 4K 完整预设尺寸，含 3840×2160 真 4K 横屏
- 新增自动适配尺寸，根据参考图比例选择输出尺寸
- 新增自定义尺寸输入，要求宽高均为 16 的倍数
- 新增生成历史、图片导出、分享、保存到相册
- 新增兼容选项：b64_json、quality 参数、超时时间
