import Foundation
import Combine

final class AISettings: ObservableObject {
    static let keychainService = "LiquidAIBrowser.API"
    static let keychainAccount = "OpenAICompatibleKey"

    static let presets: [APIPreset] = [
        APIPreset(name: "OpenAI", baseURL: "https://api.openai.com/v1", defaultModel: "gpt-4.1-mini"),
        APIPreset(name: "OpenRouter", baseURL: "https://openrouter.ai/api/v1", defaultModel: "openai/gpt-4o-mini"),
        APIPreset(name: "DeepSeek", baseURL: "https://api.deepseek.com/v1", defaultModel: "deepseek-chat"),
        APIPreset(name: "Gemini Compatible", baseURL: "https://generativelanguage.googleapis.com/v1beta/openai", defaultModel: "gemini-2.5-flash"),
        APIPreset(name: "SiliconFlow", baseURL: "https://api.siliconflow.cn/v1", defaultModel: "deepseek-ai/DeepSeek-V3"),
        APIPreset(name: "Moonshot", baseURL: "https://api.moonshot.cn/v1", defaultModel: "moonshot-v1-8k"),
        APIPreset(name: "智谱 GLM", baseURL: "https://open.bigmodel.cn/api/paas/v4", defaultModel: "glm-4-flash"),
        APIPreset(name: "通义千问", baseURL: "https://dashscope.aliyuncs.com/compatible-mode/v1", defaultModel: "qwen-plus"),
        APIPreset(name: "零一万物", baseURL: "https://api.lingyiwanwu.com/v1", defaultModel: "yi-lightning")
    ]

    @Published var providerName: String { didSet { UserDefaults.standard.set(providerName, forKey: "providerName") } }
    @Published var baseURL: String { didSet { UserDefaults.standard.set(baseURL, forKey: "baseURL") } }
    @Published var model: String { didSet { UserDefaults.standard.set(model, forKey: "model") } }
    @Published var temperature: Double { didSet { UserDefaults.standard.set(temperature, forKey: "temperature") } }
    @Published var maxIterations: Int { didSet { UserDefaults.standard.set(maxIterations, forKey: "maxIterations") } }
    @Published var requestTimeout: Double { didSet { UserDefaults.standard.set(requestTimeout, forKey: "requestTimeout") } }
    @Published var useJSONMode: Bool { didSet { UserDefaults.standard.set(useJSONMode, forKey: "useJSONMode") } }
        @Published var enableVisionScreenshots: Bool { didSet { UserDefaults.standard.set(enableVisionScreenshots, forKey: "enableVisionScreenshots") } }
    @Published var allowCoordinateFallback: Bool { didSet { UserDefaults.standard.set(allowCoordinateFallback, forKey: "allowCoordinateFallback") } }
    @Published var persistSessionHistory: Bool { didSet { UserDefaults.standard.set(persistSessionHistory, forKey: "persistSessionHistory") } }
    @Published var maxActionRetries: Int { didSet { UserDefaults.standard.set(maxActionRetries, forKey: "maxActionRetries") } }
    @Published var availableModels: [String] = []
    @Published var apiKey: String {
        didSet {
            if apiKey.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                KeychainStore.delete(service: Self.keychainService, account: Self.keychainAccount)
            } else {
                KeychainStore.save(apiKey, service: Self.keychainService, account: Self.keychainAccount)
            }
        }
    }

    init() {
        let defaults = UserDefaults.standard
        let firstPreset = Self.presets[0]
        self.providerName = defaults.string(forKey: "providerName") ?? firstPreset.name
        self.baseURL = defaults.string(forKey: "baseURL") ?? firstPreset.baseURL
        self.model = defaults.string(forKey: "model") ?? firstPreset.defaultModel
        self.temperature = defaults.object(forKey: "temperature") as? Double ?? 0.2
        self.maxIterations = defaults.object(forKey: "maxIterations") as? Int ?? 0
        self.requestTimeout = defaults.object(forKey: "requestTimeout") as? Double ?? 60
        self.useJSONMode = defaults.object(forKey: "useJSONMode") as? Bool ?? true
        self.enableVisionScreenshots = defaults.object(forKey: "enableVisionScreenshots") as? Bool ?? false
        self.allowCoordinateFallback = defaults.object(forKey: "allowCoordinateFallback") as? Bool ?? true
        self.persistSessionHistory = defaults.object(forKey: "persistSessionHistory") as? Bool ?? true
        self.maxActionRetries = defaults.object(forKey: "maxActionRetries") as? Int ?? 3
        self.apiKey = KeychainStore.load(service: Self.keychainService, account: Self.keychainAccount)
    }

    func applyPreset(_ preset: APIPreset) {
        providerName = preset.name
        baseURL = preset.baseURL
        model = preset.defaultModel
    }

    func snapshot() -> AISettingsSnapshot {
        AISettingsSnapshot(
            apiKey: apiKey,
            baseURL: baseURL,
            model: model,
            temperature: temperature,
            requestTimeout: requestTimeout,
            useJSONMode: useJSONMode,
            enableVisionScreenshots: enableVisionScreenshots,
            allowCoordinateFallback: allowCoordinateFallback,
            maxActionRetries: maxActionRetries
        )
    }
}
