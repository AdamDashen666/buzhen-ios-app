#!/usr/bin/env python3
"""Structural checks for Swift sources, for use where no Swift compiler exists.

WHAT THIS IS
------------
A tokenizer-based checker for the classes of error that a human editing Swift by
hand actually makes, and that are invisible in review:

  1. unbalanced `{}`, `()`, `[]`
  2. unbalanced `#if` / `#elseif` / `#else` / `#endif`
  3. an unterminated string literal, multi-line string, or character escape
  4. a stray `)` or `]` (a closer with no opener)
  5. `arguments[0]`-style constructs in files that are not inside a function
  6. missing trailing newline, CRLF line endings, UTF-8 BOM, tab indentation
  7. duplicate top-level type declarations

WHAT THIS IS NOT
----------------
It is not a compiler, a type checker or a parser. It cannot prove that the code
compiles, and this script says so in its own output. It exists so that "no Xcode is
available" does not mean "no mechanical verification is available at all".

Deliberate limitation: a Swift *unbalanced* string or comment cannot be described by
a single flat rule (multi-line strings and comment openers both swallow text), so the
tokenizer treats the source as a single line stream and reports the first structural
inconsistency rather than trying to recover. In practice that is enough: a mistake
introduces one inconsistency, and the reported line number points at it.

Run:  python tools/check_swift.py [--strict]
"""
from __future__ import annotations

import argparse
import pathlib
import re
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
SOURCE_DIRS = ["App", "Views", "Web", "FileManagement", "Diagnostics", "Settings"]

OPENERS = {"{": "}", "(": ")", "[": "]"}
CLOSERS = {"}": "{", ")": "(", "]": "["}
MATCHING = {"{": "}", "(": ")", "[": "]"}


class Problem:
    def __init__(self, path: pathlib.Path, line: int, message: str) -> None:
        self.path = path
        self.line = line
        self.message = message

    def __str__(self) -> str:
        return f"{self.path.relative_to(ROOT).as_posix()}:{self.line}: {self.message}"


def tokenize(path: pathlib.Path, text: str, problems: list[Problem]) -> list[tuple[str, str, int]]:
    """Returns a flat list of (kind, value, line) for code tokens.

    `kind` is 'bracket' or 'directive'. A real Swift file cannot be scanned for
    brackets with a naive counter, because brackets appear inside:

      * comments (`// (see note)`, `/* } */`)
      * single-line strings ("(")
      * multi-line strings (the start and end delimiters do not sit on one line)
      * string interpolation (`"\\(value)"` — legal, and the closing paren is
        immediately followed by a quote)

    So this is a small state machine with an explicit stack of interpolation
    contexts. Inside an interpolation the scanner is back in *code* mode, and it
    must return to *string* mode as soon as the matching `)` is consumed — the
    previous version keyed that transition off the character after the paren and
    therefore mis-lexed common forms such as `"\\(text)\\n"` and `"\\(table)."`.

    Brackets inside an interpolation are counted like any other code, so an
    unbalanced interpolation expression is still reported.
    """
    tokens: list[tuple[str, str, int]] = []
    index = 0
    line = 1
    length = len(text)

    # State, not heuristics. The hard case is interpolation that itself contains a
    # string literal:  "\(x.map { $0 } ?? "nil")"
    # The inner quotes are *not* the end of the outer string, so the scanner needs a
    # stack recording, for each open delimiter, where it came from. Two passes of
    # guessing at this produced hundreds of false positives on correct code.
    #
    # String context flags: 1 = single-line, 2 = multi-line.
    STRING_SINGLE = 1
    STRING_MULTI = 2

    in_string = 0            # 0 when scanning code
    # Entries: 'block' (a /* */ comment), 'string' (a " or """ literal), 'interp' (a \(
    # interpolation). `depth` counts still-open '(' inside the current interpolation.
    stack: list[dict] = []
    string_stack: list[int] = []   # flags of the enclosing string for each interp
    depth_stack: list[int] = []
    paren_depth = 0                # parens opened since the innermost \(
    block_comment_depth = 0

    def advance(count: int) -> None:
        nonlocal index, line
        chunk = text[index:index + count]
        line += chunk.count("\n")
        index += count

    while index < length:
        char = text[index]

        # ------------------------------------------------- unsupported raw */# --
        if block_comment_depth > 0:
            if text.startswith("/*", index):
                block_comment_depth += 1
                advance(2)
                continue
            if text.startswith("*/", index):
                block_comment_depth -= 1
                advance(2)
                continue
            advance(1)
            continue

        # ------------------------------------------------------------- in code --
        if in_string == 0:
            if text.startswith("//", index):
                end = text.find("\n", index)
                advance((end - index) if end != -1 else (length - index))
                continue
            if text.startswith("/*", index):
                block_comment_depth = 1
                advance(2)
                continue
            if text.startswith('"""', index):
                in_string = STRING_MULTI
                stack.append({"kind": "string"})
                advance(3)
                continue
            if char == '"':
                in_string = STRING_SINGLE
                stack.append({"kind": "string"})
                advance(1)
                continue
            if char == "`":
                advance(1)
                while index < length and text[index] != "`":
                    advance(1)
                advance(1)
                continue
            if char == "#" and not text.startswith("#!", index) and not text.startswith('#"', index):
                match = re.match(r"#(if|elseif|else|endif)\b", text[index:])
                if match:
                    tokens.append(("directive", match.group(1), line))
                    advance(len(match.group(0)))
                    continue
            if char in OPENERS:
                if stack and stack[-1]["kind"] == "interp" and char == "(":
                    paren_depth += 1
                tokens.append(("bracket", char, line))
                advance(1)
                continue
            if char in CLOSERS:
                if char == ")" and stack and stack[-1]["kind"] == "interp":
                    if paren_depth > 0:
                        paren_depth -= 1
                    else:
                        # This ')' closes the interpolation: resume the string it
                        # was embedded in.
                        stack.pop()
                        in_string = string_stack.pop()
                        tokens.append(("bracket", ")", line))
                        advance(1)
                        continue
                tokens.append(("bracket", char, line))
                advance(1)
                continue
            advance(1)
            continue

        # --------------------------------------------------------- inside string --
        if in_string == STRING_MULTI and text.startswith('"""', index):
            advance(3)
            in_string = 0
            stack.pop()
            continue

        if text.startswith("\\(", index):
            # Enter interpolation. Remember which string we came from so the matching
            # ')' can restore it, even if the interpolation contains strings of its own.
            stack.append({"kind": "interp"})
            string_stack.append(in_string)
            paren_depth = 0
            tokens.append(("bracket", "(", line))
            in_string = 0
            advance(2)
            continue

        if text.startswith("\\\\", index):
            advance(2)
            continue
        if char == "\\":
            advance(2)
            continue

        if in_string == STRING_SINGLE:
            if char == '"':
                advance(1)
                in_string = 0
                stack.pop()
                continue
            if char == "\n":
                problems.append(Problem(path, line, "单行字符串字面量未闭合"))
                in_string = 0
                stack.pop()
                continue
            advance(1)
            continue

        advance(1)

    if block_comment_depth > 0:
        problems.append(Problem(path, line, "块注释 /* 未闭合"))
    elif in_string:
        problems.append(Problem(path, line, "字符串字面量未闭合"))
    return tokens


def check_brackets(path: pathlib.Path, tokens: list[tuple[str, str, int]], problems: list[Problem]) -> None:
    stack: list[tuple[str, int]] = []
    punctuation = {"{", "}", "(", ")", "[", "]"}
    for kind, value, line in tokens:
        if kind != "bracket" or value not in punctuation:
            continue
        if value in OPENERS:
            stack.append((value, line))
            continue
        if not stack:
            problems.append(Problem(path, line, f"多余的闭合符号 '{value}'"))
            return
        opener, opener_line = stack.pop()
        if MATCHING[opener] != value:
            problems.append(Problem(
                path, line,
                f"括号不匹配: 第 {opener_line} 行的 '{opener}' 对应 '{MATCHING[opener]}'，却遇到 '{value}'"))
            return
    if stack:
        opener, opener_line = stack[-1]
        problems.append(Problem(
            path, opener_line,
            f"未闭合的 '{opener}'（文件结束时仍缺少 {len(stack)} 个闭合符号）"))


def check_directives(path: pathlib.Path, tokens: list[tuple[str, str, int]], problems: list[Problem]) -> None:
    depth = 0
    stack: list[int] = []
    for kind, value, line in tokens:
        if kind != "directive":
            continue
        if value == "if":
            depth += 1
            stack.append(line)
        elif value == "endif":
            if depth == 0:
                problems.append(Problem(path, line, "#endif 没有对应的 #if"))
                return
            depth -= 1
            stack.pop()
        elif value in ("else", "elseif"):
            if depth == 0:
                problems.append(Problem(path, line, f"#{value} 出现在 #if 之外"))
                return
    if depth != 0:
        problems.append(Problem(path, stack[0], f"#if 未闭合（缺少 {depth} 个 #endif）"))


# Swift *declaration* keywords that can never be used as the name being declared.
#
# Deliberately narrow. The first version of this check listed the whole keyword set and
# produced four false positives on correct code:
#   * `func open(...)`          — `open` is context-sensitive, not reserved there
#   * `let required = ...`      — same
#   * `case .x(let required, …)` — a pattern binding, not a declaration
#   * a doc comment *mentioning* `var protocol:` — comments are skipped now
# Only words that hard-fail in `var`/`let`/`func X` position are listed, which is what
# actually broke the first real CI build.
RESERVED_IDENTIFIERS = {
    "protocol", "class", "struct", "enum", "extension", "import", "func",
    "init", "deinit", "typealias", "associatedtype", "subscript", "operator",
}

# `var <word>` / `let <word>` / `func <word>`, but NOT `if let x`, `guard let x`,
# `case let x` — those are bindings, not declarations.
DECLARED_IDENTIFIER_RE = re.compile(
    r"(?<![\w.])(?P<kind>var|let|func)\s+(?P<name>[A-Za-z_][A-Za-z0-9_]*)\s*(?P<after>[:=({\[,)]|\s)"
)


def check_reserved_identifiers(path: pathlib.Path, text: str, lines: list[str],
                               problems: list[Problem]) -> None:
    """Flags `var protocol:`-style declarations that cannot compile.

    Comments are masked out first (a doc comment explaining this very rule must not
    trip it), and pattern bindings such as `case .x(let required, …)` are skipped.
    """
    # Mask comments with spaces, preserving offsets and line numbers.
    masked_chars = list(text)
    index = 0
    length = len(text)
    while index < length:
        if text.startswith("//", index):
            end = text.find("\n", index)
            end = length if end == -1 else end
            for position in range(index, end):
                masked_chars[position] = " "
            index = end
            continue
        if text.startswith("/*", index):
            depth = 1
            cursor = index + 2
            while cursor < length and depth:
                if text.startswith("/*", cursor):
                    depth += 1
                    cursor += 2
                    continue
                if text.startswith("*/", cursor):
                    depth -= 1
                    cursor += 2
                    continue
                cursor += 1
            for position in range(index, min(cursor, length)):
                if masked_chars[position] != "\n":
                    masked_chars[position] = " "
            index = cursor
            continue
        index += 1
    masked = "".join(masked_chars)

    for match in DECLARED_IDENTIFIER_RE.finditer(masked):
        name = match.group("name")
        if name not in RESERVED_IDENTIFIERS:
            continue
        line_no = masked.count("\n", 0, match.start()) + 1
        line_text = lines[line_no - 1].strip() if line_no - 1 < len(lines) else ""
        problems.append(Problem(
            path, line_no,
            f"'{name}' 是 Swift 保留字，不能作为被声明的标识符（需改名或用反引号）："
            f"{line_text[:90]}"))


def check_typechecker_risk(path: pathlib.Path, text: str, problems: list[Problem]) -> None:
    """Flags view bodies that risk "unable to type-check this expression in reasonable time".

    That error is a real build failure (GitHub run #149) and it is not a warning: the
    whole target fails. It appears when a single SwiftUI expression nests too many
    overloaded constructs — typically several ternaries inside view modifiers, since
    `foregroundStyle`, `buttonStyle` and `Image(systemName:)` each fan out into many
    overloads.

    The heuristic: count ternaries inside one `var body` / `@ViewBuilder` property, and
    flag a ternary that directly feeds an overloaded modifier. It is intentionally
    conservative — a warning, not an error — because a false positive costs a glance
    while a missed one costs a CI cycle.
    """
    lines = text.splitlines()
    for index, line in enumerate(lines):
        stripped = line.strip()
        if stripped.startswith("//") or stripped.startswith("///"):
            continue
        # A ternary passed straight into a modifier argument.
        if "?" in line and ":" in line:
            for modifier in (".foregroundStyle(", ".buttonStyle(", ".font(", ".tint(",
                             ".background(", ".frame(", ".padding("):
                if modifier in line:
                    problems.append(Problem(
                        path, index + 1,
                        f"三元表达式直接作为 {modifier}… 的参数，容易触发 "
                        f"「unable to type-check this expression in reasonable time」。"
                        f"建议先算成局部常量或拆成独立的 View：{stripped[:80]}"))
                    break

    # Count ternaries per view body; more than two in one expression is a smell.
    body_start: int | None = None
    depth = 0
    ternaries = 0
    for index, line in enumerate(lines):
        if "var body: some View" in line or (body_start is None and "some View {" in line):
            body_start = index
            ternaries = 0
            depth = 0
        if body_start is not None:
            ternaries += line.count(" ? ") + line.count("? ")
            depth += line.count("{") - line.count("}")
            if depth <= 0 and index > body_start:
                if ternaries > 6:
                    problems.append(Problem(
                        path, body_start + 1,
                        f"视图体内出现 {ternaries} 处三元表达式，接近 Swift 类型检查器的预算上限；"
                        f"建议拆成子 View（参考 Views/SharedLocationRow.swift 的做法）"))
                body_start = None


TOP_LEVEL_TYPE_RE = re.compile(
    r"^[ \t]*"
    r"(?:(?:public|internal|private|fileprivate|final|open|@\w+(?:\([^)]*\))?)\s+)*"
    r"(?P<kind>class|struct|enum|protocol|actor|extension)\s+(?P<name>[A-Za-z_][A-Za-z0-9_]*)",
    re.MULTILINE)


def check_file(path: pathlib.Path, declarations: dict[str, list[str]],
               problems: list[Problem], warnings: list[Problem] | None = None) -> int:
    raw = path.read_bytes()
    text = raw.decode("utf-8")

    if b"\r\n" in raw:
        problems.append(Problem(path, 1, "文件包含 CRLF 换行（Swift 可编译，但会污染 diff）"))
    if raw.startswith(b"\xef\xbb\xbf"):
        problems.append(Problem(path, 1, "文件包含 UTF-8 BOM"))
    if not text.endswith("\n"):
        problems.append(Problem(path, text.count("\n") + 1, "文件未以换行符结尾"))
    if "\t" in text:
        first_tab = text[:text.index("\t")].count("\n") + 1
        problems.append(Problem(path, first_tab, "含制表符缩进（项目统一使用空格）"))

    tokens = tokenize(path, text, problems)
    check_brackets(path, tokens, problems)
    check_directives(path, tokens, problems)
    check_reserved_identifiers(path, text, text.splitlines(), problems)
    check_typechecker_risk(path, text, warnings if warnings is not None else [])

    # Bare `arguments[0]` is only valid inside a function; in a Swift-adjacent JS
    # resource it is a common copy-paste error. Checked here because the same mistake
    # was found once in WebProbe.js.
    for match in re.finditer(r"arguments\[0\]", text):
        line = text[:match.start()].count("\n") + 1
        problems.append(Problem(path, line, "出现 arguments[0]：只有在函数作用域内才有意义"))

    for match in TOP_LEVEL_TYPE_RE.finditer(text):
        name = match.group("name")
        kind = match.group("kind")
        line = text[:match.start()].count("\n") + 1
        # Only non-extension declarations are collected. `extension Foo` legitimately
        # appears several times for the same type (and in several files), so treating
        # those as duplicates would produce noise instead of signal.
        if kind != "extension":
            declarations.setdefault(name, []).append(f"{path.relative_to(ROOT).as_posix()}:{line}")

    return text.count("\n") + 1


# Names that are instantiated somewhere in the sources but declared outside the
# project (system frameworks) or are not types at all. Any other instantiated name
# with no declaration in this repository is very likely a dangling reference left
# behind by a rename — the failure mode this check was added for.
EXTERNAL_CONSTRUCTORS = {
    # Foundation / Swift
    "Data", "Date", "URL", "URLComponents", "URLRequest", "UUID", "JSONEncoder", "JSONDecoder",
    "ISO8601DateFormatter", "DateFormatter", "ByteCountFormatter", "FileManager", "FileHandle",
    "NSError", "IndexSet", "Range", "Set", "Array", "Dictionary", "String", "ProcessInfo",
    "Timer", "Measurement", "CharacterSet", "Locale", "TimeZone", "NSPredicate",
    # UIKit
    "UIApplication", "UIAlertController", "UIAlertAction", "UIImage", "UIColor", "UIFont",
    "UIDocumentPickerViewController", "UIActivityViewController", "UIImageView", "UIScreen",
    "UIPasteboard", "UIViewController", "UIWindowScene", "UIView", "UIButton", "UILabel",
    "UITraitCollection", "UIMenu", "UIDeferredMenuElement", "UIContextMenuInteraction",
    # WebKit
    "WKWebView", "WKWebViewConfiguration", "WKUserScript", "WKUserContentController",
    "WKWebpagePreferences", "WKWebsiteDataStore", "WKScriptMessage", "WKFrameInfo",
    "WKNavigationAction", "WKNavigationResponse", "URLRequest",
    # Network
    "NWListener", "NWConnection", "NWParameters", "NWEndpoint", "NWProtocolTCP",
    # Concurrency
    "Task", "MainActor", "DispatchQueue", "Result", "Never", "Optional", "Error",
    # SwiftUI
    "Binding", "State", "StateObject", "EnvironmentObject", "NavigationStack", "NavigationSplitView",
    "Text", "Image", "Button", "List", "Section", "Form", "Toggle", "Picker", "Divider", "Spacer",
    "ProgressView", "ScrollView", "LazyVGrid", "LazyVStack", "VStack", "HStack", "ZStack",
    "GeometryReader", "Path", "Rectangle", "RoundedRectangle", "Capsule", "Color", "Material",
    "Label", "Link", "Menu", "Group", "ForEach", "ContentUnavailableView", "DisclosureGroup",
    "NavigationLink", "ToolbarItem", "ToolbarItemGroup", "Sheet", "Scene", "WindowGroup",
    "App", "View", "ObservableObject", "Published", "Environment", "ScenePhase", "Animation",
    "GridItem", "TextField", "SecureField", "Stepper", "Slider", "DatePicker", "ColorPicker",
    "ObjectIdentifier", "NSDictionary", "NSArray", "NSNumber", "NSString", "NSObject",
    "UTType", "UTTypeReference", "NSItemProvider", "UNNotification", "NSCache",
    "UIRefreshControl", "UIScrollView", "UISlider", "UISwitch", "UISegmentedControl",
    # Localised / misc
    "Character", "Unicode", "Mirror", "UInt8", "Int8", "UInt16", "UInt32", "UInt64", "Int32", "Int64",
    "Float", "Double", "Int", "Bool", "CGFloat", "CGPoint", "CGSize", "CGRect", "Float32",
    "Circle", "Ellipse", "Capsule", "Divider", "Spacer", "ProgressView", "Stepper",
    "ObservableObject", "Published", "StateObject", "EnvironmentObject", "Namespace",
}


def check_dangling_constructors(paths: list[pathlib.Path],
                                declared: set[str],
                                problems: list[Problem]) -> None:
    # Functions bound to system symbols with `@_silgen_name("...")` are declared in the
    # project even though the name in the attribute (not the Swift function name) is
    # what gets called. This project uses that for `csops` and the `SecTask*` readers,
    # so those symbol names must count as declared.
    silgen_symbols: set[str] = set()
    for path in paths:
        text = path.read_text(encoding="utf-8")
        silgen_symbols.update(re.findall(r'@_silgen_name\(\s*"([^"]+)"\s*\)', text))

    pattern = re.compile(r"(?<![\w.$])([A-Z][A-Za-z0-9_]*)\(([^)\n]*(?:\n[^)]*)?)\)")
    for path in paths:
        text = path.read_text(encoding="utf-8")
        for match in pattern.finditer(text):
            name = match.group(1)
            if name in declared or name in EXTERNAL_CONSTRUCTORS or name in silgen_symbols:
                continue
            line = text[:match.start()].count("\n") + 1
            problems.append(Problem(
                path, line,
                f"实例化 '{name}' 但全项目没有它的声明（重命名后遗漏的调用点？）"))


# Types that are never referenced by name in the sources because a framework
# instantiates them (SwiftUI's `@main` entry point, property wrappers, Apple's
# required delegate protocols). Excluded from the unused check.
RUNTIME_INSTANTIATED = {
    "HTMLRunnerApp",   # @main — SwiftUI creates it
}


def check_unused_types(paths: list[pathlib.Path],
                       declarations: dict[str, list[str]],
                       problems: list[Problem]) -> None:
    """Reports a declared type whose name appears nowhere else in the project.

    This is the other half of the dangling-reference check. Together they make a
    rename safe: the old name must not still be *used* anywhere, and the new name
    must not be *declared but unused* (which is what a half-finished rename leaves
    behind). A name that appears exactly once in the whole repository — at its own
    declaration — cannot be reachable.

    Reported as warnings by the caller, not errors: a genuinely unused private
    helper is a style issue, while a half-renamed type is a real hazard, and the
    two are indistinguishable from the text alone.
    """
    corpus: list[str] = []
    for path in paths:
        corpus.append(path.read_text(encoding="utf-8"))
    haystack = "\n".join(corpus)

    for name, where in sorted(declarations.items()):
        if name in RUNTIME_INSTANTIATED:
            continue
        # `\b` is not enough: Swift identifiers allow `_` and digits, so require that
        # neither neighbour is an identifier character.
        occurrences = len(re.findall(rf"(?<![A-Za-z0-9_]){re.escape(name)}(?![A-Za-z0-9_])", haystack))
        if occurrences <= len(where):
            path_text, line_text = where[0].rsplit(":", 1)
            problems.append(Problem(
                ROOT / path_text, int(line_text),
                f"类型 '{name}' 只在声明处出现，全项目没有任何引用"
                f"（重命名只改了一半？或确实是死代码）"))


def main() -> int:
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except (AttributeError, ValueError):
            pass

    parser = argparse.ArgumentParser(description="对 Swift 源码做结构检查（不是编译）")
    parser.add_argument("--strict", action="store_true", help="把警告也视为失败")
    args = parser.parse_args()

    app_root = ROOT / "HTMLRunner"
    files: list[pathlib.Path] = []
    for folder in SOURCE_DIRS:
        directory = app_root / folder
        if directory.is_dir():
            files.extend(sorted(directory.rglob("*.swift")))

    if not files:
        print("[swift] 未找到任何 Swift 文件")
        return 1

    problems: list[Problem] = []
    warnings: list[Problem] = []
    declarations: dict[str, list[str]] = {}
    total_lines = 0
    for path in files:
        total_lines += check_file(path, declarations, problems, warnings)

    duplicates = {name: where for name, where in declarations.items() if len(where) > 1}
    for name, where in sorted(duplicates.items()):
        problems.append(Problem(ROOT / "HTMLRunner", 0, f"类型 '{name}' 被声明多次: {', '.join(where)}"))

    check_dangling_constructors(files, set(declarations.keys()), problems)

    unused: list[Problem] = []
    check_unused_types(files, declarations, unused)
    for problem in unused:
        print(f"[swift][warn] {problem}")

    for problem in warnings:
        print(f"[swift][warn] {problem}")

    for problem in problems:
        print(f"[swift][ERROR] {problem}")

    print(f"[swift] 检查 {len(files)} 个文件 / {total_lines} 行，"
          f"{len(declarations)} 个类型声明，问题 {len(problems)} 个")
    if problems:
        print("[swift] 结果: 失败")
        return 1
    print("[swift] 结果: 通过（结构检查通过 ≠ 能编译；类型错误无法在此发现）")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
