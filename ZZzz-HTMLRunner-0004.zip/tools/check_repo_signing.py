#!/usr/bin/env python3
"""Check which workflows in the target repository already do code signing.

Run:  python tools/check_repo_signing.py
"""
from __future__ import annotations

import sys
import urllib.request

REPO = "AdamDashen666/buzhen-ios-app"
WORKFLOWS = [
    "build-app.yml",
    "manual-build-ipa.yml",
    "build-codexpad-v2.yml",
    "run-ipa-builder.yml",
    "run-ipa-builder-newest.yml",
    "build-macos-dmg.yml",
]
TOKENS = ["p12", "security import", "codesign", "exportArchive",
          "DEVELOPMENT_TEAM", "mobileprovision", "APPLE_CERT", "KEYCHAIN",
          "certificate", "provisioning"]

for name in WORKFLOWS:
    url = f"https://raw.githubusercontent.com/{REPO}/main/.github/workflows/{name}"
    try:
        with urllib.request.urlopen(url, timeout=20) as response:
            text = response.read().decode("utf-8", "replace")
    except Exception as error:  # noqa: BLE001
        print(f"{name}: could not read ({error})")
        continue
    hits = [token for token in TOKENS if token.lower() in text.lower()]
    label = ", ".join(hits) if hits else "none — builds unsigned only"
    print(f"{name}: {label}")
