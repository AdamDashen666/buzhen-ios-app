//
//  ProcessDebugState.swift
//  HTMLRunner
//
//  Answers two narrow, verifiable questions about **this app process**:
//
//    1. Has a debugger attached, i.e. may this process create executable memory?
//       (`csops(CS_OPS_STATUS)` & `CS_DEBUGGED`)
//    2. Which code-signing entitlements does this process actually carry?
//       (`SecTaskCopyValueForEntitlement`)
//
//  Why `csops` rather than only `sysctl(KERN_PROC_PID)` + `P_TRACED`
//  -----------------------------------------------------------------
//  Both observe the same kernel state, but `CS_DEBUGGED` is the flag the sideload
//  tools themselves test — PojavLauncher (`isJITEnabled()` in `Natives/utils.m`) and
//  LiveContainer both read it — so using the same mechanism means this app agrees
//  with the tool that enabled JIT instead of merely approximating it. The technique
//  and the constant are taken from Delta's shipping `ProcessInfo+JIT.swift`
//  (`CS_OPS_STATUS = 0`, `CS_DEBUGGED = 0x10000000`). The `sysctl`/`P_TRACED` read is
//  kept as a cross-check: when the two disagree, that is worth seeing in the log.
//
//  What this CANNOT answer
//  -----------------------
//  Whether WKWebView's *WebContent* process runs JavaScript with the JIT. That
//  process belongs to Apple, its flags are unreadable from here, and no public API
//  exposes JavaScriptCore's compilation mode. Every string below therefore says
//  "本进程 / this process", and the UI repeats the limitation verbatim.
//

import Foundation
import Darwin
import Security

// MARK: - csops

/// `csops(2)` is not in the public headers, so it is bound by symbol name — the same
/// approach Delta uses in production. `CS_OPS_STATUS` asks for the code-signing
/// status word; the individual bits are Apple's `ProcessCodeSigningFlags`
/// (LightweightCodeRequirements): `CS_VALID = 0x1`, `CS_HARD = 0x100`,
/// `CS_KILL = 0x200`, `CS_RESTRICT = 0x800`, `CS_DEBUGGED = 0x10000000`.
private let CS_OPS_STATUS: UInt32 = 0
private let CS_DEBUGGED: UInt32 = 0x10000000

@_silgen_name("csops")
private func csops(_ pid: pid_t,
                   _ ops: UInt32,
                   _ useraddr: UnsafeMutableRawPointer?,
                   _ usersize: Int) -> Int32

// MARK: - Entitlement reader

/// `SecTaskCopyValueForEntitlement` lives in the Security framework but is not
/// declared in the public Swift interface for iOS, so it is bound by symbol name.
/// PojavLauncher reads entitlements exactly this way.
@_silgen_name("SecTaskCreateFromSelf")
private func SecTaskCreateFromSelf(_ allocator: CFAllocator?) -> CFTypeRef?

@_silgen_name("SecTaskCopyValueForEntitlement")
private func SecTaskCopyValueForEntitlement(_ task: CFTypeRef,
                                           _ entitlement: CFString,
                                           _ error: UnsafeMutablePointer<Unmanaged<CFError>?>?) -> CFTypeRef?

enum ProcessEntitlements {

    /// Reads one entitlement from this process. Returns nil when it is absent;
    /// a present `false` is reported as the string "false" so the two cases differ.
    static func value(for key: String) -> String? {
        guard let task = SecTaskCreateFromSelf(nil) else { return nil }
        defer { _ = task }

        var error: Unmanaged<CFError>?
        guard let raw = SecTaskCopyValueForEntitlement(task, key as CFString, &error) else {
            return nil
        }
        let value = raw as AnyObject
        if let number = value as? NSNumber {
            return number.boolValue ? "true" : "false"
        }
        if let string = value as? String {
            return string
        }
        if let array = value as? [Any] {
            return array.map { String(describing: $0) }.joined(separator: ", ")
        }
        return String(describing: value)
    }

    /// Entitlements that decide whether *this* process may create executable memory.
    static let jitRelevantKeys = [
        "dynamic-codesigning",                 // pre-iOS 17.4 mechanism
        "com.apple.developer.cs.allow-jit",    // iOS 17.4+ mechanism
        "com.apple.security.cs.allow-jit",     // derived name, reported if present
        "com.apple.private.verified-jit",      // Apple-internal; informational only
        "get-task-allow",                      // what puts an app in a JIT tool's list
        "com.apple.security.cs.disable-library-validation",
        "task_for_pid-allow"
    ]

    static func presentJITEntitlements() -> [(key: String, value: String)] {
        jitRelevantKeys.compactMap { key in
            guard let value = value(for: key) else { return nil }
            return (key, value)
        }
    }

    /// True when an entitlement that grants executable memory is present and true.
    static func hasExecutableMemoryEntitlement(_ entitlements: [(key: String, value: String)]) -> Bool {
        entitlements.contains { entry in
            let granting = entry.key == "dynamic-codesigning"
                || entry.key == "com.apple.developer.cs.allow-jit"
                || entry.key == "com.apple.security.cs.allow-jit"
            return granting && entry.value == "true"
        }
    }
}

// MARK: - Code-signing status

struct CodeSigningStatus: Equatable {
    var statusCallSucceeded: Bool
    var flags: UInt32
    var isDebugged: Bool
    var isValid: Bool
    var isHard: Bool
    var isKill: Bool
    var isRestricted: Bool
    var failureReason: String?

    static func current() -> CodeSigningStatus {
        var flags: UInt32 = 0
        let result = csops(getpid(), CS_OPS_STATUS, &flags, MemoryLayout<UInt32>.size)
        guard result == 0 else {
            return CodeSigningStatus(statusCallSucceeded: false, flags: 0, isDebugged: false,
                                     isValid: false, isHard: false, isKill: false,
                                     isRestricted: false,
                                     failureReason: "csops 返回 \(result)，errno=\(errno)")
        }
        return CodeSigningStatus(
            statusCallSucceeded: true,
            flags: flags,
            isDebugged: (flags & CS_DEBUGGED) == CS_DEBUGGED,
            isValid: (flags & 0x1) != 0,
            isHard: (flags & 0x100) != 0,
            isKill: (flags & 0x200) != 0,
            isRestricted: (flags & 0x800) != 0,
            failureReason: nil)
    }

    var flagsHex: String { String(format: "0x%08X", flags) }

    /// A human-readable flag list, only including the bits that are set.
    var setFlagNames: [String] {
        var names: [String] = []
        if isValid { names.append("CS_VALID") }
        if isHard { names.append("CS_HARD") }
        if isKill { names.append("CS_KILL") }
        if isRestricted { names.append("CS_RESTRICT") }
        if isDebugged { names.append("CS_DEBUGGED") }
        return names
    }
}

// MARK: - Combined report

/// Everything this app can honestly determine about its own JIT capability.
///
/// The verdict is deliberately coarse and never claims more than the evidence:
///   * `.processAllowsJIT` — a debugger is attached, or a JIT entitlement is present.
///     This is exactly the condition the sideload tools establish, and it says
///     nothing whatsoever about the WebContent process.
///   * `.processCannotJIT` — neither is present, so this process cannot create
///     executable memory.
///   * `.indeterminate` — `csops` failed and no entitlement was found, so nothing
///     can be concluded.
struct JITCapabilityReport {

    enum Verdict: String {
        case processAllowsJIT = "本进程具备 JIT 条件"
        case processCannotJIT = "本进程不具备 JIT 条件"
        case indeterminate = "无法判定"
    }

    var signing: CodeSigningStatus
    var tracedBySysctl: Bool
    var entitlements: [(key: String, value: String)]
    var verdict: Verdict

    var hasJITEntitlement: Bool {
        ProcessEntitlements.hasExecutableMemoryEntitlement(entitlements)
    }

    var hasGetTaskAllow: Bool {
        entitlements.contains { $0.key == "get-task-allow" && $0.value == "true" }
    }

    /// The entitlement is present but explicitly `false`.
    ///
    /// This is a materially different state from "absent", and it is the one observed
    /// on a real device (iPad16,4 / iPadOS 27.0.1) after the IPA was signed by a
    /// third-party tool with a non-debugging certificate: the signer wrote
    /// `get-task-allow = false` into the binary. Such a process can never receive
    /// `CS_DEBUGGED`, so no JIT-enabling tool will offer to attach — and reporting it
    /// as merely "missing" would hide the actual cause.
    var getTaskAllowIsExplicitlyFalse: Bool {
        entitlements.contains { $0.key == "get-task-allow" && $0.value == "false" }
    }

    /// Explains a hardened signature that cannot be debugged.
    ///
    /// `CS_HARD | CS_KILL` together mean the kernel is authorised to terminate the
    /// process if its signature ever becomes invalid — the shape of a distribution or
    /// otherwise restricted signature, as opposed to a development one. Combined with
    /// no `CS_DEBUGGED` and no granting entitlement, this is a complete explanation of
    /// "the JIT tool does not see this app", so it is stated explicitly instead of
    /// leaving the user to infer it from three separate rows.
    var signatureBlocksDebugging: Bool {
        signing.statusCallSucceeded
            && !signing.isDebugged
            && !hasJITEntitlement
            && !hasGetTaskAllow
            && signing.isHard
            && signing.isKill
    }

    /// A short, actionable diagnosis. Nil when nothing conclusive can be said.
    var diagnosis: String? {
        guard signing.statusCallSucceeded else {
            return "读不到内核代码签名状态，无法判断。请把本页反馈。"
        }
        if signing.isDebugged {
            return "调试器已附加：JIT 权限对本进程生效。注意这只影响本 App 进程，不影响网页。"
        }
        if getTaskAllowIsExplicitlyFalse {
            return """
                签名工具把 get-task-allow 写成了 false。这类签名永远无法附加调试器，\
                因此 JIT 类工具不会把本 App 列入可开启 JIT 的清单。
                通常需要用带调试权限的描述文件重新签名（例如免费 Apple ID 的本地自签），\
                而不是分发证书。注意：即使签名正确，也只影响本 App 进程，网页 JS 不受影响。
                """
        }
        if signatureBlocksDebugging {
            return """
                当前签名带 CS_HARD + CS_KILL，属受限签名，内核不允许附加调试器。\
                这是「工具列表里看不到本 App」的直接原因。\
                需要换用带 get-task-allow 的开发/本地自签。
                """
        }
        if !hasGetTaskAllow && !hasJITEntitlement {
            return "本进程既未被调试器附加，也没有任何可执行内存 entitlement。若侧载工具应已开启 JIT，说明它没有真正附加成功。"
        }
        return nil
    }

    /// True when the two independent kernel reads agree. A disagreement is surfaced
    /// rather than hidden, because it would mean one of them is not measuring what
    /// this code assumes.
    var checksAgree: Bool {
        !signing.statusCallSucceeded || signing.isDebugged == tracedBySysctl
    }

    static func current() -> JITCapabilityReport {
        let signing = CodeSigningStatus.current()
        let entitlements = ProcessEntitlements.presentJITEntitlements()
        let hasEntitlement = ProcessEntitlements.hasExecutableMemoryEntitlement(entitlements)
        let traced = ProcessDebugState.current().isBeingTraced

        let verdict: Verdict
        if signing.statusCallSucceeded {
            verdict = (signing.isDebugged || hasEntitlement) ? .processAllowsJIT : .processCannotJIT
        } else {
            // `csops` failed, but an explicit JIT entitlement is still positive evidence.
            verdict = hasEntitlement ? .processAllowsJIT : .indeterminate
        }

        return JITCapabilityReport(signing: signing,
                                   tracedBySysctl: traced,
                                   entitlements: entitlements,
                                   verdict: verdict)
    }
}

// MARK: - Legacy P_TRACED check

/// Retained as the independent cross-check for `CS_DEBUGGED`. Uses the Apple QA1361
/// recipe: `sysctl(KERN_PROC_PID)` and read the `P_TRACED` bit of `p_flag`.
struct ProcessDebugState: Equatable {
    var isBeingTraced: Bool
    var processFlags: UInt32
    var failureReason: String?

    var isBeingTracedDescription: String {
        if let failureReason {
            return "无法确认（\(failureReason)）"
        }
        return isBeingTraced ? "是（内核报告 P_TRACED）" : "否（内核未报告 P_TRACED）"
    }

    static func current() -> ProcessDebugState {
        var info = kinfo_proc()
        var size = MemoryLayout<kinfo_proc>.stride
        var mib: [Int32] = [CTL_KERN, KERN_PROC, KERN_PROC_PID, getpid()]
        let result = mib.withUnsafeMutableBufferPointer { buffer -> Int32 in
            sysctl(buffer.baseAddress, u_int(buffer.count), &info, &size, nil, 0)
        }
        guard result == 0, size > 0 else {
            return ProcessDebugState(isBeingTraced: false, processFlags: 0,
                                     failureReason: "sysctl(KERN_PROC_PID) 失败 errno=\(errno)")
        }
        let flags = UInt32(info.kp_proc.p_flag)
        return ProcessDebugState(isBeingTraced: (flags & UInt32(P_TRACED)) != 0,
                                 processFlags: flags,
                                 failureReason: nil)
    }
}
