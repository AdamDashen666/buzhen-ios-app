//
//  JITReportExporter.swift
//  HTMLRunner
//
//  Renders `JITCapabilityReport` into text that can be copied out of the app, pasted
//  into a bug report, or compared against what a sideload tool claims.
//
//  Everything printed here is measured on the device at the moment of the call. No
//  field is inferred, defaulted or guessed — a value that could not be read is printed
//  as such, because a fabricated "false" in a JIT report is worse than an honest
//  "unknown".
//

import Foundation
import UIKit

enum JITReportExporter {

    /// The full report as plain text, in a stable order so two runs can be diffed.
    static func reportText() -> String {
        let report = JITCapabilityReport.current()
        var lines: [String] = []

        lines.append("HTMLRunner JIT 检测报告")
        lines.append("生成时间: \(DiagnosticLogStore.isoFormatter.string(from: Date()))")
        lines.append("App: \(AppInfo.versionDescription)  构建配置: \(AppInfo.buildConfigurationName)")
        lines.append("系统: \(AppInfo.systemName)")
        lines.append("设备标识: \(AppInfo.deviceModelIdentifier ?? "无法获取")")
        lines.append("")

        lines.append("== 结论（只描述本 App 进程）==")
        lines.append("判定: \(report.verdict.rawValue)")
        if let diagnosis = report.diagnosis {
            lines.append("诊断: \(diagnosis)")
        }
        lines.append("说明: 该判定基于 CS_DEBUGGED 标志与可执行内存相关 entitlement；")
        lines.append("      不代表 WKWebView 的 WebContent 进程使用了 JIT —— 那无法由 App 读取。")
        lines.append("")

        lines.append("== 内核代码签名状态 ==")
        if report.signing.statusCallSucceeded {
            lines.append("csops(CS_OPS_STATUS) 调用: 成功")
            lines.append("状态字 p_flag: \(report.signing.flagsHex)")
            lines.append("CS_DEBUGGED: \(report.signing.isDebugged ? "已置位（调试器已附加）" : "未置位")")
            lines.append("CS_VALID: \(report.signing.isValid ? "是" : "否")")
            lines.append("CS_HARD: \(report.signing.isHard ? "是" : "否")")
            lines.append("CS_KILL: \(report.signing.isKill ? "是" : "否")")
            lines.append("CS_RESTRICT: \(report.signing.isRestricted ? "是" : "否")")
            lines.append("已置位标志: \(report.signing.setFlagNames.isEmpty ? "（无）" : report.signing.setFlagNames.joined(separator: ", "))")
        } else {
            lines.append("csops(CS_OPS_STATUS) 调用: 失败")
            lines.append("原因: \(report.signing.failureReason ?? "未知")")
        }
        lines.append("")

        lines.append("== 交叉校验 ==")
        lines.append("sysctl(KERN_PROC_PID).P_TRACED: \(report.tracedBySysctl ? "已置位" : "未置位")")
        lines.append("两种读取方式一致: \(report.checksAgree ? "是" : "否（不一致，请反馈）")")
        lines.append("")

        lines.append("== 本进程实际携带的 JIT 相关 entitlements ==")
        if report.entitlements.isEmpty {
            lines.append("（一个都没有）")
            lines.append("侧载工具重签后通常至少会出现 get-task-allow。")
        } else {
            for entry in report.entitlements {
                lines.append("\(entry.key) = \(entry.value)")
            }
        }
        lines.append("")
        lines.append("get-task-allow 存在且为 true: \(report.hasGetTaskAllow ? "是" : "否")")
        lines.append("get-task-allow 被显式写成 false: \(report.getTaskAllowIsExplicitlyFalse ? "是（签名工具写入）" : "否")")
        lines.append("可执行内存 entitlement 存在: \(report.hasJITEntitlement ? "是" : "否")")
        lines.append("受限签名（CS_HARD + CS_KILL，内核可因签名失效终止进程）: \(report.signatureBlocksDebugging ? "是 —— 该签名无法被调试器附加" : "否")")
        lines.append("")

        lines.append("== 无法确认的部分（不要读成 0 或 false）==")
        lines.append("WebContent 进程是否使用 JIT: 无法确认（iOS 未提供任何接口）")
        lines.append("JavaScriptCore 编译模式: 无法确认（无公开 API）")
        lines.append("WebContent 进程内存: 无法获取")
        lines.append("")

        lines.append("== 参考 ==")
        lines.append("检测方式取自 Delta 的 ProcessInfo+JIT.swift：")
        lines.append("  CS_OPS_STATUS = 0, CS_DEBUGGED = 0x10000000")
        lines.append("同为 PojavLauncher Natives/utils.m::isJITEnabled() 与 LiveContainer 使用的方法。")

        return lines.joined(separator: "\n")
    }

    /// Copies the report so it can be pasted anywhere (a chat, an issue, a note).
    @discardableResult
    static func copyToPasteboard() -> String {
        let text = reportText()
        UIPasteboard.general.string = text
        return text
    }
}
