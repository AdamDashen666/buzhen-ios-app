//
//  SettingsView.swift
//  HTMLRunner
//
//  Every option here is one a user can reason about. Each control states what it
//  changes and what it costs; there are no "performance" toggles that quietly alter
//  WebKit behaviour without an explanation.
//

import SwiftUI
import WebKit

struct SettingsView: View {

    @EnvironmentObject private var appState: AppState
    @EnvironmentObject private var settings: AppSettings
    @EnvironmentObject private var log: DiagnosticLogStore

    @State private var showingShare = false
    @State private var exportURL: URL?
    @State private var showingResetConfirm = false
    @State private var cacheUsageText: String?
    @State private var isClearingCache = false
    @State private var destination: ProjectStore.DestinationSubfolder = ProjectStore.destinationSubfolder
    @State private var showingLocationChangeConfirm = false

    var body: some View {
        Form {
            storageSection
            loadSection
            diagnosticsSection
            serverSection
            dataSection
            aboutSection
        }
        .navigationTitle("设置")
        .sheet(isPresented: $showingShare) {
            if let exportURL { ShareSheet(items: [exportURL]) }
        }
        .confirmationDialog("更改项目存放位置？", isPresented: $showingLocationChangeConfirm, titleVisibility: .visible) {
            Button("更改", role: .destructive) { applyDestinationChange() }
            Button("取消", role: .cancel) { destination = ProjectStore.destinationSubfolder }
        } message: {
            Text("已导入的项目不会被移动，App 会在两个位置里自动找到它们。只有**新导入**的项目会放到新位置。")
        }
        .confirmationDialog("恢复默认设置？", isPresented: $showingResetConfirm, titleVisibility: .visible) {
            Button("恢复默认", role: .destructive) { resetToDefaults() }
            Button("取消", role: .cancel) {}
        }
        .onChange(of: settings.allowWebInspector) { _, newValue in
            // The toggle must reach the live web view, not just UserDefaults:
            // `WKWebView.isInspectable` is only read while the view exists.
            appState.coordinator?.setInspectable(newValue)
        }
        .task {
            await refreshCacheUsage()
        }
    }

    // MARK: Storage location

    private var storageSection: some View {
        Section {
            Picker("导入到", selection: $destination) {
                ForEach(ProjectStore.DestinationSubfolder.allCases) { option in
                    Text(option.title).tag(option)
                }
            }
            .onChange(of: destination) { _, newValue in
                guard newValue != ProjectStore.destinationSubfolder else { return }
                showingLocationChangeConfirm = true
            }
            Text(destination.explanation)
                .font(.caption)
                .foregroundStyle(.secondary)

            HStack {
                Text("当前路径")
                Spacer()
                Text(displayPath)
                    .font(.caption.monospaced())
                    .foregroundStyle(.secondary)
                    .textSelection(.enabled)
                    .multilineTextAlignment(.trailing)
            }

            Button {
                UIPasteboard.general.string = displayPath
            } label: {
                Label("复制路径", systemImage: "doc.on.doc")
            }

            Text("""
                在「文件」App 里，这个 App 显示为 **HTMLRunner**。\
                把项目文件夹直接放进它下面，或放进它的 Projects 子目录，App 都会在下次启动时自动识别，\
                不需要走文件选择器。识别条件是文件夹里至少有一个 .html/.htm 文件。
                """)
                .font(.caption)
                .foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
        } header: {
            Text("项目存放位置")
        }
    }

    private var displayPath: String {
        appState.projects.projectsRootDirectory.path
    }

    /// Extracted so the view body holds no ternary: a ternary feeding
    /// `foregroundStyle` is exactly what pushes SwiftUI's type checker over budget.
    private var serverStateColor: Color {
        appState.server.state.isRunning ? .green : .secondary
    }

    private func applyDestinationChange() {
        ProjectStore.destinationSubfolder = destination
        log.notice(LogEvent.settingsChanged, "项目存放位置已更改", metadata: [
            "destination": destination.rawValue
        ])
    }

    // MARK: Load

    private var loadSection: some View {
        Section {
            Picker("默认加载方式", selection: $settings.defaultRunMode) {
                ForEach(RunMode.allCases) { mode in
                    Text(mode.title).tag(mode)
                }
            }
            Text(settings.defaultRunMode.explanation)
                .font(.caption)
                .foregroundStyle(.secondary)

            Picker("外部链接", selection: $settings.defaultExternalLinkPolicy) {
                ForEach(ExternalLinkPolicy.allCases) { policy in
                    Text(policy.title).tag(policy)
                }
            }
            Text(settings.defaultExternalLinkPolicy.explanation)
                .font(.caption)
                .foregroundStyle(.secondary)

            Picker("音频播放策略", selection: $settings.defaultAudioPolicy) {
                ForEach(AudioPlaybackPolicy.allCases) { policy in
                    Text(policy.title).tag(policy)
                }
            }
            Text("游戏通常在加载时就播放音频，因此默认允许自动播放。若要严格跟随系统策略，可改为「需要用户手势」。")
                .font(.caption)
                .foregroundStyle(.secondary)
        } header: {
            Text("页面加载")
        } footer: {
            Text("修改后对下一次打开项目生效。当前运行的页面不会被改动，避免游戏中途重新初始化。")
        }
    }

    // MARK: Diagnostics

    private var diagnosticsSection: some View {
        Section {
            Toggle("启用诊断桥", isOn: $settings.diagnosticsEnabled)
            Text("在页面加载前注入一段只负责上报错误的脚本（console、未捕获异常、Promise 拒绝、资源加载失败）。它不修改渲染、计时器或模块加载逻辑，可在排查结束后关闭。")
                .font(.caption)
                .foregroundStyle(.secondary)

            Toggle("性能悬浮面板", isOn: $settings.performanceOverlayEnabled)
            Text("在页面右上角显示一个小型 FPS / JS 堆面板，点击即可隐藏。只在页面内绘制，不改变画布尺寸。")
                .font(.caption)
                .foregroundStyle(.secondary)

            Picker("日志级别", selection: $settings.logLevel) {
                ForEach(LogLevel.allCases) { level in
                    Text(level.title).tag(level)
                }
            }
            Text("调高到「警告」可显著减少日志量。日志最多保留 \(DiagnosticLogStore.maxEntries) 条，超过后自动丢弃最早的记录。")
                .font(.caption)
                .foregroundStyle(.secondary)

            Toggle("启动时进入诊断页", isOn: $settings.showDiagnosticsOnLaunch)

            Toggle("允许 Safari Web Inspector 附加（仅 Debug 构建生效）", isOn: $settings.allowWebInspector)
            Text("设置为 WKWebView.isInspectable。对通过侧载工具安装的 Release 版本不会生效——Web Inspector 需要可调试的签名与连接，这超出 App 能控制的范围。")
                .font(.caption)
                .foregroundStyle(.secondary)
        } header: {
            Text("诊断")
        }
    }

    // MARK: Server

    private var serverSection: some View {
        Section {
            Toggle("启用本地 HTTP 服务", isOn: $settings.localServerEnabled)
            Text("""
                开启后，新的运行会改用 http://127.0.0.1:<随机端口>/ 加载项目。服务只绑定回环地址，局域网内其他设备无法访问，也不会开放任何目录——只有当前项目的根目录可被读取，并会拒绝 ../ 与符号链接逃逸。
                用途：file:// 下的 ES Modules 与 fetch 有同源限制，HTTP 语义可以避开这些问题。
                """)
                .font(.caption)
                .foregroundStyle(.secondary)

            HStack {
                Text("当前状态")
                Spacer()
                Text(appState.server.state.description)
                    .foregroundStyle(serverStateColor)
            }

            Button("停止服务") {
                appState.stopServer(reason: "settings")
            }
            .disabled(!appState.server.state.isRunning)
        } header: {
            Text("本地服务")
        } footer: {
            Text("不改动系统代理、不监听 0.0.0.0、不需要任何特殊 entitlement。")
        }
    }

    // MARK: Data

    private var dataSection: some View {
        Section {
            Button {
                exportReport()
            } label: {
                Label("导出诊断报告", systemImage: "square.and.arrow.up")
            }

            Button {
                UIPasteboard.general.string = log.plainText(level: settings.logLevel)
            } label: {
                Label("复制当前日志", systemImage: "doc.on.doc")
            }

            HStack {
                Text("WebKit 缓存占用")
                Spacer()
                if isClearingCache {
                    ProgressView()
                } else {
                    Text(cacheUsageText ?? "正在计算…")
                        .foregroundStyle(.secondary)
                }
            }

            Button(role: .destructive) {
                clearWebKitCache()
            } label: {
                Label("清理 WebKit 缓存与网站数据", systemImage: "trash")
            }
            Text("会清除 WKWebView 的磁盘/内存缓存、localStorage 与 IndexedDB。注意：游戏存档若保存在 localStorage 中会一并被删除。App 不会声称这能「释放 WebKit 全部内存」——那不存在。")
                .font(.caption)
                .foregroundStyle(.secondary)

            Button(role: .destructive) {
                showingResetConfirm = true
            } label: {
                Label("恢复默认设置", systemImage: "arrow.counterclockwise")
            }
        } header: {
            Text("数据与缓存")
        }
    }

    // MARK: About

    private var aboutSection: some View {
        Section {
            ForEach(AppInfo.snapshot(), id: \.0) { pair in
                HStack {
                    Text(pair.0).foregroundStyle(.secondary)
                    Spacer()
                    Text(pair.1).multilineTextAlignment(.trailing)
                }
                .font(.callout)
            }
            HStack {
                Text("项目目录").foregroundStyle(.secondary)
                Spacer()
                Text(appState.projectsDirectoryDescription)
                    .font(.caption.monospaced())
                    .textSelection(.enabled)
                    .multilineTextAlignment(.trailing)
            }
        } header: {
            Text("版本与构建信息")
        } footer: {
            Text("""
                本 App 使用系统 WebKit 渲染页面，不包含第三方浏览器引擎。
                它不会修改你的 HTML 项目文件；导入时只是复制，运行时除了可关闭的诊断桥之外不注入任何内容。
                """)
        }
    }

    // MARK: Actions

    private func exportReport() {
        do {
            exportURL = try appState.makeDiagnosticReport()
            showingShare = true
        } catch {
            log.error(LogEvent.diagnosticExport, "报告生成失败", metadata: ["error": error.localizedDescription])
        }
    }

    private func resetToDefaults() {
        settings.defaultRunMode = .fileURL
        settings.defaultExternalLinkPolicy = .openInSafari
        settings.defaultAudioPolicy = .allowAll
        settings.diagnosticsEnabled = true
        settings.performanceOverlayEnabled = false
        settings.localServerEnabled = false
        settings.logLevel = .debug
        settings.allowWebInspector = false
        settings.showDiagnosticsOnLaunch = false
        log.notice(LogEvent.settingsChanged, "已恢复默认设置")
    }

    private func refreshCacheUsage() async {
        let size = await WebKitCacheInspector.diskCacheSize()
        cacheUsageText = size.map { ByteCountFormatter.string(fromByteCount: Int64($0), countStyle: .file) } ?? "无法获取"
    }

    private func clearWebKitCache() {
        isClearingCache = true
        let log = self.log
        Task {
            await WebKitCacheInspector.clearAll()
            log.notice(LogEvent.settingsChanged, "已清理 WebKit 缓存与网站数据")
            await refreshCacheUsage()
            isClearingCache = false
        }
    }
}

// MARK: - Cache inspection

enum WebKitCacheInspector {

    /// Sums the on-disk WebKit cache/data directories. These are inside the app
    /// container, so they can be measured without private APIs. When the file system
    /// refuses (some sandbox configurations), nil is returned rather than a guess.
    static func diskCacheSize() async -> UInt64? {
        await Task.detached(priority: .utility) {
            let manager = FileManager.default
            guard let library = try? manager.url(for: .libraryDirectory,
                                                in: .userDomainMask,
                                                appropriateFor: nil,
                                                create: false) else { return nil }
            let candidates = ["Caches", "WebKit", "WebsiteData"]
            var total: UInt64 = 0
            var measuredAnything = false
            for name in candidates {
                let root = library.appendingPathComponent(name, isDirectory: true)
                guard manager.fileExists(atPath: root.path) else { continue }
                measuredAnything = true
                guard let enumerator = manager.enumerator(at: root,
                                                         includingPropertiesForKeys: [.totalFileAllocatedSizeKey, .fileAllocatedSizeKey],
                                                         options: [.skipsHiddenFiles]) else { continue }
                for case let url as URL in enumerator {
                    guard let values = try? url.resourceValues(forKeys: [.totalFileAllocatedSizeKey, .fileAllocatedSizeKey]) else { continue }
                    total += UInt64(values.totalFileAllocatedSize ?? values.fileAllocatedSize ?? 0)
                }
            }
            return measuredAnything ? total : nil
        }.value
    }

    /// Removes all WebKit-managed data for the default data store. This is the only
    /// supported way to do it; there is no API to purge WebKit's *memory*.
    static func clearAll() async {
        let types = WKWebsiteDataStore.allWebsiteDataTypes()
        let store = WKWebsiteDataStore.default()
        let records = await store.dataRecords(ofTypes: types)
        await store.removeData(ofTypes: types, for: records)
    }
}
