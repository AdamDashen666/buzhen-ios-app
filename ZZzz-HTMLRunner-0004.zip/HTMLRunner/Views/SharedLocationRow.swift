//
//  SharedLocationRow.swift
//  HTMLRunner
//
//  One row of the "import from the Files app's HTMLRunner directory" list.
//
//  Extracted into its own `View` on purpose. Inlining this into the parent produced
//
//      error: the compiler is unable to type-check this expression in reasonable time
//      try breaking up the expression into distinct sub-expressions
//
//  which is a real build failure (GitHub run #149), not a warning. SwiftUI's view
//  builders are heavily overloaded, and a row with ternaries inside `Image`,
//  `foregroundStyle` and `buttonStyle` at once crosses the type checker's budget.
//  Keeping the row separate and pre-computing its strings keeps each expression small.
//

import SwiftUI

struct SharedLocationRow: View {

    let location: ProjectStore.SharedLocation
    var onAdopt: () -> Void
    var onMove: () -> Void

    /// Pre-computed so the view body contains no string interpolation of its own.
    private var symbolName: String {
        location.isAlreadyInProjectsDirectory ? "checkmark.seal" : "folder"
    }

    private var symbolColor: Color {
        location.isAlreadyInProjectsDirectory ? .green : .orange
    }

    private var actionTitle: String {
        location.isAlreadyInProjectsDirectory ? "加入列表" : "移入"
    }

    private var subtitle: String {
        "\(location.source.description) · \(location.fileCount) 个文件 · \(location.sizeDescription)"
    }

    private var entryText: String {
        "入口推测：\(location.entryGuess)"
    }

    var body: some View {
        HStack(spacing: 10) {
            Image(systemName: symbolName)
                .foregroundStyle(symbolColor)
            details
            Spacer(minLength: 8)
            actionButton
        }
        .padding(8)
        .background(.quaternary.opacity(0.35),
                    in: RoundedRectangle(cornerRadius: 10, style: .continuous))
    }

    private var details: some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(location.name)
                .font(.callout)
                .lineLimit(1)
            Text(subtitle)
                .font(.caption2)
                .foregroundStyle(.secondary)
                .lineLimit(1)
            Text(entryText)
                .font(.caption2)
                .foregroundStyle(.tertiary)
        }
    }

    private var actionButton: some View {
        // The two cases get different button styles; expressed with `if` rather than a
        // ternary on `.buttonStyle`, which is what pushed the type checker over budget.
        Group {
            if location.isAlreadyInProjectsDirectory {
                Button(actionTitle, action: onAdopt)
                    .buttonStyle(.bordered)
            } else {
                Button(actionTitle, action: onMove)
                    .buttonStyle(.borderedProminent)
            }
        }
        .controlSize(.small)
    }
}

/// Small success/failure badge for a project's last run.
///
/// A separate type so the parent view body stays free of ternaries inside modifiers —
/// see the note at the top of this file for why that matters at compile time.
struct OutcomeBadge: View {

    let succeeded: Bool

    private var symbolName: String {
        succeeded ? "checkmark.circle.fill" : "exclamationmark.circle.fill"
    }

    private var color: Color {
        succeeded ? .green : .orange
    }

    private var helpText: String {
        succeeded ? "上次运行加载成功" : "上次运行出现过错误"
    }

    var body: some View {
        Image(systemName: symbolName)
            .foregroundStyle(color)
            .help(helpText)
    }
}
