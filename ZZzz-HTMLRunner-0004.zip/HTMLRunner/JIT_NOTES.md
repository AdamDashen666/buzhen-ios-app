# HTMLRunner / JIT 研究笔记

> 研究时间：2026-10-12（本机时间）。目标环境：iPad Pro 11" M4 + iPadOS 27，经第三方侧载工具（NB助手 / NB Pro）安装。
> 阅读约定：**【已验证】**= 有一手来源（Apple 文档 / WebKit 源码 / 项目源码 / 官方文档），附 URL 与原文引用；**【推断】**= 由已验证事实推出的结论，未经直接证实；**无法直接确认**= 找不到可靠来源或原理上不可观测。
> 三条硬规则：①性能基准 ≠ JIT 证据（任何"跑分变快"都不能当作 JIT 已开启的证明）；②本项目不涉及伪造签名、伪造 entitlements、绕过 Apple 安全机制，只描述公开可用的机制与观测手段；③明确区分"App 能控制的"与"完全不在 App 控制范围内的"。

---

## 结论摘要

- **WKWebView 的 JavaScript 不在 App 进程里跑，而在 Apple 自带的系统进程 `com.apple.WebKit.WebContent` 里跑**；因此"给 App 开 JIT"与"网页 JS 有没有 JIT"是两件互不相干的事。【已验证：WebKit 源码】
- **能不能出现在侧载工具的 JIT 列表，只取决于签名方式**：IPA 必须带 `get-task-allow`（个人 Apple ID 自签 / 开发证书）才会出现在列表里；用分发/共享证书或 App Store 安装则不会。【已验证：SideStore / StikDebug / StikJIT 文档】
- 用个人 Apple ID 自签的 HTMLRunner（NB助手默认签名方式）**大概率会出现在这类列表里**，但这只代表"App 进程可被附加调试器"，**不代表 WKWebView 里的 JS 获得任何额外权限**。【已验证机制 + 推断"大概率"】
- **`com.apple.security.cs.allow-jit` / `dynamic-codesigning` 是"进程自己要执行 JIT 代码"时才需要的权限**，是逐进程授予的，不会从 App 传给 WebContent。【已验证：Apple 文档 + WebKit 源码】
- WebKit 的 RIA/内容进程在 iOS 上由 Apple 自己签名并自带 JIT 相关 entitlements（iOS SDK ≥ 17.4 用 `com.apple.developer.cs.allow-jit`，更早用 `dynamic-codesigning`），**第三方 App 无法也不需要为它添加任何东西**。【已验证：WebKit `process-entitlements.sh`】
- **WebContent 里的 JIT 默认就是开的**；能被关掉的只有三种情形：用户开启"锁定模式"（同时禁用 WebAssembly）、系统/宿主启用 Enhanced Security、宿主 App 用私有 API 下发 `disable-jit`。这三种都不由我们的 App 决定。【已验证：WebKit `XPCServiceEntryPoint.mm`】
- **没有任何公开的 WKWebView / JS API 能查询"JIT 是否开启"**；能从网页侧得到的只有间接信号（例如 `WebAssembly` 是否存在——锁定模式下 WebKit 显式 `useWasm() = false`），从原生侧能确认的只有 **App 自己** 的 `get-task-allow` / `CS_DEBUGGED` / `P_TRACED`。【已验证源码 + 无法直接确认 JIT 状态】
- **iPadOS 27 + M4 的 JIT 可用性无法从资料确认**：SideStore 官方文档（2026-06-17）称"26.6 与 27 只有少数 App 可用"，二手博客声称 iOS 27 可用；两者都没有提到 M4。必须实机验证。【见第 9 节检查清单】

---

## 1. JavaScriptCore / WebKit / WKWebView / JIT 的关系

### 1.1 三个进程，权限各不相同

一个使用 `WKWebView` 的 App 在 iOS 上至少涉及三类进程：

| 进程 | 归属 | 谁签名 | 里面跑什么 |
|---|---|---|---|
| App 进程（HTMLRunner） | 我们 | 侧载签名（个人 Apple ID / 开发证书…） | SwiftUI 界面、WKWebView 的 API 调用 |
| `com.apple.WebKit.WebContent` | 系统 WebKit | **Apple** | HTML/CSS/JS/WASM 全部网页代码 |
| `com.apple.WebKit.Networking` / `.GPU` | 系统 WebKit | **Apple** | 网络、合成/图形 |

**【已验证】** WebKit 源码里 WebContent 服务名是构建期写死的产品名，第三方 App 不能自带同名服务：

```xcconfig
# Source/WebKit/Configurations/WebContentService.xcconfig
PRODUCT_NAME_Normal = com.apple.WebKit.WebContent;
PRODUCT_NAME_Development = com.apple.WebKit.WebContent.Development;
PRODUCT_NAME_CaptivePortal = com.apple.WebKit.WebContent.CaptivePortal;
PRODUCT_NAME_EnhancedSecurity = com.apple.WebKit.WebContent.EnhancedSecurity;
```
（<https://raw.githubusercontent.com/WebKit/WebKit/main/Source/WebKit/Configurations/WebContentService.xcconfig>）

那么我们的 App 用的是哪一个变体？**【已验证】** 由 UI 进程的启动选项决定，默认走正常变体：

```cpp
// Source/WebKit/UIProcess/Launcher/cocoa/ProcessLauncherCocoa.mm
return launchOptions.nonValidInjectedCodeAllowed ? "com.apple.WebKit.WebContent.Development"_s : "com.apple.WebKit.WebContent"_s;
```
```cpp
// Source/WebKit/UIProcess/Launcher/ProcessLauncher.h
bool nonValidInjectedCodeAllowed { false };
```
（<https://raw.githubusercontent.com/WebKit/WebKit/main/Source/WebKit/UIProcess/Launcher/cocoa/ProcessLauncherCocoa.mm>、<https://raw.githubusercontent.com/WebKit/WebKit/main/Source/WebKit/UIProcess/Launcher/ProcessLauncher.h>）

"Development 变体"的用途是给"注入了 bundle 的 WebKit 客户端做开发调试"（WebKit Bug 187355：*"useless for development of WebKit clients that have injected bundles"*，<https://bugs.webkit.org/show_bug.cgi?id=187355>）。普通 WKWebView App 不注入 bundle，因此走正常变体。**【推断】** 侧载/开启 JIT 不会把 WebContent 切到 Development 变体，因为 `nonValidInjectedCodeAllowed` 与 `get-task-allow` 无关（源码未显示二者有关联，但该标志的赋值点本次未定位到，见第 9 节）。

### 1.2 JIT 权限属于"要执行 JIT 代码的那个进程"

**【已验证】** Apple 对 `com.apple.security.cs.allow-jit` 的说明（注意 platform 元数据写的是 macOS 10.7+）：

> "A Boolean value that indicates whether the app may create writable and executable memory using the `MAP_JIT` flag."
> "Without the Allow execution of JIT-compiled code entitlement, frameworks that rely on just-in-time (JIT) compilation may fall back to an interpreter."
> —— <https://developer.apple.com/documentation/bundleresources/entitlements/com.apple.security.cs.allow-jit>

也就是说：**谁执行 JIT 代码，谁就需要这个 entitlement**。App 有它，只让 App 进程内的引擎（例如一个自研 JIT 分配器、Java VM、模拟器）受益；对另一个进程（WebContent）没有任何作用。

### 1.3 Apple 自己给 WebContent 打的 JIT entitlements

**【已验证】** WebKit 构建脚本逐进程写 entitlements，iOS 家族（iphoneos/ipados 同属 iphoneos 平台）内容如下：

```bash
# Source/WebKit/Scripts/process-entitlements.sh
function ios_family_process_webcontent_entitlements()
{
    if [[ "${PLATFORM_NAME}" != watchos && "${PLATFORM_NAME}" != appletvos ]]; then
        plistbuddy Add :com.apple.private.verified-jit bool YES
        if [[ "${PLATFORM_NAME}" == iphoneos ]]; then
            if (( $(( ${SDK_VERSION_ACTUAL} )) >= 170400 )); then
                plistbuddy Add :com.apple.developer.cs.allow-jit bool YES
            else
                plistbuddy Add :dynamic-codesigning bool YES
            fi
        else
            plistbuddy Add :dynamic-codesigning bool YES
        fi
    fi
    plistbuddy Add :com.apple.developer.kernel.extended-virtual-addressing bool YES
    ...
}
```
（<https://raw.githubusercontent.com/WebKit/WebKit/main/Source/WebKit/Scripts/process-entitlements.sh>）

三个结论：
1. iOS **17.4 是一个分界点**：SDK ≥ 17.4 起 WebContent 用 `com.apple.developer.cs.allow-jit`（+ `com.apple.private.verified-jit`），更早用 `dynamic-codesigning`。
2. 这些 entitlement 由 **Apple 的构建系统**写入 Apple 签名的 WebContent，第三方 App 无法替它添加（脚本依赖 `WK_USE_RESTRICTED_ENTITLEMENTS` 等内部构建变量）。
3. 【推断】这组 entitlements 正是 WebContent 能执行 JIT 的许可来源；WebKit 源码没有"缺少 entitlement 时禁用 JIT"的分支，因为它假设自己是被正确签名的。

### 1.4 WebContent 内 JIT 的开关（默认开）

**【已验证】** WebContent 进程启动时按 UI 进程传来的参数初始化 JSC：

```cpp
// Source/WebKit/Shared/EntryPointUtilities/Cocoa/XPCService/XPCServiceEntryPoint.mm
void setJSCOptions(xpc_object_t initializerMessage, EnableLockdownMode enableLockdownMode,
                   EnableEnhancedSecurity enableEnhancedSecurity, bool isWebContentProcess)
{
    RELEASE_ASSERT(!g_jscConfig.initializeHasBeenCalled);
    ...
    if (enableLockdownMode == EnableLockdownMode::Yes) {
        JSC::Options::initialize([] {
            JSC::ExecutableAllocator::disableJIT();
            JSC::Options::useGenerationalGC() = false;
            JSC::Options::useConcurrentGC() = false;
            JSC::Options::useLLIntICs() = false;
            JSC::Options::useWasm() = false;          // ← 锁定模式连 WebAssembly 一起关
            ...
        });
    } else if (xpc_dictionary_get_bool(initializerMessage, "disable-jit")
               || enableEnhancedSecurity == EnableEnhancedSecurity::Yes) {
        JSC::Options::initialize([] {
            JSC::ExecutableAllocator::disableJIT();
        });
    }
    ...
}
```
（<https://raw.githubusercontent.com/WebKit/WebKit/main/Source/WebKit/Shared/EntryPointUtilities/Cocoa/XPCService/XPCServiceEntryPoint.mm>）

配套证据，UI 进程一侧：

```cpp
// Source/WebKit/UIProcess/Launcher/cocoa/ProcessLauncherCocoa.mm
if (!client->isJITEnabled())
    xpc_dictionary_set_bool(bootstrapMessage.get(), "disable-jit", true);
```
```cpp
// Source/WebKit/UIProcess/Launcher/ProcessLauncher.h
virtual bool isJITEnabled() const { return true; }     // 默认就是"允许 JIT"
```

**【已验证】** JSC 选项表也说明 JIT 是默认值：

```cpp
// Source/JavaScriptCore/runtime/OptionsList.h
v(Bool, useLLInt,  true, Normal, "allows the LLINT to be used if true"_s)
v(Bool, useJIT, jitEnabledByDefault(), Normal, "allows the executable pages to be allocated for JIT and thunks if true"_s)
v(Bool, useWasm, canUseWasm(), Normal, "Expose the Wasm global object."_s)
v(Bool, useWasmIPInt, ipintEnabledByDefault(), Normal, "Use the in-place interpereter for WASM instead of LLInt."_s)
v(Bool, useBBQJIT, true, ...) / v(Bool, useOMGJIT, true, ...)
```
（<https://raw.githubusercontent.com/WebKit/WebKit/main/Source/JavaScriptCore/runtime/OptionsList.h>）

**重要推论（对验证方法很关键）**：`useWasmIPInt` / LLInt 的存在说明 **WebAssembly 有解释器层级**，WebKit 自己也有 bug "WASM should not depend on JIT"（<https://bugs.webkit.org/show_bug.cgi?id=261403>，其中一注释称 *"can run some simple wasm in the no jit case"*）。所以：
- **WASM 能跑 ≠ JIT 开着**（WASM 可能走 IPInt/LLInt 解释器）；
- 但 **WASM 完全不存在（`typeof WebAssembly === 'undefined'`）是有意义的证据**——按上面的源码，只有锁定模式这条路径会显式 `useWasm() = false`。

### 1.5 与 `file://` 加载相关的 WebKit/WKWebView 约束

**【已验证】** Apple 对 `loadFileURL(_:allowingReadAccessTo:)` 的原文：

> "The URL of a file that contains web content. This URL must be a file-based URL."
> （readAccessURL）"The URL of a file or directory containing web content that you grant the system permission to read. This URL must be a file-based URL and must not be empty. To prevent WebKit from reading any other content, specify the same value as the URL parameter."
> —— <https://developer.apple.com/documentation/webkit/wkwebview/loadfileurl(_:allowingreadaccessto:)>

即：这个 API 只解决"**允许 WebKit 读哪些本地路径**"，它**不改变 Web 安全模型**。**【已验证】** 通用 Web 规范层面的行为（MDN，适用于所有现代引擎，WebKit 同源策略同构）：

> "CORS requests may only use the HTTP or HTTPS URL scheme..." / "Many browsers, including Firefox and Chrome, now treat all local files as having *opaque origins* (by default). As a result, loading a local file with included local resources will now result in CORS errors."
> —— <https://developer.mozilla.org/en-US/docs/Web/HTTP/Guides/CORS/Errors/CORSRequestNotHttp>

对本 App 的实际影响（**这是工程约束，不是 JIT 问题**）：
- 经典 `<script src>`、`<img>`、`<link rel=stylesheet>`、`<video src>` 之类的"资源加载"通常可以在 readAccessURL 范围内工作（Three.js 的 UMD 构建即属此类）。
- **`fetch()` / `XMLHttpRequest` / `<script type="module">` / `WebAssembly.instantiateStreaming()` 走的是 CORS 路径**，对 `file://` 通常会被拒（origin 为 `null`）。**【推断 + 需实测】** 我们没有找到 Apple 官方逐条列出的行为表；请在真机上对目标页面逐一验证（见第 9 节）。
- 常见解法是改用 `WKURLSchemeHandler` 自定义 scheme（如 `htmlrunner://`）或本地 HTTP 服务器。关于自定义 scheme 下 `fetch` 的行为，我们只找到低权威来源（火山引擎 AI 问答转载 Stack Exchange 内容，<https://www.volcengine.com/article/2025326>），它称需要 CSP `connect-src` 与响应头 `Access-Control-Allow-Origin` 配合。**无法直接确认，需实测。**
- 与 JIT 的关系：以上任何一条 **都不影响** WebContent 的 JIT 开关，只影响"资源能不能被读到"。

---

## 2. get-task-allow、调试器附加与 JIT（含 PojavLauncher 实际做法）

### 2.1 机制链条

```
个人 Apple ID / 开发证书签名 IPA
        ↓  签名时写入 get-task-allow = true
App 进程允许被同团队/同设备的调试器 attach
        ↓  工具（StikDebug / AltJIT / SideJITServer / NB助手…）通过 debugserver 附加
内核给该进程打上 CS_DEBUGGED 标志（P_TRACED 也会置位）
        ↓
该进程被允许分配可执行内存 → 自己的 JIT 引擎可以工作
```

**【已验证】** PojavLauncher README 把这条链条说得最清楚：

> "JIT is not supported on iOS without the application being debugged, so workarounds are required to enable it."
> "Signing services that do not use your UDID (and use distribution certificates) are not supported, as PojavLauncher requires capabilities they do not allow. However, if you do managed to gain access to a Development certificate, due to it having the necessary entitlement (being `com.apple.security.get-task-allow`) to attach a debugger to the running process (enabling JIT), you may use a Development certificate."
> —— <https://github.com/PojavLauncherTeam/PojavLauncher_iOS>

### 2.2 PojavLauncher 代码里"到底怎么判断 JIT 开了没"

**【已验证】** 这是本次研究最有价值的一段代码，可以直接借鉴到 HTMLRunner 的诊断页：

```objc
// Natives/utils.m
CFTypeRef SecTaskCopyValueForEntitlement(void* task, NSString* entitlement, CFErrorRef _Nullable *error);
void* SecTaskCreateFromSelf(CFAllocatorRef allocator);

BOOL getEntitlementValue(NSString *key) {
    void *secTask = SecTaskCreateFromSelf(NULL);
    CFTypeRef value = SecTaskCopyValueForEntitlement(SecTaskCreateFromSelf(NULL), key, nil);
    ...
    return value != nil && [(__bridge id)value boolValue];
}

BOOL isJITEnabled(BOOL checkCSFlags) {
    if (!checkCSFlags && (getEntitlementValue(@"dynamic-codesigning") || isJailbroken)) {
        return YES;
    }

    int flags;
    csops(getpid(), 0, &flags, sizeof(flags));
    return (flags & CS_DEBUGGED) != 0;
}
```
```objc
// Natives/utils.h
#define CS_DEBUGGED 0x10000000
int csops(pid_t pid, unsigned int ops, void *useraddr, size_t usersize);
BOOL isJITEnabled(BOOL checkCSOps);
```
（<https://raw.githubusercontent.com/PojavLauncherTeam/PojavLauncher_iOS/main/Natives/utils.m>、<https://raw.githubusercontent.com/PojavLauncherTeam/PojavLauncher_iOS/main/Natives/utils.h>）

要点：
- 越狱/TrollStore 路线看 `dynamic-codesigning` entitlement；普通侧载路线看 **`csops(getpid(), 0 /* CS_OPS_STATUS */)` 返回的 `CS_DEBUGGED` 位**。
- 两者都**只看 App 自己**，与 WebContent 无关。

**【已验证】** PojavLauncher 给 TrollStore/越狱用的 entitlements 清单（`v2.2/entitlements.xml`，注意其中并没有 `dynamic-codesigning`，而是靠禁用沙箱 + 自身实现）：

```xml
<key>get-task-allow</key><true/>
<key>com.apple.developer.kernel.extended-virtual-addressing</key><true/>
<key>com.apple.developer.kernel.increased-memory-limit</key><true/>
<!-- Disable sandbox so that PojavLauncher can enable JIT by itself -->
<key>com.apple.private.security.no-sandbox</key><true/>
<key>platform-application</key><true/>
```
（<https://raw.githubusercontent.com/PojavLauncherTeam/PojavLauncher_iOS/v2.2/entitlements.xml>）
这些私有/受限 entitlement 只在越狱或 TrollStore 之类"签名不受 Apple 校验"的环境生效；**普通侧载只能拿到 `get-task-allow`**。

### 2.3 iOS 17.0.1 / 17.4 之后的路线变化

**【已验证】** PojavLauncher 官方 Wiki（"iOS and JIT"）：

> "The most common method is to attach a debug server to the application while it's running - AltStore, SideStore, SideJITServer, and Jitterbug all of these use this method to enable JIT."
> "Enabling JIT on iOS 17.0.1+ (at the moment) can only be enabled through different various methods listed below that utilize pymobiledevice3 to enable JIT due to changes in iOS."
> —— <https://pojavlauncherteam.github.io/wiki/faq/ios/JIT.html>

**【已验证】** SideStore 官方文档（含 2026-06-17 的状态说明）：

> "Users on iOS or iPadOS 17.4 or higher can use a solution such as SideStore 0.6.2 or StikDebug (formerly StikJIT)."
> "**iOS 26 has broken JIT once again, and 26.6 and 27 only work with a few apps.** ... As of writing (June 17 2026), the only supported apps are: UTM, Amethyst, MeloNX, maciOS, DolphiniOS (Works up to 26.6), Geode, Manic EMU, Flycast (iOS 26 fork), MeloCafe, ARMSX2, **DukeX (Works up to 27 on A13/A14/M1 chip)**"
> —— <https://docs.sidestore.io/docs/advanced/jit>

**【已验证】** StikDebug（当前主流工具）README：

> "**JIT:** Enable Just-In-Time compilation for sideloaded apps that have the `get-task-allow` entitlement."
> 兼容表：`17.4 – 18.x | Fully supported`；`26.0+ | Supported | Limited App Availability (Developers need to update their apps to work.)`
> 功能表：`Scripts: Manage automation scripts (mainly used for iOS 26 JIT)`
> —— <https://github.com/StikDebug/StikDebug>

**【已验证】** 为什么 iOS 26 之后"光附加调试器不够"——StikJIT 集成文档（一手、且是给 App 开发者看的）：

> "The process receiving JIT must have `get-task-allow`."
> "On a device where TXM/SPTM is not present, attaching and detaching the debugger is enough to enable JIT. **Where TXM/SPTM is present, the debugger flag alone is not enough: each executable memory region must be prepared through the debug connection before the app executes code from it.**"
> "The host app's JIT memory allocator must implement the matching breakpoint protocol."
> —— <https://raw.githubusercontent.com/StikDebug/StikJIT/main/INTEGRATION.md>

这意味着：**对新系统（存在 TXM/SPTM）而言，只有"自己实现 JIT 分配器"的 App 才可能真正用上被开启的 JIT**（例如模拟器、Java VM）。HTMLRunner 没有自研 JIT 引擎，网页 JS 也不在它进程里，因此这条新协议对本项目基本无意义——**它解释了"为什么列表里能看见、但普通 App 也不会有性能变化"**。

关于设备是否具备 TXM/SPTM：本次**没有找到可靠的一手资料把 TXM/SPTM 与 M4 芯片对应起来**（StikDebug 会在界面显示 TXM/SPTM 状态，见第 9 节）。**无法直接确认。**

---

## 3. 侧载工具（NB助手等）识别 App 的条件

### 3.1 已验证的事实

1. **列表的准入条件 = 该 App 的签名里带 `get-task-allow`。** SideStore 官方文档在"启用 JIT"步骤里写得很直白：
   > "Select an app from the list (**must be sideloaded with get-task-allow to appear in the list**) to attach a debugger and activate JIT functionality."
   > —— <https://docs.sidestore.io/docs/advanced/jit>
2. **工具侧也只承诺支持带该 entitlement 的 App**（StikDebug README，见 2.3 引用）；StikJIT 集成文档要求宿主 App **自检**该 entitlement，并用 `SecTaskCopyValueForEntitlement` 实现（上文代码）。
3. **工具需要的外部前置条件（与 App 内容无关）**：iOS/iPadOS 17.4+ 需要 **loopback VPN（如 LocalDevVPN）+ pairing file + 挂载 DDI**；iOS 26.4 起改用五文件 cryptex DDI（StikJIT 文档；SideStore 文档）。StikDebug README 列出：pairing file、LocalDevVPN、SideStore/AltStore 等。
4. **NB助手（NB 全能助手 / NB Pro）官方文档的实际情况：我们只找到官网 <https://nbtool8.com/> 与帮助中心 <https://nbtool8.com/help-center.html>，其中宣传/记录的功能是：IPA 签名（可用 Apple ID）、虚拟定位、App Store 应用降级、免 Wi-Fi 安装、支持 iOS 13+/"全面支持 iOS26.4 及以上系统"，帮助中心只有"安装失败 / 需 iTunes / 需锁屏密码 / 没有开发者模式"等排障内容。**
   **→ 官方站点上没有任何关于 JIT、`get-task-allow`、内存管理列表的文档（明确结论：不存在官方 JIT 说明文档）。**
5. **能证明 NB助手确实提供"开启 JIT"功能的只有第三方来源**，例如 B 站视频标题 *"IOS设备使用NB助手免电脑签名并开启JIT权限 — 支持PojavLauncher启动器"*（<https://www.bilibili.com/video/av576106870/>），以及第三方教程（<https://blog.yizong.de/posts/ios-nb/>、<https://www.mancs.cn/31.html>，两篇都只讲签名/续签，**均未提到 JIT**）。这些来源权威性低，只能证明"存在该功能入口"，**不能证明其实现细节**。
6. **"内存管理"大概率对应 Apple 的两个内存 entitlement**（PojavLauncher 的 entitlements 文件里正是这两个）：
   > "Add this entitlement to your app to inform the system that some of your app's core features may perform better by exceeding the default app memory limit on supported devices."
   > —— `com.apple.developer.kernel.increased-memory-limit`，<https://developer.apple.com/documentation/bundleresources/entitlements/com.apple.developer.kernel.increased-memory-limit>
   同族：`com.apple.developer.kernel.extended-virtual-addressing`。这类 entitlement **必须由签名/描述文件允许**，普通免费 Apple ID 的描述文件一般不含它。

### 3.2 推断（未直接证实）

- 【推断】NB助手很可能与 StikDebug/SideJITServer 同类：枚举设备上已安装的 App，筛出带 `get-task-allow` 的条目，然后通过 iOS 的调试服务（idevice/lockdown + VPN 隧道 + DDI）附加。
- 【推断】"内存管理"很可能是通过**给已安装 App 重新签名并注入 entitlements / 使用特殊证书**实现的（与"签名安装"同一个流程），因为 iOS 不允许运行期修改别的进程的 entitlements。
- 【推断】NB助手需要"开发者模式"（官网帮助中心明确要求用户在 设置 → 隐私与安全性 → 开发者模式 中开启），这与 17.4+ 的调试服务/DDI 前提一致。

### 3.3 未知（本项目无法确认）

- NB助手 JIT 列表的**具体过滤逻辑**（是否额外要求 UDID 绑定、是否读取 `application-identifier`、是否排除系统 App）。
- NB助手是否内置 pairing file 管理 / VPN（官网教程里提到它自己会安装一个名为 "NB Tool" 的 VPN 配置用于签名通信；这与 JIT 用的 loopback VPN 是否同一个，**未知**）。
- NB助手"内存管理"是否真的改写了 `increased-memory-limit`（**无法确认**，只能实测 `os_proc_available_memory()` 前后对比）。
- NB助手是否有官方 JIT 文档（**结论：没有找到任何官方文档**）。

---

## 4. 本 App 是否会出现在 JIT 候选列表

**核心结论：能不能"出现"，由签名方式决定，与 App 的代码无关。**

| 安装方式 | 签名里 `get-task-allow` | 是否会出现在此类 JIT 列表 | 依据 |
|---|---|---|---|
| NB助手 / AltStore / SideStore 用**个人 Apple ID**自签 | true（开发类证书必带） | **会**（在工具本身支持该系统的前提下） | 【已验证】SideStore 原文 +【推断】个人证书特性 |
| Xcode 直接跑到设备（开发描述文件） | true | **会** | 【已验证】PojavLauncher README |
| 企业 / 共享 / 分发证书签名（"签名服务"、TF 签） | false（或受限） | **不会** | 【已验证】PojavLauncher README："Signing services that do not use your UDID (and use distribution certificates) are not supported" |
| App Store / TestFlight 安装 | false | **不会** | 【推断，与上一条同源机制】 |
| TrollStore / 越狱安装 | 不依赖它（可用 `dynamic-codesigning` 等） | 通常由工具/系统直接给 JIT，不走"附加调试器"路线 | 【已验证】PojavLauncher Wiki + entitlements.xml |

因此，对 HTMLRunner：
1. **如果**它和 PojavLauncher 一样是用个人 Apple ID 自签装的，那么它**会**出现在同一类列表里（这也解释了用户此前的观察：PojavLauncher 出现在列表里）。**【推断】**
2. 出现之后，工具能做的只是"attach App 进程 → 置 `CS_DEBUGGED`"。**【已验证】** 而 HTMLRunner 进程内没有 JIT 引擎（SwiftUI + WKWebView），所以**这个操作对本 App 的实际性能没有可预期的收益**。**【推断】**
3. **无法直接确认**：NB助手在你的设备上到底会不会列出 HTMLRunner——这取决于它的过滤逻辑（未知）与你的签名方式（可自查，见第 9 节）。**最可靠的判断方法就是：装好后打开工具的 JIT 页，看 HTMLRunner 是否在列表里。**
4. **不建议**为了"上列表"而修改 IPA 的 entitlements、重签或注入（既违反 Apple 的安全模型，也会破坏签名有效性）。App 侧唯一合理做法是在诊断页展示自身的 `get-task-allow` / `CS_DEBUGGED` 状态。

---

## 5. WebContent 进程的 JIT 归属问题（关键结论）

**问题：把 HTMLRunner 的 JIT 打开，会不会让 WKWebView 里的 JS/WASM 得到 JIT？**

**答案：不会，也不需要通过这种方式获得。原因是 JIT 权限是"逐进程"的，而 WebContent 是 Apple 自己签名的系统进程。**

逐条论证：

1. **JIT 权限属于执行 JIT 的那个进程。**【已验证】Apple 对外说明 `allow-jit` 的作用是让**该 App** 能用 `MAP_JIT` 创建可写可执行内存；没有它，相关框架"may fall back to an interpreter"。（<https://developer.apple.com/documentation/bundleresources/entitlements/com.apple.security.cs.allow-jit>）
2. **WebContent 的 entitlements 由 Apple 的构建脚本写入，与宿主 App 无关。**【已验证】`process-entitlements.sh` 在 iOS 上给 `com.apple.WebKit.WebContent` 写入 `com.apple.private.verified-jit` + （SDK ≥ 17.4）`com.apple.developer.cs.allow-jit`，更早版本写 `dynamic-codesigning`。（URL 见 1.3）
   → 注意：**任务假设里的"只有 `dynamic-codesigning`、且只给系统 WebKit"在方向上正确，但细节已过时**：iOS 17.4 之后这个 entitlement 名字变成了 `com.apple.developer.cs.allow-jit`。这一点必须按新版本表述。
3. **WebContent 里的 JIT 默认开启。**【已验证】只有三种情况会关：用户开锁定模式（同时关 WASM）、Enhanced Security、宿主通过私有 API 下发 `disable-jit`（`XPCServiceEntryPoint.mm::setJSCOptions`，URL 见 1.4）。
4. **第三方 App 无法把自己的 entitlements 传给 WebContent。**【已验证】WebContent 的启动参数只有 JSC 选项、语言、内存断言等（`ProcessLauncherCocoa.mm` 里的 bootstrap message 字段），**没有任何"继承宿主 entitlements"的通道**。（URL 见 1.1）
5. **第三方 App 也几乎无法把自己的 WebKit 换成自己签名、自己带 JIT 权限的引擎。** Apple 只给极少数主体开放这条路：
   > "An entitlement that enables your browser app to implement an alternative browser engine." / "To use the entitlement, request it from Apple. The steps to request the entitlement vary by geographic region: European Union / Japan."
   > —— `com.apple.developer.web-browser-engine.host`，iOS/iPadOS 17.4+，<https://developer.apple.com/documentation/bundleresources/entitlements/com.apple.developer.web-browser-engine.host>
   （需要 Apple 批准 + 地区限制，对 HTMLRunner 不适用。）

**因此，对 HTMLRunner 的准确表述是：**
- "在 NB助手/StikDebug 里给 HTMLRunner 开 JIT" **不会改变** WKWebView 内 JS/WASM 的 JIT 状态；那个状态由**系统 WebKit + 用户设置**决定，默认是开的。
- 如果网页跑得慢，**不要**指望这个开关；应该去看渲染/内存/热节流等真正的原因。
- **无法直接确认**：没有任何公开 API 能读取 WebContent 的 JIT 状态。我们只能通过源码与间接证据判断"默认开"。
- **反例（重要）**：如果用户开了**锁定模式**，WebContent 会 `disableJIT()` **并且** `useWasm() = false`——这时网页既没有 JIT 也没有 WASM，而**任何侧载工具都无法改变它**。这是验证时最容易踩的坑。

---

## 6. 如何在真机上验证

### 6.1 原生侧：只能确认"App 自己"的状态

> **本 App 已经把这三种检测全部实现了。** 打开「诊断 → JIT 诊断」即可看到实时结果，
> 也可以点「复制完整 JIT 检测报告」导出文本。实现位置
> `HTMLRunner/Diagnostics/ProcessDebugState.swift`，报告渲染
> `HTMLRunner/Diagnostics/JITReportExporter.swift`。判定逻辑有配套的离线单元测试
> （`project-tests/harness/logic.test.js` 的「JIT 权限判定」一节），因此位掩码与判定规则
> 在 CI 里被验证过，只有真正的 syscall 必须上真机。
>
> 实现采用的是 **`csops` + `CS_DEBUGGED`**（下文的 (b)），而不是只看 `P_TRACED`，
> 因为前者正是侧载工具自己用的判据，结论才能与工具一致。同时仍保留 `sysctl(P_TRACED)`
> 做交叉校验：两者不一致时报告会明确写出来，而不是挑一个看起来更好的。

**(a) 查 `get-task-allow`**（判断"会不会出现在 JIT 列表"的最直接依据，代码来自 StikJIT 官方集成文档）：

```objc
void* SecTaskCreateFromSelf(CFAllocatorRef allocator);
CFTypeRef SecTaskCopyValueForEntitlement(void* task, CFStringRef entitlement, CFErrorRef* error);

static bool HasGetTaskAllow(void) {
    void* task = SecTaskCreateFromSelf(NULL);
    if (task == NULL) return false;
    CFTypeRef value = SecTaskCopyValueForEntitlement(task, CFSTR("get-task-allow"), NULL);
    bool result = value == kCFBooleanTrue;
    if (value != NULL) CFRelease(value);
    CFRelease(task);
    return result;
}
```
（StikJIT 文档明确提醒：*"This uses Security framework SPI on iOS and is not App Store-safe."*；同时提醒"在 helper 里检查会检查错可执行文件"——只有宿主进程自己检查才对。）

**(b) 查是否被调试器附加（= JIT 是否已对该进程生效）**，PojavLauncher / Delta 风格：

```objc
#define CS_DEBUGGED 0x10000000
int csops(pid_t pid, unsigned int ops, void *useraddr, size_t usersize);
int flags = 0;
csops(getpid(), 0 /* CS_OPS_STATUS */, &flags, sizeof(flags));
bool jitLikelyOn = (flags & CS_DEBUGGED) != 0;
```

同一个状态字里还有几个值得一起读的位（Apple 的 `ProcessCodeSigningFlags`）：
`CS_VALID = 0x1`、`CS_HARD = 0x100`、`CS_KILL = 0x200`、`CS_RESTRICT = 0x800`。
本 App 会把它们全部打印出来——一个"没有 `CS_DEBUGGED` 但有 `CS_HARD | CS_KILL`"的进程，
和一个"根本读不到状态字"的进程，是完全不同的两种情况。

### 6.1.1 「为什么我的侧载工具里看不到这个 App」排查顺序

按下面的顺序查，每一步都有明确的是/否，不要跳步：

| 步骤 | 在哪里看 | 期望值 | 不对说明什么 |
|---|---|---|---|
| 1. App 里有没有 `get-task-allow`？ | App →「诊断 → JIT 诊断」的 `get-task-allow` 一行 | **存在** | 若为「不存在」，说明**当前安装的这份没有被重签上该 entitlement**。未签名的 IPA 直接装上去不会带它；必须由签名工具用带调试权限的描述文件重签。这是"列表里看不到"最常见的原因 |
| 2. `CS_DEBUGGED` 是否置位？ | 同一页的 `CS_DEBUGGED` 一行 | 工具**开启 JIT 之前**应为「否」，开启后变「是」 | 一直为「否」→ 工具并没有真的把调试器附加到这个进程上 |
| 3. 工具是否支持当前系统？ | 工具自己的界面（如 StikDebug 的 TXM/SPTM 状态） | 工具声明支持 | iOS 26+/iPadOS 27 在带 TXM/SPTM 的机型上机制有变化，部分工具需要目标 App 实现断点协议；这不是本 App 能补上的 |
| 4. 状态字能不能读到？ | 同一页的「csops 状态字」 | 形如 `0x...` 的十六进制值 | 显示「无法读取」→ 连状态字都拿不到，工具链大概也没拿到 |

**把这一页截图发给我**（或点「复制完整 JIT 检测报告」把文本贴过来），我就能判断卡在哪一步——
这些值是设备上测出来的真实状态，比反复猜测快得多。

**必须强调：** 第 1 步结果只决定"工具会不会把它列出来"，第 2 步结果只说明"**App 进程**的 JIT 权限"。
**两者都不代表 WKWebView 里的 JavaScript 获得了解释器以外的执行方式**，原因见第 5 节。

**(c) 传统 `sysctl` + `P_TRACED`（Apple QA1361 原文代码）**：

```c
mib[0] = CTL_KERN; mib[1] = KERN_PROC; mib[2] = KERN_PROC_PID; mib[3] = getpid();
size = sizeof(info);                     // struct kinfo_proc info;
junk = sysctl(mib, sizeof(mib)/sizeof(*mib), &info, &size, NULL, 0);
return ((info.kp_proc.p_flag & P_TRACED) != 0);
```
（<https://developer.apple.com/library/archive/qa/qa1361/_index.html>；`#define P_TRACED 0x00000800 /* Debugged process being traced */` 见 XNU <https://raw.githubusercontent.com/apple-oss-distributions/xnu/main/bsd/sys/proc.h>）

> **三者都只描述 App 进程**，它们**不能**告诉你 WebContent 的 JIT 状态。（对应任务书的要求：必须写明这一点。）

### 6.2 网页侧：只有间接信号

| 手段 | 能说明什么 | 不能说明什么 |
|---|---|---|
| `typeof WebAssembly` | 若为 `undefined`：**有意义的证据**——按 WebKit 源码，只有锁定模式等路径会 `useWasm() = false`；若存在，说明没走这条路 | 不能证明 JIT 开着（WASM 有 IPInt/LLInt 解释器层） |
| 热循环基准（同页多次、多档规模、去掉首轮预热） | 只能给出"当前性能水平" | **绝不能当作 JIT 证据**：会受热节流、调度、后台状态、内存压力影响 |
| **锁定模式开/关对照同一页面** | 这是一个真正有对照意义的实验：锁定模式会强制关闭 JIT+WASM，可作为"无 JIT 下界"参照；若两档性能接近，说明瓶颈可能不在 JS 编译层 | 仍然只是间接推断，不是 JIT 读数 |
| `performance.now()` / `navigator.hardwareConcurrency` | 辅助诊断 | 与 JIT 无关 |
| Safari Web Inspector 附加 | 确认页面确实跑在 WebContent、能看 profile | Inspector 不显示 JIT 开关状态 |

### 6.3 结构性事实核实（不是开关核实）

- 用 Xcode 的 Devices/Processes 或 `ps`（越狱/调试环境下）可以看到 `com.apple.WebKit.WebContent` 进程与宿主 App 并存 → 证实"JS 不在 App 进程"。
- 用 `WKWebView` 的 `configuration.processPool`（私有 `_WKProcessPoolConfiguration.JITEnabled`）**只能关不能开**（默认开）。**不建议在产品中使用该私有 API**（App Store 不安全，且无收益）。

### 6.4 局限性总表

| 结论 | 能否在真机上确认 | 说明 |
|---|---|---|
| HTMLRunner 带 `get-task-allow` | ✅ 可确认 | 6.1(a) 自检；或看工具列表里有没有它 |
| HTMLRunner 被调试器附加（`CS_DEBUGGED` / `P_TRACED`） | ✅ 可确认（仅 App 进程） | 6.1(b)(c) |
| HTMLRunner 出现在 NB助手/StikDebug 的 JIT 列表 | ✅ 可确认（打开工具看一眼即可） | 取决于签名与工具逻辑 |
| WebContent 是否带 JIT entitlements | ❌ 无法直接确认 | WebContent 是系统进程，设备上无法 `codesign -d --entitlements`；只能依据 WebKit 源码 |
| WebContent 内 JIT 当前是否真的在编译 | ❌ 无法直接确认 | 没有公开 API/计数器 |
| 网页"变快"是因为 JIT | ❌ 不能证明 | 基准只能给性能水平，不能给归因 |
| iPadOS 27 + M4 上工具的 JIT 是否可用 | ❌ 资料无法确认 | 见第 9 节，需要实机测试 |

---

## 7. 超出 App 控制范围的行为

**完全不在 HTMLRunner 控制内：**

1. **是否出现在任何 JIT 列表里**——由签名（`get-task-allow`）和工具实现决定。
2. **工具能否成功附加**——依赖 iOS/iPadOS 版本、TXM/SPTM 是否存在、DDI 是否挂载、pairing file、loopback VPN、开发者模式、工具自身对新系统的适配。
3. **WebContent 的 JIT 开关**——由 Apple 的 WebKit、系统策略、用户设置（尤其**锁定模式**）决定；App 只能"关"（私有 API）不能"开"。
4. **系统 WebKit 的版本与实现**——随 iPadOS 更新而变化（例如 17.4 换了 JIT entitlement 名字；iOS 26 又改变了 JIT 启用协议）。
5. **内存上限**——`increased-memory-limit` / `extended-virtual-addressing` 是否生效由**描述文件/证书**决定；普通个人证书通常不给。
6. **热节流与性能**——散热、后台策略、并发进程（WebContent/GPU/Networking 各自有内存与 CPU 限制）。
7. **Apple 的替代浏览器引擎路线**——需要 Apple 批准且限 EU/日本，对普通 App 不可用。

**明确不做（也不建议做）：** 伪造 entitlements、伪造签名、绕过 Apple 的代码签名/调试服务限制、通过注入方式给系统 WebContent 添加权限。

---

## 8. 参考资料

| URL | 该来源确立了什么 |
|---|---|
| <https://github.com/PojavLauncherTeam/PojavLauncher_iOS> | JIT 需要"被调试"；分发证书不行、开发证书因 `get-task-allow` 可行 |
| <https://raw.githubusercontent.com/PojavLauncherTeam/PojavLauncher_iOS/main/Natives/utils.m>、`.../Natives/utils.h` | `isJITEnabled()` 的实际实现：`dynamic-codesigning` 或 `csops` 的 `CS_DEBUGGED`（0x10000000） |
| <https://raw.githubusercontent.com/PojavLauncherTeam/PojavLauncher_iOS/v2.2/entitlements.xml> | TrollStore/越狱路线使用的受限 entitlements（no-sandbox、memorystatus、memory-limit…） |
| <https://pojavlauncherteam.github.io/wiki/faq/ios/JIT.html> | 侧载工具如何通过 debug server 开 JIT；iOS 17.0.1+ 改用 pymobiledevice3 |
| <https://docs.sidestore.io/docs/advanced/jit> | **列表准入条件原文**（must be sideloaded with get-task-allow）；17.4+ 前置条件；2026-06-17 关于 iOS 26.6/27 的支持范围 |
| <https://github.com/StikDebug/StikDebug> | 工具定位："sideloaded apps that have the `get-task-allow` entitlement"；26.0+ 支持受限；Scripts 用于 iOS 26 JIT |
| <https://raw.githubusercontent.com/StikDebug/StikJIT/main/INTEGRATION.md> | "The process receiving JIT must have `get-task-allow`"；TXM/SPTM 需要断点协议；自检代码；DDI 挂载 |
| <https://raw.githubusercontent.com/WebKit/WebKit/main/Source/WebKit/Scripts/process-entitlements.sh> | **WebContent 的 JIT entitlements 由 Apple 写入**：iOS ≥17.4 为 `com.apple.developer.cs.allow-jit` + `com.apple.private.verified-jit`，更早为 `dynamic-codesigning` |
| <https://raw.githubusercontent.com/WebKit/WebKit/main/Source/WebKit/Shared/EntryPointUtilities/Cocoa/XPCService/XPCServiceEntryPoint.mm> | `setJSCOptions()`：JIT 默认开；锁定模式 `disableJIT()`+`useWasm()=false`；`disable-jit`/Enhanced Security 也会关 |
| <https://raw.githubusercontent.com/WebKit/WebKit/main/Source/WebKit/UIProcess/Launcher/cocoa/ProcessLauncherCocoa.mm>、`.../Launcher/ProcessLauncher.h` | WebContent 服务名选择；`nonValidInjectedCodeAllowed` 默认 false；`isJITEnabled()` 默认 true |
| <https://raw.githubusercontent.com/WebKit/WebKit/main/Source/WebKit/Configurations/WebContentService.xcconfig> | WebContent 的四个变体产品名（Normal/Development/CaptivePortal/EnhancedSecurity） |
| <https://bugs.webkit.org/show_bug.cgi?id=187355> | Development 变体的用途（给注入 bundle 的客户端做开发） |
| <https://raw.githubusercontent.com/WebKit/WebKit/main/Source/JavaScriptCore/runtime/OptionsList.h> | `useJIT` 默认值、`useWasm`/`useWasmIPInt`/`useLLInt` → WASM 有解释器层，故"WASM 可用≠JIT 开" |
| <https://bugs.webkit.org/show_bug.cgi?id=261403> | WebKit 自己的 bug："WASM should not depend on JIT"（含 "can run some simple wasm in the no jit case"） |
| <https://developer.apple.com/documentation/bundleresources/entitlements/com.apple.security.cs.allow-jit> | allow-jit 语义：`MAP_JIT`；没有它框架可能退回解释器 |
| <https://developer.apple.com/documentation/bundleresources/entitlements/com.apple.developer.web-browser-engine.host> | 第三方自带浏览器引擎（自有 WebContent+JIT）必须向 Apple 申请，且限 EU/日本 |
| <https://developer.apple.com/documentation/bundleresources/entitlements/com.apple.developer.kernel.increased-memory-limit> | "内存管理"对应的官方 entitlement |
| <https://developer.apple.com/documentation/webkit/wkwebview/loadfileurl(_:allowingreadaccessto:)> | `loadFileURL` 的参数约束原文（readAccessURL 只授予读权限，不改安全模型） |
| <https://developer.mozilla.org/en-US/docs/Web/HTTP/Guides/CORS/Errors/CORSRequestNotHttp> | `file://` 被视为 opaque origin → fetch/XHR 等 CORS 请求会失败 |
| <https://developer.apple.com/library/archive/qa/qa1361/_index.html> | `sysctl(KERN_PROC_PID)` + `kinfo_proc.p_flag & P_TRACED` 的官方示例（只针对自身进程） |
| <https://raw.githubusercontent.com/apple-oss-distributions/xnu/main/bsd/sys/proc.h> | `#define P_TRACED 0x00000800` |
| <https://nbtool8.com/>、<https://nbtool8.com/help-center.html> | NB助手官方站点：功能为签名/虚拟定位/降级/免 Wi-Fi；**没有 JIT 或内存管理文档** |
| <https://www.bilibili.com/video/av576106870/>、<https://blog.yizong.de/posts/ios-nb/>、<https://www.mancs.cn/31.html> | 低权威第三方：NB助手可开启 JIT（仅标题级证据）；其签名流程与"开发者模式"要求 |
| <https://www.volcengine.com/article/2025326> | 低权威：`WKURLSchemeHandler` 处理 `fetch` 需要 CSP `connect-src` 与 CORS 响应头（**待实测**） |

---

## 9. 尚未确认 / 需要在真机上确认的点（检查清单）
1. **iPadOS 27 + M4 上 StikDebug/NB助手的 JIT 是否可用**
   - 已找到的一手信息只有 SideStore 文档的 2026-06-17 备注（"26.6 和 27 只有少数 App 可用"，且 DukeX 只在 A13/A14/M1 上支持到 27）；二手博客（<https://techybuff.com/enable-jit-iphone-without-computer-ios-27/>，2026-10-07）声称 iOS 27 可用。**两者都没有提到 M4。→ 必须实测。**
   - 真机检查：在 StikDebug 里打开设置，查看 **TXM/SPTM 状态**（`Present` / `Not Present` / `Unknown`）与它列出的 App；在 NB助手里打开 JIT 页看列表内容。
2. **HTMLRunner 是否出现在列表里**
   - 真机检查：装好后直接看列表；同时在 App 内用 6.1(a) 打印 `HasGetTaskAllow()` 结果作为对照。
3. **NB助手的 JIT/内存管理实现与门槛**（无官方文档）
   - 真机检查：对比开启"内存管理"前后 `os_proc_available_memory()`（Apple: <https://developer.apple.com/documentation/os/os_proc_available_memory>）与 `get-task-allow` / `dynamic-codesigning` / `increased-memory-limit` 的自检结果。
4. **WebContent 是否走了 Development 变体**（本次只定位到 `nonValidInjectedCodeAllowed`，未找到其赋值点）
   - 真机检查：在 Xcode 的进程列表（或调试环境下的 `ps`）里确认进程名是 `com.apple.WebKit.WebContent` 而不是 `...WebContent.Development`。
5. **`file://` 下 `fetch`/ES module/WASM 流式实例化是否被拒**
   - 真机检查：放一个测试页，分别调用 `fetch('game.glb')`、`new WebAssembly.instantiateStreaming(fetch('m.wasm'))`、`import('./m.js')`，把错误信息打印到页面；若被拒，则改用 `WKURLSchemeHandler` 或本地 HTTP 服务，并重测同一组用例。
6. **锁定模式对照实验**（唯一有对照意义的性能实验）
   - 真机检查：设置 → 隐私与安全性 → 锁定模式，开/关各跑一次同一测试页，记录 `typeof WebAssembly` 与热循环耗时；两档差异可作为"解释器/无 WASM 下界"的参考，但**仍然不能当作 JIT 读数**。
7. **网页 vs 原生 JSC 的性能对照（可选，间接）**
   - 思路：在 App 进程内用 `JSContext` 跑同一段热循环，与 WKWebView 内的结果比较。App 进程在未附加调试器时通常走解释器路径，附加后可能变化——这可以间接反映"进程级 JIT 权限"的影响，但**属于间接证据，且受多种因素干扰，不能作为 JIT 证明**。

---

## 10. 真机实测记录（2026-10-12，iPad16,4 / iPadOS 27.0.1 build 24A446）

这是本 App **第一次在真机上运行**。IPA 为 `HTMLRunner 1.0.1 (3)`，Release 构建，
由 NB 助手（第三方侧载签名工具）签名安装。App 内「诊断 → JIT 诊断」的原始输出：

```
判定: 本进程不具备 JIT 条件

csops(CS_OPS_STATUS) 调用: 成功
状态字 p_flag: 0x22003301
CS_DEBUGGED: 未置位
CS_VALID: 是
CS_HARD: 是
CS_KILL: 是
CS_RESTRICT: 否
已置位标志: CS_VALID, CS_HARD, CS_KILL

sysctl(KERN_PROC_PID).P_TRACED: 未置位
两种读取方式一致: 是

get-task-allow = false
```

### 10.1 从这些值能确定什么

1. **检测链路本身在真机上工作正常**：`csops` 调用成功、状态字读到了、两种内核读取方式结论一致。
   这验证了第 6.1 节的做法（也是 Delta / PojavLauncher / LiveContainer 的做法）在 iPadOS 27 上依然可用。
2. **`get-task-allow` 是被"写成 false"的，不是缺失。** 报告显示 `= false`。
   如果该键根本不存在，读取会返回 nil，报告会写「不存在」。所以**签名工具用了不带调试权限的凭据**，
   并把 `false` 写进了二进制。
   → 这正是「NB 助手检测不到本 App」的原因：这类工具的判据是 `get-task-allow == true`。
3. **`CS_HARD | CS_KILL` 同时置位**，且无 `CS_DEBUGGED`：这是**受限签名**的特征——
   内核被授权在签名失效时直接终止进程。这种签名**永远无法被调试器附加**，
   所以任何依赖"附加调试器"来开启 JIT 的工具都不可能对它生效。
4. 因此 `CS_DEBUGGED` 未置位是**签名方式的必然结果**，不是 App 的缺陷，也不是工具没工作。

### 10.2 由此得到的操作结论

* 想让 App 出现在 JIT 工具列表里，**必须换用带 `get-task-allow = true` 的签名**
  （通常是免费 Apple ID 的本地自签，而不是分发证书）。这一步只能在设备侧、用你的凭据完成。
* **但即使换成功，网页 JS 也不会变快**，理由见第 5 节：网页跑在 Apple 签名的
  `com.apple.WebKit.WebContent` 里，那个进程本来就带着 `com.apple.developer.cs.allow-jit`
  （SDK ≥ 17.4）或 `dynamic-codesigning`。给宿主 App 开 JIT 改的是宿主进程，
  而宿主进程里只有 SwiftUI 和诊断代码。
* **唯一能真正改变网页 JS 执行方式的开关是系统锁定模式**（会同时禁用 JIT 与 WebAssembly），
  对照实验方法见第 6 节。

### 10.3 仍然未知的

* 网页（WebContent）进程的实际 JIT 状态——**原理上不可读**，本次实测没有改变这一点。
* 本 App 的导入流程、WebGL 渲染、内存水位在真机上的表现：本次只验证了 JIT 检测页，
  其余功能仍待验收（见 `docs/TEST-PLAN.md` 第四节）。
* 白屏 / 自动刷新 / 进程退出等最初诉求的成因：需要「日志」页内容才能判断，
  与 JIT 无关（更可能是内存回收或资源路径问题）。

