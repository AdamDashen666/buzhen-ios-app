/*
 * logic.test.js — Node-only tests for the project's pure logic.
 *
 * WHY THIS FILE EXISTS
 * --------------------
 * The Swift sources cannot be compiled on this machine (no Xcode, no macOS), and
 * the device-dependent parts cannot be executed anywhere but on an iPad. What CAN
 * be checked is the *algorithmic* content of the platform-independent pieces:
 * HTTP parsing, byte-range arithmetic, path-traversal defence, import planning and
 * name sanitisation. Those rules are duplicated here in JavaScript — deliberately,
 * as an executable specification — so that a change in behaviour is visible in a
 * test rather than only in review.
 *
 * The JavaScript implementations below mirror `HTMLRunner/Web/LocalHTTPServer.swift`
 * and `HTMLRunner/FileManagement/ProjectStore.swift`. When one is changed, the other
 * must change too; `expectMirrors` exists to make that obligation explicit.
 *
 * Run:  node project-tests/harness/logic.test.js
 */

'use strict';

const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');

const results = [];
let failures = 0;

function test(name, fn) {
  try {
    fn();
    results.push({ name, passed: true });
    console.log(`  ✔ ${name}`);
  } catch (error) {
    failures += 1;
    results.push({ name, passed: false, error: String(error && error.message ? error.message : error) });
    console.log(`  ✘ ${name}\n      ${error && error.message ? error.message : error}`);
  }
}

function section(title) {
  console.log(`\n${title}`);
}

// ---------------------------------------------------------------------------
// Mirrors: HTTPRequestParser.parseHead (Swift)
// ---------------------------------------------------------------------------

const MAX_HEADER_BYTES = 32 * 1024;
const MAX_BODY_BYTES = 8 * 1024 * 1024;

function parseHead(data) {
  const text = data.toString('utf8');
  const terminatorIndex = text.indexOf('\r\n\r\n');
  if (terminatorIndex === -1) {
    return data.length > MAX_HEADER_BYTES
      ? { error: 'tooLarge' }
      : { error: 'incomplete' };
  }
  const headerText = text.slice(0, terminatorIndex);
  const lines = headerText.split('\r\n');
  const requestLine = lines.shift();
  const parts = requestLine.split(' ').filter((part) => part.length > 0);
  if (parts.length !== 3) return { error: `malformed: ${requestLine}` };
  if (!parts[2].startsWith('HTTP/1.')) return { error: `version: ${parts[2]}` };

  const headers = {};
  for (const line of lines) {
    if (line === '') continue;
    const colon = line.indexOf(':');
    if (colon === -1) continue;
    const key = line.slice(0, colon).trim().toLowerCase();
    const value = line.slice(colon + 1).trim();
    if (!key) continue;
    headers[key] = headers[key] ? `${headers[key]}, ${value}` : value;
  }

  let bodyLength = 0;
  if (headers['content-length'] !== undefined) {
    const parsed = Number(headers['content-length']);
    if (!Number.isInteger(parsed) || parsed < 0) return { error: 'malformed: content-length' };
    if (parsed > MAX_BODY_BYTES) return { error: 'tooLarge' };
    bodyLength = parsed;
  }

  return {
    method: parts[0].toUpperCase(),
    target: parts[1],
    version: parts[2],
    headers,
    bodyLength,
    headerByteCount: headerText.length + 4
  };
}

section('HTTP 请求头解析（对照 Swift HTTPRequestParser）');

test('解析标准 GET 请求行', () => {
  const head = parseHead(Buffer.from('GET /index.html HTTP/1.1\r\nHost: 127.0.0.1\r\n\r\n'));
  assert.strictEqual(head.method, 'GET');
  assert.strictEqual(head.target, '/index.html');
  assert.strictEqual(head.version, 'HTTP/1.1');
  assert.strictEqual(head.headers.host, '127.0.0.1');
});

test('头部不完整时返回 incomplete（调用方应继续读）', () => {
  const head = parseHead(Buffer.from('GET /index.html HTTP/1.1\r\nHost: 127'));
  assert.strictEqual(head.error, 'incomplete');
});

test('头部过大时返回 tooLarge', () => {
  const head = parseHead(Buffer.from('GET / HTTP/1.1\r\nX: ' + 'a'.repeat(MAX_HEADER_BYTES + 10)));
  assert.strictEqual(head.error, 'tooLarge');
});

test('请求行字段数不为 3 时判为格式错误', () => {
  const head = parseHead(Buffer.from('GET /index.html\r\n\r\n'));
  assert.ok(head.error && head.error.startsWith('malformed'));
});

test('拒绝非 HTTP/1.x 协议', () => {
  const head = parseHead(Buffer.from('GET / HTTP/2.0\r\n\r\n'));
  assert.ok(head.error && head.error.startsWith('version'));
});

test('header 名统一转小写，重复 header 用逗号连接', () => {
  const head = parseHead(Buffer.from('GET / HTTP/1.1\r\nX-Test: a\r\nx-test: b\r\n\r\n'));
  assert.strictEqual(head.headers['x-test'], 'a, b');
});

test('method 统一转大写', () => {
  const head = parseHead(Buffer.from('head / HTTP/1.1\r\n\r\n'));
  assert.strictEqual(head.method, 'HEAD');
});

test('Content-Length 为负判为格式错误', () => {
  const head = parseHead(Buffer.from('POST / HTTP/1.1\r\nContent-Length: -5\r\n\r\n'));
  assert.ok(head.error && head.error.startsWith('malformed'));
});

// ---------------------------------------------------------------------------
// Mirrors: HTTPRangeParser.parse (Swift)
// ---------------------------------------------------------------------------

function parseRange(header, fileSize) {
  if (header === null || header === undefined || header === '') return { type: 'full' };
  const trimmed = header.trim();
  if (!trimmed.toLowerCase().startsWith('bytes=')) return { type: 'malformed' };
  const spec = trimmed.slice('bytes='.length);
  if (spec.includes(',')) return { type: 'malformed' };
  const bounds = spec.split('-');
  if (bounds.length !== 2) return { type: 'malformed' };

  const startText = bounds[0].trim();
  const endText = bounds[1].trim();

  if (startText === '') {
    const suffix = Number(endText);
    if (!Number.isInteger(suffix) || suffix <= 0) return { type: 'malformed' };
    if (fileSize === 0) return { type: 'unsatisfiable' };
    const length = Math.min(suffix, fileSize);
    return { type: 'partial', start: fileSize - length, end: fileSize - 1 };
  }

  const start = Number(startText);
  if (!Number.isInteger(start)) return { type: 'malformed' };
  if (start >= fileSize) return { type: 'unsatisfiable' };
  if (endText === '') return { type: 'partial', start, end: fileSize - 1 };

  const end = Number(endText);
  if (!Number.isInteger(end) || end < start) return { type: 'malformed' };
  return { type: 'partial', start, end: Math.min(end, fileSize - 1) };
}

section('Byte-Range 解析（对照 Swift HTTPRangeParser）');

test('无 Range 头 → full', () => {
  assert.deepStrictEqual(parseRange(null, 1000), { type: 'full' });
});

test('bytes=0-499 → 前 500 字节', () => {
  assert.deepStrictEqual(parseRange('bytes=0-499', 1000), { type: 'partial', start: 0, end: 499 });
});

test('bytes=500- → 从 500 到文件末尾', () => {
  assert.deepStrictEqual(parseRange('bytes=500-', 1000), { type: 'partial', start: 500, end: 999 });
});

test('bytes=-200 → 最后 200 字节（后缀范围）', () => {
  assert.deepStrictEqual(parseRange('bytes=-200', 1000), { type: 'partial', start: 800, end: 999 });
});

test('bytes=-5000 超过文件长度时截断为整个文件', () => {
  assert.deepStrictEqual(parseRange('bytes=-5000', 1000), { type: 'partial', start: 0, end: 999 });
});

test('bytes=0-99999 末端超出时截断到 size-1', () => {
  assert.deepStrictEqual(parseRange('bytes=0-99999', 1000), { type: 'partial', start: 0, end: 999 });
});

test('start ≥ 文件长度 → unsatisfiable（应回 416）', () => {
  assert.strictEqual(parseRange('bytes=1000-', 1000).type, 'unsatisfiable');
});

test('多段 range 判为 malformed（不做 multipart 响应）', () => {
  assert.strictEqual(parseRange('bytes=0-99,200-299', 1000).type, 'malformed');
});

test('end < start 判为 malformed', () => {
  assert.strictEqual(parseRange('bytes=500-100', 1000).type, 'malformed');
});

test('非 bytes 单位判为 malformed', () => {
  assert.strictEqual(parseRange('items=0-10', 1000).type, 'malformed');
});

test('空文件的 -N 后缀范围 → unsatisfiable', () => {
  assert.strictEqual(parseRange('bytes=-10', 0).type, 'unsatisfiable');
});

// ---------------------------------------------------------------------------
// Mirrors: ProjectPathResolver.resolve (Swift)
// ---------------------------------------------------------------------------

function resolveProjectPath(rawPath, root) {
  let pathValue = rawPath;
  const hashIndex = pathValue.indexOf('#');
  if (hashIndex !== -1) pathValue = pathValue.slice(0, hashIndex);
  const queryIndex = pathValue.indexOf('?');
  if (queryIndex !== -1) pathValue = pathValue.slice(0, queryIndex);

  let decoded;
  try {
    decoded = decodeURIComponent(pathValue);
  } catch (error) {
    return { error: 'forbiddenCharacters' };
  }
  if (decoded.includes('\0') || decoded.includes('\\')) return { error: 'forbiddenCharacters' };

  let relative = decoded.replace(/^\/+/, '');
  if (relative === '') relative = 'index.html';

  const segments = relative.split('/').filter((segment) => segment.length > 0);
  if (segments.some((segment) => segment === '.' || segment === '..')) return { error: 'outsideRoot' };

  const rootReal = fs.realpathSync(root);
  const candidate = path.join(rootReal, ...segments);
  let candidateReal;
  try {
    candidateReal = fs.realpathSync(candidate);
  } catch (error) {
    return { error: 'notFound' };
  }
  if (candidateReal !== rootReal && !candidateReal.startsWith(rootReal + path.sep)) {
    return { error: 'outsideRoot' };
  }
  if (!fs.statSync(candidateReal).isFile()) return { error: 'notAFile' };
  return { filePath: candidateReal, mimeType: mimeForExtension(path.extname(candidateReal)) };
}

const MIME_TYPES = {
  html: 'text/html; charset=utf-8',
  js: 'text/javascript; charset=utf-8',
  mjs: 'text/javascript; charset=utf-8',
  json: 'application/json; charset=utf-8',
  css: 'text/css; charset=utf-8',
  wasm: 'application/wasm',
  glb: 'model/gltf-binary',
  gltf: 'model/gltf+json',
  bin: 'application/octet-stream',
  woff2: 'font/woff2',
  png: 'image/png',
  mp3: 'audio/mpeg',
  vert: 'text/plain; charset=utf-8'
};

function mimeForExtension(ext) {
  return MIME_TYPES[ext.replace(/^\./, '').toLowerCase()] || 'application/octet-stream';
}

section('路径安全与 MIME（对照 Swift ProjectPathResolver / MIMEType）');

const sandbox = fs.mkdtempSync(path.join(os.tmpdir(), 'htmlrunner-logic-'));
const projectRoot = path.join(sandbox, 'project');
fs.mkdirSync(path.join(projectRoot, 'sub', 'dir'), { recursive: true });
fs.writeFileSync(path.join(projectRoot, 'index.html'), '<html></html>');
fs.writeFileSync(path.join(projectRoot, 'sub', 'dir', '模型 文件.glb'), 'glTF');
fs.writeFileSync(path.join(projectRoot, '贴图#1.png'), 'png');
fs.writeFileSync(path.join(sandbox, 'outside.txt'), 'secret');

test('普通相对路径解析成功', () => {
  const resolved = resolveProjectPath('/index.html', projectRoot);
  assert.ok(resolved.filePath, JSON.stringify(resolved));
  assert.strictEqual(resolved.mimeType, 'text/html; charset=utf-8');
});

test('空路径回退到 index.html', () => {
  const resolved = resolveProjectPath('/', projectRoot);
  assert.ok(resolved.filePath && resolved.filePath.endsWith('index.html'));
});

test('../ 穿越被拒绝', () => {
  assert.strictEqual(resolveProjectPath('/../outside.txt', projectRoot).error, 'outsideRoot');
});

test('编码后的 ..%2f 穿越也被拒绝', () => {
  const result = resolveProjectPath('/..%2Foutside.txt', projectRoot);
  assert.ok(result.error === 'outsideRoot' || result.error === 'notFound', JSON.stringify(result));
});

test('绝对路径样式 /etc/passwd 只会被当作项目内相对路径（找不到即 404）', () => {
  const result = resolveProjectPath('/etc/passwd', projectRoot);
  assert.strictEqual(result.error, 'notFound');
});

test('反斜杠被拒绝（Windows 风格穿越）', () => {
  assert.strictEqual(resolveProjectPath('/..\\outside.txt', projectRoot).error, 'forbiddenCharacters');
});

test('NUL 字节被拒绝', () => {
  assert.strictEqual(resolveProjectPath('/index.html%00.txt', projectRoot).error, 'forbiddenCharacters');
});

test('中文目录与文件名解析成功', () => {
  const resolved = resolveProjectPath('/sub/dir/' + encodeURIComponent('模型 文件.glb'), projectRoot);
  assert.ok(resolved.filePath, JSON.stringify(resolved));
  assert.strictEqual(resolved.mimeType, 'model/gltf-binary');
});

test('文件名中的 # 需要被编码为 %23 才能命中', () => {
  const decoded = resolveProjectPath('/' + encodeURIComponent('贴图#1.png'), projectRoot);
  assert.ok(decoded.filePath, JSON.stringify(decoded));
  // 未编码的 # 会被当作 fragment 截断，因此解析到的是 "贴图"（不存在）。
  assert.strictEqual(resolveProjectPath('/贴图#1.png', projectRoot).error, 'notFound');
});

test('query string 被忽略', () => {
  const resolved = resolveProjectPath('/index.html?v=123', projectRoot);
  assert.ok(resolved.filePath && resolved.filePath.endsWith('index.html'));
});

test('MIME 表覆盖游戏常用扩展', () => {
  assert.strictEqual(mimeForExtension('.wasm'), 'application/wasm');
  assert.strictEqual(mimeForExtension('.GLB'), 'model/gltf-binary');
  assert.strictEqual(mimeForExtension('.woff2'), 'font/woff2');
  assert.strictEqual(mimeForExtension('.unknown-ext'), 'application/octet-stream');
});

// ---------------------------------------------------------------------------
// Mirrors: ImportPlanner (Swift)
// ---------------------------------------------------------------------------

const SIBLING_EXTENSIONS = new Set([
  'js', 'mjs', 'cjs', 'json', 'css', 'map',
  'wasm', 'glsl', 'vert', 'frag', 'vs', 'fs', 'wgsl',
  'glb', 'gltf', 'obj', 'mtl', 'fbx', 'dae', 'stl', 'ply', 'bin', 'ktx2', 'basis', 'drc',
  'png', 'jpg', 'jpeg', 'webp', 'gif', 'bmp', 'svg', 'ico', 'avif', 'hdr', 'exr', 'tga',
  'mp3', 'ogg', 'oga', 'wav', 'm4a', 'aac', 'flac', 'opus', 'webm', 'mp4', 'mov', 'm4v',
  'ttf', 'otf', 'woff', 'woff2', 'eot',
  'xml', 'txt', 'csv', 'tsv', 'md', 'html', 'htm'
]);

function shouldCopySibling(ext) {
  return SIBLING_EXTENSIONS.has(ext.toLowerCase());
}

function chooseEntryPath(candidates) {
  if (candidates.length === 0) return 'index.html';
  const sorted = [...candidates].sort((lhs, rhs) => {
    const lhsDepth = lhs.split('/').length;
    const rhsDepth = rhs.split('/').length;
    if (lhsDepth !== rhsDepth) return lhsDepth - rhsDepth;
    return lhs.length - rhs.length;
  });
  for (const name of ['index.html', 'index.htm', 'main.html', 'game.html', 'start.html']) {
    const match = sorted.find((item) => item.toLowerCase() === name);
    if (match) return match;
  }
  const rootIndex = sorted.find((item) => !item.includes('/') && item.toLowerCase().startsWith('index'));
  if (rootIndex) return rootIndex;
  const rootLevel = sorted.find((item) => !item.includes('/'));
  if (rootLevel) return rootLevel;
  return sorted[0];
}

function sanitizeDirectoryName(name) {
  let result = name.trim();
  result = result.split(/[/\\:*?"<>|\u0000]/).join('-');
  result = result.split('..').join('-');
  // Mirrors the Swift loop: strip every leading "." and "-".
  while (result.startsWith('.') || result.startsWith('-')) result = result.slice(1);
  if (result.length > 96) result = result.slice(0, 96);
  if (result === '') result = 'project-fallback';
  return result;
}

section('导入计划（对照 Swift ImportPlanner）');

test('优先选择根目录的 index.html', () => {
  assert.strictEqual(chooseEntryPath(['game/start.html', 'index.html']), 'index.html');
});

test('没有 index.html 时选择最浅层的 HTML', () => {
  assert.strictEqual(chooseEntryPath(['a/b/deep.html', 'main.html']), 'main.html');
});

test('只有嵌套 HTML 时选择层级最浅的', () => {
  assert.strictEqual(chooseEntryPath(['a/b/c.html', 'x/y.html']), 'x/y.html');
});

test('无候选项时回退为 index.html', () => {
  assert.strictEqual(chooseEntryPath([]), 'index.html');
});

test('大小写不敏感地匹配 INDEX.HTML', () => {
  assert.strictEqual(chooseEntryPath(['INDEX.HTML']), 'INDEX.HTML');
});

test('中文目录名被保留，路径分隔符被替换', () => {
  assert.strictEqual(sanitizeDirectoryName('我的 游戏/项目'), '我的 游戏-项目');
});

test('前导点被移除，避免隐藏目录', () => {
  assert.strictEqual(sanitizeDirectoryName('...hidden'), 'hidden');
});

test('前导连字符被移除，避免被当作命令行参数', () => {
  assert.strictEqual(sanitizeDirectoryName('--evil'), 'evil');
});

test('纯 ../ 输入不会产生空名或逃逸路径', () => {
  const sanitized = sanitizeDirectoryName('../..');
  assert.ok(sanitized.length > 0, sanitized);
  assert.ok(!sanitized.includes('/'), sanitized);
  assert.ok(!sanitized.includes('..'), sanitized);
});

test('.. 被替换，防止目录逃逸', () => {
  const sanitized = sanitizeDirectoryName('..');
  assert.ok(!sanitized.includes('..'), sanitized);
});

test('超长名称被截断到 96 字符', () => {
  assert.strictEqual(sanitizeDirectoryName('a'.repeat(200)).length, 96);
});

test('空名称得到非空结果', () => {
  assert.ok(sanitizeDirectoryName('   ').length > 0);
});

test('资源类扩展名会被一并导入', () => {
  for (const ext of ['js', 'glb', 'png', 'mp3', 'woff2', 'wasm', 'vert']) {
    assert.ok(shouldCopySibling(ext), ext);
  }
});

test('可执行文件与无关类型不会被一并导入', () => {
  for (const ext of ['exe', 'dll', 'dmg', 'psd', 'ai', 'sketch']) {
    assert.ok(!shouldCopySibling(ext), ext);
  }
});

test('扩展名匹配不区分大小写', () => {
  assert.ok(shouldCopySibling('PNG'));
  assert.ok(shouldCopySibling('Glb'));
});

// ---------------------------------------------------------------------------
// Mirrors: AppInfo / DiagnosticLogStore rendering rules
// ---------------------------------------------------------------------------

section('日志与事实呈现规则');

test('日志元数据排序稳定（键值对按 key 排序输出）', () => {
  const metadata = { zebra: '1', alpha: '2', middle: '3' };
  const rendered = Object.keys(metadata).sort().map((key) => `${key}=${metadata[key]}`).join(' ');
  assert.strictEqual(rendered, 'alpha=2 middle=3 zebra=1');
});

test('"无法获取" 与 "0" 必须是可区分的字符串', () => {
  const unknown = '无法获取';
  assert.notStrictEqual(unknown, '0');
  assert.ok(Number.isNaN(Number(unknown)));
});

section('JIT 权限判定（对照 Swift JITCapabilityReport）');

// Mirrors HTMLRunner/Diagnostics/ProcessDebugState.swift.
//
// The bit values are Apple's ProcessCodeSigningFlags; CS_DEBUGGED = 0x10000000 and
// CS_OPS_STATUS = 0 are taken from Delta's shipping ProcessInfo+JIT.swift, which is
// also the mechanism PojavLauncher and LiveContainer read. Keeping the *decision
// logic* here means the verdict rules are covered by CI even though the syscall can
// only run on a device.
const CS_VALID = 0x1;
const CS_HARD = 0x100;
const CS_KILL = 0x200;
const CS_RESTRICT = 0x800;
const CS_DEBUGGED = 0x10000000;

const JIT_ENTITLEMENT_KEYS = [
  'dynamic-codesigning',
  'com.apple.developer.cs.allow-jit',
  'com.apple.security.cs.allow-jit'
];

function hasExecutableMemoryEntitlement(entitlements) {
  return entitlements.some(
    ([key, value]) => JIT_ENTITLEMENT_KEYS.includes(key) && value === 'true');
}

function jitVerdict({ csopsSucceeded, flags, entitlements }) {
  const isDebugged = (flags & CS_DEBUGGED) === CS_DEBUGGED;
  const hasEntitlement = hasExecutableMemoryEntitlement(entitlements);
  if (csopsSucceeded) {
    return (isDebugged || hasEntitlement)
      ? '本进程具备 JIT 条件'
      : '本进程不具备 JIT 条件';
  }
  return hasEntitlement ? '本进程具备 JIT 条件' : '无法判定';
}

function describeFlags(flags) {
  const names = [];
  if ((flags & CS_VALID)) names.push('CS_VALID');
  if ((flags & CS_HARD)) names.push('CS_HARD');
  if ((flags & CS_KILL)) names.push('CS_KILL');
  if ((flags & CS_RESTRICT)) names.push('CS_RESTRICT');
  if ((flags & CS_DEBUGGED)) names.push('CS_DEBUGGED');
  return names;
}

test('CS_DEBUGGED 置位 → 判定为具备 JIT 条件', () => {
  assert.strictEqual(
    jitVerdict({ csopsSucceeded: true, flags: CS_VALID | CS_DEBUGGED, entitlements: [] }),
    '本进程具备 JIT 条件');
});

test('无调试器且无 entitlement → 判定为不具备 JIT 条件', () => {
  assert.strictEqual(
    jitVerdict({ csopsSucceeded: true, flags: CS_VALID | CS_HARD, entitlements: [] }),
    '本进程不具备 JIT 条件');
});

test('仅有 dynamic-codesigning(越狱/TrollStore 路线) 也算具备条件', () => {
  assert.strictEqual(
    jitVerdict({ csopsSucceeded: true, flags: CS_VALID,
                 entitlements: [['dynamic-codesigning', 'true']] }),
    '本进程具备 JIT 条件');
});

test('仅有 com.apple.developer.cs.allow-jit(iOS 17.4+ 路线) 也算具备条件', () => {
  assert.strictEqual(
    jitVerdict({ csopsSucceeded: true, flags: CS_VALID,
                 entitlements: [['com.apple.developer.cs.allow-jit', 'true']] }),
    '本进程具备 JIT 条件');
});

test('entitlement present 但为 false 不计入', () => {
  assert.strictEqual(
    jitVerdict({ csopsSucceeded: true, flags: CS_VALID,
                 entitlements: [['dynamic-codesigning', 'false']] }),
    '本进程不具备 JIT 条件');
});

test('get-task-allow 本身不构成 JIT 条件（它只决定是否出现在工具列表里）', () => {
  assert.strictEqual(
    jitVerdict({ csopsSucceeded: true, flags: CS_VALID,
                 entitlements: [['get-task-allow', 'true']] }),
    '本进程不具备 JIT 条件');
});

test('csops 失败但有 entitlement → 仍判定为具备条件', () => {
  assert.strictEqual(
    jitVerdict({ csopsSucceeded: false, flags: 0,
                 entitlements: [['dynamic-codesigning', 'true']] }),
    '本进程具备 JIT 条件');
});

test('csops 失败且无 entitlement → 无法判定（不能报成 false）', () => {
  assert.strictEqual(
    jitVerdict({ csopsSucceeded: false, flags: 0, entitlements: [] }),
    '无法判定');
});

test('标志位解析只列出已置位的位', () => {
  assert.deepStrictEqual(describeFlags(CS_VALID | CS_HARD | CS_DEBUGGED),
                         ['CS_VALID', 'CS_HARD', 'CS_DEBUGGED']);
  assert.deepStrictEqual(describeFlags(0), []);
});

test('CS_DEBUGGED 与其他位互不干扰（位掩码正确）', () => {
  // CS_HARD = 0x100 must not be mistaken for CS_DEBUGGED = 0x10000000.
  assert.notStrictEqual(CS_HARD & CS_DEBUGGED, CS_DEBUGGED);
  assert.strictEqual(describeFlags(CS_HARD).includes('CS_DEBUGGED'), false);
});

test('判定从不声称网页（WebContent）的 JIT 状态', () => {
  const allVerdicts = [
    jitVerdict({ csopsSucceeded: true, flags: CS_DEBUGGED, entitlements: [] }),
    jitVerdict({ csopsSucceeded: true, flags: 0, entitlements: [] }),
    jitVerdict({ csopsSucceeded: false, flags: 0, entitlements: [] })
  ];
  for (const verdict of allVerdicts) {
    assert.ok(!/WebContent|网页|JavaScriptCore/.test(verdict),
              `判定文案不得涉及网页进程: ${verdict}`);
  }
});

// --- the exact state observed on a real device (iPad16,4 / iPadOS 27.0.1) --------
//
// Recorded here so the interpretation is regression-tested rather than remembered.
// The signing tool wrote `get-task-allow = false` into the binary and the signature is
// hardened (CS_HARD | CS_KILL), so the kernel will never let a debugger attach.
const OBSERVED_FLAGS = 0x22003301;

function getTaskAllowState(entitlements) {
  const entry = entitlements.find(([key]) => key === 'get-task-allow');
  if (!entry) return 'absent';
  return entry[1];               // 'true' | 'false'
}

function signatureBlocksDebugging({ csopsSucceeded, flags, entitlements }) {
  const isDebugged = (flags & CS_DEBUGGED) === CS_DEBUGGED;
  const hasEntitlement = hasExecutableMemoryEntitlement(entitlements);
  const hasGetTaskAllow = entitlements.some(([k, v]) => k === 'get-task-allow' && v === 'true');
  const isHard = (flags & CS_HARD) === CS_HARD;
  const isKill = (flags & CS_KILL) === CS_KILL;
  return csopsSucceeded && !isDebugged && !hasEntitlement && !hasGetTaskAllow && isHard && isKill;
}

test('真机观测值 0x22003301 解析出 CS_VALID/CS_HARD/CS_KILL，且无 CS_DEBUGGED', () => {
  const names = describeFlags(OBSERVED_FLAGS);
  assert.ok(names.includes('CS_VALID'), names.join(','));
  assert.ok(names.includes('CS_HARD'), names.join(','));
  assert.ok(names.includes('CS_KILL'), names.join(','));
  assert.strictEqual(names.includes('CS_DEBUGGED'), false, 'CS_DEBUGGED 不应置位');
});

test('真机状态判定为「不具备 JIT 条件」', () => {
  assert.strictEqual(
    jitVerdict({ csopsSucceeded: true, flags: OBSERVED_FLAGS,
                 entitlements: [['get-task-allow', 'false']] }),
    '本进程不具备 JIT 条件');
});

test('区分 get-task-allow「缺失」与「显式为 false」', () => {
  assert.strictEqual(getTaskAllowState([]), 'absent');
  assert.strictEqual(getTaskAllowState([['get-task-allow', 'false']]), 'false');
  assert.strictEqual(getTaskAllowState([['get-task-allow', 'true']]), 'true');
});

test('真机状态被识别为「受限签名，无法附加调试器」', () => {
  assert.strictEqual(
    signatureBlocksDebugging({ csopsSucceeded: true, flags: OBSERVED_FLAGS,
                               entitlements: [['get-task-allow', 'false']] }),
    true);
});

test('带 get-task-allow=true 且 CS_DEBUGGED 置位时，不再判定为受限', () => {
  assert.strictEqual(
    signatureBlocksDebugging({ csopsSucceeded: true, flags: OBSERVED_FLAGS | CS_DEBUGGED,
                               entitlements: [['get-task-allow', 'true']] }),
    false);
});

// ---------------------------------------------------------------------------
// Mirrors: ProjectStore project adoption / location rules
// ---------------------------------------------------------------------------

section('项目自动识别与存放位置（对照 Swift ProjectStore）');

// A folder is adopted only if it actually contains a web entry point. The probe is
// bounded for the same reason as in Swift: adoption runs at launch, and a container
// can hold large unrelated folders.
function looksLikeWebProject(paths, probeLimit = 400) {
  let examined = 0;
  for (const path of paths) {
    examined += 1;
    if (examined > probeLimit) return false;
    const name = path.split('/').pop().toLowerCase();
    if (name.endsWith('.html') || name.endsWith('.htm')) return true;
  }
  return false;
}

function candidateDirectories({ destination, entries }) {
  // Mirrors adoptUnregisteredProjects(): the directories the app owns are never
  // candidates, so a project can never be offered as something to move onto itself.
  const owned = new Set(['Projects', 'Inbox']);
  void destination;
  return entries.filter((name) => !owned.has(name));
}

test('含 index.html 的文件夹会被识别为项目', () => {
  assert.strictEqual(looksLikeWebProject(['index.html', 'js/game.js']), true);
});

test('只有子目录里有 HTML 也会被识别（入口选层级最浅的）', () => {
  const paths = ['assets/tex.png', 'src/deep/main.html'];
  assert.strictEqual(looksLikeWebProject(paths), true);
  assert.strictEqual(chooseEntryPath(['src/deep/main.html']), 'src/deep/main.html');
});

test('没有 HTML 的文件夹不会被误识别为项目', () => {
  assert.strictEqual(looksLikeWebProject(['readme.txt', 'data.bin']), false);
});

test('探测有上限：超过上限仍未找到 HTML 就放弃（避免启动时扫描巨型目录）', () => {
  const many = Array.from({ length: 500 }, (_, i) => `file${i}.bin`).concat(['index.html']);
  assert.strictEqual(looksLikeWebProject(many, 400), false,
    'index.html 在第 500 个位置，超过 400 的探测上限，应放弃而不是全量扫描');
});

test('Projects 目录本身不会被当成候选项目', () => {
  assert.strictEqual(candidateDirectories({ destination: 'Projects',
    entries: ['Projects', 'Inbox', 'mygame'] }).includes('Projects'), false);
});

test('容器根目录作为存放位置时，Projects 仍被排除（避免自我移动）', () => {
  assert.strictEqual(candidateDirectories({ destination: '.',
    entries: ['Projects', 'Inbox', 'mygame'] }).includes('Projects'), false);
});

test('普通项目文件夹会出现在候选列表里', () => {
  const candidates = candidateDirectories({ destination: 'Projects',
    entries: ['Projects', 'Inbox', 'mygame', '另一个项目'] });
  assert.deepStrictEqual(candidates.sort(), ['mygame', '另一个项目'].sort());
});

test('项目查找顺序覆盖两种存放位置（改设置后不丢项目）', () => {
  // Mirrors locateProjectDirectory: configured root, then Projects/, then root.
  const searchOrder = (destination, name) => (destination === '.'
    ? [`. /${name}`, `Projects/${name}`, `./${name}`]
    : [`Projects/${name}`, `Projects/${name}`, `./${name}`]);
  assert.ok(searchOrder('.', 'mygame').some((p) => p.includes('Projects/mygame')),
    '容器根目录模式下仍应能找回放在 Projects/ 里的项目');
  assert.ok(searchOrder('Projects', 'mygame').includes('./mygame'),
    'Projects 模式下仍应能找回手动放在根目录的项目');
});



section('资源与契约一致性');

const REPO_ROOT = path.join(__dirname, '..', '..');
const bridgePath = path.join(REPO_ROOT, 'HTMLRunner', 'Resources', 'Web', 'DiagnosticBridge.js');
const probePath = path.join(REPO_ROOT, 'HTMLRunner', 'Resources', 'Web', 'WebProbe.js');
const factoryPath = path.join(REPO_ROOT, 'HTMLRunner', 'Web', 'WebViewFactory.swift');

test('DiagnosticBridge.js 存在且声明了 WKScriptMessageHandler 名称', () => {
  const source = fs.readFileSync(bridgePath, 'utf8');
  assert.ok(source.includes('htmlrunnerDiag'), '缺少 handler 名称');
  assert.ok(source.includes('__HTMLRUNNER_BRIDGE_INSTALLED__'), '缺少重复注入保护');
});

test('Swift 侧的 handler 名称与 JS 完全一致', () => {
  const factory = fs.readFileSync(factoryPath, 'utf8');
  assert.ok(factory.includes('diagnosticsHandlerName = "htmlrunnerDiag"'),
    'WebViewFactory.diagnosticsHandlerName 与 DiagnosticBridge.js 不一致');
});

test('诊断桥不劫持 requestAnimationFrame / fetch / 定时器', () => {
  const source = fs.readFileSync(bridgePath, 'utf8');
  for (const forbidden of ['requestAnimationFrame =', 'window.fetch =', 'setTimeout =', 'setInterval =']) {
    assert.ok(!source.includes(forbidden), `诊断桥不应改写 ${forbidden}`);
  }
});

test('WebProbe.js 明确声明 JIT 状态不可判定', () => {
  const source = fs.readFileSync(probePath, 'utf8');
  assert.ok(source.includes('cannot-be-determined-from-a-web-page'),
    'WebProbe.js 缺少 JIT 不可判定的显式标记');
  assert.ok(source.includes('indirect-evidence-only'),
    'WebProbe.js 缺少"性能只是间接证据"的显式标记');
});

test('WebProbe.js 不修改页面状态（只读取与创建临时 canvas）', () => {
  const source = fs.readFileSync(probePath, 'utf8');
  for (const forbidden of ['document.body.innerHTML', 'document.write', 'window.location =']) {
    assert.ok(!source.includes(forbidden), `WebProbe.js 不应修改页面：${forbidden}`);
  }
});

// ---------------------------------------------------------------------------

console.log(`\n结果: ${results.length - failures}/${results.length} 通过`);
if (failures > 0) {
  console.log(`失败 ${failures} 项`);
  process.exit(1);
}
console.log('全部通过');
