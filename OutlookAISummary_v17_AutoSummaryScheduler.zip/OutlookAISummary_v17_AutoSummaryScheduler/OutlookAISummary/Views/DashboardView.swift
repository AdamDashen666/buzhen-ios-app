import SwiftUI
import QuickLook

struct DashboardView: View {
    @EnvironmentObject private var state: AppState

    private var canCallBackend: Bool {
        state.backendValidationMessage == nil && !state.isLoading
    }

    var body: some View {
        ZStack {
            LiquidBackground()
            ScrollView {
                VStack(spacing: 18) {
                    header
                    if let warning = state.backendValidationMessage {
                        backendWarningCard(warning)
                    }
                    statusCard
                    connectionCheckCard
                    if state.linkedUser != nil {
                        controlCard
                    } else {
                        loginCard
                    }
                    historyList
                    if let error = state.lastError, !error.isEmpty {
                        errorCard(error)
                    }
                }
                .padding()
                .frame(maxWidth: 860)
                .frame(maxWidth: .infinity)
            }
            .refreshable { await state.refreshAll() }
        }
        .navigationTitle("总览")
        .toolbar {
            Button("刷新") { Task { await state.refreshAll() } }
        }
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Mail AI Summary")
                .font(.largeTitle.bold())
            Text("QQ IMAP + Render 后端；AI 密钥和模型只由后端环境变量控制。")
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private func backendWarningCard(_ message: String) -> some View {
        GlassCard {
            VStack(alignment: .leading, spacing: 10) {
                Label("需要先配置后端", systemImage: "server.rack")
                    .font(.headline)
                Text(message)
                    .font(.footnote)
                    .textSelection(.enabled)
                Text("设置 → 后端地址：填 Render/Railway/Vercel/自建服务器的 HTTPS 地址。")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
            }
            .foregroundStyle(.orange.opacity(0.95))
        }
    }

    private var statusCard: some View {
        GlassCard {
            VStack(alignment: .leading, spacing: 14) {
                HStack {
                    Image(systemName: state.linkedUser == nil ? "link.badge.plus" : "checkmark.seal.fill")
                        .font(.title2)
                    VStack(alignment: .leading, spacing: 3) {
                        Text(state.linkedUser == nil ? "未连接邮箱" : "邮箱已连接")
                            .font(.headline)
                        Text(state.statusText)
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                    }
                    Spacer()
                    if state.isLoading { ProgressView().tint(.white) }
                }
                HStack(spacing: 8) {
                    CapsuleTag(text: state.settings.frequency.title, systemImage: "clock")
                    CapsuleTag(text: "中文", systemImage: "textformat")
                    CapsuleTag(text: state.imapStatus?.ok == true ? "imap" : (state.backendHealth?.provider ?? "后端未检查"), systemImage: "server.rack")
                    CapsuleTag(text: state.imapStatus?.ok == true ? "IMAP 正常" : "IMAP 未检查", systemImage: "envelope.badge")
                }
            }
        }
    }

    private var connectionCheckCard: some View {
        GlassCard {
            VStack(alignment: .leading, spacing: 14) {
                HStack {
                    SectionTitle(title: "后端连接检查", subtitle: "显示上次成功连接状态；打开 App 时只后台刷新，不会阻塞自动总结。")
                    Spacer()
                    Button {
                        Task { await state.refreshBackendConnection() }
                    } label: {
                        Image(systemName: "arrow.clockwise")
                            .font(.headline)
                    }
                }

                VStack(alignment: .leading, spacing: 8) {
                    connectionRow("后端服务", state.backendHealth?.ok == true ? "正常" : "未连接", ok: state.backendHealth?.ok == true)
                    connectionRow("邮件模式", state.backendHealth?.provider ?? "未读取", ok: state.backendHealth?.provider == "imap")
                    connectionRow("QQ IMAP", state.imapStatus?.ok == true ? "正常" : (state.imapStatus?.error ?? "未检查"), ok: state.imapStatus?.ok == true)
                    if let imap = state.imapStatus, imap.ok {
                        infoRow("邮箱", imap.account ?? "未返回")
                        infoRow("IMAP", imap.host ?? "未返回")
                        infoRow("未读", "\(imap.unseen ?? 0) / 总邮件 \(imap.messages ?? 0)")
                    }
                    Text(state.connectionStatus)
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
                .textSelection(.enabled)
            }
        }
    }

    private func connectionRow(_ title: String, _ value: String, ok: Bool) -> some View {
        HStack(alignment: .top, spacing: 8) {
            Image(systemName: ok ? "checkmark.circle.fill" : "exclamationmark.triangle.fill")
                .foregroundStyle(ok ? .green : .orange)
            infoRow(title, value)
        }
        .font(.footnote)
    }

    private func infoRow(_ title: String, _ value: String) -> some View {
        HStack(alignment: .top, spacing: 8) {
            Text(title)
                .foregroundStyle(.secondary)
                .frame(width: 72, alignment: .leading)
            Text(value)
                .frame(maxWidth: .infinity, alignment: .leading)
        }
        .font(.footnote)
    }

    private var loginCard: some View {
        GlassCard {
            VStack(alignment: .leading, spacing: 14) {
                SectionTitle(title: "QQ IMAP 状态", subtitle: "QQ IMAP 模式不需要 Microsoft 登录；在 Render 环境变量配置 QQ 邮箱后检查状态。")
                Button {
                    Task { await state.refreshAll() }
                } label: {
                    Label("检查 IMAP 状态", systemImage: "arrow.clockwise")
                }
                .buttonStyle(PrimaryButtonStyle())
                .disabled(state.backendValidationMessage != nil)
                .opacity(state.backendValidationMessage == nil ? 1 : 0.45)
            }
        }
    }

    private var controlCard: some View {
        GlassCard {
            VStack(alignment: .leading, spacing: 14) {
                SectionTitle(title: "测试 AI 总结", subtitle: "仅测试最新 3 封邮件，不会处理全部历史邮件。")
                Button {
                    Task { await state.runTestSummary() }
                } label: {
                    Label("测试总结当前邮件", systemImage: "sparkles")
                }
                .buttonStyle(PrimaryButtonStyle())
                .disabled(!canCallBackend)
                .opacity(canCallBackend ? 1 : 0.45)

                Text("仅测试最新 3 封邮件，不会处理全部历史邮件。")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
                    .textSelection(.enabled)

                MarkdownSummaryText(text: state.testSummaryStatus)
                    .font(.footnote)
                    .foregroundStyle(.secondary)
                    .textSelection(.enabled)

                Divider().opacity(0.25)

                Button {
                    Task { await state.runScheduledSummaryNow() }
                } label: {
                    Label("立即总结", systemImage: "tray.full")
                }
                .buttonStyle(PrimaryButtonStyle())
                .disabled(!canCallBackend)
                .opacity(canCallBackend ? 1 : 0.45)

                Text("按当前频率执行：\(state.settings.frequency.scheduleDescription)")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
                    .textSelection(.enabled)

                Divider().opacity(0.25)

                Button {
                    state.sendTestNotification()
                } label: {
                    Label("测试通知", systemImage: "bell.badge.fill")
                }
                .buttonStyle(PrimaryButtonStyle())

                Text(state.notificationStatus)
                    .font(.footnote)
                    .foregroundStyle(.secondary)
                    .textSelection(.enabled)
            }
        }
    }

    private var historyList: some View {
        VStack(alignment: .leading, spacing: 12) {
            SectionTitle(title: "历史总结", subtitle: state.historySummaries.isEmpty ? "暂无总结。文字保留 60 天，PDF 保留 15 天。" : "按日期倒序分组；PDF 保留 15 天，文字保留 60 天。")
            ForEach(state.historyGroups) { group in
                VStack(alignment: .leading, spacing: 10) {
                    Text(group.dateTitle)
                        .font(.headline)
                        .foregroundStyle(.secondary)
                        .padding(.horizontal, 4)
                    ForEach(group.records) { record in
                        NavigationLink {
                            SummaryDetailView(recordId: record.id)
                        } label: {
                            HistorySummaryCard(record: record)
                                .environmentObject(state)
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
        }
    }

    private func errorCard(_ message: String) -> some View {
        GlassCard {
            VStack(alignment: .leading, spacing: 8) {
                Label("错误", systemImage: "exclamationmark.triangle.fill")
                    .font(.headline)
                Text(message)
                    .font(.footnote)
                    .textSelection(.enabled)
            }
            .foregroundStyle(.red.opacity(0.9))
        }
    }
}

private struct HistorySummaryCard: View {
    @EnvironmentObject private var state: AppState
    let record: LocalSummaryRecord

    var body: some View {
        GlassCard {
            VStack(alignment: .leading, spacing: 12) {
                HStack(alignment: .top) {
                    VStack(alignment: .leading, spacing: 4) {
                        Text(record.title)
                            .font(.headline)
                        Text(record.timeTitle)
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    Spacer()
                    CapsuleTag(text: state.hasPDF(for: record) ? "有 PDF" : "无 PDF", systemImage: state.hasPDF(for: record) ? "doc.richtext" : "doc.badge.plus")
                }
                VStack(alignment: .leading, spacing: 6) {
                    Text("时间范围：\(record.timeRangeDisplay)")
                        .lineLimit(2)
                    HStack(spacing: 8) {
                        CapsuleTag(text: "处理 \(record.processedCount)", systemImage: "envelope")
                        CapsuleTag(text: "重要 \(record.importantCount)", systemImage: "exclamationmark.circle")
                        CapsuleTag(text: "低价值 \(record.spamCount)", systemImage: "trash")
                    }
                }
                .font(.footnote)
                .foregroundStyle(.secondary)
            }
        }
    }
}

private struct SummaryDetailView: View {
    @EnvironmentObject private var state: AppState
    let recordId: String
    @State private var previewItem: PDFPreviewItem?

    private var record: LocalSummaryRecord? {
        state.historySummaries.first { $0.id == recordId }
    }

    var body: some View {
        ZStack {
            LiquidBackground()
            ScrollView {
                if let record {
                    let parsed = SummaryParser.parse(record)
                    VStack(alignment: .leading, spacing: 18) {
                        SummaryOverviewReportCard(record: record, parsed: parsed)

                        SummarySectionCard(title: "重点提醒", systemImage: "bell.badge") {
                            ReportBulletList(lines: parsed.reminders, emptyText: "暂无重点提醒。")
                        }

                        SummarySectionCard(title: "重要邮件", systemImage: "star.fill") {
                            if parsed.importantEmails.isEmpty {
                                ReportBulletList(lines: parsed.importantFallback, emptyText: "暂无结构化重要邮件。")
                            } else {
                                VStack(alignment: .leading, spacing: 12) {
                                    ForEach(parsed.importantEmails) { item in
                                        ImportantEmailCard(item: item)
                                    }
                                }
                            }
                        }

                        SummarySectionCard(title: "普通邮件", systemImage: "tray") {
                            ReportBulletList(lines: parsed.normalSummary, emptyText: "暂无普通邮件摘要。")
                        }

                        SummarySectionCard(title: "垃圾邮件 / 可忽略邮件", systemImage: "trash") {
                            ReportBulletList(lines: parsed.spamSummary, emptyText: "暂无明显垃圾或低价值邮件。")
                        }

                        SummarySectionCard(title: "风险提醒", systemImage: parsed.hasRisk ? "exclamationmark.triangle.fill" : "checkmark.shield.fill") {
                            RiskStatusCard(parsed: parsed)
                        }

                        SummarySectionCard(title: "下一步建议", systemImage: "checklist") {
                            ReportChecklist(lines: parsed.nextSteps, emptyText: "暂无下一步操作。")
                        }

                        if parsed.reminders.isEmpty && parsed.importantEmails.isEmpty && parsed.importantFallback.isEmpty && parsed.normalSummary.isEmpty && parsed.spamSummary.isEmpty && parsed.risks.isEmpty && parsed.nextSteps.isEmpty {
                            SummarySectionCard(title: "原始总结", systemImage: "doc.text") {
                                ReportBulletList(lines: parsed.fallbackParagraphs, emptyText: "没有可显示的总结内容。")
                            }
                        }

                        PDFActionCard(record: record, previewItem: $previewItem)
                            .environmentObject(state)
                    }
                    .padding()
                    .frame(maxWidth: 860)
                    .frame(maxWidth: .infinity)
                } else {
                    Text("历史总结不存在或已被清理。")
                        .foregroundStyle(.secondary)
                        .padding()
                }
            }
        }
        .navigationTitle("总结详情")
        .sheet(item: $previewItem) { item in
            PDFPreviewController(url: item.url)
        }
    }
}

private struct SummaryOverviewReportCard: View {
    let record: LocalSummaryRecord
    let parsed: ParsedSummary

    var body: some View {
        GlassCard {
            VStack(alignment: .leading, spacing: 14) {
                Label("邮件总结概览", systemImage: "doc.text")
                    .font(.title2.bold())
                VStack(alignment: .leading, spacing: 6) {
                    Text("总结时间：\(record.createdAtDisplay)")
                    Text("时间范围：\(parsed.timeRange)")
                }
                .font(.footnote)
                .foregroundStyle(.secondary)
                .textSelection(.enabled)

                LazyVGrid(columns: [GridItem(.adaptive(minimum: 150), spacing: 10)], spacing: 10) {
                    StatPill(title: "处理邮件", value: "\(parsed.processedCount) 封", systemImage: "envelope")
                    StatPill(title: "重要邮件", value: "\(parsed.importantCount) 封", systemImage: "star")
                    StatPill(title: "低价值邮件", value: "\(parsed.spamCount) 封", systemImage: "trash")
                }

                if let backendPDFInfo = record.backendPDFInfo {
                    Text("后端返回 PDF 信息：\(backendPDFInfo)")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .textSelection(.enabled)
                }
            }
        }
    }
}

private struct StatPill: View {
    let title: String
    let value: String
    let systemImage: String

    var body: some View {
        HStack(spacing: 10) {
            Image(systemName: systemImage)
                .font(.headline)
            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                Text(value)
                    .font(.headline)
            }
            Spacer(minLength: 0)
        }
        .padding(12)
        .background(.white.opacity(0.12), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
    }
}

private struct SummarySectionCard<Content: View>: View {
    let title: String
    let systemImage: String
    let content: Content

    init(title: String, systemImage: String, @ViewBuilder content: () -> Content) {
        self.title = title
        self.systemImage = systemImage
        self.content = content()
    }

    var body: some View {
        GlassCard {
            VStack(alignment: .leading, spacing: 12) {
                Label(title, systemImage: systemImage)
                    .font(.headline)
                content
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
    }
}

private struct ReportBulletList: View {
    let lines: [String]
    let emptyText: String

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            ForEach(Array((lines.isEmpty ? [emptyText] : lines).enumerated()), id: \.offset) { _, line in
                HStack(alignment: .top, spacing: 8) {
                    Text("•")
                        .font(.body.weight(.bold))
                    MarkdownSummaryText(text: line)
                        .textSelection(.enabled)
                }
            }
        }
        .font(.body)
    }
}

private struct ReportChecklist: View {
    let lines: [String]
    let emptyText: String

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            ForEach(Array((lines.isEmpty ? [emptyText] : lines).enumerated()), id: \.offset) { _, line in
                HStack(alignment: .top, spacing: 8) {
                    Image(systemName: "checkmark.circle")
                        .foregroundStyle(.green)
                    MarkdownSummaryText(text: line)
                        .textSelection(.enabled)
                }
            }
        }
        .font(.body)
    }
}

private struct ImportantEmailCard: View {
    let item: ParsedEmailItem

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(alignment: .top, spacing: 10) {
                Image(systemName: "flag.fill")
                    .foregroundStyle(.orange)
                VStack(alignment: .leading, spacing: 6) {
                    Text(item.subject.isEmpty ? "未识别主题" : item.subject)
                        .font(.headline)
                        .textSelection(.enabled)
                    if !item.sender.isEmpty {
                        Label(item.sender, systemImage: "person")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                            .textSelection(.enabled)
                    }
                    if !item.time.isEmpty {
                        Label(item.time, systemImage: "clock")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                            .textSelection(.enabled)
                    }
                }
                Spacer()
                if !item.priority.isEmpty {
                    PriorityChip(priority: item.priority)
                }
            }

            FieldBlock(label: "摘要", value: item.summary)
            FieldBlock(label: "需要操作", value: item.action)
            FieldBlock(label: "截止时间", value: item.deadline)
        }
        .padding(14)
        .background(.white.opacity(0.12), in: RoundedRectangle(cornerRadius: 20, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .strokeBorder(.white.opacity(0.14), lineWidth: 1)
        }
    }
}

private struct FieldBlock: View {
    let label: String
    let value: String

    var body: some View {
        if !value.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            VStack(alignment: .leading, spacing: 4) {
                Text(label)
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.secondary)
                MarkdownSummaryText(text: value)
                    .font(.subheadline)
                    .textSelection(.enabled)
            }
        }
    }
}

private struct PriorityChip: View {
    let priority: String

    private var chipColor: Color {
        let value = priority.lowercased()
        if value.contains("高") || value.contains("high") || value.contains("urgent") { return .orange }
        if value.contains("中") || value.contains("medium") { return .yellow }
        return .blue.opacity(0.8)
    }

    var body: some View {
        Text(priority)
            .font(.caption.bold())
            .padding(.horizontal, 10)
            .padding(.vertical, 6)
            .background(chipColor.opacity(0.20), in: Capsule())
            .foregroundStyle(chipColor)
    }
}

private struct RiskStatusCard: View {
    let parsed: ParsedSummary

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Label(parsed.hasRisk ? "需要注意" : "暂无明显风险", systemImage: parsed.hasRisk ? "exclamationmark.triangle.fill" : "checkmark.shield.fill")
                .font(.headline)
                .foregroundStyle(parsed.hasRisk ? .orange : .green)
            ReportBulletList(lines: parsed.risks, emptyText: "暂无明显风险。")
        }
        .padding(14)
        .background((parsed.hasRisk ? Color.orange : Color.green).opacity(0.12), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 18, style: .continuous)
                .strokeBorder((parsed.hasRisk ? Color.orange : Color.green).opacity(0.28), lineWidth: 1)
        }
    }
}

private struct PDFActionCard: View {
    @EnvironmentObject private var state: AppState
    let record: LocalSummaryRecord
    @Binding var previewItem: PDFPreviewItem?

    var body: some View {
        GlassCard {
            VStack(spacing: 12) {
                if let url = state.pdfURL(for: record) {
                    Button {
                        previewItem = PDFPreviewItem(url: url)
                    } label: {
                        Label("打开 PDF", systemImage: "doc.richtext")
                    }
                    .buttonStyle(PrimaryButtonStyle())

                    ShareLink(item: url) {
                        Label("分享 PDF", systemImage: "square.and.arrow.up")
                            .font(.headline)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 14)
                            .background(.white.opacity(0.25), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                            .overlay {
                                RoundedRectangle(cornerRadius: 18, style: .continuous)
                                    .strokeBorder(.white.opacity(0.18), lineWidth: 1)
                            }
                    }
                } else {
                    Text("PDF 已删除或不存在，但文字总结仍保留。")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                    Button {
                        state.regeneratePDF(for: record.id)
                    } label: {
                        Label("重新生成 PDF", systemImage: "doc.badge.plus")
                    }
                    .buttonStyle(PrimaryButtonStyle())
                }
            }
        }
    }
}

private struct PDFPreviewItem: Identifiable {
    let id = UUID()
    let url: URL
}

private struct PDFPreviewController: UIViewControllerRepresentable {
    let url: URL

    func makeUIViewController(context: Context) -> QLPreviewController {
        let controller = QLPreviewController()
        controller.dataSource = context.coordinator
        return controller
    }

    func updateUIViewController(_ controller: QLPreviewController, context: Context) {}

    func makeCoordinator() -> Coordinator {
        Coordinator(url: url)
    }

    final class Coordinator: NSObject, QLPreviewControllerDataSource {
        let url: URL

        init(url: URL) {
            self.url = url
        }

        func numberOfPreviewItems(in controller: QLPreviewController) -> Int { 1 }

        func previewController(_ controller: QLPreviewController, previewItemAt index: Int) -> QLPreviewItem {
            url as NSURL
        }
    }
}
