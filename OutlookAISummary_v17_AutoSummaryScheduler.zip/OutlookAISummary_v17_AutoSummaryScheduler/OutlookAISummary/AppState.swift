import Foundation
import SwiftUI
import UserNotifications
import UIKit

@MainActor
final class AppState: ObservableObject {
    @Published var backendURL: String {
        didSet {
            UserDefaults.standard.set(backendURL, forKey: "backendURL")
            api.baseURL = backendURL.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
            clearCachedConnectionIfBackendChanged()
        }
    }
    @Published var linkedUser: LinkedUser?
    @Published var historySummaries: [LocalSummaryRecord] = []
    @Published var settings = AppSettings()
    @Published var backendHealth: BackendHealthResponse?
    @Published var imapStatus: IMAPTestResponse?
    @Published var connectionStatus = "未检查后端连接"
    @Published var aiTestStatus = "未测试 AI 模型"
    @Published var testSummaryStatus = "未测试 AI 总结"
    @Published var notificationStatus = "未测试通知"
    @Published var schedulerStatus: SchedulerStatusResponse?
    @Published var schedulerStatusText = "未检查自动总结状态"
    @Published var isLoading = false
    @Published var statusText = "未连接"
    @Published var lastError: String?
    @Published var pushToken: String?

    let deviceId: String
    let api: APIClient

    private let historyKey = "localSummaryHistoryV11"
    private let textRetentionDays = 60
    private let pdfRetentionDays = 15
    private let cachedBackendHealthKey = "cachedBackendHealthV16"
    private let cachedIMAPStatusKey = "cachedIMAPStatusV16"
    private let cachedConnectionBackendURLKey = "cachedConnectionBackendURLV16"
    private let cachedConnectionAtKey = "cachedConnectionAtV16"

    init() {
        let storedBackend = UserDefaults.standard.string(forKey: "backendURL")?.trimmingCharacters(in: .whitespacesAndNewlines)
        let savedBackend = (storedBackend?.isEmpty == false) ? storedBackend! : "https://outlook-ai-backend.onrender.com"
        self.backendURL = savedBackend
        self.api = APIClient(baseURL: savedBackend)
        Self.removeLegacyAISettings()
        if let savedDeviceId = UserDefaults.standard.string(forKey: "deviceId") {
            self.deviceId = savedDeviceId
        } else {
            let newId = UUID().uuidString
            UserDefaults.standard.set(newId, forKey: "deviceId")
            self.deviceId = newId
        }
        loadLocalSummaryHistory()
        cleanupLocalHistoryAndPDFs()
        loadCachedConnectionStatus()
    }

    private static func removeLegacyAISettings() {
        ["aiModel", "aiBaseUrl", "aiApiKey"].forEach { key in
            UserDefaults.standard.removeObject(forKey: key)
        }
    }


    private var normalizedBackendURL: String {
        backendURL.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
    }

    private func clearCachedConnectionIfBackendChanged() {
        let cachedBackend = UserDefaults.standard.string(forKey: cachedConnectionBackendURLKey)
        if let cachedBackend, cachedBackend != normalizedBackendURL {
            clearCachedConnectionStatus()
        }
    }

    private func loadCachedConnectionStatus() {
        guard UserDefaults.standard.string(forKey: cachedConnectionBackendURLKey) == normalizedBackendURL else {
            clearCachedConnectionStatus()
            return
        }

        let decoder = JSONDecoder()
        if let healthData = UserDefaults.standard.data(forKey: cachedBackendHealthKey),
           let cachedHealth = try? decoder.decode(BackendHealthResponse.self, from: healthData) {
            backendHealth = cachedHealth
        }
        if let imapData = UserDefaults.standard.data(forKey: cachedIMAPStatusKey),
           let cachedIMAP = try? decoder.decode(IMAPTestResponse.self, from: imapData) {
            imapStatus = cachedIMAP
        }

        if imapStatus?.ok == true {
            linkedUser = LinkedUser(displayName: "QQ 邮箱", email: imapStatus?.account, settings: settings, lastRunAt: nil)
            statusText = imapStatus?.account ?? "QQ 邮箱已连接"
            connectionStatus = cachedConnectionStatusText(prefix: "使用上次已连接状态")
            lastError = nil
        }
    }

    private func saveCachedConnectionStatus(health: BackendHealthResponse, imap: IMAPTestResponse) {
        let encoder = JSONEncoder()
        if let healthData = try? encoder.encode(health) {
            UserDefaults.standard.set(healthData, forKey: cachedBackendHealthKey)
        }
        if let imapData = try? encoder.encode(imap) {
            UserDefaults.standard.set(imapData, forKey: cachedIMAPStatusKey)
        }
        UserDefaults.standard.set(normalizedBackendURL, forKey: cachedConnectionBackendURLKey)
        UserDefaults.standard.set(Date(), forKey: cachedConnectionAtKey)
    }

    private func clearCachedConnectionStatus() {
        UserDefaults.standard.removeObject(forKey: cachedBackendHealthKey)
        UserDefaults.standard.removeObject(forKey: cachedIMAPStatusKey)
        UserDefaults.standard.removeObject(forKey: cachedConnectionBackendURLKey)
        UserDefaults.standard.removeObject(forKey: cachedConnectionAtKey)
    }

    private func cachedConnectionStatusText(prefix: String) -> String {
        if let date = UserDefaults.standard.object(forKey: cachedConnectionAtKey) as? Date {
            let formatter = DateFormatter()
            formatter.dateFormat = "yyyy-MM-dd HH:mm"
            return "\(prefix)：\(formatter.string(from: date))。后台会自动刷新，不影响自动总结。"
        }
        return "\(prefix)。后台会自动刷新，不影响自动总结。"
    }


    private func markConnectedAfterSuccessfulSummary() {
        let health = backendHealth ?? BackendHealthResponse(ok: true, time: nil, provider: "imap")
        let imap = imapStatus ?? IMAPTestResponse(
            ok: true,
            account: nil,
            host: nil,
            inboxMailbox: nil,
            messages: nil,
            unseen: nil,
            error: nil
        )
        backendHealth = health
        imapStatus = imap
        saveCachedConnectionStatus(health: health, imap: imap)
        linkedUser = LinkedUser(displayName: "QQ 邮箱", email: imap.account, settings: settings, lastRunAt: nil)
        statusText = imap.account ?? "QQ 邮箱已连接"
        connectionStatus = "总结接口已成功，已保留连接状态；自动总结由后端按频率执行。"
    }

    func bootstrap() async {
        cleanupLocalHistoryAndPDFs()
        await registerDevice(showErrors: false)
        // App 启动/重进时不再阻塞等待 IMAP 检查；先使用上次成功连接状态，后台静默刷新。
        Task { await refreshBackendConnection(showErrors: false) }
        Task { await refreshSchedulerStatus(showErrors: false) }
    }

    var historyGroups: [LocalSummaryDayGroup] {
        let grouped = Dictionary(grouping: historySummaries) { $0.dateTitle }
        return grouped.keys.sorted(by: >).map { key in
            LocalSummaryDayGroup(
                id: key,
                dateTitle: key,
                records: (grouped[key] ?? []).sorted { $0.createdAt > $1.createdAt }
            )
        }
    }

    var backendValidationMessage: String? {
        let raw = backendURL.trimmingCharacters(in: .whitespacesAndNewlines)
        if raw.isEmpty {
            return "先到设置里填写后端地址。真机需要 HTTPS 后端地址，不能直接用 localhost。"
        }
        guard let components = URLComponents(string: raw),
              let scheme = components.scheme?.lowercased(),
              let host = components.host?.lowercased(),
              ["http", "https"].contains(scheme) else {
            return "后端地址格式不正确。示例：https://你的后端域名"
        }

        #if targetEnvironment(simulator)
        return nil
        #else
        if host == "localhost" || host == "127.0.0.1" || host == "::1" {
            return "真机里的 localhost 是 iPad/iPhone 自己，不是后端服务器。请填部署后的 HTTPS 地址，或用 ngrok/Cloudflare Tunnel 暴露本地后端。"
        }
        return nil
        #endif
    }

    func registerDevice(showErrors: Bool = true) async {
        guard backendValidationMessage == nil else {
            if showErrors { statusText = "请先配置后端地址" }
            return
        }
        do {
            _ = try await api.registerDevice(deviceId: deviceId, deviceToken: pushToken)
        } catch {
            if showErrors { lastError = error.localizedDescription }
        }
    }

    func refreshAll() async {
        cleanupLocalHistoryAndPDFs()
        await refreshBackendConnection(showErrors: true)
        if let message = backendValidationMessage {
            linkedUser = nil
            statusText = "请先配置后端地址"
            lastError = message
            return
        }

        // 手动刷新也优先保留上次成功状态；不要因为一次网络检查超时就把自动总结状态打断。
        guard imapStatus?.ok == true else {
            linkedUser = nil
            statusText = "QQ IMAP 未连接"
            if backendHealth?.ok == true {
                lastError = imapStatus?.error ?? "QQ IMAP 测试未通过"
            }
            return
        }

        linkedUser = LinkedUser(displayName: "QQ 邮箱", email: imapStatus?.account, settings: settings, lastRunAt: nil)
        statusText = imapStatus?.account ?? "QQ 邮箱已连接"
        lastError = nil
    }

    func refreshBackendConnection(showErrors: Bool = true) async {
        if let message = backendValidationMessage {
            connectionStatus = "后端地址无效"
            if showErrors { lastError = message }
            return
        }

        do {
            let health = try await api.health()
            backendHealth = health

            let imap = try await api.imapTest()
            imapStatus = imap

            if health.ok && imap.ok {
                saveCachedConnectionStatus(health: health, imap: imap)
                connectionStatus = "后端正常，QQ 邮箱 IMAP 已连接；自动总结不会依赖每次打开 App 的检查。"
                statusText = imap.account ?? "QQ 邮箱已连接"
                linkedUser = LinkedUser(displayName: "QQ 邮箱", email: imap.account, settings: settings, lastRunAt: nil)
                lastError = nil
            } else if health.ok {
                clearCachedConnectionStatus()
                connectionStatus = "后端正常，但 QQ 邮箱未连接"
                linkedUser = nil
                statusText = "QQ IMAP 未连接"
                if showErrors { lastError = imap.error ?? "IMAP 测试未通过" }
            } else {
                connectionStatus = "后端异常"
                if showErrors { lastError = "后端健康检查失败" }
            }
        } catch {
            if imapStatus?.ok == true {
                connectionStatus = cachedConnectionStatusText(prefix: "本次后台检查失败，继续使用上次已连接状态")
                statusText = imapStatus?.account ?? "QQ 邮箱已连接"
                linkedUser = LinkedUser(displayName: "QQ 邮箱", email: imapStatus?.account, settings: settings, lastRunAt: nil)
                if showErrors {
                    lastError = "本次连接检查失败，但已保留上次成功连接状态：\(error.localizedDescription)"
                } else {
                    lastError = nil
                }
            } else {
                backendHealth = nil
                imapStatus = nil
                connectionStatus = "无法连接后端"
                if showErrors { lastError = error.localizedDescription }
            }
        }
    }

    func testAIModel() async {
        if let message = backendValidationMessage {
            lastError = message
            return
        }
        isLoading = true
        aiTestStatus = "正在测试后端 AI 模型..."
        defer { isLoading = false }

        do {
            let response = try await api.testAIModel(deviceId: deviceId)
            if response.ok {
                aiTestStatus = "AI 模型可用"
                lastError = nil
            } else {
                aiTestStatus = "AI 模型测试失败"
                lastError = response.error ?? "后端返回失败状态"
            }
        } catch {
            aiTestStatus = "AI 模型测试失败"
            lastError = error.localizedDescription
        }
    }

    func refreshSchedulerStatus(showErrors: Bool = true) async {
        if let message = backendValidationMessage {
            schedulerStatusText = "后端地址无效，无法检查自动总结。"
            if showErrors { lastError = message }
            return
        }
        do {
            let response = try await api.schedulerStatus()
            schedulerStatus = response
            let enabled = response.schedulerEnabled == true
            let interval = response.schedulerIntervalMinutes ?? response.scheduler?.intervalMinutes ?? 15
            let user = response.users?.first
            var text = enabled ? "后端自动总结已启用，每 \(interval) 分钟检查一次。" : "后端自动总结未启用。"
            if let due = user?.due, due {
                text += " 当前已到期，后端下次调度会自动执行。"
            } else if let next = user?.nextDueAt, !next.isEmpty {
                text += " 下次预计：\(next)。"
            }
            if let lastRun = user?.lastRunAt ?? response.scheduler?.lastRunAt {
                text += " 上次正式总结：\(lastRun)。"
            }
            if let error = response.scheduler?.lastError, !error.isEmpty {
                text += " 最近错误：\(error)。"
            }
            schedulerStatusText = text
        } catch {
            schedulerStatusText = "自动总结状态检查失败：\(error.localizedDescription)"
            if showErrors { lastError = error.localizedDescription }
        }
    }

    func saveSettings() async {
        if let message = backendValidationMessage {
            lastError = message
            return
        }
        isLoading = true
        defer { isLoading = false }
        do {
            let response = try await api.updateSettings(deviceId: deviceId, settings: settings)
            settings = response.settings
            lastError = nil
            connectionStatus = "设置已保存；自动总结由 Render 后端按频率执行。"
            await refreshSchedulerStatus(showErrors: false)
        } catch {
            lastError = error.localizedDescription
        }
    }

    func runNow() async {
        await runTestSummary()
    }

    func runTestSummary() async {
        if let message = backendValidationMessage {
            lastError = message
            return
        }
        isLoading = true
        testSummaryStatus = "正在测试最新 3 封邮件...\n仅测试最新 3 封邮件，不会处理全部历史邮件。"
        defer { isLoading = false }
        do {
            let response = try await api.runTestSummary()
            if response.ok {
                let record = saveSuccessfulSummary(response, fallbackTitle: "QQ 邮箱测试总结")
                markConnectedAfterSuccessfulSummary()

                let testedCount = response.effectiveProcessedCount ?? record.processedCount
                var message = "已测试 \(testedCount) 封邮件，结果已保存到历史总结。"
                if record.content.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                    message += "\n后端未返回总结内容。"
                } else {
                    message += "\n请在下方历史总结中查看完整报告。"
                }
                if response.hasMore == true {
                    message += "\n邮件较多，本次只测试了部分邮件。"
                }
                testSummaryStatus = message
            } else {
                testSummaryStatus = "测试总结失败\n" + (response.error ?? response.message ?? "后端未返回成功状态")
            }
            lastError = nil
        } catch {
            let message = userFacingSummaryError(error)
            testSummaryStatus = "测试总结失败\n" + message
            lastError = message
        }
    }

    func runScheduledSummaryNow() async {
        if let message = backendValidationMessage {
            lastError = message
            return
        }
        isLoading = true
        testSummaryStatus = "正在按当前频率窗口执行正式总结..."
        defer { isLoading = false }
        do {
            let response = try await api.runScheduledSummary(frequency: settings.frequency)
            if response.ok {
                let record = saveSuccessfulSummary(response, fallbackTitle: "QQ 邮箱邮件总结")
                markConnectedAfterSuccessfulSummary()

                let processedCount = response.effectiveProcessedCount ?? record.processedCount
                testSummaryStatus = "正式总结完成：处理 \(processedCount) 封邮件，结果已保存到历史总结。"
                if !record.content.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                    testSummaryStatus += "\n请在下方历史总结中查看完整报告。"
                }
                if response.hasMore == true {
                    testSummaryStatus += "\n邮件较多，本次只处理了窗口内部分邮件。"
                }
            } else {
                testSummaryStatus = "正式总结失败\n" + (response.error ?? response.message ?? "后端未返回成功状态")
            }
            lastError = nil
        } catch {
            let message = userFacingSummaryError(error)
            testSummaryStatus = "正式总结失败\n" + message
            lastError = message
        }
    }

    private func userFacingSummaryError(_ error: Error) -> String {
        let nsError = error as NSError
        if nsError.domain == NSURLErrorDomain && nsError.code == NSURLErrorTimedOut {
            return "邮件较多或 AI 响应较慢，请稍后重试。测试模式只会处理最近 3 封。"
        }
        if let formatError = error as? BackendDecodeFormatError {
            return formatError.localizedDescription
        }
        return error.localizedDescription
    }

    func requestNotifications() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .badge, .sound]) { granted, error in
            DispatchQueue.main.async {
                if let error { self.lastError = error.localizedDescription }
                if granted { UIApplication.shared.registerForRemoteNotifications() }
            }
        }
    }

    func sendTestNotification() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .badge, .sound]) { granted, error in
            DispatchQueue.main.async {
                if let error {
                    self.notificationStatus = "测试通知失败"
                    self.lastError = error.localizedDescription
                    return
                }
                guard granted else {
                    self.notificationStatus = "请在系统设置中允许 Mail AI 通知。"
                    self.lastError = "请在系统设置中允许 Mail AI 通知。"
                    return
                }

                let content = UNMutableNotificationContent()
                content.title = "Mail AI 测试通知"
                content.body = "如果你看到这条通知，说明推送通知功能正常。"
                content.sound = .default
                let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 3, repeats: false)
                let request = UNNotificationRequest(identifier: "mail-ai-local-test-\(UUID().uuidString)", content: content, trigger: trigger)
                UNUserNotificationCenter.current().add(request) { addError in
                    DispatchQueue.main.async {
                        if let addError {
                            self.notificationStatus = "测试通知失败"
                            self.lastError = addError.localizedDescription
                        } else {
                            self.notificationStatus = "测试通知已发送，约 3 秒后显示。"
                            self.lastError = nil
                            UIApplication.shared.registerForRemoteNotifications()
                        }
                    }
                }
            }
        }
    }

    func updatePushToken(_ token: String) {
        pushToken = token
        Task { await registerDevice() }
    }

    private func saveSuccessfulSummary(_ response: RunSummaryResponse, fallbackTitle: String) -> LocalSummaryRecord {
        let now = Date()
        let createdAt = parseISODate(response.summary?.createdAt) ?? now
        let rawContent = (response.displaySummaryText ?? response.message ?? "后端未返回总结内容。")
            .trimmingCharacters(in: .whitespacesAndNewlines)
        let processedCount = response.effectiveProcessedCount ?? 0
        let importantCount = response.importantCount ?? 0
        let spamCount = response.spamCount ?? response.summary?.junkUnreadCount ?? 0
        let content = normalizedSummaryContent(
            rawContent,
            startTime: response.startTime,
            endTime: response.endTime,
            processedCount: processedCount,
            importantCount: importantCount,
            spamCount: spamCount
        )
        var record = LocalSummaryRecord(
            id: response.summary?.id ?? UUID().uuidString,
            title: response.summary?.title ?? fallbackTitle,
            content: content,
            createdAt: createdAt,
            startTime: response.startTime,
            endTime: response.endTime,
            processedCount: processedCount,
            importantCount: importantCount,
            spamCount: spamCount,
            pdfFileName: nil,
            backendPDFInfo: response.backendPDFInfo
        )

        if let pdfURL = generatePDF(for: record) {
            record.pdfFileName = pdfURL.lastPathComponent
        }

        historySummaries.removeAll { $0.id == record.id }
        historySummaries.insert(record, at: 0)
        historySummaries.sort { $0.createdAt > $1.createdAt }
        cleanupLocalHistoryAndPDFs(saveAfterCleanup: false)
        saveLocalSummaryHistory()
        return record
    }

    private func normalizedSummaryContent(
        _ raw: String,
        startTime: String?,
        endTime: String?,
        processedCount: Int,
        importantCount: Int,
        spamCount: Int
    ) -> String {
        let trimmed = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        if trimmed.contains("【邮件总结】") { return trimmed }

        var lines: [String] = ["【邮件总结】"]
        if let startTime, let endTime, !startTime.isEmpty, !endTime.isEmpty {
            lines.append("时间范围：\(startTime) - \(endTime)")
        }
        lines.append("处理邮件：\(processedCount) 封")
        lines.append("重要邮件：\(importantCount) 封")
        lines.append("垃圾/低价值邮件：\(spamCount) 封")
        lines.append("")
        lines.append(trimmed.isEmpty ? "后端未返回总结内容。" : trimmed)
        return lines.joined(separator: "\n")
    }

    private func loadLocalSummaryHistory() {
        guard let data = UserDefaults.standard.data(forKey: historyKey),
              let decoded = try? JSONDecoder().decode([LocalSummaryRecord].self, from: data) else {
            historySummaries = []
            return
        }
        historySummaries = decoded.sorted { $0.createdAt > $1.createdAt }
    }

    private func saveLocalSummaryHistory() {
        if let data = try? JSONEncoder().encode(historySummaries) {
            UserDefaults.standard.set(data, forKey: historyKey)
        }
    }

    func pdfURL(for record: LocalSummaryRecord) -> URL? {
        guard let fileName = record.pdfFileName else { return nil }
        let url = pdfDirectoryURL().appendingPathComponent(fileName)
        return FileManager.default.fileExists(atPath: url.path) ? url : nil
    }

    func hasPDF(for record: LocalSummaryRecord) -> Bool {
        pdfURL(for: record) != nil
    }

    func regeneratePDF(for recordId: String) {
        guard let index = historySummaries.firstIndex(where: { $0.id == recordId }) else { return }
        let record = historySummaries[index]
        if let url = generatePDF(for: record) {
            historySummaries[index].pdfFileName = url.lastPathComponent
            saveLocalSummaryHistory()
            lastError = nil
        } else {
            lastError = "重新生成 PDF 失败"
        }
    }

    private func generatePDF(for record: LocalSummaryRecord) -> URL? {
        let directory = pdfDirectoryURL()
        do {
            try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true, attributes: nil)
        } catch {
            lastError = error.localizedDescription
            return nil
        }

        let fileName = record.pdfFileName ?? makePDFFileName(for: record.createdAt, id: record.id)
        let url = directory.appendingPathComponent(fileName)
        let parsed = SummaryParser.parse(record)
        let pageRect = CGRect(x: 0, y: 0, width: 595.2, height: 841.8) // A4, 72 dpi
        let margin: CGFloat = 42
        let contentWidth = pageRect.width - margin * 2
        let bottomLimit = pageRect.height - 54
        let renderer = UIGraphicsPDFRenderer(bounds: pageRect)


        do {
            try renderer.writePDF(to: url) { context in
                var pageNumber = 0
                var y: CGFloat = margin

                func drawFooter() {
                    let footer = "Generated by Mail AI  ·  第 \(pageNumber) 页"
                    let footerAttrs = mailPDFAttributes(font: .systemFont(ofSize: 9), color: UIColor.darkGray)
                    let rect = CGRect(x: margin, y: pageRect.height - 34, width: contentWidth, height: 16)
                    NSAttributedString(string: footer, attributes: footerAttrs).draw(in: rect)
                }

                func beginPage() {
                    context.beginPage()
                    pageNumber += 1
                    UIColor.white.setFill()
                    context.cgContext.fill(pageRect)
                    drawFooter()
                    y = margin
                }

                func ensureSpace(_ height: CGFloat) {
                    if y + height > bottomLimit {
                        beginPage()
                    }
                }

                func drawText(_ text: String, font: UIFont, color: UIColor = .black, x: CGFloat = margin, width: CGFloat = contentWidth, extraBottom: CGFloat = 4) {
                    let attrs = mailPDFAttributes(font: font, color: color)
                    let height = mailPDFMeasuredHeight(text, width: width, attrs: attrs) + 2
                    ensureSpace(height + extraBottom)
                    let rect = CGRect(x: x, y: y, width: width, height: height)
                    guard pageRect.contains(CGPoint(x: rect.minX, y: rect.minY)) else { return }
                    NSAttributedString(string: text, attributes: attrs).draw(
                        with: rect,
                        options: [.usesLineFragmentOrigin, .usesFontLeading],
                        context: nil
                    )
                    y += height + extraBottom
                }

                func drawSectionTitle(_ title: String) {
                    ensureSpace(42)
                    drawText(title, font: .boldSystemFont(ofSize: 16), color: .black, extraBottom: 8)
                }

                func drawStatCards() {
                    let gap: CGFloat = 10
                    let cardWidth = (contentWidth - gap * 2) / 3
                    let cardHeight: CGFloat = 58
                    ensureSpace(cardHeight + 18)
                    let stats = [
                        ("处理邮件", "\(parsed.processedCount) 封"),
                        ("重要邮件", "\(parsed.importantCount) 封"),
                        ("低价值邮件", "\(parsed.spamCount) 封")
                    ]
                    for index in 0..<stats.count {
                        let x = margin + CGFloat(index) * (cardWidth + gap)
                        let rect = CGRect(x: x, y: y, width: cardWidth, height: cardHeight)
                        UIColor(white: 0.96, alpha: 1).setFill()
                        UIBezierPath(roundedRect: rect, cornerRadius: 10).fill()
                        UIColor(white: 0.86, alpha: 1).setStroke()
                        UIBezierPath(roundedRect: rect, cornerRadius: 10).stroke()
                        drawString(stats[index].0, in: CGRect(x: x + 12, y: y + 10, width: cardWidth - 24, height: 16), font: .systemFont(ofSize: 10), color: .darkGray)
                        drawString(stats[index].1, in: CGRect(x: x + 12, y: y + 29, width: cardWidth - 24, height: 22), font: .boldSystemFont(ofSize: 17), color: .black)
                    }
                    y += cardHeight + 18
                }

                func drawString(_ text: String, in rect: CGRect, font: UIFont, color: UIColor) {
                    let attrs = mailPDFAttributes(font: font, color: color)
                    NSAttributedString(string: text, attributes: attrs).draw(
                        with: rect,
                        options: [.usesLineFragmentOrigin, .usesFontLeading],
                        context: nil
                    )
                }

                func drawList(_ lines: [String], emptyText: String = "暂无") {
                    let values = lines.isEmpty ? [emptyText] : lines
                    for (index, line) in values.enumerated() {
                        drawText("\(index + 1). \(line)", font: .systemFont(ofSize: 11.5), color: .black, extraBottom: 3)
                    }
                    y += 4
                }

                func drawSmallCard(_ text: String, fill: UIColor, border: UIColor = UIColor(white: 0.86, alpha: 1)) {
                    let innerWidth = contentWidth - 24
                    let h = mailPDFMeasuredHeight(text, width: innerWidth, attrs: mailPDFAttributes(font: .systemFont(ofSize: 11.5))) + 22
                    ensureSpace(h + 8)
                    let rect = CGRect(x: margin, y: y, width: contentWidth, height: h)
                    fill.setFill()
                    UIBezierPath(roundedRect: rect, cornerRadius: 10).fill()
                    border.setStroke()
                    UIBezierPath(roundedRect: rect, cornerRadius: 10).stroke()
                    drawString(text, in: CGRect(x: margin + 12, y: y + 11, width: innerWidth, height: h - 18), font: .systemFont(ofSize: 11.5), color: .black)
                    y += h + 8
                }

                func priorityColor(_ priority: String) -> UIColor {
                    let value = priority.lowercased()
                    if value.contains("高") || value.contains("high") || value.contains("urgent") { return UIColor(red: 0.95, green: 0.36, blue: 0.16, alpha: 1) }
                    if value.contains("中") || value.contains("medium") { return UIColor(red: 0.95, green: 0.70, blue: 0.20, alpha: 1) }
                    return UIColor(white: 0.45, alpha: 1)
                }

                func drawEmailCard(_ item: ParsedEmailItem) {
                    let innerX = margin + 14
                    let innerWidth = contentWidth - 28
                    var rows: [(String, String, UIFont, UIColor)] = []
                    if !item.subject.isEmpty { rows.append(("主题", item.subject, .boldSystemFont(ofSize: 12.5), .black)) }
                    if !item.sender.isEmpty { rows.append(("发件人", item.sender, .systemFont(ofSize: 11), .darkGray)) }
                    if !item.time.isEmpty { rows.append(("时间", item.time, .systemFont(ofSize: 11), .darkGray)) }
                    if !item.summary.isEmpty { rows.append(("摘要", item.summary, .systemFont(ofSize: 11.5), .black)) }
                    if !item.action.isEmpty { rows.append(("需要操作", item.action, .systemFont(ofSize: 11.5), .black)) }
                    if !item.deadline.isEmpty { rows.append(("截止时间", item.deadline, .systemFont(ofSize: 11.5), .black)) }
                    if !item.priority.isEmpty { rows.append(("优先级", item.priority, .boldSystemFont(ofSize: 11), priorityColor(item.priority))) }

                    var height: CGFloat = 22
                    for row in rows {
                        height += mailPDFMeasuredHeight("\(row.0)：\(row.1)", width: innerWidth, attrs: mailPDFAttributes(font: row.2, color: row.3)) + 4
                    }
                    ensureSpace(height + 10)
                    let rect = CGRect(x: margin, y: y, width: contentWidth, height: height)
                    UIColor(white: 0.97, alpha: 1).setFill()
                    UIBezierPath(roundedRect: rect, cornerRadius: 12).fill()
                    UIColor(white: 0.84, alpha: 1).setStroke()
                    UIBezierPath(roundedRect: rect, cornerRadius: 12).stroke()
                    y += 11
                    for row in rows {
                        drawText("\(row.0)：\(row.1)", font: row.2, color: row.3, x: innerX, width: innerWidth, extraBottom: 2)
                    }
                    y = max(y, rect.maxY + 10)
                }

                beginPage()
                drawText("Mail AI 邮件总结", font: .boldSystemFont(ofSize: 26), color: .black, extraBottom: 4)
                drawText(parsed.timeRange, font: .systemFont(ofSize: 12), color: .darkGray, extraBottom: 14)
                drawStatCards()

                drawSectionTitle("一、重点提醒")
                drawList(parsed.reminders)

                drawSectionTitle("二、重要邮件")
                if parsed.importantEmails.isEmpty {
                    drawList(parsed.importantFallback)
                } else {
                    for item in parsed.importantEmails { drawEmailCard(item) }
                }

                drawSectionTitle("三、普通邮件")
                drawList(parsed.normalSummary)

                drawSectionTitle("四、垃圾邮件 / 可忽略邮件")
                let spamValues = parsed.spamSummary.isEmpty ? ["暂无明显垃圾或低价值邮件。"] : parsed.spamSummary
                for line in spamValues { drawSmallCard(line, fill: UIColor(white: 0.94, alpha: 1)) }

                drawSectionTitle("五、风险提醒")
                if parsed.hasRisk {
                    for line in parsed.risks { drawSmallCard(line, fill: UIColor(red: 1.0, green: 0.92, blue: 0.82, alpha: 1), border: UIColor(red: 0.95, green: 0.55, blue: 0.20, alpha: 1)) }
                } else {
                    drawSmallCard(parsed.risks.first ?? "暂无明显风险。", fill: UIColor(red: 0.88, green: 0.97, blue: 0.90, alpha: 1), border: UIColor(red: 0.35, green: 0.70, blue: 0.42, alpha: 1))
                }

                drawSectionTitle("六、下一步建议")
                let steps = parsed.nextSteps.isEmpty ? ["暂无下一步操作。"] : parsed.nextSteps
                for step in steps { drawText("☐ \(step)", font: .systemFont(ofSize: 11.5), color: .black, extraBottom: 3) }

                if parsed.reminders.isEmpty && parsed.importantEmails.isEmpty && parsed.importantFallback.isEmpty && parsed.normalSummary.isEmpty && parsed.spamSummary.isEmpty && parsed.risks.isEmpty && parsed.nextSteps.isEmpty {
                    drawSectionTitle("原始总结")
                    drawList(parsed.fallbackParagraphs)
                }
            }

            let fileAttributes = try? FileManager.default.attributesOfItem(atPath: url.path)
            let size = (fileAttributes?[.size] as? NSNumber)?.intValue ?? 0
            if size < 5 * 1024 {
                try? FileManager.default.removeItem(at: url)
                lastError = "PDF 生成失败：文件异常小，已避免保存空白 PDF。"
                return nil
            }
            return url
        } catch {
            try? FileManager.default.removeItem(at: url)
            lastError = error.localizedDescription
            return nil
        }
    }

    private func pdfDirectoryURL() -> URL {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first
            ?? FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        return base.appendingPathComponent("MailAISummaryPDFs", isDirectory: true)
    }

    private func makePDFFileName(for date: Date, id: String) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd_HH-mm"
        let suffix = String(id.prefix(6))
        return "mail_summary_\(formatter.string(from: date))_\(suffix).pdf"
    }

    private func cleanupLocalHistoryAndPDFs(saveAfterCleanup: Bool = true) {
        let now = Date()
        let textCutoff = now.addingTimeInterval(TimeInterval(-textRetentionDays * 24 * 60 * 60))
        let pdfCutoff = now.addingTimeInterval(TimeInterval(-pdfRetentionDays * 24 * 60 * 60))
        let manager = FileManager.default
        let pdfDirectory = pdfDirectoryURL()

        var changed = false
        let removed = historySummaries.filter { $0.createdAt < textCutoff }
        if !removed.isEmpty {
            changed = true
            for record in removed {
                if let fileName = record.pdfFileName {
                    try? manager.removeItem(at: pdfDirectory.appendingPathComponent(fileName))
                }
            }
            historySummaries.removeAll { $0.createdAt < textCutoff }
        }

        for index in historySummaries.indices {
            guard let fileName = historySummaries[index].pdfFileName else { continue }
            let url = pdfDirectory.appendingPathComponent(fileName)
            if historySummaries[index].createdAt < pdfCutoff || !manager.fileExists(atPath: url.path) {
                try? manager.removeItem(at: url)
                historySummaries[index].pdfFileName = nil
                changed = true
            }
        }

        if let files = try? manager.contentsOfDirectory(at: pdfDirectory, includingPropertiesForKeys: [.creationDateKey], options: []) {
            for file in files where file.pathExtension.lowercased() == "pdf" {
                let values = try? file.resourceValues(forKeys: [.creationDateKey])
                if let created = values?.creationDate, created < pdfCutoff {
                    try? manager.removeItem(at: file)
                }
            }
        }

        historySummaries.sort { $0.createdAt > $1.createdAt }
        if changed && saveAfterCleanup { saveLocalSummaryHistory() }
    }

    private func parseISODate(_ value: String?) -> Date? {
        guard let value else { return nil }
        let iso = ISO8601DateFormatter()
        if let date = iso.date(from: value) { return date }
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSXXXXX"
        return formatter.date(from: value)
    }
}

func cleanMarkdownForPlainText(_ text: String) -> String {
    text
        .replacingOccurrences(of: "**", with: "")
        .replacingOccurrences(of: #"(?m)^\s*#{1,6}\s*"#, with: "", options: .regularExpression)
        .trimmingCharacters(in: .whitespacesAndNewlines)
}


private func mailPDFParagraphStyle(lineSpacing: CGFloat = 3, paragraphSpacing: CGFloat = 5) -> NSMutableParagraphStyle {
    let style = NSMutableParagraphStyle()
    style.lineSpacing = lineSpacing
    style.paragraphSpacing = paragraphSpacing
    style.lineBreakMode = .byWordWrapping
    return style
}

private func mailPDFAttributes(font: UIFont, color: UIColor = .black, lineSpacing: CGFloat = 3) -> [NSAttributedString.Key: Any] {
    [
        .font: font,
        .foregroundColor: color,
        .paragraphStyle: mailPDFParagraphStyle(lineSpacing: lineSpacing)
    ]
}

private func mailPDFMeasuredHeight(_ text: String, width: CGFloat, attrs: [NSAttributedString.Key: Any]) -> CGFloat {
    let value = text.isEmpty ? " " : text
    return ceil(NSAttributedString(string: value, attributes: attrs).boundingRect(
        with: CGSize(width: max(10, width), height: .greatestFiniteMagnitude),
        options: [.usesLineFragmentOrigin, .usesFontLeading],
        context: nil
    ).height)
}
