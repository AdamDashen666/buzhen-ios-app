import SwiftUI

@main
struct BuzhenLocalApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
