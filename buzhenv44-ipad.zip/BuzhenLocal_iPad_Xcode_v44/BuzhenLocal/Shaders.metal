#include <metal_stdlib>
using namespace metal;

struct FlowParams {
    float alpha;
    float blendStrength;
    float sharpenAmount;
    float consistencyStrength;
};

kernel void flowWarpBlend(
    texture2d<float, access::sample> previous [[texture(0)]],
    texture2d<float, access::sample> next [[texture(1)]],
    texture2d<float, access::sample> flow [[texture(2)]],
    texture2d<float, access::write> output [[texture(3)]],
    constant FlowParams &params [[buffer(0)]],
    uint2 gid [[thread_position_in_grid]]
) {
    if (gid.x >= output.get_width() || gid.y >= output.get_height()) {
        return;
    }

    constexpr sampler s(address::clamp_to_edge, filter::linear);

    float alpha = clamp(params.alpha, 0.0, 1.0);
    float blendStrength = clamp(params.blendStrength, 0.0, 1.0);
    float sharpenAmount = clamp(params.sharpenAmount, 0.0, 0.45);

    float2 size = float2(output.get_width(), output.get_height());
    float2 texel = 1.0 / size;
    float2 uv = (float2(gid) + 0.5) / size;

    float2 flowUV = (float2(gid) + 0.5) / float2(flow.get_width(), flow.get_height());
    float2 motion = flow.sample(s, flowUV).xy;

    // previous 按 alpha 往 next 方向推，next 按 1-alpha 往 previous 方向拉。
    float2 prevUV = uv - (motion * alpha) / size;
    float2 nextUV = uv + (motion * (1.0 - alpha)) / size;

    float4 a = previous.sample(s, prevUV);
    float4 b = next.sample(s, nextUV);

    // 原始双向混合更顺滑，但高速运动容易出现双影/糊。
    // 抗模糊模式降低双帧混合权重，更多保留主导帧细节。
    float4 warpedBlend = mix(a, b, alpha);
    float4 dominant = alpha < 0.5 ? a : b;
    float4 result = mix(dominant, warpedBlend, blendStrength);

    if (sharpenAmount > 0.001) {
        float2 dx = float2(texel.x, 0.0);
        float2 dy = float2(0.0, texel.y);

        float4 left = mix(previous.sample(s, prevUV - dx), next.sample(s, nextUV - dx), alpha);
        float4 right = mix(previous.sample(s, prevUV + dx), next.sample(s, nextUV + dx), alpha);
        float4 up = mix(previous.sample(s, prevUV - dy), next.sample(s, nextUV - dy), alpha);
        float4 down = mix(previous.sample(s, prevUV + dy), next.sample(s, nextUV + dy), alpha);
        float4 blur = (left + right + up + down) * 0.25;

        result.rgb = clamp(result.rgb + (result.rgb - blur.rgb) * sharpenAmount, 0.0, 1.0);
    }

    output.write(result, gid);
}


kernel void flowWarpBlendBidirectional(
    texture2d<float, access::sample> previous [[texture(0)]],
    texture2d<float, access::sample> next [[texture(1)]],
    texture2d<float, access::sample> forwardFlow [[texture(2)]],
    texture2d<float, access::sample> reverseFlow [[texture(3)]],
    texture2d<float, access::write> output [[texture(4)]],
    constant FlowParams &params [[buffer(0)]],
    uint2 gid [[thread_position_in_grid]]
) {
    if (gid.x >= output.get_width() || gid.y >= output.get_height()) {
        return;
    }

    constexpr sampler s(address::clamp_to_edge, filter::linear);

    float alpha = clamp(params.alpha, 0.0, 1.0);
    float blendStrength = clamp(params.blendStrength, 0.0, 1.0);
    float sharpenAmount = clamp(params.sharpenAmount, 0.0, 0.45);
    float consistencyStrength = clamp(params.consistencyStrength, 0.0, 1.0);

    float2 size = float2(output.get_width(), output.get_height());
    float2 texel = 1.0 / size;
    float2 uv = (float2(gid) + 0.5) / size;

    float2 flowSize = float2(forwardFlow.get_width(), forwardFlow.get_height());
    float2 flowUV = (float2(gid) + 0.5) / flowSize;

    float2 fwd = forwardFlow.sample(s, flowUV).xy;
    float2 rev = reverseFlow.sample(s, flowUV).xy;

    // 双向 veryHigh 光流：前一帧往后一帧推，后一帧往前一帧拉。
    float2 prevUV = uv - (fwd * alpha) / size;
    float2 nextUV = uv - (rev * (1.0 - alpha)) / size;

    float4 a = previous.sample(s, prevUV);
    float4 b = next.sample(s, nextUV);

    float4 warpedBlend = mix(a, b, alpha);
    float4 dominant = alpha < 0.5 ? a : b;

    // 一致性检查：双向光流越不一致，越可能有遮挡/鬼影/拖影，降低混合权重。
    float2 fwdAtPrev = forwardFlow.sample(s, clamp(prevUV, float2(0.0), float2(1.0))).xy;
    float2 revAtNext = reverseFlow.sample(s, clamp(nextUV, float2(0.0), float2(1.0))).xy;
    float consistencyError = length(fwdAtPrev + revAtNext) / (length(fwdAtPrev) + length(revAtNext) + 1.0);
    float antiGhost = clamp(consistencyError * 2.2 * consistencyStrength, 0.0, 1.0);

    float4 stableBlend = mix(dominant, warpedBlend, blendStrength);
    float4 result = mix(stableBlend, dominant, antiGhost);

    if (sharpenAmount > 0.001) {
        float2 dx = float2(texel.x, 0.0);
        float2 dy = float2(0.0, texel.y);

        float4 left = mix(previous.sample(s, prevUV - dx), next.sample(s, nextUV - dx), alpha);
        float4 right = mix(previous.sample(s, prevUV + dx), next.sample(s, nextUV + dx), alpha);
        float4 up = mix(previous.sample(s, prevUV - dy), next.sample(s, nextUV - dy), alpha);
        float4 down = mix(previous.sample(s, prevUV + dy), next.sample(s, nextUV + dy), alpha);
        float4 blur = (left + right + up + down) * 0.25;

        float edge = clamp(length(result.rgb - blur.rgb) * 2.5, 0.0, 1.0);
        float adaptiveSharpen = sharpenAmount * mix(0.65, 1.0, edge);
        result.rgb = clamp(result.rgb + (result.rgb - blur.rgb) * adaptiveSharpen, 0.0, 1.0);
    }

    output.write(result, gid);
}
