import Foundation
import Vision
import CoreVideo

final class VisionFlowEstimator {
    func estimateFlow(
        from previous: CVPixelBuffer,
        to next: CVPixelBuffer,
        quality: OpticalFlowQuality
    ) throws -> CVPixelBuffer {
        let request = VNGenerateOpticalFlowRequest(targetedCVPixelBuffer: next, options: [:])
        request.computationAccuracy = quality.visionAccuracy
        request.outputPixelFormat = kCVPixelFormatType_TwoComponent32Float

        let handler = VNImageRequestHandler(cvPixelBuffer: previous, orientation: .up, options: [:])
        try handler.perform([request])

        guard let observation = request.results?.first as? VNPixelBufferObservation else {
            throw NSError(domain: "BuzhenLocal", code: 2001, userInfo: [NSLocalizedDescriptionKey: "Vision 光流计算失败"])
        }

        return observation.pixelBuffer
    }
}
