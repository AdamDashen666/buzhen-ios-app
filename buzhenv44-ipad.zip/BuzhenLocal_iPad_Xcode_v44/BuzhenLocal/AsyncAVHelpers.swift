import AVFoundation

extension AVAssetWriter {
    func finishWritingAsync() async {
        await withCheckedContinuation { continuation in
            finishWriting {
                continuation.resume()
            }
        }
    }
}

extension AVAssetExportSession {
    func exportAsync() async {
        await withCheckedContinuation { continuation in
            exportAsynchronously {
                continuation.resume()
            }
        }
    }
}
