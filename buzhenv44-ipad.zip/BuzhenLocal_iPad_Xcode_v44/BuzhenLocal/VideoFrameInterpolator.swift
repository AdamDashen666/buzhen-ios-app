import Foundation
import AVFoundation
import CoreMedia
import CoreVideo
import VideoToolbox

final class VideoFrameInterpolator {
    typealias ProgressHandler = @Sendable (Double, String) -> Void

    func interpolate(
        inputURL: URL,
        options: ProcessingOptions,
        progress: @escaping ProgressHandler
    ) async throws -> URL {
        switch options.processingMode {
        case .full:
            let output = try makeOutputURL(prefix: "buzhen_full", mode: options.outputMode)
            return try await processFullVideo(
                inputURL: inputURL,
                outputURL: output,
                options: options,
                progressBase: 0,
                progressSpan: 1,
                progress: progress
            )

        case .serialSegmented:
            return try await processSegmented(
                inputURL: inputURL,
                options: options,
                parallel: false,
                progress: progress
            )

        case .parallelSegmented:
            return try await processSegmented(
                inputURL: inputURL,
                options: options,
                parallel: true,
                progress: progress
            )
        }
    }

    private func processFullVideo(
        inputURL: URL,
        outputURL: URL,
        options: ProcessingOptions,
        progressBase: Double,
        progressSpan: Double,
        progress: @escaping ProgressHandler
    ) async throws -> URL {
        let videoOnly = try makeTempURL(prefix: "buzhen_video_only", ext: options.outputMode.fileExtension)

        let info = try await VideoInspector.inspect(url: inputURL)
        let segment = SegmentJob(index: 0, start: 0, duration: info.duration)
        progress(progressBase, "SEGMENT_SETUP|1|1|full")

        try await processSegmentVideoOnly(
            inputURL: inputURL,
            segment: segment,
            outputURL: videoOnly,
            options: options,
            progressBase: progressBase,
            progressSpan: progressSpan * 0.92,
            progress: progress
        )

        progress(progressBase + progressSpan * 0.94, "STAGE|合并音频/元数据...")

        let muxed = try await muxAudioAndMetadata(
            originalURL: inputURL,
            processedVideoURL: videoOnly,
            outputURL: outputURL,
            options: options
        )

        try? FileManager.default.removeItem(at: videoOnly)
        progress(progressBase + progressSpan, "STAGE|完成")
        return muxed
    }

    private func processSegmented(
        inputURL: URL,
        options: ProcessingOptions,
        parallel: Bool,
        progress: @escaping ProgressHandler
    ) async throws -> URL {
        progress(0.01, "读取视频信息...")

        let info = try await VideoInspector.inspect(url: inputURL)
        let segmentSeconds = max(1, options.segmentSeconds)
        let count = max(1, Int(ceil(info.duration / segmentSeconds)))
        let tempDir = FileManager.default.temporaryDirectory
            .appendingPathComponent("buzhen_segments_\(UUID().uuidString)", isDirectory: true)

        try FileManager.default.createDirectory(at: tempDir, withIntermediateDirectories: true)

        let outputURL = try makeOutputURL(prefix: "buzhen_segmented", mode: options.outputMode)

        defer {
            try? FileManager.default.removeItem(at: tempDir)
        }

        let jobs: [SegmentJob] = (0..<count).map { index in
            let start = Double(index) * segmentSeconds
            let duration = min(segmentSeconds, max(0.05, info.duration - start))
            return SegmentJob(index: index, start: start, duration: duration)
        }

        let segmentOutputs = jobs.map {
            tempDir
                .appendingPathComponent(String(format: "seg_%04d", $0.index))
                .appendingPathExtension(options.outputMode.fileExtension)
        }

        if parallel {
            let workers = min(max(1, options.maxParallelJobs), count)
            let tracker = SegmentProgressTracker(count: count)
            progress(0.02, "SEGMENT_SETUP|\(count)|\(workers)|parallel")

            try await withThrowingTaskGroup(of: Int.self) { group in
                var nextIndex = 0

                func submitNextJob() {
                    guard nextIndex < jobs.count else { return }
                    let job = jobs[nextIndex]
                    let out = segmentOutputs[job.index]
                    nextIndex += 1

                    group.addTask(priority: options.performanceMode.taskPriority) {
                        let startedSummary = await tracker.start(index: job.index)
                        progress(0.02 + 0.80 * startedSummary.average, "SEGMENT_START|\(job.index)|\(job.start)|\(job.duration)")

                        let processor = VideoFrameInterpolator()
                        try await processor.processSegmentVideoOnly(
                            inputURL: inputURL,
                            segment: job,
                            outputURL: out,
                            options: options,
                            progressBase: 0,
                            progressSpan: 0,
                            progress: { localProgress, _ in
                                Task {
                                    let summary = await tracker.update(index: job.index, local: localProgress)
                                    progress(0.02 + 0.80 * summary.average, "SEGMENT_PROGRESS|\(job.index)|\(localProgress)")
                                }
                            }
                        )

                        return job.index
                    }
                }

                for _ in 0..<workers {
                    submitNextJob()
                }

                while let finishedIndex = try await group.next() {
                    let summary = await tracker.complete(index: finishedIndex)
                    progress(0.02 + 0.80 * summary.average, "SEGMENT_DONE|\(finishedIndex)|\(summary.done)|\(count)")
                    submitNextJob()
                }
            }
        } else {
            progress(0.02, "SEGMENT_SETUP|\(count)|1|serial")

            for job in jobs {
                let base = 0.02 + 0.80 * Double(job.index) / Double(count)
                let span = 0.80 / Double(count)
                progress(base, "SEGMENT_START|\(job.index)|\(job.start)|\(job.duration)")

                try await processSegmentVideoOnly(
                    inputURL: inputURL,
                    segment: job,
                    outputURL: segmentOutputs[job.index],
                    options: options,
                    progressBase: base,
                    progressSpan: span,
                    progress: progress
                )
            }
        }

        progress(0.86, "STAGE|合并所有视频段...")
        let joinedVideo = tempDir.appendingPathComponent("joined").appendingPathExtension(options.outputMode.fileExtension)
        try await joinSegments(segmentOutputs: segmentOutputs, outputURL: joinedVideo, outputMode: options.outputMode)

        progress(0.94, "STAGE|合并原音频/元数据...")
        let muxed = try await muxAudioAndMetadata(
            originalURL: inputURL,
            processedVideoURL: joinedVideo,
            outputURL: outputURL,
            options: options
        )

        progress(1.0, "STAGE|完成")
        return muxed
    }

    private func processSegmentVideoOnly(
        inputURL: URL,
        segment: SegmentJob,
        outputURL: URL,
        options: ProcessingOptions,
        progressBase: Double,
        progressSpan: Double,
        progress: @escaping ProgressHandler
    ) async throws {
        let asset = AVURLAsset(url: inputURL)
        let videoTracks = try await asset.loadTracks(withMediaType: .video)

        guard let videoTrack = videoTracks.first else {
            throw NSError(domain: "BuzhenLocal", code: 4001, userInfo: [NSLocalizedDescriptionKey: "没有找到视频轨道"])
        }

        let naturalSize = try await videoTrack.load(.naturalSize)
        let transform = try await videoTrack.load(.preferredTransform)

        let width = Int(abs(naturalSize.width))
        let height = Int(abs(naturalSize.height))

        if FileManager.default.fileExists(atPath: outputURL.path) {
            try FileManager.default.removeItem(at: outputURL)
        }

        let reader = try AVAssetReader(asset: asset)
        reader.timeRange = CMTimeRange(
            start: CMTime(seconds: segment.start, preferredTimescale: 600),
            duration: CMTime(seconds: segment.duration, preferredTimescale: 600)
        )

        let readerOutput = AVAssetReaderTrackOutput(
            track: videoTrack,
            outputSettings: [
                kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA,
                kCVPixelBufferMetalCompatibilityKey as String: true
            ]
        )
        readerOutput.alwaysCopiesSampleData = false

        guard reader.canAdd(readerOutput) else {
            throw NSError(domain: "BuzhenLocal", code: 4002, userInfo: [NSLocalizedDescriptionKey: "无法创建视频读取器"])
        }
        reader.add(readerOutput)

        let writer = try AVAssetWriter(outputURL: outputURL, fileType: options.outputMode.fileType)
        let writerInput = AVAssetWriterInput(mediaType: .video, outputSettings: makeVideoSettings(width: width, height: height, options: options))
        writerInput.expectsMediaDataInRealTime = false
        writerInput.transform = transform

        let adaptor = AVAssetWriterInputPixelBufferAdaptor(
            assetWriterInput: writerInput,
            sourcePixelBufferAttributes: [
                kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA,
                kCVPixelBufferWidthKey as String: width,
                kCVPixelBufferHeightKey as String: height,
                kCVPixelBufferMetalCompatibilityKey as String: true,
                kCVPixelBufferIOSurfacePropertiesKey as String: [:]
            ]
        )

        guard writer.canAdd(writerInput) else {
            throw NSError(domain: "BuzhenLocal", code: 4003, userInfo: [NSLocalizedDescriptionKey: "无法创建视频写入器"])
        }
        writer.add(writerInput)

        guard reader.startReading() else {
            throw reader.error ?? NSError(domain: "BuzhenLocal", code: 4004, userInfo: [NSLocalizedDescriptionKey: "读取视频失败"])
        }

        guard writer.startWriting() else {
            throw writer.error ?? NSError(domain: "BuzhenLocal", code: 4005, userInfo: [NSLocalizedDescriptionKey: "写入视频失败"])
        }
        writer.startSession(atSourceTime: .zero)

        let renderer = try MetalFrameRenderer()
        let estimator = VisionFlowEstimator()

        guard let first = copyNextFrame(from: readerOutput) else {
            writerInput.markAsFinished()
            await writer.finishWritingAsync()
            return
        }

        var current = first
        var outputSourceTime = CMTimeGetSeconds(first.pts)
        let firstSourceTime = outputSourceTime
        let outputStep = 1.0 / max(1, options.targetFPS)
        var outputFrameIndex = 0

        while let next = copyNextFrame(from: readerOutput) {
            try Task.checkCancellation()

            let currentTime = CMTimeGetSeconds(current.pts)
            let nextTime = CMTimeGetSeconds(next.pts)
            let pairDuration = max(0.0001, nextTime - currentTime)

            let relation = analyzeFrameRelation(current.pixelBuffer, next.pixelBuffer)
            let shouldSkipOpticalFlow =
                (options.enableDuplicateFrameDetection && relation.isDuplicate) ||
                (options.enableSceneChangeDetection && relation.isSceneCut)

            let flow: CVPixelBuffer?
            let reverseFlow: CVPixelBuffer?

            if shouldSkipOpticalFlow {
                flow = nil
                reverseFlow = nil
            } else {
                flow = try estimator.estimateFlow(
                    from: current.pixelBuffer,
                    to: next.pixelBuffer,
                    quality: options.quality
                )

                if options.quality.usesBidirectionalConsistency {
                    reverseFlow = try estimator.estimateFlow(
                        from: next.pixelBuffer,
                        to: current.pixelBuffer,
                        quality: options.quality
                    )
                } else {
                    reverseFlow = nil
                }
            }

            while outputSourceTime < nextTime {
                try Task.checkCancellation()

                let alpha = min(max((outputSourceTime - currentTime) / pairDuration, 0), 1)
                let buffer: CVPixelBuffer

                if alpha <= 0.0001 || relation.isDuplicate {
                    buffer = current.pixelBuffer
                } else if relation.isSceneCut {
                    buffer = alpha < 0.5 ? current.pixelBuffer : next.pixelBuffer
                } else if let flow, let reverseFlow {
                    buffer = try await renderer.renderBidirectionalOpticalFlowBlend(
                        previous: current.pixelBuffer,
                        next: next.pixelBuffer,
                        forwardFlow: flow,
                        reverseFlow: reverseFlow,
                        alpha: Float(alpha),
                        quality: options.quality,
                        pixelBufferPool: adaptor.pixelBufferPool
                    )
                } else if let flow {
                    buffer = try await renderer.renderOpticalFlowBlend(
                        previous: current.pixelBuffer,
                        next: next.pixelBuffer,
                        flow: flow,
                        alpha: Float(alpha),
                        quality: options.quality,
                        pixelBufferPool: adaptor.pixelBufferPool
                    )
                } else {
                    buffer = current.pixelBuffer
                }

                let presentation = CMTime(
                    seconds: max(0, Double(outputFrameIndex) * outputStep),
                    preferredTimescale: 600
                )

                try await append(buffer, to: adaptor, input: writerInput, time: presentation)

                outputFrameIndex += 1
                outputSourceTime += outputStep

                if outputFrameIndex % 2 == 0 {
                    let local = min(1, max(0, (outputSourceTime - firstSourceTime) / max(segment.duration, 0.001)))
                    let emittedProgress = progressSpan > 0 ? progressBase + progressSpan * local : local
                    progress(emittedProgress, "SEGMENT_PROGRESS|\(segment.index)|\(local)")
                }
            }

            current = next
        }

        let lastPresentation = CMTime(
            seconds: max(0, Double(outputFrameIndex) * outputStep),
            preferredTimescale: 600
        )
        try await append(current.pixelBuffer, to: adaptor, input: writerInput, time: lastPresentation)

        writerInput.markAsFinished()
        await writer.finishWritingAsync()

        let completedProgress = progressSpan > 0 ? progressBase + progressSpan : 1
        progress(completedProgress, "SEGMENT_DONE|\(segment.index)|0|0")

        if let error = writer.error {
            throw error
        }
    }


    private struct FrameRelation {
        let averageLumaDelta: Double
        let isDuplicate: Bool
        let isSceneCut: Bool
        let isHighMotion: Bool
    }

    private func analyzeFrameRelation(_ first: CVPixelBuffer, _ second: CVPixelBuffer) -> FrameRelation {
        let width = min(CVPixelBufferGetWidth(first), CVPixelBufferGetWidth(second))
        let height = min(CVPixelBufferGetHeight(first), CVPixelBufferGetHeight(second))
        guard width > 0, height > 0 else {
            return FrameRelation(averageLumaDelta: 0, isDuplicate: false, isSceneCut: false, isHighMotion: false)
        }

        CVPixelBufferLockBaseAddress(first, .readOnly)
        CVPixelBufferLockBaseAddress(second, .readOnly)
        defer {
            CVPixelBufferUnlockBaseAddress(first, .readOnly)
            CVPixelBufferUnlockBaseAddress(second, .readOnly)
        }

        guard let baseA = CVPixelBufferGetBaseAddress(first),
              let baseB = CVPixelBufferGetBaseAddress(second) else {
            return FrameRelation(averageLumaDelta: 0, isDuplicate: false, isSceneCut: false, isHighMotion: false)
        }

        let rowA = CVPixelBufferGetBytesPerRow(first)
        let rowB = CVPixelBufferGetBytesPerRow(second)
        let stepX = max(8, width / 64)
        let stepY = max(8, height / 64)

        var totalDelta = 0.0
        var count = 0.0

        for y in stride(from: 0, to: height, by: stepY) {
            let pointerA = baseA.advanced(by: y * rowA).assumingMemoryBound(to: UInt8.self)
            let pointerB = baseB.advanced(by: y * rowB).assumingMemoryBound(to: UInt8.self)

            for x in stride(from: 0, to: width, by: stepX) {
                let offset = x * 4

                let bA = Double(pointerA[offset])
                let gA = Double(pointerA[offset + 1])
                let rA = Double(pointerA[offset + 2])

                let bB = Double(pointerB[offset])
                let gB = Double(pointerB[offset + 1])
                let rB = Double(pointerB[offset + 2])

                let lumaA = 0.2126 * rA + 0.7152 * gA + 0.0722 * bA
                let lumaB = 0.2126 * rB + 0.7152 * gB + 0.0722 * bB
                totalDelta += abs(lumaA - lumaB)
                count += 1
            }
        }

        let average = count > 0 ? totalDelta / count : 0
        return FrameRelation(
            averageLumaDelta: average,
            isDuplicate: average < 1.25,
            isSceneCut: average > 42.0,
            isHighMotion: average > 24.0
        )
    }

    private func makeVideoSettings(width: Int, height: Int, options: ProcessingOptions) -> [String: Any] {
        let bitrate = bitrate(width: width, height: height, options: options)

        var compression: [String: Any] = [
            AVVideoAverageBitRateKey: bitrate,
            AVVideoExpectedSourceFrameRateKey: Int(options.targetFPS),
            AVVideoMaxKeyFrameIntervalKey: Int(options.targetFPS)
        ]

        if options.outputMode == .hdrPreserve && options.preserveHDRTags {
            compression[AVVideoProfileLevelKey] = kVTProfileLevel_HEVC_Main10_AutoLevel
        }

        var settings: [String: Any] = [
            AVVideoCodecKey: options.outputMode.codec,
            AVVideoWidthKey: width,
            AVVideoHeightKey: height,
            AVVideoCompressionPropertiesKey: compression
        ]

        if options.outputMode == .hdrPreserve && options.preserveHDRTags {
            settings[AVVideoColorPropertiesKey] = [
                AVVideoColorPrimariesKey: AVVideoColorPrimaries_ITU_R_2020,
                AVVideoTransferFunctionKey: AVVideoTransferFunction_SMPTE_ST_2084_PQ,
                AVVideoYCbCrMatrixKey: AVVideoYCbCrMatrix_ITU_R_2020
            ]
        } else {
            settings[AVVideoColorPropertiesKey] = [
                AVVideoColorPrimariesKey: AVVideoColorPrimaries_ITU_R_709_2,
                AVVideoTransferFunctionKey: AVVideoTransferFunction_ITU_R_709_2,
                AVVideoYCbCrMatrixKey: AVVideoYCbCrMatrix_ITU_R_709_2
            ]
        }

        return settings
    }

    private func bitrate(width: Int, height: Int, options: ProcessingOptions) -> Int {
        if options.bitrateMode == .customMbps {
            return max(1, Int(options.customBitrateMbps * 1_000_000))
        }

        let pixelsPerSecond = Double(width * height) * options.targetFPS
        let bppf: Double

        switch options.outputMode {
        case .h264Compatible:
            bppf = 0.13
        case .appleHEVC:
            bppf = 0.15
        case .hdrPreserve:
            bppf = 0.17
        }

        let raw = pixelsPerSecond * bppf * options.quality.bitrateMultiplier
        let floor: Double = options.outputMode == .hdrPreserve ? 70_000_000 : 45_000_000
        let cap: Double = options.outputMode == .hdrPreserve ? 380_000_000 : 300_000_000

        return Int(min(max(raw, floor), cap))
    }

    private func copyNextFrame(from output: AVAssetReaderTrackOutput) -> VideoFrame? {
        guard let sampleBuffer = output.copyNextSampleBuffer(),
              let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else {
            return nil
        }

        return VideoFrame(
            pixelBuffer: pixelBuffer,
            pts: CMSampleBufferGetPresentationTimeStamp(sampleBuffer)
        )
    }

    private func append(
        _ pixelBuffer: CVPixelBuffer,
        to adaptor: AVAssetWriterInputPixelBufferAdaptor,
        input: AVAssetWriterInput,
        time: CMTime
    ) async throws {
        while !input.isReadyForMoreMediaData {
            try Task.checkCancellation()
            try await Task.sleep(nanoseconds: 1_000_000)
        }

        guard adaptor.append(pixelBuffer, withPresentationTime: time) else {
            throw NSError(domain: "BuzhenLocal", code: 4006, userInfo: [NSLocalizedDescriptionKey: "写入帧失败"])
        }
    }

    private func joinSegments(
        segmentOutputs: [URL],
        outputURL: URL,
        outputMode: OutputMode
    ) async throws {
        if FileManager.default.fileExists(atPath: outputURL.path) {
            try FileManager.default.removeItem(at: outputURL)
        }

        let composition = AVMutableComposition()
        guard let compVideo = composition.addMutableTrack(
            withMediaType: .video,
            preferredTrackID: kCMPersistentTrackID_Invalid
        ) else {
            throw NSError(domain: "BuzhenLocal", code: 5001, userInfo: [NSLocalizedDescriptionKey: "无法创建合并轨道"])
        }

        var cursor = CMTime.zero

        for url in segmentOutputs {
            let asset = AVURLAsset(url: url)
            guard let videoTrack = try await asset.loadTracks(withMediaType: .video).first else { continue }
            let duration = try await asset.load(.duration)

            try compVideo.insertTimeRange(
                CMTimeRange(start: .zero, duration: duration),
                of: videoTrack,
                at: cursor
            )

            cursor = cursor + duration
        }

        guard let exporter = AVAssetExportSession(asset: composition, presetName: AVAssetExportPresetPassthrough) else {
            throw NSError(domain: "BuzhenLocal", code: 5002, userInfo: [NSLocalizedDescriptionKey: "无法创建分段合并器"])
        }

        exporter.outputURL = outputURL
        exporter.outputFileType = outputMode.fileType
        exporter.shouldOptimizeForNetworkUse = true

        await exporter.exportAsync()

        if exporter.status != .completed {
            throw exporter.error ?? NSError(domain: "BuzhenLocal", code: 5003, userInfo: [NSLocalizedDescriptionKey: "合并分段失败"])
        }
    }

    private func muxAudioAndMetadata(
        originalURL: URL,
        processedVideoURL: URL,
        outputURL: URL,
        options: ProcessingOptions
    ) async throws -> URL {
        if !options.keepAudio && !options.keepMetadata {
            if FileManager.default.fileExists(atPath: outputURL.path) {
                try FileManager.default.removeItem(at: outputURL)
            }
            try FileManager.default.copyItem(at: processedVideoURL, to: outputURL)
            return outputURL
        }

        if FileManager.default.fileExists(atPath: outputURL.path) {
            try FileManager.default.removeItem(at: outputURL)
        }

        let originalAsset = AVURLAsset(url: originalURL)
        let processedAsset = AVURLAsset(url: processedVideoURL)

        let composition = AVMutableComposition()

        guard let processedVideoTrack = try await processedAsset.loadTracks(withMediaType: .video).first,
              let compVideo = composition.addMutableTrack(withMediaType: .video, preferredTrackID: kCMPersistentTrackID_Invalid) else {
            try FileManager.default.copyItem(at: processedVideoURL, to: outputURL)
            return outputURL
        }

        let processedDuration = try await processedAsset.load(.duration)

        try compVideo.insertTimeRange(
            CMTimeRange(start: .zero, duration: processedDuration),
            of: processedVideoTrack,
            at: .zero
        )

        if options.keepAudio,
           let sourceAudioTrack = try await originalAsset.loadTracks(withMediaType: .audio).first,
           let compAudio = composition.addMutableTrack(withMediaType: .audio, preferredTrackID: kCMPersistentTrackID_Invalid) {
            let originalDuration = try await originalAsset.load(.duration)
            let audioDuration = CMTimeMinimum(processedDuration, originalDuration)

            try? compAudio.insertTimeRange(
                CMTimeRange(start: .zero, duration: audioDuration),
                of: sourceAudioTrack,
                at: .zero
            )
        }

        let originalMetadata: [AVMetadataItem]
        if options.keepMetadata {
            originalMetadata = (try? await originalAsset.load(.metadata)) ?? []
        } else {
            originalMetadata = []
        }

        guard let exporter = AVAssetExportSession(asset: composition, presetName: AVAssetExportPresetPassthrough) else {
            try FileManager.default.copyItem(at: processedVideoURL, to: outputURL)
            return outputURL
        }

        if options.keepMetadata && !originalMetadata.isEmpty {
            exporter.metadata = originalMetadata
        }

        exporter.outputURL = outputURL
        exporter.outputFileType = options.outputMode.fileType
        exporter.shouldOptimizeForNetworkUse = true

        await exporter.exportAsync()

        if exporter.status == .completed {
            return outputURL
        }

        try? FileManager.default.removeItem(at: outputURL)
        try FileManager.default.copyItem(at: processedVideoURL, to: outputURL)
        return outputURL
    }

    private func makeOutputURL(prefix: String, mode: OutputMode) throws -> URL {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        let url = docs
            .appendingPathComponent("\(prefix)_\(Int(Date().timeIntervalSince1970))")
            .appendingPathExtension(mode.fileExtension)

        if FileManager.default.fileExists(atPath: url.path) {
            try FileManager.default.removeItem(at: url)
        }
        return url
    }

    private func makeTempURL(prefix: String, ext: String) throws -> URL {
        let url = FileManager.default.temporaryDirectory
            .appendingPathComponent("\(prefix)_\(UUID().uuidString)")
            .appendingPathExtension(ext)

        if FileManager.default.fileExists(atPath: url.path) {
            try FileManager.default.removeItem(at: url)
        }
        return url
    }
}

private actor SegmentProgressTracker {
    struct Summary: Sendable {
        let average: Double
        let done: Int
        let active: Int
    }

    private var values: [Double]
    private var doneFlags: [Bool]
    private var activeFlags: [Bool]

    init(count: Int) {
        self.values = Array(repeating: 0, count: max(0, count))
        self.doneFlags = Array(repeating: false, count: max(0, count))
        self.activeFlags = Array(repeating: false, count: max(0, count))
    }

    func start(index: Int) -> Summary {
        guard values.indices.contains(index) else { return summary() }
        activeFlags[index] = true
        values[index] = max(values[index], 0.01)
        return summary()
    }

    func update(index: Int, local: Double) -> Summary {
        guard values.indices.contains(index) else { return summary() }
        activeFlags[index] = true
        values[index] = max(values[index], min(max(local, 0), 1))
        return summary()
    }

    func complete(index: Int) -> Summary {
        guard values.indices.contains(index) else { return summary() }
        values[index] = 1
        doneFlags[index] = true
        activeFlags[index] = false
        return summary()
    }

    private func summary() -> Summary {
        guard !values.isEmpty else {
            return Summary(average: 0, done: 0, active: 0)
        }

        let average = values.reduce(0, +) / Double(values.count)
        let done = doneFlags.filter { $0 }.count
        let active = activeFlags.filter { $0 }.count
        return Summary(average: average, done: done, active: active)
    }
}

