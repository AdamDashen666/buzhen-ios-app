import Foundation
import AVFoundation
import CoreMedia

struct VideoInfo: Sendable {
    let width: Int
    let height: Int
    let fps: Double
    let duration: Double
    let codec: String
    let isHDRLike: Bool
    let hdrName: String
    let hasAudio: Bool
    let estimatedBitrate: Int

    var megapixels: Double {
        Double(width * height) / 1_000_000.0
    }

    var durationText: String {
        let total = Int(duration.rounded())
        let h = total / 3600
        let m = (total % 3600) / 60
        let s = total % 60
        if h > 0 { return String(format: "%02d:%02d:%02d", h, m, s) }
        return String(format: "%02d:%02d", m, s)
    }

    var bitrateText: String {
        if estimatedBitrate <= 0 { return "未知" }
        return String(format: "%.1f Mbps", Double(estimatedBitrate) / 1_000_000.0)
    }
}

enum VideoInspector {
    static func inspect(url: URL) async throws -> VideoInfo {
        let asset = AVURLAsset(url: url)
        let videoTracks = try await asset.loadTracks(withMediaType: .video)
        guard let track = videoTracks.first else {
            throw NSError(domain: "BuzhenLocal", code: 1001, userInfo: [NSLocalizedDescriptionKey: "没有找到视频轨道"])
        }

        let audioTracks = try await asset.loadTracks(withMediaType: .audio)
        let naturalSize = try await track.load(.naturalSize)
        let nominalFrameRate = try await track.load(.nominalFrameRate)
        let duration = try await asset.load(.duration)
        let formatDescriptions = try await track.load(.formatDescriptions)

        let fps = Double(nominalFrameRate > 0 ? nominalFrameRate : 30)
        let width = Int(abs(naturalSize.width))
        let height = Int(abs(naturalSize.height))
        let seconds = max(CMTimeGetSeconds(duration), 0)

        var codec = "unknown"
        var hdrLike = false
        var hdrName = "SDR"

        if let fmt = formatDescriptions.first {
            let subType = CMFormatDescriptionGetMediaSubType(fmt)
            codec = fourCCString(subType)

            let extensions = CMFormatDescriptionGetExtensions(fmt) as NSDictionary?
            let primaries = extensions?[kCMFormatDescriptionExtension_ColorPrimaries] as? String
            let transfer = extensions?[kCMFormatDescriptionExtension_TransferFunction] as? String
            let ycbcr = extensions?[kCMFormatDescriptionExtension_YCbCrMatrix] as? String

            let joined = [primaries, transfer, ycbcr].compactMap { $0 }.joined(separator: " ")

            if joined.contains("ITU_R_2020") || joined.contains("SMPTE_ST_2084") || joined.contains("ARIB_STD_B67") {
                hdrLike = true
            }

            if joined.contains("SMPTE_ST_2084") {
                hdrName = "HDR10 / PQ"
            } else if joined.contains("ARIB_STD_B67") {
                hdrName = "HLG"
            } else if joined.contains("ITU_R_2020") {
                hdrName = "疑似 HDR / BT.2020"
            }
        }

        let estimatedBitrate = Int(Double(width * height) * fps * 0.12)

        return VideoInfo(
            width: width,
            height: height,
            fps: fps,
            duration: seconds,
            codec: codec,
            isHDRLike: hdrLike,
            hdrName: hdrName,
            hasAudio: !audioTracks.isEmpty,
            estimatedBitrate: estimatedBitrate
        )
    }

    private static func fourCCString(_ code: FourCharCode) -> String {
        let chars: [CChar] = [
            CChar((code >> 24) & 255),
            CChar((code >> 16) & 255),
            CChar((code >> 8) & 255),
            CChar(code & 255),
            0
        ]
        return String(cString: chars)
    }
}
