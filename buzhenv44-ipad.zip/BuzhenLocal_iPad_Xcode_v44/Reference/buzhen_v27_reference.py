#!/usr/bin/env python3
# buzhen.py
# iPad a-Shell 光流补帧工具 v27 纯净重写版
#
# 保留：
# 1. 视频检测信息
# 2. 输入目标帧率
# 3. 输出模式 1/2/3
# 4. 光流质量 1/2/3/4
# 5. 处理模式：单次完整处理 / 串行分段处理
# 6. 码率选择
# 7. 输出文件名
# 8. 信息确认后开始
#
# 删除：
# # - 自动校准
# - 自动并行
# - 线程选择
# - 自动改光流质量
# - 复杂内存判断

import os
import re
import sys
import json
import time
import math
import shlex
import shutil
import subprocess
import threading
from pathlib import Path
from fractions import Fraction

VIDEO_EXTS = {".mp4", ".mov", ".m4v", ".mkv", ".webm", ".avi"}
OUT_EXTS = {".mp4", ".mov", ".m4v", ".mkv"}

STAT_RE = re.compile(
    r"frame=\s*(?P<frame>\d+).*?"
    r"fps=\s*(?P<fps>[0-9.]+).*?"
    r"time=\s*(?P<time>[0-9:.]+).*?"
    r"speed=\s*(?P<speed>[0-9.]+x)"
)


def ask(prompt, default=None):
    suffix = f" [{default}]" if default not in (None, "") else ""
    s = input(f"{prompt}{suffix}: ").strip()
    return s if s else default


def safe_float(prompt, default=None, min_value=None):
    while True:
        try:
            v = float(ask(prompt, default))
            if min_value is not None and v < min_value:
                print(f"❌ 不能小于 {min_value}")
                continue
            return v
        except Exception:
            print("❌ 请输入数字。")


def need(name):
    if not shutil.which(name):
        print(f"❌ 找不到 {name}。请确认 a-Shell 可以运行：{name} -version")
        sys.exit(1)


def run(cmd):
    return subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)


def parse_fps(value):
    try:
        if value and "/" in value:
            return float(Fraction(value))
        return float(value or 0)
    except Exception:
        return 0.0


def int0(x):
    try:
        return int(x)
    except Exception:
        return 0


def fmt_bitrate(bps):
    try:
        bps = int(bps)
    except Exception:
        bps = 0

    if bps <= 0:
        return "未知"
    if bps >= 1_000_000:
        return f"{bps / 1_000_000:.2f} Mbps"
    return f"{bps / 1000:.0f} kbps"


def fmt_time(seconds):
    if seconds is None or seconds < 0:
        return "--:--"
    seconds = int(seconds)
    h = seconds // 3600
    m = (seconds % 3600) // 60
    s = seconds % 60
    if h:
        return f"{h:02d}:{m:02d}:{s:02d}"
    return f"{m:02d}:{s:02d}"


def pick_input_file():
    print("\n📁 输入视频路径")
    print("提示：可以先在 a-Shell 输入 pickFolder，然后把视频和脚本放同一个目录。")
    raw = ask("请输入视频文件名/路径；直接回车自动选择当前目录第一个视频", "")

    if raw:
        path = Path(raw).expanduser()
        if not path.exists():
            print("❌ 文件不存在。")
            sys.exit(1)
        return path

    videos = sorted([p for p in Path(".").iterdir() if p.suffix.lower() in VIDEO_EXTS])
    if not videos:
        print("❌ 当前目录没有找到视频文件。")
        sys.exit(1)

    print("\n找到这些视频：")
    for i, p in enumerate(videos, 1):
        print(f"{i}. {p.name}")

    idx = int(ask("选择编号", "1"))
    return videos[idx - 1]


def ffprobe_info(path):
    p = run([
        "ffprobe", "-v", "error",
        "-print_format", "json",
        "-show_format", "-show_streams",
        str(path)
    ])
    if p.returncode != 0:
        print(p.stderr)
        sys.exit(1)
    return json.loads(p.stdout)


def first_stream(info, kind):
    for s in info.get("streams", []):
        if s.get("codec_type") == kind:
            return s
    return {}


def detect_hdr(vs):
    pix = vs.get("pix_fmt", "")
    prim = vs.get("color_primaries", "")
    trc = vs.get("color_transfer", "")
    space = vs.get("color_space", "")

    hdr = (
        "10" in pix
        or "p010" in pix
        or prim == "bt2020"
        or trc in {"smpte2084", "arib-std-b67"}
        or space in {"bt2020nc", "bt2020c"}
    )

    if trc == "smpte2084":
        return hdr, "HDR10 / PQ"
    if trc == "arib-std-b67":
        return hdr, "HLG"
    if hdr:
        return hdr, "疑似 HDR / 10-bit"
    return hdr, "SDR"


def color_args(vs, keep_hdr):
    if not keep_hdr:
        return [
            "-color_primaries", "bt709",
            "-color_trc", "bt709",
            "-colorspace", "bt709",
            "-color_range", "tv",
        ]

    result = []
    mapping = {
        "color_primaries": "-color_primaries",
        "color_transfer": "-color_trc",
        "color_space": "-colorspace",
        "color_range": "-color_range",
    }

    for key, opt in mapping.items():
        value = vs.get(key)
        if value and value != "unknown":
            result += [opt, value]

    return result


def available_encoders():
    p = run(["ffmpeg", "-hide_banner", "-encoders"])
    return (p.stdout or "") + (p.stderr or "")


def choose_encoder(mode):
    encoders = available_encoders()

    if mode == "2":
        if "h264_videotoolbox" in encoders:
            return "h264_videotoolbox", "yuv420p", [], [], False
        if "libx264" in encoders:
            return "libx264", "yuv420p", ["-preset", "veryfast"], [], False

    if "hevc_videotoolbox" in encoders:
        if mode == "3":
            return "hevc_videotoolbox", "p010le", ["-profile:v", "main10"], ["-tag:v", "hvc1"], True
        return "hevc_videotoolbox", "yuv420p", [], ["-tag:v", "hvc1"], True

    if "libx265" in encoders:
        if mode == "3":
            return "libx265", "yuv420p10le", ["-preset", "veryfast", "-x265-params", "hdr-opt=1"], ["-tag:v", "hvc1"], True
        return "libx265", "yuv420p", ["-preset", "veryfast"], ["-tag:v", "hvc1"], True

    if "h264_videotoolbox" in encoders:
        return "h264_videotoolbox", "yuv420p", [], [], False
    if "libx264" in encoders:
        return "libx264", "yuv420p", ["-preset", "veryfast"], [], False

    print("❌ 找不到可用视频编码器。")
    sys.exit(1)


def suggest_bitrate(width, height, target_fps, mode, keep_hdr):
    try:
        pixels_per_second = float(width) * float(height) * float(target_fps)
    except Exception:
        pixels_per_second = 1920 * 1080 * float(target_fps)

    if mode == "2":
        bppf = 0.13
        cap = 220_000_000
        floor = 45_000_000
    elif keep_hdr:
        bppf = 0.17
        cap = 380_000_000
        floor = 70_000_000
    else:
        bppf = 0.15
        cap = 300_000_000
        floor = 55_000_000

    return int(max(floor, min(pixels_per_second * bppf, cap)))


def ensure_suffix(path, default_ext):
    p = Path(path).expanduser()
    if p.suffix.lower() not in OUT_EXTS:
        p = p.with_suffix(default_ext)
    return p


class ProgressState:
    def __init__(self):
        self.frame = 0
        self.fps = ""
        self.time = ""
        self.speed = ""
        self.tail = []
        self.lock = threading.Lock()

    def feed(self, text):
        m = STAT_RE.search(text)
        with self.lock:
            if m:
                self.frame = int(m.group("frame"))
                self.fps = m.group("fps")
                self.time = m.group("time")
                self.speed = m.group("speed")
            elif text.strip():
                self.tail.append(text.strip())
                self.tail = self.tail[-80:]

    def snap(self):
        with self.lock:
            return self.frame, self.fps, self.time, self.speed, list(self.tail)


def read_stderr(pipe, state):
    buf = ""
    while True:
        ch = pipe.read(1)
        if not ch:
            if buf:
                state.feed(buf)
            break

        if ch in "\r\n":
            if buf:
                state.feed(buf)
                buf = ""
        else:
            buf += ch
            if len(buf) > 3000:
                state.feed(buf)
                buf = ""


def progress_line(frame, total, elapsed, prefix="", speed=""):
    total = max(1, int(total))
    frame = max(0, min(int(frame), total))
    pct = frame / total

    bar_len = 22
    filled = int(bar_len * pct)
    bar = "█" * filled + "░" * (bar_len - filled)

    if frame and elapsed > 0:
        proc_fps = frame / elapsed
        sec_per_frame = elapsed / frame
        eta = (total - frame) / proc_fps if proc_fps > 0 else None
        per_frame = f"{sec_per_frame:.2f}s/帧" if sec_per_frame >= 1 else f"{sec_per_frame * 1000:.0f}ms/帧"
        perf = f"{per_frame} 处理 {proc_fps:.3f}帧/s"
    else:
        eta = None
        perf = "--/帧 处理 --帧/s"

    line = (
        f"\r{prefix}[{bar}] {pct * 100:6.2f}%  "
        f"帧 {frame}/{total}  {perf}  "
        f"已用 {fmt_time(elapsed)}  剩余 {fmt_time(eta)}  speed={speed or '--'}"
    )

    sys.stdout.write(line)
    sys.stdout.flush()


def run_ffmpeg_progress(cmd, total_frames, prefix=""):
    state = ProgressState()
    start = time.time()

    p = subprocess.Popen(
        cmd,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.PIPE,
        text=True,
        bufsize=0
    )

    threading.Thread(target=read_stderr, args=(p.stderr, state), daemon=True).start()

    try:
        while True:
            frame, fps, ff_time, speed, tail = state.snap()
            elapsed = time.time() - start
            progress_line(frame, total_frames, elapsed, prefix=prefix, speed=speed)

            if p.poll() is not None:
                break

            time.sleep(1)

    except KeyboardInterrupt:
        p.terminate()
        print("\n已中断。")
        sys.exit(130)

    p.wait()
    frame, fps, ff_time, speed, tail = state.snap()

    if p.returncode == 0:
        progress_line(total_frames, total_frames, time.time() - start, prefix=prefix, speed=speed)
        print()
        return True, tail

    print()
    if tail:
        print("\nFFmpeg 信息 / 错误尾部：")
        print("\n".join(tail[-40:]))

    return False, tail


def base_cmd():
    # 默认最简单：不暴露线程选择，不加复杂线程限制。
    return ["ffmpeg", "-y", "-hide_banner", "-nostdin", "-stats", "-stats_period", "1"]


def encode_args(encoder, extra, bitrate, pix_fmt, tag, colors):
    return [
        "-c:v", encoder,
        *extra,
        "-b:v", str(bitrate),
        "-maxrate", str(int(bitrate * 1.5)),
        "-bufsize", str(int(bitrate * 2)),
        "-pix_fmt", pix_fmt,
        *tag,
        *colors,
    ]


def make_single_cmd(inp, out, vf, encoder, extra, bitrate, pix_fmt, tag, colors):
    return [
        *base_cmd(),
        "-i", str(inp),
        "-map", "0:v:0",
        "-map", "0:a?",
        "-map_metadata", "0",
        "-map_chapters", "0",
        "-vf", vf,
        *encode_args(encoder, extra, bitrate, pix_fmt, tag, colors),
        "-c:a", "copy",
        "-max_muxing_queue_size", "2048",
        "-movflags", "+faststart",
        str(out),
    ]


def make_segment_cmd(inp, start, length, out, vf, encoder, extra, bitrate, pix_fmt, tag, colors):
    return [
        *base_cmd(),
        "-ss", f"{start:.3f}",
        "-t", f"{length:.3f}",
        "-i", str(inp),
        "-map", "0:v:0",
        "-an",
        "-vf", vf,
        *encode_args(encoder, extra, bitrate, pix_fmt, tag, colors),
        "-max_muxing_queue_size", "2048",
        "-movflags", "+faststart",
        str(out),
    ]


def concat_and_mux(inp, out, temp_dir, seg_files, ext):
    list_file = temp_dir / "concat.txt"
    list_file.write_text(
        "".join([f"file '{s.resolve().as_posix()}'\n" for s in seg_files]),
        encoding="utf-8"
    )

    joined = temp_dir / f"joined{ext}"

    print("\n🔗 正在合并视频段...")
    p = run([
        "ffmpeg", "-y", "-hide_banner", "-nostdin",
        "-f", "concat", "-safe", "0",
        "-i", str(list_file),
        "-c", "copy",
        "-movflags", "+faststart",
        str(joined)
    ])
    if p.returncode != 0:
        print(p.stderr)
        return False

    print("🎵 正在合并原音频...")
    p = run([
        "ffmpeg", "-y", "-hide_banner", "-nostdin",
        "-i", str(joined),
        "-i", str(inp),
        "-map", "0:v:0",
        "-map", "1:a?",
        "-map_metadata", "1",
        "-map_chapters", "1",
        "-c:v", "copy",
        "-c:a", "copy",
        "-shortest",
        "-movflags", "+faststart",
        str(out)
    ])
    if p.returncode != 0:
        print(p.stderr)
        return False

    return True


def serial_segmented(inp, out, duration, target_fps, segment_seconds, vf, encoder, extra, bitrate, pix_fmt, tag, colors):
    ext = ".mov" if out.suffix.lower() == ".mov" else ".mp4"
    temp_dir = out.parent / f".buzhen_temp_{int(time.time())}"
    temp_dir.mkdir(parents=True, exist_ok=True)

    try:
        count = max(1, math.ceil(duration / segment_seconds))
        seg_files = []

        print(f"\n🧩 串行分段：共 {count} 段，每段约 {segment_seconds:g} 秒")

        for i in range(count):
            start = i * segment_seconds
            length = min(segment_seconds, max(0.05, duration - start))
            seg_out = temp_dir / f"seg_{i:04d}{ext}"
            seg_files.append(seg_out)

            frames = max(1, round(length * target_fps))
            cmd = make_segment_cmd(inp, start, length, seg_out, vf, encoder, extra, bitrate, pix_fmt, tag, colors)

            print(f"\n第 {i + 1}/{count} 段：{start:.2f}s → {start + length:.2f}s")
            ok, _ = run_ffmpeg_progress(cmd, frames, prefix=f"段{i + 1}/{count} ")

            if not ok:
                return False

        return concat_and_mux(inp, out, temp_dir, seg_files, ext)

    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)


def countdown():
    print("\n⌨️ 开始后不会再输入，可以收起键盘。")
    for i in range(3, 0, -1):
        print(f"🚀 {i} 秒后开始...", end="\r", flush=True)
        time.sleep(1)
    print("🚀 开始补帧。不要锁屏，不要切后台。       ")


def main():
    need("ffmpeg")
    need("ffprobe")

    print("\n=== iPad a-Shell 光流补帧工具 v27 纯净重写版 ===")

    inp = pick_input_file()
    info = ffprobe_info(inp)
    vs = first_stream(info, "video")
    aud = first_stream(info, "audio")

    if not vs:
        print("❌ 没检测到视频流。")
        sys.exit(1)

    width = vs.get("width", "?")
    height = vs.get("height", "?")
    codec = vs.get("codec_name", "unknown")
    pix_fmt = vs.get("pix_fmt", "unknown")
    src_fps = parse_fps(vs.get("avg_frame_rate")) or parse_fps(vs.get("r_frame_rate"))
    duration = float(info.get("format", {}).get("duration") or 0)
    video_bitrate = int0(vs.get("bit_rate"))
    container_bitrate = int0(info.get("format", {}).get("bit_rate"))
    hdr_like, hdr_name = detect_hdr(vs)

    try:
        megapixels = (float(width) * float(height)) / 1_000_000
    except Exception:
        megapixels = 2.0

    print("\n📌 检测到的视频信息")
    print(f"文件：{inp}")
    print(f"分辨率：{width} × {height}")
    print(f"视频编码：{codec}")
    print(f"像素格式：{pix_fmt}")
    print(f"当前帧率：{src_fps:.3f} fps")
    print(f"时长：{duration:.2f} 秒")
    print(f"视频码率：{fmt_bitrate(video_bitrate)}")
    print(f"容器总码率：{fmt_bitrate(container_bitrate)}")
    print(f"HDR 状态：{hdr_name}")
    print(f"音频：{'有，默认复制' if aud else '无'}")

    if not src_fps:
        print("❌ 无法读取原帧率。")
        sys.exit(1)

    target_fps = safe_float("\n🎯 请输入目标帧率，例如 60 / 120 / 240", "60", 1)

    load = megapixels * target_fps
    if load >= 500 or target_fps >= 180:
        print("\n⚠️ 高负载：这个设置容易爆内存或非常慢")
        print(f"负载约：{megapixels:.2f}MP × {target_fps:g}fps = {load:.0f}")

    print("\n🎛 输出模式")
    print("1. Apple HEVC 兼容模式：推荐，清晰，文件较小，强制 hvc1")
    print("2. H.264 最稳兼容模式：如果只能听声音看不到画面，选这个，但不保 HDR")
    print("3. HDR 保留模式：HEVC Main10 + hvc1 + HDR 色彩标签")
    out_mode = ask("选择输出模式", "3" if hdr_like else "1")

    if out_mode not in {"1", "2", "3"}:
        print("❌ 输出模式无效。")
        sys.exit(1)

    print("\n⚙️ 光流质量")
    print("1. 快速")
    print("2. 平衡")
    print("3. 高质量")
    print("4. 极限光流：更慢，尽量减少果冻/边缘模糊")
    q = ask("选择光流质量", "1")

    flow_map = {
        "1": ("快速", "mi_mode=mci:mc_mode=obmc:me_mode=bidir:vsbmc=0"),
        "2": ("平衡", "mi_mode=mci:mc_mode=aobmc:me_mode=bidir:vsbmc=0"),
        "3": ("高质量", "mi_mode=mci:mc_mode=aobmc:me_mode=bidir:vsbmc=1"),
        "4": ("极限光流", "mi_mode=mci:mc_mode=aobmc:me_mode=bidir:me=umh:mb_size=8:search_param=48:vsbmc=1:scd=fdiff:scd_threshold=8"),
    }

    if q not in flow_map:
        print("❌ 光流质量无效。")
        sys.exit(1)

    flow_name, flow_opts = flow_map[q]

    print("\n🚀 处理模式")
    print("1. 单次完整处理")
    print("2. 串行分段处理")
    proc_mode = ask("选择处理模式", "2")

    if proc_mode not in {"1", "2"}:
        print("❌ 处理模式无效。")
        sys.exit(1)

    segment_seconds = 0
    if proc_mode == "2":
        segment_seconds = safe_float("每段秒数，推荐 3", "3", 1)

    encoder, out_pix_fmt, extra_encoder_args, tag_args, keep_hdr = choose_encoder(out_mode)
    colors = color_args(vs, keep_hdr)

    recommended_bitrate = suggest_bitrate(width, height, target_fps, out_mode, keep_hdr)

    print("\n🎚 码率")
    print(f"推荐码率：{recommended_bitrate / 1_000_000:.1f} Mbps")
    mbps = ask("输出视频码率 Mbps；直接回车使用推荐", f"{recommended_bitrate / 1_000_000:.1f}")
    out_bitrate = int(float(mbps) * 1_000_000)

    default_ext = ".MOV" if inp.suffix.lower() == ".mov" else ".mp4"
    default_out = inp.with_name(f"{inp.stem}_OF_{target_fps:g}fps_v27{default_ext}")
    out = ensure_suffix(ask("输出文件名；不写后缀会自动补", str(default_out)), default_ext)

    vf = f"minterpolate=fps={target_fps:g}:{flow_opts},format={out_pix_fmt}"
    total_frames = max(1, round(duration * target_fps))

    print("\n🧾 信息确认")
    print(f"输入：{inp}")
    print(f"输出：{out}")
    print(f"当前帧率：{src_fps:.3f} fps")
    print(f"目标帧率：{target_fps:g} fps")
    print(f"预计总帧：{total_frames}")
    print(f"输出码率：{fmt_bitrate(out_bitrate)}")
    print(f"输出模式：{out_mode}")
    print(f"光流质量：{flow_name}")
    print(f"处理模式：{proc_mode}")
    if proc_mode == "2":
        print(f"分段秒数：{segment_seconds:g}")
    print(f"编码器：{encoder}")
    print(f"像素格式：{out_pix_fmt}")
    print(f"HDR/色彩：{'尝试保留' if keep_hdr else '转 SDR / BT.709'}")
    print(f"滤镜：{vf}")

    confirm = str(ask("\n输入 y 开始补帧", "n")).lower()
    if confirm != "y":
        print("已取消。")
        return

    countdown()

    if proc_mode == "1":
        cmd = make_single_cmd(inp, out, vf, encoder, extra_encoder_args, out_bitrate, out_pix_fmt, tag_args, colors)
        print("\n实际命令：")
        print(" ".join(shlex.quote(x) for x in cmd))
        ok, _ = run_ffmpeg_progress(cmd, total_frames)
    else:
        ok = serial_segmented(inp, out, duration, target_fps, segment_seconds, vf, encoder, extra_encoder_args, out_bitrate, out_pix_fmt, tag_args, colors)

    if ok:
        print(f"\n✅ 完成：{out}")
    else:
        print("\n❌ FFmpeg 执行失败。")
        print("建议：先试 输出模式3 + 光流质量1 + 串行分段 + 每段3秒；如果想减少果冻/边缘模糊，可试光流质量4；如果还失败，再试输出模式2。")
        sys.exit(1)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n已中断。")
        sys.exit(130)
    except Exception as e:
        print(f"\n❌ 错误：{e}")
        sys.exit(1)
