# LiquidAIBrowser v1.2

一个独立的 iOS AI 浏览器原型：多标签页、每个标签独立 Agent 任务、任务管理页、网页缩略图、Liquid Glass 风格 UI。

## 核心功能

- 独立 `WKWebView` 浏览器。
- 多标签页，前台 App 内非当前标签页任务可继续执行。
- 每个标签右下角 Agent 按钮。
- AI 自动拆解任务清单。
- 逐步执行：click / input / scroll / navigate / back / wait / select / submit。
- 完成清单打绿色勾，显示进度条。
- 全局任务管理页显示缩略图、当前状态、日志、最终报告。
- 设置页支持 API Key、Base URL、模型、刷新模型、测试连接、Temperature、最大循环、超时。
- API Key 存 Keychain。
- 新系统使用 Liquid Glass 风格，旧系统 fallback 半透明毛玻璃。

## v1.2 重点

- 修复暂停、停止、关闭标签时任务 worker 生命周期问题。
- 增强敏感操作确认和风险展示。
- 加入 prompt injection 防护。
- 加入页面内容脱敏。
- 修复 Base URL endpoint、Keychain 清除、设置刷新等问题。

## 使用方式

1. 解压 zip。
2. 用 Xcode 打开 `LiquidAIBrowser.xcodeproj`。
3. 选择 `LiquidAIBrowser` target。
4. 设置自己的 Team / Bundle ID。
5. 真机运行。
6. 进入 App 设置页填写 API Key、Base URL、模型。

## 重要限制

- App 前台时，非当前标签页任务可继续执行；App 退到后台或锁屏后，iOS 可能挂起普通网页自动化任务。
- 有些网站会检查 `event.isTrusted`，JS 合成点击可能失败，需要人工接管。
- Agent 会把当前页面文本和可交互元素发送给你设置的模型服务；已加入脱敏，但仍建议只在可信网页使用。
- 支付、下单、发送、删除、订阅、转账、签署等敏感操作需要用户确认。


## v1.3 新增说明

本版是独立 AI 浏览器 App，核心新增：任务队列、坐标点击/双击/滑动/拖动 fallback、视觉截图辅助、PDF 报告导出、详细日志过滤，以及蓝白 Liquid Glass UI。

### 视觉截图辅助

进入设置页打开“每一步发送当前可视区域截图给 AI”。开启后，Agent 每轮都会把当前 WKWebView 可视区域截图发送给模型。请确保模型支持图片输入，否则可能请求失败或被中转 API 拒绝。

### 坐标动作

DOM 扫描会提供元素中心坐标，AI 可返回：

```json
{"type":"coordinateClick","x":120,"y":340,"reason":"DOM 找不到按钮，改用坐标点击"}
```

也支持：`doubleClick`、`swipe`、`drag`。这些动作基于网页 JS 合成事件，不是系统级真实触摸，遇到网站检测 `isTrusted` 时可能失败。

### 报告与日志

任务卡右下角的文档按钮可以导出 PDF 报告；复制按钮会复制完整详细日志。
