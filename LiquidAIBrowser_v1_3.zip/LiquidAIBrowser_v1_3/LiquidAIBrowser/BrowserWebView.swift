import SwiftUI
import WebKit

struct BrowserWebView: UIViewRepresentable {
    @EnvironmentObject var store: BrowserStore
    let tabID: UUID

    func makeUIView(context: Context) -> WKWebView {
        let url = store.tabs.first(where: { $0.id == tabID })?.urlString ?? "https://www.google.com"
        return store.webPool.webView(for: tabID, initialURL: url)
    }

    func updateUIView(_ uiView: WKWebView, context: Context) { }
}
