import SwiftUI

extension View {
    @ViewBuilder
    func liquidGlassCard(cornerRadius: CGFloat = 24) -> some View {
        let shape = RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
        #if compiler(>=6.2)
        if #available(iOS 26.0, *) {
            self
                .glassEffect(.regular, in: shape)
                .overlay(shape.stroke(LinearGradient(colors: [.white.opacity(0.42), .cyan.opacity(0.24), .blue.opacity(0.14)], startPoint: .topLeading, endPoint: .bottomTrailing), lineWidth: 1))
                .shadow(color: .cyan.opacity(0.12), radius: 18, x: 0, y: 10)
        } else {
            self.liquidFallbackBackground(shape: shape)
        }
        #else
        self.liquidFallbackBackground(shape: shape)
        #endif
    }

    @ViewBuilder
    func liquidGlassCapsule() -> some View {
        #if compiler(>=6.2)
        if #available(iOS 26.0, *) {
            self
                .glassEffect(.regular, in: Capsule())
                .overlay(Capsule().stroke(LinearGradient(colors: [.white.opacity(0.55), .cyan.opacity(0.28), .blue.opacity(0.18)], startPoint: .topLeading, endPoint: .bottomTrailing), lineWidth: 1))
                .shadow(color: .cyan.opacity(0.14), radius: 14, x: 0, y: 7)
        } else {
            self.liquidFallbackBackground(shape: Capsule())
        }
        #else
        self.liquidFallbackBackground(shape: Capsule())
        #endif
    }

    private func liquidFallbackBackground<S: Shape>(shape: S) -> some View {
        self
            .background(.ultraThinMaterial, in: shape)
            .background(
                LinearGradient(colors: [.white.opacity(0.24), .blue.opacity(0.08), .cyan.opacity(0.05)], startPoint: .topLeading, endPoint: .bottomTrailing),
                in: shape
            )
            .overlay(shape.stroke(LinearGradient(colors: [.white.opacity(0.45), .cyan.opacity(0.25), .blue.opacity(0.12)], startPoint: .topLeading, endPoint: .bottomTrailing), lineWidth: 1))
            .shadow(color: .blue.opacity(0.12), radius: 18, x: 0, y: 10)
    }
}

struct LiquidBackground: View {
    var body: some View {
        ZStack {
            LinearGradient(
                colors: [
                    Color(red: 0.94, green: 0.98, blue: 1.00),
                    Color(red: 0.77, green: 0.91, blue: 1.00),
                    Color(red: 0.43, green: 0.70, blue: 1.00),
                    Color(red: 0.08, green: 0.18, blue: 0.36)
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            Circle().fill(.white.opacity(0.50)).blur(radius: 85).offset(x: -180, y: -250)
            Circle().fill(.cyan.opacity(0.42)).blur(radius: 90).offset(x: 170, y: 245)
            Circle().fill(.blue.opacity(0.28)).blur(radius: 70).offset(x: 180, y: -150)
            Circle().fill(.white.opacity(0.20)).blur(radius: 55).offset(x: -120, y: 260)
            LinearGradient(colors: [.white.opacity(0.12), .clear, .black.opacity(0.12)], startPoint: .top, endPoint: .bottom)
        }
        .ignoresSafeArea()
    }
}
