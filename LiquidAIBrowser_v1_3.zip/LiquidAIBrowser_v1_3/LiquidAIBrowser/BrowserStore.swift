import Foundation
import SwiftUI
import UIKit
import Combine

final class BrowserStore: ObservableObject {
    @Published var tabs: [BrowserTab] = []
    @Published var selectedTabID: UUID?
    @Published var tasks: [AgentTask] = []
    @Published var activePanel: AppPanel = .none
    @Published var newTaskPrompt: String = ""
    @Published var alertMessage: String?
    @Published var shareItem: ShareItem?
    @Published var selectedLogLevels: Set<TaskLogLevel> = Set(TaskLogLevel.allCases)

    let settings = AISettings()
    let webPool = WebViewPool()
    lazy var engine: AgentEngine = AgentEngine(store: self, webPool: webPool)
    private var cancellables = Set<AnyCancellable>()

    private struct StoredSession: Codable {
        var tabs: [BrowserTab]
        var selectedTabID: UUID?
        var tasks: [AgentTask]
    }

    init() {
        webPool.store = self
        settings.objectWillChange
            .sink { [weak self] _ in self?.objectWillChange.send() }
            .store(in: &cancellables)

        if settings.persistSessionHistory, restoreSession() {
            for tab in tabs {
                _ = webPool.webView(for: tab.id, initialURL: tab.urlString)
            }
            if selectedTabID == nil { selectedTabID = tabs.first?.id }
        } else {
            createTab(urlString: "https://www.google.com", select: true)
        }
    }

    var selectedTab: BrowserTab? {
        guard let selectedTabID = selectedTabID else { return nil }
        return tabs.first(where: { $0.id == selectedTabID })
    }

    func createTab(urlString: String = "https://www.google.com", select: Bool = true) {
        let tab = BrowserTab(urlString: normalizedURLString(urlString))
        tabs.append(tab)
        if select { selectedTabID = tab.id }
        _ = webPool.webView(for: tab.id, initialURL: tab.urlString)
        persistSession()
    }

    func closeTab(_ id: UUID) {
        let affectedTaskIDs = tasks.filter { $0.tabID == id && !$0.status.isTerminal }.map(\.id)
        affectedTaskIDs.forEach { taskID in
            engine.cancel(taskID: taskID)
            updateTask(taskID, persist: false) { task in
                task.status = .stopped
                task.finishedAt = Date()
                task.pendingAction = nil
                task.pendingActionRisk = ""
                task.currentAction = "标签页已关闭"
            }
            appendLog(taskID: taskID, "标签页已关闭，任务已停止。", level: .warning, persist: false)
        }
        webPool.destroy(tabID: id)
        tabs.removeAll { $0.id == id }
        if selectedTabID == id { selectedTabID = tabs.first?.id }
        if tabs.isEmpty { createTab(select: true) } else { persistSession() }
    }

    func selectTab(_ id: UUID) {
        selectedTabID = id
        webPool.refreshProgress(tabID: id)
        webPool.captureThumbnail(tabID: id)
        persistSession()
    }

    func loadSelectedAddress(_ text: String) {
        guard let id = selectedTabID else { return }
        let normalized = normalizedURLString(text)
        updateTab(id) { tab in
            tab.urlString = normalized
            tab.isLoading = true
            tab.updatedAt = Date()
        }
        webPool.load(tabID: id, urlString: normalized)
    }

    func goBack() { guard let id = selectedTabID else { return }; webPool.goBack(tabID: id) }
    func goForward() { guard let id = selectedTabID else { return }; webPool.goForward(tabID: id) }
    func reload() { guard let id = selectedTabID else { return }; webPool.reload(tabID: id) }
    func stopLoading() { guard let id = selectedTabID else { return }; webPool.stopLoading(tabID: id) }

    func updateTab(_ id: UUID, mutate: (inout BrowserTab) -> Void) {
        guard let index = tabs.firstIndex(where: { $0.id == id }) else { return }
        mutate(&tabs[index])
        persistSession()
    }

    func updateThumbnail(tabID: UUID, image: UIImage?) {
        guard let image, let data = image.jpegData(compressionQuality: 0.72) else { return }
        updateTab(tabID) { tab in
            tab.thumbnailData = data
            tab.updatedAt = Date()
        }
    }

    func createTask(goal: String, tabID: UUID? = nil) {
        let cleanGoal = goal.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleanGoal.isEmpty else { return }
        guard !settings.apiKey.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            alertMessage = "请先在设置里填写 API Key。"
            activePanel = .settings
            return
        }
        let targetTabID = tabID ?? selectedTabID
        guard let targetTabID = targetTabID else { return }
        let hasActive = tasks.contains { $0.tabID == targetTabID && !$0.status.isTerminal && $0.status != .queued }
        let queuedBefore = tasks.filter { $0.tabID == targetTabID && $0.status == .queued }.count
        var task = AgentTask(tabID: targetTabID, goal: cleanGoal, maxIterations: settings.maxIterations, queueIndex: queuedBefore + 1)
        if hasActive {
            task.status = .queued
            task.currentAction = "等待前一个任务完成"
            task.log.append(TaskLogEntry(level: .info, message: "同一标签页已有任务，新任务已加入队列。"))
            tasks.insert(task, at: 0)
            alertMessage = "已加入该标签页任务队列。"
        } else {
            tasks.insert(task, at: 0)
            engine.start(taskID: task.id)
        }
        newTaskPrompt = ""
        activePanel = .tasks
        persistSession()
    }

    func startNextQueuedTask(for tabID: UUID) {
        let hasActive = tasks.contains { $0.tabID == tabID && !$0.status.isTerminal && $0.status != .queued }
        guard !hasActive else { return }
        let queued = tasks
            .filter { $0.tabID == tabID && $0.status == .queued }
            .sorted { $0.createdAt < $1.createdAt }
        guard let next = queued.first else { persistSession(); return }
        appendLog(taskID: next.id, "队列轮到该任务，开始执行。", level: .info, persist: false)
        updateTask(next.id, persist: false) { task in
            task.currentAction = "队列开始执行"
            task.queueIndex = 0
        }
        engine.start(taskID: next.id)
        persistSession()
    }

    func appendLog(taskID: UUID, _ message: String, level: TaskLogLevel = .info, actionType: String? = nil, coordinates: String? = nil, result: String? = nil, persist: Bool = true) {
        guard let index = tasks.firstIndex(where: { $0.id == taskID }) else { return }
        let baseDate = tasks[index].startedAt ?? tasks[index].createdAt
        let elapsed = Date().timeIntervalSince(baseDate)
        tasks[index].log.append(TaskLogEntry(level: level, elapsedSeconds: elapsed, message: message, actionType: actionType, coordinates: coordinates, result: result))
        tasks[index].updatedAt = Date()
        if persist { persistSession() }
    }

    func updateTask(_ id: UUID, persist: Bool = true, mutate: (inout AgentTask) -> Void) {
        guard let index = tasks.firstIndex(where: { $0.id == id }) else { return }
        mutate(&tasks[index])
        tasks[index].updatedAt = Date()
        if persist { persistSession() }
    }

    func task(for id: UUID) -> AgentTask? {
        tasks.first(where: { $0.id == id })
    }

    func pauseTask(_ id: UUID) {
        updateTask(id) { task in
            guard task.status == .running || task.status == .planning else { return }
            task.status = .paused
            task.currentAction = "已暂停"
        }
        appendLog(taskID: id, "用户暂停任务。", level: .warning)
    }

    func resumeTask(_ id: UUID) {
        updateTask(id) { task in
            guard task.status == .paused || task.status == .waitingConfirmation || task.status == .queued else { return }
            task.status = .running
            task.currentAction = task.pendingAction == nil ? "继续执行" : "已确认，准备执行待确认动作"
        }
        appendLog(taskID: id, "用户已确认继续。", level: .security)
        engine.start(taskID: id)
    }

    func stopTask(_ id: UUID) {
        let tabID = task(for: id)?.tabID
        engine.cancel(taskID: id)
        updateTask(id) { task in
            task.status = .stopped
            task.finishedAt = Date()
            task.pendingAction = nil
            task.pendingActionRisk = ""
            task.currentAction = "用户已停止"
        }
        appendLog(taskID: id, "用户停止任务。", level: .warning)
        if let tabID { startNextQueuedTask(for: tabID) }
    }

    func copyTaskLog(_ id: UUID) {
        guard let task = task(for: id) else { return }
        let text = detailedLogText(for: task)
        UIPasteboard.general.string = text
        alertMessage = "日志已复制。"
    }

    func exportReportPDF(taskID: UUID) {
        guard let task = task(for: taskID) else { return }
        let tab = tabs.first(where: { $0.id == task.tabID })
        do {
            let url = try PDFReportExporter.export(task: task, tab: tab, detailedLog: detailedLogText(for: task))
            shareItem = ShareItem(url: url)
            appendLog(taskID: taskID, "已生成 PDF 报告：\(url.lastPathComponent)", level: .info)
        } catch {
            alertMessage = "PDF 导出失败：\(error.localizedDescription)"
        }
    }

    func detailedLogText(for task: AgentTask) -> String {
        task.log.map { entry in
            let date = entry.date.formatted(date: .abbreviated, time: .standard)
            var line = "[\(date)] \(entry.compactLine)"
            if let result = entry.result, !result.isEmpty { line += "\n  result: \(result)" }
            return line
        }.joined(separator: "\n")
    }

    func normalizedURLString(_ text: String) -> String {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        if trimmed.isEmpty { return "https://www.google.com" }
        if trimmed.contains(" ") || (!trimmed.contains(".") && !trimmed.contains("://")) {
            let encoded = trimmed.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? trimmed
            return "https://www.google.com/search?q=\(encoded)"
        }
        if trimmed.lowercased().hasPrefix("http://") || trimmed.lowercased().hasPrefix("https://") {
            return trimmed
        }
        return "https://\(trimmed)"
    }

    private var sessionURL: URL {
        let directory = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first ?? FileManager.default.temporaryDirectory
        try? FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        return directory.appendingPathComponent("liquid_ai_browser_session.json")
    }

    func persistSession() {
        guard settings.persistSessionHistory else { return }
        let stored = StoredSession(tabs: tabs, selectedTabID: selectedTabID, tasks: tasks.map { task in
            var copy = task
            if !copy.status.isTerminal && copy.status != .queued {
                copy.status = .paused
                copy.currentAction = "App 重新打开后已暂停，可手动继续。"
            }
            copy.pendingAction = nil
            copy.pendingActionRisk = ""
            return copy
        })
        if let data = try? JSONEncoder().encode(stored) {
            try? data.write(to: sessionURL, options: [.atomic])
        }
    }

    private func restoreSession() -> Bool {
        guard let data = try? Data(contentsOf: sessionURL), let stored = try? JSONDecoder().decode(StoredSession.self, from: data), !stored.tabs.isEmpty else { return false }
        tabs = stored.tabs
        selectedTabID = stored.selectedTabID ?? stored.tabs.first?.id
        tasks = stored.tasks.map { old in
            var task = old
            if !task.status.isTerminal && task.status != .queued {
                task.status = .paused
                task.currentAction = "App 重新打开后已暂停，可手动继续。"
                task.pendingAction = nil
                task.pendingActionRisk = ""
            }
            return task
        }
        return true
    }
}

enum AppPanel: String, CaseIterable {
    case none
    case newTask
    case tasks
    case settings
}
