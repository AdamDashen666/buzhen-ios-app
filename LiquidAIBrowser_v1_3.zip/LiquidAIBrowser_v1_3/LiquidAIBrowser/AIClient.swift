import Foundation

struct AIClient {
    struct ChatMessage: Encodable {
        let role: String
        let content: String
        let imageBase64JPEG: String?

        init(role: String, content: String, imageBase64JPEG: String? = nil) {
            self.role = role
            self.content = content
            self.imageBase64JPEG = imageBase64JPEG
        }

        enum CodingKeys: String, CodingKey { case role, content }
        enum ContentCodingKeys: String, CodingKey { case type, text, image_url }
        enum ImageURLCodingKeys: String, CodingKey { case url }

        func encode(to encoder: Encoder) throws {
            var container = encoder.container(keyedBy: CodingKeys.self)
            try container.encode(role, forKey: .role)
            guard let imageBase64JPEG, !imageBase64JPEG.isEmpty else {
                try container.encode(content, forKey: .content)
                return
            }
            var parts = container.nestedUnkeyedContainer(forKey: .content)
            var textPart = parts.nestedContainer(keyedBy: ContentCodingKeys.self)
            try textPart.encode("text", forKey: .type)
            try textPart.encode(content, forKey: .text)
            var imagePart = parts.nestedContainer(keyedBy: ContentCodingKeys.self)
            try imagePart.encode("image_url", forKey: .type)
            var imageURL = imagePart.nestedContainer(keyedBy: ImageURLCodingKeys.self, forKey: .image_url)
            try imageURL.encode("data:image/jpeg;base64,\(imageBase64JPEG)", forKey: .url)
        }
    }

    struct ChatRequest: Encodable {
        let model: String
        let messages: [ChatMessage]
        let temperature: Double
        let response_format: ResponseFormat?
    }

    struct ResponseFormat: Encodable {
        let type: String
    }

    struct ChatResponse: Decodable {
        struct Choice: Decodable {
            struct Message: Decodable { let content: String? }
            let message: Message
        }
        let choices: [Choice]
    }

    struct ModelsResponse: Decodable {
        struct Model: Decodable { let id: String }
        let data: [Model]
    }

    func chatJSON(snapshot: AISettingsSnapshot, messages: [ChatMessage]) async throws -> String {
        do {
            return try await chat(snapshot: snapshot, messages: messages, jsonMode: snapshot.useJSONMode)
        } catch {
            if snapshot.useJSONMode {
                return try await chat(snapshot: snapshot, messages: messages, jsonMode: false)
            }
            throw error
        }
    }

    private func chat(snapshot: AISettingsSnapshot, messages: [ChatMessage], jsonMode: Bool) async throws -> String {
        let url = endpoint(baseURL: snapshot.baseURL, path: "chat/completions")
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.timeoutInterval = snapshot.requestTimeout
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("Bearer \(snapshot.apiKey)", forHTTPHeaderField: "Authorization")
        request.setValue("LiquidAIBrowser", forHTTPHeaderField: "X-Title")
        request.setValue("https://liquid-ai-browser.local", forHTTPHeaderField: "HTTP-Referer")
        let body = ChatRequest(model: snapshot.model, messages: messages, temperature: snapshot.temperature, response_format: jsonMode ? ResponseFormat(type: "json_object") : nil)
        request.httpBody = try JSONEncoder().encode(body)
        let (data, response) = try await URLSession.shared.data(for: request)
        if let http = response as? HTTPURLResponse, !(200...299).contains(http.statusCode) {
            let text = String(data: data, encoding: .utf8) ?? "HTTP \(http.statusCode)"
            throw NSError(domain: "LiquidAIBrowser.API", code: http.statusCode, userInfo: [NSLocalizedDescriptionKey: text])
        }
        let decoded = try JSONDecoder().decode(ChatResponse.self, from: data)
        return decoded.choices.first?.message.content ?? "{}"
    }

    func fetchModels(snapshot: AISettingsSnapshot) async throws -> [String] {
        let url = endpoint(baseURL: snapshot.baseURL, path: "models")
        var request = URLRequest(url: url)
        request.timeoutInterval = snapshot.requestTimeout
        request.setValue("Bearer \(snapshot.apiKey)", forHTTPHeaderField: "Authorization")
        request.setValue("https://liquid-ai-browser.local", forHTTPHeaderField: "HTTP-Referer")
        request.setValue("LiquidAIBrowser", forHTTPHeaderField: "X-Title")
        let (data, response) = try await URLSession.shared.data(for: request)
        if let http = response as? HTTPURLResponse, !(200...299).contains(http.statusCode) {
            let text = String(data: data, encoding: .utf8) ?? "HTTP \(http.statusCode)"
            throw NSError(domain: "LiquidAIBrowser.API", code: http.statusCode, userInfo: [NSLocalizedDescriptionKey: text])
        }
        let decoded = try JSONDecoder().decode(ModelsResponse.self, from: data)
        return decoded.data.map(\.id).sorted()
    }

    private func endpoint(baseURL: String, path: String) -> URL {
        var clean = normalizedBaseURL(baseURL)
        if clean.isEmpty { clean = "https://api.openai.com/v1" }
        if path == "chat/completions", clean.hasSuffix("/chat/completions") {
            return URL(string: clean) ?? URL(string: "https://api.openai.com/v1/chat/completions")!
        }
        if path == "models", clean.hasSuffix("/models") {
            return URL(string: clean) ?? URL(string: "https://api.openai.com/v1/models")!
        }
        return URL(string: clean + "/" + path) ?? URL(string: "https://api.openai.com/v1/" + path)!
    }

    static func normalizedBaseURL(_ baseURL: String) -> String {
        var clean = baseURL.trimmingCharacters(in: .whitespacesAndNewlines)
        while clean.hasSuffix("/") { clean.removeLast() }
        if clean.hasSuffix("/chat/completions") {
            clean = String(clean.dropLast("/chat/completions".count))
        }
        if clean.hasSuffix("/models") {
            clean = String(clean.dropLast("/models".count))
        }
        return clean
    }

    static func extractJSONObject(from text: String) -> String {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard let start = trimmed.firstIndex(of: "{") else { return "{}" }
        var depth = 0
        var inString = false
        var escape = false
        var endIndex: String.Index?
        var index = start
        while index < trimmed.endIndex {
            let char = trimmed[index]
            if escape { escape = false }
            else if char == "\\" { escape = true }
            else if char == "\"" { inString.toggle() }
            else if !inString {
                if char == "{" { depth += 1 }
                if char == "}" {
                    depth -= 1
                    if depth == 0 { endIndex = trimmed.index(after: index); break }
                }
            }
            index = trimmed.index(after: index)
        }
        if let endIndex = endIndex { return String(trimmed[start..<endIndex]) }
        return "{}"
    }
}
