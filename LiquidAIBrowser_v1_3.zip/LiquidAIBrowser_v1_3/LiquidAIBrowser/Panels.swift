import SwiftUI
import UIKit

struct NewTaskPanel: View {
    @EnvironmentObject private var store: BrowserStore

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            if let tab = store.selectedTab {
                HStack(spacing: 10) {
                    ThumbnailView(image: tab.thumbnailImage, title: tab.displayTitle)
                        .frame(width: 96, height: 70)
                    VStack(alignment: .leading, spacing: 4) {
                        Text(tab.displayTitle)
                            .font(.headline)
                            .lineLimit(2)
                        Text(tab.urlString)
                            .font(.caption)
                            .foregroundStyle(.secondary)
                            .lineLimit(2)
                    }
                }
                .padding(12)
                .background(.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 20, style: .continuous))
            }

            Text("输入你想让 AI 在当前标签页完成的任务。AI 会先拆清单，再按顺序操作网页；必要时可用元素坐标、滑动、拖动或视觉截图辅助。")
                .font(.footnote)
                .foregroundStyle(.secondary)

            TextEditor(text: $store.newTaskPrompt)
                .frame(minHeight: 170)
                .scrollContentBackground(.hidden)
                .padding(10)
                .background(.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 20, style: .continuous))
                .overlay(alignment: .topLeading) {
                    if store.newTaskPrompt.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                        Text("例如：帮我在这个页面找到下载按钮并进入；帮我搜索 iPadOS Liquid Glass 文档；帮我把页面里的价格整理出来。")
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                            .padding(18)
                            .allowsHitTesting(false)
                    }
                }

            HStack {
                Button {
                    store.newTaskPrompt = "帮我总结当前网页的重点，并告诉我有没有需要继续点击查看的内容。"
                } label: { Text("总结网页") }
                Button {
                    store.newTaskPrompt = "帮我在当前网页找到最可能的下载按钮，如果有就点击进入下一步。"
                } label: { Text("找下载") }
            }
            .buttonStyle(.bordered)

            Button {
                store.createTask(goal: store.newTaskPrompt)
            } label: {
                Label("开始任务", systemImage: "play.fill")
                    .frame(maxWidth: .infinity)
            }
            .buttonStyle(.borderedProminent)
            .controlSize(.large)
            .disabled(store.newTaskPrompt.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)

            Spacer()
        }
    }
}

struct TasksPanel: View {
    @EnvironmentObject private var store: BrowserStore

    var body: some View {
        ScrollView {
            LazyVStack(spacing: 12) {
                if store.tasks.isEmpty {
                    VStack(spacing: 12) {
                        Image(systemName: "checklist.unchecked")
                            .font(.largeTitle)
                        Text("还没有任务")
                            .font(.headline)
                        Text("在任意标签页点击 Agent 按钮即可创建任务。")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 60)
                }
                ForEach(store.tasks) { task in
                    TaskCardView(task: task)
                }
            }
            .padding(.vertical, 4)
        }
    }
}

struct TaskCardView: View {
    @EnvironmentObject private var store: BrowserStore
    let task: AgentTask
    @State private var expanded = false
    @State private var showSensitiveConfirmation = false

    var body: some View {
        let tab = store.tabs.first(where: { $0.id == task.tabID })
        VStack(alignment: .leading, spacing: 12) {
            HStack(alignment: .top, spacing: 10) {
                ThumbnailView(image: tab?.thumbnailImage, title: tab?.displayTitle ?? "Tab")
                    .frame(width: 92, height: 68)
                    .onTapGesture {
                        if let tab = tab { store.selectTab(tab.id) }
                    }
                VStack(alignment: .leading, spacing: 6) {
                    HStack {
                        Label(task.status.title, systemImage: task.status.symbolName)
                            .font(.caption.weight(.semibold))
                            .foregroundStyle(statusColor)
                        Spacer()
                        Text("\(Int(task.progress * 100))%")
                            .font(.caption.monospacedDigit())
                            .foregroundStyle(.secondary)
                    }
                    Text(task.goal)
                        .font(.subheadline.weight(.semibold))
                        .lineLimit(expanded ? 4 : 2)
                    Text(tab?.displayTitle ?? "标签页已关闭")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                    ProgressView(value: task.progress)
                }
            }

            Text(task.currentAction)
                .font(.caption)
                .foregroundStyle(.secondary)
                .lineLimit(expanded ? 4 : 2)

            if task.status == .waitingConfirmation, let pending = task.pendingAction {
                VStack(alignment: .leading, spacing: 6) {
                    Label("等待确认的敏感操作", systemImage: "exclamationmark.triangle.fill")
                        .font(.caption.weight(.bold))
                        .foregroundStyle(.orange)
                    Text(pendingActionSummary(pending))
                        .font(.caption2)
                        .textSelection(.enabled)
                    if !task.pendingActionRisk.isEmpty {
                        Text(task.pendingActionRisk)
                            .font(.caption2)
                            .foregroundStyle(.secondary)
                            .lineLimit(expanded ? 10 : 4)
                            .textSelection(.enabled)
                    }
                }
                .padding(10)
                .background(.orange.opacity(0.12), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
            }

            VStack(alignment: .leading, spacing: 8) {
                ForEach(Array(task.checklist.enumerated()), id: \.element.id) { index, item in
                    HStack(alignment: .top, spacing: 8) {
                        Image(systemName: item.isDone ? "checkmark.circle.fill" : "circle")
                            .foregroundStyle(item.isDone ? .green : .secondary)
                        VStack(alignment: .leading, spacing: 2) {
                            Text("\(index + 1). \(item.title)")
                                .font(.caption.weight(.semibold))
                            if expanded && !item.detail.isEmpty {
                                Text(item.detail)
                                    .font(.caption2)
                                    .foregroundStyle(.secondary)
                            }
                        }
                    }
                }
            }
            .padding(10)
            .background(.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 16, style: .continuous))

            if expanded {
                if !task.report.isEmpty {
                    VStack(alignment: .leading, spacing: 6) {
                        Text("报告")
                            .font(.caption.weight(.bold))
                        Text(task.report)
                            .font(.caption)
                            .textSelection(.enabled)
                    }
                    .padding(10)
                    .background(.green.opacity(0.10), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                }

                if let data = task.lastScreenshotData, let image = UIImage(data: data) {
                    VStack(alignment: .leading, spacing: 6) {
                        Text("最近一次视觉截图")
                            .font(.caption.weight(.bold))
                        Image(uiImage: image)
                            .resizable()
                            .scaledToFit()
                            .frame(maxHeight: 180)
                            .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                        if let date = task.lastScreenshotAt {
                            Text("截图时间：\(date.formatted(date: .omitted, time: .standard))")
                                .font(.caption2)
                                .foregroundStyle(.secondary)
                        }
                    }
                    .padding(10)
                    .background(.blue.opacity(0.08), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                }

                DisclosureGroup("详细运行日志") {
                    VStack(alignment: .leading, spacing: 8) {
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack {
                                ForEach(TaskLogLevel.allCases) { level in
                                    Toggle(level.title, isOn: Binding(
                                        get: { store.selectedLogLevels.contains(level) },
                                        set: { enabled in
                                            if enabled { store.selectedLogLevels.insert(level) }
                                            else { store.selectedLogLevels.remove(level) }
                                        }
                                    ))
                                    .toggleStyle(.button)
                                    .font(.caption2)
                                }
                            }
                        }
                        ForEach(task.log.filter { store.selectedLogLevels.contains($0.level) }.suffix(28)) { entry in
                            VStack(alignment: .leading, spacing: 2) {
                                Text(entry.compactLine)
                                    .font(.caption2.monospaced())
                                    .foregroundStyle(entry.level == .error ? .red : entry.level == .warning ? .orange : .secondary)
                                    .textSelection(.enabled)
                                if let result = entry.result, !result.isEmpty {
                                    Text(result)
                                        .font(.caption2.monospaced())
                                        .foregroundStyle(.tertiary)
                                        .lineLimit(3)
                                        .textSelection(.enabled)
                                }
                            }
                            .frame(maxWidth: .infinity, alignment: .leading)
                        }
                    }
                    .padding(.top, 6)
                }
            }

            HStack {
                Button(expanded ? "收起" : "详情") { expanded.toggle() }
                Spacer()
                if task.status == .running || task.status == .planning {
                    Button("暂停") { store.pauseTask(task.id) }
                } else if task.status == .waitingConfirmation {
                    Button("确认继续") { showSensitiveConfirmation = true }
                } else if task.status == .paused {
                    Button("继续") { store.resumeTask(task.id) }
                }
                if !task.status.isTerminal {
                    Button("停止", role: .destructive) { store.stopTask(task.id) }
                }
                Button { store.copyTaskLog(task.id) } label: { Image(systemName: "doc.on.doc") }
                Button { store.exportReportPDF(taskID: task.id) } label: { Image(systemName: "doc.richtext") }
            }
            .buttonStyle(.bordered)
            .font(.caption)
        }
        .padding(12)
        .background(.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 22, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 22, style: .continuous)
                .stroke(.white.opacity(0.09), lineWidth: 1)
        }
        .confirmationDialog("确认执行敏感操作？", isPresented: $showSensitiveConfirmation, titleVisibility: .visible) {
            Button("确认执行", role: .destructive) { store.resumeTask(task.id) }
            Button("取消", role: .cancel) {}
        } message: {
            Text(task.pendingActionRisk.isEmpty ? "确认后，Agent 会继续执行当前待确认动作。" : task.pendingActionRisk)
        }
    }

    private func pendingActionSummary(_ action: AgentAction) -> String {
        var lines = ["动作：\(action.type)"]
        if let selector = action.selector, !selector.isEmpty { lines.append("Selector：\(selector)") }
        if let text = action.text, !text.isEmpty { lines.append("目标文字：\(text)") }
        if let value = action.value, !value.isEmpty { lines.append("输入/选择：\(String(value.prefix(120)))") }
        if let url = action.url, !url.isEmpty { lines.append("URL：\(url)") }
        if let reason = action.reason, !reason.isEmpty { lines.append("原因：\(reason)") }
        return lines.joined(separator: "\n")
    }

    var statusColor: Color {
        switch task.status {
        case .completed: return .green
        case .failed, .stopped: return .red
        case .waitingConfirmation: return .orange
        case .paused: return .yellow
        default: return .blue
        }
    }
}

struct SettingsPanel: View {
    @EnvironmentObject private var store: BrowserStore
    @State private var isTesting = false
    @State private var testMessage = ""

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                GroupBox("API 预设") {
                    VStack(alignment: .leading, spacing: 10) {
                        Picker("Provider", selection: Binding(get: { store.settings.providerName }, set: { newValue in
                            if let preset = AISettings.presets.first(where: { $0.name == newValue }) {
                                store.settings.applyPreset(preset)
                            }
                        })) {
                            ForEach(AISettings.presets) { preset in
                                Text(preset.name).tag(preset.name)
                            }
                        }
                        .pickerStyle(.menu)

                        TextField("Base URL", text: Binding(get: { store.settings.baseURL }, set: { store.settings.baseURL = $0 }))
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled()
                            .textFieldStyle(.roundedBorder)

                        HStack {
                            SecureField("API Key", text: Binding(get: { store.settings.apiKey }, set: { store.settings.apiKey = $0 }))
                                .textInputAutocapitalization(.never)
                                .autocorrectionDisabled()
                                .textFieldStyle(.roundedBorder)
                            Button("清除") { store.settings.apiKey = "" }
                                .disabled(store.settings.apiKey.isEmpty)
                        }

                        HStack {
                            TextField("模型", text: Binding(get: { store.settings.model }, set: { store.settings.model = $0 }))
                                .textInputAutocapitalization(.never)
                                .autocorrectionDisabled()
                                .textFieldStyle(.roundedBorder)
                            Button("刷新模型") { refreshModels() }
                                .disabled(isTesting || store.settings.apiKey.isEmpty)
                        }

                        if !store.settings.availableModels.isEmpty {
                            Picker("可用模型", selection: Binding(get: { store.settings.model }, set: { store.settings.model = $0 })) {
                                ForEach(store.settings.availableModels, id: \.self) { model in
                                    Text(model).tag(model)
                                }
                            }
                            .pickerStyle(.menu)
                        }
                    }
                }
                .groupBoxStyle(.liquid)

                GroupBox("Agent 参数") {
                    VStack(alignment: .leading, spacing: 12) {
                        HStack {
                            Text("Temperature")
                            Slider(value: Binding(get: { store.settings.temperature }, set: { store.settings.temperature = $0 }), in: 0...1)
                            Text(String(format: "%.2f", store.settings.temperature))
                                .font(.caption.monospacedDigit())
                        }
                        Stepper("最大循环次数：\(store.settings.maxIterations)", value: Binding(get: { store.settings.maxIterations }, set: { store.settings.maxIterations = $0 }), in: 3...50)
                        Stepper("请求超时：\(Int(store.settings.requestTimeout)) 秒", value: Binding(get: { store.settings.requestTimeout }, set: { store.settings.requestTimeout = $0 }), in: 15...180, step: 5)
                        Toggle("使用 JSON Mode，失败自动降级", isOn: Binding(get: { store.settings.useJSONMode }, set: { store.settings.useJSONMode = $0 }))
                        Toggle("敏感操作需要确认", isOn: Binding(get: { store.settings.requireConfirmationForSensitiveActions }, set: { store.settings.requireConfirmationForSensitiveActions = $0 }))
                        Toggle("允许坐标点击 / 双击 / 滑动 / 拖动 fallback", isOn: Binding(get: { store.settings.allowCoordinateFallback }, set: { store.settings.allowCoordinateFallback = $0 }))
                        Toggle("每一步发送当前可视区域截图给 AI", isOn: Binding(get: { store.settings.enableVisionScreenshots }, set: { store.settings.enableVisionScreenshots = $0 }))
                        Toggle("保存标签页和任务历史", isOn: Binding(get: { store.settings.persistSessionHistory }, set: { store.settings.persistSessionHistory = $0 }))
                        Stepper("动作失败重试上限：\(store.settings.maxActionRetries)", value: Binding(get: { store.settings.maxActionRetries }, set: { store.settings.maxActionRetries = $0 }), in: 1...10)
                        Text("视觉截图辅助需要你选择的模型支持图片输入。坐标动作使用网页 viewport 坐标，仍是 JS 合成事件，不等于系统级真手指触摸。")
                            .font(.caption2)
                            .foregroundStyle(.secondary)
                        Text("隐私：Agent 会把当前网页文本、元素坐标和可选截图发送给你设置的模型服务。密码、验证码、信用卡、token 等字段会默认脱敏，但仍建议只在可信网页使用。")
                            .font(.caption2)
                            .foregroundStyle(.secondary)
                    }
                }
                .groupBoxStyle(.liquid)

                Button {
                    testConnection()
                } label: {
                    if isTesting {
                        ProgressView()
                            .frame(maxWidth: .infinity)
                    } else {
                        Label("测试连接", systemImage: "network")
                            .frame(maxWidth: .infinity)
                    }
                }
                .buttonStyle(.borderedProminent)
                .disabled(isTesting || store.settings.apiKey.isEmpty)

                if !testMessage.isEmpty {
                    Text(testMessage)
                        .font(.caption)
                        .foregroundStyle(testMessage.contains("成功") ? .green : .orange)
                        .textSelection(.enabled)
                }

                Text("说明：App 前台时，非当前标签页的任务会继续运行；App 退到后台或锁屏后，iOS 可能挂起普通网页自动化任务。")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            .padding(.bottom, 20)
        }
    }

    private func refreshModels() {
        isTesting = true
        testMessage = ""
        let snapshot = store.settings.snapshot()
        Swift.Task {
            do {
                let models = try await AIClient().fetchModels(snapshot: snapshot)
                await MainActor.run {
                    store.settings.availableModels = models
                    if let first = models.first, store.settings.model.isEmpty { store.settings.model = first }
                    testMessage = "刷新成功：\(models.count) 个模型。"
                    isTesting = false
                }
            } catch {
                await MainActor.run {
                    testMessage = "刷新失败：\(error.localizedDescription)"
                    isTesting = false
                }
            }
        }
    }

    private func testConnection() {
        isTesting = true
        testMessage = ""
        let snapshot = store.settings.snapshot()
        Swift.Task {
            do {
                let raw = try await AIClient().chatJSON(snapshot: snapshot, messages: [
                    AIClient.ChatMessage(role: "system", content: "只输出 JSON：{\"ok\":true,\"message\":\"success\"}"),
                    AIClient.ChatMessage(role: "user", content: "测试连接")
                ])
                await MainActor.run {
                    testMessage = "连接成功：\(AIClient.extractJSONObject(from: raw))"
                    isTesting = false
                }
            } catch {
                await MainActor.run {
                    testMessage = "连接失败：\(error.localizedDescription)"
                    isTesting = false
                }
            }
        }
    }
}

struct ThumbnailView: View {
    let image: UIImage?
    let title: String

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .fill(.white.opacity(0.10))
            if let image = image {
                Image(uiImage: image)
                    .resizable()
                    .scaledToFill()
                    .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
            } else {
                VStack(spacing: 4) {
                    Image(systemName: "globe")
                    Text(String(title.prefix(8)))
                        .font(.caption2)
                        .lineLimit(1)
                }
                .foregroundStyle(.secondary)
            }
        }
        .clipped()
        .overlay {
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .stroke(.white.opacity(0.12), lineWidth: 1)
        }
    }
}

struct LiquidGroupBoxStyle: GroupBoxStyle {
    func makeBody(configuration: Configuration) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            configuration.label
                .font(.headline)
            configuration.content
        }
        .padding(12)
        .background(.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 20, style: .continuous))
    }
}

extension GroupBoxStyle where Self == LiquidGroupBoxStyle {
    static var liquid: LiquidGroupBoxStyle { LiquidGroupBoxStyle() }
}
