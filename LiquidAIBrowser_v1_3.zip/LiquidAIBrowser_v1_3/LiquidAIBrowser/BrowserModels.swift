import Foundation
import UIKit

struct BrowserTab: Identifiable, Equatable, Codable {
    let id: UUID
    var title: String
    var urlString: String
    var isLoading: Bool
    var estimatedProgress: Double
    var createdAt: Date
    var updatedAt: Date
    var thumbnailData: Data?

    init(id: UUID = UUID(), title: String = "New Tab", urlString: String = "https://www.google.com", isLoading: Bool = false, estimatedProgress: Double = 0) {
        self.id = id
        self.title = title
        self.urlString = urlString
        self.isLoading = isLoading
        self.estimatedProgress = estimatedProgress
        self.createdAt = Date()
        self.updatedAt = Date()
        self.thumbnailData = nil
    }

    var displayTitle: String {
        if !title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { return title }
        return URL(string: urlString)?.host ?? "New Tab"
    }

    var thumbnailImage: UIImage? {
        guard let data = thumbnailData else { return nil }
        return UIImage(data: data)
    }
}

enum TaskStatus: String, Codable, CaseIterable, Hashable {
    case queued
    case planning
    case running
    case paused
    case waitingConfirmation
    case completed
    case failed
    case stopped

    var title: String {
        switch self {
        case .queued: return "排队中"
        case .planning: return "规划中"
        case .running: return "执行中"
        case .paused: return "已暂停"
        case .waitingConfirmation: return "等待确认"
        case .completed: return "已完成"
        case .failed: return "失败"
        case .stopped: return "已停止"
        }
    }

    var symbolName: String {
        switch self {
        case .queued: return "clock"
        case .planning: return "wand.and.stars"
        case .running: return "play.circle.fill"
        case .paused: return "pause.circle.fill"
        case .waitingConfirmation: return "exclamationmark.triangle.fill"
        case .completed: return "checkmark.circle.fill"
        case .failed: return "xmark.octagon.fill"
        case .stopped: return "stop.circle.fill"
        }
    }

    var isTerminal: Bool {
        self == .completed || self == .failed || self == .stopped
    }
}

enum TaskLogLevel: String, Codable, CaseIterable, Hashable, Identifiable {
    case info
    case action
    case visual
    case security
    case warning
    case error

    var id: String { rawValue }

    var title: String {
        switch self {
        case .info: return "信息"
        case .action: return "动作"
        case .visual: return "视觉"
        case .security: return "安全"
        case .warning: return "警告"
        case .error: return "错误"
        }
    }
}

struct TaskChecklistItem: Identifiable, Codable, Equatable {
    var id: UUID = UUID()
    var title: String
    var detail: String
    var isDone: Bool = false
    var note: String = ""
}

struct TaskLogEntry: Identifiable, Codable, Equatable {
    var id: UUID = UUID()
    var date: Date = Date()
    var level: TaskLogLevel = .info
    var elapsedSeconds: Double = 0
    var message: String
    var actionType: String? = nil
    var coordinates: String? = nil
    var result: String? = nil

    var compactLine: String {
        let time = String(format: "+%.1fs", elapsedSeconds)
        let coord = coordinates.map { " @\($0)" } ?? ""
        let action = actionType.map { " [\($0)]" } ?? ""
        return "[\(time)] [\(level.title)]\(action)\(coord) \(message)"
    }
}

struct AgentTask: Identifiable, Equatable, Codable {
    let id: UUID
    var tabID: UUID
    var goal: String
    var status: TaskStatus
    var checklist: [TaskChecklistItem]
    var log: [TaskLogEntry]
    var report: String
    var progress: Double
    var currentAction: String
    var pendingAction: AgentAction?
    var pendingActionRisk: String
    var lastError: String
    var iteration: Int
    var maxIterations: Int
    var createdAt: Date
    var updatedAt: Date
    var startedAt: Date?
    var finishedAt: Date?
    var queueIndex: Int
    var totalActionCount: Int
    var failureCount: Int
    var lastFailureCategory: String
    var lastScreenshotAt: Date?
    var lastScreenshotData: Data?

    init(id: UUID = UUID(), tabID: UUID, goal: String, maxIterations: Int, queueIndex: Int = 0) {
        self.id = id
        self.tabID = tabID
        self.goal = goal
        self.status = .queued
        self.checklist = []
        self.log = [TaskLogEntry(message: "任务已创建：\(goal)")]
        self.report = ""
        self.progress = 0
        self.currentAction = "等待开始"
        self.pendingAction = nil
        self.pendingActionRisk = ""
        self.lastError = ""
        self.iteration = 0
        self.maxIterations = maxIterations
        self.createdAt = Date()
        self.updatedAt = Date()
        self.startedAt = nil
        self.finishedAt = nil
        self.queueIndex = queueIndex
        self.totalActionCount = 0
        self.failureCount = 0
        self.lastFailureCategory = ""
        self.lastScreenshotAt = nil
        self.lastScreenshotData = nil
    }
}

struct APIPreset: Identifiable, Hashable {
    var id: String { name }
    let name: String
    let baseURL: String
    let defaultModel: String
}

struct AgentAction: Codable, Equatable {
    var type: String
    var selector: String?
    var text: String?
    var value: String?
    var url: String?
    var direction: String?
    var amount: Int?
    var stepIndex: Int?
    var reason: String?
    var x: Double?
    var y: Double?
    var startX: Double?
    var startY: Double?
    var endX: Double?
    var endY: Double?
    var durationMs: Int?
}

struct AgentDecision: Codable {
    var status: String?
    var summary: String?
    var completedStepIndexes: [Int]?
    var action: AgentAction?
    var report: String?
}

struct AgentPlanResponse: Codable {
    struct Step: Codable {
        var title: String
        var detail: String?
    }
    var steps: [Step]
}

struct AgentActionResult: Codable {
    var ok: Bool
    var message: String
    var category: String?
    var x: Double?
    var y: Double?
    var targetText: String?
}

struct AISettingsSnapshot {
    let apiKey: String
    let baseURL: String
    let model: String
    let temperature: Double
    let requestTimeout: Double
    let useJSONMode: Bool
    let enableVisionScreenshots: Bool
    let allowCoordinateFallback: Bool
    let maxActionRetries: Int
}

struct ShareItem: Identifiable {
    let id = UUID()
    let url: URL
}
