import SwiftUI
import UIKit

struct ContentView: View {
    @EnvironmentObject private var store: BrowserStore
    @State private var addressText: String = ""

    var body: some View {
        GeometryReader { proxy in
            let compact = proxy.size.width < 760
            ZStack(alignment: .trailing) {
                LiquidBackground()
                HStack(spacing: 12) {
                    if !compact {
                        SidebarView()
                            .frame(width: min(290, max(240, proxy.size.width * 0.28)))
                    }
                    BrowserAreaView(addressText: $addressText)
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                    if store.activePanel != .none && !compact {
                        SidePanelView()
                            .frame(width: min(390, max(320, proxy.size.width * 0.34)))
                            .transition(.move(edge: .trailing).combined(with: .opacity))
                    }
                }
                .padding(compact ? 8 : 14)
                .padding(.bottom, compact ? 72 : 0)

                if compact {
                    VStack {
                        Spacer()
                        CompactDockView()
                            .padding(.horizontal, 10)
                            .padding(.bottom, 8)
                    }
                    if store.activePanel != .none {
                        SidePanelView()
                            .frame(width: min(390, proxy.size.width - 20))
                            .padding(.trailing, 10)
                            .transition(.move(edge: .trailing).combined(with: .opacity))
                    }
                }
            }
        }
        .onAppear { addressText = store.selectedTab?.urlString ?? "" }
        .onChange(of: store.selectedTabID) { _ in addressText = store.selectedTab?.urlString ?? "" }
        .alert("提示", isPresented: Binding(get: { store.alertMessage != nil }, set: { if !$0 { store.alertMessage = nil } })) {
            Button("OK", role: .cancel) { store.alertMessage = nil }
        } message: {
            Text(store.alertMessage ?? "")
        }
        .sheet(item: Binding(get: { store.shareItem }, set: { store.shareItem = $0 })) { item in
            ActivityView(activityItems: [item.url])
        }
    }
}

struct CompactDockView: View {
    @EnvironmentObject private var store: BrowserStore

    var body: some View {
        HStack(spacing: 10) {
            Button { store.createTab(select: true) } label: { Image(systemName: "plus") }
            Menu {
                ForEach(store.tabs) { tab in
                    Button(tab.displayTitle) { store.selectTab(tab.id) }
                }
            } label: {
                Label("标签", systemImage: "rectangle.stack.fill")
            }
            Button {
                withAnimation(.easeInOut(duration: 0.2)) { store.activePanel = .newTask }
            } label: { Label("任务", systemImage: "sparkles") }
            Button {
                withAnimation(.easeInOut(duration: 0.2)) { store.activePanel = .tasks }
            } label: { Image(systemName: "checklist.checked") }
            Button {
                withAnimation(.easeInOut(duration: 0.2)) { store.activePanel = .settings }
            } label: { Image(systemName: "gearshape.fill") }
        }
        .buttonStyle(.bordered)
        .padding(10)
        .liquidGlassCard(cornerRadius: 24)
    }
}

struct SidebarView: View {
    @EnvironmentObject private var store: BrowserStore

    var body: some View {
        VStack(spacing: 14) {
            HStack {
                Image(systemName: "sparkles.rectangle.stack.fill")
                    .font(.title2)
                VStack(alignment: .leading, spacing: 2) {
                    Text("Liquid AI Browser")
                        .font(.headline)
                    Text("多标签网页代理")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                Spacer()
            }
            .padding(14)
            .liquidGlassCard(cornerRadius: 24)

            Button {
                store.createTab(select: true)
            } label: {
                Label("新建标签页", systemImage: "plus")
                    .frame(maxWidth: .infinity)
            }
            .buttonStyle(.borderedProminent)
            .controlSize(.large)

            ScrollView {
                VStack(spacing: 10) {
                    ForEach(store.tabs) { tab in
                        TabCardView(tab: tab)
                    }
                }
                .padding(.vertical, 2)
            }

            Spacer()

            VStack(spacing: 8) {
                PanelButton(title: "任务管理", icon: "checklist.checked", panel: .tasks)
                PanelButton(title: "设置", icon: "gearshape.fill", panel: .settings)
            }
        }
        .padding(12)
        .liquidGlassCard(cornerRadius: 30)
    }
}

struct PanelButton: View {
    @EnvironmentObject private var store: BrowserStore
    let title: String
    let icon: String
    let panel: AppPanel

    var body: some View {
        Button {
            withAnimation(.easeInOut(duration: 0.22)) {
                store.activePanel = store.activePanel == panel ? .none : panel
            }
        } label: {
            HStack {
                Label(title, systemImage: icon)
                Spacer()
                if badgeCount > 0 {
                    Text("\(badgeCount)")
                        .font(.caption2.weight(.bold))
                        .padding(.horizontal, 8)
                        .padding(.vertical, 3)
                        .background(.blue.opacity(0.30), in: Capsule())
                }
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 10)
            .background(store.activePanel == panel ? .white.opacity(0.16) : .white.opacity(0.06), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
        }
        .buttonStyle(.plain)
    }

    var badgeCount: Int {
        guard panel == .tasks else { return 0 }
        return store.tasks.filter { !$0.status.isTerminal }.count
    }
}

struct TabCardView: View {
    @EnvironmentObject private var store: BrowserStore
    let tab: BrowserTab

    var body: some View {
        Button {
            store.selectTab(tab.id)
        } label: {
            HStack(spacing: 10) {
                ThumbnailView(image: tab.thumbnailImage, title: tab.displayTitle)
                    .frame(width: 64, height: 48)
                VStack(alignment: .leading, spacing: 5) {
                    HStack {
                        Text(tab.displayTitle)
                            .font(.subheadline.weight(.semibold))
                            .lineLimit(1)
                        Spacer()
                        if tab.isLoading { ProgressView().scaleEffect(0.65) }
                    }
                    Text(URL(string: tab.urlString)?.host ?? tab.urlString)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                    let running = store.tasks.filter { $0.tabID == tab.id && !$0.status.isTerminal }
                    if let task = running.first {
                        HStack(spacing: 6) {
                            Image(systemName: task.status.symbolName).font(.caption2)
                            Text(task.status.title)
                                .font(.caption2)
                            ProgressView(value: task.progress)
                                .frame(maxWidth: 70)
                        }
                        .foregroundStyle(.green)
                    }
                }
                Button(role: .destructive) { store.closeTab(tab.id) } label: { Image(systemName: "xmark") }
                    .buttonStyle(.plain)
                    .font(.caption)
                    .opacity(store.tabs.count > 1 ? 0.8 : 0.25)
                    .disabled(store.tabs.count <= 1)
            }
            .padding(10)
            .background(store.selectedTabID == tab.id ? .white.opacity(0.18) : .white.opacity(0.06), in: RoundedRectangle(cornerRadius: 20, style: .continuous))
            .overlay {
                RoundedRectangle(cornerRadius: 20, style: .continuous)
                    .stroke(store.selectedTabID == tab.id ? .white.opacity(0.30) : .white.opacity(0.08), lineWidth: 1)
            }
        }
        .buttonStyle(.plain)
    }
}

struct BrowserAreaView: View {
    @EnvironmentObject private var store: BrowserStore
    @Binding var addressText: String

    var body: some View {
        VStack(spacing: 10) {
            BrowserToolbarView(addressText: $addressText)
            ZStack(alignment: .bottomTrailing) {
                RoundedRectangle(cornerRadius: 28, style: .continuous)
                    .fill(.white.opacity(0.08))
                if let tab = store.selectedTab {
                    BrowserWebView(tabID: tab.id)
                        .id(tab.id)
                        .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
                        .padding(5)
                    AgentFloatingButton(tabID: tab.id)
                        .padding(24)
                } else {
                    Text("没有打开的标签页")
                        .foregroundStyle(.secondary)
                }
            }
            .liquidGlassCard(cornerRadius: 30)
        }
    }
}

struct BrowserToolbarView: View {
    @EnvironmentObject private var store: BrowserStore
    @Binding var addressText: String

    var body: some View {
        HStack(spacing: 10) {
            Button { store.goBack() } label: { Image(systemName: "chevron.left") }
            Button { store.goForward() } label: { Image(systemName: "chevron.right") }
            Button { store.selectedTab?.isLoading == true ? store.stopLoading() : store.reload() } label: { Image(systemName: store.selectedTab?.isLoading == true ? "xmark" : "arrow.clockwise") }
            TextField("搜索或输入网址", text: $addressText)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .keyboardType(.URL)
                .submitLabel(.go)
                .onSubmit { store.loadSelectedAddress(addressText) }
                .padding(.horizontal, 14)
                .padding(.vertical, 10)
                .background(.white.opacity(0.10), in: Capsule())
            Button {
                withAnimation(.easeInOut(duration: 0.2)) { store.activePanel = .newTask }
            } label: {
                Label("给当前页设任务", systemImage: "sparkles")
                    .labelStyle(.titleAndIcon)
            }
            .buttonStyle(.borderedProminent)
        }
        .buttonStyle(.bordered)
        .padding(10)
        .liquidGlassCard(cornerRadius: 24)
        .onChange(of: store.selectedTab?.urlString ?? "") { newValue in addressText = newValue }
    }
}

struct AgentFloatingButton: View {
    @EnvironmentObject private var store: BrowserStore
    let tabID: UUID

    var body: some View {
        VStack(alignment: .trailing, spacing: 10) {
            if let task = store.tasks.first(where: { $0.tabID == tabID && !$0.status.isTerminal }) {
                VStack(alignment: .leading, spacing: 8) {
                    HStack {
                        Image(systemName: task.status.symbolName)
                        Text(task.status.title)
                        Spacer()
                        Text("\(Int(task.progress * 100))%")
                    }
                    .font(.caption.weight(.semibold))
                    ProgressView(value: task.progress)
                    Text(task.currentAction)
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                        .lineLimit(2)
                }
                .padding(12)
                .frame(width: 260)
                .liquidGlassCard(cornerRadius: 22)
            }

            HStack(spacing: 8) {
                Button {
                    withAnimation(.easeInOut(duration: 0.2)) { store.activePanel = .tasks }
                } label: {
                    Image(systemName: "rectangle.stack.badge.play")
                        .font(.headline)
                        .padding(13)
                }
                .liquidGlassCapsule()

                Button {
                    withAnimation(.easeInOut(duration: 0.2)) { store.activePanel = .newTask }
                } label: {
                    HStack {
                        Image(systemName: "sparkles")
                        Text("Agent")
                    }
                    .font(.headline)
                    .padding(.horizontal, 18)
                    .padding(.vertical, 13)
                }
                .liquidGlassCapsule()
            }
        }
    }
}

struct SidePanelView: View {
    @EnvironmentObject private var store: BrowserStore

    var body: some View {
        VStack(spacing: 14) {
            HStack {
                Text(title)
                    .font(.title3.weight(.bold))
                Spacer()
                Button { withAnimation(.easeInOut(duration: 0.2)) { store.activePanel = .none } } label: { Image(systemName: "xmark") }
                    .buttonStyle(.bordered)
            }
            .padding(.horizontal, 4)

            switch store.activePanel {
            case .newTask:
                NewTaskPanel()
            case .tasks:
                TasksPanel()
            case .settings:
                SettingsPanel()
            case .none:
                EmptyView()
            }
        }
        .padding(14)
        .liquidGlassCard(cornerRadius: 30)
    }

    var title: String {
        switch store.activePanel {
        case .newTask: return "新建网页任务"
        case .tasks: return "所有任务"
        case .settings: return "设置"
        case .none: return ""
        }
    }
}
