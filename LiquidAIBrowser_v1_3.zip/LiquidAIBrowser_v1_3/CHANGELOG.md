# LiquidAIBrowser v1.3 更新说明

## 重点新增

- 新增同一标签页任务队列：同一标签页已有任务时，新任务进入队列，前一个完成/失败/停止后自动启动下一个。
- 新增视觉截图辅助开关：开启后，Agent 每轮会截取当前可视区域，并把截图作为 image input 发给支持视觉的模型。
- 新增坐标动作 fallback：支持 `coordinateClick/tap`、`doubleClick`、`swipe`、`drag`。
- 页面扫描增强：元素信息包含 `rect.centerX/centerY`、viewport 坐标、page 坐标、可见性和样式提示。
- 新增 PDF 报告导出：报告包含目标、进度、网页缩略图、视觉截图、清单、总结和详细日志。
- 新增详细日志字段：运行秒数、日志级别、动作类型、坐标、原始执行结果。
- 新增日志过滤：info/action/visual/security/warning/error 可过滤查看。
- 新增会话保存/恢复：可保存标签页与任务历史，重启后未完成任务自动暂停等待手动继续。

## UI 改进

- 将整体风格改为参考之前补帧 App 的蓝白透明玻璃风：明亮蓝白背景、半透明玻璃卡片、大圆角、柔和蓝色发光、高光边框。
- 保留 iOS 27 / Liquid Glass 兼容逻辑：新 SDK 使用 glassEffect，旧 SDK fallback 到 ultraThinMaterial。
- 任务卡增加最近视觉截图展示、PDF 导出按钮、详细日志视图。

## 稳定性改进

- 动作失败后按类别记录，并在达到重试上限后提示坐标 fallback 或人工接管。
- 敏感操作确认继续保留，不会绕过付款/下单/发布/发送等风险操作。
- 坐标动作仍使用网页 JS 合成事件，遇到网站检测 `isTrusted` 时可能失败，并会记录日志。

## 版本

- Marketing Version: 1.3
- Build: 4
