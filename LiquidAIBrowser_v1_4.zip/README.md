# Liquid AI Browser v1.4

独立 iOS / iPadOS AI 浏览器。v1.4 将“标签页”重构为“分组”：一个分组可包含多个网页页面和多个任务；每个任务可以让 AI 根据需要创建新页面、切换页面，并完成跨网站复制、对照、填写等工作流。

## 主要功能

- 独立 `WKWebView` 浏览器。
- 分组管理：一个分组包含多个页面。
- 每个分组可排队多个任务，同一时间只运行一个，避免冲突。
- 任务可使用多个页面，AI 可自行 `createTab / openTab / switchTab`。
- AI 先分析最终目标，再拆成动作级清单。
- 每次点击、输入、按键、滚动、切换页面、检查结果都尽量拆成独立步骤。
- 坐标动作：点击、双击、滑动、拖动。
- 键盘动作：`keyPress / pressEnter / pressTab / keyboardShortcut / typeText`。
- 可选视觉截图辅助：每轮把当前页面截图发给支持视觉的模型。
- 任务完成后可导出 PDF 报告和详细日志。
- 蓝白 Liquid Glass 风格 UI，ProMotion 友好动画。

## 使用方式

1. 解压 zip。
2. 用 Xcode 打开 `LiquidAIBrowser.xcodeproj`。
3. 设置 Team 和 Bundle ID。
4. 真机运行。
5. 进入设置页填写 API Key、Base URL 和模型。
6. 新建分组，打开网页，点击“给分组设任务”。

## 注意

- 这是 DOM + 坐标 + 可选视觉辅助 Agent，不是系统级真电脑控制。
- 键盘和点击是网页 JS 合成事件，部分网站如果检查 `isTrusted` 可能失败。
- iOS/iPadOS 退后台或锁屏后不保证任务长期继续。
- 登录、验证码、付款、下单等敏感操作需要用户确认或手动处理。
