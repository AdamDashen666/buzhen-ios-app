# LiquidAIBrowser v1.4 Project Index

## 核心源码

- `LiquidAIBrowser/LiquidAIBrowserApp.swift`：App 入口。
- `LiquidAIBrowser/BrowserModels.swift`：分组、页面、任务、动作、日志数据模型。
- `LiquidAIBrowser/BrowserStore.swift`：全局状态、分组/页面/任务队列管理、会话保存、PDF 导出入口。
- `LiquidAIBrowser/WebViewPool.swift`：WKWebView 池、DOM 扫描、坐标动作、键盘动作、截图。
- `LiquidAIBrowser/AgentEngine.swift`：任务规划、AI 决策、多页面动作、敏感确认、执行循环。
- `LiquidAIBrowser/AIClient.swift`：OpenAI-compatible API 请求。
- `LiquidAIBrowser/AISettings.swift`：API 设置、模型刷新、Keychain。
- `LiquidAIBrowser/ContentView.swift`：主 UI、分组侧栏、浏览器区域、任务/设置入口。
- `LiquidAIBrowser/Panels.swift`：新建任务、任务管理、设置页、任务卡。
- `LiquidAIBrowser/PDFReportExporter.swift`：PDF 报告导出。
- `LiquidAIBrowser/LiquidGlassSupport.swift`：Liquid Glass / fallback UI。

## 文档

- `README.md`：使用说明。
- `CHANGELOG.md`：版本更新说明。
- `AI_REVIEW_REQUIREMENTS.md`：需求和验收标准。
- `QA_CHECK_REPORT.md`：历史静态检查报告。
- `QA_FIX_REPORT.md`：历史修复报告。
- `QA_V13_FIX_REPORT.md`：v1.3 修复报告。
- `QA_V13_1_BUILD_FIX_REPORT.md`：v1.3.1 编译修复报告。
- `QA_V13_2_UI_FIX_REPORT.md`：v1.3.2 UI 修复报告。
- `QA_V14_GROUP_TASK_KEYBOARD_REPORT.md`：v1.4 分组/键盘/多页面任务修复报告。

## 当前版本

- Version: 1.4
- Build: 7
- 主要新增：分组、多页面任务、AI 创建/切换页面、动作级规划、键盘动作、非线性动画。
