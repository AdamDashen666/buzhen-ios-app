import SwiftUI

@main
struct LiquidAIBrowserApp: App {
    @StateObject private var store = BrowserStore()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(store)
                .preferredColorScheme(.dark)
                .transaction { transaction in
                    transaction.animation = transaction.animation ?? Animation.interactiveSpring(response: 0.22, dampingFraction: 0.90, blendDuration: 0.08)
                }
        }
    }
}
