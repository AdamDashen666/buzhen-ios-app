import SwiftUI

extension View {
    @ViewBuilder
    func liquidGlassCard(cornerRadius: CGFloat = 22) -> some View {
        let shape = RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
        #if compiler(>=6.2)
        if #available(iOS 26.0, *) {
            self
                .glassEffect(.regular, in: shape)
                .overlay(shape.stroke(LinearGradient(colors: [.white.opacity(0.36), .cyan.opacity(0.20), .blue.opacity(0.10)], startPoint: .topLeading, endPoint: .bottomTrailing), lineWidth: 0.8))
                .shadow(color: .cyan.opacity(0.08), radius: 8, x: 0, y: 4)
        } else {
            self.liquidFallbackBackground(shape: shape)
        }
        #else
        self.liquidFallbackBackground(shape: shape)
        #endif
    }

    @ViewBuilder
    func liquidGlassCapsule() -> some View {
        #if compiler(>=6.2)
        if #available(iOS 26.0, *) {
            self
                .glassEffect(.regular, in: Capsule())
                .overlay(Capsule().stroke(LinearGradient(colors: [.white.opacity(0.45), .cyan.opacity(0.20), .blue.opacity(0.12)], startPoint: .topLeading, endPoint: .bottomTrailing), lineWidth: 0.8))
                .shadow(color: .cyan.opacity(0.08), radius: 7, x: 0, y: 3)
        } else {
            self.liquidFallbackBackground(shape: Capsule())
        }
        #else
        self.liquidFallbackBackground(shape: Capsule())
        #endif
    }

    private func liquidFallbackBackground<S: Shape>(shape: S) -> some View {
        self
            .background(.ultraThinMaterial, in: shape)
            .background(
                LinearGradient(colors: [.white.opacity(0.18), .blue.opacity(0.06), .cyan.opacity(0.04)], startPoint: .topLeading, endPoint: .bottomTrailing),
                in: shape
            )
            .overlay(shape.stroke(LinearGradient(colors: [.white.opacity(0.35), .cyan.opacity(0.18), .blue.opacity(0.08)], startPoint: .topLeading, endPoint: .bottomTrailing), lineWidth: 0.8))
            .shadow(color: .blue.opacity(0.08), radius: 7, x: 0, y: 4)
    }
}

struct LiquidBackground: View {
    var body: some View {
        ZStack {
            LinearGradient(
                colors: [
                    Color(red: 0.92, green: 0.97, blue: 1.00),
                    Color(red: 0.68, green: 0.87, blue: 1.00),
                    Color(red: 0.22, green: 0.47, blue: 0.86),
                    Color(red: 0.04, green: 0.10, blue: 0.23)
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            Circle().fill(.white.opacity(0.38)).blur(radius: 42).offset(x: -190, y: -260)
            Circle().fill(.cyan.opacity(0.26)).blur(radius: 46).offset(x: 180, y: 260)
            Circle().fill(.blue.opacity(0.18)).blur(radius: 38).offset(x: 170, y: -170)
            LinearGradient(colors: [.white.opacity(0.08), .clear, .black.opacity(0.18)], startPoint: .top, endPoint: .bottom)
        }
        .ignoresSafeArea()
    }
}
