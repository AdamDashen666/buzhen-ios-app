import Foundation
import SwiftUI
import UIKit
import Combine

final class BrowserStore: ObservableObject {
    @Published var groups: [BrowserGroup] = []
    @Published var selectedGroupID: UUID?
    @Published var tabs: [BrowserTab] = []
    @Published var selectedTabID: UUID?
    @Published var tasks: [AgentTask] = []
    @Published var activePanel: AppPanel = .none
    @Published var newTaskPrompt: String = ""
    @Published var alertMessage: String?
    @Published var shareItem: ShareItem?
    @Published var selectedLogLevels: Set<TaskLogLevel> = Set(TaskLogLevel.allCases)
    @Published var showingSettingsPage: Bool = false

    let settings = AISettings()
    let webPool = WebViewPool()
    lazy var engine: AgentEngine = AgentEngine(store: self, webPool: webPool)
    private var cancellables = Set<AnyCancellable>()

    private struct StoredSession: Codable {
        var groups: [BrowserGroup]?
        var selectedGroupID: UUID?
        var tabs: [BrowserTab]
        var selectedTabID: UUID?
        var tasks: [AgentTask]
    }

    init() {
        webPool.store = self
        settings.objectWillChange
            .sink { [weak self] _ in self?.objectWillChange.send() }
            .store(in: &cancellables)

        if settings.persistSessionHistory, restoreSession() {
            for tab in tabs {
                _ = webPool.webView(for: tab.id, initialURL: tab.urlString)
            }
            normalizeSelection()
        } else {
            groups = []
            tabs = []
            tasks = []
            selectedGroupID = nil
            selectedTabID = nil
        }
    }

    var selectedGroup: BrowserGroup? {
        guard let selectedGroupID else { return nil }
        return groups.first(where: { $0.id == selectedGroupID })
    }

    var selectedTab: BrowserTab? {
        guard let selectedTabID else { return nil }
        return tabs.first(where: { $0.id == selectedTabID })
    }

    var selectedGroupTabs: [BrowserTab] {
        guard let groupID = selectedGroupID else { return [] }
        return tabs.filter { $0.groupID == groupID }.sorted { $0.createdAt < $1.createdAt }
    }

    var selectedGroupTasks: [AgentTask] {
        guard let groupID = selectedGroupID else { return [] }
        return tasks.filter { $0.groupID == groupID }
    }

    @discardableResult
    func createGroup(name: String? = nil, select: Bool = true) -> UUID {
        let index = groups.count + 1
        let group = BrowserGroup(name: name ?? "分组 \(index)")
        groups.append(group)
        if select {
            selectedGroupID = group.id
            selectedTabID = nil
        }
        persistSession()
        return group.id
    }

    func renameGroup(_ id: UUID, name: String) {
        guard let index = groups.firstIndex(where: { $0.id == id }) else { return }
        groups[index].name = name
        groups[index].updatedAt = Date()
        persistSession()
    }

    func selectGroup(_ id: UUID) {
        guard groups.contains(where: { $0.id == id }) else { return }
        selectedGroupID = id
        let groupTabs = tabs.filter { $0.groupID == id }.sorted { $0.updatedAt > $1.updatedAt }
        if let selectedTabID, tabs.contains(where: { $0.id == selectedTabID && $0.groupID == id }) {
            webPool.refreshProgress(tabID: selectedTabID)
            webPool.captureThumbnail(tabID: selectedTabID)
        } else {
            selectedTabID = groupTabs.first?.id
            if let selectedTabID {
                webPool.refreshProgress(tabID: selectedTabID)
                webPool.captureThumbnail(tabID: selectedTabID)
            }
        }
        persistSession()
    }

    func closeGroup(_ id: UUID) {
        let affectedTaskIDs = tasks.filter { $0.groupID == id && !$0.status.isTerminal }.map(\.id)
        affectedTaskIDs.forEach { taskID in
            engine.cancel(taskID: taskID)
            updateTask(taskID, persist: false) { task in
                task.status = .stopped
                task.finishedAt = Date()
                task.pendingAction = nil
                task.pendingActionRisk = ""
                task.currentAction = "分组已关闭"
            }
            appendLog(taskID: taskID, "分组已关闭，任务已停止。", level: .warning, persist: false)
        }
        tabs.filter { $0.groupID == id }.map(\.id).forEach { webPool.destroy(tabID: $0) }
        tabs.removeAll { $0.groupID == id }
        groups.removeAll { $0.id == id }
        if selectedGroupID == id { selectedGroupID = groups.first?.id }
        selectedTabID = selectedGroupID.flatMap { gid in tabs.first(where: { $0.groupID == gid })?.id }
        if groups.isEmpty { selectedGroupID = nil; selectedTabID = nil }
        persistSession()
    }

    @discardableResult
    func createTab(urlString: String = "about:blank", groupID: UUID? = nil, select: Bool = true) -> UUID {
        let targetGroupID: UUID
        if let groupID, groups.contains(where: { $0.id == groupID }) {
            targetGroupID = groupID
        } else if let selectedGroupID {
            targetGroupID = selectedGroupID
        } else {
            targetGroupID = createGroup(select: true)
        }
        let tab = BrowserTab(groupID: targetGroupID, urlString: normalizedURLString(urlString))
        tabs.append(tab)
        if select {
            selectedGroupID = targetGroupID
            selectedTabID = tab.id
        }
        if let index = groups.firstIndex(where: { $0.id == targetGroupID }) { groups[index].updatedAt = Date() }
        _ = webPool.webView(for: tab.id, initialURL: tab.urlString)
        persistSession()
        return tab.id
    }

    func closeTab(_ id: UUID) {
        let affectedTaskIDs = tasks.filter { !$0.status.isTerminal && $0.workingTabIDs.contains(id) }.map(\.id)
        affectedTaskIDs.forEach { taskID in
            engine.cancel(taskID: taskID)
            updateTask(taskID, persist: false) { task in
                task.status = .stopped
                task.finishedAt = Date()
                task.pendingAction = nil
                task.pendingActionRisk = ""
                task.currentAction = "任务使用的页面已关闭"
            }
            appendLog(taskID: taskID, "任务使用的页面已关闭，任务已停止。", level: .warning, persist: false)
        }
        webPool.destroy(tabID: id)
        let closedGroupID = tabs.first(where: { $0.id == id })?.groupID
        tabs.removeAll { $0.id == id }
        if selectedTabID == id {
            selectedTabID = closedGroupID.flatMap { gid in tabs.first(where: { $0.groupID == gid })?.id }
        }
        persistSession()
    }

    func clearAllTabs() {
        clearAllGroups()
    }

    func clearAllGroups() {
        let openTaskIDs = tasks.filter { !$0.status.isTerminal }.map(\.id)
        openTaskIDs.forEach { taskID in
            engine.cancel(taskID: taskID)
            updateTask(taskID, persist: false) { task in
                task.status = .stopped
                task.finishedAt = Date()
                task.pendingAction = nil
                task.pendingActionRisk = ""
                task.currentAction = "所有分组和页面已清空"
            }
            appendLog(taskID: taskID, "用户清空所有分组和页面，任务已停止。", level: .warning, persist: false)
        }
        tabs.map(\.id).forEach { webPool.destroy(tabID: $0) }
        tabs.removeAll()
        groups.removeAll()
        selectedGroupID = nil
        selectedTabID = nil
        activePanel = .none
        persistSession()
    }

    func showSettings() {
        activePanel = .none
        showingSettingsPage = true
    }

    func selectTab(_ id: UUID) {
        guard let tab = tabs.first(where: { $0.id == id }) else { return }
        selectedGroupID = tab.groupID
        selectedTabID = id
        webPool.refreshProgress(tabID: id)
        webPool.captureThumbnail(tabID: id)
        persistSession()
    }

    func loadSelectedAddress(_ text: String) {
        let normalized = normalizedURLString(text)
        guard let id = selectedTabID else {
            createTab(urlString: normalized, select: true)
            return
        }
        updateTab(id) { tab in
            tab.urlString = normalized
            tab.isLoading = true
            tab.updatedAt = Date()
        }
        webPool.load(tabID: id, urlString: normalized)
    }

    func goBack() { guard let id = selectedTabID else { return }; webPool.goBack(tabID: id) }
    func goForward() { guard let id = selectedTabID else { return }; webPool.goForward(tabID: id) }
    func reload() { guard let id = selectedTabID else { return }; webPool.reload(tabID: id) }
    func stopLoading() { guard let id = selectedTabID else { return }; webPool.stopLoading(tabID: id) }

    func updateTab(_ id: UUID, mutate: (inout BrowserTab) -> Void) {
        guard let index = tabs.firstIndex(where: { $0.id == id }) else { return }
        mutate(&tabs[index])
        tabs[index].updatedAt = Date()
        if let groupIndex = groups.firstIndex(where: { $0.id == tabs[index].groupID }) { groups[groupIndex].updatedAt = Date() }
        persistSession()
    }

    func updateThumbnail(tabID: UUID, image: UIImage?) {
        guard let image, let data = image.jpegData(compressionQuality: 0.72) else { return }
        updateTab(tabID) { tab in
            tab.thumbnailData = data
            tab.updatedAt = Date()
        }
    }

    func createTask(goal: String, groupID: UUID? = nil, tabID: UUID? = nil) {
        let cleanGoal = goal.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleanGoal.isEmpty else { return }
        guard !settings.apiKey.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            alertMessage = "请先在设置里填写 API Key。"
            showSettings()
            return
        }
        let targetGroupID = groupID ?? selectedGroupID ?? createGroup(select: true)
        let targetTabID: UUID
        if let tabID, tabs.contains(where: { $0.id == tabID && $0.groupID == targetGroupID }) {
            targetTabID = tabID
        } else if let selectedTabID, tabs.contains(where: { $0.id == selectedTabID && $0.groupID == targetGroupID }) {
            targetTabID = selectedTabID
        } else if let first = tabs.first(where: { $0.groupID == targetGroupID })?.id {
            targetTabID = first
        } else {
            targetTabID = createTab(urlString: "about:blank", groupID: targetGroupID, select: true)
        }
        let hasActive = tasks.contains { $0.groupID == targetGroupID && !$0.status.isTerminal && $0.status != .queued }
        let queuedBefore = tasks.filter { $0.groupID == targetGroupID && $0.status == .queued }.count
        var task = AgentTask(groupID: targetGroupID, tabID: targetTabID, goal: cleanGoal, maxIterations: settings.maxIterations, queueIndex: queuedBefore + 1)
        if hasActive {
            task.status = .queued
            task.currentAction = "等待该分组的前一个任务完成"
            task.log.append(TaskLogEntry(level: .info, message: "同一分组已有任务，新任务已加入队列。"))
            tasks.insert(task, at: 0)
            alertMessage = "已加入该分组任务队列。"
        } else {
            tasks.insert(task, at: 0)
            engine.start(taskID: task.id)
        }
        newTaskPrompt = ""
        activePanel = .tasks
        persistSession()
    }

    func startNextQueuedTask(for groupID: UUID) {
        let hasActive = tasks.contains { $0.groupID == groupID && !$0.status.isTerminal && $0.status != .queued }
        guard !hasActive else { return }
        let queued = tasks
            .filter { $0.groupID == groupID && $0.status == .queued }
            .sorted { $0.createdAt < $1.createdAt }
        guard let next = queued.first else { persistSession(); return }
        appendLog(taskID: next.id, "队列轮到该分组任务，开始执行。", level: .info, persist: false)
        updateTask(next.id, persist: false) { task in
            task.currentAction = "队列开始执行"
            task.queueIndex = 0
        }
        engine.start(taskID: next.id)
        persistSession()
    }

    @MainActor
    func createTabForTask(taskID: UUID, urlString: String = "about:blank", select: Bool = true) -> UUID? {
        guard let task = task(for: taskID) else { return nil }
        let tabID = createTab(urlString: urlString, groupID: task.groupID, select: select)
        updateTask(taskID, persist: false) { task in
            if !task.workingTabIDs.contains(tabID) { task.workingTabIDs.append(tabID) }
            task.tabID = tabID
        }
        appendLog(taskID: taskID, "AI 为任务创建了新页面：\(urlString)", level: .action, actionType: "createTab", persist: false)
        persistSession()
        return tabID
    }

    @MainActor
    func switchTask(taskID: UUID, to tabID: UUID) -> Bool {
        guard let task = task(for: taskID), tabs.contains(where: { $0.id == tabID && $0.groupID == task.groupID }) else { return false }
        updateTask(taskID, persist: false) { task in
            task.tabID = tabID
            if !task.workingTabIDs.contains(tabID) { task.workingTabIDs.append(tabID) }
        }
        selectedGroupID = task.groupID
        selectedTabID = tabID
        appendLog(taskID: taskID, "AI 切换到任务页面：\(tabs.first(where: { $0.id == tabID })?.displayTitle ?? tabID.uuidString)", level: .action, actionType: "switchTab", persist: false)
        persistSession()
        return true
    }

    func tabsSummary(for groupID: UUID) -> String {
        tabs.filter { $0.groupID == groupID }.map { tab in
            let activeMark = tab.id == selectedTabID ? "当前显示" : "后台"
            return "- tabID=\(tab.id.uuidString) [\(activeMark)] title=\(tab.displayTitle) url=\(tab.urlString)"
        }.joined(separator: "\n")
    }

    func appendLog(taskID: UUID, _ message: String, level: TaskLogLevel = .info, actionType: String? = nil, coordinates: String? = nil, result: String? = nil, persist: Bool = true) {
        guard let index = tasks.firstIndex(where: { $0.id == taskID }) else { return }
        let baseDate = tasks[index].startedAt ?? tasks[index].createdAt
        let elapsed = Date().timeIntervalSince(baseDate)
        tasks[index].log.append(TaskLogEntry(level: level, elapsedSeconds: elapsed, message: message, actionType: actionType, coordinates: coordinates, result: result))
        tasks[index].updatedAt = Date()
        if persist { persistSession() }
    }

    func updateTask(_ id: UUID, persist: Bool = true, mutate: (inout AgentTask) -> Void) {
        guard let index = tasks.firstIndex(where: { $0.id == id }) else { return }
        mutate(&tasks[index])
        tasks[index].updatedAt = Date()
        if persist { persistSession() }
    }

    func task(for id: UUID) -> AgentTask? {
        tasks.first(where: { $0.id == id })
    }

    func pauseTask(_ id: UUID) {
        updateTask(id) { task in
            guard task.status == .running || task.status == .planning else { return }
            task.status = .paused
            task.currentAction = "已暂停"
        }
        appendLog(taskID: id, "用户暂停任务。", level: .warning)
    }

    func resumeTask(_ id: UUID) {
        updateTask(id) { task in
            guard task.status == .paused || task.status == .waitingConfirmation || task.status == .queued else { return }
            task.status = .running
            task.currentAction = task.pendingAction == nil ? "继续执行" : "已确认，准备执行待确认动作"
        }
        appendLog(taskID: id, "用户已确认继续。", level: .security)
        engine.start(taskID: id)
    }

    func stopTask(_ id: UUID) {
        stopTask(id, reason: "用户已停止")
    }

    func stopTask(_ id: UUID, reason: String) {
        let groupID = task(for: id)?.groupID
        engine.cancel(taskID: id)
        updateTask(id) { task in
            task.status = .stopped
            task.finishedAt = Date()
            task.pendingAction = nil
            task.pendingActionRisk = ""
            task.currentAction = reason
        }
        appendLog(taskID: id, reason, level: .warning)
        if let groupID { startNextQueuedTask(for: groupID) }
    }

    func copyTaskLog(_ id: UUID) {
        guard let task = task(for: id) else { return }
        let text = detailedLogText(for: task)
        UIPasteboard.general.string = text
        alertMessage = "日志已复制。"
    }

    func exportReportPDF(taskID: UUID) {
        guard let task = task(for: taskID) else { return }
        let tab = tabs.first(where: { $0.id == task.tabID })
        do {
            let url = try PDFReportExporter.export(task: task, tab: tab, detailedLog: detailedLogText(for: task))
            shareItem = ShareItem(url: url)
            appendLog(taskID: taskID, "已生成 PDF 报告：\(url.lastPathComponent)", level: .info)
        } catch {
            alertMessage = "PDF 导出失败：\(error.localizedDescription)"
        }
    }

    func detailedLogText(for task: AgentTask) -> String {
        let groupName = groups.first(where: { $0.id == task.groupID })?.displayName ?? "未知分组"
        let pages = task.workingTabIDs.compactMap { id in tabs.first(where: { $0.id == id }) }.map { "- \($0.displayTitle) | \($0.urlString)" }.joined(separator: "\n")
        let header = "任务：\(task.goal)\n分组：\(groupName)\n参与页面：\n\(pages.isEmpty ? "- 无" : pages)\n\n"
        let body = task.log.map { entry in
            let date = entry.date.formatted(date: .abbreviated, time: .standard)
            var line = "[\(date)] \(entry.compactLine)"
            if let result = entry.result, !result.isEmpty { line += "\n  result: \(result)" }
            return line
        }.joined(separator: "\n")
        return header + body
    }

    func normalizedURLString(_ text: String) -> String {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        if trimmed.isEmpty { return "about:blank" }
        if trimmed.contains(" ") || (!trimmed.contains(".") && !trimmed.contains("://")) {
            let encoded = trimmed.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? trimmed
            return "https://www.google.com/search?q=\(encoded)"
        }
        if trimmed.lowercased().hasPrefix("http://") || trimmed.lowercased().hasPrefix("https://") || trimmed.lowercased().hasPrefix("about:") {
            return trimmed
        }
        return "https://\(trimmed)"
    }

    private var sessionURL: URL {
        let directory = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first ?? FileManager.default.temporaryDirectory
        try? FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        return directory.appendingPathComponent("liquid_ai_browser_session.json")
    }

    func persistSession() {
        guard settings.persistSessionHistory else { return }
        let stored = StoredSession(groups: groups, selectedGroupID: selectedGroupID, tabs: tabs, selectedTabID: selectedTabID, tasks: tasks.map { task in
            var copy = task
            if !copy.status.isTerminal && copy.status != .queued {
                copy.status = .paused
                copy.currentAction = "App 重新打开后已暂停，可手动继续。"
            }
            copy.pendingAction = nil
            copy.pendingActionRisk = ""
            return copy
        })
        if let data = try? JSONEncoder().encode(stored) {
            try? data.write(to: sessionURL, options: [.atomic])
        }
    }

    private func restoreSession() -> Bool {
        guard let data = try? Data(contentsOf: sessionURL), let stored = try? JSONDecoder().decode(StoredSession.self, from: data) else { return false }
        let fallbackGroup = BrowserGroup(id: UUID(uuidString: "00000000-0000-0000-0000-000000000001")!, name: "恢复的分组")
        groups = stored.groups?.isEmpty == false ? (stored.groups ?? []) : (stored.tabs.isEmpty ? [] : [fallbackGroup])
        tabs = stored.tabs.map { tab in
            var fixed = tab
            if !groups.contains(where: { $0.id == fixed.groupID }) {
                fixed.groupID = groups.first?.id ?? fallbackGroup.id
            }
            return fixed
        }
        selectedGroupID = stored.selectedGroupID ?? tabs.first?.groupID ?? groups.first?.id
        selectedTabID = stored.selectedTabID
        tasks = stored.tasks.map { old in
            var task = old
            if !groups.contains(where: { $0.id == task.groupID }) { task.groupID = tabs.first(where: { $0.id == task.tabID })?.groupID ?? groups.first?.id ?? fallbackGroup.id }
            if !task.workingTabIDs.contains(task.tabID) { task.workingTabIDs.append(task.tabID) }
            if !task.status.isTerminal && task.status != .queued {
                task.status = .paused
                task.currentAction = "App 重新打开后已暂停，可手动继续。"
                task.pendingAction = nil
                task.pendingActionRisk = ""
            }
            return task
        }
        normalizeSelection()
        return true
    }

    private func normalizeSelection() {
        if let selectedGroupID, !groups.contains(where: { $0.id == selectedGroupID }) {
            self.selectedGroupID = groups.first?.id
        }
        if let selectedTabID, !tabs.contains(where: { $0.id == selectedTabID && $0.groupID == self.selectedGroupID }) {
            self.selectedTabID = self.selectedGroupID.flatMap { gid in tabs.first(where: { $0.groupID == gid })?.id }
        }
        if selectedGroupID == nil { selectedGroupID = tabs.first?.groupID ?? groups.first?.id }
        if selectedTabID == nil, let selectedGroupID { selectedTabID = tabs.first(where: { $0.groupID == selectedGroupID })?.id }
        if groups.isEmpty { selectedGroupID = nil }
        if tabs.isEmpty { selectedTabID = nil }
    }
}

enum AppPanel: String, CaseIterable {
    case none
    case newTask
    case tasks
    case settings
}
