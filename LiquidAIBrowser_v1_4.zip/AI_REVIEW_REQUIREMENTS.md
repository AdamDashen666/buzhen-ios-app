# Liquid AI Browser：需求、验收标准与总规划

## 1. 项目目标

做一个独立 iOS / iPadOS 浏览器 App，不依赖 Safari 插件。用户可以在 App 内打开多个网页标签页，并给每个标签页创建一个 AI Agent 任务。AI 需要读取网页 DOM/文本/可交互元素，自动拆解任务步骤，然后按顺序执行点击、输入、滚动、打开链接等动作。任务执行中要显示进度、清单勾选、日志、缩略图和最终报告。

## 2. 必须达到的核心要求

### 2.1 独立浏览器
- 使用原生 WKWebView 加载网页。
- 支持输入网址或关键词搜索。
- 支持前进、后退、刷新、停止加载。
- 支持多标签页。
- 标签页之间保留网页状态，不因切换标签而销毁。
- 支持网页 target=_blank / window.open 在当前标签内打开，避免点击后无响应。
- 支持网页 JavaScript alert / confirm / prompt。

### 2.2 多标签与多任务
- 每个标签页都可以创建独立 Agent 任务。
- App 前台时，非当前标签页任务也应继续执行。
- 每个标签页同一时间只允许一个未结束任务，避免多个 Agent 同时操作同一个网页导致混乱。
- 关闭标签时，相关未结束任务必须停止或标记停止。
- 任务可以暂停、继续、停止。

### 2.3 Agent 执行流程
- 用户输入自然语言任务。
- AI 首先根据当前网页状态拆解目标清单。
- 清单应包含短标题和验证说明。
- Agent 循环读取网页状态。
- AI 根据目标、清单、日志和网页状态输出下一步动作。
- 支持动作类型：click、input、scroll、navigate、back、wait、select、submit。
- 动作执行后重新读取页面，继续判断下一步。
- 完成步骤时在清单上打绿色勾。
- 所有目标完成后，任务状态变为完成，并生成报告。

### 2.4 网页读取与操作能力
- 读取页面标题、URL、正文文本、选中文本、视口信息、滚动位置。
- 读取按钮、链接、输入框、textarea、select、role button/link、contenteditable、summary、label。
- 每个元素需要包含 selector、文字、placeholder、name、value、href、可见性、坐标和尺寸。
- 优先使用 selector 操作元素。
- selector 失败时允许根据文字、aria-label、placeholder、value 查找。
- 输入框填值需要兼容 React / Vue 这类监听 input/change 的页面。
- 点击需要模拟 pointer / mouse / click 事件，PointerEvent 不存在时要 fallback。

### 2.5 任务 UI
- 每个标签页右下角有 Agent 按钮。
- 当前页可以快速创建任务。
- 有全局任务管理页，可以查看所有标签页任务。
- 每个任务卡片显示：网页缩略图、标签名、状态、进度条、当前动作、目标清单、绿色勾、日志、报告。
- 支持复制任务日志。
- iPad 横屏要有侧边栏 + 浏览器 + 右侧任务/设置面板。
- 窄屏设备要有底部 Dock，避免固定侧边栏挤爆布局。

### 2.6 设置页
- 用户自己输入 API Key。
- API Key 存入 Keychain。
- 支持 Base URL 输入。
- 预设常用 OpenAI-compatible Base URL。
- 支持模型输入。
- 支持刷新模型列表。
- 支持测试连接。
- 支持 Temperature、最大循环次数、请求超时、JSON Mode、敏感操作确认开关。

### 2.7 Liquid Glass / iOS 27 UI
- UI 风格要接近 iOS 27 / Liquid Glass：半透明、模糊、圆角、漂浮面板、深色背景。
- 新系统可使用 glassEffect。
- 旧系统或旧 Xcode 需要 fallback 到 ultraThinMaterial，避免直接编译失败。

### 2.8 安全限制
- 付款、下单、购买、删除账号、发送消息等敏感操作必须拦截并等待用户确认。
- 登录、验证码、权限弹窗、付款等 AI 无法可靠处理时，应暂停并提示用户手动处理。
- 任务不能在 iOS 后台长期保证运行；用户切到后台或锁屏后，系统可能挂起。

## 3. 当前架构

- LiquidAIBrowserApp.swift：App 入口。
- BrowserStore.swift：全局状态，管理标签页、任务、设置、WebViewPool、AgentEngine。
- BrowserModels.swift：标签页、任务、清单、日志、API preset、AI action/decision 数据模型。
- WebViewPool.swift：WKWebView 池、网页加载、JS 注入、DOM 状态读取、动作执行、缩略图、JS 弹窗处理。
- AgentEngine.swift：任务循环、规划、判断、执行、敏感操作确认、完成报告。
- AIClient.swift：OpenAI-compatible chat/completions 和 models API。
- AISettings.swift：API 设置、预设、UserDefaults、Keychain。
- ContentView.swift：主 UI、侧边栏、浏览器区域、工具栏、Agent 浮动按钮、响应式布局。
- Panels.swift：新建任务、任务管理、设置、缩略图组件。
- LiquidGlassSupport.swift：Liquid Glass / 毛玻璃兼容层。

## 4. 验收测试清单

### 基础浏览器
- 新建 3 个标签页，分别打开不同网站，切换后网页不丢失。
- 搜索关键词能打开搜索结果页。
- 后退、前进、刷新、停止加载可用。
- 点击 target=_blank 链接不会无响应。
- 普通 alert / confirm / prompt 能弹出。

### Agent 任务
- 在当前标签创建“总结当前网页重点”任务，AI 应先生成清单，再执行，最后完成并出报告。
- 在搜索页创建“点击下一页/更多结果”任务，AI 应读取元素并点击。
- 在输入框页面创建“输入 xxx 并搜索”任务，React/Vue 页面也应能触发输入事件。
- 暂停任务后，任务不继续执行；继续后恢复。
- 停止任务后，不再执行动作。
- 任务完成后进度 100%，所有清单显示绿色勾。

### 多标签任务
- Tab 1 和 Tab 2 分别创建任务，App 前台时两者都能继续推进。
- 当前显示 Tab 1 时，Tab 2 的任务卡仍能更新状态和日志。
- 关闭某个标签时，该标签未完成任务被标记停止。
- 同一个标签页已有未结束任务时，不允许新建第二个任务。

### 设置/API
- 不填 API Key 创建任务时跳转设置并提示。
- API Key 保存后重启 App 仍存在。
- 清除 API Key 后不可测试连接。
- 刷新模型能返回列表或显示错误。
- Base URL 填完整 /chat/completions 时不会拼出重复路径。

### UI/兼容
- iPad 横屏：侧边栏、浏览器、右面板正常。
- iPhone/窄屏：底部 Dock 正常，不出现固定 290px 侧边栏挤压。
- iOS 27 / 新 SDK：应显示 glassEffect 玻璃效果。
- 旧 SDK：应 fallback 到 ultraThinMaterial，不因 glassEffect 编译失败。

## 5. 已知边界

- 这是 DOM Agent，不是真正系统级视觉电脑控制。
- 背景标签页可以由 App 继续调度 WKWebView 执行 JS，但网页自身渲染和定时器可能受系统优化影响。
- App 退后台或锁屏后，iOS 不保证长期继续网页自动化。
- 遇到验证码、复杂登录、支付、人机验证，需要用户手动处理。
- 某些网站阻止脚本、强 CSP、跨域 iframe 或自定义 canvas UI，DOM Agent 可能无法完整操作。

## 6. 下一阶段规划

### v1.2
- 增加任务队列，允许同一标签页排队多个任务。
- 增加“人工接管后继续”按钮说明。
- 增加失败重试次数和 action 失败分类。
- 增加更细的日志过滤和导出报告。

### v1.3
- 增加截图视觉辅助：当前可视区域截图 + 视觉模型判断元素位置。
- 增加坐标点击 fallback。
- 增加网页内容摘要缓存，减少 token 消耗。

### v1.4
- 增加会话保存/恢复。
- 增加标签组。
- 增加任务模板。
- 增加可视化 Agent 回放。

## v1.4 新增验收要求

### 分组架构
- “标签页”在 UI 上应改称“分组/页面”。
- 一个分组可包含多个网页页面。
- 一个任务归属于一个分组，而不是只能绑定单个页面。
- 一个任务可记录多个参与页面，用于跨网站对照、复制、填写。

### 多页面 Agent
- AI 可在任务执行中创建新页面：`createTab / openTab`。
- AI 可在同一分组内切换页面：`switchTab`。
- AI 可在动作里指定 `tabID` 或 `tabHint`，决定要操作哪个页面。
- 适合“从 A 网站读取内容到 B 网站填写”的工作流。

### 动作级规划
- 规划阶段必须先分析用户最终目标，输出 `goalAnalysis`。
- 每一次点击、输入、按键、滚动、切换页面、创建页面、等待和检查都应拆成独立步骤。
- 每一步执行后必须重新读取页面并检查是否完成，再勾选清单。

### 键盘能力
- 支持 `keyPress`。
- 支持 `pressEnter`。
- 支持 `pressTab`。
- 支持 `keyboardShortcut`。
- 支持 `typeText`。
- 输入时应兼容普通 input、textarea 和 contenteditable。

### 动画体验
- 分组展开、页面切换、任务面板显示/隐藏应使用非线性 spring 动画。
- 动画应轻量、丝滑，避免大面积模糊层重复重绘。
