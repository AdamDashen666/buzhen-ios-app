//
//  ProbeResult.swift
//  HTMLRunner
//
//  Typed decoding of the JSON produced by `Resources/Web/WebProbe.js`.
//
//  Every optional here corresponds to something the page may legitimately be unable
//  to report. The UI must render an absence as "无法获取"/"不支持" — never as 0 and
//  never as a guess.
//

import Foundation

struct ProbeScalar: Codable, Hashable {
    var text: String?

    init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        if container.decodeNil() {
            text = nil
        } else if let value = try? container.decode(String.self) {
            text = value
        } else if let value = try? container.decode(Int.self) {
            text = String(value)
        } else if let value = try? container.decode(Double.self) {
            text = String(value)
        } else if let value = try? container.decode(Bool.self) {
            text = value ? "true" : "false"
        } else {
            text = nil
        }
    }

    func encode(to encoder: Encoder) throws {
        var container = encoder.singleValueContainer()
        try container.encode(text)
    }
}

struct ShaderCompileReport: Codable, Hashable {
    var vertexCompiled: Bool?
    var vertexLog: String?
    var fragmentCompiled: Bool?
    var fragmentLog: String?
    var linked: Bool?
    var linkLog: String?
    var activeUniforms: Int?

    var succeeded: Bool {
        (vertexCompiled ?? false) && (fragmentCompiled ?? false) && (linked ?? false)
    }
}

struct WebGLContextReport: Codable, Hashable {
    var available: Bool
    var label: String?
    var error: String?
    var version: String?
    var shadingLanguageVersion: String?
    var vendor: String?
    var renderer: String?
    var limits: [String: ProbeScalar]?
    var extensions: [String]?
    var shaderTest: ShaderCompileReport?

    var extensionCount: Int { extensions?.count ?? 0 }

    var summaryLine: String {
        guard available else { return "不可用\(error.map { ": \($0)" } ?? "")" }
        let rendererText = renderer ?? "renderer 无法获取"
        let versionText = version ?? "版本无法获取"
        return "\(versionText) · \(rendererText)"
    }
}

struct BenchmarkReport: Codable, Hashable {
    struct Iterations: Codable, Hashable {
        var numeric: Int?
        var allocationRounds: Int?
        var allocationSize: Int?
    }

    struct Measurements: Codable, Hashable {
        var warmupMs: Double?
        var numericMs: Double?
        var numericOpsPerSecond: Double?
        var numericSink: Double?
        var allocationMs: Double?
        var allocationSink: Double?
    }

    struct Conditions: Codable, Hashable {
        var visibilityState: String?
        var pageWasHidden: Bool?
        var thermalState: String?
        var note: String?
    }

    var iterations: Iterations?
    var measurements: Measurements?
    var conditions: Conditions?
}

struct TextureStagingStep: Codable, Hashable {
    var size: Int?
    var bytes: Int?
    var allocateMs: Double?
    var error: Int?
}

struct ProbeConfidence: Codable, Hashable {
    var webglCapabilities: String?
    var webAssemblyAvailability: String?
    var dynamicCodeEvaluationAvailability: String?
    var javascriptJitState: String?
    var javascriptPerformance: String?
}

struct ProbeError: Codable, Hashable {
    var section: String
    var message: String
}

struct PerformanceMemoryReport: Codable, Hashable {
    var usedJSHeapSize: Double?
    var totalJSHeapSize: Double?
    var jsHeapSizeLimit: Double?
}

struct ProbeResult: Codable {
    var probeVersion: String?
    var startedAt: String?
    var finishedAt: String?
    var elapsedMs: Double?
    var userAgent: String?
    var location: String?
    /// The page's `location.protocol`.
    ///
    /// The Swift property cannot be named `protocol` — that is a reserved keyword and
    /// `var protocol: String?` fails to compile ("keyword 'protocol' cannot be used as
    /// an identifier here"). The JSON field produced by `WebProbe.js` *is* `protocol`,
    /// so `CodingKeys` maps between the two names.
    var pageProtocol: String?
    var isSecureContext: Bool?
    var hardwareConcurrency: Int?
    var deviceMemoryGB: Double?
    var performanceMemory: PerformanceMemoryReport?
    var limits: [String: ProbeScalar]?
    var webgl2: WebGLContextReport?
    var webgl1: WebGLContextReport?
    var benchmark: BenchmarkReport?
    var textureStaging: [TextureStagingStep]?
    var confidence: ProbeConfidence?
    var errors: [ProbeError]?

    enum CodingKeys: String, CodingKey {
        case probeVersion, startedAt, finishedAt, elapsedMs, userAgent, location
        case pageProtocol = "protocol"
        case isSecureContext, hardwareConcurrency, deviceMemoryGB, performanceMemory
        case limits, webgl2, webgl1, benchmark, textureStaging, confidence, errors
    }

    // MARK: Convenience accessors used by the diagnostics UI

    var webAssemblyAvailable: Bool? {
        guard let raw = limits?["webAssembly"]?.text else { return nil }
        return raw == "true"
    }

    var webAssemblyModuleValid: Bool? {
        guard let raw = limits?["webAssemblyModuleValid"]?.text else { return nil }
        return raw == "true"
    }

    var newFunctionSupported: Bool? {
        guard let raw = limits?["newFunctionSupported"]?.text else { return nil }
        return raw == "true"
    }

    var numericOpsPerSecond: Double? { benchmark?.measurements?.numericOpsPerSecond }

    static func decode(fromJSONString string: String) throws -> ProbeResult {
        guard let data = string.data(using: .utf8) else {
            throw NSError(domain: "ProbeResult", code: 1,
                          userInfo: [NSLocalizedDescriptionKey: "探测结果不是有效的 UTF-8"])
        }
        return try JSONDecoder().decode(ProbeResult.self, from: data)
    }
}

/// One row in the diagnostics table. Keeps the view code free of formatting logic
/// and, more importantly, keeps "unknown" visibly distinct from "zero".
struct DiagnosticRow: Identifiable, Hashable {
    enum Value: Hashable {
        case text(String)
        case unknown(String)
        indirect case measured(String, note: String)
    }

    let id = UUID()
    var group: String
    var label: String
    var value: Value

    var displayValue: String {
        switch value {
        case .text(let text): return text
        case .unknown(let reason): return "无法获取（\(reason)）"
        case .measured(let text, _): return text
        }
    }

    var note: String? {
        if case .measured(_, let note) = value { return note }
        return nil
    }
}
