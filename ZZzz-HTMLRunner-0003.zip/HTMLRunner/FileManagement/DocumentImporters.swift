//
//  DocumentImporters.swift
//  HTMLRunner
//
//  SwiftUI wrappers around `UIDocumentPickerViewController`, plus a diagnostic
//  implementation of `UIDocumentPickerDelegate` that reports which delegate callback
//  actually fired.
//
//  Why the delegate reports callbacks
//  ----------------------------------
//  A picker that appears to "do nothing" is ambiguous: the delegate may never fire,
//  the chosen URL may be unreadable, or the copy may fail silently. Those need
//  different fixes, so every callback, the resolved URL and its security-scope result
//  are written to the diagnostic log. Without that, a silent picker is unguessable.
//
//  Design choices worth keeping
//  ---------------------------
//  1. `asCopy: false` for projects. Letting the picker copy would hide the progress,
//     make cancellation impossible, and discard the source layout; copying ourselves
//     (see `ProjectStore`) is what makes a multi-gigabyte import watchable.
//  2. **Content types are asked for two ways.** `UTType(filenameExtension:)` can
//     return nil for extensions the system does not know, and an empty type list
//     makes the picker refuse to hand anything back. The picker therefore always
//     includes a permissive fallback (`UTType.item`), so a file is never greyed out
//     or silently unselectable because of a type-table gap. Validation happens after
//     the fact, on the file's extension, where it can produce a real error message.
//  3. A folder picker additionally accepts `.folder`, and the import path no longer
//     *depends* on the picker at all — see "从共享目录导入" in the project list, which
//     reads folders the user copied into the app's own Documents directory.
//

import SwiftUI
import UniformTypeIdentifiers

// MARK: - Diagnostics

enum ImportPickerDiagnostics {
    /// Set by the picker wrappers so the log can show which picker was presented.
    /// Read by `RootView` when reporting a selection.
    static let filePickerTag = "file"
    static let folderPickerTag = "folder"
}

// MARK: - Shared coordinator

/// One delegate implementation used by both pickers, so the callback behaviour cannot
/// drift between them.
final class DocumentPickerCoordinator: NSObject, UIDocumentPickerDelegate {

    private let tag: String
    private let onPick: ([URL]) -> Void
    private let onCancel: () -> Void
    private let log: (String, String) -> Void

    init(tag: String,
         onPick: @escaping ([URL]) -> Void,
         onCancel: @escaping () -> Void,
         log: @escaping (String, String) -> Void) {
        self.tag = tag
        self.onPick = onPick
        self.onCancel = onCancel
        self.log = log
    }

    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        log("picker.\(tag).didPick", "收到 \(urls.count) 个 URL")
        for url in urls {
            let reachable = (try? url.checkResourceIsReachable()) ?? false
            let isDirectory = (try? url.resourceValues(forKeys: [.isDirectoryKey]).isDirectory) ?? false
            log("picker.\(tag).didPick", "URL=\(url.lastPathComponent)", metadata: [
                "scheme": url.scheme ?? "nil",
                "isDirectory": "\(isDirectory)",
                "reachable": "\(reachable)",
                "isFileURL": "\(url.isFileURL)"
            ])
        }
        onPick(urls)
    }

    func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
        log("picker.\(tag).cancelled", "用户取消")
        onCancel()
    }

    // iOS 14+ "open in place" flow; not used by the app's own import path, but if the
    // system ever calls it, the log will say so instead of the UI looking frozen.
    func documentPicker(_ controller: UIDocumentPickerViewController,
                        didPickDocumentAt url: URL) {
        log("picker.\(tag).didPickDocumentAt", "旧版回调，URL=\(url.lastPathComponent)")
        onPick([url])
    }
}

// MARK: - HTML file importer

struct HTMLFileImporter: UIViewControllerRepresentable {

    var onPick: ([URL]) -> Void
    var onCancel: () -> Void
    var log: (String, String, [String: String]) -> Void = { _, _, _ in }

    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        let types = Self.acceptableTypes()
        let picker = UIDocumentPickerViewController(forOpeningContentTypes: types, asCopy: false)
        picker.allowsMultipleSelection = false
        picker.shouldShowFileExtensions = true
        picker.delegate = context.coordinator
        return picker
    }

    func updateUIViewController(_ uiViewController: UIDocumentPickerViewController, context: Context) {}

    func makeCoordinator() -> DocumentPickerCoordinator {
        DocumentPickerCoordinator(
            tag: ImportPickerDiagnostics.filePickerTag,
            onPick: onPick,
            onCancel: onCancel,
            log: { event, message in log(event, message, [:]) })
    }

    /// A *permissive* list on purpose.
    ///
    /// `UTType(filenameExtension: "html")` yields `public.html` on a normal system,
    /// but a type-table gap would return nil; an empty list makes the picker hand
    /// nothing back and the UI look broken. Known HTML types are listed first so they
    /// sort to the top, with `UTType.item` last so every file remains selectable.
    /// The real validation is the extension check the importer performs afterwards.
    static func acceptableTypes() -> [UTType] {
        var types: [UTType] = []
        if let html = UTType(filenameExtension: "html") { types.append(html) }
        if let htm = UTType(filenameExtension: "htm") { types.append(htm) }
        if !types.contains(.html) { types.append(.html) }
        if !types.contains(.text) { types.append(.text) }
        if !types.contains(.data) { types.append(.data) }
        if !types.contains(.item) { types.append(.item) }
        return types
    }
}

// MARK: - Folder importer

struct FolderImporter: UIViewControllerRepresentable {

    var onPick: ([URL]) -> Void
    var onCancel: () -> Void
    var log: (String, String, [String: String]) -> Void = { _, _, _ in }

    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        // `.folder` is the correct content type for a directory. `.item` is appended
        // so that a provider which reports a directory with an unexpected type still
        // lets the user pick it; the importer re-checks `isDirectory` afterwards.
        var types: [UTType] = [.folder, .directory]
        types.append(.item)

        let picker = UIDocumentPickerViewController(forOpeningContentTypes: types, asCopy: false)
        picker.allowsMultipleSelection = false
        picker.delegate = context.coordinator
        return picker
    }

    func updateUIViewController(_ uiViewController: UIDocumentPickerViewController, context: Context) {}

    func makeCoordinator() -> DocumentPickerCoordinator {
        DocumentPickerCoordinator(
            tag: ImportPickerDiagnostics.folderPickerTag,
            onPick: onPick,
            onCancel: onCancel,
            log: { event, message in log(event, message, [:]) })
    }
}

// MARK: - Plain text share sheet (log export, diagnostic report)

struct ShareSheet: UIViewControllerRepresentable {

    var items: [Any]

    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: items, applicationActivities: nil)
    }

    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}
