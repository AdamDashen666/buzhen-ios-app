//
//  RootView.swift
//  HTMLRunner
//
//  iPad-first layout. `NavigationSplitView` is used because the target device is an
//  11" iPad that is usually held in landscape: a split layout gives the project list
//  a permanent sidebar instead of a stretched iPhone list, and the detail pane is
//  where the WebView lives.
//
//  The run screen deliberately has no navigation chrome: the game gets the whole
//  display, and a toolbar is summoned with a tap (see `RunView`).
//

import SwiftUI

struct RootView: View {

    @EnvironmentObject private var appState: AppState
    @State private var columnVisibility: NavigationSplitViewVisibility = .all
    @State private var sidebarSelection: SidebarItem? = .projects

    enum SidebarItem: Hashable {
        case projects
        case diagnostics
        case settings
    }

    var body: some View {
        NavigationSplitView(columnVisibility: $columnVisibility) {
            sidebar
                .navigationTitle("HTMLRunner")
                .navigationBarTitleDisplayMode(.inline)
        } detail: {
            detail
        }
        .navigationSplitViewStyle(.balanced)
        .sheet(isPresented: $appState.showingImporter) {
            HTMLFileImporter(
                onPick: { urls in
                    Task { await handlePickedFiles(urls) }
                },
                onCancel: {
                    appState.log.info(LogEvent.importCancelled, "用户取消了文件选择")
                },
                log: { event, message, metadata in
                    // The picker's callbacks are logged so a picker that appears to do
                    // nothing can be diagnosed from the log instead of guessed at.
                    appState.log.info(event, message, metadata: metadata)
                })
        }
        .sheet(isPresented: $appState.showingFolderImporter) {
            FolderImporter(
                onPick: { urls in
                    Task { await handlePickedFolders(urls) }
                },
                onCancel: {
                    appState.log.info(LogEvent.importCancelled, "用户取消了文件夹选择")
                },
                log: { event, message, metadata in
                    appState.log.info(event, message, metadata: metadata)
                })
        }
        .sheet(isPresented: $appState.showingLogViewer) {
            NavigationStack {
                LogViewerView()
                    .toolbar {
                        ToolbarItem(placement: .cancellationAction) {
                            Button("关闭") { appState.showingLogViewer = false }
                        }
                    }
            }
        }
        .overlay(alignment: .top) {
            BannerOverlay()
        }
    }

    // MARK: Sidebar

    private var sidebar: some View {
        List(selection: $sidebarSelection) {
            Section("库") {
                Label("项目", systemImage: "square.stack.3d.up")
                    .tag(SidebarItem.projects)
            }
            Section("工具") {
                Label("诊断", systemImage: "stethoscope")
                    .tag(SidebarItem.diagnostics)
                Label("设置", systemImage: "gearshape")
                    .tag(SidebarItem.settings)
            }
        }
        .listStyle(.sidebar)
        .safeAreaInset(edge: .bottom) {
            VStack(alignment: .leading, spacing: 6) {
                Text(AppInfo.versionDescription)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                Text("已导入 \(appState.projects.projects.count) 个项目")
                    .font(.caption2)
                    .foregroundStyle(.tertiary)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.horizontal, 16)
            .padding(.vertical, 10)
        }
    }

    // MARK: Detail

    @ViewBuilder
    private var detail: some View {
        switch sidebarSelection {
        case .projects:
            if let id = appState.activeProjectID,
               let project = appState.projects.project(withID: id),
               case .run = appState.route {
                RunView(project: project)
            } else {
                ProjectListView()
            }
        case .diagnostics:
            DiagnosticsView()
        case .settings:
            SettingsView()
        case nil:
            ContentUnavailableView("选择一个项目",
                                   systemImage: "hand.tap",
                                   description: Text("从左侧选择项目、诊断或设置。"))
        }
    }

    // MARK: Import handling

    private func handlePickedFiles(_ urls: [URL]) async {
        guard let url = urls.first else {
            appState.log.warning(LogEvent.importFailed, "文件选择器返回了空结果")
            return
        }
        // A directory handed to the *file* picker is a real possibility (some providers
        // ignore the content-type filter). Import it as a project instead of failing.
        let isDirectory = (try? url.resourceValues(forKeys: [.isDirectoryKey]).isDirectory) ?? false
        if isDirectory {
            appState.log.notice(LogEvent.importStarted, "文件选择器返回的是文件夹，按项目文件夹导入")
            await handlePickedFolders([url])
            return
        }

        let name = url.deletingPathExtension().lastPathComponent
        appState.log.info(LogEvent.importStarted, "开始导入所选文件", metadata: [
            "file": url.lastPathComponent,
            "extension": url.pathExtension.lowercased()
        ])
        do {
            let project = try await appState.projects.importHTMLFile(at: url, suggestedName: name)
            appState.handleImportedProject(project, fromFolder: false)
        } catch {
            appState.handleImportFailure(error)
        }
    }

    private func handlePickedFolders(_ urls: [URL]) async {
        guard let url = urls.first else {
            appState.log.warning(LogEvent.importFailed, "文件夹选择器返回了空结果")
            return
        }
        let name = url.lastPathComponent.isEmpty
            ? url.deletingPathExtension().lastPathComponent
            : url.lastPathComponent
        appState.log.info(LogEvent.importStarted, "开始导入所选文件夹", metadata: ["folder": name])
        do {
            let project = try await appState.projects.importFolder(at: url, suggestedName: name)
            appState.handleImportedProject(project, fromFolder: true)
        } catch {
            appState.handleImportFailure(error)
        }
    }
}

// MARK: - Banner

struct BannerOverlay: View {

    @EnvironmentObject private var appState: AppState

    var body: some View {
        if let banner = appState.banner {
            HStack(alignment: .top, spacing: 12) {
                Image(systemName: symbol(for: banner.kind))
                    .font(.title3)
                    .foregroundStyle(color(for: banner.kind))
                VStack(alignment: .leading, spacing: 4) {
                    Text(banner.title).font(.headline)
                    Text(banner.message)
                        .font(.callout)
                        .foregroundStyle(.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                }
                Spacer(minLength: 8)
                Button {
                    appState.banner = nil
                } label: {
                    Image(systemName: "xmark.circle.fill")
                        .foregroundStyle(.secondary)
                }
                .buttonStyle(.plain)
            }
            .padding(16)
            .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .strokeBorder(color(for: banner.kind).opacity(0.35), lineWidth: 1)
            )
            .shadow(radius: 12, y: 4)
            .padding(.horizontal, 20)
            .padding(.top, 12)
            .frame(maxWidth: 720)
            .transition(.move(edge: .top).combined(with: .opacity))
            .onTapGesture { appState.banner = nil }
        }
    }

    private func symbol(for kind: AppState.Banner.Kind) -> String {
        switch kind {
        case .info: return "info.circle.fill"
        case .success: return "checkmark.circle.fill"
        case .warning: return "exclamationmark.triangle.fill"
        case .error: return "xmark.octagon.fill"
        }
    }

    private func color(for kind: AppState.Banner.Kind) -> Color {
        switch kind {
        case .info: return .blue
        case .success: return .green
        case .warning: return .orange
        case .error: return .red
        }
    }
}
