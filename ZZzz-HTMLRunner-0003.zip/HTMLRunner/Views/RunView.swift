//
//  RunView.swift
//  HTMLRunner
//
//  The immersive run screen.
//
//  Layout rules that matter for a game:
//   * The WebView fills the entire window, edge to edge, ignoring the safe area, so
//     a WebGL canvas is never letterboxed by the app.
//   * No navigation bar is shown by default. A tap anywhere summons a lightweight
//     toolbar overlay; tapping the game again dismisses it. The toolbar is an
//     overlay, never a layout participant, so showing it cannot resize the canvas
//     and force the page to re-layout mid-game.
//   * The performance overlay is opt-in and lives *inside* the page (small, in the
//     corner) rather than being a native panel covering the game.
//

import SwiftUI
import WebKit

struct RunView: View {

    let project: Project

    @EnvironmentObject private var appState: AppState
    @EnvironmentObject private var log: DiagnosticLogStore
    @EnvironmentObject private var settings: AppSettings

    @State private var toolbarVisible = false
    @State private var showingProjectPicker = false
    @State private var showingSettingsSheet = false

    private var coordinator: WebViewCoordinator? { appState.coordinator }

    var body: some View {
        ZStack(alignment: .top) {
            Color.black.ignoresSafeArea()

            if let coordinator {
                WebViewContainer(coordinator: coordinator)
                    .ignoresSafeArea()
                    .onTapGesture {
                        withAnimation(.easeOut(duration: 0.15)) {
                            toolbarVisible.toggle()
                        }
                    }
            } else {
                ProgressView("正在准备运行环境…")
                    .tint(.white)
                    .foregroundStyle(.white)
            }

            if let coordinator, shouldShowStatusCard(for: coordinator) {
                statusCard(for: coordinator)
                    .padding(.horizontal, 20)
                    .padding(.top, 20)
                    .frame(maxWidth: 620)
                    .transition(.opacity)
            }

            if appState.isPreparingRun {
                ProgressView("正在启动本地服务…")
                    .padding(12)
                    .background(.regularMaterial, in: Capsule())
                    .padding(.top, 8)
            }
        }
        .overlay(alignment: .top) {
            if toolbarVisible {
                RunToolbar(
                    project: project,
                    onReload: { coordinator?.reload(userInitiated: true) },
                    onStop: { coordinator?.stopLoading() },
                    onRestore: { coordinator?.restoreAfterTermination() },
                    onClose: { appState.closeRun() },
                    onLogs: { appState.showingLogViewer = true },
                    onDiagnostics: {
                        toolbarVisible = false
                        appState.route = .diagnostics
                    },
                    onSettings: { showingSettingsSheet = true },
                    onProbe: { runProbe() },
                    onHideToolbar: {
                        withAnimation(.easeOut(duration: 0.15)) { toolbarVisible = false }
                    },
                    probeEnabled: !(coordinator?.isProbing ?? true)
                )
                .padding(.horizontal, 16)
                .padding(.top, 12)
                .transition(.move(edge: .top).combined(with: .opacity))
            }
        }
        .overlay(alignment: .bottomTrailing) {
            if coordinator?.lastProbe != nil {
                probeBadge
                    .padding(16)
            }
        }
        .navigationBarBackButtonHidden(true)
        .toolbar(.hidden, for: .navigationBar)
        .statusBarHidden(!toolbarVisible)
        .persistentSystemOverlays(.hidden)
        .sheet(isPresented: $showingSettingsSheet) {
            NavigationStack {
                SettingsView()
                    .toolbar {
                        ToolbarItem(placement: .cancellationAction) {
                            Button("关闭") { showingSettingsSheet = false }
                        }
                    }
            }
        }
    }

    // MARK: Status card

    private func shouldShowStatusCard(for coordinator: WebViewCoordinator) -> Bool {
        switch coordinator.phase {
        case .failed, .terminated: return true
        default: return coordinator.suspendedWarning != nil
        }
    }

    private func statusCard(for coordinator: WebViewCoordinator) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            Label(title(for: coordinator), systemImage: symbol(for: coordinator))
                .font(.headline)
                .foregroundStyle(.white)

            Text(message(for: coordinator))
                .font(.callout)
                .foregroundStyle(.white.opacity(0.85))
                .fixedSize(horizontal: false, vertical: true)

            HStack(spacing: 10) {
                if case .terminated = coordinator.phase {
                    Button("重新加载（状态会丢失）") {
                        coordinator.restoreAfterTermination()
                    }
                    .buttonStyle(.borderedProminent)
                } else {
                    Button("重新加载") {
                        coordinator.reload(userInitiated: true)
                    }
                    .buttonStyle(.borderedProminent)
                }
                Button("查看日志") { appState.showingLogViewer = true }
                    .buttonStyle(.bordered)
                Button("返回项目") { appState.closeRun() }
                    .buttonStyle(.bordered)
            }
            .tint(.white)
        }
        .padding(18)
        .background(.black.opacity(0.72), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 16, style: .continuous)
                .strokeBorder(.white.opacity(0.18), lineWidth: 1)
        )
    }

    private func title(for coordinator: WebViewCoordinator) -> String {
        switch coordinator.phase {
        case .failed: return "页面加载失败"
        case .terminated: return "网页进程被系统终止"
        default: return "页面可能没有正常工作"
        }
    }

    private func symbol(for coordinator: WebViewCoordinator) -> String {
        switch coordinator.phase {
        case .failed: return "exclamationmark.triangle.fill"
        case .terminated: return "memorychip"
        default: return "questionmark.circle"
        }
    }

    private func message(for coordinator: WebViewCoordinator) -> String {
        switch coordinator.phase {
        case .failed(let description):
            return "\(description)\n\n提示：这通常是入口文件路径、资源缺失或本地服务未启动导致的。日志中记录了失败时的 URL 与 WebKit 错误码。"
        case .terminated:
            return "iOS 回收了 WKWebView 的 WebContent 进程，App 无法得知具体原因（系统不提供）。重新加载可以恢复，但页面内部的进度、场景状态不会保留。\n\n已发生 \(coordinator.terminationCount) 次。如反复出现，建议降低贴图分辨率或分批加载资源，并查看日志中的内存采样。"
        default:
            return coordinator.suspendedWarning ?? ""
        }
    }

    // MARK: Probe badge

    private var probeBadge: some View {
        VStack(alignment: .trailing, spacing: 2) {
            if let probe = coordinator?.lastProbe {
                Text("WebGL2: \(probe.webgl2?.available == true ? "可用" : "不可用")")
                Text("WASM: \(probe.webAssemblyAvailable.map { $0 ? "可用" : "不可用" } ?? "未知")")
                if let ops = probe.numericOpsPerSecond {
                    Text("numeric: \(Int(ops / 1000)) k ops/s")
                }
            }
            Text("点击工具栏「探测」重新测量")
                .font(.caption2)
                .foregroundStyle(.tertiary)
        }
        .font(.caption.monospacedDigit())
        .padding(8)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 10, style: .continuous))
    }

    private func runProbe() {
        guard let coordinator else { return }
        coordinator.runProbe(includeLargeTexture: false) { _ in }
    }
}

// MARK: - WebView bridge

/// Hosts the coordinator's single WKWebView. `updateUIView` intentionally does
/// nothing to the web view: recreating or re-configuring it here would destroy the
/// WebGL context and every decoded asset on any unrelated SwiftUI state change.
struct WebViewContainer: UIViewRepresentable {

    let coordinator: WebViewCoordinator

    func makeUIView(context: Context) -> WKWebView {
        coordinator.webView
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {
        // No-op by design. See the type comment.
    }

    // NOTE: `dismantleUIView(_:coordinator:)` is deliberately NOT implemented.
    // Declaring it here made the type fail to conform to `UIViewRepresentable`
    // ("type 'WebViewContainer' does not conform to protocol 'UIViewRepresentable'")
    // because the required signature for a `UIViewRepresentable` whose
    // `UIViewType` is `WKWebView` cannot be satisfied by a static method taking the
    // coordinator wrapper as the non-optional second parameter in this SDK. There is
    // nothing to clean up anyway: the coordinator owns the web view's lifetime and
    // may hand the same instance to the next run.
}

// MARK: - Toolbar

struct RunToolbar: View {

    let project: Project
    var onReload: () -> Void
    var onStop: () -> Void
    var onRestore: () -> Void
    var onClose: () -> Void
    var onLogs: () -> Void
    var onDiagnostics: () -> Void
    var onSettings: () -> Void
    var onProbe: () -> Void
    var onHideToolbar: () -> Void
    var probeEnabled: Bool

    @EnvironmentObject private var appState: AppState

    var body: some View {
        HStack(spacing: 6) {
            Button {
                onClose()
            } label: {
                Label("项目", systemImage: "chevron.left")
            }
            .help("返回项目列表")

            Divider().frame(height: 20)

            Button {
                onReload()
            } label: {
                Label("刷新", systemImage: "arrow.clockwise")
            }

            Button {
                onStop()
            } label: {
                Label("停止", systemImage: "stop.fill")
            }

            Button {
                onRestore()
            } label: {
                Label("重新打开", systemImage: "arrow.counterclockwise.circle")
            }

            Divider().frame(height: 20)

            Button {
                onProbe()
            } label: {
                Label("探测", systemImage: "speedometer")
            }
            .disabled(!probeEnabled)

            Button {
                onLogs()
            } label: {
                Label("日志", systemImage: "text.alignleft")
            }

            Button {
                onDiagnostics()
            } label: {
                Label("诊断", systemImage: "stethoscope")
            }

            Button {
                onSettings()
            } label: {
                Label("设置", systemImage: "gearshape")
            }

            Divider().frame(height: 20)

            Text(project.name)
                .font(.caption)
                .foregroundStyle(.secondary)
                .lineLimit(1)
                .frame(maxWidth: 160)

            Button {
                onHideToolbar()
            } label: {
                Image(systemName: "eye.slash")
            }
            .help("隐藏工具栏")
        }
        .labelStyle(.iconOnly)
        .buttonStyle(.bordered)
        .controlSize(.regular)
        .padding(.horizontal, 12)
        .padding(.vertical, 8)
        .background(.regularMaterial, in: Capsule())
        .overlay(Capsule().strokeBorder(.white.opacity(0.12), lineWidth: 1))
        .shadow(radius: 12, y: 4)
    }
}
