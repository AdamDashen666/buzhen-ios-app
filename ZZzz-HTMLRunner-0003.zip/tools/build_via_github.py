#!/usr/bin/env python3
"""Build the iOS app on GitHub's macOS runners and fetch the resulting IPA.

This is the "no Mac available" build path. It drives an existing GitHub Actions
workflow (`run-ipa-builder-newest.yml`) in the user's repository:

    upload a source ZIP to the repo root  ->  the workflow builds an UNSIGNED IPA
    ->  download the artifact  ->  verify it  ->  place it in dist/

Design notes that matter:

  * The workflow selects the LEXICOGRAPHICALLY LAST root-level `*.zip`
    (`find . -maxdepth 1 -name "*.zip" | sort -V | tail -n 1`). A name that sorts
    before the zips already in the repository is silently ignored and the wrong
    project gets built. `--zip-name` therefore defaults to a name that sorts last,
    and `check_name_order()` proves it against the live directory listing.
  * Artifacts are never publicly downloadable, so a token is required for both the
    upload and the download. The token is read from the environment only and is
    never written to a file.
  * The downloaded artifact is a ZIP containing the IPA, not the IPA itself. It is
    unwrapped and then verified with `mac/verify_ipa.sh` when a POSIX shell is
    available (that script is bash, so it runs under Git Bash on Windows too).
  * Nothing is fabricated: if the build fails, the workflow log is printed and no
    IPA is produced.

Usage
-----
    export HTMLRUNNER_GH_TOKEN=github_pat_...
    python tools/build_via_github.py --owner AdamDashen666 --repo buzhen-ios-app

    --watch-only   skip the upload and attach to whatever run is newest
    --no-upload    poll an already-triggered run
"""
from __future__ import annotations

import argparse
import base64
import hashlib
import json
import os
import pathlib
import shutil
import subprocess
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import zipfile

ROOT = pathlib.Path(__file__).resolve().parent.parent
DIST = ROOT / "dist"
API = "https://api.github.com"
WORKFLOW_FILE = "run-ipa-builder-newest.yml"
DEFAULT_ZIP_NAME = "ZZzz-HTMLRunner-0003.zip"


def reconfigure_streams() -> None:
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except (AttributeError, ValueError):
            pass


class GitHub:
    def __init__(self, token: str) -> None:
        self.token = token

    def request(self, method: str, path: str, body: dict | None = None, raw: bool = False,
                attempts: int = 4):
        """Performs an API call with retries for transient network failures.

        Large responses (the base64 body of a multi-hundred-kilobyte file) can be cut
        short mid-read; `http.client.IncompleteRead` is a transport hiccup, not an API
        error, so it is retried rather than surfaced. Real HTTP errors are not retried.
        """
        url = path if path.startswith("http") else f"{API}{path}"
        data = json.dumps(body).encode() if body is not None else None
        last_error: Exception | None = None
        for attempt in range(1, attempts + 1):
            request = urllib.request.Request(url, data=data, method=method)
            request.add_header("Authorization", f"Bearer {self.token}")
            request.add_header("Accept", "application/vnd.github+json")
            request.add_header("X-GitHub-Api-Version", "2022-11-28")
            if data is not None:
                request.add_header("Content-Type", "application/json")
            try:
                with urllib.request.urlopen(request, timeout=180) as response:
                    payload = response.read()
                return payload if raw else (json.loads(payload.decode("utf-8")) if payload else {})
            except urllib.error.HTTPError as error:
                detail = error.read().decode("utf-8", "replace")[:400]
                raise RuntimeError(f"HTTP {error.code} {method} {path}: {detail}") from None
            except Exception as error:  # noqa: BLE001 - transport-level, retry
                last_error = error
                if attempt < attempts:
                    print(f"[build] 网络错误（第 {attempt} 次），重试: {type(error).__name__}: {error}")
                    time.sleep(2 * attempt)
        raise RuntimeError(f"{method} {path} 在 {attempts} 次尝试后失败: {last_error}")

    # --- convenience wrappers -------------------------------------------------
    def whoami(self) -> dict:
        return self.request("GET", "/user")

    def repo(self, owner: str, name: str) -> dict:
        return self.request("GET", f"/repos/{owner}/{name}")

    def contents(self, owner: str, name: str) -> list[dict]:
        return self.request("GET", f"/repos/{owner}/{name}/contents/")

    def put_file(self, owner: str, name: str, path: str, data: bytes, message: str) -> dict:
        body = {
            "message": message,
            "content": base64.b64encode(data).decode("ascii"),
            "branch": "main",
        }
        try:
            existing = self.request("GET", f"/repos/{owner}/{name}/contents/{urllib.parse.quote(path)}")
            if isinstance(existing, dict) and "sha" in existing:
                body["sha"] = existing["sha"]
        except RuntimeError:
            pass  # clean create
        return self.request("PUT", f"/repos/{owner}/{name}/contents/{urllib.parse.quote(path)}", body)

    def delete_file(self, owner: str, name: str, path: str, message: str) -> bool:
        """Deletes a file from the default branch. Returns False when it is absent."""
        try:
            existing = self.request("GET", f"/repos/{owner}/{name}/contents/{urllib.parse.quote(path)}")
        except RuntimeError:
            return False
        if not isinstance(existing, dict) or "sha" not in existing:
            return False
        self.request("DELETE", f"/repos/{owner}/{name}/contents/{urllib.parse.quote(path)}",
                     {"message": message, "sha": existing["sha"], "branch": "main"})
        return True

    def runs(self, owner: str, name: str, limit: int = 10) -> list[dict]:
        data = self.request(
            "GET",
            f"/repos/{owner}/{name}/actions/workflows/{WORKFLOW_FILE}/runs?per_page={limit}")
        return data.get("workflow_runs", [])

    def run(self, owner: str, name: str, run_id: int) -> dict:
        return self.request("GET", f"/repos/{owner}/{name}/actions/runs/{run_id}")

    def jobs(self, owner: str, name: str, run_id: int) -> list[dict]:
        return self.request("GET", f"/repos/{owner}/{name}/actions/runs/{run_id}/jobs").get("jobs", [])

    def artifacts(self, owner: str, name: str, run_id: int) -> list[dict]:
        return self.request(
            "GET", f"/repos/{owner}/{name}/actions/runs/{run_id}/artifacts").get("artifacts", [])

    def download_artifact(self, owner: str, name: str, artifact_id: int) -> bytes:
        """Downloads an artifact zip, following GitHub's redirect to blob storage.

        `GET /actions/artifacts/{id}/zip` answers 302 to a signed Azure Blob URL. The
        Authorization header must NOT be forwarded there — Azure rejects a GitHub
        bearer token with `InvalidAuthenticationInfo`. urllib follows redirects while
        KEEPING the headers, so the redirect is handled manually and the second
        request carries no credentials. (Missing this made a successful build look
        like an authentication failure.)
        """
        class NoRedirect(urllib.request.HTTPRedirectHandler):
            def redirect_request(self, req, fp, code, msg, headers, newurl):  # noqa: D102
                return None

        opener = urllib.request.build_opener(NoRedirect)
        request = urllib.request.Request(
            f"{API}/repos/{owner}/{name}/actions/artifacts/{artifact_id}/zip")
        request.add_header("Authorization", f"Bearer {self.token}")
        request.add_header("Accept", "application/vnd.github+json")
        request.add_header("X-GitHub-Api-Version", "2022-11-28")
        try:
            with opener.open(request, timeout=300) as response:
                return response.read()
        except urllib.error.HTTPError as error:
            if error.code not in (301, 302, 303, 307, 308):
                raise RuntimeError(f"HTTP {error.code} 下载 artifact 失败: "
                                   f"{error.read().decode('utf-8', 'replace')[:300]}") from None
            location = error.headers.get("Location")
        if not location:
            raise RuntimeError("artifact 重定向没有 Location 头")
        # Fetch the signed URL WITHOUT the GitHub credentials.
        with urllib.request.urlopen(urllib.request.Request(location), timeout=600) as response:
            return response.read()


def find_workflow_runs(gh: GitHub, owner: str, repo: str) -> list[dict]:
    return gh.runs(owner, repo)


def wait_for_run(gh: GitHub, owner: str, repo: str, run_id: int | None, timeout_s: int = 45 * 60) -> dict:
    """Blocks until the workflow run reaches a terminal state."""
    deadline = time.time() + timeout_s
    last_line = ""
    while time.time() < deadline:
        if run_id is None:
            runs = gh.runs(owner, repo, limit=5)
            if not runs:
                time.sleep(10)
                continue
            run_id = runs[0]["id"]
        run = gh.run(owner, repo, run_id)
        line = f"#{run['run_number']} status={run['status']} conclusion={run.get('conclusion')}"
        if line != last_line:
            print(f"[build] {line}  {run['html_url']}", flush=True)
            last_line = line
        if run["status"] == "completed":
            return run
        time.sleep(20)
    raise TimeoutError(f"run {run_id} did not finish within {timeout_s}s")


def print_failed_job_log(gh: GitHub, owner: str, repo: str, run_id: int) -> None:
    for job in gh.jobs(owner, repo, run_id):
        print(f"[build] job '{job['name']}' -> {job.get('conclusion')}")
        for step in job.get("steps", []):
            marker = "  " if step.get("conclusion") == "success" else "! "
            print(f"[build] {marker}{step['name']}: {step.get('conclusion')}")


def extract_ipa(artifact_zip: bytes, destination: pathlib.Path) -> pathlib.Path:
    """The uploaded artifact is a ZIP that contains the .ipa (and its .sha256)."""
    with zipfile.ZipFile(__import__("io").BytesIO(artifact_zip)) as archive:
        names = archive.namelist()
        print(f"[build] artifact contains: {names}")
        ipa_names = [n for n in names if n.lower().endswith(".ipa")]
        if not ipa_names:
            raise RuntimeError(f"artifact has no .ipa (contains {names})")
        target = ipa_names[0]
        destination.parent.mkdir(parents=True, exist_ok=True)
        with archive.open(target) as source, destination.open("wb") as sink:
            shutil.copyfileobj(source, sink)
        return destination


def main() -> int:
    reconfigure_streams()
    parser = argparse.ArgumentParser(description="在 GitHub macOS runner 上构建未签名 IPA 并取回")
    parser.add_argument("--owner", default="AdamDashen666")
    parser.add_argument("--repo", default="buzhen-ios-app")
    parser.add_argument("--zip", default=str(DIST / DEFAULT_ZIP_NAME), help="要上传的源码 ZIP")
    parser.add_argument("--zip-name", default=DEFAULT_ZIP_NAME, help="上传到仓库根目录后的文件名")
    parser.add_argument("--watch-only", action="store_true", help="不上传，只等待最新的运行")
    parser.add_argument("--run-id", type=int, default=None, help="指定要等待的 run id")
    parser.add_argument("--timeout", type=int, default=2700, help="等待上限（秒）")
    args = parser.parse_args()

    token = os.environ.get("HTMLRUNNER_GH_TOKEN", "").strip()
    if not token:
        print("[build] 缺少 HTMLRUNNER_GH_TOKEN 环境变量", file=sys.stderr)
        return 2
    gh = GitHub(token)

    who = gh.whoami()
    print(f"[build] 认证用户: {who['login']}")
    meta = gh.repo(args.owner, args.repo)
    print(f"[build] 目标仓库: {meta['full_name']} (private={meta['private']}, push={meta['permissions']['push']})")

    # ---- name-order proof: the workflow picks the lexicographically last zip ----
    #
    # This guard has already prevented a wrong build once: a leftover archive from an
    # earlier run (`ZZzz-HTMLRunner-1.0.000.zip`) sorted AFTER the new, shorter name
    # (`ZZzz-HTMLRunner-0003.zip`) because ASCII '-' (0x2D) precedes '.' (0x2E), so the
    # builder would have rebuilt the previous source. Uploads made by this tool are
    # therefore cleaned up first, and the ordering is proved rather than assumed.
    root_entries = gh.contents(args.owner, args.repo)
    zips = sorted(entry["name"] for entry in root_entries
                  if entry.get("type") == "file" and entry["name"].lower().endswith(".zip"))
    print(f"[build] 仓库根目录现有 zip: {zips}")

    stale = [name for name in zips
             if name.startswith("ZZzz-") and name != args.zip_name]
    if stale and not args.watch_only:
        print(f"[build] 清理本工具此前的上传（避免字典序冲突）: {stale}")
        for name in stale:
            if gh.delete_file(args.owner, args.repo, name,
                              f"ci: remove superseded builder zip {name}"):
                print(f"[build]   已删除 {name}")
        zips = [name for name in zips if name not in stale]

    if args.zip_name in zips:
        print(f"[build] 注意: {args.zip_name} 已存在，将被覆盖")
    pool = sorted(set(zips) | {args.zip_name})
    winner = pool[-1]
    if winner != args.zip_name:
        print(f"[build] 危险: 字典序最大的 zip 是 '{winner}'，不是 '{args.zip_name}'。"
              f"workflow 会构建错误的项目。请改用排序更靠后的文件名。", file=sys.stderr)
        return 3
    print(f"[build] 名称顺序校验通过: workflow 会选中 '{winner}'")

    run_id = args.run_id
    if not args.watch_only:
        payload = pathlib.Path(args.zip)
        if not payload.exists():
            print(f"[build] 找不到 {payload}", file=sys.stderr)
            return 2
        data = payload.read_bytes()
        print(f"[build] 上传 {args.zip_name} ({len(data)} 字节, "
              f"sha256={hashlib.sha256(data).hexdigest()[:16]}…)")
        gh.put_file(args.owner, args.repo, args.zip_name, data,
                    f"ci: source zip for unsigned IPA build ({args.zip_name})")
        print("[build] 已提交，等待 workflow 被触发…")
        time.sleep(8)
        runs = find_workflow_runs(gh, args.owner, args.repo)
        if runs and runs[0]["event"] == "push":
            run_id = runs[0]["id"]
            print(f"[build] 已触发 run #{runs[0]['run_number']} (id={run_id})")

    # ---- wait ------------------------------------------------------------------
    run = wait_for_run(gh, args.owner, args.repo, run_id, args.timeout)
    print(f"[build] 运行结束: conclusion={run.get('conclusion')} ({run['html_url']})")

    if run.get("conclusion") != "success":
        print("[build] 构建失败，打印步骤状态：")
        print_failed_job_log(gh, args.owner, args.repo, run["id"])
        print("[build] 没有生成 IPA。请查看上面的失败步骤，或下载 Build-Diagnostics artifact。")
        return 1

    # ---- download --------------------------------------------------------------
    artifacts = gh.artifacts(args.owner, args.repo, run["id"])
    for artifact in artifacts:
        print(f"[build] artifact: {artifact['name']} ({artifact['size_in_bytes']} 字节, "
              f"expired={artifact['expired']})")
    ipa_artifacts = [a for a in artifacts if "ipa" in a["name"].lower() and not a["expired"]]
    if not ipa_artifacts:
        print("[build] 没有可下载的 IPA artifact", file=sys.stderr)
        return 1

    chosen = ipa_artifacts[0]
    print(f"[build] 下载 {chosen['name']}…")
    blob = gh.download_artifact(args.owner, args.repo, chosen["id"])
    print(f"[build] artifact 下载完成 ({len(blob)} 字节)")

    target = DIST / "HTMLRunner.ipa"
    extract_ipa(blob, target)
    digest = hashlib.sha256(target.read_bytes()).hexdigest()
    print(f"[build] IPA: {target.relative_to(ROOT)}  {target.stat().st_size} 字节")
    print(f"[build] sha256: {digest}")

    # ---- verify with the project's own verifier --------------------------------
    verifier = ROOT / "mac" / "verify_ipa.sh"
    bash = shutil.which("bash")
    if verifier.exists() and bash:
        print("[build] 运行 mac/verify_ipa.sh…")
        result = subprocess.run([bash, str(verifier), str(target)],
                                cwd=ROOT, capture_output=True, text=True,
                                encoding="utf-8", errors="replace")
        print(result.stdout)
        if result.stderr.strip():
            print(result.stderr, file=sys.stderr)
        print(f"[build] verify_ipa.sh exit={result.returncode}")
    else:
        print("[build] 未找到 bash 或 verify_ipa.sh，跳过本地校验（在 macOS 上请手动运行）")

    # record the run for the report
    (DIST / "GITHUB-BUILD-RUN.json").write_text(json.dumps({
        "owner": args.owner,
        "repo": args.repo,
        "runId": run["id"],
        "runNumber": run["run_number"],
        "runUrl": run["html_url"],
        "headSha": run.get("head_sha"),
        "workflow": WORKFLOW_FILE,
        "sourceZip": args.zip_name,
        "artifactName": chosen["name"],
        "ipaSha256": digest,
    }, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print("[build] 已记录 dist/GITHUB-BUILD-RUN.json")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
