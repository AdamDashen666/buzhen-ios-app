#!/usr/bin/env python3
"""Verify an iOS IPA without macOS.

`mac/verify_ipa.sh` is the authoritative verifier on a Mac (it uses `plutil`,
`codesign`, `file` and `lipo`). This script answers the same questions with only
Python, so a Windows/Linux machine can check an IPA that was produced elsewhere —
which is exactly the situation this project is in, since the IPA is built on a
GitHub macOS runner.

What it checks, and why each one matters
----------------------------------------
  * zip integrity and `Payload/<name>.app/` layout — a malformed IPA is not installable.
  * **Mach-O cputype must be arm64.** A simulator or x86 build produces an IPA that
    looks fine and simply refuses to install on an iPad.
  * **LC_BUILD_VERSION platform must be iOS (2), not iOS Simulator (7).** This is the
    check that catches "we shipped a simulator build" — the failure mode the task
    brief explicitly warned about.
  * `MinimumOSVersion`, `CFBundleSupportedPlatforms`, `UIDeviceFamily` (must contain 2
    for iPad) and the version keys, read from the *built* Info.plist.
  * `Assets.car` (compiled icon catalog) and `PkgInfo` presence.
  * `_CodeSignature` / `embedded.mobileprovision` are reported as information, not
    failures: an unsigned IPA is the intended input to a re-signing tool.

Usage
-----
    python tools/verify_ipa_py.py dist/HTMLRunner.ipa
"""
from __future__ import annotations

import argparse
import hashlib
import pathlib
import plistlib
import struct
import sys
import zipfile

MH_MAGIC_64 = 0xFEEDFACF
CPU_TYPE_ARM64 = 0x0100000C
CPU_TYPE_X86_64 = 0x01000007
MH_EXECUTE = 2
LC_BUILD_VERSION = 0x32
LC_VERSION_MIN_IPHONEOS = 0x25

PLATFORM_NAMES = {
    1: "macOS",
    2: "iOS",
    3: "tvOS",
    4: "watchOS",
    5: "bridgeOS",
    6: "macCatalyst",
    7: "iOS Simulator",
    8: "tvOS Simulator",
    9: "watchOS Simulator",
    10: "DriverKit",
    11: "visionOS",
    12: "visionOS Simulator",
}


class Report:
    def __init__(self) -> None:
        self.errors: list[str] = []
        self.warnings: list[str] = []
        self.notes: list[str] = []

    def check(self, condition: bool, message: str) -> bool:
        if not condition:
            self.errors.append(message)
        return condition

    def warn_unless(self, condition: bool, message: str) -> None:
        if not condition:
            self.warnings.append(message)


def parse_macho(header: bytes, blob: bytes) -> dict:
    """Reads enough of the Mach-O to decide architecture and target platform.

    Header layout for `mach_header_64` (28 bytes of fields, then a 4-byte reserved
    field, so the load-command table starts at byte 32):

        uint32 magic; cpu_type_t cputype; cpu_subtype_t cpusubtype; uint32 filetype;
        uint32 ncmds; uint32 sizeofcmds; uint32 flags;

    Getting these offsets wrong makes the whole scan read garbage and then report
    "no platform found" — a false negative that looks like a real finding. It was.
    """
    magic, cputype, cpusubtype, filetype, ncmds, _sizeofcmds, flags = struct.unpack(
        "<IiiIIII", header[:28])
    info: dict = {
        "magic": magic,
        "cputype": cputype,
        "cpusubtype": cpusubtype,
        "filetype": filetype,
        "ncmds": ncmds,
        "flags": flags,
        "platforms": [],
    }
    offset = 32
    for _ in range(ncmds):
        if offset + 8 > len(blob):
            break
        cmd, cmdsize = struct.unpack("<II", blob[offset:offset + 8])
        if cmdsize < 8:
            break
        if cmd == LC_BUILD_VERSION and offset + 12 <= len(blob):
            platform = struct.unpack("<I", blob[offset + 8:offset + 12])[0]
            info["platforms"].append(("LC_BUILD_VERSION", platform))
        elif cmd == LC_VERSION_MIN_IPHONEOS:
            info["platforms"].append(("LC_VERSION_MIN_IPHONEOS", 2))
        offset += cmdsize
    return info


def main() -> int:
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except (AttributeError, ValueError):
            pass

    parser = argparse.ArgumentParser(description="在没有 macOS 的情况下校验 IPA")
    parser.add_argument("ipa", help="IPA 路径")
    parser.add_argument("--expect-bundle-id", default=None, help="期望的 CFBundleIdentifier")
    args = parser.parse_args()

    report = Report()
    ipa = pathlib.Path(args.ipa)
    if not report.check(ipa.is_file() and ipa.stat().st_size > 0, f"找不到或为空的 IPA: {ipa}"):
        return finish(report)

    digest = hashlib.sha256(ipa.read_bytes()).hexdigest()
    report.notes.append(f"文件: {ipa}  {ipa.stat().st_size:,} 字节")
    report.notes.append(f"sha256: {digest}")

    if not report.check(zipfile.is_zipfile(ipa), "不是有效的 zip（IPA 必须是 zip 容器）"):
        return finish(report)

    with zipfile.ZipFile(ipa) as archive:
        report.check(archive.testzip() is None, "zip 内部损坏")
        names = archive.namelist()
        apps = sorted({n.split("/")[1] for n in names
                       if n.startswith("Payload/") and len(n.split("/")) > 1 and n.split("/")[1].endswith(".app")})
        if not report.check(len(apps) == 1, f"期望 Payload 下恰好一个 .app，实际 {apps}"):
            return finish(report)
        app_name = apps[0]
        prefix = f"Payload/{app_name}/"
        report.notes.append(f"app 包: {app_name}  内含 {len([n for n in names if n.startswith(prefix)])} 个条目")

        # ---- Info.plist -------------------------------------------------------
        info_entries = [n for n in names if n == prefix + "Info.plist"]
        if report.check(bool(info_entries), f"{app_name}/Info.plist 缺失"):
            info = plistlib.loads(archive.read(info_entries[0]))
            for key in ("CFBundleIdentifier", "CFBundleShortVersionString", "CFBundleVersion",
                        "MinimumOSVersion", "CFBundleSupportedPlatforms", "UIDeviceFamily"):
                if key in info:
                    report.notes.append(f"  {key} = {info[key]}")
                else:
                    report.errors.append(f"Info.plist 缺少必需键 {key}")
            report.check(info.get("CFBundleSupportedPlatforms") == ["iPhoneOS"],
                         f"CFBundleSupportedPlatforms 应为 ['iPhoneOS']，实际 {info.get('CFBundleSupportedPlatforms')}")
            families = info.get("UIDeviceFamily") or []
            report.check(2 in families,
                         f"UIDeviceFamily 必须包含 2（iPad），实际 {families}")
            if args.expect_bundle_id:
                report.check(info.get("CFBundleIdentifier") == args.expect_bundle_id,
                             f"Bundle ID 为 {info.get('CFBundleIdentifier')}，期望 {args.expect_bundle_id}")

        # ---- executable -------------------------------------------------------
        executables = [n for n in names
                       if n.startswith(prefix)
                       and n.count("/") == 2
                       and not n.endswith((".plist", ".car", ".png", ".mobileprovision"))
                       and "PkgInfo" not in n]
        binary_name = prefix + (app_name.rsplit(".app", 1)[0])
        if binary_name not in names:
            binary_name = executables[0] if executables else ""
        if not report.check(bool(binary_name) and binary_name in names,
                            f"找不到可执行文件（期望 {prefix}{app_name[:-4]}）"):
            return finish(report)

        blob = archive.read(binary_name)
        report.check(len(blob) > 4096, "可执行文件过小，可能不是真正的 Mach-O")
        # Parse the WHOLE file, not a prefix: `ncmds` and the load-command table can
        # extend well past the first 4 KiB on a real app binary, and truncating the
        # buffer silently stops the platform scan early (which is why the first run of
        # this script could not find LC_BUILD_VERSION).
        macho = parse_macho(blob[:4096], blob)
        report.notes.append(f"可执行文件: {binary_name.rsplit('/', 1)[-1]}  {len(blob):,} 字节")
        report.check(macho["magic"] == MH_MAGIC_64,
                     f"Mach-O magic 为 0x{macho['magic']:08x}，期望 0x{MH_MAGIC_64:08x}")
        report.check(macho["filetype"] == MH_EXECUTE,
                     f"Mach-O filetype 为 {macho['filetype']}，期望 {MH_EXECUTE} (MH_EXECUTE)")
        report.check(macho["ncmds"] < 100_000,
                     f"Mach-O 头部声明的 load command 数量异常（{macho['ncmds']}），文件可能损坏")
        arm64 = macho["cputype"] == CPU_TYPE_ARM64
        report.check(arm64,
                     f"cputype 为 0x{macho['cputype']:08x}，不是 arm64 (0x{CPU_TYPE_ARM64:08x})"
                     + ("——这是 x86_64" if macho["cputype"] == CPU_TYPE_X86_64 else "")
                     + "；该 IPA 无法安装到 iPad")
        if arm64:
            report.notes.append(f"架构: arm64 (cpusubtype=0x{macho['cpusubtype']:08x})")

        platforms = macho["platforms"]
        if platforms:
            for name, platform in platforms:
                report.notes.append(f"  {name} platform={platform} ({PLATFORM_NAMES.get(platform, '?')})")
            simulator = [p for _, p in platforms if p in (7, 8, 9, 12)]
            report.check(not simulator,
                         f"构建目标是模拟器平台 {[PLATFORM_NAMES.get(p) for p in simulator]}，"
                         "这不是可安装到真机的 IPA")
            report.check(any(p == 2 for _, p in platforms),
                         f"未找到 iOS 平台标记（platform=2），实际 {platforms}")
        else:
            report.warnings.append("未找到 LC_BUILD_VERSION/LC_VERSION_MIN_IPHONEOS，无法确认目标平台")

        # ---- resources --------------------------------------------------------
        report.check(any(n == prefix + "Assets.car" for n in names),
                     f"{app_name}/Assets.car 缺失（图标资源未编译进包）")
        report.warn_unless(any(n == prefix + "PkgInfo" for n in names),
                           f"{app_name}/PkgInfo 缺失（安装通常仍可进行，但不标准）")
        icons = [n for n in names if n.startswith(prefix) and n.endswith(".png") and "AppIcon" in n]
        if icons:
            report.notes.append(f"图标 PNG: {len(icons)} 个")
        report.warn_unless(bool(icons) or any(n == prefix + "Assets.car" for n in names),
                           "既没有 Assets.car 也没有 AppIcon PNG，主屏图标会是空白")

        # ---- signing state (informational) -----------------------------------
        signed = any("/_CodeSignature/" in n for n in names)
        provisioned = any(n == prefix + "embedded.mobileprovision" for n in names)
        if signed:
            report.notes.append("已签名（含 _CodeSignature）")
        else:
            report.notes.append("未签名（无 _CodeSignature）—— 这是供侧载工具重签的预期形态")
            report.warnings.append("IPA 未签名：必须经签名工具（如 NB 助手）重签后才能安装")
        report.notes.append("含 embedded.mobileprovision"
                            if provisioned else "无 embedded.mobileprovision（未签名 IPA 的正常状态）")

        # ---- simulator leftovers --------------------------------------------
        sim_named = [n for n in names if "simulator" in n.lower()]
        report.check(not sim_named, f"包内含模拟器相关条目: {sim_named[:3]}")

        # ---- bundled resources that the app loads by name --------------------
        for required in ("DiagnosticBridge.js", "WebProbe.js", "JIT_NOTES.md"):
            report.check(any(n == prefix + required for n in names),
                         f"{required} 未打包进 app（App 运行时会找不到它）")

    return finish(report)


def finish(report: Report) -> int:
    for note in report.notes:
        print(f"[ipa] {note}")
    for warning in report.warnings:
        print(f"[ipa][warn] {warning}")
    for error in report.errors:
        print(f"[ipa][ERROR] {error}")
    if report.errors:
        print(f"[ipa] 结果: 失败（{len(report.errors)} 个问题）")
        return 1
    print("[ipa] 结果: 通过（arm64 真机构建、结构完整、资源齐全）")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
