#!/usr/bin/env python3
"""Generate the HTMLRunner Xcode project, asset catalog, Info.plist and scheme.

Why generate instead of hand-writing `project.pbxproj`
------------------------------------------------------
A pbxproj is a graph of 24-hex-character object ids. Hand-editing one reliably
produces dangling references that Xcode reports as "The project is damaged".
Generating it here makes three things possible:

  * `HTMLRunner.xcodeproj` is reproducible: `python tools/generate_project.py`
    rebuilds it byte-identically.
  * `tools/verify_project.py` can check the same graph independently.
  * The target uses `PBXFileSystemSynchronizedRootGroup` (Xcode 16+), so files
    added to `HTMLRunner/App`, `Views`, `Web`, `FileManagement`, `Diagnostics`,
    `Settings` and `Resources` are picked up without touching the pbxproj at all.

Scope of the synchronized groups
--------------------------------
`HTMLRunner/Tests/` is deliberately NOT synchronized. Those are review artefacts
and shell/Python harnesses, not app resources; excluding them at the group level
means no `PBXFileSystemSynchronizedBuildFileExceptionSet` bookkeeping is needed.

Run:  python tools/generate_project.py
"""
from __future__ import annotations

import json
import os
import pathlib
import plistlib
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
PROJECT_NAME = "HTMLRunner"
BUNDLE_ID = "com.htmlrunner.ipad"
MARKETING_VERSION = "1.0.1"
CURRENT_PROJECT_VERSION = "3"
DEPLOYMENT_TARGET = "17.0"
SWIFT_VERSION = "5.0"
TARGETED_DEVICE_FAMILY = "2"          # 2 = iPad only
OBJECT_VERSION = "77"                  # Xcode 16 project format
COMPATIBILITY_VERSION = "Xcode 15.0"
LAST_UPGRADE_VERSION = "1640"          # Xcode 16.4

# Directories inside HTMLRunner/ that belong to the app target. Order matters only
# for how the groups appear in Xcode's navigator.
SYNCHRONIZED_GROUPS = [
    ("App", "App"),
    ("Views", "Views"),
    ("Web", "Web"),
    ("FileManagement", "FileManagement"),
    ("Diagnostics", "Diagnostics"),
    ("Settings", "Settings"),
    ("Resources", "Resources"),
]

# Files inside a synchronized group that must NOT be treated as bundle resources.
#
# These live in `Resources/` for discoverability, but Xcode already handles them
# through dedicated build settings:
#
#   Resources/Info.plist                              -> INFOPLIST_FILE (processed into
#                                                        the bundle's Info.plist)
#   Resources/Entitlements/HTMLRunner.entitlements    -> CODE_SIGN_ENTITLEMENTS
#
# Without the exception, the synchronized group ALSO copies them as resources and the
# build fails with:
#
#   error: Multiple commands produce '.../HTMLRunner.app/Info.plist'
#
# That is a real failure this project hit on a macOS CI runner (GitHub run #141).
# Shipping the entitlements file inside the .app would additionally leak the
# provisioning intent into the bundle, so both are excluded.
SYNCHRONIZED_EXCEPTIONS = {
    "Resources": [
        "Info.plist",
        "Entitlements/HTMLRunner.entitlements",
    ],
}


def uid(*parts: str) -> str:
    """Deterministic 24-hex object id derived from a readable key.

    Deterministic ids keep regenerating the project idempotent and make diffs
    reviewable, which random ids would not.
    """
    import hashlib
    digest = hashlib.sha1("::".join(parts).encode("utf-8")).hexdigest()
    return digest[:24].upper()


def build_pbxproj() -> str:
    ids = {
        "project": uid("project"),
        "main_group": uid("main_group"),
        "products_group": uid("products_group"),
        "target": uid("target"),
        "product_ref": uid("product_ref"),
        "sources_phase": uid("sources_phase"),
        "frameworks_phase": uid("frameworks_phase"),
        "resources_phase": uid("resources_phase"),
        "project_config_list": uid("project_config_list"),
        "target_config_list": uid("target_config_list"),
        "project_debug": uid("project_debug"),
        "project_release": uid("project_release"),
        "target_debug": uid("target_debug"),
        "target_release": uid("target_release"),
        "jit_notes_ref": uid("jit_notes_ref"),
        "jit_notes_build": uid("jit_notes_build"),
        "exception_set": uid("exception_set"),
    }
    group_ids = {name: uid("syncgroup", name) for name, _ in SYNCHRONIZED_GROUPS}

    # ---------------------------------------------------------------- header --
    lines: list[str] = []
    lines.append("// !$*UTF8*$!")
    lines.append("{")
    lines.append("\tarchiveVersion = 1;")
    lines.append("\tclasses = {")
    lines.append("\t};")
    lines.append(f"\tobjectVersion = {OBJECT_VERSION};")
    lines.append("\tobjects = {")

    # ------------------------------------------------------- PBXBuildFile ----
    lines.append("")
    lines.append("/* Begin PBXBuildFile section */")
    lines.append(
        f"\t\t{ids['jit_notes_build']} /* JIT_NOTES.md in Resources */ = "
        f"{{isa = PBXBuildFile; fileRef = {ids['jit_notes_ref']} /* JIT_NOTES.md */; }};"
    )
    lines.append("/* End PBXBuildFile section */")

    # ------------------------------------------------------- PBXFileReference -
    lines.append("")
    lines.append("/* Begin PBXFileReference section */")
    lines.append(
        f"\t\t{ids['jit_notes_ref']} /* JIT_NOTES.md */ = "
        "{isa = PBXFileReference; lastKnownFileType = net.daringfireball.markdown; "
        "path = JIT_NOTES.md; sourceTree = \"<group>\"; };"
    )
    lines.append(
        f"\t\t{ids['product_ref']} /* {PROJECT_NAME}.app */ = "
        "{isa = PBXFileReference; explicitFileType = wrapper.application; includeInIndex = 0; "
        f"path = {PROJECT_NAME}.app; sourceTree = BUILT_PRODUCTS_DIR; }};"
    )
    lines.append("/* End PBXFileReference section */")

    # --------------------------------------------- PBXFileSystemSynchronized -
    lines.append("")
    lines.append("/* Begin PBXFileSystemSynchronizedBuildFileExceptionSet section */")
    excluded = SYNCHRONIZED_EXCEPTIONS.get("Resources", [])
    lines.append(
        f"\t\t{ids['exception_set']} /* Exceptions for \"Resources\" folder in \"{PROJECT_NAME}\" target */ = {{"
    )
    lines.append("\t\t\tisa = PBXFileSystemSynchronizedBuildFileExceptionSet;")
    if excluded:
        lines.append("\t\t\tmembershipExceptions = (")
        for relative in excluded:
            lines.append(f"\t\t\t\t{relative},")
        lines.append("\t\t\t);")
    lines.append(f"\t\t\ttarget = {ids['target']} /* {PROJECT_NAME} */;")
    lines.append("\t\t};")
    lines.append("/* End PBXFileSystemSynchronizedBuildFileExceptionSet section */")

    lines.append("")
    lines.append("/* Begin PBXFileSystemSynchronizedRootGroup section */")
    for name, folder in SYNCHRONIZED_GROUPS:
        lines.append(f"\t\t{group_ids[name]} /* {folder} */ = {{")
        lines.append("\t\t\tisa = PBXFileSystemSynchronizedRootGroup;")
        if name == "Resources":
            lines.append(f"\t\t\texceptions = (\n\t\t\t\t{ids['exception_set']} /* Exceptions for \"Resources\" folder in \"{PROJECT_NAME}\" target */,\n\t\t\t);")
        lines.append(f"\t\t\tpath = {folder};")
        lines.append("\t\t\tsourceTree = \"<group>\";")
        lines.append("\t\t};")
    lines.append("/* End PBXFileSystemSynchronizedRootGroup section */")

    # ---------------------------------------------------------- PBXFrameworks -
    lines.append("")
    lines.append("/* Begin PBXFrameworksBuildPhase section */")
    lines.append(f"\t\t{ids['frameworks_phase']} /* Frameworks */ = {{")
    lines.append("\t\t\tisa = PBXFrameworksBuildPhase;")
    lines.append("\t\t\tbuildActionMask = 2147483647;")
    lines.append("\t\t\tfiles = (\n\t\t\t);")
    lines.append("\t\t\trunOnlyForDeploymentPostprocessing = 0;")
    lines.append("\t\t};")
    lines.append("/* End PBXFrameworksBuildPhase section */")

    # --------------------------------------------------------------- PBXGroup -
    lines.append("")
    lines.append("/* Begin PBXGroup section */")
    # Main group
    main_children = "\n".join(
        f"\t\t\t\t{group_ids[name]} /* {folder} */," for name, folder in SYNCHRONIZED_GROUPS
    )
    lines.append(f"\t\t{ids['main_group']} = {{")
    lines.append("\t\t\tisa = PBXGroup;")
    lines.append("\t\t\tchildren = (")
    lines.append(main_children)
    lines.append(f"\t\t\t\t{ids['jit_notes_ref']} /* JIT_NOTES.md */,")
    lines.append(f"\t\t\t\t{ids['products_group']} /* Products */,")
    lines.append("\t\t\t);")
    lines.append(f"\t\t\tpath = {PROJECT_NAME};")
    lines.append("\t\t\tsourceTree = \"<group>\";")
    lines.append("\t\t};")
    # Products group
    lines.append(f"\t\t{ids['products_group']} /* Products */ = {{")
    lines.append("\t\t\tisa = PBXGroup;")
    lines.append("\t\t\tchildren = (")
    lines.append(f"\t\t\t\t{ids['product_ref']} /* {PROJECT_NAME}.app */,")
    lines.append("\t\t\t);")
    lines.append("\t\t\tname = Products;")
    lines.append("\t\t\tsourceTree = \"<group>\";")
    lines.append("\t\t};")
    lines.append("/* End PBXGroup section */")

    # -------------------------------------------------------- PBXNativeTarget -
    lines.append("")
    lines.append("/* Begin PBXNativeTarget section */")
    lines.append(f"\t\t{ids['target']} /* {PROJECT_NAME} */ = {{")
    lines.append("\t\t\tisa = PBXNativeTarget;")
    lines.append(
        f"\t\t\tbuildConfigurationList = {ids['target_config_list']} "
        f"/* Build configuration list for PBXNativeTarget \"{PROJECT_NAME}\" */;"
    )
    lines.append("\t\t\tbuildPhases = (")
    lines.append(f"\t\t\t\t{ids['sources_phase']} /* Sources */,")
    lines.append(f"\t\t\t\t{ids['frameworks_phase']} /* Frameworks */,")
    lines.append(f"\t\t\t\t{ids['resources_phase']} /* Resources */,")
    lines.append("\t\t\t);")
    lines.append("\t\t\tbuildRules = (\n\t\t\t);")
    lines.append("\t\t\tdependencies = (\n\t\t\t);")
    lines.append("\t\t\tfileSystemSynchronizedGroups = (")
    for name, folder in SYNCHRONIZED_GROUPS:
        lines.append(f"\t\t\t\t{group_ids[name]} /* {folder} */,")
    lines.append("\t\t\t);")
    lines.append(f"\t\t\tname = {PROJECT_NAME};")
    lines.append(f"\t\t\tproductName = {PROJECT_NAME};")
    lines.append(f"\t\t\tproductReference = {ids['product_ref']} /* {PROJECT_NAME}.app */;")
    lines.append("\t\t\tproductType = \"com.apple.product-type.application\";")
    lines.append("\t\t};")
    lines.append("/* End PBXNativeTarget section */")

    # ------------------------------------------------------------ PBXProject -
    lines.append("")
    lines.append("/* Begin PBXProject section */")
    lines.append(f"\t\t{ids['project']} /* Project object */ = {{")
    lines.append("\t\t\tisa = PBXProject;")
    lines.append("\t\t\tattributes = {")
    lines.append("\t\t\t\tBuildIndependentTargetsInParallel = 1;")
    lines.append(f"\t\t\t\tLastUpgradeCheck = {LAST_UPGRADE_VERSION};")
    lines.append("\t\t\t\tTargetAttributes = {")
    lines.append(f"\t\t\t\t\t{ids['target']} = {{")
    lines.append("\t\t\t\t\t\tCreatedOnToolsVersion = 16.0;")
    lines.append("\t\t\t\t\t};")
    lines.append("\t\t\t\t};")
    lines.append("\t\t\t};")
    lines.append(
        f"\t\t\tbuildConfigurationList = {ids['project_config_list']} "
        f"/* Build configuration list for PBXProject \"{PROJECT_NAME}\" */;"
    )
    lines.append(f"\t\t\tcompatibilityVersion = \"{COMPATIBILITY_VERSION}\";")
    lines.append("\t\t\tdevelopmentRegion = en;")
    lines.append("\t\t\thasScannedForEncodings = 0;")
    lines.append("\t\t\tknownRegions = (\n\t\t\t\ten,\n\t\t\t\tBase,\n\t\t\t\t\"zh-Hans\",\n\t\t\t);")
    lines.append(f"\t\t\tmainGroup = {ids['main_group']};")
    lines.append(f"\t\t\tproductRefGroup = {ids['products_group']} /* Products */;")
    lines.append("\t\t\tprojectDirPath = \"\";")
    lines.append("\t\t\tprojectRoot = \"\";")
    lines.append("\t\t\ttargets = (")
    lines.append(f"\t\t\t\t{ids['target']} /* {PROJECT_NAME} */,")
    lines.append("\t\t\t);")
    lines.append("\t\t};")
    lines.append("/* End PBXProject section */")

    # ------------------------------------------------------- PBXResourcesBuild -
    lines.append("")
    lines.append("/* Begin PBXResourcesBuildPhase section */")
    lines.append(f"\t\t{ids['resources_phase']} /* Resources */ = {{")
    lines.append("\t\t\tisa = PBXResourcesBuildPhase;")
    lines.append("\t\t\tbuildActionMask = 2147483647;")
    lines.append("\t\t\tfiles = (")
    lines.append(f"\t\t\t\t{ids['jit_notes_build']} /* JIT_NOTES.md in Resources */,")
    lines.append("\t\t\t);")
    lines.append("\t\t\trunOnlyForDeploymentPostprocessing = 0;")
    lines.append("\t\t};")
    lines.append("/* End PBXResourcesBuildPhase section */")

    # --------------------------------------------------------- PBXSourcesBuild -
    lines.append("")
    lines.append("/* Begin PBXSourcesBuildPhase section */")
    lines.append(f"\t\t{ids['sources_phase']} /* Sources */ = {{")
    lines.append("\t\t\tisa = PBXSourcesBuildPhase;")
    lines.append("\t\t\tbuildActionMask = 2147483647;")
    lines.append("\t\t\tfiles = (\n\t\t\t);")
    lines.append("\t\t\trunOnlyForDeploymentPostprocessing = 0;")
    lines.append("\t\t};")
    lines.append("/* End PBXSourcesBuildPhase section */")

    # ---------------------------------------------------------- XCBuildConfig -
    lines.append("")
    lines.append("/* Begin XCBuildConfiguration section */")

    shared_project_settings = [
        ("ALWAYS_SEARCH_USER_PATHS", "NO"),
        ("ASSETCATALOG_COMPILER_GENERATE_SWIFT_ASSET_SYMBOL_EXTENSIONS", "YES"),
        ("CLANG_ANALYZER_NONNULL", "YES"),
        ("CLANG_ANALYZER_NUMBER_OBJECT_CONVERSION", "YES_AGGRESSIVE"),
        ("CLANG_CXX_LANGUAGE_STANDARD", "\"gnu++20\""),
        ("CLANG_ENABLE_MODULES", "YES"),
        ("CLANG_ENABLE_OBJC_ARC", "YES"),
        ("CLANG_ENABLE_OBJC_WEAK", "YES"),
        ("CLANG_WARN_BLOCK_CAPTURE_AUTORELEASING", "YES"),
        ("CLANG_WARN_BOOL_CONVERSION", "YES"),
        ("CLANG_WARN_COMMA", "YES"),
        ("CLANG_WARN_CONSTANT_CONVERSION", "YES"),
        ("CLANG_WARN_DEPRECATED_OBJC_IMPLEMENTATIONS", "YES"),
        ("CLANG_WARN_DIRECT_OBJC_ISA_USAGE", "YES_ERROR"),
        ("CLANG_WARN_DOCUMENTATION_COMMENTS", "YES"),
        ("CLANG_WARN_EMPTY_BODY", "YES"),
        ("CLANG_WARN_ENUM_CONVERSION", "YES"),
        ("CLANG_WARN_INFINITE_RECURSION", "YES"),
        ("CLANG_WARN_INT_CONVERSION", "YES"),
        ("CLANG_WARN_NON_LITERAL_NULL_CONVERSION", "YES"),
        ("CLANG_WARN_OBJC_IMPLICIT_RETAIN_SELF", "YES"),
        ("CLANG_WARN_OBJC_LITERAL_CONVERSION", "YES"),
        ("CLANG_WARN_OBJC_ROOT_CLASS", "YES_ERROR"),
        ("CLANG_WARN_QUOTED_INCLUDE_IN_FRAMEWORK_HEADER", "YES"),
        ("CLANG_WARN_RANGE_LOOP_ANALYSIS", "YES"),
        ("CLANG_WARN_STRICT_PROTOTYPES", "YES"),
        ("CLANG_WARN_SUSPICIOUS_MOVE", "YES"),
        ("CLANG_WARN_UNGUARDED_AVAILABILITY", "YES_AGGRESSIVE"),
        ("CLANG_WARN_UNREACHABLE_CODE", "YES"),
        ("CLANG_WARN__DUPLICATE_METHOD_MATCH", "YES"),
        ("COPY_PHASE_STRIP", "NO"),
        ("ENABLE_STRICT_OBJC_MSGSEND", "YES"),
        ("ENABLE_USER_SCRIPT_SANDBOXING", "YES"),
        ("GCC_C_LANGUAGE_STANDARD", "gnu17"),
        ("GCC_NO_COMMON_BLOCKS", "YES"),
        ("GCC_WARN_64_TO_32_BIT_CONVERSION", "YES"),
        ("GCC_WARN_ABOUT_RETURN_TYPE", "YES_ERROR"),
        ("GCC_WARN_UNDECLARED_SELECTOR", "YES"),
        ("GCC_WARN_UNINITIALIZED_AUTOS", "YES_AGGRESSIVE"),
        ("GCC_WARN_UNUSED_FUNCTION", "YES"),
        ("GCC_WARN_UNUSED_VARIABLE", "YES"),
        ("IPHONEOS_DEPLOYMENT_TARGET", DEPLOYMENT_TARGET),
        ("LOCALIZATION_PREFERS_STRING_CATALOGS", "YES"),
        ("MTL_ENABLE_DEBUG_INFO", "INJECTED"),
        ("MTL_FAST_MATH", "YES"),
        ("SDKROOT", "iphoneos"),
        ("SWIFT_VERSION", SWIFT_VERSION),
        # "minimal" keeps Swift 5 language mode without strict-concurrency errors on
        # a codebase that talks to WebKit delegates and Network callbacks. Raising
        # this is a deliberate future task, not a build fix.
        ("SWIFT_STRICT_CONCURRENCY", "minimal"),
    ]

    debug_project_extra = [
        ("DEBUG_INFORMATION_FORMAT", "dwarf"),
        ("ENABLE_TESTABILITY", "YES"),
        ("GCC_DYNAMIC_NO_PIC", "NO"),
        ("GCC_OPTIMIZATION_LEVEL", "0"),
        ("GCC_PREPROCESSOR_DEFINITIONS", "(\n\t\t\t\t\t\"DEBUG=1\",\n\t\t\t\t\t\"$(inherited)\",\n\t\t\t\t)"),
        ("MTL_ENABLE_DEBUG_INFO", "INJECTED"),
        ("ONLY_ACTIVE_ARCH", "YES"),
        ("SWIFT_ACTIVE_COMPILATION_CONDITIONS", "\"DEBUG $(inherited)\""),
        ("SWIFT_OPTIMIZATION_LEVEL", "\"-Onone\""),
    ]

    release_project_extra = [
        ("DEBUG_INFORMATION_FORMAT", "\"dwarf-with-dsym\""),
        ("ENABLE_NS_ASSERTIONS", "NO"),
        ("MTL_ENABLE_DEBUG_INFO", "NO"),
        ("SWIFT_COMPILATION_MODE", "wholemodule"),
    ]

    def emit_config(config_id: str, name: str, settings: list[tuple[str, str]], extra: list[tuple[str, str]]) -> None:
        merged = list(settings) + list(extra)
        lines.append(f"\t\t{config_id} /* {name} */ = {{")
        lines.append("\t\t\tisa = XCBuildConfiguration;")
        lines.append("\t\t\tbuildSettings = {")
        seen: set[str] = set()
        for key, value in merged:
            if key in seen:
                continue
            seen.add(key)
            # An empty value would be emitted as `KEY = ;`, which is not valid
            # OpenStep plist syntax and makes Xcode report a damaged project. The
            # Release configuration relies on this: it deliberately has no
            # CODE_SIGN_ENTITLEMENTS, so the key must be omitted rather than blanked.
            if value == "":
                continue
            lines.append(f"\t\t\t\t{key} = {value};")
        lines.append("\t\t\t};")
        lines.append(f"\t\t\tname = {name};")
        lines.append("\t\t};")

    # Target settings, split so Debug can carry its own entitlement file.
    target_common = [
        ("ASSETCATALOG_COMPILER_APPICON_NAME", "AppIcon"),
        ("ASSETCATALOG_COMPILER_GLOBAL_ACCENT_COLOR_NAME", "AccentColor"),
        ("CODE_SIGN_STYLE", "Automatic"),
        ("CURRENT_PROJECT_VERSION", CURRENT_PROJECT_VERSION),
        # No DEVELOPMENT_TEAM is baked in on purpose: it must not be committed, and
        # mac/build.sh supplies one (or builds unsigned for re-signing tools).
        ("ENABLE_PREVIEWS", "YES"),
        ("GENERATE_INFOPLIST_FILE", "NO"),
        ("INFOPLIST_FILE", f"{PROJECT_NAME}/Resources/Info.plist"),
        ("INFOPLIST_KEY_UIApplicationSceneManifest_Generation", "YES"),
        ("INFOPLIST_KEY_UIApplicationSupportsIndirectInputEvents", "YES"),
        ("INFOPLIST_KEY_UILaunchScreen_Generation", "YES"),
        ("INFOPLIST_KEY_UIStatusBarHidden", "YES"),
        ("INFOPLIST_KEY_UISupportedInterfaceOrientations_iPad",
         "\"UIInterfaceOrientationPortrait UIInterfaceOrientationPortraitUpsideDown UIInterfaceOrientationLandscapeLeft UIInterfaceOrientationLandscapeRight\""),
        ("LD_RUNPATH_SEARCH_PATHS", "(\n\t\t\t\t\t\"$(inherited)\",\n\t\t\t\t\t\"@executable_path/Frameworks\",\n\t\t\t\t)"),
        ("MARKETING_VERSION", MARKETING_VERSION),
        ("PRODUCT_BUNDLE_IDENTIFIER", BUNDLE_ID),
        ("PRODUCT_NAME", "\"$(TARGET_NAME)\""),
        ("SWIFT_EMIT_LOC_STRINGS", "YES"),
        ("TARGETED_DEVICE_FAMILY", f"\"{TARGETED_DEVICE_FAMILY}\""),
    ]

    emit_config(ids["project_debug"], "Debug", shared_project_settings, debug_project_extra)
    emit_config(ids["project_release"], "Release", shared_project_settings, release_project_extra)
    emit_config(ids["target_debug"], "Debug", target_common, [
        ("CODE_SIGN_ENTITLEMENTS", f"{PROJECT_NAME}/Resources/Entitlements/{PROJECT_NAME}.entitlements"),
        ("SWIFT_ACTIVE_COMPILATION_CONDITIONS", "\"DEBUG $(inherited)\""),
    ])
    emit_config(ids["target_release"], "Release", target_common, [
        # Release builds carry no entitlements file: get-task-allow must not end up in
        # a distributed binary. See JIT_NOTES.md for why this is the correct default.
        ("CODE_SIGN_ENTITLEMENTS", ""),
    ])
    lines.append("/* End XCBuildConfiguration section */")

    # ------------------------------------------------------ XCConfigurationList
    lines.append("")
    lines.append("/* Begin XCConfigurationList section */")
    lines.append(f"\t\t{ids['project_config_list']} /* Build configuration list for PBXProject \"{PROJECT_NAME}\" */ = {{")
    lines.append("\t\t\tisa = XCConfigurationList;")
    lines.append("\t\t\tbuildConfigurations = (")
    lines.append(f"\t\t\t\t{ids['project_debug']} /* Debug */,")
    lines.append(f"\t\t\t\t{ids['project_release']} /* Release */,")
    lines.append("\t\t\t);")
    lines.append("\t\t\tdefaultConfigurationIsVisible = 0;")
    lines.append("\t\t\tdefaultConfigurationName = Release;")
    lines.append("\t\t};")
    lines.append(f"\t\t{ids['target_config_list']} /* Build configuration list for PBXNativeTarget \"{PROJECT_NAME}\" */ = {{")
    lines.append("\t\t\tisa = XCConfigurationList;")
    lines.append("\t\t\tbuildConfigurations = (")
    lines.append(f"\t\t\t\t{ids['target_debug']} /* Debug */,")
    lines.append(f"\t\t\t\t{ids['target_release']} /* Release */,")
    lines.append("\t\t\t);")
    lines.append("\t\t\tdefaultConfigurationIsVisible = 0;")
    lines.append("\t\t\tdefaultConfigurationName = Release;")
    lines.append("\t\t};")
    lines.append("/* End XCConfigurationList section */")

    lines.append("\t};")
    lines.append(f"\trootObject = {ids['project']} /* Project object */;")
    lines.append("}")
    lines.append("")
    return "\n".join(lines)


def build_scheme() -> str:
    target_id = uid("target")
    return f"""<?xml version="1.0" encoding="UTF-8"?>
<Scheme
   LastUpgradeVersion = "{LAST_UPGRADE_VERSION}"
   version = "1.7">
   <BuildAction
      parallelizeBuildables = "YES"
      buildImplicitDependencies = "YES">
      <BuildActionEntries>
         <BuildActionEntry
            buildForTesting = "YES"
            buildForRunning = "YES"
            buildForProfiling = "YES"
            buildForArchiving = "YES"
            buildForAnalyzing = "YES">
            <BuildableReference
               BuildableIdentifier = "primary"
               BlueprintIdentifier = "{target_id}"
               BuildableName = "{PROJECT_NAME}.app"
               BlueprintName = "{PROJECT_NAME}"
               ReferencedContainer = "container:{PROJECT_NAME}.xcodeproj">
            </BuildableReference>
         </BuildActionEntry>
      </BuildActionEntries>
   </BuildAction>
   <TestAction
      buildConfiguration = "Debug"
      selectedDebuggerIdentifier = "Xcode.DebuggerFoundation.Debugger.LLDB"
      selectedLauncherIdentifier = "Xcode.DebuggerFoundation.Launcher.LLDB"
      shouldUseLaunchSchemeArgsEnv = "YES">
      <Testables>
      </Testables>
   </TestAction>
   <LaunchAction
      buildConfiguration = "Debug"
      selectedDebuggerIdentifier = "Xcode.DebuggerFoundation.Debugger.LLDB"
      selectedLauncherIdentifier = "Xcode.DebuggerFoundation.Launcher.LLDB"
      launchStyle = "0"
      useCustomWorkingDirectory = "NO"
      ignoresPersistentStateOnLaunch = "NO"
      debugDocumentVersioning = "YES"
      debugServiceExtension = "internal"
      allowLocationSimulation = "YES">
      <BuildableProductRunnable
         runnableDebuggingMode = "0">
         <BuildableReference
            BuildableIdentifier = "primary"
            BlueprintIdentifier = "{target_id}"
            BuildableName = "{PROJECT_NAME}.app"
            BlueprintName = "{PROJECT_NAME}"
            ReferencedContainer = "container:{PROJECT_NAME}.xcodeproj">
         </BuildableReference>
      </BuildableProductRunnable>
   </LaunchAction>
   <ProfileAction
      buildConfiguration = "Release"
      shouldUseLaunchSchemeArgsEnv = "YES"
      savedToolIdentifier = ""
      useCustomWorkingDirectory = "NO"
      debugDocumentVersioning = "YES">
      <BuildableProductRunnable
         runnableDebuggingMode = "0">
         <BuildableReference
            BuildableIdentifier = "primary"
            BlueprintIdentifier = "{target_id}"
            BuildableName = "{PROJECT_NAME}.app"
            BlueprintName = "{PROJECT_NAME}"
            ReferencedContainer = "container:{PROJECT_NAME}.xcodeproj">
         </BuildableReference>
      </BuildableProductRunnable>
   </ProfileAction>
   <AnalyzeAction
      buildConfiguration = "Debug">
   </AnalyzeAction>
   <ArchiveAction
      buildConfiguration = "Release"
      revealArchiveInOrganizer = "YES">
   </ArchiveAction>
</Scheme>
"""


def build_info_plist() -> dict:
    return {
        "CFBundleDevelopmentRegion": "zh_CN",
        "CFBundleDisplayName": "HTMLRunner",
        "CFBundleExecutable": "$(EXECUTABLE_NAME)",
        "CFBundleIdentifier": "$(PRODUCT_BUNDLE_IDENTIFIER)",
        "CFBundleInfoDictionaryVersion": "6.0",
        "CFBundleName": "$(PRODUCT_NAME)",
        "CFBundlePackageType": "APPL",
        "CFBundleShortVersionString": "$(MARKETING_VERSION)",
        "CFBundleVersion": "$(CURRENT_PROJECT_VERSION)",
        # iPad only. Requiring full screen also guarantees the app is never run in a
        # slide-over window, where a WebGL canvas would get an unpredictable size.
        "UIDeviceFamily": [2],
        "UIRequiresFullScreen": True,
        "UIStatusBarHidden": True,
        "UIViewControllerBasedStatusBarAppearance": False,
        "UILaunchScreen": {
            "UIColorName": "",
            "UIBackgroundColor": "#000000"
        },
        "UISupportedInterfaceOrientations~ipad": [
            "UIInterfaceOrientationPortrait",
            "UIInterfaceOrientationPortraitUpsideDown",
            "UIInterfaceOrientationLandscapeLeft",
            "UIInterfaceOrientationLandscapeRight"
        ],
        "UIApplicationSupportsIndirectInputEvents": True,
        "UIRequiredDeviceCapabilities": ["arm64"],
        # Exposes Documents/ to the Files app so imported projects are inspectable and
        # a user can drop a project in without going through the picker.
        "UIFileSharingEnabled": True,
        "LSSupportsOpeningDocumentsInPlace": True,
        # Declare the content the app can open. Two reasons this matters:
        #   * HTMLRunner becomes a destination in the share sheet, so an .html file or a
        #     project folder can be sent to the app from Files / another app instead of
        #     going through the document picker at all.
        #   * `LSSupportsOpeningDocumentsInPlace` only behaves as expected for content
        #     the app declares it handles; without these entries the system treats the
        #     app as a generic container and offers it for nothing.
        "CFBundleDocumentTypes": [
            {
                "CFBundleTypeName": "HTML 文档",
                "CFBundleTypeRole": "Viewer",
                "LSHandlerRank": "Alternate",
                "LSItemContentTypes": ["public.html", "public.xhtml"],
            },
            {
                "CFBundleTypeName": "网页项目文件夹",
                "CFBundleTypeRole": "Viewer",
                "LSHandlerRank": "Alternate",
                "LSItemContentTypes": ["public.folder"],
            },
        ],
        # No background modes, no network entitlements: the loopback server needs none.
        "ITSAppUsesNonExemptEncryption": False,
        "CFBundleLocalizations": ["zh-Hans", "en"],
    }


def build_entitlements() -> dict:
    # Deliberately minimal. See JIT_NOTES.md:
    #   * get-task-allow is added by the *Debug* code-signing path and by re-signing
    #     tools; declaring it here makes that explicit and reviewable.
    #   * No com.apple.security.cs.allow-jit, no dynamic-codesigning: neither is a
    #     thing an app-signed iOS binary can grant itself, and adding them would
    #     produce a build that fails to install rather than one with working JIT.
    return {"get-task-allow": True}


def build_asset_catalog() -> dict[str, str]:
    appicon_contents = {
        "images": [
            {
                "filename": "AppIcon-1024.png",
                "idiom": "universal",
                "platform": "ios",
                "size": "1024x1024"
            }
        ],
        "info": {"author": "xcode", "version": 1}
    }
    accent_contents = {
        "colors": [
            {
                "color": {
                    "color-space": "srgb",
                    "components": {
                        "alpha": "1.000",
                        "blue": "0.949",
                        "green": "0.478",
                        "red": "0.204"
                    }
                },
                "idiom": "universal"
            }
        ],
        "info": {"author": "xcode", "version": 1}
    }
    root_contents = {"info": {"author": "xcode", "version": 1}}
    return {
        "Assets.xcassets/Contents.json": json.dumps(root_contents, indent=2) + "\n",
        "Assets.xcassets/AppIcon.appiconset/Contents.json": json.dumps(appicon_contents, indent=2) + "\n",
        "Assets.xcassets/AccentColor.colorset/Contents.json": json.dumps(accent_contents, indent=2) + "\n",
    }


def write_if_changed(path: pathlib.Path, content: str) -> bool:
    if path.exists() and path.read_text(encoding="utf-8") == content:
        return False
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8", newline="\n")
    return True


def main() -> int:
    project_dir = ROOT / f"{PROJECT_NAME}.xcodeproj"
    changes: list[str] = []

    if write_if_changed(project_dir / "project.pbxproj", build_pbxproj()):
        changes.append(f"{PROJECT_NAME}.xcodeproj/project.pbxproj")
    if write_if_changed(project_dir / "project.xcworkspace" / "contents.xcworkspacedata",
                        "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
                        "<Workspace version = \"1.0\">\n"
                        "   <FileRef location = \"self:\">\n"
                        "   </FileRef>\n"
                        "</Workspace>\n"):
        changes.append(f"{PROJECT_NAME}.xcodeproj/project.xcworkspace/contents.xcworkspacedata")
    if write_if_changed(project_dir / "xcshareddata" / "xcschemes" / f"{PROJECT_NAME}.xcscheme", build_scheme()):
        changes.append(f"{PROJECT_NAME}.xcodeproj/xcshareddata/xcschemes/{PROJECT_NAME}.xcscheme")

    resources = ROOT / PROJECT_NAME / "Resources"
    if write_if_changed(resources / "Info.plist", plistlib.dumps(build_info_plist()).decode("utf-8")):
        changes.append(f"{PROJECT_NAME}/Resources/Info.plist")
    if write_if_changed(resources / "Entitlements" / f"{PROJECT_NAME}.entitlements",
                        plistlib.dumps(build_entitlements()).decode("utf-8")):
        changes.append(f"{PROJECT_NAME}/Resources/Entitlements/{PROJECT_NAME}.entitlements")

    for relative, content in build_asset_catalog().items():
        if write_if_changed(resources / relative, content):
            changes.append(f"{PROJECT_NAME}/Resources/{relative}")

    if changes:
        for change in changes:
            print(f"[generate] wrote {change}")
    else:
        print("[generate] everything already up to date")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
