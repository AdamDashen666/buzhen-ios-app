#!/usr/bin/env python3
"""Diagnostic: dump the Mach-O load commands of an IPA's executable.

Written to explain why `tools/verify_ipa_py.py` could not find `LC_BUILD_VERSION` in
a binary that is unmistakably an iOS arm64 app. Run it when a platform check needs
to be explained rather than asserted.

Run:  python tools/inspect_macho.py dist/HTMLRunner.ipa
"""
from __future__ import annotations

import pathlib
import struct
import sys
import zipfile

COMMAND_NAMES = {
    0x01: "LC_SEGMENT",
    0x02: "LC_SYMTAB",
    0x0B: "LC_DYSYMTAB",
    0x0C: "LC_LOAD_DYLIB",
    0x0D: "LC_ID_DYLIB",
    0x18: "LC_LOAD_WEAK_DYLIB",
    0x19: "LC_SEGMENT_64",
    0x1B: "LC_UUID",
    0x1D: "LC_CODE_SIGNATURE",
    0x1E: "LC_SEGMENT_SPLIT_INFO",
    0x20: "LC_LAZY_LOAD_DYLIB",
    0x21: "LC_ENCRYPTION_INFO",
    0x22: "LC_DYLD_INFO",
    0x23: "LC_DYLD_INFO_ONLY",
    0x24: "LC_VERSION_MIN_MACOSX",
    0x25: "LC_VERSION_MIN_IPHONEOS",
    0x26: "LC_FUNCTION_STARTS",
    0x29: "LC_DATA_IN_CODE",
    0x2A: "LC_SOURCE_VERSION",
    0x2B: "LC_DYLIB_CODE_SIGN_DRS",
    0x2C: "LC_ENCRYPTION_INFO_64",
    0x2D: "LC_LINKER_OPTION",
    0x2E: "LC_LINKER_OPTIMIZATION_HINT",
    0x2F: "LC_VERSION_MIN_TVOS",
    0x30: "LC_VERSION_MIN_WATCHOS",
    0x32: "LC_BUILD_VERSION",
    0x33: "LC_DYLD_EXPORTS_TRIE",
    0x34: "LC_DYLD_CHAINED_FIXUPS",
    0x80000022: "LC_DYLD_INFO_REQ",
    0x80000028: "LC_MAIN",
    0x8000002A: "LC_SOURCE_VERSION_REQ",
    0x80000033: "LC_FUNCTION_STARTS_REQ",
    0x80000034: "LC_DATA_IN_CODE_REQ",
    0x80000035: "LC_CODE_SIGNATURE_REQ",
    0x80000036: "LC_SEGMENT_SPLIT_INFO_REQ",
    0x80000037: "LC_DYLIB_CODE_SIGN_DRS_REQ",
    0x80000038: "LC_LINKER_OPTIMIZATION_HINT_REQ",
    0x80000039: "LC_VERSION_MIN_MACOSX_REQ",
}


def main() -> int:
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except (AttributeError, ValueError):
            pass

    target = sys.argv[1] if len(sys.argv) > 1 else "dist/HTMLRunner.ipa"
    path = pathlib.Path(target)
    if path.suffix.lower() == ".ipa":
        import plistlib

        with zipfile.ZipFile(path) as archive:
            # Ask the bundle which file is the executable (`CFBundleExecutable`) rather
            # than guessing from the entry list. Guessing by depth/extension picked
            # `DiagnosticBridge.js` first — a plausible-looking answer that was wrong.
            app_prefix = next(info.filename for info in archive.infolist()
                              if info.filename.startswith("Payload/")
                              and info.filename.count("/") == 2
                              and info.filename.endswith(".app/"))
            info = plistlib.loads(archive.read(app_prefix + "Info.plist"))
            executable = info.get("CFBundleExecutable")
            if not executable:
                raise SystemExit("Info.plist 中没有 CFBundleExecutable")
            binary_name = app_prefix + executable
            blob = archive.read(binary_name)
            print(f"app      : {app_prefix}")
            print(f"executable: {executable}")
    else:
        blob = path.read_bytes()

    # struct mach_header_64 { uint32 magic; cpu_type_t cputype; cpu_subtype_t cpusubtype;
    #                         uint32 filetype; uint32 ncmds; uint32 sizeofcmds; uint32 flags; }
    # That is 7 x uint32 = 28 bytes, so `ncmds` lives at byte 16 and the load-command
    # table begins at byte 32 (the 64-bit header adds a 4-byte `reserved` field).
    magic, cputype, cpusubtype, filetype, ncmds, sizeofcmds, flags = struct.unpack(
        "<IiiIIII", blob[:28])
    print(f"magic=0x{magic:08x}  cputype=0x{cputype:08x}  filetype={filetype}")
    print(f"ncmds={ncmds}  sizeofcmds={sizeofcmds}  flags=0x{flags:08x}  file={len(blob)} bytes")

    offset = 32
    seen: dict[int, int] = {}
    platforms: list[tuple[int, int]] = []
    for index in range(ncmds):
        if offset + 8 > len(blob):
            print(f"  !! ran past end of file at command {index} (offset {offset})")
            break
        command, command_size = struct.unpack("<II", blob[offset:offset + 8])
        seen[command] = seen.get(command, 0) + 1
        if command in (0x32, 0x25, 0x24, 0x2F, 0x30) and offset + 12 <= len(blob):
            if command == 0x32:
                platform = struct.unpack("<I", blob[offset + 8:offset + 12])[0]
                platforms.append((command, platform))
            else:
                platforms.append((command, 2 if command in (0x25, 0x2F, 0x30) else 1))
        if command_size < 8:
            print(f"  !! zero/absurd command size ({command_size}) at offset {offset}")
            break
        offset += command_size

    print("\nload commands:")
    for command, count in sorted(seen.items()):
        print(f"  0x{command:08x}  {COMMAND_NAMES.get(command, '?'):36} x{count}")
    print("\nplatform-bearing commands:")
    if platforms:
        for command, platform in platforms:
            print(f"  {COMMAND_NAMES.get(command)} platform={platform}")
    else:
        print("  (none found in the load-command table)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
