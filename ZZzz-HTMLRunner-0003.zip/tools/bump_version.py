#!/usr/bin/env python3
"""Bump the app version everywhere it is recorded.

Used when a rebuild must be distinguishable from an already-installed build: the IPA
filename, the CI zip name, `CFBundleVersion`, and the checksum manifest all have to
agree, and doing it by hand is how a stale version number survives into a release.

Run:  python tools/bump_version.py 1.0.1 3
      (marketing version, build number)
"""
from __future__ import annotations

import pathlib
import re
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent

# The CI zip name must sort AFTER every other root-level zip in the target repository,
# because the builder selects `find . -maxdepth 1 -name "*.zip" | sort -V | tail -n 1`.
#
# The name is a single zero-padded sequence number rather than a dotted version: a
# dotted form such as `1.000.001` invites the reader to mistake the padding for a real
# version component, and a monotonic counter avoids the classic lexical trap where
# `1.0.10` sorts before `1.0.9` under a plain `sort`. `sort -V` handles that, but the
# simpler name removes the question entirely.
ZIP_TEMPLATE = "ZZzz-HTMLRunner-{sequence}.zip"
ZIP_SEQUENCE_WIDTH = 4


def zip_name_for(build: str) -> str:
    """Sequence number for the archive name, derived from the build number."""
    try:
        sequence = int(build)
    except ValueError:
        sequence = 0
    return ZIP_TEMPLATE.format(sequence=f"{sequence:0{ZIP_SEQUENCE_WIDTH}d}")


def replace_once(path: pathlib.Path, pattern: str, replacement: str) -> bool:
    text = path.read_text(encoding="utf-8")
    updated, count = re.subn(pattern, replacement, text, count=1)
    if count:
        path.write_text(updated, encoding="utf-8", newline="\n")
    return bool(count)


def main() -> int:
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except (AttributeError, ValueError):
            pass

    if len(sys.argv) < 3:
        print(__doc__)
        return 2
    marketing, build = sys.argv[1], sys.argv[2]
    zip_name = zip_name_for(build)

    changes: list[str] = []

    package = ROOT / "tools" / "package_zip.py"
    if replace_once(package, r'VERSION = "[^"]+"', f'VERSION = "{marketing}"'):
        changes.append(f"package_zip.py VERSION = {marketing}")
    if replace_once(package, r'CI_ZIP_NAME = "[^"]+"', f'CI_ZIP_NAME = "{zip_name}"'):
        changes.append(f"package_zip.py CI_ZIP_NAME = {zip_name}")

    builder = ROOT / "tools" / "build_via_github.py"
    if replace_once(builder, r'DEFAULT_ZIP_NAME = "[^"]+"', f'DEFAULT_ZIP_NAME = "{zip_name}"'):
        changes.append(f"build_via_github.py DEFAULT_ZIP_NAME = {zip_name}")

    generator = ROOT / "tools" / "generate_project.py"
    if replace_once(generator, r'MARKETING_VERSION = "[^"]+"', f'MARKETING_VERSION = "{marketing}"'):
        changes.append(f"generate_project.py MARKETING_VERSION = {marketing}")
    if replace_once(generator, r'CURRENT_PROJECT_VERSION = "[^"]+"',
                    f'CURRENT_PROJECT_VERSION = "{build}"'):
        changes.append(f"generate_project.py CURRENT_PROJECT_VERSION = {build}")

    for change in changes:
        print(f"[bump] {change}")
    if not changes:
        print("[bump] 没有改动（版本已相同？）")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
