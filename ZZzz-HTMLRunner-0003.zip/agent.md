# agent.md — 项目交接说明

## 项目目标

面向 iPad 的 HTML / WebGL 游戏运行器：Swift + SwiftUI + 系统 WKWebView。
导入任意本地 HTML 项目 → 全屏运行 → 提供诊断能力。**不重写游戏代码，不引入第三方浏览器引擎。**

交付要求：源码 + 可侧载的 `.ipa` + 完整文档。用户目标设备是 iPad Pro 11" M4 / iPadOS 27，
用第三方签名工具（NB 助手）安装，并关注 JIT 相关行为。

## 当前状态（2026-10-12）

**代码完成、IPA 已构建并通过校验；本机是 Windows，构建在 GitHub 的 macOS runner 上完成。**

* `HTMLRunner/` — 22 个 Swift 文件、约 6,999 行；2 个打包进 App 的 JS 脚本；零第三方依赖。
* `HTMLRunner.xcodeproj` — 由 `tools/generate_project.py` 生成，Xcode 16 同步组（新增 .swift 自动纳入编译）。
  Bundle ID `com.htmlrunner.ipad`，仅 iPad，部署目标 iOS 17.0，Release 不带 entitlements，Debug 只带 `get-task-allow`。
* `mac/` — macOS 上的构建与打包（已通过 `bash -n` 与 `--dry-run`，**从未在 macOS 上真正执行过**）。
* 文档：`README.md`、`BUILD.md`、`CHANGELOG.md`、`DELIVERY-REPORT.md`、`docs/TEST-PLAN.md`、
  `HTMLRunner/JIT_NOTES.md`（JIT 研究，已交叉复核关键结论）。
* 交付物：`dist/HTMLRunner-source-1.0.0.zip` + `HTMLRunner-FILE-MANIFEST.json` + `SHA256SUMS.txt`
  （由 `tools/package_zip.py` 生成，由 `tools/verify_dist.py` 独立校验）。

**6 个验证套件全部通过**；测试计划 13 项中 8 项 `ran-webkit` / 4 项 `static-check` / 1 项 `not-run`。
**模拟器从未运行，真机从未运行，IPA 从未生成。**

## 环境硬约束（不要浪费时间重新试探）

本机是 **Windows 11，没有 macOS、Xcode、Swift 工具链、iOS SDK、iOS 模拟器、签名证书、连接的 iPad**，
也没有 WSL / Docker / SSH 到 Mac 的通道。**iOS 应用无法在此编译，也不存在合法替代方案。**
`xcodebuild` 不存在，`dist/HTMLRunner.ipa` 从未生成——不要创建空文件或占位 IPA 冒充它。

本机**可用**的工具：Python 3.10、Node 24、npm、7-Zip、Git，以及**已缓存的 Playwright WebKit 浏览器**
（`~/AppData/Local/ms-playwright/webkit-2359`，playwright-core 1.64 需要用 `executablePath` 显式指定，
默认版本号不匹配）。这是本机唯一能真实执行网页代码的引擎，也是测试夹具的基础。

## 验证入口

```bash
python project-tests/run_all.py        # 6 个套件全跑，生成 test-output/TEST-REPORT.json
python tools/check_swift.py            # Swift 结构检查（括号/字符串/#if/重复声明/遗漏的构造调用/未引用的类型）
python tools/verify_project.py         # Xcode 工程与资源校验（90 项）
python tools/verify_pbxproj.py         # 构建配置一致性 + 确认 pbxproj 未被手工改过
node   project-tests/harness/logic.test.js   # 52 项纯逻辑测试（Swift 算法的可执行规格）
python project-tests/run_tests.py      # 12 个 HTML 夹具，桌面 WebKit 驱动
python tools/package_zip.py            # 生成 dist/ 的 ZIP、清单与 SHA256SUMS.txt
python tools/verify_dist.py            # 校验刚打好的交付物（哈希、条目安全、必需文件）
python tools/sync_doc_counts.py --check  # 文档里的文件数/行数是否与代码一致
```

`tools/check_swift.py` 的括号检查依赖一个模式栈词法器（处理 `"\(a ?? "b")"` 这类嵌套）。
如果它开始报大量假阳性，先跑 `python tools/debug_swift_tokenizer.py <文件>`，
它会指出词法器在哪里失去同步——不要再去猜。

**改完代码后必须重跑 `tools/sync_doc_counts.py` 并重新 `package_zip.py`**，否则文档里的行数与
`dist/` 的哈希会过期（`verify_dist.py` 会因此失败——这是有意设计的门禁）。

## 关键设计决策（改动前请先理解理由）

1. **不伪造能力。** 读不到的数值一律 `nil` + 显示「无法获取」，绝不用 0 冒充。
   诊断页与日志明确区分「测量事实」与「间接证据」。任何改动都必须保持这一点。
2. **`WebProbe.js` 发布 `__HTMLRUNNER_PROBE_RUN__`，不自调用。** Swift 侧先求值该文件、再显式调用。
   曾经的写法 `return (<file>)(opts)` 会抛 `SyntaxError`，因为文件自身已自调用——已由夹具 11 捕获。
   改回自调用形式会立刻破坏「探测」功能。
3. **`tools/verify_project.py` 与 `tools/check_swift.py` 是替代编译器。**
   本机没有 Swift 编译器，这两个脚本是唯一能机械发现结构错误的手段。新增 Swift 文件必须落在
   `HTMLRunner/{App,Views,Web,FileManagement,Diagnostics,Settings,Resources}` 之内（同步组范围内），
   否则不会被编译，`verify_project.py` 会报错。
4. **`logic.test.js` 是 Swift 算法的可执行规格。** 修改 `LocalHTTPServer.swift` 或 `ProjectStore.swift`
   的算法时，必须同步修改这个文件里对应的 JS 实现，否则两份实现会悄悄漂移。
5. **`mac/` 是 macOS 专属目录。** 脚本假设 cwd 是仓库根、以 `bash mac/xxx.sh` 方式调用（不需要可执行位）。
   不要为了「让它在 Windows 上也能跑」而改写它们。
6. **`project-tests/fixtures/` 不在 Xcode 目标内**，是审查用产物；`HTMLRunner/Resources/Web/*.js` 才打包进 App。
   夹具 11 通过测试服务器的 `/__app__/` 挂载点加载**真实**的那两个脚本，因此不可能测到过期副本。
7. **本地 HTTP 服务是可选功能。** 默认 `file://`；服务只绑 127.0.0.1、随机端口、只暴露当前项目根目录。
   没有加 `com.apple.security.network.server` entitlement，且不应添加。

## JIT —— 已经查清，不要再重复调研

两条核心结论都已对着**一手源码**复核过（见 `HTMLRunner/JIT_NOTES.md`）：

* WebKit 的 `Source/WebKit/Scripts/process-entitlements.sh` 给 iOS 的 `com.apple.WebKit.WebContent`
  写入 `com.apple.private.verified-jit`，并在 `SDK_VERSION_ACTUAL >= 170400` 时写
  `com.apple.developer.cs.allow-jit`（更早是 `dynamic-codesigning`）；
  而 `com.apple.WebKit.WebContent.Development` 在 iOS 上**不写任何 entitlement**。
  → 网页的执行权限由 Apple 签名的系统进程决定，**App 无法授予，也不需要授予**。
* PojavLauncher `Natives/utils.m` 的 `isJITEnabled()` 检查 `dynamic-codesigning` 或
  `csops(getpid(),0,&f,…) & CS_DEBUGGED` → 侧载工具的「开 JIT」作用于**被附加的 App 进程**。

**由此得出的产品结论（不要改写成更乐观的说法）：** 给 HTMLRunner 开 JIT **不会**让 WKWebView 里的
Three.js 更快；能真正改变网页 JS 执行方式的只有**系统锁定模式**（它会同时关掉 JIT 与 WebAssembly）。
网页侧没有任何公开 API 能判定 JIT 状态；唯一有对照意义的实验是锁定模式开/关各跑一次。

## 已知阻塞与未完成事项

* **阻塞**：未生成 IPA、未在模拟器/真机运行、未做真机内存与稳定性测试、
  未验证安装后是否出现在侧载工具的 JIT 列表中。全部需要 macOS / 真机。
* **未实现**：测试计划第 12 项（长时间稳定性）；第 9、10、11、13 项中的真机部分。
* **代码层面**：`SWIFT_STRICT_CONCURRENCY = minimal` 是有意选择；若提升到 `complete`，
  需要重新审视 WebKit delegate 与 Network 回调的隔离标注。`LocalHTTPServer` 禁用了 keep-alive（有意的简化）。

## 下一步（按优先级）

1. **在 macOS 上构建**：`bash mac/build.sh` → `bash mac/verify_ipa.sh dist/HTMLRunner.ipa`。
   没有 Mac 时，把 `mac/ci-github-actions.yml` 复制到 `.github/workflows/build-ipa.yml` 用 GitHub 的
   macOS runner 产出未签名 IPA（不需要任何密钥）。
2. **真机验收**：按 `docs/TEST-PLAN.md` 第四节的清单逐项执行，重点是第 9、10、11、13 项。
3. **只有在那之后**，才考虑根据真机数据调整 WebKit 配置——并且必须留下基准数据作为依据。
