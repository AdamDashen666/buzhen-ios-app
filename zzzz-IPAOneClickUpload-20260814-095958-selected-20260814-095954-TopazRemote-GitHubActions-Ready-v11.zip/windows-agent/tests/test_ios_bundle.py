from __future__ import annotations

import plistlib
import unittest
from pathlib import Path


class IOSBundleTests(unittest.TestCase):
    def test_ats_allows_the_paired_tailscale_agent_only(self) -> None:
        root = Path(__file__).resolve().parents[2]
        plist = plistlib.loads((root / "ios" / "TopazRemote" / "Resources" / "Info.plist").read_bytes())
        ats = plist["NSAppTransportSecurity"]

        self.assertNotIn("NSAllowsLocalNetworking", ats)
        self.assertEqual(
            ats["NSExceptionDomains"]["desktop-inn4klw-1.taildee45d.ts.net"]["NSTemporaryExceptionAllowsInsecureHTTPLoads"],
            True,
        )
