from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from topazremote.discovery import discover_capabilities


class DiscoveryTests(unittest.TestCase):
    def test_marks_models_seen_only_in_local_logs_as_unavailable_until_probed(self) -> None:
        """A historical export proves syntax, not that its model package is installed today."""
        with tempfile.TemporaryDirectory() as temp:
            executable = Path(temp) / "ffmpeg.exe"; executable.write_bytes(b"placeholder")
            log = Path(temp) / "recent.tzlog"
            log.write_text('Info CMD: ffmpeg -vf tvai_fi=model=apo-8:fps=60:download=0\n')
            detected = discover_capabilities(
                executable,
                logs_root=Path(temp),
                model_config_root=Path(temp) / "models",
                model_data_root=Path(temp) / "payloads",
                help_reader=lambda _: """Filter tvai_fi\ntvai_fi AVOptions:\n   fps <video_rate> output's frame rate\n   slowmo <double> (from 0.1 to 16)\n""",
            )
        interpolation = detected["interpolationModels"]
        self.assertEqual(interpolation[0]["id"], "apo-8")
        self.assertEqual(interpolation[0]["source"], "detected-log")
        self.assertFalse(interpolation[0]["available"])
        self.assertEqual(interpolation[0]["parameters"][0]["id"], "fps")
        self.assertEqual(interpolation[0]["parameters"][0]["max"], 480)

    def test_returns_filter_contract_even_when_no_local_model_is_observed(self) -> None:
        """Filter discovery must remain useful without guessing a model ID or causing a model download."""
        with tempfile.TemporaryDirectory() as temp:
            executable = Path(temp) / "ffmpeg.exe"; executable.write_bytes(b"placeholder")
            detected = discover_capabilities(executable, logs_root=Path(temp), help_reader=lambda _: "Filter tvai_up\nscale <int> (from 0 to 4)\n")
        self.assertEqual(detected["filterSupport"]["tvai_up"]["scale"]["max"], 4)
        self.assertEqual(detected["enhancementModels"], [])

    def test_discovers_installed_neuroserver_model(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            executable = root / "Topaz Video" / "ffmpeg.exe"
            neuroserver = executable.parent / "neuroserver" / "neuroserver.exe"
            model_root = root / "ProgramData" / "models"
            executable.parent.mkdir(parents=True); executable.write_bytes(b"ffmpeg")
            neuroserver.parent.mkdir(parents=True); neuroserver.write_bytes(b"neuroserver")
            (neuroserver.parent / "models" / "slp25").mkdir(parents=True)
            model_root.mkdir(parents=True)
            (model_root / "slp-2.5.json").write_text('{"name":"Starlight SLP-2.5","isNeuroserverModel":true}')

            detected = discover_capabilities(executable, logs_root=root / "logs", model_config_root=model_root)

        self.assertEqual(detected["enhancementModels"], [{
            "id": "slp-2.5", "displayName": "Starlight SLP-2.5", "available": True,
            "parameters": [{"id": "scale", "displayName": "Scale", "type": "integer", "min": 1, "max": 4}],
            "executor": "neuroserver", "executorModel": "slp-25",
        }])

    def test_discovers_installed_legacy_interpolation_model_from_payload(self) -> None:
        """A .tz3 payload must make its matching frame model available even without an export log."""
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            executable = root / "ffmpeg.exe"; executable.write_bytes(b"ffmpeg")
            config_root = root / "models"; config_root.mkdir()
            config_root.joinpath("apo-8.json").write_text(
                '{"displayName":"Apollo 8","shortName":"apo","version":"8","changesFPS":1}'
            )
            payload_root = root / "payloads"; payload_root.mkdir()
            payload_root.joinpath("apo-v8-fp16-1088x1056-ox.tz3").write_bytes(b"model")

            detected = discover_capabilities(
                executable,
                logs_root=root / "logs",
                model_config_root=config_root,
                model_data_root=payload_root,
                help_reader=lambda _: "Filter tvai_fi\nfps <video_rate> output's frame rate\n",
            )

        self.assertEqual(detected["interpolationModels"], [{
            "id": "apo-8", "displayName": "Apollo 8", "available": True,
            "parameters": [{"id": "fps", "displayName": "Output FPS", "min": 1, "max": 480, "type": "number"}],
            "source": "installed-payload",
        }])


if __name__ == "__main__":
    unittest.main()
