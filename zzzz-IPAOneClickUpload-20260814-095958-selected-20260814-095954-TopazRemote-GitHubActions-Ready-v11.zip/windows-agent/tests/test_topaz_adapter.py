from __future__ import annotations

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from topazremote.topaz_adapter import TopazFfmpegAdapter, TopazValidationError


class TopazAdapterTests(unittest.TestCase):
    def setUp(self) -> None: self.adapter = TopazFfmpegAdapter(Path("C:/Topaz/ffmpeg.exe"), {"enhancementModels": [{"id": "prob-4"}], "interpolationModels": [{"id": "chr-2"}]})
    def test_builds_allowlisted_enhancement_argv_with_download_disabled(self) -> None:
        """Allowing model downloads or shell composition could alter Topaz or execute unintended commands."""
        command = self.adapter.build_command(Path("C:/input clip.mp4"), Path("C:/output clip.mp4"), {"enhancement": {"model": "prob-4", "scale": 2}})
        self.assertEqual(command[0], "C:\\Topaz\\ffmpeg.exe")
        self.assertIn("tvai_up=model=prob-4:scale=2:download=0", command)
        self.assertEqual(command[-1], "C:\\output clip.mp4")
    def test_rejects_unknown_model_before_process_start(self) -> None:
        """Passing arbitrary filter text would bypass the dynamic capability contract."""
        with self.assertRaises(TopazValidationError): self.adapter.build_command(Path("C:/in.mp4"), Path("C:/out.mp4"), {"enhancement": {"model": "prob-4:evil=1"}})

    def test_rejects_model_not_verified_as_available(self) -> None:
        """A historical Topaz log must not turn a missing local model package into a runnable job."""
        adapter = TopazFfmpegAdapter(Path("C:/Topaz/ffmpeg.exe"), {
            "enhancementModels": [{"id": "prob-4", "available": False, "parameters": []}],
            "interpolationModels": [],
        })
        with self.assertRaises(TopazValidationError):
            adapter.build_command(Path("C:/in.mp4"), Path("C:/out.mp4"), {"enhancement": {"model": "prob-4", "scale": 1}})
    def test_can_chain_interpolation_after_enhancement(self) -> None:
        """Dropping the second filter would silently ignore a requested frame interpolation stage."""
        command = self.adapter.build_command(Path("C:/in.mp4"), Path("C:/out.mp4"), {"enhancement": {"model": "prob-4", "scale": 1}, "interpolation": {"model": "chr-2", "fps": 60}})
        self.assertIn("tvai_up=model=prob-4:scale=1:download=0,tvai_fi=model=chr-2:fps=60:download=0", command)

    def test_builds_observed_neuroserver_command_for_installed_slp_model(self) -> None:
        adapter = TopazFfmpegAdapter(Path("C:/Topaz/ffmpeg.exe"), {
            "enhancementModels": [{"id": "slp-2.5", "available": True, "executor": "neuroserver", "executorModel": "slp-25", "parameters": []}],
            "interpolationModels": [],
        }, video_probe=lambda _: (1920, 1080, 120))
        command = adapter.build_command(Path("C:/in.mp4"), Path("C:/out.mp4"), {"enhancement": {"model": "slp-2.5", "scale": 2}})
        self.assertEqual(command[0], "C:\\Topaz\\neuroserver\\neuroserver.exe")
        self.assertEqual(command[command.index("--filters") + 1], '[{"model":"slp-25"}]')
        self.assertEqual(command[command.index("--output-width") + 1], "3840")
        self.assertEqual(command[command.index("--end-frame-idx") + 1], "119")

    def test_forwards_capability_validated_dynamic_parameter_to_filter(self) -> None:
        """A value selected in the iOS dynamic form must reach the Topaz argv rather than being display-only."""
        adapter = TopazFfmpegAdapter(Path("C:/Topaz/ffmpeg.exe"), {
            "enhancementModels": [{"id": "prob-4", "parameters": [{"id": "noise", "type": "number", "min": -1, "max": 1}]}],
            "interpolationModels": [],
        })
        command = adapter.build_command(Path("C:/in.mp4"), Path("C:/out.mp4"), {"enhancement": {"model": "prob-4", "scale": 1, "noise": 0.25}})
        self.assertIn("tvai_up=model=prob-4:scale=1:noise=0.25:download=0", command)

    def test_rejects_dynamic_parameter_outside_capability_range(self) -> None:
        """Unvalidated dynamic form data must not be forwarded to the local FFmpeg filter."""
        adapter = TopazFfmpegAdapter(Path("C:/Topaz/ffmpeg.exe"), {
            "enhancementModels": [{"id": "prob-4", "parameters": [{"id": "noise", "type": "number", "min": -1, "max": 1}]}],
            "interpolationModels": [],
        })
        with self.assertRaises(TopazValidationError):
            adapter.build_command(Path("C:/in.mp4"), Path("C:/out.mp4"), {"enhancement": {"model": "prob-4", "scale": 1, "noise": 2}})


if __name__ == "__main__": unittest.main()
