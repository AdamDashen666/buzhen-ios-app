param(
    [int]$Port = 8123,
    [string]$DataDirectory = "$env:LOCALAPPDATA\TopazRemote",
    [string]$MediaDirectory = (Join-Path ([Environment]::GetFolderPath('Desktop')) (([char]0x8FDC).ToString() + ([char]0x7A0B).ToString() + 'topaz'))
)

$scriptRoot = Split-Path -Parent $PSScriptRoot
$sourceRoot = Join-Path $scriptRoot "src"
if (-not (Test-Path -LiteralPath $sourceRoot)) { throw "Topaz Remote source folder not found: $sourceRoot" }
if ($Port -lt 1024 -or $Port -gt 65535) { throw "Port must be between 1024 and 65535." }
$env:PYTHONPATH = $sourceRoot
python -m topazremote.main --host 0.0.0.0 --port $Port --data-dir $DataDirectory --media-dir $MediaDirectory
