from __future__ import annotations

import hashlib
import os
import re
from pathlib import Path


class StorageError(ValueError):
    pass


class Storage:
    def __init__(self, root: Path, media_root: Path | None = None) -> None:
        self.root = root.resolve()
        self.media_root = (media_root or self.root).resolve()
        self.uploads = self.root / "uploads"
        self.sources = self.media_root
        self.outputs = self.media_root
        self.uploads.mkdir(parents=True, exist_ok=True)
        self.media_root.mkdir(parents=True, exist_ok=True)

    def _upload_dir(self, upload_id: str) -> Path:
        if not re.fullmatch(r"[A-Za-z0-9-]{1,128}", upload_id):
            raise StorageError("invalid upload id")
        return self.uploads / upload_id

    def write_chunk(self, upload_id: str, index: int, body: bytes) -> None:
        if index < 0:
            raise StorageError("invalid chunk index")
        directory = self._upload_dir(upload_id)
        directory.mkdir(parents=True, exist_ok=True)
        temporary = directory / f"{index}.part"
        completed = directory / f"{index}.chunk"
        with temporary.open("wb") as handle:
            handle.write(body)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, completed)

    def complete_upload(self, upload_id: str, filename: str, expected_size: int, expected_sha256: str | None) -> Path:
        if Path(filename).name != filename or filename in {"", ".", ".."}:
            raise StorageError("invalid filename")
        destination = self.sources / filename
        if destination.exists():
            raise StorageError("source filename already exists")
        directory = self._upload_dir(upload_id)
        chunks = sorted(directory.glob("*.chunk"), key=lambda path: int(path.stem))
        if not chunks:
            raise StorageError("upload has no chunks")
        if [int(chunk.stem) for chunk in chunks] != list(range(len(chunks))):
            raise StorageError("upload chunk map is incomplete")
        temporary = self.sources / f".{upload_id}.part"
        digest = hashlib.sha256()
        size = 0
        with temporary.open("wb") as target:
            for chunk in chunks:
                with chunk.open("rb") as source:
                    while data := source.read(1024 * 1024):
                        target.write(data)
                        digest.update(data)
                        size += len(data)
            target.flush()
            os.fsync(target.fileno())
        if size != expected_size or (expected_sha256 and digest.hexdigest().lower() != expected_sha256.lower()):
            temporary.unlink(missing_ok=True)
            raise StorageError("upload integrity validation failed")
        os.replace(temporary, destination)
        for chunk in directory.glob("*"):
            chunk.unlink()
        directory.rmdir()
        return destination
