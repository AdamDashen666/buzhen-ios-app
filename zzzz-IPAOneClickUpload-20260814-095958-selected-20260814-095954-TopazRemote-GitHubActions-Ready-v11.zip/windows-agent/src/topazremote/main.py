from __future__ import annotations

import argparse
import os
from pathlib import Path

from .server import create_server


def default_topaz_ffmpeg(program_files_roots: tuple[Path, ...] | None = None) -> Path:
    if program_files_roots is None:
        program_files_roots = tuple(
            Path(value)
            for value in (
                os.environ.get("ProgramFiles"),
                r"C:\\Program Files",
                r"D:\\Program Files",
            )
            if value
        )
    candidates = tuple(root / "Topaz Labs LLC" / "Topaz Video" / "ffmpeg.exe" for root in program_files_roots)
    return next((candidate for candidate in candidates if candidate.is_file()), candidates[0])


def main() -> int:
    parser = argparse.ArgumentParser(description="Topaz Remote Windows Agent")
    parser.add_argument("--data-dir", type=Path, default=Path.home() / "AppData/Local/TopazRemote")
    parser.add_argument("--media-dir", type=Path, default=Path.home() / "Desktop" / "远程topaz")
    parser.add_argument("--host", default="0.0.0.0"); parser.add_argument("--port", type=int, default=8123)
    default_ffmpeg = default_topaz_ffmpeg()
    parser.add_argument("--topaz-ffmpeg", type=Path, default=default_ffmpeg)
    parser.add_argument("--no-job-execution", action="store_true", help="Expose the API without launching Topaz child processes.")
    args = parser.parse_args()
    server = create_server(args.data_dir, args.host, args.port, None if args.no_job_execution else args.topaz_ffmpeg, media_root=args.media_dir)
    print(f"Topaz Remote Agent listening on {args.host}:{server.server_port}")
    try: server.serve_forever()
    except KeyboardInterrupt: pass
    finally: server.server_close()
    return 0

if __name__ == "__main__": raise SystemExit(main())
