from __future__ import annotations

import json
import uuid
import os
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

from .auth import TokenStore
from .capabilities import merge_capabilities
from .database import Database
from .storage import Storage, StorageError
from .jobs import JobRunner
from .topaz_adapter import TopazFfmpegAdapter
from .worker import TopazProcessWorker
from .discovery import discover_capabilities


UPLOAD_CHUNK_SIZE = 1024 * 1024
MAX_UPLOAD_CHUNK_SIZE = 8 * 1024 * 1024


def _read_json(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    return value if isinstance(value, dict) else {}


def create_server(
    data_root: Path,
    host: str = "127.0.0.1",
    port: int = 8123,
    topaz_ffmpeg: Path | None = None,
    detected_capabilities: dict[str, Any] | None = None,
    media_root: Path | None = None,
) -> ThreadingHTTPServer:
    data_root.mkdir(parents=True, exist_ok=True)
    config_root = Path(__file__).resolve().parents[2] / "config"
    token = TokenStore(data_root / "config" / "auth-token").load_or_create()
    database = Database(data_root / "db" / "agent.sqlite3")
    storage = Storage(data_root, media_root=media_root)
    detected = detected_capabilities if detected_capabilities is not None else (discover_capabilities(topaz_ffmpeg) if topaz_ffmpeg is not None and topaz_ffmpeg.is_file() else {})
    capabilities = merge_capabilities(detected, _read_json(config_root / "fallback-capabilities.json"), _read_json(config_root / "capability-overrides.json"))
    runner: JobRunner | None = None
    if topaz_ffmpeg is not None:
        if not topaz_ffmpeg.is_file():
            raise ValueError("Topaz FFmpeg executable was not found")
        holder: dict[str, JobRunner] = {}
        def worker_finished(job_id: str, succeeded: bool) -> None:
            holder["runner"].finish(job_id, succeeded)
            holder["runner"].start_next()
        worker = TopazProcessWorker(database, storage, TopazFfmpegAdapter(topaz_ffmpeg, capabilities), worker_finished)
        runner = JobRunner(database, worker.start, worker.cancel)
        holder["runner"] = runner
        runner.recover_after_restart()

    class Handler(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"
        def log_message(self, format: str, *args: object) -> None: pass
        def send_json(self, status: int, value: Any) -> None:
            body = json.dumps(value, separators=(",", ":")).encode("utf-8")
            self.send_response(status); self.send_header("Content-Type", "application/json"); self.send_header("Content-Length", str(len(body))); self.end_headers(); self.wfile.write(body)
        def send_empty(self, status: int) -> None:
            self.send_response(status); self.send_header("Content-Length", "0"); self.end_headers()
        def authorized(self) -> bool:
            return self.headers.get("Authorization") == f"Bearer {token}"
        def do_GET(self) -> None:
            if self.path == "/api/v1/health": self.send_json(200, {"status": "ok", "apiVersion": "v1"}); return
            if not self.authorized(): self.send_json(401, {"error": {"code": "AUTH_FAILED", "message": "Bearer token required.", "recoverable": True}}); return
            if self.path == "/api/v1/capabilities": self.send_json(200, {"apiVersion": "v1", "agentVersion": "0.1.0", **capabilities}); return
            if self.path == "/api/v1/system": self.send_json(200, {"apiVersion":"v1", "queueConcurrency":1, "dataDirectory":str(data_root)}); return
            if self.path == "/api/v1/jobs": self.send_json(200, database.list_jobs()); return
            if self.path.startswith("/api/v1/jobs/") and self.path.count("/") == 4:
                try: self.send_json(200, database.get_job(self.path.rsplit("/", 1)[-1]))
                except KeyError: self.send_json(404, {"error":{"code":"NOT_FOUND","message":"Job not found.","recoverable":False}})
                return
            if self.path.startswith("/api/v1/jobs/") and self.path.endswith("/output"):
                try: output = Path(database.get_job(self.path.split("/")[-2])["outputPath"])
                except (KeyError, TypeError): self.send_json(404, {"error":{"code":"OUTPUT_NOT_FOUND","message":"Output not found.","recoverable":True}}); return
                if not output.is_file(): self.send_json(404, {"error":{"code":"OUTPUT_NOT_FOUND","message":"Output not found.","recoverable":True}}); return
                size = output.stat().st_size; start, end = 0, size - 1; range_value = self.headers.get("Range")
                if range_value:
                    try:
                        raw = range_value.removeprefix("bytes="); first, last = raw.split("-", 1); start = int(first); end = int(last) if last else end
                        if start < 0 or end < start or start >= size: raise ValueError()
                        end = min(end, size - 1)
                    except ValueError: self.send_response(416); self.send_header("Content-Range", f"bytes */{size}"); self.send_header("Content-Length", "0"); self.end_headers(); return
                length = end - start + 1; self.send_response(206 if range_value else 200); self.send_header("Content-Type", "video/mp4"); self.send_header("Accept-Ranges", "bytes"); self.send_header("Content-Length", str(length)); self.send_header("Content-Range", f"bytes {start}-{end}/{size}"); self.end_headers()
                with output.open("rb") as file:
                    file.seek(start); remaining = length
                    while remaining:
                        data = file.read(min(1024 * 1024, remaining))
                        if not data: break
                        self.wfile.write(data); remaining -= len(data)
                return
            if self.path.startswith("/api/v1/uploads/"):
                try: self.send_json(200, database.get_upload(self.path.rsplit("/", 1)[-1]))
                except KeyError: self.send_json(404, {"error": {"code":"NOT_FOUND","message":"Upload not found.","recoverable":False}})
                return
            self.send_json(404, {"error": {"code": "NOT_FOUND", "message": "Unknown API path.", "recoverable": False}})
        def body(self) -> bytes:
            return self.rfile.read(int(self.headers.get("Content-Length", "0")))
        def discard_body(self) -> None:
            remaining = int(self.headers.get("Content-Length", "0"))
            while remaining:
                data = self.rfile.read(min(1024 * 1024, remaining))
                if not data: break
                remaining -= len(data)
        def do_POST(self) -> None:
            if not self.authorized(): self.send_json(401, {"error":{"code":"AUTH_FAILED","message":"Bearer token required.","recoverable":True}}); return
            if self.path == "/api/v1/uploads":
                try:
                    payload = json.loads(self.body()); filename, size = payload["filename"], int(payload["size"])
                    if size < 1: raise ValueError()
                except (KeyError, ValueError, json.JSONDecodeError): self.send_json(400, {"error":{"code":"INVALID_UPLOAD","message":"Filename and positive size required.","recoverable":True}}); return
                upload_id = str(uuid.uuid4()); database.create_upload(upload_id, filename, size, payload.get("sha256")); self.send_json(201, {"id":upload_id,"chunkSize":UPLOAD_CHUNK_SIZE}); return
            if self.path == "/api/v1/jobs":
                try:
                    payload = json.loads(self.body()); filename = payload["sourceFilename"]; settings = payload["settings"]
                    source = storage.sources / filename
                    if Path(filename).name != filename or not source.is_file() or not isinstance(settings, dict): raise ValueError()
                except (KeyError, ValueError, json.JSONDecodeError): self.send_json(400, {"error":{"code":"SOURCE_MISSING","message":"A completed Agent source is required.","recoverable":True}}); return
                job_id = database.create_job(filename, settings)
                if runner is not None: runner.start_next()
                self.send_json(201, database.get_job(job_id)); return
            if self.path.startswith("/api/v1/jobs/") and self.path.endswith("/cancel"):
                job_id = self.path.split("/")[-2]
                try:
                    if runner is not None: runner.cancel(job_id)
                    else:
                        job = database.get_job(job_id)
                        if job["status"] == "created": database.set_status(job_id, "cancelled")
                        elif job["status"] == "processing": database.set_status(job_id, "cancel_requested")
                        else: raise ValueError()
                    self.send_json(200, database.get_job(job_id))
                except (KeyError, ValueError): self.send_json(409, {"error":{"code":"JOB_NOT_CANCELLABLE","message":"Job cannot be cancelled in its current state.","recoverable":False}})
                return
            if self.path.endswith("/complete") and self.path.startswith("/api/v1/uploads/"):
                upload_id = self.path.split("/")[-2]
                try:
                    upload = database.get_upload(upload_id); output = storage.complete_upload(upload_id, upload["filename"], upload["size"], upload["sha256"]); database.delete_upload(upload_id); self.send_json(200, {"sourceFilename":output.name})
                except (KeyError, StorageError): self.send_json(400, {"error":{"code":"UPLOAD_INCOMPLETE","message":"Upload integrity validation failed.","recoverable":True}})
                return
            self.send_json(404, {"error":{"code":"NOT_FOUND","message":"Unknown API path.","recoverable":False}})
        def do_PUT(self) -> None:
            if not self.authorized(): self.send_json(401, {"error":{"code":"AUTH_FAILED","message":"Bearer token required.","recoverable":True}}); return
            parts = self.path.split("/")
            if len(parts) == 7 and parts[-2] == "chunks":
                if int(self.headers.get("Content-Length", "0")) > MAX_UPLOAD_CHUNK_SIZE:
                    self.discard_body(); self.send_json(413, {"error":{"code":"CHUNK_TOO_LARGE","message":"Chunk exceeds 8 MiB limit.","recoverable":True}}); return
                try: upload_id, index = parts[-3], int(parts[-1]); database.get_upload(upload_id); storage.write_chunk(upload_id, index, self.body()); database.record_chunk(upload_id, index); self.send_empty(204)
                except (KeyError, ValueError, StorageError): self.send_json(400, {"error":{"code":"INVALID_CHUNK","message":"Invalid upload chunk.","recoverable":True}})
                return
            self.send_json(404, {"error":{"code":"NOT_FOUND","message":"Unknown API path.","recoverable":False}})

    class AgentHttpServer(ThreadingHTTPServer):
        def server_close(self) -> None:
            database.close()
            super().server_close()

    server = AgentHttpServer((host, port), Handler)
    server.token = token  # type: ignore[attr-defined]
    server.database = database  # type: ignore[attr-defined]
    server.storage = storage  # type: ignore[attr-defined]
    server.runner = runner  # type: ignore[attr-defined]
    return server
