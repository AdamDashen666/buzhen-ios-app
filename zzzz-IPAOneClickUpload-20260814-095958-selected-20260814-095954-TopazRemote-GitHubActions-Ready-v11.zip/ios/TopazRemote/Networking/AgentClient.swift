import Foundation

enum AgentClientError: LocalizedError {
    case invalidHost, badResponse(Int), invalidUpload
    var errorDescription: String? { switch self { case .invalidHost: return "Enter a valid PC address without http:// or a path."; case .badResponse(let status): return "The PC returned HTTP \(status)."; case .invalidUpload: return "The Agent returned an invalid upload response." } }
}

struct AgentClient {
    let settings: AgentSettings

    static let agentSession: URLSession = {
        let configuration = URLSessionConfiguration.default
        configuration.timeoutIntervalForRequest = 300
        configuration.timeoutIntervalForResource = 3600
        return URLSession(configuration: configuration)
    }()

    func makeRequest(path: String, method: String = "GET", body: Data? = nil, contentType: String? = "application/json") throws -> URLRequest {
        guard settings.port >= 1024, settings.port <= 65535,
              !settings.host.isEmpty,
              !settings.host.contains("://"),
              !settings.host.contains("/"),
              !settings.host.contains("?"),
              let url = URL(string: "http://\(settings.host):\(settings.port)/api/v1\(path)") else { throw AgentClientError.invalidHost }
        var request = URLRequest(url: url)
        request.httpMethod = method
        request.httpBody = body
        request.timeoutInterval = 300
        request.setValue("Bearer \(settings.token)", forHTTPHeaderField: "Authorization")
        if let contentType { request.setValue(contentType, forHTTPHeaderField: "Content-Type") }
        return request
    }

    func capabilities() async throws -> CapabilityResponse { try await decode(CapabilityResponse.self, request: makeRequest(path: "/capabilities"), accepted: [200]) }
    func jobs() async throws -> [Job] { try await decode([Job].self, request: makeRequest(path: "/jobs"), accepted: [200]) }

    func createUpload(filename: String, size: Int, sha256: String) async throws -> UploadTicket {
        let body = try JSONSerialization.data(withJSONObject: ["filename": filename, "size": size, "sha256": sha256])
        return try await decode(UploadTicket.self, request: makeRequest(path: "/uploads", method: "POST", body: body), accepted: [201])
    }

    func uploadChunk(uploadID: String, index: Int, data: Data) async throws {
        let request = try makeRequest(path: "/uploads/\(uploadID)/chunks/\(index)", method: "PUT", body: data, contentType: "application/octet-stream")
        let (_, response) = try await Self.agentSession.data(for: request)
        guard let http = response as? HTTPURLResponse, http.statusCode == 204 else { throw AgentClientError.badResponse((response as? HTTPURLResponse)?.statusCode ?? -1) }
    }

    func completeUpload(uploadID: String) async throws -> CompletedUpload {
        try await decode(CompletedUpload.self, request: makeRequest(path: "/uploads/\(uploadID)/complete", method: "POST", body: Data("{}".utf8)), accepted: [200])
    }

    func uploadStatus(uploadID: String) async throws -> UploadStatus {
        try await decode(UploadStatus.self, request: makeRequest(path: "/uploads/\(uploadID)"), accepted: [200])
    }

    func createJob(sourceFilename: String, settings: [String: Any]) async throws -> Job {
        let body = try JSONSerialization.data(withJSONObject: ["sourceFilename": sourceFilename, "settings": settings])
        return try await decode(Job.self, request: makeRequest(path: "/jobs", method: "POST", body: body), accepted: [201])
    }

    func cancelJob(id: String) async throws -> Job {
        try await decode(Job.self, request: makeRequest(path: "/jobs/\(id)/cancel", method: "POST", body: Data("{}".utf8)), accepted: [200])
    }

    func outputRequest(jobID: String) throws -> URLRequest { try makeRequest(path: "/jobs/\(jobID)/output", contentType: nil) }

    private func decode<T: Decodable>(_ type: T.Type, request: URLRequest, accepted: Set<Int>) async throws -> T {
        let (data, response) = try await Self.agentSession.data(for: request)
        let status = (response as? HTTPURLResponse)?.statusCode ?? -1
        guard accepted.contains(status) else { throw AgentClientError.badResponse(status) }
        do { return try JSONDecoder().decode(T.self, from: data) } catch { throw AgentClientError.invalidUpload }
    }
}
