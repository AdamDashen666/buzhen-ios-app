# Version Notes — v7.2 / Build 63

This version restores the intended "0 = infinite" behavior for return/rework loops.

## Main change
The workflow engine no longer exits because of an internal hard-coded 3-return protection. It only exits for return count when the user explicitly sets a maximum return count above 0.

## Also fixed
- No automatic token ceiling increases are added by the engine.
- Module max token settings are respected exactly.
- Loop warnings remain visible in logs, but do not stop infinite workflows.

## Verification
- ZIP integrity checked.
- Xcode project included.
- Info.plist version updated to 7.2 / Build 63.
- Swift parse checked.
