import Foundation
import WebKit
import UIKit

final class WebViewPool: NSObject, WKNavigationDelegate, WKUIDelegate {
    weak var store: BrowserStore?
    private struct GroupWebContext {
        let processPool: WKProcessPool
        let dataStore: WKWebsiteDataStore
    }

    private var webViews: [UUID: WKWebView] = [:]
    private var tabIDsByWebView: [ObjectIdentifier: UUID] = [:]
    private var progressObservers: [UUID: NSKeyValueObservation] = [:]
    private var urlObservers: [UUID: NSKeyValueObservation] = [:]
    private var titleObservers: [UUID: NSKeyValueObservation] = [:]
    private var loadingObservers: [UUID: NSKeyValueObservation] = [:]
    private var groupContexts: [UUID: GroupWebContext] = [:]

    static let desktopSafariUserAgent = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Safari/605.1.15"
    static let desktopEdgeUserAgent = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36 Edg/124.0.0.0"

    @discardableResult
    func prepareGroupStorage(groupID: UUID) -> Bool {
        _ = context(for: groupID)
        return true
    }

    private func context(for groupID: UUID) -> GroupWebContext {
        if let context = groupContexts[groupID] { return context }
        let context = GroupWebContext(
            processPool: WKProcessPool(),
            dataStore: WKWebsiteDataStore.nonPersistent()
        )
        groupContexts[groupID] = context
        return context
    }

    private func groupID(for tabID: UUID) -> UUID? {
        store?.tabs.first(where: { $0.id == tabID })?.groupID
    }

    private static func purgeWebsiteData(from dataStore: WKWebsiteDataStore) {
        let dataTypes = WKWebsiteDataStore.allWebsiteDataTypes()
        dataStore.httpCookieStore.getAllCookies { cookies in
            cookies.forEach { cookie in
                dataStore.httpCookieStore.delete(cookie, completionHandler: nil)
            }
        }
        dataStore.fetchDataRecords(ofTypes: dataTypes) { records in
            dataStore.removeData(ofTypes: dataTypes, for: records, completionHandler: {})
        }
        dataStore.removeData(ofTypes: dataTypes, modifiedSince: .distantPast, completionHandler: {})
    }

    func resetGroupStorage(groupID: UUID) {
        if let context = groupContexts.removeValue(forKey: groupID) {
            Self.purgeWebsiteData(from: context.dataStore)
        }
    }

    func resetAllStorageContexts() {
        let contexts = Array(groupContexts.values)
        groupContexts.removeAll()
        contexts.forEach { Self.purgeWebsiteData(from: $0.dataStore) }
    }

    func webView(for tabID: UUID, initialURL: String) -> WKWebView {
        if let existing = webViews[tabID] { return existing }
        let configuration = WKWebViewConfiguration()
        configuration.defaultWebpagePreferences.allowsContentJavaScript = true
        configuration.defaultWebpagePreferences.preferredContentMode = .desktop
        configuration.preferences.javaScriptCanOpenWindowsAutomatically = true
        configuration.allowsInlineMediaPlayback = true
        configuration.mediaTypesRequiringUserActionForPlayback = []
        configuration.applicationNameForUserAgent = "Version/18.0 Safari/605.1.15"
        if let groupID = groupID(for: tabID) {
            let context = context(for: groupID)
            configuration.processPool = context.processPool
            configuration.websiteDataStore = context.dataStore
        } else {
            configuration.websiteDataStore = .nonPersistent()
        }
        let controller = WKUserContentController()
        controller.addUserScript(WKUserScript(source: Self.autoConsentScript, injectionTime: .atDocumentStart, forMainFrameOnly: false))
        controller.addUserScript(WKUserScript(source: Self.autoConsentScript, injectionTime: .atDocumentEnd, forMainFrameOnly: false))
        controller.addUserScript(WKUserScript(source: Self.agentBridgeScript, injectionTime: .atDocumentEnd, forMainFrameOnly: false))
        configuration.userContentController = controller

        let webView = WKWebView(frame: .zero, configuration: configuration)
        webView.customUserAgent = Self.desktopSafariUserAgent
        webView.navigationDelegate = self
        webView.uiDelegate = self
        webView.allowsBackForwardNavigationGestures = true
        webView.allowsLinkPreview = false
        if #available(iOS 16.4, *) { webView.isInspectable = true }
        webView.scrollView.contentInsetAdjustmentBehavior = .never
        webView.scrollView.keyboardDismissMode = .interactive
        webViews[tabID] = webView
        tabIDsByWebView[ObjectIdentifier(webView)] = tabID
        observeProgress(webView: webView, tabID: tabID)
        load(tabID: tabID, urlString: initialURL)
        return webView
    }

    func destroy(tabID: UUID) {
        progressObservers[tabID]?.invalidate()
        progressObservers.removeValue(forKey: tabID)
        urlObservers[tabID]?.invalidate()
        urlObservers.removeValue(forKey: tabID)
        titleObservers[tabID]?.invalidate()
        titleObservers.removeValue(forKey: tabID)
        loadingObservers[tabID]?.invalidate()
        loadingObservers.removeValue(forKey: tabID)
        if let webView = webViews.removeValue(forKey: tabID) {
            tabIDsByWebView.removeValue(forKey: ObjectIdentifier(webView))
            webView.stopLoading()
            webView.navigationDelegate = nil
            webView.uiDelegate = nil
        }
    }

    func load(tabID: UUID, urlString: String) {
        guard let webView = webViews[tabID] else { return }
        if urlString.trimmingCharacters(in: .whitespacesAndNewlines).lowercased() == "about:blank" {
            DispatchQueue.main.async {
                webView.loadHTMLString("", baseURL: nil)
                self.store?.updateTab(tabID) { tab in
                    tab.urlString = "about:blank"
                    tab.title = "新页面"
                    tab.isLoading = false
                    tab.estimatedProgress = 1
                }
            }
            return
        }
        guard let url = URL(string: urlString) else {
            DispatchQueue.main.async {
                self.store?.updateTab(tabID) { tab in
                    tab.isLoading = false
                    tab.title = "无效网址"
                }
            }
            return
        }
        guard Self.shouldLoadInsideBrowser(url) else {
            // 静默拦截外部 App scheme，避免打断用户视野。Agent/网页只能留在内置浏览器里。
            return
        }
        DispatchQueue.main.async {
            Self.applyCompatibility(for: url, to: webView)
            var request = URLRequest(url: url)
            request.timeoutInterval = 30
            request.setValue(Self.userAgent(for: url), forHTTPHeaderField: "User-Agent")
            webView.load(request)
        }
    }

    static func shouldLoadInsideBrowser(_ url: URL) -> Bool {
        guard let scheme = url.scheme?.lowercased() else { return false }
        if ["http", "https", "about", "file"].contains(scheme) { return true }
        return false
    }

    static func isMicrosoftLike(_ url: URL) -> Bool {
        let host = (url.host ?? "").lowercased()
        return host.contains("teams.microsoft.com")
            || host.contains("microsoftonline.com")
            || host.contains("office.com")
            || host.contains("live.com")
            || host.contains("sharepoint.com")
    }

    static func isConsentPolicyDetour(_ url: URL) -> Bool {
        let host = (url.host ?? "").lowercased()
        let path = url.path.lowercased()
        let query = (url.query ?? "").lowercased()
        let combined = host + " " + path + " " + query
        let policyHosts = host.contains("privacy.") || host.contains("support.weixin.qq.com") || host.contains("microsoft.com") || host.contains("qq.com") || host.contains("wechat.com")
        let policyWords = ["privacy", "privacystatement", "cookie", "cookies", "terms", "legal", "gdpr", "protect", "policy", "agreement"]
        return policyHosts && policyWords.contains { combined.contains($0) }
    }

    static func userAgent(for url: URL) -> String {
        isMicrosoftLike(url) ? desktopEdgeUserAgent : desktopSafariUserAgent
    }

    static func applyCompatibility(for url: URL, to webView: WKWebView) {
        webView.customUserAgent = userAgent(for: url)
        if #available(iOS 14.0, *) {
            webView.configuration.defaultWebpagePreferences.preferredContentMode = .desktop
        }
    }

    func goBack(tabID: UUID) { DispatchQueue.main.async { self.webViews[tabID]?.goBack() } }
    func goForward(tabID: UUID) { DispatchQueue.main.async { self.webViews[tabID]?.goForward() } }
    func reload(tabID: UUID) { DispatchQueue.main.async { self.webViews[tabID]?.reload() } }
    func stopLoading(tabID: UUID) { DispatchQueue.main.async { self.webViews[tabID]?.stopLoading() } }

    func refreshProgress(tabID: UUID) {
        guard let webView = webViews[tabID] else { return }
        syncTabState(tabID: tabID, webView: webView)
    }

    private func syncTabState(tabID: UUID, webView: WKWebView, overrideURL: URL? = nil, isLoading: Bool? = nil, progress: Double? = nil) {
        DispatchQueue.main.async {
            self.store?.updateTab(tabID) { tab in
                if let current = overrideURL ?? webView.url {
                    let value = current.absoluteString
                    if !value.isEmpty { tab.urlString = value }
                }
                if let title = webView.title, !title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                    tab.title = title
                }
                tab.estimatedProgress = progress ?? webView.estimatedProgress
                tab.isLoading = isLoading ?? webView.isLoading
                tab.updatedAt = Date()
            }
        }
    }

    private func observeProgress(webView: WKWebView, tabID: UUID) {
        progressObservers[tabID] = webView.observe(\.estimatedProgress, options: [.new]) { [weak self] webView, _ in
            self?.syncTabState(tabID: tabID, webView: webView)
        }
        urlObservers[tabID] = webView.observe(\.url, options: [.new]) { [weak self] webView, _ in
            self?.syncTabState(tabID: tabID, webView: webView)
        }
        titleObservers[tabID] = webView.observe(\.title, options: [.new]) { [weak self] webView, _ in
            self?.syncTabState(tabID: tabID, webView: webView)
        }
        loadingObservers[tabID] = webView.observe(\.isLoading, options: [.new]) { [weak self] webView, _ in
            self?.syncTabState(tabID: tabID, webView: webView)
        }
    }

    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        guard let tabID = tabIDsByWebView[ObjectIdentifier(webView)] else { return }
        syncTabState(tabID: tabID, webView: webView, isLoading: true, progress: 0.05)
    }

    func webView(_ webView: WKWebView, didCommit navigation: WKNavigation!) {
        guard let tabID = tabIDsByWebView[ObjectIdentifier(webView)] else { return }
        syncTabState(tabID: tabID, webView: webView, isLoading: true)
    }

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        guard let tabID = tabIDsByWebView[ObjectIdentifier(webView)] else { return }
        DispatchQueue.main.async {
            self.store?.updateTab(tabID) { tab in
                tab.title = webView.title ?? tab.title
                tab.urlString = webView.url?.absoluteString ?? tab.urlString
                tab.isLoading = false
                tab.estimatedProgress = 1
                tab.updatedAt = Date()
            }
            self.captureThumbnail(tabID: tabID)
        }
    }

    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        updateFailure(webView: webView, error: error)
    }

    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        updateFailure(webView: webView, error: error)
    }

    private func updateFailure(webView: WKWebView, error: Error) {
        guard let tabID = tabIDsByWebView[ObjectIdentifier(webView)] else { return }
        DispatchQueue.main.async {
            self.store?.updateTab(tabID) { tab in
                tab.isLoading = false
                tab.updatedAt = Date()
            }
        }
    }

    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
        guard let tabID = tabIDsByWebView[ObjectIdentifier(webView)] else { return }
        DispatchQueue.main.async {
            self.store?.updateTab(tabID) { tab in
                tab.isLoading = false
                tab.title = tab.title.isEmpty ? "页面已恢复" : tab.title
                tab.updatedAt = Date()
            }
            // WebKit 内容进程被系统回收时自动 reload，避免 Agent 后台页面变成空壳。
            webView.reload()
        }
    }

    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = navigationAction.request.url else {
            decisionHandler(.allow)
            return
        }
        guard Self.shouldLoadInsideBrowser(url) else {
            // 静默拦截外部 App scheme，例如 douyin://、snssdk://、bitbrowser://、itms-apps://。
            // 不弹窗，只取消导航，避免遮挡网页和任务。
            decisionHandler(.cancel)
            return
        }
        let tabID = tabIDsByWebView[ObjectIdentifier(webView)]
        if let tabID = tabID, isTaskControlledTab(tabID), Self.isConsentPolicyDetour(url), navigationAction.navigationType == .linkActivated {
            // AI 自动任务里经常会误点 Cookie/Privacy/Terms 说明链接，导致从登录页跳到政策长文。
            // 对任务页阻止这类说明页跳转，再尝试点击真正的同意/继续按钮。
            decisionHandler(.cancel)
            webView.evaluateJavaScript(Self.autoConsentScript, completionHandler: nil)
            return
        }
        Self.applyCompatibility(for: url, to: webView)
        if let tabID = tabID { syncTabState(tabID: tabID, webView: webView, overrideURL: url, isLoading: true) }
        decisionHandler(.allow)
    }

    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        if navigationAction.targetFrame == nil, let url = navigationAction.request.url {
            if Self.shouldLoadInsideBrowser(url) {
                if let tabID = tabIDsByWebView[ObjectIdentifier(webView)] {
                    if isTaskControlledTab(tabID), Self.isConsentPolicyDetour(url) {
                        webView.evaluateJavaScript(Self.autoConsentScript, completionHandler: nil)
                        return nil
                    }
                    syncTabState(tabID: tabID, webView: webView, overrideURL: url, isLoading: true)
                }
                webView.load(navigationAction.request)
            } else {
                // 外部 App scheme 直接静默取消。
            }
        }
        return nil
    }

    private func isTaskControlledTab(_ tabID: UUID) -> Bool {
        guard let store else { return false }
        return store.tasks.contains { task in
            !task.status.isTerminal && task.workingTabIDs.contains(tabID)
        }
    }


    func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping () -> Void) {
        // 不弹出网页 alert，避免 cookie/站点提示打断任务；默认视为已确认。
        completionHandler()
    }

    func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (Bool) -> Void) {
        // 不弹出网页 confirm；默认同意，适合 cookie/继续访问类提示。
        completionHandler(true)
    }

    func webView(_ webView: WKWebView, runJavaScriptTextInputPanelWithPrompt prompt: String, defaultText: String?, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (String?) -> Void) {
        // 不弹出网页 prompt；没有用户输入时使用默认值或空字符串。
        completionHandler(defaultText ?? "")
    }

    private func topViewController(base: UIViewController? = UIApplication.shared.connectedScenes.compactMap { ($0 as? UIWindowScene)?.keyWindow }.first?.rootViewController) -> UIViewController? {
        if let nav = base as? UINavigationController { return topViewController(base: nav.visibleViewController) }
        if let tab = base as? UITabBarController { return topViewController(base: tab.selectedViewController) }
        if let presented = base?.presentedViewController { return topViewController(base: presented) }
        return base
    }

    func captureThumbnail(tabID: UUID) {
        guard let webView = webViews[tabID] else { return }
        let config = WKSnapshotConfiguration()
        config.rect = CGRect(origin: .zero, size: CGSize(width: max(webView.bounds.width, 320), height: max(webView.bounds.height, 480)))
        config.snapshotWidth = NSNumber(value: 260)
        webView.takeSnapshot(with: config) { [weak self] image, error in
            guard error == nil, image != nil else { return }
            DispatchQueue.main.async {
                self?.store?.updateThumbnail(tabID: tabID, image: image)
            }
        }
    }

    func collectPageState(tabID: UUID) async throws -> String {
        let script = Self.safeCollectStateScript
        do {
            return try await evaluateJSON(tabID: tabID, script: script)
        } catch {
            // v1.4.16: 页面扫描不能因为单次 JS 异常直接让任务失败。
            // 先重注入 bridge，再重试；仍失败则返回最小可用页面状态，让 Agent 可继续 navigate / reload。
            _ = try? await evaluateJavaScriptString(tabID: tabID, script: Self.autoConsentScript)
            _ = try? await evaluateJavaScriptString(tabID: tabID, script: Self.agentBridgeScript)
            do {
                return try await evaluateJavaScriptString(tabID: tabID, script: script)
            } catch {
                return fallbackPageStateJSON(tabID: tabID, error: error)
            }
        }
    }

    private func fallbackPageStateJSON(tabID: UUID, error: Error) -> String {
        let tab = store?.tabs.first(where: { $0.id == tabID })
        let title = tab?.title ?? ""
        let url = tab?.urlString ?? "about:blank"
        let payload: [String: Any] = [
            "title": title,
            "url": url,
            "readyState": "unknown",
            "isLoading": tab?.isLoading ?? false,
            "hasFocus": false,
            "activeElement": NSNull(),
            "lang": "",
            "description": "",
            "viewport": ["width": 0, "height": 0, "scrollX": 0, "scrollY": 0, "fullHeight": 0],
            "coordinateSystem": "viewport/client coordinates; JS scan failed, use native navigation or wait/reload.",
            "selection": "",
            "text": "",
            "headings": [],
            "inputButtonSummary": ["inputs": [], "buttons": []],
            "elements": [],
            "collectError": String(describing: error)
        ]
        guard JSONSerialization.isValidJSONObject(payload),
              let data = try? JSONSerialization.data(withJSONObject: payload),
              let json = String(data: data, encoding: .utf8) else {
            return "{\"title\":\"\",\"url\":\"about:blank\",\"readyState\":\"unknown\",\"isLoading\":false,\"elements\":[],\"collectError\":\"fallback serialization failed\"}"
        }
        return json
    }

    func describeActionTarget(tabID: UUID, action: AgentAction) async throws -> String {
        let data = try JSONEncoder().encode(action)
        let json = String(data: data, encoding: .utf8) ?? "{}"
        let script = "window.__liquidAgent && window.__liquidAgent.describeActionTarget ? window.__liquidAgent.describeActionTarget(\(json)) : JSON.stringify({ok:false,message:'Agent bridge not ready'});"
        return try await evaluateJSON(tabID: tabID, script: script)
    }

    func performAction(tabID: UUID, action: AgentAction) async throws -> String {
        let data = try JSONEncoder().encode(action)
        let json = String(data: data, encoding: .utf8) ?? "{}"
        let script = "window.__liquidAgent && window.__liquidAgent.performAction ? window.__liquidAgent.performAction(\(json)) : JSON.stringify({ok:false,message:'Agent bridge not ready'});"
        return try await evaluateJSON(tabID: tabID, script: script)
    }

    func screenshotJPEGData(tabID: UUID, maxWidth: CGFloat = 720) async throws -> Data {
        try await withCheckedThrowingContinuation { continuation in
            DispatchQueue.main.async {
                guard let webView = self.webViews[tabID] else {
                    continuation.resume(throwing: NSError(domain: "LiquidAIBrowser", code: 404, userInfo: [NSLocalizedDescriptionKey: "找不到页面 WebView"]))
                    return
                }
                let config = WKSnapshotConfiguration()
                if webView.bounds.width < 10 || webView.bounds.height < 10 {
                    webView.frame = CGRect(x: 0, y: 0, width: 1024, height: 768)
                    webView.layoutIfNeeded()
                }
                let bounds = webView.bounds.isEmpty ? CGRect(x: 0, y: 0, width: 1024, height: 768) : webView.bounds
                config.rect = bounds
                let aspectSafeWidth = min(maxWidth, 720)
                config.snapshotWidth = NSNumber(value: Double(aspectSafeWidth))
                webView.takeSnapshot(with: config) { image, error in
                    if let error = error {
                        continuation.resume(throwing: error)
                        return
                    }
                    guard let image, let data = image.liquidCompressedJPEG(maxLongSide: 1280, quality: 0.68) else {
                        continuation.resume(throwing: NSError(domain: "LiquidAIBrowser", code: 500, userInfo: [NSLocalizedDescriptionKey: "截图失败"]))
                        return
                    }
                    continuation.resume(returning: data)
                }
            }
        }
    }

    private func evaluateJSON(tabID: UUID, script: String) async throws -> String {
        let first = try await evaluateJavaScriptString(tabID: tabID, script: script)
        if first.contains("Agent bridge not ready") || first.contains("__liquidAgent") || first.contains("collectError") {
            _ = try? await evaluateJavaScriptString(tabID: tabID, script: Self.autoConsentScript)
            _ = try? await evaluateJavaScriptString(tabID: tabID, script: Self.agentBridgeScript)
            return try await evaluateJavaScriptString(tabID: tabID, script: script)
        }
        return first
    }

    private func evaluateJavaScriptString(tabID: UUID, script: String) async throws -> String {
        try await withCheckedThrowingContinuation { continuation in
            DispatchQueue.main.async {
                guard let webView = self.webViews[tabID] else {
                    continuation.resume(throwing: NSError(domain: "LiquidAIBrowser", code: 404, userInfo: [NSLocalizedDescriptionKey: "找不到页面 WebView"]))
                    return
                }
                webView.evaluateJavaScript(script) { result, error in
                    if let error = error {
                        continuation.resume(throwing: error)
                        return
                    }
                    if let string = result as? String {
                        continuation.resume(returning: string)
                    } else if let result = result {
                        continuation.resume(returning: "\(result)")
                    } else {
                        continuation.resume(returning: "{}")
                    }
                }
            }
        }
    }
}

extension WebViewPool {
    static let safeCollectStateScript = #"""
(function() {
  function safeText(value, max) { return String(value || '').replace(/\s+/g, ' ').trim().slice(0, max || 12000); }
  function fallback(error) {
    try {
      return JSON.stringify({
        title: document.title || '',
        url: location.href || '',
        readyState: document.readyState || 'unknown',
        isLoading: document.readyState !== 'complete',
        hasFocus: document.hasFocus ? document.hasFocus() : false,
        activeElement: null,
        lang: document.documentElement ? (document.documentElement.lang || '') : '',
        description: '',
        viewport: { width: innerWidth || 0, height: innerHeight || 0, scrollX: Math.round(scrollX || 0), scrollY: Math.round(scrollY || 0), fullHeight: Math.round((document.documentElement && document.documentElement.scrollHeight) || (document.body && document.body.scrollHeight) || 0) },
        coordinateSystem: 'viewport/client coordinates. Agent bridge fallback state.',
        selection: '',
        text: document.body ? safeText(document.body.innerText || document.body.textContent || '', 12000) : '',
        headings: [],
        inputButtonSummary: { inputs: [], buttons: [] },
        elements: [],
        collectError: String(error && error.message ? error.message : error || '')
      });
    } catch (e) {
      return '{"title":"","url":"about:blank","readyState":"unknown","isLoading":false,"elements":[],"collectError":"safe fallback failed"}';
    }
  }
  try {
    if (window.__liquidAgent && typeof window.__liquidAgent.collectState === 'function') {
      return window.__liquidAgent.collectState();
    }
    return fallback('Agent bridge not ready');
  } catch (e) {
    return fallback(e);
  }
})();
"""#

    static let autoConsentScript = #"""
(function(){
  if (window.__liquidAutoConsentInstalled) {
    try { window.__liquidRunAutoConsent && window.__liquidRunAutoConsent(); } catch(e) {}
    return;
  }
  window.__liquidAutoConsentInstalled = true;
  const strongPositive = [
    '全部同意','同意全部','接受全部','允许全部','接受所有','同意所有','全部接受','我同意','同意并继续','接受并继续','继续访问','确认并继续',
    'accept all','agree all','allow all','accept cookies','allow cookies','i agree','agree and continue','accept and continue','continue','got it','ok','okay'
  ];
  const weakPositive = ['同意','接受','允许','确定','好的','好','继续','知道了','我知道了','accept','agree','allow','yes','confirm','proceed'];
  const negative = ['拒绝','不同意','取消','deny','decline','reject','no','cancel','仅拒绝','全部拒绝'];
  const detour = ['隐私声明','隐私政策','隐私保护指引','cookie 和类似技术','cookie policy','privacy statement','privacy policy','terms of use','使用条款','了解详细信息','learn more','more information','管理选项','manage options','settings','preferences','第三方 cookie'];
  const contextWords = ['cookie','cookies','隐私','privacy','consent','gdpr','条款','terms','同意','accept'];
  function norm(value){ return String(value||'').replace(/\s+/g,' ').trim().toLowerCase(); }
  function textOf(el){ return norm([el.innerText, el.textContent, el.value, el.getAttribute('aria-label'), el.getAttribute('title'), el.getAttribute('data-testid'), el.id, el.className].filter(Boolean).join(' ')); }
  function hrefOf(el){ return norm(el.getAttribute('href') || el.href || ''); }
  function visible(el){ const r=el.getBoundingClientRect(); const s=getComputedStyle(el); return r.width>2 && r.height>2 && s.display!=='none' && s.visibility!=='hidden' && s.opacity!=='0' && s.pointerEvents!=='none'; }
  function isRealButton(el){
    const tag=(el.tagName||'').toLowerCase();
    const role=norm(el.getAttribute('role'));
    const type=norm(el.getAttribute('type'));
    return tag==='button' || role==='button' || type==='button' || type==='submit' || el.onclick || /button|btn|accept|agree|consent|allow/i.test(String(el.className||'')+' '+String(el.id||''));
  }
  function isPolicyLink(el, text){
    const tag=(el.tagName||'').toLowerCase();
    const href=hrefOf(el);
    if(tag !== 'a' && !href) return false;
    if(detour.some(x=>text.includes(norm(x)))) return true;
    return /privacy|cookie|cookies|terms|legal|gdpr|agreement|protect/i.test(href) && !strongPositive.some(x=>text.includes(norm(x)));
  }
  function inConsentArea(el){
    let node=el;
    for(let i=0; node && i<5; i++, node=node.parentElement){
      const t=textOf(node).slice(0,1600);
      if(contextWords.some(x=>t.includes(norm(x)))) return true;
    }
    return false;
  }
  function score(el){
    if(!visible(el)) return -100;
    const t=textOf(el); if(!t) return -100;
    if(negative.some(x=>t.includes(norm(x)))) return -100;
    if(isPolicyLink(el,t)) return -100;
    const strong=strongPositive.some(x=>t.includes(norm(x)));
    const weak=weakPositive.some(x=>t.includes(norm(x)));
    if(!strong && !weak) return -100;
    if(!isRealButton(el) && !strong) return -100;
    const consentArea = inConsentArea(el);
    const consentText = /cookie|cookies|consent|gdpr|privacy|隐私|条款|accept|agree|allow|同意|接受|允许/.test(t);
    if(!consentArea && !consentText) return -100;
    let v=strong ? 80 : 35;
    if(consentArea) v+=25;
    if(/accept|agree|allow|同意|接受|允许/.test(t)) v+=15;
    if(/all|全部|所有/.test(t)) v+=8;
    const r=el.getBoundingClientRect();
    if(r.top > 0 && r.top < innerHeight) v+=5;
    return v;
  }
  function allCandidates(root){
    const out=[];
    function walk(node){
      if(!node) return;
      try { out.push(...Array.from(node.querySelectorAll('button,input[type="button"],input[type="submit"],[role="button"],a,[data-testid],.button,.btn'))); } catch(e) {}
      try { node.querySelectorAll('*').forEach(el=>{ if(el.shadowRoot) walk(el.shadowRoot); }); } catch(e) {}
    }
    walk(root || document);
    return out;
  }
  function clickConsent(){
    const best=allCandidates(document).map(el=>({el, s:score(el)})).filter(x=>x.s>0).sort((a,b)=>b.s-a.s)[0];
    if(best){
      try{
        best.el.scrollIntoView({block:'center', inline:'center'});
        best.el.click();
        window.__liquidLastAutoConsent = { text: textOf(best.el).slice(0,160), score: best.s, at: Date.now() };
        return true;
      }catch(e){}
    }
    return false;
  }
  function run(){ try{ clickConsent(); }catch(e){} }
  window.__liquidRunAutoConsent = run;
  function start(){
    run();
    let count=0;
    const timer=setInterval(()=>{ run(); if(++count>18) clearInterval(timer); }, 600);
    try{ new MutationObserver(run).observe(document.documentElement || document.body,{childList:true,subtree:true}); }catch(e){}
  }
  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start, {once:true}); else start();
})();
"""#

    static let agentBridgeScript = #"""
(function() {
  if (window.__liquidAgent && window.__liquidAgent.version === '1.4.21') return;
  function norm(s) { return (s || '').replace(/\s+/g, ' ').trim(); }
  function sanitizeAgentURL(raw) {
    let value = norm(raw || 'about:blank');
    if (!value) return 'about:blank';
    if (/^(douyin|snssdk|aweme|itms-apps|itms-services):\/\//i.test(value)) {
      const m = value.match(/(?:keyword|query|q|search|word)=([^&]+)/i);
      const keyword = m ? decodeURIComponent(m[1]).replace(/\+/g, ' ') : '';
      return keyword ? 'https://www.douyin.com/search/' + encodeURIComponent(keyword) : 'https://www.douyin.com/';
    }
    if (/抖音/.test(value) && /(搜索|搜|查找)/.test(value)) {
      const keyword = value.replace(/.*?(搜索|搜|查找)/, '').replace(/抖音/g, '').trim();
      return keyword ? 'https://www.douyin.com/search/' + encodeURIComponent(keyword) : 'https://www.douyin.com/';
    }
    if (!/^https?:\/\//i.test(value) && !value.startsWith('/') && value.includes('.')) return 'https://' + value;
    return value;
  }
  const cssEscape = (window.CSS && CSS.escape) ? CSS.escape.bind(CSS) : function(value) {
    return String(value).replace(/[^a-zA-Z0-9_-]/g, function(ch) { return '\\' + ch.codePointAt(0).toString(16) + ' '; });
  };
  const interactiveSelector = 'a,button,input,textarea,select,[role="button"],[role="link"],[contenteditable],summary,label,[onclick],[tabindex]';
  function isSensitiveInput(el) {
    const joined = norm([
      el.getAttribute('type'), el.getAttribute('name'), el.getAttribute('id'), el.getAttribute('autocomplete'),
      el.getAttribute('placeholder'), el.getAttribute('aria-label'), el.getAttribute('title')
    ].filter(Boolean).join(' ')).toLowerCase();
    return /(password|passcode|token|secret|api.?key|credit|card|cc-|cvc|cvv|otp|2fa|verification|验证码|密码|银行卡|信用卡|动态码)/i.test(joined);
  }
  function safeValue(el) {
    if (!('value' in el)) return '';
    if (isSensitiveInput(el)) return '[REDACTED]';
    return String(el.value || '').slice(0, 120);
  }
  function cssPath(el) {
    if (!el || el.nodeType !== 1) return '';
    if (el.id) return '#' + cssEscape(el.id);
    const parts = [];
    let node = el;
    while (node && node.nodeType === 1 && parts.length < 5) {
      let part = node.nodeName.toLowerCase();
      if (node.className && typeof node.className === 'string') {
        const cls = node.className.split(/\s+/).filter(Boolean).slice(0, 2).map(c => '.' + cssEscape(c)).join('');
        part += cls;
      }
      const parent = node.parentElement;
      if (parent) {
        const siblings = Array.from(parent.children).filter(x => x.nodeName === node.nodeName);
        if (siblings.length > 1) part += ':nth-of-type(' + (siblings.indexOf(node) + 1) + ')';
      }
      parts.unshift(part);
      node = parent;
    }
    return parts.join(' > ');
  }
  function labelText(el) {
    if (!el) return '';
    if (el.id) {
      const label = document.querySelector('label[for="' + cssEscape(el.id) + '"]');
      if (label) return norm(label.innerText || label.textContent || '');
    }
    const wrap = el.closest('label');
    return wrap ? norm(wrap.innerText || wrap.textContent || '') : '';
  }
  function elementSearchText(el) {
    return norm([
      el.innerText, el.textContent, el.value, el.getAttribute('aria-label'), el.getAttribute('placeholder'),
      el.getAttribute('name'), el.getAttribute('title'), el.getAttribute('href'), el.getAttribute('id'),
      typeof el.className === 'string' ? el.className : '', labelText(el)
    ].filter(Boolean).join(' '));
  }
  function visible(el) {
    const rect = el.getBoundingClientRect();
    const style = window.getComputedStyle(el);
    return rect.width > 0 && rect.height > 0 && style.visibility !== 'hidden' && style.display !== 'none' && style.opacity !== '0';
  }
  function describeElement(el, index) {
    const rect = el.getBoundingClientRect();
    const style = window.getComputedStyle(el);
    const form = el.form || el.closest('form');
    const centerX = Math.round(rect.left + rect.width / 2);
    const centerY = Math.round(rect.top + rect.height / 2);
    return {
      index,
      tag: el.tagName.toLowerCase(),
      type: el.getAttribute('type') || '',
      role: el.getAttribute('role') || '',
      text: norm(el.innerText || el.textContent || el.getAttribute('aria-label') || el.getAttribute('title') || labelText(el) || '').slice(0, 180),
      placeholder: el.getAttribute('placeholder') || '',
      name: el.getAttribute('name') || '',
      value: safeValue(el),
      href: el.href || el.getAttribute('href') || '',
      title: el.getAttribute('title') || '',
      id: el.getAttribute('id') || '',
      label: labelText(el).slice(0, 180),
      formAction: form ? (form.action || form.getAttribute('action') || '') : '',
      selector: cssPath(el),
      visible: visible(el),
      rect: {
        x: Math.round(rect.x), y: Math.round(rect.y), width: Math.round(rect.width), height: Math.round(rect.height),
        centerX, centerY, pageX: Math.round(rect.x + scrollX), pageY: Math.round(rect.y + scrollY)
      },
      disabled: !!el.disabled || el.getAttribute('aria-disabled') === 'true',
      focused: document.activeElement === el || el.contains(document.activeElement),
      style: {
        display: style.display, visibility: style.visibility, opacity: style.opacity, pointerEvents: style.pointerEvents,
        position: style.position, zIndex: style.zIndex, cursor: style.cursor, overflow: style.overflow,
        color: style.color, backgroundColor: style.backgroundColor, fontSize: style.fontSize
      }
    };
  }
  function interactiveElements() {
    return Array.from(document.querySelectorAll(interactiveSelector))
      .filter(visible)
      .slice(0, 280)
      .map(describeElement);
  }
  function findElement(action) {
    if (!action) return null;
    if (action.selector) {
      try { const direct = document.querySelector(action.selector); if (direct) return direct; } catch(e) {}
    }
    if (typeof action.x === 'number' && typeof action.y === 'number') {
      const byPoint = document.elementFromPoint(action.x, action.y);
      if (byPoint) return byPoint.closest(interactiveSelector) || byPoint;
    }
    const candidates = Array.from(document.querySelectorAll(interactiveSelector)).filter(visible);
    const target = norm(action.text || action.value || '').toLowerCase();
    if (target) {
      let best = candidates.find(el => elementSearchText(el).toLowerCase() === target);
      if (best) return best;
      best = candidates.find(el => elementSearchText(el).toLowerCase().includes(target));
      if (best) return best;
    }
    if (typeof action.stepIndex === 'number' && candidates[action.stepIndex]) return candidates[action.stepIndex];
    return null;
  }
  function nativeSetValue(el, value) {
    if (!el) return;
    const text = String(value || '');
    if (el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement) {
      const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      const descriptor = Object.getOwnPropertyDescriptor(proto, 'value');
      const setter = descriptor && descriptor.set;
      if (setter) setter.call(el, text); else el.value = text;
    } else if ('value' in el) {
      el.value = text;
    } else {
      el.textContent = text;
    }
    try { el.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertReplacementText', data: text })); }
    catch (_) { el.dispatchEvent(new Event('input', { bubbles: true })); }
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }
  function isEditableElement(el) {
    if (!el) return false;
    if (el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement) return true;
    if (el.isContentEditable) return true;
    const role = (el.getAttribute && String(el.getAttribute('role') || '').toLowerCase()) || '';
    return role === 'textbox' || !!(el.closest && el.closest('[contenteditable="true"],[role="textbox"]'));
  }
  function editableElementText(el) {
    if (!el) return '';
    if (el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement || 'value' in el) return String(el.value || '');
    return String(el.innerText || el.textContent || '');
  }
  function dispatchTextInputEvents(el, data, inputType) {
    const text = String(data || '');
    try { el.dispatchEvent(new InputEvent('beforeinput', { bubbles: true, cancelable: true, inputType: inputType || 'insertText', data: text })); } catch (_) {}
    try { el.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: inputType || 'insertText', data: text })); }
    catch (_) { el.dispatchEvent(new Event('input', { bubbles: true })); }
    try { el.dispatchEvent(new CompositionEvent('compositionend', { bubbles: true, data: text })); } catch (_) {}
  }
  function findTextEntryElement(action) {
    if (action && action.selector) {
      try {
        const direct = document.querySelector(action.selector);
        if (direct) return direct.closest('input,textarea,[contenteditable="true"],[role="textbox"]') || direct;
      } catch (_) {}
    }
    if (action && typeof action.x === 'number' && typeof action.y === 'number') {
      const byPoint = document.elementFromPoint(action.x, action.y);
      if (byPoint) {
        const editable = byPoint.closest && byPoint.closest('input,textarea,[contenteditable="true"],[role="textbox"]');
        if (editable) return editable;
      }
    }
    const active = document.activeElement;
    if (isEditableElement(active) && visible(active)) return active;
    const targetLabel = norm((action && action.text) || '').toLowerCase();
    const candidates = Array.from(document.querySelectorAll('input,textarea,[contenteditable="true"],[role="textbox"]')).filter(visible);
    if (targetLabel) {
      const byText = candidates.find(el => elementSearchText(el).toLowerCase().includes(targetLabel));
      if (byText) return byText;
    }
    const password = candidates.find(el => el instanceof HTMLInputElement && (el.type || '').toLowerCase() === 'password');
    if (password) return password;
    const email = candidates.find(el => el instanceof HTMLInputElement && /email|username|login|i0116/i.test((el.type || '') + ' ' + (el.name || '') + ' ' + (el.id || '') + ' ' + (el.autocomplete || '')));
    if (email) return email;
    return candidates[0] || null;
  }
  function firePointer(el, name, x, y) {
    const init = { bubbles: true, cancelable: true, clientX: x, clientY: y, screenX: x, screenY: y };
    if (typeof PointerEvent !== 'undefined') {
      el.dispatchEvent(new PointerEvent(name, Object.assign({ pointerId: 1, pointerType: 'touch', isPrimary: true, buttons: name === 'pointerup' ? 0 : 1 }, init)));
    }
  }
  function fireMouse(el, name, x, y, detail) {
    el.dispatchEvent(new MouseEvent(name, { bubbles: true, cancelable: true, clientX: x, clientY: y, screenX: x, screenY: y, detail: detail || 1 }));
  }
  function clickAt(x, y, detail) {
    const el = document.elementFromPoint(x, y) || document.body;
    const target = el.closest ? (el.closest(interactiveSelector) || el) : el;
    try {
      firePointer(target, 'pointerdown', x, y);
      fireMouse(target, 'mousedown', x, y, detail || 1);
      firePointer(target, 'pointerup', x, y);
      fireMouse(target, 'mouseup', x, y, detail || 1);
      fireMouse(target, 'click', x, y, detail || 1);
      target.focus && target.focus();
    } catch (_) {
      target.click && target.click();
    }
    return { target, x: Math.round(x), y: Math.round(y) };
  }
  function realClick(el) {
    el.scrollIntoView({ block: 'center', inline: 'center', behavior: 'smooth' });
    const rect = el.getBoundingClientRect();
    const x = rect.left + rect.width / 2;
    const y = rect.top + rect.height / 2;
    return clickAt(x, y, 1);
  }
  function doubleClickAt(x, y) {
    const first = clickAt(x, y, 1);
    clickAt(x, y, 2);
    const target = first.target || document.elementFromPoint(x, y) || document.body;
    fireMouse(target, 'dblclick', x, y, 2);
    return first;
  }
  function swipeOrDrag(action, shouldScroll) {
    const sx = Number(action.startX ?? action.x ?? Math.round(innerWidth / 2));
    const sy = Number(action.startY ?? action.y ?? Math.round(innerHeight / 2));
    const ex = Number(action.endX ?? sx);
    const ey = Number(action.endY ?? (String(action.direction || 'down').toLowerCase() === 'up' ? sy + 420 : sy - 420));
    const startEl = document.elementFromPoint(sx, sy) || document.body;
    const target = startEl.closest ? (startEl.closest(interactiveSelector) || startEl) : startEl;
    firePointer(target, 'pointerdown', sx, sy);
    fireMouse(target, 'mousedown', sx, sy, 1);
    const steps = 6;
    for (let i = 1; i <= steps; i++) {
      const x = sx + (ex - sx) * i / steps;
      const y = sy + (ey - sy) * i / steps;
      firePointer(target, 'pointermove', x, y);
      fireMouse(target, 'mousemove', x, y, 1);
    }
    firePointer(target, 'pointerup', ex, ey);
    fireMouse(target, 'mouseup', ex, ey, 1);
    if (shouldScroll) window.scrollBy({ top: sy - ey, left: sx - ex, behavior: 'smooth' });
    return { target, x: Math.round(sx), y: Math.round(sy), endX: Math.round(ex), endY: Math.round(ey) };
  }

  function keyCodeFor(key) {
    const k = String(key || '').toLowerCase();
    const map = { enter: 'Enter', return: 'Enter', tab: 'Tab', escape: 'Escape', esc: 'Escape', backspace: 'Backspace', delete: 'Delete', space: ' ', arrowup: 'ArrowUp', arrowdown: 'ArrowDown', arrowleft: 'ArrowLeft', arrowright: 'ArrowRight' };
    return map[k] || key || '';
  }
  function keyboardTarget(action) {
    return findElement(action) || document.activeElement || document.body;
  }
  function isActiveWithin(el) {
    const active = document.activeElement;
    return !!(el && active && (active === el || (el.contains && el.contains(active)) || (active.contains && active.contains(el))));
  }
  function activeElementInfo() {
    const el = document.activeElement;
    if (!el) return null;
    try {
      const info = describeElement(el, -2);
      info.isBody = el === document.body;
      info.isDocumentElement = el === document.documentElement;
      info.isContentEditable = !!el.isContentEditable;
      info.searchText = norm(elementSearchText(el)).slice(0, 220);
      return info;
    } catch (_) {
      return { tag: el.tagName ? el.tagName.toLowerCase() : 'unknown', text: norm(el.innerText || el.textContent || '').slice(0, 160) };
    }
  }
  function focusAndVerify(el) {
    if (!el) return false;
    try {
      const r = el.getBoundingClientRect();
      if (r.width > 1 && r.height > 1) {
        clickAt(Math.round(r.left + Math.min(Math.max(16, r.width / 2), Math.max(16, r.width - 8))), Math.round(r.top + r.height / 2), 1);
      }
    } catch (_) {}
    try { el.focus && el.focus({ preventScroll: true }); } catch (_) { try { el.focus && el.focus(); } catch (__) {} }
    return isActiveWithin(el);
  }
  function elementTextSnapshot(el) {
    if (!el) return '';
    if (el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement || 'value' in el) return norm(el.value || '');
    return norm(el.innerText || el.textContent || '');
  }
  function dispatchKeyboard(el, key, modifiers) {
    const code = keyCodeFor(key);
    const mods = (modifiers || []).map(x => String(x).toLowerCase());
    const init = {
      bubbles: true,
      cancelable: true,
      key: code,
      code: code.length === 1 ? 'Key' + code.toUpperCase() : code,
      metaKey: mods.includes('cmd') || mods.includes('command') || mods.includes('meta'),
      ctrlKey: mods.includes('ctrl') || mods.includes('control'),
      altKey: mods.includes('alt') || mods.includes('option'),
      shiftKey: mods.includes('shift')
    };
    el.focus && el.focus();
    el.dispatchEvent(new KeyboardEvent('keydown', init));
    el.dispatchEvent(new KeyboardEvent('keypress', init));
    if (code === 'Enter') {
      const form = el.form || (el.closest && el.closest('form'));
      if (form && !init.shiftKey) { try { form.requestSubmit ? form.requestSubmit() : form.submit(); } catch (_) {} }
    }
    if (code === 'Tab') {
      const focusables = Array.from(document.querySelectorAll('a,button,input,textarea,select,[contenteditable],[tabindex]')).filter(visible);
      const idx = focusables.indexOf(el);
      const next = focusables[(idx + (init.shiftKey ? -1 : 1) + focusables.length) % focusables.length];
      next && next.focus && next.focus();
    }
    el.dispatchEvent(new KeyboardEvent('keyup', init));
    return { target: el, key: code };
  }
  function smartFillTextField(el, text, replaceExisting) {
    const value = String(text || '');
    if (!el) return { target: el, focused: false, activeMatches: false, before: '', after: '', inserted: false, frameworkSynced: false, message: '没有找到输入框' };
    const focused = focusAndVerify(el);
    const before = editableElementText(el);
    let frameworkSynced = false;

    if (el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement || 'value' in el) {
      try { el.focus && el.focus(); } catch (_) {}
      try { if (el.select) el.select(); } catch (_) {}
      try { if (el.setSelectionRange) el.setSelectionRange(0, String(el.value || '').length); } catch (_) {}
      if (replaceExisting !== false) {
        try { dispatchKeyboard(el, 'a', ['cmd']); } catch (_) {}
        try { dispatchKeyboard(el, 'Backspace', []); } catch (_) {}
        nativeSetValue(el, '');
        dispatchTextInputEvents(el, '', 'deleteContentBackward');
      }
      try {
        if (typeof el.setRangeText === 'function') {
          const start = replaceExisting === false ? String(el.value || '').length : 0;
          const end = replaceExisting === false ? String(el.value || '').length : String(el.value || '').length;
          el.setRangeText(value, start, end, 'end');
          dispatchTextInputEvents(el, value, replaceExisting === false ? 'insertText' : 'insertReplacementText');
          frameworkSynced = true;
        }
      } catch (_) {}
      if (String(el.value || '') !== value && replaceExisting !== false) {
        nativeSetValue(el, value);
        dispatchTextInputEvents(el, value, 'insertReplacementText');
        frameworkSynced = true;
      } else if (replaceExisting === false && !String(el.value || '').endsWith(value)) {
        nativeSetValue(el, String(el.value || '') + value);
        dispatchTextInputEvents(el, value, 'insertText');
        frameworkSynced = true;
      }
      if ((replaceExisting !== false && String(el.value || '') !== value) || (replaceExisting === false && !String(el.value || '').includes(value))) {
        let current = replaceExisting === false ? String(el.value || '') : '';
        if (replaceExisting !== false) nativeSetValue(el, '');
        for (const ch of value) {
          dispatchKeyboard(el, ch, []);
          current += ch;
          try {
            if (typeof el.setRangeText === 'function') {
              const pos = String(el.value || '').length;
              el.setRangeText(ch, pos, pos, 'end');
            } else {
              nativeSetValue(el, current);
            }
          } catch (_) { nativeSetValue(el, current); }
          dispatchTextInputEvents(el, ch, 'insertText');
        }
        frameworkSynced = true;
      }
      el.dispatchEvent(new Event('change', { bubbles: true }));
    } else if (el.isContentEditable || (el.getAttribute && (el.getAttribute('role') || '').toLowerCase() === 'textbox')) {
      placeCaretAtEnd(el);
      if (replaceExisting !== false) {
        try { document.execCommand && document.execCommand('selectAll', false, null); } catch (_) {}
        try { document.execCommand && document.execCommand('delete', false, null); } catch (_) {}
        if (elementTextSnapshot(el)) el.textContent = '';
      }
      try { frameworkSynced = !!(document.execCommand && document.execCommand('insertText', false, value)); } catch (_) { frameworkSynced = false; }
      if (!elementTextSnapshot(el).includes(value)) {
        for (const ch of value) {
          dispatchKeyboard(el, ch, []);
          try { frameworkSynced = !!(document.execCommand && document.execCommand('insertText', false, ch)) || frameworkSynced; } catch (_) {}
          dispatchTextInputEvents(el, ch, 'insertText');
        }
      }
      if (!elementTextSnapshot(el).includes(value)) {
        const p = el.querySelector('p,div,span') || el;
        p.textContent = replaceExisting === false ? (p.textContent || '') + value : value;
      }
      dispatchTextInputEvents(el, value, replaceExisting === false ? 'insertText' : 'insertReplacementText');
      el.dispatchEvent(new Event('change', { bubbles: true }));
    } else {
      for (const ch of value) dispatchKeyboard(el, ch, []);
    }
    let after = editableElementText(el);
    let repaired = false;
    let inserted = false;
    if (replaceExisting === false) {
      inserted = norm(after).includes(norm(value)) || after !== before;
    } else {
      inserted = norm(after) === norm(value);
      if (!inserted && value) {
        const repair = replaceEditableTextExactly(el, value);
        after = editableElementText(el);
        repaired = true;
        frameworkSynced = frameworkSynced || !!repair.frameworkSynced;
        inserted = norm(after) === norm(value);
      }
    }
    return { target: el, focused, activeMatches: isActiveWithin(el), before, after, inserted, frameworkSynced, repaired, message: focused ? (inserted ? (repaired ? '已校准为精确目标文本' : '已用键盘/输入事件写入文本') : '已聚焦但未检测到精确文本写入') : '未确认输入焦点' };
  }

  function insertTextLikeKeyboard(el, text) {
    const value = String(text || '');
    const focused = focusAndVerify(el);
    const before = elementTextSnapshot(el);
    let frameworkSynced = false;
    if (el.isContentEditable) {
      placeCaretAtEnd(el);
      try { el.dispatchEvent(new InputEvent('beforeinput', { bubbles: true, cancelable: true, inputType: 'insertText', data: value })); } catch (_) {}
      try { frameworkSynced = !!(document.execCommand && document.execCommand('insertText', false, value)); } catch (_) { frameworkSynced = false; }
      if (!elementTextSnapshot(el).includes(value)) {
        for (const ch of value) {
          dispatchKeyboard(el, ch, []);
          try { el.dispatchEvent(new InputEvent('beforeinput', { bubbles: true, cancelable: true, inputType: 'insertText', data: ch })); } catch (_) {}
          try { frameworkSynced = !!(document.execCommand && document.execCommand('insertText', false, ch)) || frameworkSynced; } catch (_) {}
        }
      }
      if (!elementTextSnapshot(el).includes(value)) {
        const p = el.querySelector('p,div,span') || el;
        p.textContent = (p.textContent || '') + value;
      }
      try { el.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: value })); }
      catch (_) { el.dispatchEvent(new Event('input', { bubbles: true })); }
      el.dispatchEvent(new Event('change', { bubbles: true }));
      try { el.dispatchEvent(new CompositionEvent('compositionend', { bubbles: true, data: value })); } catch (_) {}
    } else if (el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement || 'value' in el) {
      const filled = smartFillTextField(el, value, false);
      frameworkSynced = !!filled.frameworkSynced;
    } else {
      for (const ch of value) dispatchKeyboard(el, ch, []);
    }
    const after = elementTextSnapshot(el);
    return { target: el, focused, activeMatches: isActiveWithin(el), before, after, inserted: after.includes(value) || after !== before, frameworkSynced };
  }


  function isTeamsPage() {
    return /(^|\.)teams\.microsoft\.com$/i.test(location.hostname) || /Microsoft Teams/i.test(document.title || '') || /\bTeams\b/i.test(document.body ? document.body.innerText.slice(0, 1200) : '');
  }
  function editableScore(el) {
    const txt = elementSearchText(el).toLowerCase();
    const r = el.getBoundingClientRect();
    let score = 0;
    if (el.isContentEditable) score += 20;
    if ((el.getAttribute('role') || '').toLowerCase() === 'textbox') score += 10;
    if (/键入消息|type a message|type your message|new-message|compose|message/i.test(txt)) score += 40;
    if (r.top > innerHeight * 0.55) score += 12;
    if (r.width > Math.min(240, innerWidth * 0.2)) score += 8;
    if (document.activeElement === el || el.contains(document.activeElement)) score += 15;
    return score;
  }
  function findChatComposer(action) {
    const selectors = [
      action && action.selector,
      '[contenteditable="true"][role="textbox"]',
      '[contenteditable][role="textbox"]',
      '[role="textbox"][aria-label*="键入消息"]',
      '[role="textbox"][aria-label*="Type"]',
      '[contenteditable][aria-label*="message" i]',
      '[contenteditable][data-tid*="new-message" i]',
      '[contenteditable][class*="new-message" i]',
      'div[contenteditable="true"]',
      'textarea[placeholder*="message" i]',
      'input[placeholder*="message" i]'
    ].filter(Boolean);
    for (const sel of selectors) {
      try {
        const matches = Array.from(document.querySelectorAll(sel)).filter(visible);
        if (matches.length) return matches.sort((a,b) => editableScore(b) - editableScore(a))[0];
      } catch (_) {}
    }
    const candidates = Array.from(document.querySelectorAll('textarea,input,[contenteditable],[role="textbox"]')).filter(visible);
    if (!candidates.length) return null;
    return candidates.sort((a,b) => editableScore(b) - editableScore(a))[0];
  }
  function placeCaretAtEnd(el) {
    try {
      const range = document.createRange();
      range.selectNodeContents(el);
      range.collapse(false);
      const sel = window.getSelection();
      sel.removeAllRanges();
      sel.addRange(range);
    } catch (_) {}
  }
  function clearEditableBeforeMessage(el) {
    if (!el) return false;
    let cleared = false;
    try { el.focus && el.focus(); } catch (_) {}
    if (el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement || 'value' in el) {
      try { if (el.select) el.select(); } catch (_) {}
      try { if (el.setSelectionRange) el.setSelectionRange(0, String(el.value || '').length); } catch (_) {}
      try { dispatchKeyboard(el, 'a', ['cmd']); } catch (_) {}
      try { dispatchKeyboard(el, 'Backspace', []); } catch (_) {}
      if (String(el.value || '').length) nativeSetValue(el, '');
      dispatchTextInputEvents(el, '', 'deleteContentBackward');
      el.dispatchEvent(new Event('change', { bubbles: true }));
      return true;
    }
    if (el.isContentEditable || (el.getAttribute && (el.getAttribute('role') || '').toLowerCase() === 'textbox')) {
      try {
        const range = document.createRange();
        range.selectNodeContents(el);
        const sel = window.getSelection();
        sel.removeAllRanges();
        sel.addRange(range);
        cleared = !!(document.execCommand && document.execCommand('delete', false, null));
        sel.removeAllRanges();
      } catch (_) {}
      if (elementTextSnapshot(el)) {
        try {
          Array.from(el.querySelectorAll('br')).forEach(n => n.remove());
          const leaves = Array.from(el.querySelectorAll('p,div,span')).filter(n => !n.querySelector('p,div,span'));
          if (leaves.length) leaves.forEach(n => { n.textContent = ''; });
          else el.textContent = '';
          cleared = true;
        } catch (_) { try { el.textContent = ''; cleared = true; } catch (__) {} }
      }
      try { el.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'deleteContentBackward', data: null })); } catch (_) { el.dispatchEvent(new Event('input', { bubbles: true })); }
      el.dispatchEvent(new Event('change', { bubbles: true }));
      placeCaretAtEnd(el);
      return cleared;
    }
    return false;
  }

  function countOccurrences(text, needle) {
    const t = norm(text || '');
    const n = norm(needle || '');
    if (!t || !n) return 0;
    let count = 0;
    let idx = 0;
    while ((idx = t.indexOf(n, idx)) !== -1) {
      count += 1;
      idx += Math.max(n.length, 1);
    }
    return count;
  }
  function expectedRepeatCount(action) {
    // 默认每个动作只应把目标文本放入输入框 1 次。只有 AI 明确声明这是“同一输入框内重复文本”时才允许更高次数。
    const repeatMode = String(action && (action.repeatMode || action.inputRepeatMode || '') || '').toLowerCase();
    const explicitlyAllowed = !!(action && (action.allowRepeatedInput === true || action.allowRepeatedText === true || repeatMode.includes('input')));
    if (!explicitlyAllowed) return 1;
    const raw = Number(action && (action.expectedCount ?? action.repeatCount ?? action.inputCount));
    if (!Number.isFinite(raw) || raw < 1) return 1;
    return Math.max(1, Math.min(20, Math.floor(raw)));
  }
  function replaceEditableTextExactly(el, value) {
    const text = String(value || '');
    let frameworkSynced = false;
    if (!el) return { focused: false, frameworkSynced: false, after: '' };
    const focused = focusAndVerify(el);
    clearEditableBeforeMessage(el);
    try { el.focus && el.focus(); } catch (_) {}
    if (el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement || 'value' in el) {
      nativeSetValue(el, '');
      dispatchTextInputEvents(el, '', 'deleteContentBackward');
      try { if (typeof el.setRangeText === 'function') { el.setRangeText(text, 0, String(el.value || '').length, 'end'); frameworkSynced = true; } } catch (_) {}
      if (String(el.value || '') !== text) {
        nativeSetValue(el, text);
        frameworkSynced = true;
      }
      dispatchTextInputEvents(el, text, 'insertReplacementText');
      el.dispatchEvent(new Event('change', { bubbles: true }));
    } else if (el.isContentEditable || (el.getAttribute && (el.getAttribute('role') || '').toLowerCase() === 'textbox')) {
      placeCaretAtEnd(el);
      try { el.dispatchEvent(new InputEvent('beforeinput', { bubbles: true, cancelable: true, inputType: 'insertReplacementText', data: text })); } catch (_) {}
      try { frameworkSynced = !!(document.execCommand && document.execCommand('insertText', false, text)); } catch (_) { frameworkSynced = false; }
      if (norm(elementTextSnapshot(el)) !== norm(text)) {
        clearEditableBeforeMessage(el);
        const p = el.querySelector('p,div,span,[data-text],br') || el;
        if (p && p.tagName && String(p.tagName).toLowerCase() === 'br') {
          el.textContent = text;
        } else if (p) {
          p.textContent = text;
        } else {
          el.textContent = text;
        }
      }
      try { el.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertReplacementText', data: text })); } catch (_) { el.dispatchEvent(new Event('input', { bubbles: true })); }
      el.dispatchEvent(new Event('change', { bubbles: true }));
      try { el.dispatchEvent(new CompositionEvent('compositionend', { bubbles: true, data: text })); } catch (_) {}
    } else {
      for (const ch of text) dispatchKeyboard(el, ch, []);
    }
    return { focused, frameworkSynced, after: elementTextSnapshot(el) };
  }
  function ensureEditableTextWithinCount(el, value, allowedCount) {
    const target = String(value || '');
    const allowed = Math.max(1, Number(allowedCount || 1));
    const beforeRepair = elementTextSnapshot(el);
    const countBefore = countOccurrences(beforeRepair, target);
    const expectedText = allowed === 1 ? target : Array(allowed).fill(target).join('');
    const normalizedBefore = norm(beforeRepair);
    if (target && normalizedBefore === norm(expectedText) && countBefore === allowed) {
      return { ok: true, repaired: false, beforeRepair, afterRepair: beforeRepair, count: countBefore, expectedText };
    }
    // 如果输入框内容超过指定次数、少于指定次数、或混入旧草稿，统一重置成精确目标文本。
    const repair = replaceEditableTextExactly(el, expectedText);
    const afterRepair = elementTextSnapshot(el);
    const countAfter = countOccurrences(afterRepair, target);
    return {
      ok: norm(afterRepair) === norm(expectedText) && countAfter === allowed,
      repaired: true,
      beforeRepair,
      afterRepair,
      count: countAfter,
      expectedText,
      frameworkSynced: repair.frameworkSynced,
      focused: repair.focused
    };
  }

  function insertIntoRichEditor(el, text, action) {
    const value = String(text || '');
    const allowedCount = expectedRepeatCount(action || {});
    if (!el) return { ok: false, target: el, message: '没有找到消息输入框', focused: false, inserted: false, frameworkSynced: false, repaired: false, overInserted: false };
    const focused = focusAndVerify(el);
    const before = elementTextSnapshot(el);
    const normalizedBefore = norm(before);
    let frameworkSynced = false;
    let cleared = false;
    let repaired = false;
    const exactTarget = allowedCount === 1 ? value : Array(allowedCount).fill(value).join('');

    // 发送消息必须先把草稿校准成“精确目标文本”。重试时不追加，避免“的吃哇”变成“的吃哇的吃哇”。
    if (normalizedBefore && normalizedBefore !== norm(exactTarget)) {
      cleared = clearEditableBeforeMessage(el);
    } else if (normalizedBefore === norm(exactTarget)) {
      return {
        ok: focused,
        target: el,
        message: focused ? '聊天输入框内容已等于目标文本，未重复插入' : '输入框已有目标文本但未确认焦点',
        focused,
        activeMatches: isActiveWithin(el),
        inserted: true,
        frameworkSynced: true,
        before,
        after: elementTextSnapshot(el),
        repaired: false,
        overInserted: false,
        expectedCount: allowedCount
      };
    }

    if (el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement || 'value' in el) {
      const filled = smartFillTextField(el, exactTarget, true);
      frameworkSynced = !!filled.frameworkSynced;
    } else if (el.isContentEditable || (el.getAttribute('role') || '').toLowerCase() === 'textbox') {
      placeCaretAtEnd(el);
      try { el.dispatchEvent(new InputEvent('beforeinput', { bubbles: true, cancelable: true, inputType: 'insertText', data: exactTarget })); } catch (_) {}
      try { frameworkSynced = !!(document.execCommand && document.execCommand('insertText', false, exactTarget)); } catch (_) { frameworkSynced = false; }
      if (countOccurrences(elementTextSnapshot(el), value) < allowedCount) {
        clearEditableBeforeMessage(el);
        for (const ch of exactTarget) {
          dispatchKeyboard(el, ch, []);
          try { el.dispatchEvent(new InputEvent('beforeinput', { bubbles: true, cancelable: true, inputType: 'insertText', data: ch })); } catch (_) {}
          try { frameworkSynced = !!(document.execCommand && document.execCommand('insertText', false, ch)) || frameworkSynced; } catch (_) {}
        }
      }
      try { el.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: exactTarget })); } catch (_) { el.dispatchEvent(new Event('input', { bubbles: true })); }
      el.dispatchEvent(new Event('change', { bubbles: true }));
      try { el.dispatchEvent(new CompositionEvent('compositionend', { bubbles: true, data: exactTarget })); } catch (_) {}
    } else {
      for (const ch of exactTarget) dispatchKeyboard(el, ch, []);
    }

    let after = elementTextSnapshot(el);
    let occurrenceCount = countOccurrences(after, value);
    let overInserted = value && occurrenceCount > allowedCount;
    let inserted = norm(after) === norm(exactTarget) && occurrenceCount === allowedCount;
    if (!inserted || overInserted) {
      const guard = ensureEditableTextWithinCount(el, value, allowedCount);
      repaired = !!guard.repaired;
      after = guard.afterRepair;
      occurrenceCount = guard.count;
      inserted = !!guard.ok;
      overInserted = value && occurrenceCount > allowedCount;
      frameworkSynced = frameworkSynced || !!guard.frameworkSynced;
    }
    return {
      ok: focused && inserted && (frameworkSynced || !isTeamsPage()),
      target: el,
      message: focused ? (inserted ? (repaired ? '检测到输入次数不准确，已校准为目标文本' : (cleared ? '已清空草稿并写入目标文本' : '已写入目标文本')) : '已聚焦但无法把输入框校准为目标文本，未发送') : '点击/聚焦输入框后未获得输入焦点',
      focused,
      activeMatches: isActiveWithin(el),
      inserted,
      frameworkSynced,
      before,
      after,
      repaired,
      cleared,
      occurrenceCount,
      expectedCount: allowedCount,
      overInserted
    };
  }

  function findSendButton() {
    const selectors = [
      'button[aria-label*="发送"]', 'button[aria-label*="Send" i]', 'button[title*="发送"]', 'button[title*="Send" i]',
      '[role="button"][aria-label*="发送"]', '[role="button"][aria-label*="Send" i]',
      'button[data-tid*="send" i]', '[data-tid*="send" i]', 'button[class*="send" i]'
    ];
    for (const sel of selectors) {
      try {
        const found = Array.from(document.querySelectorAll(sel)).filter(visible).find(el => !el.disabled && el.getAttribute('aria-disabled') !== 'true');
        if (found) return found;
      } catch (_) {}
    }
    return Array.from(document.querySelectorAll('button,[role="button"]')).filter(visible).find(el => /发送|send/i.test(elementSearchText(el)) && !el.disabled && el.getAttribute('aria-disabled') !== 'true') || null;
  }
  function composerHasText(el, message) {
    const text = norm(elementTextSnapshot(el) || elementSearchText(el));
    return text.includes(String(message || '').trim());
  }
  function sendChatMessage(action, preferTeams) {
    const message = String(action.message || action.value || action.text || '').trim();
    if (!message) return JSON.stringify({ ok: false, category: 'message_missing', message: '发送消息缺少 message/value/text' });
    const allowedCount = expectedRepeatCount(action || {});

    const composer = findChatComposer(action);
    if (!composer) return JSON.stringify({ ok: false, category: 'composer_not_found', message: '没有找到聊天消息输入框', activeElement: activeElementInfo() });
    const beforeBody = norm(document.body ? document.body.innerText : '');
    const insert = insertIntoRichEditor(composer, message, action);
    if (!insert.focused) {
      const info = describeElement(composer, -1);
      return JSON.stringify({
        ok: false,
        category: 'composer_focus_failed',
        message: '找到了消息输入框，但点击后没有获得真实输入焦点，不能继续假装已输入。',
        x: info.rect.centerX,
        y: info.rect.centerY,
        targetText: norm(elementSearchText(composer)).slice(0, 160),
        activeElement: activeElementInfo(),
        focused: false
      });
    }
    if (insert.overInserted || insert.occurrenceCount > allowedCount) {
      const info = describeElement(composer, -1);
      return JSON.stringify({
        ok: false,
        category: 'message_over_input_guard',
        message: '发送前检测到输入次数超过要求，已尝试校准但仍不可靠，因此没有发送。下一轮应重新读取输入框后再继续。',
        x: info.rect.centerX,
        y: info.rect.centerY,
        targetText: norm(elementSearchText(composer)).slice(0, 160),
        activeElement: activeElementInfo(),
        focused: true,
        inserted: insert.inserted,
        before: insert.before,
        after: insert.after,
        occurrenceCount: insert.occurrenceCount,
        expectedCount: allowedCount
      });
    }
    if (!insert.inserted || (preferTeams && !insert.frameworkSynced && !composerHasText(composer, message))) {
      const info = describeElement(composer, -1);
      return JSON.stringify({
        ok: false,
        category: 'composer_insert_unverified',
        message: '已聚焦消息输入框，但没有可靠检测到消息被富文本编辑器接收，未发送。',
        x: info.rect.centerX,
        y: info.rect.centerY,
        targetText: norm(elementSearchText(composer)).slice(0, 160),
        activeElement: activeElementInfo(),
        focused: true,
        inserted: insert.inserted,
        frameworkSynced: insert.frameworkSynced,
        occurrenceCount: insert.occurrenceCount,
        expectedCount: allowedCount
      });
    }
    let sendButton = findSendButton();
    let method = 'enter';
    if (sendButton) {
      const rect = sendButton.getBoundingClientRect();
      clickAt(rect.left + rect.width / 2, rect.top + rect.height / 2, 1);
      method = 'send_button';
    } else {
      // 只触发一次发送动作。是否需要再次发送由后续步骤/用户要求决定，不在同一步里重复按键。
      dispatchKeyboard(composer, 'Enter', []);
    }
    const afterText = norm(document.body ? document.body.innerText : '');
    const composerStillHasMessage = composerHasText(composer, message);
    const appearsInPage = afterText.includes(message);
    const changed = beforeBody !== afterText;
    const info = describeElement(composer, -1);
    return JSON.stringify({
      ok: true,
      category: preferTeams ? 'teams_send_message' : 'send_message',
      message: '已把输入框校准为目标文本并发送' + (method === 'send_button' ? '（点击发送按钮）' : '（按 Enter 一次）') + '；下一轮必须读取页面确认消息是否出现在聊天记录中。',
      x: info.rect.centerX,
      y: info.rect.centerY,
      targetText: norm(elementSearchText(composer)).slice(0, 160),
      activeElement: activeElementInfo(),
      inserted: insert.inserted,
      focused: insert.focused,
      frameworkSynced: insert.frameworkSynced,
      repairedInput: !!insert.repaired,
      occurrenceCount: insert.occurrenceCount,
      expectedCount: allowedCount,
      method: method,
      composerStillHasMessage: composerStillHasMessage,
      appearsInPage: appearsInPage,
      pageChanged: changed
    });
  }

  function describeTarget(action) {
    let el = findElement(action);
    if (!el && typeof action.x === 'number' && typeof action.y === 'number') el = document.elementFromPoint(action.x, action.y);
    if (!el) return { ok: false, message: '没有找到目标元素', action };
    const info = describeElement(el, -1);
    const around = norm((el.closest('section,article,form,main,div') || el).innerText || '').slice(0, 500);
    info.nearbyText = around;
    return { ok: true, target: info, action };
  }
  function coordinateString(action) {
    if (typeof action.x === 'number' && typeof action.y === 'number') return '(' + Math.round(action.x) + ',' + Math.round(action.y) + ')';
    if (typeof action.startX === 'number' && typeof action.startY === 'number') return '(' + Math.round(action.startX) + ',' + Math.round(action.startY) + ')→(' + Math.round(action.endX || 0) + ',' + Math.round(action.endY || 0) + ')';
    return '';
  }
  function formSummary() {
    try {
      const inputs = Array.from(document.querySelectorAll('input,textarea,[contenteditable],[role="textbox"]'))
        .filter(visible)
        .slice(0, 80)
        .map(function(el, index) {
          const rect = el.getBoundingClientRect();
          return {
            index,
            tag: el.tagName ? el.tagName.toLowerCase() : '',
            type: el.getAttribute('type') || '',
            role: el.getAttribute('role') || '',
            placeholder: el.getAttribute('placeholder') || '',
            name: el.getAttribute('name') || '',
            label: labelText(el).slice(0, 120),
            value: safeValue(el),
            focused: document.activeElement === el || (el.contains && el.contains(document.activeElement)),
            disabled: !!el.disabled || el.getAttribute('aria-disabled') === 'true' || el.disabled === true,
            isContentEditable: !!el.isContentEditable,
            rect: { x: Math.round(rect.x), y: Math.round(rect.y), width: Math.round(rect.width), height: Math.round(rect.height), centerX: Math.round(rect.left + rect.width / 2), centerY: Math.round(rect.top + rect.height / 2) },
            searchText: norm(elementSearchText(el)).slice(0, 220)
          };
        });
      const buttons = Array.from(document.querySelectorAll('button,[role="button"],input[type="button"],input[type="submit"]'))
        .filter(visible)
        .slice(0, 100)
        .map(function(el, index) {
          const rect = el.getBoundingClientRect();
          return {
            index,
            tag: el.tagName ? el.tagName.toLowerCase() : '',
            type: el.getAttribute('type') || '',
            role: el.getAttribute('role') || '',
            text: norm(elementSearchText(el)).slice(0, 160),
            disabled: !!el.disabled || el.getAttribute('aria-disabled') === 'true' || el.disabled === true,
            focused: document.activeElement === el || (el.contains && el.contains(document.activeElement)),
            rect: { x: Math.round(rect.x), y: Math.round(rect.y), width: Math.round(rect.width), height: Math.round(rect.height), centerX: Math.round(rect.left + rect.width / 2), centerY: Math.round(rect.top + rect.height / 2) }
          };
        });
      return { inputs, buttons };
    } catch (e) {
      return { inputs: [], buttons: [], error: String(e && e.message ? e.message : e) };
    }
  }
  function safeInteractiveElements() {
    try {
      return interactiveElements();
    } catch (e) {
      return [{ index: -999, tag: 'error', text: 'interactiveElements failed: ' + String(e && e.message ? e.message : e), visible: false, rect: { x: 0, y: 0, width: 0, height: 0, centerX: 0, centerY: 0, pageX: 0, pageY: 0 } }];
    }
  }
  function safeCollectStateError(error) {
    return JSON.stringify({
      title: document.title || '',
      url: location.href || '',
      readyState: document.readyState || 'unknown',
      isLoading: document.readyState !== 'complete',
      hasFocus: document.hasFocus ? document.hasFocus() : false,
      activeElement: activeElementInfo(),
      lang: document.documentElement ? (document.documentElement.lang || '') : '',
      description: '',
      viewport: { width: innerWidth || 0, height: innerHeight || 0, scrollX: Math.round(scrollX || 0), scrollY: Math.round(scrollY || 0), fullHeight: 0 },
      coordinateSystem: 'viewport/client coordinates. Use rect.centerX/centerY for coordinateClick/doubleClick/swipe/drag.',
      selection: '',
      text: document.body ? norm(document.body.innerText || '').slice(0, 12000) : '',
      headings: [],
      inputButtonSummary: { inputs: [], buttons: [] },
      elements: [],
      collectError: String(error && error.message ? error.message : error)
    });
  }
  window.__liquidAgent = {
    version: '1.4.21',
    collectState: function() {
      try {
        const text = document.body ? norm(document.body.innerText).slice(0, 18000) : '';
        const selection = norm(String(window.getSelection ? window.getSelection() : '')).slice(0, 2000);
        const root = document.documentElement || document.body || { scrollHeight: 0, lang: '' };
        return JSON.stringify({
          title: document.title || '',
          url: location.href || '',
          readyState: document.readyState || 'unknown',
          isLoading: document.readyState !== 'complete',
          hasFocus: document.hasFocus ? document.hasFocus() : false,
          activeElement: activeElementInfo(),
          lang: root.lang || '',
          description: (document.querySelector('meta[name="description"]') || {}).content || '',
          viewport: { width: innerWidth || 0, height: innerHeight || 0, scrollX: Math.round(scrollX || 0), scrollY: Math.round(scrollY || 0), fullHeight: Math.round(root.scrollHeight || (document.body && document.body.scrollHeight) || 0) },
          coordinateSystem: 'viewport/client coordinates. Use rect.centerX/centerY for coordinateClick/doubleClick/swipe/drag.',
          selection,
          text,
          headings: Array.from(document.querySelectorAll('h1,h2,h3')).slice(0, 60).map(h => norm(h.innerText || h.textContent || '')).filter(Boolean),
          inputButtonSummary: formSummary(),
          elements: safeInteractiveElements()
        });
      } catch (e) {
        return safeCollectStateError(e);
      }
    },
    describeActionTarget: function(action) {
      try { return JSON.stringify(describeTarget(action)); }
      catch (e) { return JSON.stringify({ ok: false, message: String(e && e.message ? e.message : e) }); }
    },
    performAction: function(action) {
      try {
        const type = String(action.type || '').toLowerCase();
        if (type === 'navigate') {
          return JSON.stringify({ ok: false, category: 'native_navigation_required', message: 'navigate 必须由 App 原生 WKWebView.load 执行，避免触发外部 App scheme。' });
        }
        if (type === 'back') { history.back(); return JSON.stringify({ ok: true, category: 'back', message: '已返回上一页' }); }
        if (type === 'wait') { return JSON.stringify({ ok: true, category: 'wait', message: '已等待' }); }
        if (type === 'scroll') {
          const amount = action.amount || Math.round(innerHeight * 0.78);
          const direction = String(action.direction || 'down').toLowerCase();
          window.scrollBy({ top: direction === 'up' ? -amount : amount, behavior: 'smooth' });
          return JSON.stringify({ ok: true, category: 'scroll', message: '已滚动 ' + direction });
        }
        if (type === 'coordinateclick' || type === 'tap') {
          if (typeof action.x !== 'number' || typeof action.y !== 'number') return JSON.stringify({ ok: false, category: 'missing_coordinates', message: 'coordinateClick 缺少 x/y' });
          const hit = clickAt(action.x, action.y, 1);
          return JSON.stringify({ ok: true, category: 'coordinate_click', message: '已在坐标点击 ' + coordinateString(action), x: hit.x, y: hit.y, targetText: norm(elementSearchText(hit.target)).slice(0, 120) });
        }
        if (type === 'doubleclick') {
          const x = Number(action.x ?? Math.round(innerWidth / 2));
          const y = Number(action.y ?? Math.round(innerHeight / 2));
          const hit = doubleClickAt(x, y);
          return JSON.stringify({ ok: true, category: 'double_click', message: '已双击 ' + coordinateString({x:x,y:y}), x: Math.round(x), y: Math.round(y), targetText: norm(elementSearchText(hit.target)).slice(0, 120) });
        }
        if (type === 'swipe') {
          const hit = swipeOrDrag(action, true);
          return JSON.stringify({ ok: true, category: 'swipe', message: '已滑动/滚动', x: hit.x, y: hit.y, targetText: norm(elementSearchText(hit.target)).slice(0, 120) });
        }
        if (type === 'drag') {
          const hit = swipeOrDrag(action, false);
          return JSON.stringify({ ok: true, category: 'drag', message: '已拖动', x: hit.x, y: hit.y, targetText: norm(elementSearchText(hit.target)).slice(0, 120) });
        }
        if (type === 'sendmessage' || type === 'sendchatmessage' || type === 'teamssendmessage') {
          if (type === 'teamssendmessage' && !isTeamsPage()) {
            return JSON.stringify({ ok: false, category: 'not_teams_page', message: '当前页面不是 Teams，无法使用 Teams 专用发送动作' });
          }
          return sendChatMessage(action, type === 'teamssendmessage');
        }
        if (type === 'keypress' || type === 'pressenter' || type === 'presstab' || type === 'keyboardshortcut') {
          const key = type === 'pressenter' ? 'Enter' : (type === 'presstab' ? 'Tab' : (action.key || action.value || action.text || 'Enter'));
          if (type === 'pressenter' && isTeamsPage()) {
            const composer = findChatComposer(action);
            if (composer && isActiveWithin(composer) && composerHasText(composer, elementTextSnapshot(composer))) {
              let sendButton = findSendButton();
              if (sendButton) {
                const r = sendButton.getBoundingClientRect();
                clickAt(r.left + r.width / 2, r.top + r.height / 2, 1);
              } else {
                dispatchKeyboard(composer, 'Enter', []);
              }
              const info = describeElement(composer, -1);
              return JSON.stringify({ ok: true, category: 'teams_enter_send', message: 'Teams 输入框已聚焦，已尝试发送 Enter。下一轮必须检查聊天记录。', x: info.rect.centerX, y: info.rect.centerY, targetText: norm(elementSearchText(composer)).slice(0, 120), activeElement: activeElementInfo(), focused: true });
            }
          }
          const target = keyboardTarget(action);
          const focused = focusAndVerify(target);
          const hit = dispatchKeyboard(target, key, action.modifiers || []);
          const info = describeElement(hit.target, -1);
          return JSON.stringify({ ok: focused || keyCodeFor(key) === 'Tab', category: focused ? 'keyboard' : 'keyboard_focus_unverified', message: (focused ? '已发送键盘按键：' : '已尝试发送键盘按键但未确认输入焦点：') + keyCodeFor(key), x: info.rect.centerX, y: info.rect.centerY, targetText: norm(elementSearchText(hit.target)).slice(0, 120), activeElement: activeElementInfo(), focused: focused });
        }
        if (type === 'typetext') {
          const value = action.value || action.text || '';
          const target = isTeamsPage() ? (findChatComposer(action) || findTextEntryElement(action) || keyboardTarget(action)) : (findTextEntryElement(action) || keyboardTarget(action));
          const hit = isTeamsPage() ? insertIntoRichEditor(target, value) : smartFillTextField(target, value, false);
          const info = describeElement(hit.target, -1);
          return JSON.stringify({ ok: isTeamsPage() ? !!hit.ok : (!!hit.ok || (!!hit.focused && !!hit.inserted)), category: (!!hit.focused ? (isTeamsPage() && !hit.ok ? 'type_text_unverified_rich_editor' : 'type_text_keyboard_like') : 'type_text_focus_unverified'), message: hit.message || '已模拟键盘输入文本', x: info.rect.centerX, y: info.rect.centerY, targetText: norm(elementSearchText(hit.target)).slice(0, 120), activeElement: activeElementInfo(), focused: !!hit.focused, inserted: !!hit.inserted, frameworkSynced: !!hit.frameworkSynced, requireTeamsSendMessage: isTeamsPage() && !hit.ok });
        }
        if (type === 'settext' || type === 'modifypage') {
          const text = action.value || action.text || '';
          const el = findTextEntryElement(action) || findElement(action) || document.body;
          if (!el) return JSON.stringify({ ok: false, category: 'target_not_found', message: '没有找到可修改区域' });
          if (el === document.body && action.selector) return JSON.stringify({ ok: false, category: 'target_not_found', message: '没有找到 selector 对应元素' });
          if (isEditableElement(el)) {
            const hit = smartFillTextField(el, text, true);
            const info = describeElement(hit.target, -1);
            return JSON.stringify({ ok: !!hit.inserted, category: hit.focused ? 'set_text_keyboard_like' : 'set_text_focus_unverified', message: hit.message || '已用键盘式输入替代 setText', x: info.rect.centerX, y: info.rect.centerY, targetText: norm(elementSearchText(hit.target)).slice(0, 120), activeElement: activeElementInfo(), focused: !!hit.focused, inserted: !!hit.inserted, frameworkSynced: !!hit.frameworkSynced });
          }
          el.textContent = text;
          dispatchTextInputEvents(el, text, 'insertReplacementText');
          el.dispatchEvent(new Event('change', { bubbles: true }));
          const info = describeElement(el, -1);
          return JSON.stringify({ ok: true, category: 'set_text', message: '已修改网页文本', x: info.rect.centerX, y: info.rect.centerY, targetText: norm(elementSearchText(el)).slice(0, 120) });
        }
        if (type === 'sethtml') {
          const el = findElement(action);
          if (!el) return JSON.stringify({ ok: false, category: 'target_not_found', message: '没有找到可修改元素' });
          el.innerHTML = action.value || action.text || '';
          const info = describeElement(el, -1);
          return JSON.stringify({ ok: true, category: 'set_html', message: '已修改网页 HTML', x: info.rect.centerX, y: info.rect.centerY, targetText: norm(elementSearchText(el)).slice(0, 120) });
        }
        if (type === 'setstyle') {
          const el = findElement(action);
          if (!el) return JSON.stringify({ ok: false, category: 'target_not_found', message: '没有找到可修改元素' });
          el.style.cssText += ';' + (action.value || action.text || '');
          const info = describeElement(el, -1);
          return JSON.stringify({ ok: true, category: 'set_style', message: '已修改网页样式', x: info.rect.centerX, y: info.rect.centerY, targetText: norm(elementSearchText(el)).slice(0, 120) });
        }
        if (type === 'input') {
          const target = findTextEntryElement(action) || findElement(action);
          if (!target) return JSON.stringify({ ok: false, category: 'target_not_found', message: '没有找到可输入元素', action });
          const hit = smartFillTextField(target, action.value || action.text || '', true);
          const info = describeElement(hit.target, -1);
          return JSON.stringify({ ok: !!hit.inserted, category: hit.focused ? 'input_keyboard_like' : 'input_focus_unverified', message: hit.message || '已输入内容', x: info.rect.centerX, y: info.rect.centerY, targetText: norm(elementSearchText(hit.target)).slice(0, 120), activeElement: activeElementInfo(), focused: !!hit.focused, inserted: !!hit.inserted, frameworkSynced: !!hit.frameworkSynced });
        }
        const el = findElement(action);
        if (!el) return JSON.stringify({ ok: false, category: 'target_not_found', message: '没有找到目标元素', action });
        if (type === 'click') {
          const hit = realClick(el);
          return JSON.stringify({ ok: true, category: 'click', message: '已点击：' + norm(elementSearchText(el) || el.tagName).slice(0, 100), x: hit.x, y: hit.y, targetText: norm(elementSearchText(el)).slice(0, 120) });
        }
        if (type === 'select') {
          if (!(el instanceof HTMLSelectElement)) return JSON.stringify({ ok: false, category: 'wrong_target', message: '目标不是 select 元素' });
          const value = String(action.value || action.text || '').trim();
          let option = Array.from(el.options).find(o => String(o.value).trim() === value);
          if (!option) option = Array.from(el.options).find(o => norm(o.textContent || '').toLowerCase() === value.toLowerCase());
          if (!option) option = Array.from(el.options).find(o => norm(o.textContent || '').toLowerCase().includes(value.toLowerCase()));
          if (!option) return JSON.stringify({ ok: false, category: 'option_not_found', message: '没有找到匹配选项：' + value });
          el.value = option.value;
          el.dispatchEvent(new Event('input', { bubbles: true }));
          el.dispatchEvent(new Event('change', { bubbles: true }));
          const info = describeElement(el, -1);
          return JSON.stringify({ ok: true, category: 'select', message: '已选择选项：' + norm(option.textContent || option.value), x: info.rect.centerX, y: info.rect.centerY, targetText: norm(option.textContent || option.value) });
        }
        if (type === 'submit') {
          const form = el.form || el.closest('form');
          const info = describeElement(el, -1);
          if (form) { form.requestSubmit ? form.requestSubmit() : form.submit(); return JSON.stringify({ ok: true, category: 'submit', message: '已提交表单', x: info.rect.centerX, y: info.rect.centerY, targetText: norm(elementSearchText(el)).slice(0, 120) }); }
          const hit = realClick(el);
          return JSON.stringify({ ok: true, category: 'submit_click', message: '没有表单，已点击目标', x: hit.x, y: hit.y, targetText: norm(elementSearchText(el)).slice(0, 120) });
        }
        return JSON.stringify({ ok: false, category: 'unknown_action', message: '未知动作：' + type });
      } catch (e) {
        return JSON.stringify({ ok: false, category: 'exception', message: String(e && e.message ? e.message : e) });
      }
    }
  };
})();
"""#
}


private extension UIImage {
    func liquidCompressedJPEG(maxLongSide: CGFloat, quality: CGFloat) -> Data? {
        let width = max(size.width, 1)
        let height = max(size.height, 1)
        let longest = max(width, height)
        let scale = longest > maxLongSide ? (maxLongSide / longest) : 1
        let targetSize = CGSize(width: max(1, floor(width * scale)), height: max(1, floor(height * scale)))
        let format = UIGraphicsImageRendererFormat.default()
        format.scale = 1
        format.opaque = true
        let renderer = UIGraphicsImageRenderer(size: targetSize, format: format)
        let rendered = renderer.image { context in
            UIColor.white.setFill()
            context.fill(CGRect(origin: .zero, size: targetSize))
            self.draw(in: CGRect(origin: .zero, size: targetSize))
        }
        return rendered.jpegData(compressionQuality: quality)
    }
}
