# Changelog

## v1.4.21 (build 28)

- Refined chat/message input safety: repeated sends are no longer globally blocked.
- Added exact input guard so each send action verifies the composer contains only the expected target text.
- Added repair path for duplicated rich-text drafts such as `的吃哇的吃哇` before sending.
- Changed Teams Enter fallback to press Enter once instead of twice.
- Updated AI prompt: if multiple sends are required, they must be separate verified steps, not accidental duplicated input in the same composer.


## v1.4.17 / build 24 - Package Integrity Rebuild

- Rebuilt the source package with a clean root directory: `LiquidAIBrowser_v1_4_17/`.
- Incremented App version from `1.4.16` to `1.4.17`.
- Incremented build number from `23` to `24`.
- Verified the source zip structure with `unzip -t`: no compressed data errors.
- Added package integrity report for the damaged IPA Builder output zip.


## v1.4.16 buildfix2 - 2026-06-18

- Repackaged with a distinct root folder name (`LiquidAIBrowser_v1_4_16_buildfix2`) to avoid IPA Builder accidentally selecting/caching the old `LiquidAIBrowser_v1_4_16` source folder.
- Verified `WebViewPool.swift` raw string delimiter: `safeCollectStateScript` now closes with `"""#`, so `autoConsentScript` is parsed as a real static member.
- Added this build-fix report for diagnostics traceability.

# Changelog

## v1.4.16 build diagnostics patch 1

- 修复 Xcode 26.3 报错：`WebViewPool.swift` 中 `Self.autoConsentScript` 找不到。
- 原因：`safeCollectStateScript` 使用 `#"""` 开头，但结尾误写为 `"""`，导致 `autoConsentScript` 被吞进字符串而没有生成 Swift 成员。
- 修复：将 `safeCollectStateScript` 结尾改为 `"""#`，恢复 `autoConsentScript` 与 `agentBridgeScript` 的独立声明。
- 已做静态校验：3 个 `#"""` raw string 均匹配 3 个 `"""#` 结尾。

## v1.4.16

- 修复任务开始首次扫描页面立即失败：`A JavaScript exception occurred`。
- 补回 Agent Bridge 缺失的 `formSummary()`。
- `collectState()` 增加全量 try/catch，页面状态读取异常不再直接终止任务。
- 新增 `safeCollectStateScript`，bridge 未准备好或报错时返回 fallback 页面状态。
- Swift 侧 `collectPageState()` 增加重注入和 fallback JSON。
- Agent Bridge 增加版本号 `1.4.16`，允许覆盖旧 bridge。
- 版本号更新到 1.4.16 / build 23。

## v1.4.15

- Session 持久化改为防抖写入，降低长任务主线程 IO 压力。
- PDF 自动报告改为后台生成，避免任务完成时明显卡顿。
- 新增孤儿截图目录清理，减少长期使用后的缓存膨胀。
- WebKit 内容进程终止时自动 reload 恢复。
- Agent Bridge 未就绪时自动重注入并重试。
- about:blank 改为 loadHTMLString 空页面。
- 后台/零尺寸 WebView 截图前自动设置安全尺寸。
- 动作失败判断改为最近连续失败，避免累计失败误判。
- 普通 JS 动作增加 10 秒超时，URLRequest 增加 30 秒 timeout。
- 版本号更新到 1.4.15 / build 22。


### v1.4.15 build diagnostics patch

- 修复 Xcode 26.3 报错：`BrowserModels.swift` ambiguous `String.init`。
- 修复 Xcode 26.3 报错：`BrowserStore.swift` cannot find `excluding` in scope。
- 降低 `safeAction` 与计时器 worker 的并发捕获风险。
- 新增 `QA_V14_15_BUILD_AND_STABILITY_REPORT.md`。

## v1.4.14

- 设置页从 sheet 改为独立主页面。
- 任务完成后自动生成 PDF，任务卡可打开/分享已生成报告。
- 截图从内存/session JSON 改为文件存储，避免长任务 session 暴涨。
- `collectState()` 增强 readyState、isLoading、activeElement、focused、disabled、style、inputButtonSummary。
- 新增原生 `reload / forward / stopLoading / wait / back` 动作处理。
- `wait` 改为 Swift 原生等待，不再由 JS 立即返回。
- 失败任务折叠状态也显示失败原因。
- 新增清除失败任务、清除停止任务。
- 移除主界面系统 alert 和清空确认 dialog，改为 toast/banner。
- AI 后台任务切换页面不再抢占用户当前 UI。
- countUp 正计时器不再自动结束。
- 保存 AI 原始计划、重规划历史、raw plan response。
- PDF 增加原始计划、重规划历史、分组/页面信息、截图大小统计；截图显示高度提升。
- Agent 对页面读取和截图增加超时保护。

## v1.4.13

- 取消步骤截图数量限制。
- 增强 AI JSON 容错，减少“格式不稳定”导致长时间等待。
