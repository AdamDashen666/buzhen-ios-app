# LiquidAIBrowser v1.4.7 Browser / External Scheme / Retry Fix Report

## 本次目标

根据最新实机反馈，修复以下问题：

1. 网页尝试打开外部 App scheme 时不应弹出遮挡视野的提示框。
2. Agent 前往特定网站时必须留在 App 内置浏览器中，不应跳转到 iPad 外部 App。
3. 浏览器兼容性需要增强，减少“浏览器版本不受支持”的情况。
4. 任务管理里需要支持“重试任务”。

## 修改内容

### 1. 外部 App scheme 静默拦截

修改文件：`LiquidAIBrowser/WebViewPool.swift`

- `load(tabID:urlString:)` 遇到非 `http/https/about/file` scheme 时直接取消，不再设置 `alertMessage`。
- `decidePolicyFor navigationAction` 遇到 `douyin://`、`snssdk://`、`aweme://`、`bitbrowser://`、`itms-apps://`、`mailto:`、`tel:` 等外部 scheme 时直接 `.cancel`。
- `createWebViewWith` 遇到外部 scheme 也直接静默取消。
- 保留内置浏览器加载 `http` / `https` / `about` / `file`。

效果：网页不会再弹出“已阻止网页打开外部 App”的系统提示，也不会跳到外部 App。

### 2. 禁止 JS navigate 直接改 location.href

修改文件：`LiquidAIBrowser/WebViewPool.swift`

- Agent Bridge 里的 JS `navigate` 不再执行 `location.href = ...`。
- 所有 `navigate` 都必须走 `AgentEngine` 的原生 `WKWebView.load`。

原因：某些网站或 App scheme 通过 JS 直接改地址可能触发外部 App 跳转。改成原生加载后，可以统一经过 App 的 URL 过滤逻辑。

### 3. 浏览器兼容性增强

修改文件：`LiquidAIBrowser/WebViewPool.swift`

新增/调整：

- `configuration.defaultWebpagePreferences.preferredContentMode = .desktop`
- `configuration.preferences.javaScriptCanOpenWindowsAutomatically = true`
- `configuration.mediaTypesRequiringUserActionForPlayback = []`
- `configuration.applicationNameForUserAgent = "Version/18.0 Safari/605.1.15"`
- `webView.customUserAgent = desktopSafariUserAgent`
- `webView.allowsLinkPreview = false`
- `webView.isInspectable = true`，仅 iOS 16.4+
- `scrollView.keyboardDismissMode = .interactive`

目标：让 WKWebView 更接近 iPad/桌面 Safari 浏览器环境，减少部分网站直接识别为“旧浏览器/不支持浏览器”的情况。

限制：iOS App 内核仍然是 WKWebView/WebKit，无法真正变成 Edge/Chrome 内核。某些强制要求 Chrome/Edge 的网站仍可能拒绝。

### 4. 新增重试任务

修改文件：

- `LiquidAIBrowser/BrowserStore.swift`
- `LiquidAIBrowser/Panels.swift`

新增能力：

- 失败/停止/完成后的任务卡显示：
  - `重试`
  - `按原计划重试`
- `重试`：使用原用户要求创建一个新任务，重新扫描页面并重新规划。
- `按原计划重试`：保留旧任务的目标分析和步骤标题，但所有步骤重新置为未完成，然后重新执行。
- 如果同一分组已有运行任务，重试任务会进入队列。
- 重试任务尽量复用原任务参与过的页面。

## 静态检查

已完成：

```text
swiftc -parse LiquidAIBrowser/*.swift OK
Agent Bridge JS node --check OK
Info.plist OK
project.pbxproj 版本号 OK
外部 scheme 弹窗文案已移除 OK
重试任务按钮已接入 OK
```

## 版本

- Version: 1.4.7
- Build: 14

## 仍需真机验证

- Teams / Microsoft 登录页面是否仍提示浏览器不支持。
- 抖音页面点击“Get App”等入口是否只静默取消、不再弹窗、不再跳 App。
- 失败任务点击“重试”是否能正常创建新任务并执行。
- `按原计划重试` 是否能按旧计划重新跑。
