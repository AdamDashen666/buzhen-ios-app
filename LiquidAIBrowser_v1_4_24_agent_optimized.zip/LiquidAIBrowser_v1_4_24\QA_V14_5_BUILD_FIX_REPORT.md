# QA v1.4.5 Build Fix Report

## 输入诊断包

用户上传：`Build-Diagnostics-Newest-9-1.zip`

诊断包中实际构建目录显示为：

`LiquidAIBrowser_v1_4_3`

说明这次 IPA Builder 选中的包仍是 v1.4.3，而不是后续 v1.4.4。不过本次修复基于最新 v1.4.4 代码继续升级到 v1.4.5。

## 主要错误

```text
BrowserStore.swift:221:9: error:
call to main actor-isolated instance method 'loadURLInTab(tabID:urlString:)'
in a synchronous nonisolated context
```

## 原因

`loadURLInTab(tabID:urlString:)` 被标记为 `@MainActor`，但 `loadSelectedAddress(_:)` 是普通同步方法，直接调用了这个 MainActor 隔离方法。Xcode 26.3 / Swift 6.2 对并发隔离检查更严格，因此编译失败。

## 修复

将 `loadSelectedAddress(_:)` 同样标记为 `@MainActor`：

```swift
@MainActor
func loadSelectedAddress(_ text: String) {
    let normalized = normalizedURLString(text)
    guard let id = selectedTabID else {
        createTab(urlString: normalized, select: true)
        return
    }
    loadURLInTab(tabID: id, urlString: normalized)
}
```

## 为什么这样修

地址栏加载、AI 内置浏览器导航、WKWebView 加载和 SwiftUI 状态更新都应在主线程执行。将调用入口也标记为 `@MainActor` 是最小修改，并且符合 UI/WebView 操作线程要求。

## 版本

- App version：`1.4.5`
- Build：`12`

## 静态检查

- `Info.plist` 版本检查：OK
- `project.pbxproj` 版本检查：OK
- `BrowserStore.swift` MainActor 修复检查：OK
- `project.pbxproj` 文件引用检查：OK
- zip 完整性：OK

## 未能执行

当前环境无法运行 macOS Xcode，因此不能实际执行 `xcodebuild clean build`。请用 v1.4.5 重新上传 IPA Builder。如果还有新的 Build-Diagnostics zip，继续发回来。
