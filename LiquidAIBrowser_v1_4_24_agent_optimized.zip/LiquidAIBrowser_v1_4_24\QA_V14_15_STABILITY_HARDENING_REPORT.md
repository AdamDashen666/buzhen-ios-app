# LiquidAIBrowser v1.4.15 稳定性加固检查报告

## 目标

本版本不新增大功能，重点根据 v1.4.14 继续排查长任务、后台页面、PDF、截图、WebKit 和 Agent 执行链路的稳定性问题。

## 主要修复

### 1. Session 持久化改为防抖写入

问题：v1.4.14 每条日志、每张截图、每次状态变化都可能立即写 session JSON，长任务中会频繁阻塞主线程。

修复：
- `persistSession()` 改为 0.35 秒防抖写入。
- 新增 `persistSessionImmediately()` 用于需要立即落盘的场景。
- Session 继续移除截图二进制，只保存截图文件路径。

收益：
- 降低主线程 IO 压力。
- 减少长任务 UI 卡顿。
- 减少大量日志/截图时频繁写文件导致的停顿。

### 2. PDF 自动生成改为后台生成

问题：任务完成后自动生成 PDF 如果在主线程执行，容易造成完成瞬间卡顿，尤其长任务截图多时更明显。

修复：
- 新增 `generateReportPDFInBackground(taskID:share:)`。
- 任务完成后后台导出 PDF。
- 导出完成后回主线程更新 `pdfReportURLString` 和任务日志。
- 不自动弹分享 sheet。

收益：
- 任务完成瞬间不再明显卡 UI。
- 后续队列任务不会被 PDF 导出阻塞太久。

### 3. 截图缓存目录清理

问题：清除任务后可能残留截图目录；长期使用可能累计无主缓存。

修复：
- `SnapshotFileStore` 新增：
  - `taskSnapshotDirectory(taskID:)`
  - `totalSize(taskID:)`
  - `removeOrphanedSnapshots(validTaskIDs:)`
- App 启动 / session 恢复后清理孤儿截图目录。

收益：
- 减少长期使用后的磁盘膨胀。
- 避免已删除任务的截图继续占空间。

### 4. WebKit 内容进程终止自动恢复

问题：iPadOS 可能回收后台 `WKWebView` 内容进程，导致后台页面变空或 Agent 后续读取失败。

修复：
- 实现 `webViewWebContentProcessDidTerminate(_:)`。
- WebKit 内容进程终止时更新 tab 状态并自动 reload。

收益：
- 后台标签页更稳定。
- 减少长任务中页面突然不可读的问题。

### 5. Agent Bridge 自动重注入

问题：少数页面或刚加载完成时，`window.__liquidAgent` 可能还没准备好，导致 “Agent bridge not ready”。

修复：
- `evaluateJSON` 检测 bridge 未就绪时：
  1. 重新注入 auto consent 脚本。
  2. 重新注入 agent bridge 脚本。
  3. 重试原 JS。

收益：
- 减少页面刚加载时动作/读取失败。
- 提高后台页面、重载页面的恢复成功率。

### 6. about:blank 加载逻辑稳定化

问题：直接用 URLRequest 加载 `about:blank` 在部分 WebKit 环境里可能表现不一致。

修复：
- `about:blank` 改用 `loadHTMLString("", baseURL:nil)`。
- 同步更新 tab 标题、URL、loading 状态。

收益：
- 空白初始页更稳定。
- 避免空页面状态异常。

### 7. 后台 / 零尺寸 WebView 截图修复

问题：后台 `WKWebView` 没有附着视图层时，bounds 可能为 0，截图失败或空白。

修复：
- 截图前如果 bounds 太小，临时设为 `1024x768` 并 layout。
- 继续按 720p 等比例压缩输出。

收益：
- 后台分组页面截图成功率更高。
- PDF 中空白截图减少。

### 8. 动作失败判断从累计失败改为连续失败

问题：v1.4.14 用 `failureCount` 累计总失败次数判断是否超过重试上限。长任务中早期失败累计后，后续一次小失败也可能被误判为连续失败。

修复：
- 新增 `recentActionFailureStreak(task:limit:)`。
- 只有最近连续 N 个动作都失败，才触发“优先坐标/重规划/人工接管”逻辑。

收益：
- 长任务更稳。
- 减少因为历史失败导致后续正常步骤被误判。

### 9. 普通网页 JS 动作增加 10 秒超时

问题：`performAction` 里 `evaluateJavaScript` 如果 WebKit 卡住，Agent 可能长时间挂住。

修复：
- 普通网页 JS 动作通过 `withTimeout(seconds:10)` 包裹。
- 原生 wait / timer 不受这个 10 秒限制。

收益：
- 单步动作卡死概率降低。
- 卡住时能更快进入重规划或失败处理。

### 10. URL 请求 timeout 补充

修复：
- 原生导航 `URLRequest.timeoutInterval = 30`。

收益：
- 网络异常时减少无限等待概率。

## 静态检查结果

已通过：

```text
swiftc -parse LiquidAIBrowser/*.swift OK
Info.plist version 1.4.15 / build 22 OK
project.pbxproj MARKETING_VERSION / CURRENT_PROJECT_VERSION OK
zip 完整性 OK
```

## 仍需真机验证

当前环境不能运行 macOS Xcode / iPad 真机测试，仍需重点验证：

- 长任务连续运行 30+ 分钟。
- 后台分组 WebView 被系统回收后的自动 reload。
- PDF 大量截图后台生成时 UI 是否不卡。
- Session 恢复是否保留任务、页面、截图文件路径。
- Teams 富文本发送和最终验证。
- Stage Manager 窗口化下截图是否正常。
