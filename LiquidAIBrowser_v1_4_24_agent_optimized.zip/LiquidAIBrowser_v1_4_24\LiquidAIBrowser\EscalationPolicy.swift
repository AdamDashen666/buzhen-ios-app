import Foundation

struct EscalationDecision {
    let shouldUsePro: Bool
    let shouldCaptureVision: Bool
    let useFullContext: Bool
    let waitingUser: Bool
    let reason: String

    static let none = EscalationDecision(shouldUsePro: false, shouldCaptureVision: false, useFullContext: false, waitingUser: false, reason: "normal fast path")
}

struct EscalationPolicy {
    func evaluate(task: AgentTask, compactContext: CompactPageContext, snapshot: AISettingsSnapshot, lastDecision: AgentDecision? = nil) -> EscalationDecision {
        if let reason = userTakeoverReason(task: task, compactContext: compactContext) {
            return EscalationDecision(shouldUsePro: false, shouldCaptureVision: false, useFullContext: false, waitingUser: true, reason: reason)
        }

        let consecutiveActionFailureCount = consecutiveActionFailures(task: task)
        let lowerFailure = task.lastFailureCategory.lowercased()
        let targetNotFound = lowerFailure.contains("target_not_found") || lowerFailure.contains("selector") || lowerFailure.contains("not_found")
        let lowConfidence = (lastDecision?.confidence ?? 1.0) < 0.58
        let needsVision = lastDecision?.needsVision == true
        let sparseOrCanvas = compactContext.isSparseDOM || compactContext.hasCanvas
        let repeatedFailure = consecutiveActionFailureCount >= max(2, min(snapshot.maxActionRetries, 3))
        let visionAllowed = snapshot.enableVisionScreenshots && snapshot.visionMode != .off
        let failureVisionAllowed = visionAllowed && snapshot.visionMode == .onFailureOnly
        let everyStepVision = visionAllowed && snapshot.visionMode == .everyStep

        if everyStepVision {
            return EscalationDecision(shouldUsePro: true, shouldCaptureVision: true, useFullContext: true, waitingUser: false, reason: "visionMode everyStep")
        }

        if needsVision || (failureVisionAllowed && (targetNotFound || repeatedFailure || sparseOrCanvas)) {
            return EscalationDecision(shouldUsePro: true, shouldCaptureVision: true, useFullContext: true, waitingUser: false, reason: "needsVision after target_not_found or sparse DOM")
        }

        if targetNotFound || repeatedFailure || lowConfidence || sparseOrCanvas {
            return EscalationDecision(shouldUsePro: true, shouldCaptureVision: false, useFullContext: true, waitingUser: false, reason: "Pro escalation without vision")
        }

        return .none
    }

    func shouldCapturePDFSnapshot(task: AgentTask, actionType: String?) -> Bool {
        if task.stepSnapshots.isEmpty { return true }
        if let actionType, ["click", "input", "sendMessage", "teamsSendMessage", "navigate", "createTab", "verify"].contains(actionType) {
            return task.iteration % 2 == 0 || task.failureCount > 0
        }
        return task.iteration % 3 == 0
    }

    private func consecutiveActionFailures(task: AgentTask) -> Int {
        var count = 0
        for entry in task.log.reversed() {
            guard entry.actionType != nil else { continue }
            if entry.level == .warning || entry.level == .error {
                count += 1
            } else {
                break
            }
        }
        return count
    }

    private func userTakeoverReason(task: AgentTask, compactContext: CompactPageContext) -> String? {
        let combined = (task.currentAction + " " + task.lastError + " " + compactContext.jsonString).lowercased()
        let sensitiveSignals = [
            "captcha", "verification code", "verify you are human", "password", "passcode", "one-time code",
            "payment", "checkout", "credit card", "bank card", "delete account",
            "验证码", "人机验证", "登录密码", "付款", "支付", "信用卡", "银行卡", "删除账号"
        ]
        if let signal = sensitiveSignals.first(where: { combined.contains($0.lowercased()) }) {
            return "waitingUser: page contains sensitive/manual step (\(signal))"
        }
        return nil
    }
}
