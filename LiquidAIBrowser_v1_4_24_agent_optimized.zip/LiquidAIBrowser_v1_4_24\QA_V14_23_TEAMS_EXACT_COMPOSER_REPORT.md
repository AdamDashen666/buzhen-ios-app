# QA v1.4.23 - Teams Exact Composer Report

## Scope

Fix the repeated Teams message draft issue where a requested single message, for example:

```text
晚上回来吃饭吗，记得带酱油，别加班到太晚
```

could become duplicated in the Teams rich-text composer before sending.

## Evidence from user report

The uploaded PDF showed:

- `sendMessage` detected `message_over_input_guard`.
- The active Teams composer contained the target message twice.
- `occurrenceCount = 2`, while `expectedCount = 1`.
- Later recovery steps repeatedly tried `Ctrl+A`, but the old shortcut implementation only dispatched a synthetic `a` key and did not truly select the editable content.

## Root cause

Teams uses a complex CKEditor/React contenteditable composer. The previous bridge could emit both:

1. a `beforeinput` / input-style event containing the full text, and
2. `execCommand('insertText')` or follow-up DOM insertion.

Some rich editors process both paths, so the same target text can be inserted twice during one send action.

## Changes

### 1. Atomic composer replacement

For contenteditable / role=textbox message composers, `replaceEditableTextExactly()` now:

- clears the composer,
- inserts the exact target text once,
- emits a single sync `input` event with `data = null`,
- rechecks the composer text,
- hard-normalizes again if the framework duplicates or rehydrates stale text.

It avoids the high-risk `beforeinput + execCommand(insertText)` double insertion combination for Teams message sending.

### 2. teamsSendMessage exact pre-send guard

`sendMessage` / `teamsSendMessage` still require:

- `occurrenceCount == expectedCount`,
- normalized composer text exactly matches the expected text,
- default `expectedCount = 1`, unless the action explicitly allows repeated input.

If the input is not exact, the bridge attempts repair before sending rather than appending again.

### 3. Real keyboard shortcut handling

`keyboardShortcut` now handles editable-field operations directly:

- `Ctrl+A`, `Cmd+A`, `Command+A`, or action descriptions containing “全选” select the actual editable contents.
- `Backspace` / `Delete` delete the selected text or clear the editable field.

This prevents loops where the AI believes it has selected all text, but the page only receives a harmless synthetic `a` key.

## Versioning

- Marketing version: `1.4.23`
- Build: `30`
- Bridge version: `1.4.23`

## Static checks

- `node --check agentBridgeScript`: passed.
- `Info.plist` version/build inspected.
- `project.pbxproj` MARKETING_VERSION/CURRENT_PROJECT_VERSION inspected.

## Limitations

- This environment cannot run Xcode or a real WKWebView/Teams session.
- Teams can still change its DOM/CKEditor implementation, so runtime validation in IPA Builder/TestFlight is still required.
