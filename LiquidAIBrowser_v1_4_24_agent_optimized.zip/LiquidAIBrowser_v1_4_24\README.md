## v1.4.24 / Build 31 - Manual Navbar Collapse

- 顶部网页导航栏默认保持展开，不再自动收起。
- 新增导航栏手动收起按钮，避免用户/AI 输入网页内容时因为自动收起导致焦点丢失。
- 收起后顶部保留热区，鼠标/指针移动到页面上方会自动拉出导航栏。
- 保留页面输入、AI 操作、地址栏同步和上一版 Teams 输入保护能力。
- QA: see `QA_V14_24_MANUAL_NAVBAR_COLLAPSE_REPORT.md`.

# Liquid AI Browser v1.4.19

## v1.4.19 重点

本版专门修复任务开始扫描页面时出现 `A JavaScript exception occurred` 的问题。

核心修复：

- 补回 Agent Bridge 中缺失的 `formSummary()`。
- `collectState()` 全量 try/catch，任何页面读取异常都返回 fallback 状态。
- Swift 侧页面扫描失败后自动重注入 bridge 并重试。
- 旧 bridge / 半损坏 bridge 可以被 v1.4.19 新 bridge 覆盖。
- 初始 about:blank、Teams 登录页、Teams 聊天页扫描失败不应再直接终止任务。

保留 v1.4.15 的稳定性修复：

- session 防抖写入
- PDF 后台生成
- 截图文件落盘
- 孤儿截图缓存清理
- WebKit 内容进程终止自动恢复
- Agent Bridge 自动重注入
- JS 动作超时保护

## 历史说明


本版本根据外部静态检查建议，重点修复 Requirements 合规缺口和长任务稳定性。

## v1.4.15 重点

- 设置页改为独立页面，不再是 sheet。
- 任务完成后自动生成 PDF，但不自动弹分享窗口。
- 截图改为文件存储，避免 session JSON 暴涨。
- collectState 增强 readyState / activeElement / focused / disabled / style 等字段。
- 新增 reload / forward / stopLoading / 原生 wait。
- 失败任务折叠后仍显示失败原因。
- 新增清除失败任务、清除停止任务。
- 移除系统 alert / 清空确认 dialog，改用 toast。
- 后台任务切换页面不再抢占用户当前 UI。
- countUp 正计时不会自动结束。
- 保存 AI 原始计划、重规划历史，并写入 PDF。

# Liquid AI Browser v1.4.11

## v1.4.11 重点

- 修复多网站测试任务中 AI 容易“忘记已验证结果”的问题。
- 新增结构化 findings/事实记忆：每轮可记录平台/网站结论、状态、证据和 URL。
- 最终验收改为读取所有参与页面状态，不再只看当前活动页面。
- 修复计时器结束后重复显示“任务 worker 已启动”的体验问题。
- 修复步骤截图被重复缓存的问题。
- 修复 PDF 已选择关键截图但实际仍输出全部截图的问题。
- PDF 报告继续使用 720p 等比例截图，最多 10 张关键图，日志最多 120 行；完整日志仍在任务卡复制。

## 使用建议

对“比较多个网站/多个页面”的任务，AI 会记录每个对象的结论，最终报告会列出事实记忆。

- 稳定性专项加固：session 防抖写入、PDF 后台生成、孤儿截图清理。
- WebKit 内容进程终止自动恢复，Agent Bridge 未就绪时自动重注入。
- about:blank 加载更稳定，后台零尺寸 WebView 截图修复。
- 动作失败改为连续失败判定，避免长任务因历史失败误判。
- 普通网页 JS 动作增加 10 秒超时，导航请求增加 30 秒 timeout。


## v1.4.15 build diagnostics patch

本版已合并 `Build-Diagnostics-Newest-14-1.zip` 中发现的 Xcode 26.3 编译问题修复，并保留 v1.4.15 稳定性加固。

## v1.4.19 隐私分组隔离

- 每个分组使用独立的 `WKProcessPool` + `WKWebsiteDataStore.nonPersistent()`，Web Cookie、LocalStorage、IndexedDB、缓存和 Service Worker 不跨分组共享。
- 新建分组等价于一个新的临时浏览器环境。
- 关闭/删除分组会销毁该分组页面、停止并移除该分组任务、清除计时器、截图缓存、PDF 报告和 WebKit 临时数据。
- 清空所有分组会同步清空所有分组相关任务和临时数据，避免任务报告/截图残留造成混淆。
