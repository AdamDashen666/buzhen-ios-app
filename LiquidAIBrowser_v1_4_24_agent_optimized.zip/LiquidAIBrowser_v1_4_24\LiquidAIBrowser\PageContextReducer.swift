import Foundation

struct CompactPageContext {
    let jsonString: String
    let keywords: [String]
    let elementCount: Int
    let inputCount: Int
    let buttonCount: Int
    let hasCanvas: Bool
    let isSparseDOM: Bool
}

struct PageContextReducer {
    func compact(pageJSON: String, goal: String, checklist: [TaskChecklistItem], recentLogs: [TaskLogEntry], maxCharacters: Int = 8_000) -> CompactPageContext {
        let source = decodeObject(pageJSON)
        let keywords = buildKeywords(goal: goal, checklist: checklist, logs: recentLogs)
        let text = redactedString(source["text"] as? String ?? "")
        let elements = source["elements"] as? [[String: Any]] ?? []
        let compactInputs = compactFormItems(source: source, key: "inputs", limit: 40)
        let compactButtons = compactFormItems(source: source, key: "buttons", limit: 50)
        let compactElements = compactInteractiveElements(elements: elements, keywords: keywords, limit: 90)
        let links = compactElements.filter { (($0["tag"] as? String) ?? "").lowercased() == "a" }.prefix(30)
        let textExcerpt = focusedTextExcerpt(text: text, keywords: keywords, maxCharacters: 3_000)
        let activeElement = compactDictionary(source["activeElement"] as? [String: Any], keys: ["tag", "type", "role", "text", "placeholder", "name", "value", "label", "selector", "focused", "disabled", "rect"])
        let viewport = compactDictionary(source["viewport"] as? [String: Any], keys: ["width", "height", "scrollX", "scrollY", "fullHeight"])
        let hasCanvas = text.lowercased().contains("canvas") || elements.contains { (($0["tag"] as? String) ?? "").lowercased() == "canvas" }

        var payload: [String: Any] = [
            "title": redactedString(source["title"] as? String ?? ""),
            "url": redactedString(source["url"] as? String ?? ""),
            "readyState": source["readyState"] as? String ?? "",
            "isLoading": source["isLoading"] as? Bool ?? false,
            "hasFocus": source["hasFocus"] as? Bool ?? false,
            "activeElement": activeElement,
            "viewport": viewport,
            "keywords": keywords,
            "textExcerpt": textExcerpt,
            "headings": (source["headings"] as? [String] ?? []).prefix(30).map { redactedString($0) },
            "inputs": compactInputs,
            "buttons": compactButtons,
            "links": Array(links),
            "elements": compactElements,
            "elementStats": [
                "all": elements.count,
                "kept": compactElements.count,
                "inputs": compactInputs.count,
                "buttons": compactButtons.count,
                "hasCanvas": hasCanvas
            ],
            "contextMode": "compact"
        ]

        var json = encodeJSON(payload)
        if json.count > maxCharacters {
            payload["textExcerpt"] = String(textExcerpt.prefix(1_400))
            payload["elements"] = Array(compactElements.prefix(45))
            payload["buttons"] = Array(compactButtons.prefix(30))
            payload["inputs"] = Array(compactInputs.prefix(25))
            json = encodeJSON(payload)
        }

        if json.count > maxCharacters {
            json = String(json.prefix(maxCharacters))
        }

        return CompactPageContext(
            jsonString: json,
            keywords: keywords,
            elementCount: elements.count,
            inputCount: compactInputs.count,
            buttonCount: compactButtons.count,
            hasCanvas: hasCanvas,
            isSparseDOM: elements.isEmpty && compactInputs.isEmpty && compactButtons.isEmpty
        )
    }

    private func decodeObject(_ value: String) -> [String: Any] {
        guard let data = value.data(using: .utf8),
              let object = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else {
            return ["text": value]
        }
        return object
    }

    private func buildKeywords(goal: String, checklist: [TaskChecklistItem], logs: [TaskLogEntry]) -> [String] {
        let nextSteps = checklist.filter { !$0.isDone }.prefix(4).flatMap { [$0.title, $0.detail] }
        let logText = logs.suffix(4).map(\.message)
        let raw = ([goal] + nextSteps + logText).joined(separator: " ")
        let tokens = raw
            .components(separatedBy: CharacterSet.alphanumerics.inverted)
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { $0.count >= 3 && $0.count <= 28 }
        var seen = Set<String>()
        var output: [String] = []
        for token in tokens {
            let key = token.lowercased()
            guard !seen.contains(key) else { continue }
            seen.insert(key)
            output.append(token)
            if output.count >= 18 { break }
        }
        return output
    }

    private func focusedTextExcerpt(text: String, keywords: [String], maxCharacters: Int) -> String {
        guard !text.isEmpty else { return "" }
        var snippets: [String] = []
        let lower = text.lowercased()
        for keyword in keywords.prefix(10) {
            guard let range = lower.range(of: keyword.lowercased()) else { continue }
            let start = text.index(range.lowerBound, offsetBy: -260, limitedBy: text.startIndex) ?? text.startIndex
            let end = text.index(range.upperBound, offsetBy: 520, limitedBy: text.endIndex) ?? text.endIndex
            snippets.append(String(text[start..<end]))
        }
        let joined = snippets.isEmpty ? String(text.prefix(maxCharacters)) : snippets.joined(separator: "\n---\n")
        return String(joined.prefix(maxCharacters))
    }

    private func compactFormItems(source: [String: Any], key: String, limit: Int) -> [[String: Any]] {
        let summary = source["inputButtonSummary"] as? [String: Any] ?? [:]
        let items = summary[key] as? [[String: Any]] ?? []
        return items.prefix(limit).map { item in
            compactDictionary(item, keys: ["index", "tag", "type", "role", "text", "placeholder", "name", "label", "value", "selector", "focused", "disabled", "isContentEditable", "rect", "searchText"])
        }
    }

    private func compactInteractiveElements(elements: [[String: Any]], keywords: [String], limit: Int) -> [[String: Any]] {
        let visible = elements.filter { ($0["visible"] as? Bool) ?? true }
        let scored = visible.map { element -> (Int, [String: Any]) in
            let text = redactedString([
                element["text"] as? String,
                element["placeholder"] as? String,
                element["label"] as? String,
                element["value"] as? String,
                element["href"] as? String,
                element["title"] as? String
            ].compactMap { $0 }.joined(separator: " "))
            let lower = text.lowercased()
            let keywordScore = keywords.reduce(0) { score, keyword in
                lower.contains(keyword.lowercased()) ? score + 20 : score
            }
            let tag = ((element["tag"] as? String) ?? "").lowercased()
            let actionScore = ["button", "input", "textarea", "select", "a"].contains(tag) ? 10 : 0
            let viewportScore = isInViewport(element["rect"] as? [String: Any]) ? 6 : 0
            return (keywordScore + actionScore + viewportScore, compactDictionary(element, keys: ["index", "tag", "type", "role", "text", "placeholder", "name", "value", "href", "title", "id", "label", "selector", "visible", "disabled", "focused", "rect"]))
        }
        return scored.sorted { $0.0 > $1.0 }.prefix(limit).map(\.1)
    }

    private func isInViewport(_ rect: [String: Any]?) -> Bool {
        guard let rect,
              let y = rect["y"] as? Int,
              let height = rect["height"] as? Int else { return true }
        return y + height >= -40 && y <= 1_400
    }

    private func compactDictionary(_ value: [String: Any]?, keys: [String]) -> [String: Any] {
        guard let value else { return [:] }
        var output: [String: Any] = [:]
        for key in keys {
            guard let raw = value[key] else { continue }
            if let string = raw as? String {
                output[key] = redactedString(String(string.prefix(220)))
            } else if let dict = raw as? [String: Any] {
                output[key] = compactDictionary(dict, keys: ["x", "y", "width", "height", "centerX", "centerY", "pageX", "pageY"])
            } else {
                output[key] = raw
            }
        }
        return output
    }

    private func redactedString(_ value: String) -> String {
        var output = value
        let replacements: [(String, String, NSRegularExpression.Options)] = [
            (#"[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}"#, "[REDACTED_EMAIL]", [.caseInsensitive]),
            (#"(?<!\d)(?:\+?\d[\d\s\-\(\)]{7,}\d)(?!\d)"#, "[REDACTED_PHONE]", []),
            (#"\b(?:\d[ -]*?){13,19}\b"#, "[REDACTED_CARD]", []),
            (#"(?i)(password|passcode|otp|token|secret|api[_-]?key)\s*[:=]\s*\S+"#, "$1=[REDACTED]", [])
        ]
        for (pattern, marker, options) in replacements {
            guard let regex = try? NSRegularExpression(pattern: pattern, options: options) else { continue }
            let range = NSRange(output.startIndex..<output.endIndex, in: output)
            output = regex.stringByReplacingMatches(in: output, options: [], range: range, withTemplate: marker)
        }
        return output
    }

    private func encodeJSON(_ object: [String: Any]) -> String {
        guard JSONSerialization.isValidJSONObject(object),
              let data = try? JSONSerialization.data(withJSONObject: object, options: [.sortedKeys]),
              let json = String(data: data, encoding: .utf8) else {
            return "{}"
        }
        return json
    }
}
