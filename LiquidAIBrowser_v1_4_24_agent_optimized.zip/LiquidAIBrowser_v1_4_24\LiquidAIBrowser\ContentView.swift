import SwiftUI
import UIKit

private let uiSpring = Animation.interpolatingSpring(mass: 0.85, stiffness: 260, damping: 30, initialVelocity: 0.18)

struct ContentView: View {
    @EnvironmentObject private var store: BrowserStore
    @State private var addressText: String = ""

    var body: some View {
        GeometryReader { proxy in
            let compact = proxy.size.width < 640
            ZStack(alignment: .bottom) {
                LiquidBackground()

                if store.showingSettingsPage {
                    SettingsPage()
                        .transition(.asymmetric(
                            insertion: .move(edge: .trailing).combined(with: .opacity),
                            removal: .move(edge: .leading).combined(with: .opacity)
                        ))
                } else if store.showingTaskOverviewPage {
                    TaskOverviewPage()
                        .transition(.asymmetric(
                            insertion: .move(edge: .trailing).combined(with: .opacity),
                            removal: .move(edge: .leading).combined(with: .opacity)
                        ))
                } else if compact {
                    CompactRootLayout(addressText: $addressText)
                } else {
                    RegularRootLayout(addressText: $addressText, width: proxy.size.width)
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .ignoresSafeArea(.container, edges: .all)
        .statusBar(hidden: true)
        .background(WindowSizingSupportView().allowsHitTesting(false))
        .onAppear { addressText = store.selectedTab?.urlString ?? "" }
        .onChange(of: store.selectedTabID) { _ in addressText = store.selectedTab?.urlString ?? "" }
        .animation(uiSpring, value: store.activePanel)
        .animation(uiSpring, value: store.selectedGroupID)
        .animation(uiSpring, value: store.selectedTabID)
        .animation(uiSpring, value: store.groups.count)
        .animation(uiSpring, value: store.tabs.count)
        .overlay(alignment: .top) {
            if let message = store.alertMessage {
                ToastBanner(message: message)
                    .padding(.top, 12)
                    .padding(.horizontal, 16)
                    .transition(.move(edge: .top).combined(with: .opacity))
                    .task(id: message) {
                        try? await Task.sleep(nanoseconds: 2_200_000_000)
                        await MainActor.run { if store.alertMessage == message { store.alertMessage = nil } }
                    }
            }
        }
        .sheet(item: Binding(get: { store.shareItem }, set: { store.shareItem = $0 })) { item in
            ActivityView(activityItems: [item.url])
        }
    }
}

struct TaskOverviewPage: View {
    @EnvironmentObject private var store: BrowserStore

    var body: some View {
        VStack(spacing: 10) {
            HStack(spacing: 10) {
                Button {
                    withAnimation(uiSpring) { store.showingTaskOverviewPage = false }
                } label: {
                    Label("返回浏览器", systemImage: "chevron.left")
                }
                .buttonStyle(.bordered)
                .controlSize(.small)

                VStack(alignment: .leading, spacing: 2) {
                    Text("全部任务")
                        .font(.title3.weight(.bold))
                    Text("这里是全局任务总览；分组顶部/工具栏的任务按钮只打开当前分组任务侧栏。")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                }
                Spacer()
                Button("清除已完成") { store.clearCompletedTasks(groupID: nil) }
                    .disabled(!store.tasks.contains { $0.status == .completed })
                    .buttonStyle(.bordered)
                    .controlSize(.small)
                Button("清除已结束") { store.clearTerminalTasks(groupID: nil) }
                    .disabled(!store.tasks.contains { $0.status.isTerminal })
                    .buttonStyle(.bordered)
                    .controlSize(.small)
                Button("清除失败") { store.clearFailedTasks(groupID: nil) }
                    .disabled(!store.tasks.contains { $0.status == .failed })
                    .buttonStyle(.bordered)
                    .controlSize(.small)
                Button("清除停止") { store.clearStoppedTasks(groupID: nil) }
                    .disabled(!store.tasks.contains { $0.status == .stopped })
                    .buttonStyle(.bordered)
                    .controlSize(.small)
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 10)
            .liquidGlassCard(cornerRadius: 22)

            TasksPanel(scope: .all)
                .padding(10)
                .liquidGlassCard(cornerRadius: 24)
        }
        .padding(10)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}

struct SettingsPage: View {
    @EnvironmentObject private var store: BrowserStore

    var body: some View {
        VStack(spacing: 10) {
            HStack(spacing: 10) {
                Button {
                    withAnimation(uiSpring) { store.showingSettingsPage = false }
                } label: {
                    Label("返回浏览器", systemImage: "chevron.left")
                }
                .buttonStyle(.bordered)
                .controlSize(.small)

                VStack(alignment: .leading, spacing: 2) {
                    Text("设置")
                        .font(.title3.weight(.bold))
                    Text("独立设置页面，不使用弹窗或侧栏。")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                Spacer()
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 10)
            .liquidGlassCard(cornerRadius: 22)

            SettingsPanel()
                .padding(12)
                .liquidGlassCard(cornerRadius: 24)
        }
        .padding(10)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}

struct ToastBanner: View {
    let message: String

    var body: some View {
        Text(message)
            .font(.caption.weight(.semibold))
            .foregroundStyle(.white)
            .multilineTextAlignment(.center)
            .lineLimit(3)
            .padding(.horizontal, 14)
            .padding(.vertical, 10)
            .background(.black.opacity(0.78), in: Capsule())
            .overlay(Capsule().stroke(.white.opacity(0.10), lineWidth: 1))
            .shadow(color: .black.opacity(0.25), radius: 12, x: 0, y: 6)
            .onTapGesture { }
    }
}

struct RegularRootLayout: View {
    @EnvironmentObject private var store: BrowserStore
    @Binding var addressText: String
    let width: CGFloat

    var body: some View {
        let railWidth = min(190, max(132, width * 0.14))
        let panelWidth = min(310, max(248, width * 0.25))
        let inlinePanel = width >= 1280

        ZStack(alignment: .trailing) {
            HStack(spacing: 8) {
                TabRailView()
                    .frame(width: railWidth)

                BrowserAreaView(addressText: $addressText)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)

                if inlinePanel && (store.activePanel == .newTask || store.activePanel == .tasks) {
                    SidePanelView()
                        .frame(width: panelWidth)
                        .transition(.move(edge: .trailing).combined(with: .opacity))
                }
            }

            if !inlinePanel && (store.activePanel == .newTask || store.activePanel == .tasks) {
                SidePanelView()
                    .frame(width: panelWidth)
                    .padding(.trailing, 8)
                    .transition(.move(edge: .trailing).combined(with: .opacity))
                    .shadow(color: .black.opacity(0.25), radius: 18, x: -8, y: 0)
            }
        }
        .padding(0)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}

struct CompactRootLayout: View {
    @EnvironmentObject private var store: BrowserStore
    @Binding var addressText: String

    var body: some View {
        ZStack(alignment: .bottom) {
            BrowserAreaView(addressText: $addressText)
                .padding(.horizontal, 0)
                .padding(.top, 0)
                .padding(.bottom, 54)

            CompactDockView()
                .padding(.horizontal, 8)
                .padding(.bottom, 6)

            if store.activePanel == .newTask || store.activePanel == .tasks {
                VStack {
                    Spacer(minLength: 50)
                    SidePanelView()
                        .frame(maxWidth: .infinity, maxHeight: 430)
                        .padding(.horizontal, 8)
                        .padding(.bottom, 62)
                        .transition(.move(edge: .bottom).combined(with: .opacity))
                }
            }
        }
    }
}

struct CompactDockView: View {
    @EnvironmentObject private var store: BrowserStore
    var body: some View {
        HStack(spacing: 8) {
            Button { store.createGroup(select: true) } label: { Image(systemName: "plus") }

            Menu {
                ForEach(store.groups) { group in
                    Button(group.displayName) { store.selectGroup(group.id) }
                }
                Divider()
                Button("清空所有分组", role: .destructive) { store.clearAllTabs() }
                    .disabled(store.groups.isEmpty)
            } label: {
                Label("分组", systemImage: "rectangle.3.group.fill")
            }

            Button { withAnimation(uiSpring) { store.activePanel = .newTask } } label: {
                Label("新任务", systemImage: "sparkles")
            }
            .disabled(store.selectedGroupID == nil)

            Button { withAnimation(uiSpring) { store.activePanel = .tasks } } label: {
                Image(systemName: "sidebar.right")
            }

            Button { store.showSettings() } label: { Image(systemName: "gearshape.fill") }
        }
        .buttonStyle(.bordered)
        .controlSize(.small)
        .padding(.horizontal, 10)
        .padding(.vertical, 8)
        .liquidGlassCard(cornerRadius: 22)
    }
}

struct TabRailView: View {
    @EnvironmentObject private var store: BrowserStore
    var body: some View {
        VStack(spacing: 10) {
            HStack(spacing: 8) {
                Image(systemName: "sparkles.rectangle.stack.fill")
                    .font(.headline)
                VStack(alignment: .leading, spacing: 1) {
                    Text("Liquid AI")
                        .font(.subheadline.weight(.bold))
                    Text("AI 网页代理")
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                }
                Spacer()
            }
            .padding(.horizontal, 10)
            .padding(.vertical, 9)
            .liquidGlassCard(cornerRadius: 20)

            HStack(spacing: 8) {
                Button { store.createGroup(select: true) } label: { Label("新建分组", systemImage: "plus") }
                    .frame(maxWidth: .infinity)
                Menu {
                    Button("清空所有分组", role: .destructive) { store.clearAllTabs() }
                        .disabled(store.groups.isEmpty)
                } label: { Image(systemName: "ellipsis.circle") }
            }
            .buttonStyle(.bordered)
            .controlSize(.small)

            ScrollView {
                LazyVStack(spacing: 8) {
                    if store.groups.isEmpty {
                        EmptyGroupsHint()
                    } else {
                        ForEach(store.groups) { group in
                            GroupSectionView(group: group)
                        }
                    }
                }
                .padding(.vertical, 2)
            }

            Spacer(minLength: 0)

            VStack(spacing: 7) {
                Button { store.showTaskOverview() } label: {
                    HStack(spacing: 8) {
                        Label("全部任务", systemImage: "checklist.checked")
                        Spacer()
                        let attention = store.attentionTasks.count
                        let count = store.tasks.filter { !$0.status.isTerminal }.count
                        if attention > 0 {
                            Image(systemName: "exclamationmark.triangle.fill")
                                .font(.caption2.weight(.bold))
                                .foregroundStyle(.yellow)
                                .accessibilityLabel("有任务需要处理")
                        }
                        if count > 0 {
                            Text("\(count)")
                                .font(.caption2.weight(.bold))
                                .padding(.horizontal, 7)
                                .padding(.vertical, 2)
                                .background(attention > 0 ? .yellow.opacity(0.22) : .white.opacity(0.16), in: Capsule())
                        }
                    }
                    .font(.caption.weight(.semibold))
                    .padding(.horizontal, 10)
                    .padding(.vertical, 8)
                    .background(.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                }
                .buttonStyle(.plain)
                Button { store.showSettings() } label: {
                    HStack {
                        Label("设置", systemImage: "gearshape.fill")
                        Spacer()
                    }
                    .padding(.horizontal, 10)
                    .padding(.vertical, 8)
                    .background(.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                }
                .buttonStyle(.plain)
            }
        }
        .padding(10)
        .liquidGlassCard(cornerRadius: 24)
    }
}

struct EmptyGroupsHint: View {
    var body: some View {
        VStack(spacing: 8) {
            Image(systemName: "rectangle.stack.badge.plus")
                .font(.title3)
            Text("没有分组")
                .font(.caption.weight(.semibold))
            Text("点击新建分组开始")
                .font(.caption2)
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 28)
        .background(.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
    }
}

struct PanelButton: View {
    @EnvironmentObject private var store: BrowserStore
    let title: String
    let icon: String
    let panel: AppPanel

    var body: some View {
        Button {
            withAnimation(uiSpring) {
                store.activePanel = store.activePanel == panel ? .none : panel
            }
        } label: {
            HStack(spacing: 8) {
                Label(title, systemImage: icon)
                Spacer()
                if badgeCount > 0 {
                    Text("\(badgeCount)")
                        .font(.caption2.weight(.bold))
                        .padding(.horizontal, 7)
                        .padding(.vertical, 2)
                        .background(.white.opacity(0.16), in: Capsule())
                }
            }
            .font(.caption.weight(.semibold))
            .padding(.horizontal, 10)
            .padding(.vertical, 8)
            .background(store.activePanel == panel ? .white.opacity(0.14) : .white.opacity(0.055), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
        }
        .buttonStyle(.plain)
    }

    var badgeCount: Int {
        guard panel == .tasks else { return 0 }
        return store.tasks.filter { !$0.status.isTerminal }.count
    }
}


struct GroupSectionView: View {
    @EnvironmentObject private var store: BrowserStore
    let group: BrowserGroup

    private var groupTabs: [BrowserTab] {
        store.tabs.filter { $0.groupID == group.id }.sorted { $0.createdAt < $1.createdAt }
    }

    private var activeTasks: [AgentTask] {
        store.tasks.filter { $0.groupID == group.id && !$0.status.isTerminal }
    }

    private var attentionTasks: [AgentTask] {
        store.attentionTasks(for: group.id)
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 7) {
            Button { store.selectGroup(group.id) } label: {
                HStack(spacing: 8) {
                    Image(systemName: store.selectedGroupID == group.id ? "folder.fill.badge.gearshape" : "folder")
                        .symbolRenderingMode(.hierarchical)
                    VStack(alignment: .leading, spacing: 2) {
                        Text(group.displayName)
                            .font(.caption.weight(.bold))
                            .lineLimit(1)
                        Text("\(groupTabs.count) 个页面 · \(activeTasks.count) 个运行/排队任务")
                            .font(.caption2)
                            .foregroundStyle(.secondary)
                    }
                    Spacer()
                    if !attentionTasks.isEmpty {
                        Image(systemName: "exclamationmark.triangle.fill")
                            .font(.caption.weight(.bold))
                            .foregroundStyle(.yellow)
                            .accessibilityLabel("此分组有任务需要处理")
                    }
                    Menu {
                        Button("新建页面") { store.createTab(groupID: group.id, select: true) }
                        Button("给分组设任务") {
                            store.selectGroup(group.id)
                            withAnimation(uiSpring) { store.activePanel = .newTask }
                        }
                        Button("关闭分组", role: .destructive) { store.closeGroup(group.id) }
                    } label: {
                        Image(systemName: "ellipsis.circle")
                    }
                    .buttonStyle(.plain)
                }
                .padding(8)
                .background(store.selectedGroupID == group.id ? .white.opacity(0.15) : .white.opacity(0.055), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                .overlay {
                    RoundedRectangle(cornerRadius: 12, style: .continuous)
                        .stroke(store.selectedGroupID == group.id ? .white.opacity(0.18) : .white.opacity(0.06), lineWidth: 1)
                }
            }
            .buttonStyle(.plain)

            if store.selectedGroupID == group.id {
                VStack(spacing: 6) {
                    if groupTabs.isEmpty {
                        Button { store.createTab(groupID: group.id, select: true) } label: {
                            Label("添加页面", systemImage: "plus")
                                .font(.caption)
                                .frame(maxWidth: .infinity)
                        }
                        .buttonStyle(.bordered)
                        .controlSize(.small)
                    } else {
                        ForEach(groupTabs) { tab in
                            TabCardView(tab: tab)
                                .transition(.asymmetric(insertion: .move(edge: .top).combined(with: .opacity), removal: .scale(scale: 0.96).combined(with: .opacity)))
                        }
                    }
                }
                .padding(.leading, 6)
                .animation(uiSpring, value: groupTabs.count)
            }
        }
        .animation(uiSpring, value: store.selectedGroupID)
    }
}

struct TabCardView: View {
    @EnvironmentObject private var store: BrowserStore
    let tab: BrowserTab

    private var attentionTask: AgentTask? {
        store.attentionTask(for: tab.id)
    }

    var body: some View {
        Button { store.selectTab(tab.id) } label: {
            HStack(spacing: 8) {
                ThumbnailView(image: tab.thumbnailImage, title: tab.displayTitle)
                    .frame(width: 48, height: 36)
                    .overlay(alignment: .topLeading) {
                        if attentionTask != nil {
                            Image(systemName: "exclamationmark.triangle.fill")
                                .font(.caption2.weight(.heavy))
                                .foregroundStyle(.yellow)
                                .padding(3)
                                .background(.black.opacity(0.55), in: Circle())
                                .offset(x: -5, y: -5)
                        }
                    }
                VStack(alignment: .leading, spacing: 3) {
                    HStack(spacing: 4) {
                        Text(tab.displayTitle)
                            .font(.caption.weight(.semibold))
                            .lineLimit(1)
                        if tab.isLoading { ProgressView().scaleEffect(0.55) }
                    }
                    Text(URL(string: tab.urlString)?.host ?? tab.urlString)
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                    if let task = store.tasks.first(where: { $0.workingTabIDs.contains(tab.id) && !$0.status.isTerminal }) {
                        HStack(spacing: 5) {
                            Image(systemName: task.status.symbolName).font(.caption2)
                            Text("\(Int(task.progress * 100))%")
                                .font(.caption2.monospacedDigit())
                            ProgressView(value: task.progress)
                                .frame(maxWidth: 44)
                        }
                        .foregroundStyle(task.needsUserAttention ? .yellow : .mint)
                    }
                }
                Button(role: .destructive) { store.closeTab(tab.id) } label: { Image(systemName: "xmark") }
                    .buttonStyle(.plain)
                    .font(.caption2)
                    .opacity(0.75)
            }
            .padding(8)
            .background(store.selectedTabID == tab.id ? .white.opacity(0.09) : .white.opacity(0.032), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
            .overlay {
                RoundedRectangle(cornerRadius: 12, style: .continuous)
                    .stroke(store.selectedTabID == tab.id ? .white.opacity(0.20) : .white.opacity(0.06), lineWidth: 1)
            }
        }
        .buttonStyle(.plain)
    }
}

struct BrowserAreaView: View {
    @EnvironmentObject private var store: BrowserStore
    @Binding var addressText: String
    // v1.4.24: 顶部网页导航栏默认保持展开，避免用户/AI 输入时被自动收起导致焦点丢失。
    // 只有用户点击工具栏内的收起按钮才会隐藏；隐藏后移动到顶部热区会自动拉出。
    @State private var topControlsVisible = true

    var body: some View {
        ZStack(alignment: .top) {
            browserSurface
                .frame(maxWidth: .infinity, maxHeight: .infinity)

            topRevealHotZone
                .zIndex(1)

            if topControlsVisible {
                BrowserToolbarView(addressText: $addressText) {
                    collapseTopControls()
                }
                .padding(.horizontal, 8)
                .padding(.top, 6)
                .transition(.asymmetric(
                    insertion: .move(edge: .top).combined(with: .opacity),
                    removal: .move(edge: .top).combined(with: .opacity)
                ))
                .zIndex(3)
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .onAppear {
            revealTopControls()
        }
        .onChange(of: store.selectedTabID) { _ in
            revealTopControls()
        }
    }

    private var browserSurface: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .fill(Color.black.opacity(0.10))
            if let tab = store.selectedTab {
                BrowserWebView(tabID: tab.id)
                    .id(tab.id)
                    .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                    .padding(2)
            } else {
                EmptyBrowserView(addressText: $addressText)
            }
        }
        .overlay {
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .stroke(.white.opacity(0.08), lineWidth: 1)
        }
    }

    private var topRevealHotZone: some View {
        VStack(spacing: 0) {
            Color.clear
                .contentShape(Rectangle())
                .frame(height: topControlsVisible ? 8 : 34)
                .onHover { hovering in
                    if hovering && !topControlsVisible {
                        revealTopControls()
                    }
                }
                .onTapGesture {
                    if !topControlsVisible {
                        revealTopControls()
                    }
                }

            if !topControlsVisible {
                HStack(spacing: 6) {
                    Image(systemName: "chevron.down")
                        .font(.caption2.weight(.bold))
                    Text("导航栏")
                        .font(.caption2.weight(.semibold))
                }
                .foregroundStyle(.white.opacity(0.82))
                .padding(.horizontal, 10)
                .padding(.vertical, 4)
                .background(.black.opacity(0.34), in: Capsule())
                .overlay {
                    Capsule().stroke(.white.opacity(0.18), lineWidth: 1)
                }
                .padding(.top, 4)
                .transition(.opacity)
                .allowsHitTesting(false)
            }

            Spacer(minLength: 0)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
    }

    private func revealTopControls() {
        withAnimation(uiSpring) {
            topControlsVisible = true
        }
    }

    private func collapseTopControls() {
        withAnimation(uiSpring) {
            topControlsVisible = false
        }
    }
}

struct EmptyBrowserView: View {
    @EnvironmentObject private var store: BrowserStore
    @Binding var addressText: String

    var body: some View {
        VStack(spacing: 16) {
            Image(systemName: "safari")
                .font(.system(size: 42, weight: .semibold))
                .foregroundStyle(.white.opacity(0.72))
            Text("没有打开的页面")
                .font(.title3.weight(.bold))
            Text("当前是空网页。可以在地址栏输入链接，也可以创建任务；AI 会先扫描当前页面，再决定是否新建/切换页面。")
                .font(.footnote)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
            Button { store.createTab(select: true) } label: {
                Label("新建页面", systemImage: "plus")
            }
            .buttonStyle(.borderedProminent)
            .controlSize(.regular)
        }
        .padding(24)
        .frame(maxWidth: 420)
    }
}

struct BrowserToolbarView: View {
    @EnvironmentObject private var store: BrowserStore
    @Binding var addressText: String
    var onCollapse: () -> Void = {}
    @FocusState private var addressFocused: Bool

    var body: some View {
        HStack(spacing: 7) {
            Button { store.goBack() } label: { Image(systemName: "chevron.left") }
                .disabled(store.selectedTabID == nil)
            Button { store.goForward() } label: { Image(systemName: "chevron.right") }
                .disabled(store.selectedTabID == nil)
            Button { store.selectedTab?.isLoading == true ? store.stopLoading() : store.reload() } label: {
                Image(systemName: store.selectedTab?.isLoading == true ? "xmark" : "arrow.clockwise")
            }
            .disabled(store.selectedTabID == nil)

            TextField("搜索或输入网址", text: $addressText)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .keyboardType(.URL)
                .submitLabel(.go)
                .focused($addressFocused)
                .onSubmit {
                    addressFocused = false
                    store.loadSelectedAddress(addressText)
                }
                .font(.callout)
                .padding(.horizontal, 11)
                .padding(.vertical, 7)
                .background(.white.opacity(0.055), in: Capsule())

            Button { withAnimation(uiSpring) { store.activePanel = .newTask } } label: {
                Label("任务", systemImage: "sparkles")
                    .labelStyle(.titleAndIcon)
            }
            .disabled(store.selectedGroupID == nil)

            Button { withAnimation(uiSpring) { store.activePanel = .tasks } } label: {
                Image(systemName: "sidebar.right")
            }

            Button { store.showSettings() } label: {
                Image(systemName: "gearshape.fill")
            }

            Button(action: onCollapse) {
                Label("收起导航栏", systemImage: "chevron.up")
                    .labelStyle(.iconOnly)
            }
        }
        .buttonStyle(.bordered)
        .controlSize(.small)
        .padding(.horizontal, 8)
        .padding(.vertical, 7)
        .liquidGlassCard(cornerRadius: 20)
        .onChange(of: store.selectedTab?.urlString ?? "") { newValue in
            if !addressFocused { addressText = newValue }
        }
        .onChange(of: store.selectedTabID) { _ in
            if !addressFocused { addressText = store.selectedTab?.urlString ?? "" }
        }
        .onReceive(store.$tabs) { _ in
            let current = store.selectedTab?.urlString ?? ""
            if !addressFocused && !current.isEmpty && addressText != current { addressText = current }
        }
    }
}

struct SidePanelView: View {
    @EnvironmentObject private var store: BrowserStore

    var body: some View {
        VStack(spacing: 10) {
            HStack {
                Text(title)
                    .font(.headline.weight(.bold))
                Spacer()
                Button { withAnimation(uiSpring) { store.activePanel = .none } } label: { Image(systemName: "xmark") }
                    .buttonStyle(.bordered)
                    .controlSize(.small)
            }
            .padding(.horizontal, 2)

            switch store.activePanel {
            case .newTask:
                NewTaskPanel()
            case .tasks:
                TasksPanel(scope: .currentGroup)
            case .settings, .none:
                EmptyView()
            }
        }
        .padding(10)
        .liquidGlassCard(cornerRadius: 24)
    }

    var title: String {
        switch store.activePanel {
        case .newTask: return "新建任务"
        case .tasks: return "当前分组任务"
        case .settings: return "设置"
        case .none: return ""
        }
    }
}
