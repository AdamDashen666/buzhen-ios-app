# LiquidAIBrowser v1.4.8 Teams / Cookie / Task Cleanup Report

## Fix scope

This patch is based on v1.4.7 and adds the requested fixes:

- Repair Microsoft Teams / Microsoft login compatibility as much as possible within iOS WKWebView.
- Remove website pop-up interruptions from JavaScript alert / confirm / prompt.
- Default to agreeing to common Cookie / privacy consent prompts.
- Add single task deletion.
- Add one-click clear completed tasks.
- Add one-click clear all terminal tasks.
- Make completed and stopped tasks collapsed by default; active tasks remain expanded by default.

## Browser compatibility changes

### Microsoft / Teams domains

`WebViewPool.swift` now detects Microsoft-like hosts:

- `teams.microsoft.com`
- `login.microsoftonline.com`
- `office.com`
- `live.com`
- `sharepoint.com`

For these domains, the WebView applies a desktop Edge-like user agent:

```text
Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36 Edg/124.0.0.0
```

This is intended to reduce “unsupported browser” pages. It cannot fully turn WKWebView into Chromium/Edge; Microsoft can still block WKWebView by feature detection.

### Teams URL normalization

`BrowserStore.normalizedURLString(_:)` now routes generic Teams requests to:

```text
https://teams.microsoft.com/v2/
```

## No popup / default consent behavior

### JavaScript dialogs

`WKUIDelegate` handlers now avoid user-facing dialogs:

- `alert`: completes silently.
- `confirm`: returns `true` by default.
- `prompt`: returns `defaultText` or empty string.

### Cookie consent auto-click

A new injected script, `autoConsentScript`, scans visible buttons/links and clicks likely positive consent buttons such as:

- 同意 / 接受 / 允许 / 确定 / 继续
- Accept / Agree / Allow / OK / Continue / Got it / Accept all

Negative choices such as 拒绝 / Reject / Decline / Cancel are avoided.

## Task cleanup changes

### BrowserStore.swift

New functions:

- `clearTask(_:)`
- `clearCompletedTasks()`
- `clearTerminalTasks()`

`clearTask(_:)` cancels active task workers before removing the task.

### Panels.swift

Task management panel now includes:

- 清除已完成
- 清除已结束
- Per-task 清除

Display behavior:

- Running/planning/queued/waiting tasks are expanded by default.
- Completed/stopped tasks are collapsed by default and show only summary until manually expanded.
- Task list is sorted so active tasks are shown first.

## Static checks performed

- Swift parse check: OK for all `.swift` files.
- Agent bridge JavaScript syntax check: OK.
- Cookie consent JavaScript syntax check: OK.
- Info.plist lint: OK.
- Version updated to 1.4.8 / build 15.

## Known limitation

Teams compatibility is best-effort. iOS third-party browsers and in-app browsers are still backed by WebKit/WKWebView. A site can still reject the browser if it requires Chromium-only capabilities or explicitly blocks WKWebView-like environments.
