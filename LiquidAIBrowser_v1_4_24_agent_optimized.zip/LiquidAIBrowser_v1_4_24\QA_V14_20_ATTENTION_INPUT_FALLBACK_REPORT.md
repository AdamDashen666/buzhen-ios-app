# QA v1.4.20 - Attention Notification and Keyboard Input Fallback Report

## Version

- App version: `1.4.20`
- Build: `27`
- Source root: `LiquidAIBrowser_v1_4_20/`

## User requirements

1. If an AI task is paused by the agent or needs user input, the user must be notified inside and outside the app.
2. Inside the app, the left tab/group rail must show a clear warning indicator.
3. Microsoft password/login inputs and other framework-controlled inputs must use keyboard-like input fallback when normal `setText` does not work.

## Changes

### 1. Task attention model

Added task-level attention detection:

- `AgentTask.needsUserAttention`
- `AgentTask.attentionTitle`
- `AgentTask.attentionMessage`

The task is treated as needing attention when it is waiting for user input/confirmation, or when the AI pauses because of login, captcha, permission, manual handling, or blocked state.

### 2. In-app notification UI

Added visible warning indicators:

- Left group card shows a yellow warning icon when any task in the group needs attention.
- Left tab card shows a yellow warning icon on the page thumbnail when a task using that tab needs attention.
- The global task button shows a warning marker when attention is needed.
- Task card shows an inline yellow attention panel with “我已处理，继续” and “停止”.
- Toast message appears immediately when AI pauses or asks the user for input.

### 3. Out-of-app notification

Added `BrowserStore.notifyTaskNeedsAttention(...)` as the unified notification path.

It calls the existing local notification system through `NotificationService.shared.notify(...)`, so a system notification is sent when:

- AI asks for user input.
- AI marks the task as blocked/paused and needs manual handling.

### 4. Password/login input fallback

Improved WebView automation input handling:

- `setText` on editable fields now falls back to keyboard-like input instead of only changing `textContent`.
- `input` action no longer depends on locating the element by the text value being entered.
- Added `findTextEntryElement(...)` to prioritize:
  - explicit selector,
  - coordinate hit target,
  - currently focused editable field,
  - password field,
  - email/username field,
  - first visible text entry field.
- Added `smartFillTextField(...)` to simulate a more user-like input path:
  - focus/click field,
  - select/clear existing content,
  - native value setter,
  - `beforeinput`, `input`, `change`, `compositionend`,
  - per-character keyboard fallback,
  - contenteditable fallback.

### 5. Sensitive answer logging

User-provided answers that look like passwords, passcodes, verification codes, or tokens are redacted in logs as:

`[已隐藏敏感输入]`

## Expected behavior

- When Microsoft login asks for password and `setText` fails, the AI can retry with `input` or `typeText`, and editable input fields will use the keyboard-like path.
- If AI cannot continue because it needs the user, the left rail immediately shows a warning icon and the system sends a local notification.
- The user can process the issue and tap “我已处理，继续”.

## Notes

The app cannot bypass iOS/WebKit system privacy prompts. For system-level cookie-sharing prompts, the app can pause and notify the user, but it cannot secretly press the system prompt on the user’s behalf.
