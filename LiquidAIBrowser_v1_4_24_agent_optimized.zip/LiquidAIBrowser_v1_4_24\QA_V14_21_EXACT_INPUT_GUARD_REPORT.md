# QA v1.4.23 - Exact Input Guard Report

## Version

- App version: `1.4.23`
- Build: `28`
- Source root: `LiquidAIBrowser_v1_4_23/`

## User issue

When the AI was asked to send one message, for example `的吃哇`, some rich text editors / Teams-style composers could end up with `的吃哇的吃哇` because the previous input attempt was retried or appended instead of being replaced.

Important clarification: the fix must not globally forbid sending the same message multiple times. The app should allow repeated sends when the task requires them, but each individual input/send action must verify that the input box contains only the expected content and not extra duplicated text.

## Fixes

### 1. Removed short-time duplicate-send blocking

Removed the 15-second same-message blocking behavior from the send-message bridge path. Repeated sends are not blocked at the browser bridge level.

### 2. Added exact input reconciliation before sending

Before a chat message is sent, the bridge now:

1. Finds the composer.
2. Focuses it.
3. Clears stale draft text when needed.
4. Inserts the target message.
5. Counts visible occurrences of the target text.
6. Repairs the composer to exact target text if the text was appended or duplicated.
7. Sends only if the composer can be verified as matching the expected content.

### 3. Prevented double Enter in Teams fallback

The Teams `pressEnter` fallback now triggers Enter once instead of twice. This prevents a single user-intended send from being doubled by the fallback path.

### 4. Refined AI instruction prompt

Updated the planning prompt so the AI understands:

- Do not solve repeated text by forbidding repeated sends.
- The real rule is: one send action must prepare the input box exactly once.
- If the user requests multiple sends, execute them as separate verified steps.
- If repeated text inside the same input field is intentionally required, the action must explicitly mark it with `allowRepeatedInput=true` and `expectedCount`.

## Files changed

- `LiquidAIBrowser/WebViewPool.swift`
- `LiquidAIBrowser/AgentEngine.swift`
- `LiquidAIBrowser/Info.plist`
- `LiquidAIBrowser.xcodeproj/project.pbxproj`
- `CHANGELOG.md`
- `PROJECT_INDEX.md`
- `README.md`
- `QA_V14_21_EXACT_INPUT_GUARD_REPORT.md`

## Validation

Static checks performed:

- Confirmed `MARKETING_VERSION = 1.4.23`.
- Confirmed `CURRENT_PROJECT_VERSION = 30`.
- Confirmed bridge script version is `1.4.23`.
- Confirmed old `duplicate_send_blocked` logic was removed.
- Confirmed Teams double Enter fallback was removed.
- Confirmed zip integrity passes `unzip -t`.

## Remaining risk

Some secure Microsoft login controls and Teams rich text editors may still reject script-driven input at the framework level. In that case, the app now refuses to falsely send and reports that the composer could not be reliably verified, instead of sending duplicated or unintended content.
