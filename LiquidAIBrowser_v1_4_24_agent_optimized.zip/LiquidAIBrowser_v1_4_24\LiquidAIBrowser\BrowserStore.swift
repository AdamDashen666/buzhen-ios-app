import Foundation
import SwiftUI
import UIKit
import Combine
import UserNotifications

final class BrowserStore: ObservableObject {
    @Published var groups: [BrowserGroup] = []
    @Published var selectedGroupID: UUID?
    @Published var tabs: [BrowserTab] = []
    @Published var selectedTabID: UUID?
    @Published var tasks: [AgentTask] = []
    @Published var activePanel: AppPanel = .none
    @Published var newTaskPrompt: String = ""
    @Published var alertMessage: String?
    @Published var shareItem: ShareItem?
    @Published var selectedLogLevels: Set<TaskLogLevel> = Set(TaskLogLevel.allCases)
    @Published var showingSettingsPage: Bool = false
    @Published var showingTaskOverviewPage: Bool = false
    @Published var timers: [AgentTimerEntry] = []

    let settings = AISettings()
    let webPool = WebViewPool()
    lazy var engine: AgentEngine = AgentEngine(store: self, webPool: webPool)
    private var cancellables = Set<AnyCancellable>()
    private var timerWorkers: [UUID: Task<Void, Never>] = [:]
    private var persistWorkItem: DispatchWorkItem?
    private var lastPersistRequestAt: Date = .distantPast

    private struct StoredSession: Codable {
        var groups: [BrowserGroup]?
        var selectedGroupID: UUID?
        var tabs: [BrowserTab]
        var selectedTabID: UUID?
        var tasks: [AgentTask]
        var timers: [AgentTimerEntry]?
    }

    init() {
        webPool.store = self
        settings.objectWillChange
            .sink { [weak self] _ in self?.objectWillChange.send() }
            .store(in: &cancellables)

        if settings.persistSessionHistory, restoreSession() {
            for tab in tabs {
                _ = webPool.webView(for: tab.id, initialURL: tab.urlString)
            }
            normalizeSelection()
        } else {
            groups = []
            tabs = []
            tasks = []
            timers = []
            selectedGroupID = nil
            selectedTabID = nil
        }
        cleanupOrphanedSnapshots()
    }

    func cleanupOrphanedSnapshots() {
        SnapshotFileStore.removeOrphanedSnapshots(validTaskIDs: Set(tasks.map(\.id)))
    }

    private func removeArtifacts(for task: AgentTask) {
        SnapshotFileStore.removeTaskSnapshots(taskID: task.id)
        guard let url = URL(string: task.pdfReportURLString), url.isFileURL else { return }
        guard url.lastPathComponent.hasPrefix("LiquidAIBrowser_Report_") else { return }
        try? FileManager.default.removeItem(at: url)
    }

    private func removeTimers(groupID: UUID, taskIDs: Set<UUID>) {
        let removedTimers = timers.filter { timer in
            timer.groupID == groupID || timer.taskID.map { taskIDs.contains($0) } == true
        }
        removedTimers.forEach { timer in
            timerWorkers[timer.id]?.cancel()
            timerWorkers[timer.id] = nil
            UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: [timer.id.uuidString])
        }
        timers.removeAll { timer in
            timer.groupID == groupID || timer.taskID.map { taskIDs.contains($0) } == true
        }
    }

    private func destroyGroupRuntimeAndArtifacts(groupID: UUID) {
        let groupTasks = tasks.filter { $0.groupID == groupID }
        let taskIDs = Set(groupTasks.map(\.id))
        groupTasks.forEach { task in
            if !task.status.isTerminal { engine.cancel(taskID: task.id) }
            removeArtifacts(for: task)
        }
        removeTimers(groupID: groupID, taskIDs: taskIDs)
        tabs.filter { $0.groupID == groupID }.map(\.id).forEach { webPool.destroy(tabID: $0) }
        tasks.removeAll { $0.groupID == groupID }
        tabs.removeAll { $0.groupID == groupID }
        webPool.resetGroupStorage(groupID: groupID)
    }

    var selectedGroup: BrowserGroup? {
        guard let selectedGroupID else { return nil }
        return groups.first(where: { $0.id == selectedGroupID })
    }

    var selectedTab: BrowserTab? {
        guard let selectedTabID else { return nil }
        return tabs.first(where: { $0.id == selectedTabID })
    }

    var selectedGroupTabs: [BrowserTab] {
        guard let groupID = selectedGroupID else { return [] }
        return tabs.filter { $0.groupID == groupID }.sorted { $0.createdAt < $1.createdAt }
    }

    var selectedGroupTasks: [AgentTask] {
        guard let groupID = selectedGroupID else { return [] }
        return tasks.filter { $0.groupID == groupID }
    }

    var attentionTasks: [AgentTask] {
        tasks.filter { $0.needsUserAttention }
    }

    func attentionTasks(for groupID: UUID) -> [AgentTask] {
        tasks.filter { $0.groupID == groupID && $0.needsUserAttention }
    }

    func attentionTask(for tabID: UUID) -> AgentTask? {
        tasks.first { $0.workingTabIDs.contains(tabID) && $0.needsUserAttention }
    }

    @discardableResult
    func createGroup(name: String? = nil, select: Bool = true) -> UUID {
        let index = groups.count + 1
        let group = BrowserGroup(name: name ?? "分组 \(index)")
        groups.append(group)
        webPool.prepareGroupStorage(groupID: group.id)
        if select {
            selectedGroupID = group.id
            selectedTabID = nil
        }
        persistSession()
        return group.id
    }

    func renameGroup(_ id: UUID, name: String) {
        guard let index = groups.firstIndex(where: { $0.id == id }) else { return }
        groups[index].name = name
        groups[index].updatedAt = Date()
        persistSession()
    }

    func selectGroup(_ id: UUID) {
        guard groups.contains(where: { $0.id == id }) else { return }
        selectedGroupID = id
        let groupTabs = tabs.filter { $0.groupID == id }.sorted { $0.updatedAt > $1.updatedAt }
        if let selectedTabID, tabs.contains(where: { $0.id == selectedTabID && $0.groupID == id }) {
            webPool.refreshProgress(tabID: selectedTabID)
            webPool.captureThumbnail(tabID: selectedTabID)
        } else {
            selectedTabID = groupTabs.first?.id
            if let selectedTabID {
                webPool.refreshProgress(tabID: selectedTabID)
                webPool.captureThumbnail(tabID: selectedTabID)
            }
        }
        persistSession()
    }

    func closeGroup(_ id: UUID) {
        guard groups.contains(where: { $0.id == id }) else { return }
        destroyGroupRuntimeAndArtifacts(groupID: id)
        groups.removeAll { $0.id == id }
        if selectedGroupID == id { selectedGroupID = groups.first?.id }
        selectedTabID = selectedGroupID.flatMap { gid in tabs.first(where: { $0.groupID == gid })?.id }
        if groups.isEmpty { selectedGroupID = nil; selectedTabID = nil }
        persistSession()
    }

    @discardableResult
    func createTab(urlString: String = "about:blank", groupID: UUID? = nil, select: Bool = true) -> UUID {
        let targetGroupID: UUID
        if let groupID, groups.contains(where: { $0.id == groupID }) {
            targetGroupID = groupID
        } else if let selectedGroupID {
            targetGroupID = selectedGroupID
        } else {
            targetGroupID = createGroup(select: true)
        }
        let tab = BrowserTab(groupID: targetGroupID, urlString: normalizedURLString(urlString))
        tabs.append(tab)
        if select {
            selectedGroupID = targetGroupID
            selectedTabID = tab.id
        }
        if let index = groups.firstIndex(where: { $0.id == targetGroupID }) { groups[index].updatedAt = Date() }
        _ = webPool.webView(for: tab.id, initialURL: tab.urlString)
        persistSession()
        return tab.id
    }

    func closeTab(_ id: UUID) {
        let affectedTaskIDs = tasks.filter { !$0.status.isTerminal && $0.workingTabIDs.contains(id) }.map(\.id)
        affectedTaskIDs.forEach { taskID in
            engine.cancel(taskID: taskID)
            updateTask(taskID, persist: false) { task in
                task.status = .stopped
                task.finishedAt = Date()
                task.pendingAction = nil
                task.pendingActionRisk = ""
                task.currentAction = "任务使用的页面已关闭"
            }
            appendLog(taskID: taskID, "任务使用的页面已关闭，任务已停止。", level: .warning, persist: false)
        }
        webPool.destroy(tabID: id)
        let closedGroupID = tabs.first(where: { $0.id == id })?.groupID
        tabs.removeAll { $0.id == id }
        if selectedTabID == id {
            selectedTabID = closedGroupID.flatMap { gid in tabs.first(where: { $0.groupID == gid })?.id }
        }
        persistSession()
    }

    func clearAllTabs() {
        clearAllGroups()
    }

    func clearAllGroups() {
        tasks.forEach { task in
            if !task.status.isTerminal { engine.cancel(taskID: task.id) }
            removeArtifacts(for: task)
        }
        timers.forEach { timer in
            timerWorkers[timer.id]?.cancel()
            timerWorkers[timer.id] = nil
        }
        UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: timers.map { $0.id.uuidString })
        tabs.map(\.id).forEach { webPool.destroy(tabID: $0) }
        webPool.resetAllStorageContexts()
        tasks.removeAll()
        timers.removeAll()
        tabs.removeAll()
        groups.removeAll()
        selectedGroupID = nil
        selectedTabID = nil
        activePanel = .none
        cleanupOrphanedSnapshots()
        persistSession()
    }

    func showSettings() {
        activePanel = .none
        showingTaskOverviewPage = false
        showingSettingsPage = true
    }

    func showTaskOverview() {
        activePanel = .none
        showingSettingsPage = false
        showingTaskOverviewPage = true
    }

    func selectTab(_ id: UUID) {
        guard let tab = tabs.first(where: { $0.id == id }) else { return }
        selectedGroupID = tab.groupID
        selectedTabID = id
        webPool.refreshProgress(tabID: id)
        webPool.captureThumbnail(tabID: id)
        persistSession()
    }

    @MainActor
    func loadSelectedAddress(_ text: String) {
        let normalized = normalizedURLString(text)
        guard let id = selectedTabID else {
            createTab(urlString: normalized, select: true)
            return
        }
        loadURLInTab(tabID: id, urlString: normalized)
    }

    @MainActor
    func loadURLInTab(tabID: UUID, urlString: String) {
        let normalized = normalizedURLString(urlString)
        guard tabs.contains(where: { $0.id == tabID }) else { return }
        updateTab(tabID) { tab in
            tab.urlString = normalized
            tab.isLoading = true
            tab.updatedAt = Date()
        }
        webPool.load(tabID: tabID, urlString: normalized)
        persistSession()
    }

    func goBack() { guard let id = selectedTabID else { return }; webPool.goBack(tabID: id) }
    func goForward() { guard let id = selectedTabID else { return }; webPool.goForward(tabID: id) }
    func reload() { guard let id = selectedTabID else { return }; webPool.reload(tabID: id) }
    func stopLoading() { guard let id = selectedTabID else { return }; webPool.stopLoading(tabID: id) }

    func updateTab(_ id: UUID, mutate: (inout BrowserTab) -> Void) {
        guard let index = tabs.firstIndex(where: { $0.id == id }) else { return }
        objectWillChange.send()
        mutate(&tabs[index])
        tabs[index].updatedAt = Date()
        if let groupIndex = groups.firstIndex(where: { $0.id == tabs[index].groupID }) { groups[groupIndex].updatedAt = Date() }
        persistSession()
    }

    func updateThumbnail(tabID: UUID, image: UIImage?) {
        guard let image, let data = image.jpegData(compressionQuality: 0.72) else { return }
        updateTab(tabID) { tab in
            tab.thumbnailData = data
            tab.updatedAt = Date()
        }
    }

    func appendStepSnapshot(taskID: UUID, tabID: UUID, imageData: Data, stepIndex: Int?, actionType: String?, title: String, note: String, persist: Bool = true) {
        guard let index = tasks.firstIndex(where: { $0.id == taskID }) else { return }
        let baseDate = tasks[index].startedAt ?? tasks[index].createdAt
        let elapsed = Date().timeIntervalSince(baseDate)
        let tab = tabs.first(where: { $0.id == tabID })
        let fileInfo = SnapshotFileStore.write(data: imageData, taskID: taskID, index: tasks[index].stepSnapshots.count + 1)
        let shot = TaskStepSnapshot(
            elapsedSeconds: elapsed,
            stepIndex: stepIndex,
            actionType: actionType,
            title: title,
            note: note,
            tabID: tabID,
            urlString: tab?.urlString ?? "",
            imageFileName: fileInfo.fileName,
            width: fileInfo.width,
            height: fileInfo.height,
            fileSize: fileInfo.fileSize,
            imageData: nil
        )
        tasks[index].lastScreenshotData = nil
        tasks[index].lastScreenshotAt = Date()
        tasks[index].stepSnapshots.append(shot)
        tasks[index].updatedAt = Date()
        if persist { persistSession() }
    }

    func createTask(goal: String, groupID: UUID? = nil, tabID: UUID? = nil) {
        let cleanGoal = goal.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleanGoal.isEmpty else { return }
        guard !settings.apiKey.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            alertMessage = "请先在设置里填写 API Key。"
            showSettings()
            return
        }
        let targetGroupID = groupID ?? selectedGroupID ?? createGroup(select: true)
        let targetTabID: UUID
        if let tabID, tabs.contains(where: { $0.id == tabID && $0.groupID == targetGroupID }) {
            targetTabID = tabID
        } else if let selectedTabID, tabs.contains(where: { $0.id == selectedTabID && $0.groupID == targetGroupID }) {
            targetTabID = selectedTabID
        } else if let first = tabs.first(where: { $0.groupID == targetGroupID })?.id {
            targetTabID = first
        } else {
            targetTabID = createTab(urlString: "about:blank", groupID: targetGroupID, select: true)
        }
        let hasActive = tasks.contains { $0.groupID == targetGroupID && !$0.status.isTerminal && $0.status != .queued }
        let queuedBefore = tasks.filter { $0.groupID == targetGroupID && $0.status == .queued }.count
        var task = AgentTask(groupID: targetGroupID, tabID: targetTabID, goal: cleanGoal, maxIterations: settings.maxIterations, queueIndex: queuedBefore + 1)
        if hasActive {
            task.status = .queued
            task.currentAction = "等待该分组的前一个任务完成"
            task.log.append(TaskLogEntry(level: .info, message: "同一分组已有任务，新任务已加入队列。"))
            tasks.insert(task, at: 0)
            alertMessage = "已加入该分组任务队列。"
        } else {
            tasks.insert(task, at: 0)
            engine.start(taskID: task.id)
        }
        newTaskPrompt = ""
        activePanel = .tasks
        persistSession()
    }


    func retryTask(_ id: UUID, reusePlan: Bool = false) {
        guard let old = task(for: id) else { return }
        guard !settings.apiKey.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            alertMessage = "请先在设置里填写 API Key。"
            showSettings()
            return
        }
        let groupID = groups.contains(where: { $0.id == old.groupID }) ? old.groupID : (selectedGroupID ?? createGroup(select: true))
        let availableWorkingTabs = old.workingTabIDs.filter { tabID in tabs.contains(where: { $0.id == tabID && $0.groupID == groupID }) }
        let targetTabID: UUID
        if tabs.contains(where: { $0.id == old.tabID && $0.groupID == groupID }) {
            targetTabID = old.tabID
        } else if let first = availableWorkingTabs.first {
            targetTabID = first
        } else if let selectedTabID, tabs.contains(where: { $0.id == selectedTabID && $0.groupID == groupID }) {
            targetTabID = selectedTabID
        } else if let first = tabs.first(where: { $0.groupID == groupID })?.id {
            targetTabID = first
        } else {
            targetTabID = createTab(urlString: "about:blank", groupID: groupID, select: true)
        }

        let hasActive = tasks.contains { $0.groupID == groupID && !$0.status.isTerminal && $0.status != .queued }
        let queuedBefore = tasks.filter { $0.groupID == groupID && $0.status == .queued }.count
        var newTask = AgentTask(groupID: groupID, tabID: targetTabID, goal: old.goal, maxIterations: settings.maxIterations, queueIndex: queuedBefore + 1)
        let preservedTabs = Array(Set(([targetTabID] + availableWorkingTabs))).filter { tabID in tabs.contains(where: { $0.id == tabID && $0.groupID == groupID }) }
        newTask.workingTabIDs = preservedTabs.isEmpty ? [targetTabID] : preservedTabs
        if reusePlan {
            newTask.goalAnalysis = old.goalAnalysis
            newTask.checklist = old.checklist.map { item in
                TaskChecklistItem(title: item.title, detail: item.detail, isDone: false, note: "")
            }
        }
        newTask.currentAction = hasActive ? "已加入重试队列" : "正在重试任务"
        newTask.log.append(TaskLogEntry(level: .info, message: "从任务【\(old.goal)】创建重试。原状态：\(old.status.title)。"))
        tasks.insert(newTask, at: 0)
        activePanel = .tasks
        if hasActive {
            newTask.status = .queued
            updateTask(newTask.id, persist: false) { task in
                task.status = .queued
                task.currentAction = "等待该分组当前任务结束后重试"
            }
            alertMessage = "重试任务已加入队列。"
        } else {
            engine.start(taskID: newTask.id)
        }
        persistSession()
    }

    func startNextQueuedTask(for groupID: UUID) {
        let hasActive = tasks.contains { $0.groupID == groupID && !$0.status.isTerminal && $0.status != .queued }
        guard !hasActive else { return }
        let queued = tasks
            .filter { $0.groupID == groupID && $0.status == .queued }
            .sorted { $0.createdAt < $1.createdAt }
        guard let next = queued.first else { persistSession(); return }
        appendLog(taskID: next.id, "队列轮到该分组任务，开始执行。", level: .info, persist: false)
        updateTask(next.id, persist: false) { task in
            task.currentAction = "队列开始执行"
            task.queueIndex = 0
        }
        engine.start(taskID: next.id)
        persistSession()
    }

    @MainActor
    func createTabForTask(taskID: UUID, urlString: String = "about:blank", select: Bool = false) -> UUID? {
        guard let task = task(for: taskID) else { return nil }
        let tabID = createTab(urlString: urlString, groupID: task.groupID, select: select)
        updateTask(taskID, persist: false) { task in
            if !task.workingTabIDs.contains(tabID) { task.workingTabIDs.append(tabID) }
            task.tabID = tabID
        }
        appendLog(taskID: taskID, "AI 为任务创建了新页面：\(urlString)", level: .action, actionType: "createTab", persist: false)
        persistSession()
        return tabID
    }

    @MainActor
    func switchTask(taskID: UUID, to tabID: UUID) -> Bool {
        guard let task = task(for: taskID), tabs.contains(where: { $0.id == tabID && $0.groupID == task.groupID }) else { return false }
        updateTask(taskID, persist: false) { task in
            task.tabID = tabID
            if !task.workingTabIDs.contains(tabID) { task.workingTabIDs.append(tabID) }
        }
        appendLog(taskID: taskID, "AI 切换工作页面（不抢占用户当前视图）：\(tabs.first(where: { $0.id == tabID })?.displayTitle ?? tabID.uuidString)", level: .action, actionType: "switchTab", persist: false)
        persistSession()
        return true
    }

    func tabsSummary(for groupID: UUID) -> String {
        tabs.filter { $0.groupID == groupID }.map { tab in
            let activeMark = tab.id == selectedTabID ? "当前显示" : "后台"
            return "- tabID=\(tab.id.uuidString) [\(activeMark)] title=\(tab.displayTitle) url=\(tab.urlString)"
        }.joined(separator: "\n")
    }

    func tasksSummary(for groupID: UUID, excluding taskID: UUID? = nil) -> String {
        let excludedTaskID = taskID
        return tasks.filter { task in
            task.groupID == groupID && task.id != excludedTaskID
        }.prefix(20).map { task in
            "- taskID=\(task.id.uuidString) status=\(task.status.rawValue) progress=\(Int(task.progress * 100))% goal=\(task.goal.prefix(120)) current=\(task.currentAction.prefix(120))"
        }.joined(separator: "\n")
    }

    func appendLog(taskID: UUID, _ message: String, level: TaskLogLevel = .info, actionType: String? = nil, coordinates: String? = nil, result: String? = nil, persist: Bool = true) {
        guard let index = tasks.firstIndex(where: { $0.id == taskID }) else { return }
        let baseDate = tasks[index].startedAt ?? tasks[index].createdAt
        let elapsed = Date().timeIntervalSince(baseDate)
        tasks[index].log.append(TaskLogEntry(level: level, elapsedSeconds: elapsed, message: message, actionType: actionType, coordinates: coordinates, result: result))
        tasks[index].updatedAt = Date()
        if persist { persistSession() }
    }

    func updateTask(_ id: UUID, persist: Bool = true, mutate: (inout AgentTask) -> Void) {
        guard let index = tasks.firstIndex(where: { $0.id == id }) else { return }
        mutate(&tasks[index])
        tasks[index].updatedAt = Date()
        if persist { persistSession() }
    }

    func task(for id: UUID) -> AgentTask? {
        tasks.first(where: { $0.id == id })
    }

    func pauseTask(_ id: UUID) {
        updateTask(id) { task in
            guard task.status == .running || task.status == .planning || task.status == .timerRunning else { return }
            task.status = .paused
            task.currentAction = "已暂停"
        }
        appendLog(taskID: id, "用户暂停任务。", level: .warning)
    }

    func resumeTask(_ id: UUID) {
        updateTask(id) { task in
            guard task.status == .paused || task.status == .waitingConfirmation || task.status == .waitingUser || task.status == .timerRunning || task.status == .queued else { return }
            task.status = .running
            task.currentAction = task.pendingAction == nil ? "继续执行" : "已确认，准备执行待确认动作"
        }
        appendLog(taskID: id, "用户已确认继续。", level: .security)
        engine.start(taskID: id)
    }

    func stopTask(_ id: UUID) {
        stopTask(id, reason: "用户已停止")
    }

    func stopTask(_ id: UUID, reason: String) {
        let groupID = task(for: id)?.groupID
        engine.cancel(taskID: id)
        updateTask(id) { task in
            task.status = .stopped
            task.finishedAt = Date()
            task.pendingAction = nil
            task.pendingActionRisk = ""
            task.currentAction = reason
        }
        appendLog(taskID: id, reason, level: .warning)
        if let groupID { startNextQueuedTask(for: groupID) }
    }

    func clearTask(_ id: UUID) {
        if let task = task(for: id), !task.status.isTerminal {
            engine.cancel(taskID: id)
            timers.filter { $0.taskID == id && $0.status == .running }.forEach { cancelTimer($0.id) }
        }
        SnapshotFileStore.removeTaskSnapshots(taskID: id)
        tasks.removeAll { $0.id == id }
        timers.removeAll { $0.taskID == id && $0.status != .running }
        persistSession()
    }

    func clearCompletedTasks(groupID: UUID? = nil) {
        let completedIDs = Set(tasks.filter { task in
            task.status == .completed && (groupID == nil || task.groupID == groupID)
        }.map(\.id))
        guard !completedIDs.isEmpty else { return }
        completedIDs.forEach { SnapshotFileStore.removeTaskSnapshots(taskID: $0) }
        tasks.removeAll { completedIDs.contains($0.id) }
        timers.removeAll { timer in
            guard let taskID = timer.taskID else { return false }
            return completedIDs.contains(taskID) && timer.status != .running
        }
        persistSession()
    }

    func clearTerminalTasks(groupID: UUID? = nil) {
        let terminalIDs = Set(tasks.filter { task in
            task.status.isTerminal && (groupID == nil || task.groupID == groupID)
        }.map(\.id))
        guard !terminalIDs.isEmpty else { return }
        terminalIDs.forEach { SnapshotFileStore.removeTaskSnapshots(taskID: $0) }
        tasks.removeAll { terminalIDs.contains($0.id) }
        timers.removeAll { timer in
            guard let taskID = timer.taskID else { return false }
            return terminalIDs.contains(taskID) && timer.status != .running
        }
        persistSession()
    }

    func clearFailedTasks(groupID: UUID? = nil) {
        let ids = Set(tasks.filter { $0.status == .failed && (groupID == nil || $0.groupID == groupID) }.map(\.id))
        guard !ids.isEmpty else { return }
        ids.forEach { SnapshotFileStore.removeTaskSnapshots(taskID: $0) }
        tasks.removeAll { ids.contains($0.id) }
        timers.removeAll { timer in
            guard let taskID = timer.taskID else { return false }
            return ids.contains(taskID) && timer.status != .running
        }
        persistSession()
    }

    func clearStoppedTasks(groupID: UUID? = nil) {
        let ids = Set(tasks.filter { $0.status == .stopped && (groupID == nil || $0.groupID == groupID) }.map(\.id))
        guard !ids.isEmpty else { return }
        ids.forEach { SnapshotFileStore.removeTaskSnapshots(taskID: $0) }
        tasks.removeAll { ids.contains($0.id) }
        timers.removeAll { timer in
            guard let taskID = timer.taskID else { return false }
            return ids.contains(taskID) && timer.status != .running
        }
        persistSession()
    }


    func notifyTaskNeedsAttention(taskID: UUID, title: String = "Liquid AI 需要你处理", message: String) {
        let clean = message.trimmingCharacters(in: .whitespacesAndNewlines)
        let body = clean.isEmpty ? "AI 任务已暂停，需要你处理后继续。" : clean
        if selectedTabID == nil, let task = task(for: taskID) {
            selectedGroupID = task.groupID
            selectedTabID = task.tabID
        }
        alertMessage = "⚠️ \(body)"
        appendLog(taskID: taskID, "已通知用户处理：\(body)", level: .user, actionType: "userAttention")
        NotificationService.shared.notify(title: title, body: body)
    }

    private func redactedUserAnswerForLog(question: String, answer: String) -> String {
        let lower = (question + " " + answer).lowercased()
        if lower.contains("密码") || lower.contains("password") || lower.contains("passcode") || lower.contains("验证码") || lower.contains("code") || lower.contains("token") {
            return "[已隐藏敏感输入]"
        }
        return answer
    }

    func requestUserInput(taskID: UUID, question: String, placeholder: String = "请输入后继续任务") {
        updateTask(taskID) { task in
            task.status = .waitingUser
            task.pendingUserQuestion = question
            task.pendingUserPlaceholder = placeholder.isEmpty ? "请输入后继续任务" : placeholder
            task.currentAction = "AI 需要用户补充信息"
        }
        appendLog(taskID: taskID, "AI 询问用户：\(question)", level: .user, actionType: "askUser")
        alertMessage = "AI 需要你的输入：\n\(question)"
        NotificationService.shared.notify(title: "Liquid AI 需要你处理", body: question)
    }

    func updatePendingUserInput(taskID: UUID, value: String) {
        updateTask(taskID) { task in
            task.pendingUserInput = value
        }
    }

    func answerUserQuestion(taskID: UUID, answer: String) {
        let clean = answer.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !clean.isEmpty else { return }
        let question = task(for: taskID)?.pendingUserQuestion ?? ""
        updateTask(taskID) { task in
            task.status = .running
            task.pendingUserInput = ""
            task.pendingUserQuestion = ""
            task.pendingUserPlaceholder = "请输入后继续任务"
            task.currentAction = "已收到用户补充信息，继续任务"
        }
        appendLog(taskID: taskID, "用户回复：\(redactedUserAnswerForLog(question: question, answer: clean))", level: .user)
        engine.start(taskID: taskID)
    }

    @discardableResult
    func startAgentTimer(taskID: UUID, title: String, mode: AgentTimerMode, durationSeconds: Double, note: String) -> UUID {
        let task = task(for: taskID)
        let safeDuration = max(1, durationSeconds)
        let id = UUID()
        let entry = AgentTimerEntry(
            id: id,
            taskID: taskID,
            groupID: task?.groupID,
            title: title.isEmpty ? (mode == .countDown ? "AI 倒计时" : "AI 正计时") : title,
            mode: mode,
            durationSeconds: safeDuration,
            startedAt: Date(),
            endsAt: mode == .countDown ? Date().addingTimeInterval(safeDuration) : nil,
            status: .running,
            note: note
        )
        timers.insert(entry, at: 0)
        appendLog(taskID: taskID, "计时器已启动：\(entry.title)，\(mode == .countDown ? "倒计时" : "正计时") \(Int(safeDuration)) 秒。", level: .timer, actionType: "startTimer")
        if mode == .countDown {
            updateTask(taskID) { task in
                task.status = .timerRunning
                task.currentAction = "计时中：\(entry.title)"
            }
        }
        timerWorkers[id]?.cancel()
        if mode == .countDown {
            NotificationService.shared.schedule(title: "Liquid AI 计时结束", body: entry.title, after: safeDuration, identifier: id.uuidString)
            timerWorkers[id] = Task { [weak self, timerID = id] in
                do {
                    try await Task.sleep(nanoseconds: UInt64(safeDuration * 1_000_000_000))
                    await MainActor.run { [weak self] in
                        self?.finishTimer(timerID)
                    }
                } catch { }
            }
        }
        persistSession()
        return id
    }

    func finishTimer(_ id: UUID) {
        guard let index = timers.firstIndex(where: { $0.id == id }) else { return }
        guard timers[index].status == .running else { return }
        timers[index].status = .completed
        let taskID = timers[index].taskID
        timerWorkers[id] = nil
        if let taskID {
            appendLog(taskID: taskID, "计时器结束：\(timers[index].title)", level: .timer, actionType: "timerDone", persist: false)
            if let task = task(for: taskID), task.status == .timerRunning {
                updateTask(taskID, persist: false) { task in
                    task.status = .running
                    task.currentAction = "计时结束，继续任务"
                }
                engine.start(taskID: taskID)
            }
        }
        persistSession()
    }

    func cancelTimer(_ id: UUID) {
        timerWorkers[id]?.cancel()
        timerWorkers[id] = nil
        if let index = timers.firstIndex(where: { $0.id == id }) {
            timers[index].status = .cancelled
            if let taskID = timers[index].taskID { appendLog(taskID: taskID, "计时器已取消：\(timers[index].title)", level: .timer, actionType: "cancelTimer") }
        }
        UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: [id.uuidString])
        persistSession()
    }

    func timerSummary() -> String {
        timers.prefix(12).map { timer in
            "- timerID=\(timer.id.uuidString) status=\(timer.status.rawValue) mode=\(timer.mode.rawValue) title=\(timer.title) time=\(timer.displayTime) note=\(timer.note)"
        }.joined(separator: "\n")
    }

    func copyTaskLog(_ id: UUID) {
        guard let task = task(for: id) else { return }
        let text = detailedLogText(for: task)
        UIPasteboard.general.string = text
        alertMessage = "日志已复制。"
    }

    @discardableResult
    func generateReportPDF(taskID: UUID, share: Bool = false) -> URL? {
        guard let task = task(for: taskID) else { return nil }
        let tab = tabs.first(where: { $0.id == task.tabID })
        do {
            let url = try PDFReportExporter.export(task: task, tab: tab, detailedLog: detailedLogText(for: task))
            updateTask(taskID, persist: false) { task in
                task.pdfReportURLString = url.absoluteString
            }
            if share { shareItem = ShareItem(url: url) }
            appendLog(taskID: taskID, "已生成 PDF 报告：\(url.lastPathComponent)", level: .info)
            persistSession()
            return url
        } catch {
            alertMessage = "PDF 导出失败：\(error.localizedDescription)"
            return nil
        }
    }

    func generateReportPDFInBackground(taskID: UUID, share: Bool = false) {
        guard let task = task(for: taskID) else { return }
        let tab = tabs.first(where: { $0.id == task.tabID })
        let logText = detailedLogText(for: task)
        DispatchQueue.global(qos: .utility).async { [weak self] in
            do {
                let url = try PDFReportExporter.export(task: task, tab: tab, detailedLog: logText)
                DispatchQueue.main.async {
                    guard let self else { return }
                    self.updateTask(taskID, persist: false) { task in
                        task.pdfReportURLString = url.absoluteString
                    }
                    if share { self.shareItem = ShareItem(url: url) }
                    self.appendLog(taskID: taskID, "已生成 PDF 报告：\(url.lastPathComponent)", level: .info)
                    self.persistSession()
                }
            } catch {
                DispatchQueue.main.async { [weak self] in
                    self?.alertMessage = "PDF 导出失败：\(error.localizedDescription)"
                }
            }
        }
    }

    func exportReportPDF(taskID: UUID) {
        _ = generateReportPDF(taskID: taskID, share: true)
    }

    func openExistingReport(taskID: UUID) {
        guard let task = task(for: taskID), let url = URL(string: task.pdfReportURLString), FileManager.default.fileExists(atPath: url.path) else {
            _ = generateReportPDF(taskID: taskID, share: true)
            return
        }
        shareItem = ShareItem(url: url)
    }

    func detailedLogText(for task: AgentTask) -> String {
        let groupName = groups.first(where: { $0.id == task.groupID })?.displayName ?? "未知分组"
        let pages = task.workingTabIDs.compactMap { id in tabs.first(where: { $0.id == id }) }.map { "- \($0.displayTitle) | \($0.urlString)" }.joined(separator: "\n")
        let header = "任务：\(task.goal)\n分组：\(groupName)\n参与页面：\n\(pages.isEmpty ? "- 无" : pages)\n\n"
        let body = task.log.map { entry in
            let date = entry.date.formatted(date: .abbreviated, time: .standard)
            var line = "[\(date)] \(entry.compactLine)"
            if let result = entry.result, !result.isEmpty { line += "\n  result: \(result)" }
            return line
        }.joined(separator: "\n")
        return header + body
    }

    func normalizedURLString(_ text: String) -> String {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        if trimmed.isEmpty { return "about:blank" }
        let lower = trimmed.lowercased()

        if lower.contains("抖音") || lower.contains("douyin") || lower.contains("snssdk") || lower.contains("aweme") {
            let keyword = extractDouyinKeyword(from: trimmed)
            if let keyword, !keyword.isEmpty {
                let encoded = keyword.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? keyword
                return "https://www.douyin.com/search/\(encoded)"
            }
            return "https://www.douyin.com/"
        }

        if lower.contains("teams") || lower.contains("microsoft teams") || lower.contains("网页版teams") || lower.contains("网页版 teams") {
            if lower.contains("login.microsoftonline.com") || lower.contains("teams.microsoft.com") { return trimmed.hasPrefix("http") ? trimmed : "https://teams.microsoft.com/v2/" }
            return "https://teams.microsoft.com/v2/"
        }

        if let components = URLComponents(string: trimmed), let scheme = components.scheme?.lowercased(), !scheme.isEmpty {
            if ["http", "https", "about", "file"].contains(scheme) { return trimmed }
            let encoded = trimmed.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? trimmed
            return "https://www.google.com/search?q=\(encoded)"
        }

        if trimmed.contains(" ") || !trimmed.contains(".") {
            let encoded = trimmed.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? trimmed
            return "https://www.google.com/search?q=\(encoded)"
        }
        return "https://\(trimmed)"
    }

    private func extractDouyinKeyword(from text: String) -> String? {
        let patterns = ["搜索", "搜", "查找", "search", "keyword=", "q="]
        let lower = text.lowercased()
        for pattern in patterns {
            if let range = lower.range(of: pattern.lowercased()) {
                let tail = String(text[range.upperBound...])
                    .replacingOccurrences(of: "抖音", with: "")
                    .replacingOccurrences(of: "douyin", with: "", options: .caseInsensitive)
                    .replacingOccurrences(of: "=", with: "")
                    .trimmingCharacters(in: .whitespacesAndNewlines.union(CharacterSet(charactersIn: "/:?&")))
                if !tail.isEmpty { return tail }
            }
        }
        return nil
    }

    private var sessionURL: URL {
        let directory = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first ?? FileManager.default.temporaryDirectory
        try? FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        return directory.appendingPathComponent("liquid_ai_browser_session.json")
    }

    func persistSession() {
        schedulePersistSession()
    }

    func persistSessionImmediately() {
        persistWorkItem?.cancel()
        persistWorkItem = nil
        writeSessionToDisk()
    }

    private func schedulePersistSession(delay: TimeInterval = 0.35) {
        guard settings.persistSessionHistory else { return }
        persistWorkItem?.cancel()
        let item = DispatchWorkItem { [weak self] in
            self?.writeSessionToDisk()
        }
        persistWorkItem = item
        DispatchQueue.main.asyncAfter(deadline: .now() + delay, execute: item)
    }

    private func storedSessionForPersistence() -> StoredSession {
        StoredSession(groups: groups, selectedGroupID: selectedGroupID, tabs: tabs, selectedTabID: selectedTabID, tasks: tasks.map { task in
            var copy = task
            if !copy.status.isTerminal && copy.status != .queued {
                copy.status = .paused
                copy.currentAction = "App 重新打开后已暂停，可手动继续。"
            }
            copy.pendingAction = nil
            copy.pendingActionRisk = ""
            copy.lastScreenshotData = nil
            copy.stepSnapshots = copy.stepSnapshots.map { shot in
                var clean = shot
                clean.imageData = nil
                return clean
            }
            return copy
        }, timers: timers)
    }

    private func writeSessionToDisk() {
        guard settings.persistSessionHistory else { return }
        let stored = storedSessionForPersistence()
        guard let data = try? JSONEncoder().encode(stored) else { return }
        let tmp = sessionURL.appendingPathExtension("tmp")
        do {
            try data.write(to: tmp, options: [.atomic])
            if FileManager.default.fileExists(atPath: sessionURL.path) {
                _ = try? FileManager.default.replaceItemAt(sessionURL, withItemAt: tmp)
            } else {
                try FileManager.default.moveItem(at: tmp, to: sessionURL)
            }
        } catch {
            try? data.write(to: sessionURL, options: [.atomic])
        }
    }

    private func restoreSession() -> Bool {
        guard let data = try? Data(contentsOf: sessionURL), let stored = try? JSONDecoder().decode(StoredSession.self, from: data) else { return false }
        let fallbackGroup = BrowserGroup(id: UUID(uuidString: "00000000-0000-0000-0000-000000000001")!, name: "恢复的分组")
        groups = stored.groups?.isEmpty == false ? (stored.groups ?? []) : (stored.tabs.isEmpty ? [] : [fallbackGroup])
        tabs = stored.tabs.map { tab in
            var fixed = tab
            if !groups.contains(where: { $0.id == fixed.groupID }) {
                fixed.groupID = groups.first?.id ?? fallbackGroup.id
            }
            return fixed
        }
        selectedGroupID = stored.selectedGroupID ?? tabs.first?.groupID ?? groups.first?.id
        selectedTabID = stored.selectedTabID
        timers = stored.timers ?? []
        tasks = stored.tasks.map { old in
            var task = old
            if !groups.contains(where: { $0.id == task.groupID }) { task.groupID = tabs.first(where: { $0.id == task.tabID })?.groupID ?? groups.first?.id ?? fallbackGroup.id }
            if !task.workingTabIDs.contains(task.tabID) { task.workingTabIDs.append(task.tabID) }
            if !task.status.isTerminal && task.status != .queued {
                task.status = .paused
                task.currentAction = "App 重新打开后已暂停，可手动继续。"
                task.pendingAction = nil
                task.pendingActionRisk = ""
            }
            return task
        }
        normalizeSelection()
        cleanupOrphanedSnapshots()
        return true
    }

    private func normalizeSelection() {
        if let selectedGroupID, !groups.contains(where: { $0.id == selectedGroupID }) {
            self.selectedGroupID = groups.first?.id
        }
        if let selectedTabID, !tabs.contains(where: { $0.id == selectedTabID && $0.groupID == self.selectedGroupID }) {
            self.selectedTabID = self.selectedGroupID.flatMap { gid in tabs.first(where: { $0.groupID == gid })?.id }
        }
        if selectedGroupID == nil { selectedGroupID = tabs.first?.groupID ?? groups.first?.id }
        if selectedTabID == nil, let selectedGroupID { selectedTabID = tabs.first(where: { $0.groupID == selectedGroupID })?.id }
        if groups.isEmpty { selectedGroupID = nil }
        if tabs.isEmpty { selectedTabID = nil }
    }
}

enum AppPanel: String, CaseIterable {
    case none
    case newTask
    case tasks
    case settings
}
