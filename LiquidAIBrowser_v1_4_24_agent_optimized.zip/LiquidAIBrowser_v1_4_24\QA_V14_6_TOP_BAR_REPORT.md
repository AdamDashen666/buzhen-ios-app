# QA v1.4.6 顶部状态栏 / 工具栏修复报告

## 用户反馈

- 顶部状态栏挡视野。
- 希望参考 iPad DaVinci Resolve：状态/顶部栏默认隐藏，鼠标移动到顶部时显示。
- 可以把功能放在隐藏顶部栏里。

## 修复内容

### 1. 系统状态栏隐藏

`Info.plist` 修改：

- `UIStatusBarHidden = true`
- `UIViewControllerBasedStatusBarAppearance = false`

`ContentView` 增加：

- `.statusBar(hidden: true)`

目的：隐藏时间、电量、VPN 等系统状态栏信息，避免覆盖 App 顶部 UI。

### 2. 顶部浏览器工具栏自动隐藏

`BrowserAreaView` 重构为沉浸式布局：

- WebView / 空白页内容铺满浏览器区域。
- `BrowserToolbarView` 不再固定占据顶部高度。
- 工具栏以 overlay 方式显示。
- 默认短暂显示后自动隐藏。
- 鼠标移动到顶部 26pt 热区时显示。
- 轻点顶部热区也可显示，兼容触摸操作。
- 鼠标离开工具栏后自动收起。

### 3. 工具栏保留功能

隐藏工具栏仍包含：

- 返回
- 前进
- 刷新 / 停止
- 地址栏
- 新建任务
- 任务管理
- 设置

## 检查结果

- `Info.plist` 状态栏配置已更新。
- `BrowserAreaView` 已重构为 overlay 顶部栏。
- 未新增源码文件，不需要修改 Xcode Sources。
- 版本号更新为 `1.4.6 / build 13`。

## 已知边界

- iPadOS Stage Manager 的窗口装饰、窗口边距、系统悬浮控件不是 App 能完全控制的区域。
- App 能铺满并隐藏的是自己的窗口内容区和系统状态栏。
