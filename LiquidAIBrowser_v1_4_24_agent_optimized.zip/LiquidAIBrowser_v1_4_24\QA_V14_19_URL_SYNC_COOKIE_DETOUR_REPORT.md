# QA v1.4.19 - URL Sync and Cookie Detour Report

## Version

- App version: `1.4.19`
- Build: `26`
- Source root: `LiquidAIBrowser_v1_4_19/`

## User-reported problems

1. AI opened/navigated to a new page, but the top address field still showed `about:blank`.
2. Many sites were being diverted into Cookie / Privacy / Terms long-form pages, making the AI task unable to continue into the actual target site.

## Root causes

### Address bar stale URL

The tab model URL was mostly updated on explicit native loads and `didFinish`, but not aggressively enough for all WebKit navigation paths:

- JavaScript-triggered navigation.
- Popup or `target=_blank` navigation loaded back into the same WebView.
- Redirects and provisional/committed navigation before `didFinish`.
- UI address text only listened to selected tab changes and a narrow URL change path.

### Cookie / privacy detours

The previous auto-consent script gave positive score to elements containing only `cookie/privacy/隐私` context words. This meant documentation links such as “Cookie 和类似技术” or “隐私声明” could be clicked even when they were not accept buttons. That could send the task to a policy page instead of continuing login / file transfer / target site flow.

## Fixes applied

### `WebViewPool.swift`

- Added KVO observers for:
  - `estimatedProgress`
  - `url`
  - `title`
  - `isLoading`
- Added centralized `syncTabState(...)` to keep `BrowserTab.urlString`, title, loading state, and progress aligned with the real `WKWebView`.
- Synced URL in:
  - `decidePolicyFor navigationAction`
  - `didStartProvisionalNavigation`
  - `didCommit`
  - `didFinish`
  - `createWebViewWith` popup/current-tab fallback
- Added task-only policy detour guard for accidental Privacy/Cookie/Terms link navigation.
- Rebuilt `autoConsentScript` so it:
  - requires a real positive button/action text,
  - prefers `Accept / Agree / Allow / Continue / 同意 / 接受 / 允许`,
  - rejects `Privacy policy / Cookie policy / Terms / Learn more / 了解详细信息` links,
  - supports open Shadow DOM scanning,
  - runs at both document start and document end.

### `ContentView.swift`

- Added address field focus tracking.
- Address field now resyncs from `store.$tabs` and selected tab changes.
- It does not overwrite the user while the user is actively typing into the address field.

### `BrowserStore.swift`

- `updateTab(...)` now explicitly sends `objectWillChange` before in-place tab mutation so SwiftUI updates are not missed.

### `AgentEngine.swift`

- Updated AI action rules to avoid clicking Privacy/Cookie/Terms/Learn More documentation links during site entry.
- If the task lands on a privacy/cookie long-form page, AI should go back and look for the real accept/continue button instead of treating that page as the goal.

## Static checks

- Version fields updated in project file and Info.plist.
- Raw string delimiters checked for the main JS scripts.
- Source zip integrity should be verified with `unzip -t LiquidAIBrowser_v1_4_19.zip`.

## Limitation

This environment cannot run macOS/Xcode, so real `xcodebuild` and device WebKit login testing must be done in IPA Builder/Xcode. The changes are source-level and package-level fixes.
