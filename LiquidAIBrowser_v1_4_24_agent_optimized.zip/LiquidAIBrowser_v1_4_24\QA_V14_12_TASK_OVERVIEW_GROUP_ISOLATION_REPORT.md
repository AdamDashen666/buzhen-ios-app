# LiquidAIBrowser v1.4.12 修复报告：任务入口与分组浏览器数据隔离

## 修复目标

1. 左侧侧栏的「全部任务」必须进入一个完整的新页面，而不是弹窗窗口。
2. 上栏/顶部工具栏的任务按钮只显示当前分组任务，并以侧栏方式打开。
3. 每个分组的浏览器数据必须隔离，避免一个分组登录后，另一个分组自动继承登录态。

## 已完成修改

### 1. 全部任务改为完整页面

- 移除了 `showingTaskOverviewPage` 对应的 sheet 展示方式。
- 新增 `TaskOverviewPage`。
- 当用户点击左侧侧栏「全部任务」时，主区域切换为全局任务总览页面。
- 页面内提供「返回浏览器」、「清除已完成」、「清除已结束」。

### 2. 当前分组任务保持侧栏

- 顶部/上栏任务列表按钮不再打开全局任务页。
- 现在只设置 `store.activePanel = .tasks`，显示当前分组任务侧栏。
- `TasksPanel(scope: .currentGroup)` 继续只过滤当前分组任务。

### 3. 分组级 WebKit 数据隔离

- `WebViewPool` 新增 `GroupWebContext`。
- 每个 `BrowserGroup` 独立拥有：
  - `WKProcessPool`
  - `WKWebsiteDataStore.nonPersistent()`
- 创建 `WKWebView` 时，根据 `tabID -> groupID` 绑定到对应分组上下文。
- 关闭分组时调用 `resetGroupStorage(groupID:)` 清除对应上下文。
- 清空所有分组时调用 `resetAllStorageContexts()`。

## 行为说明

- 同一分组内多个页面共享该分组的登录态，便于任务在多个页面之间切换。
- 不同分组之间不共享 cookies / localStorage / sessionStorage / 登录态。
- 因为使用非持久数据存储来保证强隔离，App 完全重启后，网页登录态可能需要重新登录。

## 静态检查

- `swiftc -parse LiquidAIBrowser/*.swift`：通过。
- `Info.plist` 版本号：1.4.12 / build 19。
- `project.pbxproj` 版本号：1.4.12 / build 19。
- zip 完整性：已检查。
