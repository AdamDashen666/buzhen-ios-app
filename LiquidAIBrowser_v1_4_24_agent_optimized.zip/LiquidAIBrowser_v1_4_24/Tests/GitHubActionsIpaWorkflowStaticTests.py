from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_build_ipa_workflow_exists_and_is_manually_triggerable():
    workflow = read(".github/workflows/build-ipa.yml")
    assert "name: Build IPA" in workflow
    assert "workflow_dispatch:" in workflow
    assert "runs-on: macos-" in workflow
    assert "actions/checkout" in workflow


def test_workflow_can_build_unsigned_or_signed_ipa_artifacts():
    workflow = read(".github/workflows/build-ipa.yml")
    assert "signing" in workflow
    assert "unsigned" in workflow
    assert "signed" in workflow
    assert "CODE_SIGNING_ALLOWED=NO" in workflow
    assert "xcodebuild archive" in workflow
    assert "xcodebuild -exportArchive" in workflow
    assert "LiquidAIBrowser-unsigned.ipa" in workflow
    assert "LiquidAIBrowser-signed.ipa" in workflow
    assert "actions/upload-artifact" in workflow


def test_workflow_documents_required_ios_signing_secrets():
    workflow = read(".github/workflows/build-ipa.yml")
    for name in [
        "IOS_CERTIFICATE_P12_BASE64",
        "IOS_CERTIFICATE_PASSWORD",
        "IOS_PROVISIONING_PROFILE_BASE64",
        "IOS_TEAM_ID",
    ]:
        assert name in workflow
    assert "APPLE_PROVISIONING_PROFILE_NAME" not in workflow
    assert "security import" in workflow
    assert "security cms -D -i" in workflow
    assert "com.adam.LiquidAIBrowser" in workflow


def test_shared_xcode_scheme_is_checked_in_for_ci():
    scheme = read("LiquidAIBrowser.xcodeproj/xcshareddata/xcschemes/LiquidAIBrowser.xcscheme")
    assert "<Scheme" in scheme
    assert 'version = "1.7"' in scheme
    assert 'BlueprintName = "LiquidAIBrowser"' in scheme
    assert 'ReferencedContainer = "container:LiquidAIBrowser.xcodeproj"' in scheme
    assert 'BuildableName = "LiquidAIBrowser.app"' in scheme


if __name__ == "__main__":
    failures = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"PASS {name}")
            except Exception as exc:
                failures += 1
                print(f"FAIL {name}: {exc}")
    if failures:
        raise SystemExit(f"{failures} static test(s) failed")
    print("4 static tests passed")
