# QA v1.4.11 多网站任务 / PDF / 验收修复报告

## 触发问题

用户日志显示：

- AI 已完成 B站和 YouTube 测试后，最终验收又说 YouTube 未测试。
- 抖音测试前后判断反复矛盾，出现重复导航和重复测试。
- 计时器结束后日志出现新的“任务 worker 已启动”。
- PDF 仍可能过大。

## 原因分析

1. Agent 只把最近 12 条日志给模型，多网站任务运行时间长后，早期结论会被挤出上下文。
2. 最终验收主要读取当前活动页，不能完整看到所有参与页面的真实状态。
3. 任务没有结构化“事实记忆”，只能依赖日志文本。
4. `captureStepSnapshot` 重复调用 `appendStepSnapshot`，导致截图缓存翻倍。
5. PDF exporter 创建了 `compactSnapshots`，但实际循环仍使用 `task.stepSnapshots`，导致全部截图进入 PDF。
6. `startTimer` 后任务状态变成 `timerRunning`，动作后检查只允许 `.running`，导致 worker 退出，计时结束后又重新启动。

## 修复内容

- 新增 `AgentFinding`：记录 subject/status/evidence/urlString/updatedAt。
- `AgentDecision` 新增 `findings` 字段。
- 每轮决策 prompt 强制要求多网站对比任务记录 findings。
- 每轮都把已记录 findings 传回 AI，避免忘记 B站/YouTube 已测试。
- 最终验收改为读取所有参与页面状态，并结合 findings。
- 验收 JSON 解析失败时不再直接判定完成。
- 修复重复截图缓存。
- 修复 PDF 关键截图选择逻辑。
- PDF 日志最多输出 120 行。
- 计时器动作后允许 `.timerRunning` 继续进入等待循环，减少 worker 重启日志。

## 静态检查

- `swiftc -parse *.swift`：通过。
- 版本号：1.4.11 / build 18。

## 仍需真机验证

- 长任务多网站比较场景。
- 最终报告中的 findings 是否符合用户预期。
- PDF 实际页数和图片清晰度。
