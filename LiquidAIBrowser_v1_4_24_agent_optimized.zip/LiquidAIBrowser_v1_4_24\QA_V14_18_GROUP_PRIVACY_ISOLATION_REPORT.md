# QA v1.4.18 - Group Privacy Isolation Report

## Version

- App version: `1.4.18`
- Build number: `25`
- Source root: `LiquidAIBrowser_v1_4_18/`

## User Requirement

Each browser group must behave like a separate temporary browser:

- Cookies and site data can be shared only within the same group.
- Different groups must not share cookies, LocalStorage, cache, IndexedDB or Service Worker data.
- Creating a new group must start a clean browser environment.
- Deleting/closing a group must delete that group's browser data and task artifacts.
- Closed groups should not leave old task reports/screenshots around and mix with other groups.

## Changes Made

### 1. WebKit group isolation hardened

File: `LiquidAIBrowser/WebViewPool.swift`

- Added explicit `prepareGroupStorage(groupID:)` so a group receives its own runtime web context immediately when created.
- Kept the existing per-group `WKProcessPool` + `WKWebsiteDataStore.nonPersistent()` structure.
- Added `purgeWebsiteData(from:)` to clear:
  - HTTP cookies
  - WebKit website data records
  - LocalStorage / SessionStorage style records
  - IndexedDB / cache records
  - Service Worker related records

### 2. Group deletion now removes all related app data

File: `LiquidAIBrowser/BrowserStore.swift`

- Added task artifact cleanup:
  - task screenshots under `TaskSnapshots/<taskID>/`
  - generated `LiquidAIBrowser_Report_*.pdf` files
- Added timer cleanup:
  - cancels timer workers
  - removes pending local notification requests
- `closeGroup(_:)` now removes:
  - all tabs in the group
  - all tasks in the group, including completed/failed/queued tasks
  - all timers associated with the group or those tasks
  - snapshots and generated PDF artifacts
  - the group's WebKit temporary data context

### 3. Clear-all cleanup fixed

File: `LiquidAIBrowser/BrowserStore.swift`

`clearAllGroups()` now removes all browser/task data instead of only stopping tasks and leaving old task entries behind.

### 4. UI privacy explanation added

File: `LiquidAIBrowser/Panels.swift`

Added a settings-page note explaining that group web data is isolated and cleared when a group is closed.

## Static Verification

Checked source markers:

- `MARKETING_VERSION = 1.4.18`
- `CURRENT_PROJECT_VERSION = 25`
- `CFBundleShortVersionString = 1.4.18`
- `CFBundleVersion = 25`
- `WKWebsiteDataStore.nonPersistent()` remains used for group contexts.
- `resetGroupStorage(groupID:)` now purges WebKit data before dropping the context.
- `closeGroup(_:)` removes group tasks and tabs before persisting session.

## Known Limitations

- This environment cannot run `xcodebuild` because macOS/Xcode is unavailable.
- WebKit data purge completion is asynchronous by Apple API design; the group context is dropped immediately after scheduling purge. Because the data store is non-persistent and all web views are destroyed first, this should prevent cross-group reuse.
