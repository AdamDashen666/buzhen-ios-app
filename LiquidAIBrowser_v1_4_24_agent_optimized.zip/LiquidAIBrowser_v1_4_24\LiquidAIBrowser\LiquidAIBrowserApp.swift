import SwiftUI

@main
struct LiquidAIBrowserApp: App {
    var body: some Scene {
        WindowGroup {
            BrowserSceneRoot()
        }
    }
}

struct BrowserSceneRoot: View {
    @StateObject private var store = BrowserStore()

    var body: some View {
        ContentView()
            .environmentObject(store)
            .preferredColorScheme(.dark)
            .onAppear { NotificationService.shared.requestAuthorization() }
            .transaction { transaction in
                transaction.animation = transaction.animation ?? Animation.interactiveSpring(response: 0.28, dampingFraction: 0.88, blendDuration: 0.08)
            }
    }
}
