import Foundation

struct AIClient {
    struct ChatMessage: Encodable {
        let role: String
        let content: String
        let imageBase64JPEG: String?

        init(role: String, content: String, imageBase64JPEG: String? = nil) {
            self.role = role
            self.content = content
            self.imageBase64JPEG = imageBase64JPEG
        }

        enum CodingKeys: String, CodingKey { case role, content }
        enum ContentCodingKeys: String, CodingKey { case type, text, image_url }
        enum ImageURLCodingKeys: String, CodingKey { case url }

        func encode(to encoder: Encoder) throws {
            var container = encoder.container(keyedBy: CodingKeys.self)
            try container.encode(role, forKey: .role)
            guard let imageBase64JPEG, !imageBase64JPEG.isEmpty else {
                try container.encode(content, forKey: .content)
                return
            }
            var parts = container.nestedUnkeyedContainer(forKey: .content)
            var textPart = parts.nestedContainer(keyedBy: ContentCodingKeys.self)
            try textPart.encode("text", forKey: .type)
            try textPart.encode(content, forKey: .text)
            var imagePart = parts.nestedContainer(keyedBy: ContentCodingKeys.self)
            try imagePart.encode("image_url", forKey: .type)
            var imageURL = imagePart.nestedContainer(keyedBy: ImageURLCodingKeys.self, forKey: .image_url)
            try imageURL.encode("data:image/jpeg;base64,\(imageBase64JPEG)", forKey: .url)
        }
    }

    struct ChatRequest: Encodable {
        let model: String
        let messages: [ChatMessage]
        let temperature: Double
        let response_format: ResponseFormat?
        let thinking: ThinkingConfig?
        let reasoning_effort: String?
    }

    struct ResponseFormat: Encodable {
        let type: String
    }

    struct ThinkingConfig: Encodable {
        let type: String
    }

    struct Usage: Decodable {
        let promptTokens: Int?
        let completionTokens: Int?
        let totalTokens: Int?
        let promptCacheHitTokens: Int?
        let promptCacheMissTokens: Int?

        enum CodingKeys: String, CodingKey {
            case promptTokens = "prompt_tokens"
            case completionTokens = "completion_tokens"
            case totalTokens = "total_tokens"
            case promptCacheHitTokens = "prompt_cache_hit_tokens"
            case promptCacheMissTokens = "prompt_cache_miss_tokens"
        }

        var compactLine: String {
            [
                totalTokens.map { "tokens=\($0)" },
                promptTokens.map { "in=\($0)" },
                completionTokens.map { "out=\($0)" },
                promptCacheHitTokens.map { "cacheHit=\($0)" },
                promptCacheMissTokens.map { "cacheMiss=\($0)" }
            ].compactMap { $0 }.joined(separator: " ")
        }
    }

    struct ChatResult {
        let content: String
        let model: String
        let routeName: String
        let elapsedMilliseconds: Int
        let sentVision: Bool
        let usage: Usage?

        var compactLine: String {
            let usageText = usage?.compactLine ?? "usage=unavailable"
            return "\(routeName) model=\(model) \(elapsedMilliseconds)ms vision=\(sentVision ? "yes" : "no") \(usageText)"
        }
    }

    struct ChatOptions: Equatable {
        let routeName: String
        let modelOverride: String?
        let disableThinking: Bool
        let reasoningEffort: String?
        let sentVision: Bool

        var usesProviderControls: Bool {
            disableThinking || reasoningEffort != nil
        }

        func withoutProviderControls() -> ChatOptions {
            ChatOptions(routeName: routeName, modelOverride: modelOverride, disableThinking: false, reasoningEffort: nil, sentVision: sentVision)
        }

        static let standard = ChatOptions(routeName: "standard", modelOverride: nil, disableThinking: false, reasoningEffort: nil, sentVision: false)

        static func fast(snapshot: AISettingsSnapshot, includesVision: Bool = false) -> ChatOptions {
            let model = includesVision ? snapshot.visionModel : snapshot.fastModel
            return ChatOptions(
                routeName: includesVision ? "Flash Vision" : "Flash",
                modelOverride: model.isEmpty ? snapshot.model : model,
                disableThinking: snapshot.disableThinkingForFastTurns && snapshot.supportsDeepSeekControls,
                reasoningEffort: nil,
                sentVision: includesVision
            )
        }

        static func escalation(snapshot: AISettingsSnapshot, includesVision: Bool = false) -> ChatOptions {
            let model = includesVision ? snapshot.visionModel : snapshot.escalationModel
            return ChatOptions(
                routeName: includesVision ? "Pro Vision" : "Pro",
                modelOverride: model.isEmpty ? snapshot.model : model,
                disableThinking: false,
                reasoningEffort: snapshot.supportsDeepSeekControls ? "high" : nil,
                sentVision: includesVision
            )
        }
    }

    struct ChatResponse: Decodable {
        struct Choice: Decodable {
            struct Message: Decodable { let content: String? }
            let message: Message
        }
        let choices: [Choice]
        let usage: Usage?
    }

    struct ModelsResponse: Decodable {
        struct Model: Decodable { let id: String }
        let data: [Model]
    }

    func chatJSON(snapshot: AISettingsSnapshot, messages: [ChatMessage], options: ChatOptions = .standard) async throws -> String {
        try await chatResultJSON(snapshot: snapshot, messages: messages, options: options).content
    }

    func chatResultJSON(snapshot: AISettingsSnapshot, messages: [ChatMessage], options: ChatOptions = .standard) async throws -> ChatResult {
        var attempts: [(Bool, ChatOptions)] = [(snapshot.useJSONMode, options)]
        if options.usesProviderControls {
            attempts.append((snapshot.useJSONMode, options.withoutProviderControls()))
        }
        if snapshot.useJSONMode {
            attempts.append((false, options))
            if options.usesProviderControls { attempts.append((false, options.withoutProviderControls())) }
        }

        var seen = Set<String>()
        var lastError: Error?
        for (jsonMode, attemptOptions) in attempts {
            let key = "\(jsonMode)|\(attemptOptions.routeName)|\(attemptOptions.modelOverride ?? "")|\(attemptOptions.disableThinking)|\(attemptOptions.reasoningEffort ?? "")"
            guard !seen.contains(key) else { continue }
            seen.insert(key)
            do {
                return try await chat(snapshot: snapshot, messages: messages, jsonMode: jsonMode, options: attemptOptions)
            } catch {
                lastError = error
            }
        }
        throw lastError ?? NSError(domain: "LiquidAIBrowser.API", code: -1, userInfo: [NSLocalizedDescriptionKey: "AI request failed"])
    }

    private func chat(snapshot: AISettingsSnapshot, messages: [ChatMessage], jsonMode: Bool, options: ChatOptions) async throws -> ChatResult {
        let url = endpoint(baseURL: snapshot.baseURL, path: "chat/completions")
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.timeoutInterval = snapshot.requestTimeout
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("Bearer \(snapshot.apiKey)", forHTTPHeaderField: "Authorization")
        request.setValue("LiquidAIBrowser", forHTTPHeaderField: "X-Title")
        request.setValue("https://liquid-ai-browser.local", forHTTPHeaderField: "HTTP-Referer")
        let cleanOverride = options.modelOverride?.trimmingCharacters(in: .whitespacesAndNewlines)
        let model = cleanOverride?.isEmpty == false ? cleanOverride! : snapshot.model
        let body = ChatRequest(
            model: model,
            messages: messages,
            temperature: snapshot.temperature,
            response_format: jsonMode ? ResponseFormat(type: "json_object") : nil,
            thinking: options.disableThinking ? ThinkingConfig(type: "disabled") : nil,
            reasoning_effort: options.reasoningEffort
        )
        request.httpBody = try JSONEncoder().encode(body)
        let start = Date()
        let (data, response) = try await URLSession.shared.data(for: request)
        if let http = response as? HTTPURLResponse, !(200...299).contains(http.statusCode) {
            let text = String(data: data, encoding: .utf8) ?? "HTTP \(http.statusCode)"
            throw NSError(domain: "LiquidAIBrowser.API", code: http.statusCode, userInfo: [NSLocalizedDescriptionKey: text])
        }
        let decoded = try JSONDecoder().decode(ChatResponse.self, from: data)
        let elapsed = Int(Date().timeIntervalSince(start) * 1000)
        return ChatResult(
            content: decoded.choices.first?.message.content ?? "{}",
            model: model,
            routeName: options.routeName,
            elapsedMilliseconds: elapsed,
            sentVision: options.sentVision,
            usage: decoded.usage
        )
    }

    func fetchModels(snapshot: AISettingsSnapshot) async throws -> [String] {
        let url = endpoint(baseURL: snapshot.baseURL, path: "models")
        var request = URLRequest(url: url)
        request.timeoutInterval = snapshot.requestTimeout
        request.setValue("Bearer \(snapshot.apiKey)", forHTTPHeaderField: "Authorization")
        request.setValue("https://liquid-ai-browser.local", forHTTPHeaderField: "HTTP-Referer")
        request.setValue("LiquidAIBrowser", forHTTPHeaderField: "X-Title")
        let (data, response) = try await URLSession.shared.data(for: request)
        if let http = response as? HTTPURLResponse, !(200...299).contains(http.statusCode) {
            let text = String(data: data, encoding: .utf8) ?? "HTTP \(http.statusCode)"
            throw NSError(domain: "LiquidAIBrowser.API", code: http.statusCode, userInfo: [NSLocalizedDescriptionKey: text])
        }
        let decoded = try JSONDecoder().decode(ModelsResponse.self, from: data)
        return decoded.data.map(\.id).sorted()
    }

    private func endpoint(baseURL: String, path: String) -> URL {
        var clean = Self.normalizedBaseURL(baseURL)
        if clean.isEmpty { clean = "https://api.openai.com/v1" }
        if path == "chat/completions", clean.hasSuffix("/chat/completions") {
            return URL(string: clean) ?? URL(string: "https://api.openai.com/v1/chat/completions")!
        }
        if path == "models", clean.hasSuffix("/models") {
            return URL(string: clean) ?? URL(string: "https://api.openai.com/v1/models")!
        }
        return URL(string: clean + "/" + path) ?? URL(string: "https://api.openai.com/v1/" + path)!
    }

    static func normalizedBaseURL(_ baseURL: String) -> String {
        var clean = baseURL.trimmingCharacters(in: .whitespacesAndNewlines)
        while clean.hasSuffix("/") { clean.removeLast() }
        if clean.hasSuffix("/chat/completions") {
            clean = String(clean.dropLast("/chat/completions".count))
        }
        if clean.hasSuffix("/models") {
            clean = String(clean.dropLast("/models".count))
        }
        return clean
    }

    static func extractJSONObject(from text: String) -> String {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard let start = trimmed.firstIndex(of: "{") else { return "{}" }
        var depth = 0
        var inString = false
        var escape = false
        var endIndex: String.Index?
        var index = start
        while index < trimmed.endIndex {
            let char = trimmed[index]
            if escape { escape = false }
            else if char == "\\" { escape = true }
            else if char == "\"" { inString.toggle() }
            else if !inString {
                if char == "{" { depth += 1 }
                if char == "}" {
                    depth -= 1
                    if depth == 0 { endIndex = trimmed.index(after: index); break }
                }
            }
            index = trimmed.index(after: index)
        }
        if let endIndex = endIndex { return String(trimmed[start..<endIndex]) }
        return "{}"
    }
}

private extension AISettingsSnapshot {
    var supportsDeepSeekControls: Bool {
        let joined = [baseURL, model, fastModel, escalationModel, visionModel].joined(separator: " ").lowercased()
        return joined.contains("deepseek")
    }
}
