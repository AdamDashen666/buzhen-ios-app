# QA v1.4.23 - Agent Wait Plugins Report

## Version

- App version: `1.4.23`
- Build: `29`
- Source root: `LiquidAIBrowser_v1_4_23/`

## User Request

Add a page-load waiting plugin and common AI tools. The page-load plugin should wait until the page is loaded before the AI continues acting.

## Implemented Tools / Plugins

### `waitForPageReady`

Native WKWebView-level page readiness wait. It checks:

- `WKWebView.isLoading`
- `WKWebView.estimatedProgress`
- `document.readyState`
- current URL
- DOM node count stability
- visible page text length stability
- page height stability
- visible loading/progress/spinner nodes

The tool waits until the page is stable for a short period before returning success.

### `waitForElement`

Uses the same native waiting engine, but also requires:

- `selector` exists
- selected element is visible

### `waitForText`

Uses the same native waiting engine, but also requires page body text to contain:

- `text` or `value`

### `waitForUrl`

Uses the same native waiting engine, but also requires `location.href` to contain:

- `url`

### `autoConsent`

Runs the built-in cookie/consent handler again and asks the AI to re-check the page after it runs.

## Automatic Stabilization

The engine now automatically performs a short page-readiness wait after page-changing actions:

- `navigate`
- `createTab/openTab`
- `reload`
- `back`
- `forward`
- `click`
- `coordinateClick/tap`
- `doubleClick`
- `submit`
- `select`
- `pressEnter`

This reduces cases where the AI clicks too early while the page is still loading.

## Prompt / Schema Updates

The action schema now exposes:

- `waitForPageReady`
- `waitForElement`
- `waitForText`
- `waitForUrl`
- `autoConsent`

The prompt instructs the AI to prefer `waitForPageReady` after navigation/click/refresh/back/submit and to use targeted waiting tools when specific selectors, text, or URLs are expected.

## Input Guard Follow-up

Added missing Codable fields so AI-supplied repeat controls survive decoding/encoding:

- `allowRepeatedInput`
- `expectedCount`
- `repeatCount`
- `inputCount`

This preserves the previous exact-input guard behavior while allowing legitimate repeated input when explicitly requested.

## Files Changed

- `LiquidAIBrowser/WebViewPool.swift`
- `LiquidAIBrowser/AgentEngine.swift`
- `LiquidAIBrowser/BrowserModels.swift`
- `LiquidAIBrowser/Info.plist`
- `LiquidAIBrowser.xcodeproj/project.pbxproj`
- `CHANGELOG.md`
- `PROJECT_INDEX.md`
- `README.md`
- `AI_REVIEW_REQUIREMENTS.md`

## Notes

- This is implemented as internal AI action tools, not App Store-style external extensions.
- Long waits should still use `startTimer`; page-loading waits should use `waitForPageReady`.
- This environment cannot run Xcode, so the final check is source/zip integrity only.
