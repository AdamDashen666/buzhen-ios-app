import Foundation

struct LocalActionResolution {
    let action: AgentAction
    let reason: String
    let confidence: Double

    var isHighConfidence: Bool { confidence >= 0.82 }
}

struct LocalActionResolver {
    func resolve(goal: String, task: AgentTask, compactContext: CompactPageContext) -> LocalActionResolution? {
        let context = decode(compactContext.jsonString)
        let nextStep = task.checklist.first(where: { !$0.isDone })
        let stepText = [nextStep?.title, nextStep?.detail, goal].compactMap { $0 }.joined(separator: " ")
        let lower = stepText.lowercased()

        if shouldWait(context: context, stepText: lower) {
            var action = AgentAction(type: "waitForPageReady")
            action.durationMs = 8_000
            action.reason = "LocalActionResolver: page is still loading or current step asks to wait"
            return LocalActionResolution(action: action, reason: "local waitForPageReady", confidence: 0.95)
        }

        if let url = extractURL(from: stepText), shouldNavigate(context: context, url: url) {
            var action = AgentAction(type: "navigate")
            action.url = url
            action.reason = "LocalActionResolver: explicit URL found in goal or next step"
            return LocalActionResolution(action: action, reason: "local navigate", confidence: 0.92)
        }

        if lower.contains("waitfortext"), let target = quotedCandidates(from: stepText).first {
            var action = AgentAction(type: "waitForText")
            action.text = target
            action.durationMs = 10_000
            action.reason = "LocalActionResolver: explicit waitForText request"
            return LocalActionResolution(action: action, reason: "local waitForText", confidence: 0.9)
        }

        if lower.contains("waitforurl"), let target = extractURL(from: stepText) {
            var action = AgentAction(type: "waitForUrl")
            action.url = target
            action.durationMs = 10_000
            action.reason = "LocalActionResolver: explicit waitForUrl request"
            return LocalActionResolution(action: action, reason: "local waitForUrl", confidence: 0.9)
        }

        if isClickStep(lower), let action = clickAction(stepText: stepText, context: context) {
            return LocalActionResolution(action: action, reason: "local click exact text", confidence: 0.86)
        }

        if isInputStep(lower), let action = inputAction(stepText: stepText, context: context) {
            return LocalActionResolution(action: action, reason: "local input by label/placeholder", confidence: 0.84)
        }

        if isSendMessageStep(lower), let action = sendMessageAction(stepText: stepText, context: context) {
            return LocalActionResolution(action: action, reason: "local sendMessage/teamsSendMessage", confidence: 0.84)
        }

        return nil
    }

    private func shouldWait(context: [String: Any], stepText: String) -> Bool {
        if (context["isLoading"] as? Bool) == true { return true }
        let readyState = ((context["readyState"] as? String) ?? "").lowercased()
        if readyState == "loading" { return true }
        return stepText.contains("wait") || stepText.contains("等待") || stepText.contains("加载")
    }

    private func shouldNavigate(context: [String: Any], url: String) -> Bool {
        let current = ((context["url"] as? String) ?? "").lowercased()
        guard !url.isEmpty else { return false }
        if current.isEmpty || current == "about:blank" { return true }
        return !current.contains(url.lowercased())
    }

    private func isClickStep(_ value: String) -> Bool {
        value.contains("click") || value.contains("tap") || value.contains("点击") || value.contains("打开") || value.contains("选择")
    }

    private func isInputStep(_ value: String) -> Bool {
        value.contains("input") || value.contains("type") || value.contains("输入") || value.contains("填写") || value.contains("搜索")
    }

    private func isSendMessageStep(_ value: String) -> Bool {
        value.contains("sendmessage") || value.contains("teamssendmessage") || value.contains("发送") || value.contains("send")
    }

    private func clickAction(stepText: String, context: [String: Any]) -> AgentAction? {
        let targets = quotedCandidates(from: stepText)
        guard !targets.isEmpty else { return nil }
        let candidates = ((context["buttons"] as? [[String: Any]]) ?? []) + ((context["links"] as? [[String: Any]]) ?? []) + ((context["elements"] as? [[String: Any]]) ?? [])
        for target in targets {
            if let element = candidates.first(where: { elementMatches($0, target: target) }),
               let selector = element["selector"] as? String, !selector.isEmpty {
                var action = AgentAction(type: "click")
                action.selector = selector
                action.text = target
                action.reason = "LocalActionResolver: matched visible element text"
                return action
            }
        }
        return nil
    }

    private func inputAction(stepText: String, context: [String: Any]) -> AgentAction? {
        let values = quotedCandidates(from: stepText)
        guard let value = values.last, !value.isEmpty else { return nil }
        let inputs = context["inputs"] as? [[String: Any]] ?? []
        guard let input = preferredInput(inputs: inputs, stepText: stepText),
              let selector = input["selector"] as? String, !selector.isEmpty else { return nil }
        var action = AgentAction(type: "input")
        action.selector = selector
        action.value = value
        action.reason = "LocalActionResolver: matched visible input by focus/label/placeholder"
        return action
    }

    private func sendMessageAction(stepText: String, context: [String: Any]) -> AgentAction? {
        let values = quotedCandidates(from: stepText)
        guard let value = values.last, !value.isEmpty else { return nil }
        let url = ((context["url"] as? String) ?? "").lowercased()
        var action = AgentAction(type: url.contains("teams") ? "teamsSendMessage" : "sendMessage")
        action.value = value
        action.text = value
        action.reason = "LocalActionResolver: explicit send message text"
        return action
    }

    private func preferredInput(inputs: [[String: Any]], stepText: String) -> [String: Any]? {
        if let focused = inputs.first(where: { ($0["focused"] as? Bool) == true }) { return focused }
        let lower = stepText.lowercased()
        let keywords = ["search", "query", "搜索", "email", "username", "账号", "message", "消息"]
        for keyword in keywords where lower.contains(keyword.lowercased()) {
            if let match = inputs.first(where: { elementMatches($0, target: keyword) }) { return match }
        }
        return inputs.first
    }

    private func elementMatches(_ element: [String: Any], target: String) -> Bool {
        let target = normalize(target)
        guard !target.isEmpty else { return false }
        let text = normalize([
            element["text"] as? String,
            element["placeholder"] as? String,
            element["label"] as? String,
            element["value"] as? String,
            element["name"] as? String,
            element["searchText"] as? String
        ].compactMap { $0 }.joined(separator: " "))
        return text == target || text.contains(target)
    }

    private func quotedCandidates(from text: String) -> [String] {
        let pattern = #""([^"]{1,160})"|'([^']{1,160})'|“([^”]{1,160})”|‘([^’]{1,160})’"#
        guard let regex = try? NSRegularExpression(pattern: pattern) else { return [] }
        let nsText = text as NSString
        return regex.matches(in: text, range: NSRange(location: 0, length: nsText.length)).compactMap { match in
            for index in 1..<match.numberOfRanges where match.range(at: index).location != NSNotFound {
                return nsText.substring(with: match.range(at: index)).trimmingCharacters(in: .whitespacesAndNewlines)
            }
            return nil
        }
    }

    private func extractURL(from text: String) -> String? {
        let pattern = #"https?://[^\s"'<>，。；、]+"#
        guard let regex = try? NSRegularExpression(pattern: pattern),
              let match = regex.firstMatch(in: text, range: NSRange(text.startIndex..<text.endIndex, in: text)),
              let range = Range(match.range, in: text) else { return nil }
        return String(text[range])
    }

    private func normalize(_ value: String) -> String {
        value.replacingOccurrences(of: #"\s+"#, with: " ", options: .regularExpression)
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .lowercased()
    }

    private func decode(_ json: String) -> [String: Any] {
        guard let data = json.data(using: .utf8),
              let object = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else { return [:] }
        return object
    }
}
