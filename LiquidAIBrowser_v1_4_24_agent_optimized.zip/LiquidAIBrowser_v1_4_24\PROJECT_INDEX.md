## v1.4.24 / Build 31 - Manual Navbar Collapse

- 顶部网页导航栏默认保持展开，不再自动收起。
- 新增导航栏手动收起按钮，避免用户/AI 输入网页内容时因为自动收起导致焦点丢失。
- 收起后顶部保留热区，鼠标/指针移动到页面上方会自动拉出导航栏。
- 保留页面输入、AI 操作、地址栏同步和上一版 Teams 输入保护能力。
- QA: see `QA_V14_24_MANUAL_NAVBAR_COLLAPSE_REPORT.md`.

# LiquidAIBrowser v1.4.16 Project Index

- Marketing Version: 1.4.16
- Build: 23
- Package: LiquidAIBrowser_v1_4_16.zip

## Key v1.4.16 changes

- Fixed initial page scan failure caused by JavaScript exception.
- Added missing Agent Bridge `formSummary()` implementation.
- Added safe collect-state wrapper and Swift fallback JSON.
- Added Agent Bridge versioning so stale/broken bridges can be replaced.
- Preserved v1.4.15 stability fixes.

## Important files

- `LiquidAIBrowser/WebViewPool.swift`
  - Browser WebView lifecycle, compatibility UA, JS bridge, safe page scan, screenshots.
- `LiquidAIBrowser/AgentEngine.swift`
  - Agent worker loop, planning, action execution, verification.
- `LiquidAIBrowser/BrowserStore.swift`
  - App state, tasks, tabs, persistence, reports.
- `LiquidAIBrowser/PDFReportExporter.swift`
  - Task report PDF generation.
- `QA_V14_16_JS_SCAN_RECOVERY_REPORT.md`
  - v1.4.16 focused fix report.

## Static checks

- `node --check safeCollectStateScript` OK
- `node --check autoConsentScript` OK
- `node --check agentBridgeScript` OK
- `swiftc -parse LiquidAIBrowser/*.swift` OK


## Previous index/history

# LiquidAIBrowser v1.4.15 Project Index

## Version
- Marketing Version: 1.4.15
- Build: 22

## Main source files
- `LiquidAIBrowserApp.swift`: App entry.
- `ContentView.swift`: Main route, browser layout, settings page, task overview page, toast banner.
- `BrowserStore.swift`: Groups, tabs, tasks, timers, PDF generation, session persistence.
- `BrowserModels.swift`: Data models, task snapshots, plan history, findings.
- `AgentEngine.swift`: Agent loop, planning, decisions, verification, action execution.
- `WebViewPool.swift`: WKWebView pool, JS bridge, DOM reading, actions, screenshots.
- `PDFReportExporter.swift`: PDF report generation.
- `Panels.swift`: New task, task cards, settings, task management panels.
- `AIClient.swift`: OpenAI-compatible API client and JSON extraction.
- `AISettings.swift`: API settings, presets, Keychain.
- `NotificationService.swift`: Local notifications.
- `WindowSizingSupport.swift`: Stage Manager/window sizing support.

## Important reports
- `QA_V14_14_STABILITY_COMPLIANCE_FIX_REPORT.md`: This version's fix report.
- `AI_REVIEW_REQUIREMENTS.md`: Current requirements document.
- `QA_CHECK_REPORT.md`: Prior static check report.
- `QA_FIX_REPORT.md`: Prior fix summary.

## Key v1.4.15 changes
- Independent settings page.
- Auto PDF report after task completion.
- Screenshot file storage under Application Support.
- Enhanced DOM/page state reading.
- Native wait/reload/forward/stopLoading/back.
- Clear failed/stopped task actions.
- No system alert/confirmation dialog for normal operations.
- Background task no longer hijacks current UI.
- Count-up timer fixed.
- Original plan and plan history stored.


## v1.4.15 Stability Hardening

- `QA_V14_15_STABILITY_HARDENING_REPORT.md`: 稳定性专项修复报告。
- BrowserStore: 防抖 session、后台 PDF、截图缓存清理。
- WebViewPool: WebKit 进程恢复、bridge 重注入、about:blank 和截图稳定性。
- AgentEngine: 连续失败判定、JS 动作超时、后台 PDF 触发。

## v1.4.15 Build Diagnostics Patch

- `QA_V14_15_BUILD_AND_STABILITY_REPORT.md`: 构建诊断修复与稳定性检查报告。
- 修复 Xcode 26.3 下 Swift `String.init` ambiguous 与 `excluding` 参数解析问题。
