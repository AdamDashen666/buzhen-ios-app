# LiquidAIBrowser v1.4.16 JS 扫描异常与稳定性修复报告

## 用户日志问题

任务刚开始，在 about:blank 首次扫描页面阶段立即失败：

```text
开始任务前先扫描当前活动页面，避免盲目操作。
失败：A JavaScript exception occurred
```

## 根因

静态检查 `WebViewPool.swift` 后发现 v1.4.15 的 Agent Bridge 中 `collectState()` 调用了：

```javascript
inputButtonSummary: formSummary()
```

但 `formSummary()` 函数没有定义。  
因此只要任务开始扫描页面，`collectState()` 就可能直接抛出 JavaScript exception，导致任务在第一步失败，无法进入导航、登录或重试流程。

## 修复内容

### 1. 补回 `formSummary()`

新增稳定版 `formSummary()`，用于收集：

- 当前可见 input / textarea / contenteditable / role=textbox
- 当前可见 button / role=button / submit button
- focused 状态
- disabled 状态
- rect 坐标
- label / placeholder / name / value / searchText

### 2. `collectState()` 全量 try/catch

`collectState()` 现在内部包裹 try/catch。  
即使页面 DOM、某个元素、Teams 动态节点、无 body 页面触发异常，也会返回最小页面状态，而不是让任务失败。

### 3. 新增 `safeCollectStateScript`

Swift 原生扫描入口不再直接裸调用 `window.__liquidAgent.collectState()`。  
现在使用安全 IIFE：

- bridge 可用：调用 bridge collectState
- bridge 未准备好：返回 fallback state
- bridge 抛异常：返回 fallback state + collectError
- fallback 本身失败：返回硬编码最小 JSON

### 4. Swift 侧扫描失败兜底

`collectPageState(tabID:)` 新增三层兜底：

1. 正常 evaluate safe collect
2. 失败后重新注入 autoConsent + agentBridge，再重试
3. 仍失败时返回 Swift 侧 fallback JSON

这样页面扫描不能再因为一次 JS exception 直接终止整个任务。

### 5. Bridge 版本号与重注入

Agent Bridge 增加：

```javascript
version: '1.4.16'
```

注入逻辑从旧版：

```javascript
if (window.__liquidAgent) return;
```

改为：

```javascript
if (window.__liquidAgent && window.__liquidAgent.version === '1.4.16') return;
```

这样旧 bridge 或半损坏 bridge 可以被新版本覆盖，避免页面里残留旧对象继续报错。

### 6. `evaluateJSON()` 增强恢复

如果返回内容包含 `collectError`，会自动重新注入 bridge 并重试一次。

## 影响范围

主要修复：

- about:blank 初始扫描失败
- Teams 任务开始就报 `A JavaScript exception occurred`
- Agent Bridge 部分函数缺失导致任务无法启动
- 页面状态读取单点异常导致 worker 直接失败

不改变：

- Teams 专用发送逻辑
- 分组隔离逻辑
- 截图落盘逻辑
- PDF 自动生成逻辑
- 任务 UI 逻辑

## 静态检查结果

```text
node --check safeCollectStateScript OK
node --check autoConsentScript OK
node --check agentBridgeScript OK
swiftc -parse LiquidAIBrowser/*.swift OK
Info.plist version 1.4.16 / build 23 OK
```

## 仍需真机验证

- Teams 登录页首次扫描是否不再直接失败
- 旧任务重试时旧 bridge 是否会被覆盖
- Teams 聊天页 collectState 是否稳定
- 长任务中 collectError 是否能自动恢复
