from pathlib import Path
import re


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "LiquidAIBrowser"
PROJECT = ROOT / "LiquidAIBrowser.xcodeproj" / "project.pbxproj"


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def test_agent_optimization_files_are_project_sources():
    pbx = read(PROJECT)
    for filename in [
        "PageContextReducer.swift",
        "LocalActionResolver.swift",
        "EscalationPolicy.swift",
    ]:
        assert (APP / filename).exists(), f"{filename} should exist"
        assert filename in pbx, f"{filename} should be added to the Xcode project"
        assert f"{filename} in Sources" in pbx, f"{filename} should be compiled"


def test_ai_settings_exposes_model_routing_defaults():
    source = read(APP / "AISettings.swift")
    assert 'defaultModel: "deepseek-v4-flash"' in source
    assert "fastModel" in source
    assert 'deepseek-v4-flash' in source
    assert "escalationModel" in source
    assert 'deepseek-v4-pro' in source
    assert "visionModel" in source
    assert "visionMode" in source
    assert "disableThinkingForFastTurns" in source


def test_ai_client_supports_route_options_usage_and_thinking_control():
    source = read(APP / "AIClient.swift")
    assert "ChatOptions" in source
    assert "ChatResult" in source
    assert "prompt_cache_hit_tokens" in source
    assert "prompt_cache_miss_tokens" in source
    assert "thinking" in source
    assert "reasoning_effort" in source
    assert "extra_body" not in source, "options should encode provider fields at request top level"


def test_page_context_reducer_has_compact_context_limits_and_redaction():
    source = read(APP / "PageContextReducer.swift")
    assert "CompactPageContext" in source
    assert "maxCharacters" in source
    assert "keywords" in source
    assert "inputs" in source
    assert "buttons" in source
    assert "links" in source
    assert "activeElement" in source
    assert "REDACTED" in source


def test_escalation_policy_covers_failure_vision_and_user_takeover():
    source = read(APP / "EscalationPolicy.swift")
    assert "EscalationDecision" in source
    assert "target_not_found" in source
    assert "needsVision" in source
    assert "waitingUser" in source
    assert re.search(r"consecutive.*Failure", source, re.IGNORECASE | re.DOTALL)


def test_local_action_resolver_covers_common_dom_actions():
    source = read(APP / "LocalActionResolver.swift")
    for action in [
        "navigate",
        "click",
        "input",
        "waitForPageReady",
        "waitForText",
        "waitForUrl",
        "sendMessage",
        "teamsSendMessage",
    ]:
        assert action.lower() in source.lower()
    assert "LocalActionResolution" in source


def test_agent_engine_uses_compact_context_local_resolution_and_escalation():
    source = read(APP / "AgentEngine.swift")
    assert "PageContextReducer" in source
    assert "LocalActionResolver" in source
    assert "EscalationPolicy" in source
    assert "compact" in source.lower()
    assert "ChatOptions.fast" in source
    assert "ChatOptions.escalation" in source
    assert "shouldCaptureVision" in source
    assert "Flash" in source
    assert "Pro" in source


if __name__ == "__main__":
    tests = [
        (name, fn)
        for name, fn in sorted(globals().items())
        if name.startswith("test_") and callable(fn)
    ]
    failures = []
    for name, fn in tests:
        try:
            fn()
            print(f"PASS {name}")
        except Exception as exc:
            failures.append((name, exc))
            print(f"FAIL {name}: {exc}")
    if failures:
        raise SystemExit(f"{len(failures)} static test(s) failed")
    print(f"{len(tests)} static tests passed")
