# LiquidAIBrowser v1.4.4 修复报告

## 本版目标

根据用户反馈，v1.4.4 重点补齐：

1. AI 中途询问用户意见/输入信息，并能暂停任务。
2. App 内提醒 + 本地通知提醒用户继续处理。
3. 新增 AI 可调用的计时器插件，支持倒计时与正计时。
4. 计时器等待不占用 AI 请求超时时间。
5. 无论是否开启“发送截图给 AI”，每一步都缓存截图。
6. PDF 报告按步骤展示截图，并修复字体过淡、图片被压扁的问题。
7. 增加 App 图标资源。

## 已实现功能

### 1. AI 询问用户 / 等待用户输入

新增动作：

- `askUser`
- `requestInput`

AI 可以在遇到信息不足、需要用户选择、需要用户提供账号/验证码/偏好时暂停任务，并把任务状态改为“等待用户”。任务卡片会出现输入框，用户提交后任务继续。

### 2. 通知能力

新增 `NotificationService.swift`：

- 首次启动请求本地通知权限。
- AI 等待用户输入时发送本地通知。
- 计时器结束时发送本地通知。
- App 内同时用 `alertMessage` 提示。

### 3. 计时器插件

新增数据模型：

- `AgentTimerEntry`
- `AgentTimerMode`
- `AgentTimerStatus`

新增 AI 动作：

- `startTimer`
- `checkTimer`
- `stopTimer`

倒计时会让任务进入 `timerRunning`，到点后自动继续任务；正计时可以独立运行，用户可以在任务管理页查看。计时使用 App 内部 `Task.sleep` 调度，不占用 AI 网络请求 timeout。

### 4. 步骤截图缓存

新增 `TaskStepSnapshot`。每轮读取页面、执行动作后、最终验收时，都会调用 `captureStepSnapshot` 缓存截图。即使关闭“每一步发送截图给 AI”，截图仍会保留用于 PDF 报告；只有开启该选项时，截图才会作为视觉输入发送给模型。

### 5. PDF 报告升级

`PDFReportExporter.swift` 已重写：

- 文本改为黑色/深色，避免太淡看不清。
- 标题和数据卡片加粗。
- 图片使用等比例 aspect-fit，不再拉伸压扁。
- 每一步截图按顺序插入 PDF。
- 报告结构包含：
  - 用户要求
  - AI 计划 / 最终目标分析
  - 需要实现的目标与完成检查
  - 网页缩略图
  - 按步骤截图记录
  - 结尾总结
  - 详细运行日志

### 6. App 图标

新增 `Assets.xcassets/AppIcon.appiconset`，包含 iPhone、iPad 和 1024 marketing icon 尺寸。Xcode build setting 已设置：

```text
ASSETCATALOG_COMPILER_APPICON_NAME = AppIcon
```

## 已检查

- `Info.plist` 校验通过。
- `NotificationService.swift` 已加入 Xcode Sources。
- `AppIcon.appiconset` 已加入现有 Assets.xcassets。
- `project.pbxproj` 版本号更新至 1.4.4 / build 11。
- PDF 图片绘制逻辑为等比例，不压缩变形。
- 所有新 Swift 文件大括号静态检查通过。

## 仍需真机验证

我这里无法运行 macOS / Xcode 真机编译，所以以下需要用户在 Xcode / IPA Builder 中验证：

1. 本地通知权限弹窗是否正常出现。
2. App 前台/后台通知表现。
3. 计时器结束后任务是否稳定继续。
4. PDF 报告在真机打开后截图是否清晰。
5. App 图标是否正确显示在桌面和 App 切换器。
