# QA V14.17 Package Integrity Report

## Version

- App version: `1.4.17`
- Build number: `24`
- Source package: `LiquidAIBrowser_v1_4_17.zip`

## Reason

The uploaded built artifact `Built-IPA-Newest-19-1.zip` was inspected because it appeared damaged after IPA Builder packaging.

## Findings

- The built output zip is structurally damaged.
- `unzip -t` reports missing end-of-central-directory signature.
- Attempted `zip -FF` salvage, but the contained unsigned `.ipa` stream is incomplete.
- A partial `.ipa` could be decompressed, but it is also missing the zip central directory and the executable stream is incomplete.
- The previous source project zip was retested and did not show zip structure errors.

## Action Taken

- Rebuilt the source package with a new root directory to avoid builder cache confusion.
- Incremented app version and build number.
- Re-tested the new source zip after packaging.

## Verification

Expected command:

```bash
unzip -t LiquidAIBrowser_v1_4_17.zip
```

Expected result:

```text
No errors detected in compressed data
```

## Notes

The damaged `Built-IPA-Newest-19-1.zip` cannot be made into a valid installable IPA because bytes are missing from the end of the archive/stream. A clean rebuild/download from IPA Builder is required.
