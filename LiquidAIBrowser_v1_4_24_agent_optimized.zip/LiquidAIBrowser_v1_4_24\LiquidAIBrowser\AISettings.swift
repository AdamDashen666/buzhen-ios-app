import Foundation
import Combine

final class AISettings: ObservableObject {
    static let keychainService = "LiquidAIBrowser.API"
    static let keychainAccount = "OpenAICompatibleKey"

    static let presets: [APIPreset] = [
        APIPreset(name: "OpenAI", baseURL: "https://api.openai.com/v1", defaultModel: "gpt-4.1-mini"),
        APIPreset(name: "OpenRouter", baseURL: "https://openrouter.ai/api/v1", defaultModel: "openai/gpt-4o-mini"),
        APIPreset(name: "DeepSeek", baseURL: "https://api.deepseek.com/v1", defaultModel: "deepseek-v4-flash"),
        APIPreset(name: "Gemini Compatible", baseURL: "https://generativelanguage.googleapis.com/v1beta/openai", defaultModel: "gemini-2.5-flash"),
        APIPreset(name: "SiliconFlow", baseURL: "https://api.siliconflow.cn/v1", defaultModel: "deepseek-ai/DeepSeek-V3"),
        APIPreset(name: "Moonshot", baseURL: "https://api.moonshot.cn/v1", defaultModel: "moonshot-v1-8k"),
        APIPreset(name: "智谱 GLM", baseURL: "https://open.bigmodel.cn/api/paas/v4", defaultModel: "glm-4-flash"),
        APIPreset(name: "通义千问", baseURL: "https://dashscope.aliyuncs.com/compatible-mode/v1", defaultModel: "qwen-plus"),
        APIPreset(name: "零一万物", baseURL: "https://api.lingyiwanwu.com/v1", defaultModel: "yi-lightning")
    ]

    @Published var providerName: String { didSet { UserDefaults.standard.set(providerName, forKey: "providerName") } }
    @Published var baseURL: String { didSet { UserDefaults.standard.set(baseURL, forKey: "baseURL") } }
    @Published var model: String { didSet { UserDefaults.standard.set(model, forKey: "model") } }
    @Published var fastModel: String { didSet { UserDefaults.standard.set(fastModel, forKey: "fastModel") } }
    @Published var escalationModel: String { didSet { UserDefaults.standard.set(escalationModel, forKey: "escalationModel") } }
    @Published var visionModel: String { didSet { UserDefaults.standard.set(visionModel, forKey: "visionModel") } }
    @Published var temperature: Double { didSet { UserDefaults.standard.set(temperature, forKey: "temperature") } }
    @Published var maxIterations: Int { didSet { UserDefaults.standard.set(maxIterations, forKey: "maxIterations") } }
    @Published var requestTimeout: Double { didSet { UserDefaults.standard.set(requestTimeout, forKey: "requestTimeout") } }
    @Published var useJSONMode: Bool { didSet { UserDefaults.standard.set(useJSONMode, forKey: "useJSONMode") } }
    @Published var enableVisionScreenshots: Bool { didSet { UserDefaults.standard.set(enableVisionScreenshots, forKey: "enableVisionScreenshots") } }
    @Published var visionMode: AgentVisionMode { didSet { UserDefaults.standard.set(visionMode.rawValue, forKey: "visionMode") } }
    @Published var disableThinkingForFastTurns: Bool { didSet { UserDefaults.standard.set(disableThinkingForFastTurns, forKey: "disableThinkingForFastTurns") } }
    @Published var allowCoordinateFallback: Bool { didSet { UserDefaults.standard.set(allowCoordinateFallback, forKey: "allowCoordinateFallback") } }
    @Published var persistSessionHistory: Bool { didSet { UserDefaults.standard.set(persistSessionHistory, forKey: "persistSessionHistory") } }
    @Published var maxActionRetries: Int { didSet { UserDefaults.standard.set(maxActionRetries, forKey: "maxActionRetries") } }
    @Published var availableModels: [String] = []
    @Published var apiKey: String {
        didSet {
            if apiKey.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                KeychainStore.delete(service: Self.keychainService, account: Self.keychainAccount)
            } else {
                KeychainStore.save(apiKey, service: Self.keychainService, account: Self.keychainAccount)
            }
        }
    }

    init() {
        let defaults = UserDefaults.standard
        let firstPreset = Self.presets[0]
        let savedProviderName = defaults.string(forKey: "providerName") ?? firstPreset.name
        let savedBaseURL = defaults.string(forKey: "baseURL") ?? firstPreset.baseURL
        let savedModel = defaults.string(forKey: "model") ?? firstPreset.defaultModel
        let upgradedModel = Self.upgradedLegacyModel(savedModel)
        let defaultFast = Self.defaultFastModel(providerName: savedProviderName, baseURL: savedBaseURL, model: upgradedModel)
        let defaultEscalation = Self.defaultEscalationModel(providerName: savedProviderName, baseURL: savedBaseURL, model: upgradedModel)
        self.providerName = savedProviderName
        self.baseURL = savedBaseURL
        self.model = upgradedModel
        self.fastModel = Self.upgradedLegacyModel(defaults.string(forKey: "fastModel") ?? defaultFast)
        self.escalationModel = Self.upgradedLegacyModel(defaults.string(forKey: "escalationModel") ?? defaultEscalation)
        self.visionModel = Self.upgradedLegacyModel(defaults.string(forKey: "visionModel") ?? defaultEscalation)
        self.temperature = defaults.object(forKey: "temperature") as? Double ?? 0.2
        self.maxIterations = defaults.object(forKey: "maxIterations") as? Int ?? 0
        self.requestTimeout = defaults.object(forKey: "requestTimeout") as? Double ?? 60
        self.useJSONMode = defaults.object(forKey: "useJSONMode") as? Bool ?? true
        self.enableVisionScreenshots = defaults.object(forKey: "enableVisionScreenshots") as? Bool ?? false
        self.visionMode = AgentVisionMode(rawValue: defaults.string(forKey: "visionMode") ?? "") ?? .onFailureOnly
        self.disableThinkingForFastTurns = defaults.object(forKey: "disableThinkingForFastTurns") as? Bool ?? true
        self.allowCoordinateFallback = defaults.object(forKey: "allowCoordinateFallback") as? Bool ?? true
        self.persistSessionHistory = defaults.object(forKey: "persistSessionHistory") as? Bool ?? true
        self.maxActionRetries = defaults.object(forKey: "maxActionRetries") as? Int ?? 3
        self.apiKey = KeychainStore.load(service: Self.keychainService, account: Self.keychainAccount)
    }

    func applyPreset(_ preset: APIPreset) {
        providerName = preset.name
        baseURL = preset.baseURL
        model = Self.upgradedLegacyModel(preset.defaultModel)
        fastModel = Self.defaultFastModel(providerName: preset.name, baseURL: preset.baseURL, model: model)
        escalationModel = Self.defaultEscalationModel(providerName: preset.name, baseURL: preset.baseURL, model: model)
        visionModel = escalationModel
    }

    func snapshot() -> AISettingsSnapshot {
        AISettingsSnapshot(
            apiKey: apiKey,
            baseURL: baseURL,
            model: model,
            fastModel: fastModel,
            escalationModel: escalationModel,
            visionModel: visionModel,
            temperature: temperature,
            requestTimeout: requestTimeout,
            useJSONMode: useJSONMode,
            enableVisionScreenshots: enableVisionScreenshots,
            visionMode: visionMode,
            disableThinkingForFastTurns: disableThinkingForFastTurns,
            allowCoordinateFallback: allowCoordinateFallback,
            maxActionRetries: maxActionRetries
        )
    }

    private static func upgradedLegacyModel(_ model: String) -> String {
        let clean = model.trimmingCharacters(in: .whitespacesAndNewlines)
        if clean == "deepseek-chat" || clean == "deepseek-reasoner" { return "deepseek-v4-flash" }
        return clean.isEmpty ? "deepseek-v4-flash" : clean
    }

    private static func isDeepSeek(providerName: String, baseURL: String, model: String) -> Bool {
        providerName.lowercased().contains("deepseek")
            || baseURL.lowercased().contains("deepseek")
            || model.lowercased().contains("deepseek")
    }

    private static func defaultFastModel(providerName: String, baseURL: String, model: String) -> String {
        isDeepSeek(providerName: providerName, baseURL: baseURL, model: model) ? "deepseek-v4-flash" : model
    }

    private static func defaultEscalationModel(providerName: String, baseURL: String, model: String) -> String {
        isDeepSeek(providerName: providerName, baseURL: baseURL, model: model) ? "deepseek-v4-pro" : model
    }
}
