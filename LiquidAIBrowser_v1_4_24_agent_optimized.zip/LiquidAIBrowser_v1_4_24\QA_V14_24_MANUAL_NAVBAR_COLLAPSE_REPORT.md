# QA V14.24 Manual Navbar Collapse Report

## Version
- App Version: 1.4.24
- Build: 31

## User issue
网页顶部导航栏会自动收起。用户或 AI 在网页输入框中输入时，导航栏自动收起可能导致焦点变化、输入中断或无法继续输入。

## Fix summary
- 顶部网页导航栏默认保持展开。
- 移除自动隐藏计时器，不再在 onAppear、切换标签页、鼠标离开工具栏后自动收起。
- 新增工具栏内手动收起按钮。
- 手动收起后，顶部保留 34pt 热区和“导航栏”提示胶囊。
- 鼠标/指针移动到顶部热区或点击顶部热区时自动展开。

## Files changed
- LiquidAIBrowser/ContentView.swift
- LiquidAIBrowser.xcodeproj/project.pbxproj
- CHANGELOG.md
- PROJECT_INDEX.md
- README.md
- AI_REVIEW_REQUIREMENTS.md

## Verification
- Static source inspection passed.
- Confirmed no remaining delayed auto-hide path in BrowserAreaView.
- Confirmed toolbar can only collapse through explicit onCollapse button.
- Confirmed hover/tap top reveal works only when collapsed.
