# LiquidAIBrowser v1.4.9 修复报告

## 修复目标

本版本针对 Teams 发消息任务卡住、输入焦点误判、最大循环次数、动态重规划和任务列表范围进行修复。

## 1. Teams 发消息任务失败原因

日志显示 Agent 已经找到 Teams 的“键入消息”区域，并且 `click` / `typeText` / `pressEnter` 动作都返回了 `ok:true`，但任务没有完成。根因不是找不到 DOM，而是判断标准错误：

- 旧逻辑把“读取到输入框文本”或“DOM 中出现目标文字”当成输入成功。
- Teams 的消息框是复杂富文本编辑器，直接改 DOM 或合成事件可能不会进入 Teams 内部编辑器状态。
- 点击输入框后能再次读取网页，不等于真正拥有输入焦点。
- `pressEnter` 返回成功，只代表合成键盘事件发出，不代表 Teams 已发送消息。

## 2. 已修复内容

### 2.1 输入焦点验证

新增真实焦点检查：

- 检查 `document.activeElement`。
- 检查 activeElement 是否是目标输入框，或在目标输入框内部。
- 点击/聚焦后若没有真实 focus，动作返回失败，不再假装成功。
- action result 会带回 `activeElement`、`focused`、`inserted`、`frameworkSynced`。

### 2.2 Teams 富文本输入验证

- Teams 页面优先使用 `teamsSendMessage`。
- `typeText` 在 Teams 页面不会再只因 DOM 出现文本就直接判定成功。
- 如果没有确认 Teams 富文本编辑器接收文本，会返回 `type_text_unverified_rich_editor`，让 AI 改用 `teamsSendMessage` 或重新规划。
- `teamsSendMessage` 会先找消息输入框、聚焦、写入、验证，再尝试点击发送按钮或按 Enter。
- 发送后下一轮必须读取页面确认消息是否出现在聊天记录中。

### 2.3 最大循环次数默认无限

- `maxIterations` 默认值改为 `0`。
- UI 显示为“不限制”。
- 只有用户手动设置大于 0 时才会触发最大循环限制。

### 2.4 动态重规划增强

Agent prompt 已强化：

- 每一轮只能执行一个最小动作。
- 每一步后必须重新读取页面并检查结果。
- 不能因为动作返回 ok 就直接认为完成。
- 如果当前步骤未完成、动作不可验证、页面状态与预期不符，AI 必须用 `updatedSteps` 重写当前或后续步骤。
- 必要时可以 `restartPlan=true` 从头重规划。
- 每个点击、输入、按键、滚动、切换页面、检查动作都应拆成独立步骤。

### 2.5 AI 可查看当前分组页面和 URL

每轮决策都会传入当前分组内所有页面：

```text
- tabID=<UUID> [当前显示/后台] title=<标题> url=<当前 URL>
```

AI 可据此决定 `switchTab`、`createTab`、`openTab` 或继续在当前页面操作。

### 2.6 任务列表范围修复

- 分组上方/右侧任务列表：只显示当前分组任务。
- 左侧侧栏“全部任务”：打开独立总览页面，显示所有分组的所有任务。
- 清除已完成/已结束支持当前分组范围和全局范围。

## 3. 已检查

- `swiftc -parse` 通过。
- Agent Bridge JS `node --check` 通过。
- `Info.plist` 版本更新到 `1.4.9 / build 16`。
- Xcode project 版本号同步到 `1.4.9 / build 16`。
- zip 完整性检查通过。

## 4. 仍需真机验证

- Teams 真实发送消息是否成功。
- Teams 登录后富文本编辑器是否接受 `teamsSendMessage`。
- Microsoft 网页端是否继续限制 WKWebView。
- iPadOS 台前调度窗口尺寸表现。
