# LiquidAIBrowser v1.4.14 稳定性与合规修复报告

## 检查来源
根据用户提供的静态检查建议，对 `LiquidAIBrowser_v1_4_13` 进行修复。

## 本版目标
v1.4.14 不新增大功能，重点修复 Requirements 合规缺口和长任务稳定性。

## 已修复项

### 1. 设置页改为独立页面
- 移除设置页 `.sheet(isPresented:)` 弹窗。
- `showingSettingsPage` 现在进入主路由页面 `SettingsPage()`。
- 设置页有返回浏览器按钮，与“全部任务”页面一致。

### 2. 任务完成后自动生成 PDF
- `AgentEngine.complete()` 完成任务后自动调用 `generateReportPDF(taskID:share:false)`。
- 不自动弹分享面板。
- 任务卡上的 PDF 按钮会优先打开已生成报告，没有报告时再生成。
- `AgentTask` 新增 `pdfReportURLString` 保存 PDF 路径。

### 3. 截图改为文件存储，避免 session JSON 暴涨
- `TaskStepSnapshot` 不再把新截图 Data 常驻编码进 session JSON。
- 新增 `SnapshotFileStore`。
- 截图写入：`Application Support/TaskSnapshots/<taskID>/0001.jpg`。
- session 只保存 `imageFileName / width / height / fileSize`。
- PDF 导出时从文件读取截图。
- 清理任务时同步清理对应截图目录。

### 4. collectState 补全页面状态
新增/增强字段：
- `readyState`
- `isLoading`
- `hasFocus`
- `activeElement`
- `focused`
- `selectionInside`
- `disabled`
- `inputButtonSummary`
- 更完整 style：display、visibility、opacity、pointerEvents、position、zIndex、cursor、overflow、color、backgroundColor、fontSize。

### 5. Agent 新增原生动作
新增/修复动作：
- `reload`
- `forward`
- `stopLoading`
- 原生 `wait`
- 原生 `back`

`wait` 不再走 JS 立即返回，而是在原生 Swift 层真正 sleep，对应 `durationMs / durationSeconds / amount`。

### 6. 失败任务折叠后显示失败原因
- 失败任务即使折叠，也会显示 `lastError` 或当前失败动作。

### 7. 增加清除失败/停止任务
新增：
- `clearFailedTasks(groupID:)`
- `clearStoppedTasks(groupID:)`

当前分组任务侧栏和全局任务页都增加了对应按钮。

### 8. 移除 App 内系统弹窗
- 移除主界面 `.alert("提示")`。
- 移除“清空所有分组？”系统 confirmation dialog。
- 改为顶部 toast/banner。
- 设置页不再用 sheet。

说明：分享 PDF 仍使用系统 Share Sheet，因为这是用户主动点击分享/打开报告触发，不属于自动打断任务的弹窗。

### 9. 后台任务不再抢当前 UI
- `switchTask()` 不再修改 `selectedGroupID / selectedTabID`。
- AI 切换工作页面只改变任务的 `task.tabID`。
- `createTabForTask()` 默认 `select:false`。
- 多分组/后台任务执行时不强制把用户当前页面切走。

### 10. 正计时器修正
- `countDown`：设置 endsAt，倒计时结束后恢复任务。
- `countUp`：不再自动 sleep 到结束，不会强行完成；持续运行直到 AI/用户 stopTimer。

### 11. 原始计划与重规划历史
新增：
- `originalPlan`
- `planHistory`
- `rawPlanResponse`

PDF 里会显示：
- AI 原始计划
- 动态重规划历史
- 最终执行清单

### 12. JS / 截图超时保护
- Agent 层对 `collectPageState` 和 `screenshotJPEGData` 增加 8 秒超时包装。
- 防止 WebKit 卡住导致任务 worker 长时间挂住。

### 13. PDF 内容增强
- 增加分组 ID。
- 增加参与页面 ID 列表。
- 增加截图数量和缓存大小统计。
- 增加 AI 原始计划。
- 增加动态重规划历史。
- 截图最大显示高度从 165pt 提升到 360pt，更容易看清。

## 已检查
- `swiftc -parse LiquidAIBrowser/*.swift`：通过。
- `Info.plist`：通过 plutil 校验。
- Xcode project Swift 文件引用：通过。
- 移除主要 `.alert / confirmationDialog / settings sheet`：通过静态检查。
- 版本号：1.4.14 / build 21。

## 仍需真机验证
- Xcode clean build。
- 任务完成后自动生成 PDF 是否不卡 UI。
- 长任务截图文件落盘是否稳定。
- 关闭/清除任务时截图目录是否完全清理。
- 后台任务不抢 UI 的真实体验。
- Stage Manager 窗口化实际表现。
