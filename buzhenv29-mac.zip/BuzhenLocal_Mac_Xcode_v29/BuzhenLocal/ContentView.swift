import SwiftUI
import UniformTypeIdentifiers
import AVFoundation
import CoreImage
import PhotosUI
import CoreTransferable
import UIKit
import Darwin

struct ContentView: View {
    @StateObject private var vm = ProcessorViewModel()

    @State private var showDocumentPicker = false
    @State private var showPhotosPicker = false
    @State private var showBenchmarkSetupScreen = false
    @State private var selectedPhotoItem: PhotosPickerItem?
    @State private var entranceAnimationReady = false

    var body: some View {
        NavigationStack {
            GeometryReader { proxy in
                ZStack {
                    LinearGradient(
                        colors: [
                            Color(.systemGroupedBackground),
                            Color(.secondarySystemGroupedBackground)
                        ],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                    .ignoresSafeArea()

                    if vm.showProcessingScreen {
                        processingOnlyScreen(proxy: proxy)
                    } else if showBenchmarkSetupScreen {
                        benchmarkSetupScreen(proxy: proxy)
                    } else {
                        LiquidGlassRoot(spacing: 18) {
                        ScrollView {
                            VStack(alignment: .leading, spacing: 24) {
                                headerCard

                                if vm.shouldShowProgressPanel {
                                    progressStatusCard
                                }

                                settingsContentLayout(width: proxy.size.width)
                            }
                            .padding(.horizontal, horizontalPadding(for: proxy.size.width))
                            .padding(.top, proxy.size.width < 430 ? 10 : 16)
                            .padding(.bottom, max(18, proxy.safeAreaInsets.bottom + 14))
                            .frame(maxWidth: contentMaxWidth(for: proxy.size.width))
                            .frame(maxWidth: .infinity)
                            .frame(minHeight: proxy.size.height, alignment: .top)
                        }
                        .scrollIndicators(.visible)
                        .onAppear {
                            entranceAnimationReady = false
                            withAnimation(.spring(response: 0.72, dampingFraction: 0.82).delay(0.05)) {
                                entranceAnimationReady = true
                            }
                        }
                        }
                    }
                }
            }
            .navigationTitle(vm.showProcessingScreen ? "处理进度" : "Buzhen Local v29 Mac")
            .navigationBarTitleDisplayMode(.inline)
            .navigationBarBackButtonHidden(vm.showProcessingScreen && vm.isProcessing)
            .toolbar(vm.showProcessingScreen && vm.isProcessing ? .hidden : .visible, for: .navigationBar)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    if vm.isProcessing {
                        StatusBadge(text: vm.progressPercentText, systemImage: "waveform.path.ecg")
                    }
                }
            }
            .sheet(isPresented: $showDocumentPicker) {
                VideoDocumentPicker { urls in
                    vm.handleDocumentPickerImport(urls)
                }
                .ignoresSafeArea()
            }
            .photosPicker(
                isPresented: $showPhotosPicker,
                selection: $selectedPhotoItem,
                matching: .videos,
                photoLibrary: .shared()
            )
            .onChange(of: selectedPhotoItem) { item in
                guard let item else { return }
                Task {
                    await vm.handlePhotoLibraryImport(item)
                    await MainActor.run {
                        selectedPhotoItem = nil
                    }
                }
            }
        }
    }

    private func horizontalPadding(for width: CGFloat) -> CGFloat {
        if width < 390 { return 8 }
        if width < 430 { return 10 }
        if width < 760 { return 12 }
        if width < 1100 { return 18 }
        return 24
    }

    private func contentMaxWidth(for width: CGFloat) -> CGFloat {
        return .infinity
    }

    private func gridColumns(for width: CGFloat) -> [GridItem] {
        let usable = width - horizontalPadding(for: width) * 2

        if usable >= 1180 {
            return Array(repeating: GridItem(.flexible(minimum: 300), spacing: 16, alignment: .top), count: 3)
        }

        if usable >= 720 {
            return Array(repeating: GridItem(.flexible(minimum: 320), spacing: 16, alignment: .top), count: 2)
        }

        return [GridItem(.flexible(minimum: 0), spacing: 16, alignment: .top)]
    }

    @ViewBuilder
    private func entranceCard<Content: View>(index: Int, @ViewBuilder content: () -> Content) -> some View {
        content()
            .modifier(NonlinearEntranceModifier(index: index, isReady: entranceAnimationReady))
    }

    @ViewBuilder
    private func settingsContentLayout(width: CGFloat) -> some View {
        let usableWidth = width - horizontalPadding(for: width) * 2

        if usableWidth >= 820 {
            VStack(alignment: .leading, spacing: 24) {
                HStack(alignment: .top, spacing: 28) {
                    VStack(alignment: .leading, spacing: 24) {
                        entranceCard(index: 0) { importCard }
                        entranceCard(index: 2) { fpsCard }
                        entranceCard(index: 4) { qualityCard }
                        entranceCard(index: 6) { bitrateCard }
                    }
                    .frame(maxWidth: .infinity, alignment: .topLeading)

                    VStack(alignment: .leading, spacing: 24) {
                        entranceCard(index: 1) { videoInfoCard }
                        #if targetEnvironment(macCatalyst)
                        entranceCard(index: 9) { macDesktopPerformanceCard }
                        #endif
                        entranceCard(index: 3) { outputCard }
                        entranceCard(index: 5) { processingCard }
                        entranceCard(index: 7) { cacheCard }
                    }
                    .frame(maxWidth: .infinity, alignment: .topLeading)
                }

                entranceCard(index: 8) { startCard }
                    .frame(maxWidth: .infinity)
            }
        } else {
            VStack(alignment: .leading, spacing: 14) {
                entranceCard(index: 0) { importCard }
                entranceCard(index: 1) { videoInfoCard }
                #if targetEnvironment(macCatalyst)
                entranceCard(index: 9) { macDesktopPerformanceCard }
                #endif
                entranceCard(index: 2) { fpsCard }
                entranceCard(index: 3) { outputCard }
                entranceCard(index: 4) { qualityCard }
                entranceCard(index: 5) { processingCard }
                entranceCard(index: 6) { bitrateCard }
                entranceCard(index: 7) { cacheCard }
                entranceCard(index: 8) { startCard }
            }
        }
    }

    private func benchmarkSetupScreen(proxy: GeometryProxy) -> some View {
        LiquidGlassRoot(spacing: 18) {
            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    VStack(alignment: .leading, spacing: 12) {
                        ViewThatFits(in: .horizontal) {
                            HStack(spacing: 12) {
                                Image(systemName: "speedometer")
                                    .font(.system(size: 36, weight: .semibold))
                                    .symbolRenderingMode(.hierarchical)

                                VStack(alignment: .leading, spacing: 4) {
                                    Text("性能测试")
                                        .font(.title2.bold())
                                    Text("使用内置 sample 视频测试补帧速度、CPU、GPU 估算和内存。")
                                        .font(.subheadline)
                                        .foregroundStyle(.secondary)
                                }

                                Spacer(minLength: 8)

                                Button {
                                    showBenchmarkSetupScreen = false
                                } label: {
                                    Label("返回", systemImage: "chevron.backward")
                                }
                                .buttonStyle(.bordered)
                            }

                            VStack(alignment: .leading, spacing: 10) {
                                HStack(spacing: 10) {
                                    Image(systemName: "speedometer")
                                        .font(.system(size: 32, weight: .semibold))
                                        .symbolRenderingMode(.hierarchical)

                                    Button {
                                        showBenchmarkSetupScreen = false
                                    } label: {
                                        Label("返回", systemImage: "chevron.backward")
                                    }
                                    .buttonStyle(.bordered)
                                }

                                Text("性能测试")
                                    .font(.title2.bold())
                                Text("使用内置 sample 视频测试补帧速度、CPU、GPU 估算和内存。")
                                    .font(.subheadline)
                                    .foregroundStyle(.secondary)
                            }
                        }
                    }
                    .padding(18)
                    .liquidGlassCard(cornerRadius: 24)

                    benchmarkSampleCard
                    benchmarkSettingsLayout(width: proxy.size.width)
                    benchmarkStartCard
                }
                .padding(.horizontal, horizontalPadding(for: proxy.size.width))
                .padding(.top, proxy.size.width < 430 ? 10 : 16)
                .padding(.bottom, max(18, proxy.safeAreaInsets.bottom + 14))
                .frame(maxWidth: .infinity)
                .frame(minHeight: proxy.size.height, alignment: .top)
            }
            .scrollIndicators(.visible)
        }
    }

    @ViewBuilder
    private func benchmarkSettingsLayout(width: CGFloat) -> some View {
        let usableWidth = width - horizontalPadding(for: width) * 2

        if usableWidth >= 820 {
            HStack(alignment: .top, spacing: 28) {
                VStack(alignment: .leading, spacing: 24) {
                    entranceCard(index: 0) { fpsCard }
                    entranceCard(index: 2) { qualityCard }
                    entranceCard(index: 4) { bitrateCard }
                }
                .frame(maxWidth: .infinity, alignment: .topLeading)

                VStack(alignment: .leading, spacing: 24) {
                    entranceCard(index: 1) { outputCard }
                    entranceCard(index: 3) { processingCard }
                    entranceCard(index: 5) { cacheCard }
                    #if targetEnvironment(macCatalyst)
                    entranceCard(index: 6) { macDesktopPerformanceCard }
                    #endif
                }
                .frame(maxWidth: .infinity, alignment: .topLeading)
            }
        } else {
            VStack(alignment: .leading, spacing: 14) {
                entranceCard(index: 0) { fpsCard }
                entranceCard(index: 1) { outputCard }
                entranceCard(index: 2) { qualityCard }
                entranceCard(index: 3) { processingCard }
                entranceCard(index: 4) { bitrateCard }
                entranceCard(index: 5) { cacheCard }
                #if targetEnvironment(macCatalyst)
                entranceCard(index: 6) { macDesktopPerformanceCard }
                #endif
            }
        }
    }

    private func processingOnlyScreen(proxy: GeometryProxy) -> some View {
        LiquidGlassRoot(spacing: 18) {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    VStack(alignment: .leading, spacing: 12) {
                        ViewThatFits(in: .horizontal) {
                            HStack(spacing: 12) {
                                Image(systemName: vm.isProcessing ? "bolt.horizontal.circle" : "checkmark.circle")
                                    .font(.system(size: 36, weight: .semibold))
                                    .symbolRenderingMode(.hierarchical)

                                VStack(alignment: .leading, spacing: 4) {
                                    Text(vm.isProcessing ? "正在补帧" : "补帧完成")
                                        .font(.title2.bold())
                                    Text(vm.isProcessing ? "处理中不可返回，防止任务中断。" : "现在可以返回设置或导出视频。")
                                        .font(.subheadline)
                                        .foregroundStyle(.secondary)
                                }

                                Spacer(minLength: 8)

                                StatusBadge(text: vm.progressPercentText, systemImage: "waveform.path.ecg")
                            }

                            VStack(alignment: .leading, spacing: 10) {
                                HStack(spacing: 10) {
                                    Image(systemName: vm.isProcessing ? "bolt.horizontal.circle" : "checkmark.circle")
                                        .font(.system(size: 32, weight: .semibold))
                                        .symbolRenderingMode(.hierarchical)

                                    StatusBadge(text: vm.progressPercentText, systemImage: "waveform.path.ecg")
                                }

                                Text(vm.isProcessing ? "正在补帧" : "补帧完成")
                                    .font(.title2.bold())
                                Text(vm.isProcessing ? "处理中不可返回，防止任务中断。" : "现在可以返回设置或导出视频。")
                                    .font(.subheadline)
                                    .foregroundStyle(.secondary)
                            }
                        }

                        ProcessingProgressRing(
                            value: vm.progress,
                            percentText: vm.progressPercentText,
                            isComplete: !vm.isProcessing && vm.outputURL != nil && vm.errorMessage == nil
                        )
                        .frame(maxWidth: .infinity)

                        LiquidGlassProgressBar(title: "总进度", value: vm.progress, detail: vm.progressPercentText)

                        Text(vm.status)
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                            .textSelection(.enabled)
                    }
                    .padding(18)
                    .liquidGlassCard(cornerRadius: 24)

                    progressStatusCard
                    performanceCard

                    if !vm.isProcessing {
                        completionActionCard
                    }
                }
                .padding(.horizontal, horizontalPadding(for: proxy.size.width))
                .padding(.top, max(16, proxy.safeAreaInsets.top + 10))
                .padding(.bottom, max(28, proxy.safeAreaInsets.bottom + 18))
                .frame(maxWidth: .infinity)
                .frame(minHeight: proxy.size.height, alignment: .top)
            }
            .scrollIndicators(.visible)
        }
    }

    private var completionActionCard: some View {
        Card("完成操作", systemImage: "square.and.arrow.up") {
            VStack(alignment: .leading, spacing: 12) {
                if let error = vm.errorMessage {
                    Text(error)
                        .font(.footnote)
                        .foregroundStyle(.red)
                        .textSelection(.enabled)

                    Button {
                        vm.copyFullErrorLogToClipboard()
                    } label: {
                        Label("复制完整错误日志", systemImage: "doc.on.doc")
                            .frame(maxWidth: .infinity)
                    }
                    .liquidGlassButtonStyle(prominent: false)
                } else if vm.outputURL != nil {
                    SuccessPulseView()
                        .frame(maxWidth: .infinity)
                }

                if let copyMessage = vm.copyStatusMessage {
                    Text(copyMessage)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                if let outputURL = vm.outputURL {
                    Text(outputURL.lastPathComponent)
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                        .lineLimit(2)
                        .textSelection(.enabled)

                    ShareLink(item: outputURL) {
                        Label("导出 / 保存视频", systemImage: "square.and.arrow.up")
                            .frame(maxWidth: .infinity)
                    }
                    .liquidGlassButtonStyle(prominent: true)
                }

                if let logURL = vm.performanceLogURL {
                    ShareLink(item: logURL) {
                        Label("下载 / 导出性能日志 CSV", systemImage: "doc.text")
                            .frame(maxWidth: .infinity)
                    }
                    .liquidGlassButtonStyle(prominent: false)

                    Text("日志包含 CPU、GPU 估算、内存、frame/s、温度、进度、分段状态。")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                Button {
                    vm.cleanupExportCaches()
                } label: {
                    Label("导出后清理缓存/临时文件", systemImage: "trash")
                        .frame(maxWidth: .infinity)
                }
                .liquidGlassButtonStyle(prominent: false)

                if let cleanupMessage = vm.cacheCleanupMessage {
                    Text(cleanupMessage)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                Button {
                    vm.leaveProcessingScreen()
                } label: {
                    Label("返回设置页面", systemImage: "chevron.backward")
                        .frame(maxWidth: .infinity)
                }
                .liquidGlassButtonStyle(prominent: false)
            }
        }
    }

    #if targetEnvironment(macCatalyst)
    private var macDesktopPerformanceCard: some View {
        Card("Mac 性能监控", systemImage: "desktopcomputer.and.macbook") {
            VStack(alignment: .leading, spacing: 10) {
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 150), spacing: 10, alignment: .top)], alignment: .leading, spacing: 10) {
                    MetricTile(title: "CPU 核心", value: vm.cpuCoreText, systemImage: "cpu")
                    MetricTile(title: "系统内存", value: vm.totalSystemMemoryText, systemImage: "memorychip")
                    MetricTile(title: "采样来源", value: vm.performanceSourceText, systemImage: "waveform.path.ecg")
                    MetricTile(title: "平台", value: vm.platformText, systemImage: "laptopcomputer")
                }

                InfoRow("Mac 性能说明", "CPU / 内存为 App 级实时采样；GPU 为 Metal/处理强度估算。")
                InfoRow("适合场景", "长视频、并行分段、终极 AI 混合光流。")
            }
        }
    }
    #endif

    private var performanceCard: some View {
        Card("实时性能", systemImage: "cpu") {
            VStack(alignment: .leading, spacing: 10) {
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 128), spacing: 8, alignment: .top)], alignment: .leading, spacing: 10) {
                    MetricTile(title: "CPU", value: vm.cpuUsageText, systemImage: "cpu")
                    MetricTile(title: "GPU", value: vm.gpuEstimateText, systemImage: "memorychip")
                    MetricTile(title: "内存", value: vm.memoryUsageText, systemImage: "externaldrive")
                    MetricTile(title: "温度", value: vm.thermalStateText, systemImage: "thermometer.medium")
                    MetricTile(title: "补帧速度", value: vm.processingSpeedText, systemImage: "speedometer")
                    MetricTile(title: "预计剩余", value: vm.estimatedRemainingText, systemImage: "timer")
                }

                InfoRow("已运行", vm.elapsedTimeText)
                InfoRow("并行/活动任务", vm.liveWorkerText)
                InfoRow("平均速度", vm.averageSpeedText)
                InfoRow("峰值速度", vm.peakSpeedText)
                InfoRow("最低速度", vm.lowestSpeedText)
                InfoRow("日志采样", "\(vm.performanceLogSampleCount) 条")

                if !vm.isProcessing, let logURL = vm.performanceLogURL {
                    ShareLink(item: logURL) {
                        Label("导出性能日志", systemImage: "square.and.arrow.up.on.square")
                            .frame(maxWidth: .infinity)
                    }
                    .liquidGlassButtonStyle(prominent: false)
                }

                Text("GPU 为本 App Metal/光流任务的估算负载；iPadOS 不开放整机 GPU 百分比。")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
    }

    private var headerCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            ViewThatFits(in: .horizontal) {
                HStack(spacing: 12) {
                    Image(systemName: "sparkles.tv")
                        .font(.system(size: 32, weight: .semibold))
                        .symbolRenderingMode(.hierarchical)

                    VStack(alignment: .leading, spacing: 3) {
                        Text("Buzhen Local v29 Mac")
                            .font(.title2.bold())
                        Text("iPhone / Mac 本地补帧 · 性能测试 · DMG")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                    }

                    Spacer(minLength: 8)

                    StatusBadge(text: vm.inputURL == nil ? "未导入" : "已导入", systemImage: vm.inputURL == nil ? "tray" : "checkmark.circle")
                }

                VStack(alignment: .leading, spacing: 10) {
                    HStack(spacing: 10) {
                        Image(systemName: "sparkles.tv")
                            .font(.system(size: 30, weight: .semibold))
                            .symbolRenderingMode(.hierarchical)

                        StatusBadge(text: vm.inputURL == nil ? "未导入" : "已导入", systemImage: vm.inputURL == nil ? "tray" : "checkmark.circle")
                    }

                    Text("Buzhen Local v29 Mac")
                        .font(.title2.bold())
                    Text("iPhone / Mac 本地补帧 · 性能测试 · DMG")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
            }

            if vm.isProcessing {
                LiquidGlassProgressBar(title: "总进度", value: vm.progress, detail: vm.progressPercentText)
                Text(vm.status)
                    .font(.footnote)
                    .foregroundStyle(.secondary)
                    .lineLimit(2)
            }
        }
        .padding(18)
        .liquidGlassCard(cornerRadius: 24)
    }

    private var progressStatusCard: some View {
        Card("处理进度", systemImage: "chart.line.uptrend.xyaxis") {
            VStack(alignment: .leading, spacing: 14) {
                LiquidGlassProgressBar(title: "总进度", value: vm.progress, detail: vm.progressPercentText)

                HStack(spacing: 8) {
                    StatusBadge(text: vm.processingMode.title, systemImage: "square.stack.3d.up")
                    StatusBadge(text: vm.workerSummaryText, systemImage: "person.2.wave.2")
                    StatusBadge(text: vm.segmentSummaryText, systemImage: "scissors")
                }

                VStack(alignment: .leading, spacing: 8) {
                    InfoRow("当前阶段", vm.status)
                    if let stage = vm.currentStageText {
                        InfoRow("阶段状态", stage)
                    }
                }

                if !vm.segmentRows.isEmpty {
                    Divider()

                    HStack {
                        Text("分段任务")
                            .font(.subheadline.weight(.semibold))
                        Spacer()
                        Text("\(vm.completedSegmentCount)/\(vm.segmentRows.count) 完成")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }

                    ScrollView {
                        LazyVStack(spacing: 10) {
                            ForEach(vm.segmentRows) { row in
                                SegmentProgressRowView(row: row)
                            }
                        }
                        .padding(.vertical, 2)
                    }
                    .frame(maxHeight: vm.segmentRows.count > 6 ? 330 : nil)
                }
            }
        }
    }

    private var benchmarkSampleCard: some View {
        Card("Sample 视频", systemImage: "testtube.2") {
            VStack(alignment: .leading, spacing: 12) {
                Picker("清晰度", selection: $vm.benchmarkResolution) {
                    ForEach(BenchmarkResolution.allCases) { resolution in
                        Text(resolution.title).tag(resolution)
                    }
                }
                .pickerStyle(.segmented)
                .disabled(vm.isProcessing)

                Picker("原始帧率", selection: $vm.benchmarkSourceFPS) {
                    ForEach(BenchmarkSourceFPS.allCases) { fps in
                        Text(fps.title).tag(fps)
                    }
                }
                .pickerStyle(.segmented)
                .disabled(vm.isProcessing)

                InfoRow("样片参数", vm.benchmarkSampleSummaryText)
                InfoRow("测试时长", vm.benchmarkDurationText)

                Text("点击开始后会自动生成内置 sample 视频，再进入与普通补帧相同的处理界面。")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
    }

    private var benchmarkStartCard: some View {
        Card("开始性能测试", systemImage: "speedometer") {
            VStack(alignment: .leading, spacing: 14) {
                Button {
                    Task { await vm.startBenchmark() }
                } label: {
                    Label(vm.isProcessing ? "测试中..." : "生成样片并开始测试", systemImage: "play.fill")
                        .frame(maxWidth: .infinity)
                }
                .liquidGlassButtonStyle(prominent: true)
                .disabled(vm.isProcessing)

                if let error = vm.errorMessage {
                    Text(error)
                        .font(.footnote)
                        .foregroundStyle(.red)
                        .textSelection(.enabled)
                }

                Text("测试会记录 frame/s、平均/峰值/最低速度、CPU、GPU 估算、内存和温度。")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
    }

    private var importCard: some View {
        Card("导入视频", systemImage: "square.and.arrow.down") {
            VStack(spacing: 12) {
                Button {
                    showPhotosPicker = true
                } label: {
                    Label("从相册选择视频", systemImage: "photo.on.rectangle")
                        .frame(maxWidth: .infinity)
                }
                .liquidGlassButtonStyle(prominent: true)
                .disabled(vm.isProcessing)

                Button {
                    showDocumentPicker = true
                } label: {
                    Label("从文件选择视频", systemImage: "folder")
                        .frame(maxWidth: .infinity)
                }
                .liquidGlassButtonStyle(prominent: false)
                .disabled(vm.isProcessing)

                Button {
                    showBenchmarkSetupScreen = true
                } label: {
                    Label("性能测试", systemImage: "speedometer")
                        .frame(maxWidth: .infinity)
                }
                .liquidGlassButtonStyle(prominent: false)
                .disabled(vm.isProcessing)

                if let inputURL = vm.inputURL {
                    Divider()

                    VStack(alignment: .leading, spacing: 6) {
                        Text("当前视频")
                            .font(.caption)
                            .foregroundStyle(.secondary)

                        Text(inputURL.lastPathComponent)
                            .font(.footnote.weight(.medium))
                            .lineLimit(2)
                            .textSelection(.enabled)
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)

                    Button(role: .destructive) {
                        vm.clearImportedVideo()
                    } label: {
                        Label("清除视频", systemImage: "trash")
                            .frame(maxWidth: .infinity)
                    }
                    .liquidGlassButtonStyle(prominent: false)
                    .disabled(vm.isProcessing)
                }

                Text("v29 Mac：独立 Mac DMG 版，保留性能测试与桌面性能监控。")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
        }
    }

    private var videoInfoCard: some View {
        Card("视频信息", systemImage: "info.circle") {
            if let info = vm.videoInfo {
                VStack(alignment: .leading, spacing: 10) {
                    InfoRow("分辨率", "\(info.width) × \(info.height)")
                    InfoRow("帧率", String(format: "%.3f fps", info.fps))
                    InfoRow("时长", info.durationText)
                    InfoRow("编码", info.codec)
                    InfoRow("HDR", info.hdrName)
                    InfoRow("音频", info.hasAudio ? "有" : "无")
                    InfoRow("估算码率", info.bitrateText)
                }
            } else {
                EmptyState(text: "导入视频后显示参数。", systemImage: "film")
            }
        }
    }

    private var fpsCard: some View {
        Card("目标帧率", systemImage: "speedometer") {
            VStack(alignment: .leading, spacing: 12) {
                Picker("目标帧率", selection: $vm.targetFPS) {
                    Text("60").tag(60.0)
                    Text("90").tag(90.0)
                    Text("120").tag(120.0)
                    Text("240").tag(240.0)
                }
                .pickerStyle(.segmented)
                .disabled(vm.isProcessing)

                Stepper(value: $vm.targetFPS, in: 24...240, step: 1) {
                    Text("自定义：\(Int(vm.targetFPS)) fps")
                }
                .disabled(vm.isProcessing)

                PreciseDoubleInput(
                    title: "精确帧率",
                    value: $vm.targetFPS,
                    range: 24...240,
                    unit: "fps",
                    fractionDigits: 3
                )
                .disabled(vm.isProcessing)

                Text("导入后会自动按原帧率推荐目标帧率，也可以手动输入精确数字。")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
    }

    private var outputCard: some View {
        Card("输出 / HDR", systemImage: "rectangle.on.rectangle") {
            VStack(alignment: .leading, spacing: 12) {
                Picker("输出模式", selection: $vm.outputMode) {
                    ForEach(OutputMode.allCases) { mode in
                        Text(mode.title).tag(mode)
                    }
                }
                .pickerStyle(.menu)
                .disabled(vm.isProcessing)

                Toggle("复制原音频", isOn: $vm.keepAudio)
                    .disabled(vm.isProcessing)

                Toggle("复制元数据/章节", isOn: $vm.keepMetadata)
                    .disabled(vm.isProcessing)

                Toggle("尝试保留 HDR 色彩标签", isOn: $vm.preserveHDRTags)
                    .disabled(vm.outputMode != .hdrPreserve || vm.isProcessing)

                Text("HDR 模式会写入 BT.2020/PQ/HLG 相关输出标签；完整杜比视界元数据不保证。")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
    }

    private var qualityCard: some View {
        Card("光流质量", systemImage: "point.3.connected.trianglepath.dotted") {
            VStack(alignment: .leading, spacing: 12) {
                Picker("光流质量", selection: $vm.quality) {
                    ForEach(OpticalFlowQuality.allCases) { q in
                        Text(q.title).tag(q)
                    }
                }
                .pickerStyle(.menu)
                .disabled(vm.isProcessing)

                Text(vm.quality.subtitle)
                    .font(.footnote)
                    .foregroundStyle(.secondary)

                VStack(alignment: .leading, spacing: 6) {
                    QualityLine(index: "1", title: "快速", detail: "速度优先")
                    QualityLine(index: "2", title: "极限光流", detail: "画质优先")
                    QualityLine(index: "3", title: "终极 AI 混合", detail: "绝对质量，最慢")
                }
            }
        }
    }

    private var processingCard: some View {
        Card("处理模式", systemImage: "square.stack.3d.up") {
            VStack(alignment: .leading, spacing: 12) {
                Picker("处理模式", selection: $vm.processingMode) {
                    ForEach(ProcessingMode.allCases) { mode in
                        Text(mode.title).tag(mode)
                    }
                }
                .pickerStyle(.menu)
                .disabled(vm.isProcessing)

                Text(vm.processingMode.subtitle)
                    .font(.footnote)
                    .foregroundStyle(.secondary)

                if vm.processingMode != .full {
                    Stepper(value: $vm.segmentSeconds, in: 1...120, step: 1) {
                        Text("每段：\(Int(vm.segmentSeconds)) 秒")
                    }
                    .disabled(vm.isProcessing)

                    PreciseDoubleInput(
                        title: "分段秒数",
                        value: $vm.segmentSeconds,
                        range: 1...120,
                        unit: "秒",
                        fractionDigits: 2
                    )
                    .disabled(vm.isProcessing)

                    if let count = vm.estimatedSegmentCount {
                        StatusBadge(text: "预计 \(count) 段", systemImage: "scissors")
                    }
                }

                if vm.processingMode == .parallelSegmented {
                    Stepper(value: $vm.maxParallelJobs, in: 1...8, step: 1) {
                        Text("并行任务：\(vm.maxParallelJobs)")
                    }
                    .disabled(vm.isProcessing)

                    PreciseIntInput(
                        title: "并行任务数",
                        value: $vm.maxParallelJobs,
                        range: 1...8,
                        unit: "个"
                    )
                    .disabled(vm.isProcessing)

                    Text("进度面板会显示每段状态、并行任务数、已完成段数。")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
        }
    }

    private var bitrateCard: some View {
        Card("码率", systemImage: "slider.horizontal.3") {
            VStack(alignment: .leading, spacing: 12) {
                Picker("码率", selection: $vm.bitrateMode) {
                    ForEach(BitrateMode.allCases) { mode in
                        Text(mode.title).tag(mode)
                    }
                }
                .pickerStyle(.segmented)
                .disabled(vm.isProcessing)

                if let mbps = vm.recommendedBitrateMbps {
                    InfoRow("推荐", String(format: "%.1f Mbps / %.0f Kbps", mbps, mbps * 1000))
                }

                if vm.bitrateMode == .customMbps {
                    Stepper(value: $vm.customBitrateMbps, in: 1...1000, step: 1) {
                        Text("手动：\(Int(vm.customBitrateMbps)) Mbps")
                    }
                    .disabled(vm.isProcessing)

                    PreciseDoubleInput(
                        title: "精确码率",
                        value: $vm.customBitrateMbps,
                        range: 1...1000,
                        unit: "Mbps",
                        fractionDigits: 3
                    )
                    .disabled(vm.isProcessing)

                    InfoRow("等于", String(format: "%.0f Kbps", vm.customBitrateMbps * 1000))
                }
            }
        }
    }

    private var cacheCard: some View {
        Card("缓存管理", systemImage: "externaldrive.badge.xmark") {
            VStack(alignment: .leading, spacing: 12) {
                InfoRow("当前缓存", vm.cacheFootprintText)
                InfoRow("清理范围", "导入副本 / 输出副本 / 日志 / 临时分段")

                Button {
                    vm.cleanupExportCaches()
                } label: {
                    Label("一键清理全部缓存", systemImage: "trash")
                        .frame(maxWidth: .infinity)
                }
                .liquidGlassButtonStyle(prominent: false)
                .disabled(vm.isProcessing)

                if let cleanupMessage = vm.cacheCleanupMessage {
                    Text(cleanupMessage)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                Text("清理会删除 App 沙盒里的中间文件；已保存到相册/文件 App 的导出文件不会受影响。")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
    }

    private var startCard: some View {
        Card("开始处理", systemImage: "wand.and.stars") {
            VStack(alignment: .leading, spacing: 14) {
                Button {
                    Task { await vm.start() }
                } label: {
                    Label(vm.isProcessing ? "处理中..." : "开始补帧", systemImage: "play.fill")
                        .frame(maxWidth: .infinity)
                }
                .liquidGlassButtonStyle(prominent: true)
                .disabled(vm.inputURL == nil || vm.isProcessing)

                if let error = vm.errorMessage {
                    Text(error)
                        .font(.footnote)
                        .foregroundStyle(.red)
                        .textSelection(.enabled)
                }

                if let outputURL = vm.outputURL {
                    Divider()

                    VStack(alignment: .leading, spacing: 8) {
                        Text("输出完成")
                            .font(.headline)

                        Text(outputURL.lastPathComponent)
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                            .lineLimit(2)
                            .textSelection(.enabled)

                        ShareLink(item: outputURL) {
                            Label("分享 / 保存视频", systemImage: "square.and.arrow.up")
                                .frame(maxWidth: .infinity)
                        }
                        .liquidGlassButtonStyle(prominent: true)
                    }
                }

                if vm.inputURL == nil {
                    EmptyState(text: "先从相册或文件导入视频。", systemImage: "arrow.up.doc")
                }
            }
        }
    }
}

@MainActor
final class ProcessorViewModel: ObservableObject {
    @Published var inputURL: URL?
    @Published var outputURL: URL?
    @Published var videoInfo: VideoInfo?

    @Published var targetFPS: Double = 120
    @Published var quality: OpticalFlowQuality = .extreme
    @Published var processingMode: ProcessingMode = .serialSegmented
    @Published var segmentSeconds: Double = 3
    @Published var maxParallelJobs: Int = 2

    @Published var outputMode: OutputMode = .appleHEVC
    @Published var bitrateMode: BitrateMode = .automatic
    @Published var customBitrateMbps: Double = 80

    @Published var keepAudio = true
    @Published var keepMetadata = true
    @Published var preserveHDRTags = true

    @Published var benchmarkResolution: BenchmarkResolution = .p1080
    @Published var benchmarkSourceFPS: BenchmarkSourceFPS = .fps60
    @Published var isBenchmarkMode = false

    @Published var progress: Double = 0
    @Published var status: String = "等待开始"
    @Published var currentStageText: String?
    @Published var errorMessage: String?
    @Published var isProcessing: Bool = false
    @Published var showProcessingScreen: Bool = false
    @Published var segmentRows: [TaskProgressRow] = []
    @Published var workerCount: Int = 0
    @Published var progressModeText: String = "未开始"

    @Published var cpuUsagePercent: Double = 0
    @Published var memoryUsageMB: Double = 0
    @Published var gpuEstimatePercent: Double = 0
    @Published var processingFPS: Double = 0
    @Published var elapsedTimeText: String = "00:00"
    @Published var estimatedRemainingText: String = "--"
    @Published var thermalStateText: String = "正常"
    @Published var performanceLogURL: URL?
    @Published var performanceLogSampleCount: Int = 0
    @Published var averageProcessingFPS: Double = 0
    @Published var peakProcessingFPS: Double = 0
    @Published var lowestProcessingFPS: Double = 0
    @Published var cacheCleanupMessage: String?
    @Published var cacheFootprintText: String = "--"
    @Published var copyStatusMessage: String?
    @Published var cpuCoreText: String = Self.cpuCoreDescription()
    @Published var totalSystemMemoryText: String = Self.totalSystemMemoryDescription()
    @Published var performanceSourceText: String = Self.performanceSourceDescription()
    @Published var platformText: String = Self.platformDescription()

    private var performanceTimer: Timer?
    private var processingStartDate: Date?
    private var fpsStatsSampleCount: Int = 0

    var cpuUsageText: String {
        String(format: "%.0f%%", cpuUsagePercent)
    }

    var memoryUsageText: String {
        String(format: "%.0f MB", memoryUsageMB)
    }

    var gpuEstimateText: String {
        String(format: "%.0f%% 估算", gpuEstimatePercent)
    }

    var processingSpeedText: String {
        processingFPS > 0 ? String(format: "%.1f frame/s", processingFPS) : "--"
    }

    var averageSpeedText: String {
        averageProcessingFPS > 0 ? String(format: "%.1f frame/s", averageProcessingFPS) : "--"
    }

    var peakSpeedText: String {
        peakProcessingFPS > 0 ? String(format: "%.1f frame/s", peakProcessingFPS) : "--"
    }

    var lowestSpeedText: String {
        lowestProcessingFPS > 0 ? String(format: "%.1f frame/s", lowestProcessingFPS) : "--"
    }

    var benchmarkSampleSummaryText: String {
        "\(benchmarkResolution.title) · \(benchmarkSourceFPS.title) · 内置 sample"
    }

    var benchmarkDurationText: String {
        String(format: "%.1f 秒", BenchmarkSampleVideoGenerator.durationSeconds)
    }

    var liveWorkerText: String {
        if processingMode == .parallelSegmented {
            return "活动 \(activeSegmentCount) / 并行 \(maxParallelJobs)"
        }
        return "活动 \(activeSegmentCount) / 任务 \(max(workerCount, 1))"
    }

    var shouldShowProgressPanel: Bool {
        isProcessing || !segmentRows.isEmpty || progress > 0
    }

    var completedSegmentCount: Int {
        segmentRows.filter { $0.state == .done }.count
    }

    var activeSegmentCount: Int {
        segmentRows.filter { $0.state == .running }.count
    }

    var segmentSummaryText: String {
        guard !segmentRows.isEmpty else { return "无分段" }
        return "\(completedSegmentCount)/\(segmentRows.count)"
    }

    var workerSummaryText: String {
        if workerCount <= 0 { return "未启动" }
        if processingMode == .parallelSegmented {
            return "并行 \(workerCount)"
        }
        return "任务 \(workerCount)"
    }

    var progressPercentText: String {
        "\(Int((min(max(progress, 0), 1) * 100).rounded()))%"
    }

    var estimatedSegmentCount: Int? {
        guard let duration = videoInfo?.duration, processingMode != .full else { return nil }
        return max(1, Int(ceil(duration / max(1, segmentSeconds))))
    }

    var recommendedBitrateMbps: Double? {
        guard let info = videoInfo else { return nil }

        let pixelsPerSecond = Double(info.width * info.height) * targetFPS
        let baseBppf: Double

        switch outputMode {
        case .h264Compatible:
            baseBppf = 0.13
        case .appleHEVC:
            baseBppf = 0.15
        case .hdrPreserve:
            baseBppf = 0.17
        }

        let raw = pixelsPerSecond * baseBppf * quality.bitrateMultiplier
        let floor: Double = outputMode == .hdrPreserve ? 70_000_000 : 45_000_000
        let cap: Double = outputMode == .hdrPreserve ? 380_000_000 : 300_000_000

        return min(max(raw, floor), cap) / 1_000_000
    }

    func handleDocumentPickerImport(_ urls: [URL]) {
        guard !isProcessing else { return }

        errorMessage = nil
        outputURL = nil
        videoInfo = nil
        cacheCleanupMessage = nil
        copyStatusMessage = nil
        resetProgressUI()

        refreshCacheFootprint()

        guard let picked = urls.first else {
            status = "未选择视频"
            return
        }

        status = "正在从文件导入视频..."

        Task {
            do {
                let copied = try await Task.detached(priority: .userInitiated) {
                    try ImportStore.copyIntoAppSandbox(from: picked, preferredExtension: picked.pathExtension)
                }.value

                await loadImportedVideo(copied, sourceName: "文件")
            } catch {
                await MainActor.run {
                    self.errorMessage = "文件导入失败：\(error.localizedDescription)"
                    self.status = "导入失败"
                }
            }
        }
    }

    func handlePhotoLibraryImport(_ item: PhotosPickerItem) async {
        guard !isProcessing else { return }

        errorMessage = nil
        outputURL = nil
        videoInfo = nil
        cacheCleanupMessage = nil
        copyStatusMessage = nil
        resetProgressUI()
        status = "正在从相册导入视频..."
        refreshCacheFootprint()

        do {
            guard let picked = try await item.loadTransferable(type: PickedVideo.self) else {
                throw NSError(domain: "BuzhenLocal", code: 1101, userInfo: [
                    NSLocalizedDescriptionKey: "相册没有返回可用的视频文件。"
                ])
            }

            await loadImportedVideo(picked.url, sourceName: "相册")
        } catch {
            errorMessage = "相册导入失败：\(error.localizedDescription)"
            status = "导入失败"
        }
    }

    func clearImportedVideo() {
        inputURL = nil
        outputURL = nil
        videoInfo = nil
        cacheCleanupMessage = nil
        copyStatusMessage = nil
        resetProgressUI()
        status = "等待开始"
        errorMessage = nil
        isBenchmarkMode = false
        refreshCacheFootprint()
    }

    private func loadImportedVideo(_ url: URL, sourceName: String) async {
        inputURL = url
        outputURL = nil
        videoInfo = nil
        resetProgressUI()
        cacheCleanupMessage = nil
        copyStatusMessage = nil
        errorMessage = nil
        status = "正在读取视频信息..."

        do {
            let info = try await VideoInspector.inspect(url: url)
            videoInfo = info
            targetFPS = max(60, min(240, ceil(info.fps * 2)))
            outputMode = info.isHDRLike ? .hdrPreserve : .appleHEVC
            status = "\(sourceName)视频已导入"
            refreshCacheFootprint()
        } catch {
            errorMessage = "读取视频信息失败：\(error.localizedDescription)"
            status = "读取失败"
        }
    }

    func startBenchmark() async {
        guard !isProcessing else { return }

        isBenchmarkMode = true
        errorMessage = nil
        outputURL = nil
        videoInfo = nil
        cacheCleanupMessage = nil
        copyStatusMessage = nil
        resetProgressUI()
        resetPerformanceUI()
        status = "正在生成性能测试样片..."
        currentStageText = "生成 sample 视频"

        do {
            let resolution = benchmarkResolution
            let fps = benchmarkSourceFPS
            let sampleURL = try await Task.detached(priority: .userInitiated) {
                try BenchmarkSampleVideoGenerator.generate(resolution: resolution, fps: fps)
            }.value

            await loadImportedVideo(sampleURL, sourceName: "性能测试样片")
            keepAudio = false
            keepMetadata = false
            preserveHDRTags = false
            await start()
        } catch {
            errorMessage = "性能测试样片生成失败：\(error.localizedDescription)"
            status = "性能测试失败"
            currentStageText = "样片生成失败"
            isProcessing = false
        }
    }

    func start() async {
        guard let inputURL else { return }

        showProcessingScreen = true
        isProcessing = true
        cacheCleanupMessage = nil
        copyStatusMessage = nil
        cleanupResidualTemporaryFiles()
        refreshCacheFootprint()
        resetProgressUI()
        resetPerformanceUI()
        errorMessage = nil
        outputURL = nil
        status = "准备处理..."
        currentStageText = "初始化"
        progressModeText = processingMode.title
        startPerformanceMonitoring()

        let options = ProcessingOptions(
            targetFPS: targetFPS,
            quality: quality,
            processingMode: processingMode,
            segmentSeconds: segmentSeconds,
            maxParallelJobs: maxParallelJobs,
            outputMode: outputMode,
            bitrateMode: bitrateMode,
            customBitrateMbps: customBitrateMbps,
            keepAudio: keepAudio,
            keepMetadata: keepMetadata,
            preserveHDRTags: preserveHDRTags && outputMode == .hdrPreserve,
            enableSceneChangeDetection: true,
            enableDuplicateFrameDetection: true,
            enableMotionSafety: true
        )

        do {
            let processor = VideoFrameInterpolator()

            let result = try await processor.interpolate(
                inputURL: inputURL,
                options: options
            ) { [weak self] p, s in
                Task { @MainActor in
                    self?.applyProcessorProgress(p, s)
                }
            }

            outputURL = result
            status = "完成"
            currentStageText = "全部完成"
            progress = 1
            markAllSegmentsDone()
        } catch {
            errorMessage = "处理失败：\(error.localizedDescription)"
            status = "失败"
            currentStageText = "处理失败"
        }

        refreshPerformanceMetrics(final: true)
        stopPerformanceMonitoring()
        isProcessing = false
        refreshCacheFootprint()
    }

    func copyFullErrorLogToClipboard() {
        UIPasteboard.general.string = fullErrorLogText()
        copyStatusMessage = "完整错误日志已复制。"
    }

    private func fullErrorLogText() -> String {
        var lines: [String] = []
        lines.append("Buzhen Local Error Log")
        lines.append("time: \(ISO8601DateFormatter().string(from: Date()))")
        lines.append("status: \(status)")
        lines.append("stage: \(currentStageText ?? "-")")
        lines.append("progress: \(progressPercentText)")
        lines.append("error: \(errorMessage ?? "-")")
        lines.append("input: \(inputURL?.lastPathComponent ?? "-")")
        lines.append("output: \(outputURL?.lastPathComponent ?? "-")")
        lines.append("log: \(performanceLogURL?.lastPathComponent ?? "-")")
        lines.append("target_fps: \(String(format: "%.3f", targetFPS))")
        lines.append("quality: \(quality.title)")
        lines.append("processing_mode: \(processingMode.title)")
        lines.append("segment_seconds: \(String(format: "%.2f", segmentSeconds))")
        lines.append("parallel_jobs: \(maxParallelJobs)")
        lines.append("output_mode: \(outputMode.title)")
        lines.append("bitrate_mode: \(bitrateMode.title)")
        lines.append("custom_bitrate_mbps: \(String(format: "%.3f", customBitrateMbps))")
        lines.append("keep_audio: \(keepAudio)")
        lines.append("keep_metadata: \(keepMetadata)")
        lines.append("preserve_hdr_tags: \(preserveHDRTags)")
        lines.append("cpu_percent: \(String(format: "%.2f", cpuUsagePercent))")
        lines.append("gpu_estimate_percent: \(String(format: "%.2f", gpuEstimatePercent))")
        lines.append("memory_mb: \(String(format: "%.2f", memoryUsageMB))")
        lines.append("current_frame_second: \(String(format: "%.3f", processingFPS))")
        lines.append("average_frame_second: \(String(format: "%.3f", averageProcessingFPS))")
        lines.append("peak_frame_second: \(String(format: "%.3f", peakProcessingFPS))")
        lines.append("lowest_frame_second: \(String(format: "%.3f", lowestProcessingFPS))")
        lines.append("thermal_state: \(thermalStateText)")
        lines.append("cache: \(cacheFootprintText)")
        lines.append("is_benchmark: \(isBenchmarkMode)")
        lines.append("benchmark_resolution: \(benchmarkResolution.title)")
        lines.append("benchmark_source_fps: \(benchmarkSourceFPS.title)")

        if let info = videoInfo {
            lines.append("video_width: \(info.width)")
            lines.append("video_height: \(info.height)")
            lines.append("video_fps: \(String(format: "%.3f", info.fps))")
            lines.append("video_duration: \(info.durationText)")
            lines.append("video_codec: \(info.codec)")
            lines.append("video_hdr: \(info.hdrName)")
            lines.append("video_audio: \(info.hasAudio)")
            lines.append("video_bitrate: \(info.bitrateText)")
        }

        lines.append("segments_done: \(completedSegmentCount)/\(segmentRows.count)")
        for row in segmentRows {
            let percent = Int((min(max(row.progress, 0), 1) * 100).rounded())
            lines.append("segment_\(row.id + 1): \(row.stateText) \(percent)% \(row.detail)")
        }

        return lines.joined(separator: "\n")
    }

    func leaveProcessingScreen() {
        guard !isProcessing else { return }
        showProcessingScreen = false
    }

    func cleanupExportCaches() {
        guard !isProcessing else { return }

        let fileManager = FileManager.default
        var removed = 0
        var failures: [String] = []

        let directURLs = [inputURL, outputURL, performanceLogURL].compactMap { $0 }
        for url in Set(directURLs) {
            do {
                if fileManager.fileExists(atPath: url.path) {
                    try fileManager.removeItem(at: url)
                    removed += 1
                }
            } catch {
                failures.append(url.lastPathComponent)
            }
        }

        removed += removeContentsIfExists(in: documentsDirectory().appendingPathComponent("ImportedVideos", isDirectory: true), using: fileManager, failures: &failures)
        removed += removeContentsIfExists(in: documentsDirectory().appendingPathComponent("BuzhenLogs", isDirectory: true), using: fileManager, failures: &failures)
        removed += removeTemporaryArtifacts(using: fileManager, failures: &failures)

        inputURL = nil
        outputURL = nil
        performanceLogURL = nil
        videoInfo = nil
        resetProgressUI()
        resetPerformanceUI()
        status = "缓存已清理"
        currentStageText = "缓存已清理"
        errorMessage = nil

        if failures.isEmpty {
            cacheCleanupMessage = "已清理 \(removed) 个缓存/临时文件。"
        } else {
            cacheCleanupMessage = "已清理 \(removed) 个项目，以下文件未删掉：\(failures.joined(separator: "、"))"
        }
        refreshCacheFootprint()
    }

    private func cleanupResidualTemporaryFiles() {
        let fileManager = FileManager.default
        var failures: [String] = []
        _ = removeTemporaryArtifacts(using: fileManager, failures: &failures)
    }

    private func documentsDirectory() -> URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
    }

    @discardableResult
    private func removeContentsIfExists(in directory: URL, using fileManager: FileManager, failures: inout [String]) -> Int {
        guard fileManager.fileExists(atPath: directory.path) else { return 0 }
        guard let items = try? fileManager.contentsOfDirectory(at: directory, includingPropertiesForKeys: nil) else {
            failures.append(directory.lastPathComponent)
            return 0
        }

        var removed = 0
        for item in items {
            do {
                try fileManager.removeItem(at: item)
                removed += 1
            } catch {
                failures.append(item.lastPathComponent)
            }
        }
        return removed
    }

    @discardableResult
    private func removeTemporaryArtifacts(using fileManager: FileManager, failures: inout [String]) -> Int {
        let tempRoot = fileManager.temporaryDirectory
        guard let items = try? fileManager.contentsOfDirectory(at: tempRoot, includingPropertiesForKeys: nil) else {
            return 0
        }

        var removed = 0
        let prefixes = ["buzhen_", "buzhensegments_", "buzhen_segments_", "buzhen_benchmark_"]
        for item in items {
            let name = item.lastPathComponent.lowercased()
            guard prefixes.contains(where: { name.hasPrefix($0) }) else { continue }
            do {
                try fileManager.removeItem(at: item)
                removed += 1
            } catch {
                failures.append(item.lastPathComponent)
            }
        }
        return removed
    }

    private func refreshCacheFootprint() {
        cacheFootprintText = Self.byteText(cacheFootprintBytes())
    }

    private func cacheFootprintBytes() -> Int64 {
        let fileManager = FileManager.default
        var total: Int64 = 0
        var seen = Set<URL>()

        func addURL(_ url: URL?) {
            guard let url else { return }
            guard !seen.contains(url) else { return }
            seen.insert(url)
            total += Self.sizeOfItem(at: url, fileManager: fileManager)
        }

        addURL(inputURL)
        addURL(outputURL)
        addURL(performanceLogURL)
        addURL(documentsDirectory().appendingPathComponent("ImportedVideos", isDirectory: true))
        addURL(documentsDirectory().appendingPathComponent("BuzhenLogs", isDirectory: true))

        if let items = try? fileManager.contentsOfDirectory(at: fileManager.temporaryDirectory, includingPropertiesForKeys: nil) {
            for item in items {
                let name = item.lastPathComponent.lowercased()
                if ["buzhen_", "buzhensegments_", "buzhen_segments_"].contains(where: { name.hasPrefix($0) }) {
                    addURL(item)
                }
            }
        }

        return total
    }

    private static func sizeOfItem(at url: URL, fileManager: FileManager) -> Int64 {
        var isDirectory: ObjCBool = false
        guard fileManager.fileExists(atPath: url.path, isDirectory: &isDirectory) else { return 0 }

        if isDirectory.boolValue {
            guard let enumerator = fileManager.enumerator(at: url, includingPropertiesForKeys: [.fileSizeKey], options: []) else { return 0 }
            var total: Int64 = 0
            for case let fileURL as URL in enumerator {
                if let size = try? fileURL.resourceValues(forKeys: [.fileSizeKey]).fileSize {
                    total += Int64(size)
                }
            }
            return total
        }

        return Int64((try? url.resourceValues(forKeys: [.fileSizeKey]).fileSize) ?? 0)
    }

    private static func byteText(_ bytes: Int64) -> String {
        let value = Double(max(0, bytes))
        if value >= 1_073_741_824 {
            return String(format: "%.2f GB", value / 1_073_741_824)
        }
        if value >= 1_048_576 {
            return String(format: "%.1f MB", value / 1_048_576)
        }
        if value >= 1024 {
            return String(format: "%.1f KB", value / 1024)
        }
        return "\(bytes) B"
    }

    private func resetProgressUI() {
        progress = 0
        currentStageText = nil
        segmentRows = []
        workerCount = 0
        progressModeText = "未开始"
        performanceLogURL = nil
        performanceLogSampleCount = 0
    }

    private func resetPerformanceStats() {
        averageProcessingFPS = 0
        peakProcessingFPS = 0
        lowestProcessingFPS = 0
        fpsStatsSampleCount = 0
    }

    private func resetPerformanceUI() {
        performanceTimer?.invalidate()
        performanceTimer = nil
        processingStartDate = nil
        cpuUsagePercent = 0
        memoryUsageMB = 0
        gpuEstimatePercent = 0
        processingFPS = 0
        elapsedTimeText = "00:00"
        estimatedRemainingText = "--"
        thermalStateText = Self.thermalText(ProcessInfo.processInfo.thermalState)
        performanceLogSampleCount = 0
        resetPerformanceStats()
    }

    private func startPerformanceMonitoring() {
        processingStartDate = Date()
        preparePerformanceLogFile()
        refreshPerformanceMetrics()
        performanceTimer?.invalidate()
        performanceTimer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { [weak self] _ in
            Task { @MainActor in
                self?.refreshPerformanceMetrics()
            }
        }
    }

    private func stopPerformanceMonitoring() {
        performanceTimer?.invalidate()
        performanceTimer = nil
    }

    private func refreshPerformanceMetrics(final: Bool = false) {
        cpuUsagePercent = PerformanceSampler.appCPUUsagePercent()
        memoryUsageMB = PerformanceSampler.memoryFootprintMB()
        thermalStateText = Self.thermalText(ProcessInfo.processInfo.thermalState)

        let elapsed = max(0, Date().timeIntervalSince(processingStartDate ?? Date()))
        elapsedTimeText = Self.timeText(elapsed)

        let duration = videoInfo?.duration ?? 0
        if elapsed > 0, duration > 0 {
            let estimatedFrames = min(max(progress, 0), 1) * duration * targetFPS
            processingFPS = estimatedFrames / elapsed
        } else {
            processingFPS = 0
        }

        updatePerformanceStats()

        if progress > 0.005, progress < 0.999, elapsed > 1 {
            let remaining = elapsed * (1 - progress) / max(progress, 0.001)
            estimatedRemainingText = Self.timeText(remaining)
        } else if final || progress >= 0.999 {
            estimatedRemainingText = "00:00"
        } else {
            estimatedRemainingText = "--"
        }

        let workerBase = processingMode == .parallelSegmented ? max(1, maxParallelJobs) : max(1, workerCount)
        let activityRatio = Double(max(activeSegmentCount, isProcessing ? 1 : 0)) / Double(workerBase)
        let speedRatio = duration > 0 ? min(max(processingFPS / max(targetFPS, 1), 0), 1) : 0
        gpuEstimatePercent = isProcessing ? min(99, max(8, activityRatio * 68 + speedRatio * 28)) : 0

        appendPerformanceLogSample(final: final)
    }

    private func updatePerformanceStats() {
        guard processingFPS > 0.001 else { return }
        fpsStatsSampleCount += 1
        peakProcessingFPS = max(peakProcessingFPS, processingFPS)
        lowestProcessingFPS = lowestProcessingFPS == 0 ? processingFPS : min(lowestProcessingFPS, processingFPS)
        let previousWeight = Double(max(0, fpsStatsSampleCount - 1))
        averageProcessingFPS = ((averageProcessingFPS * previousWeight) + processingFPS) / Double(fpsStatsSampleCount)
    }

    private func preparePerformanceLogFile() {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        let dir = docs.appendingPathComponent("BuzhenLogs", isDirectory: true)

        do {
            if !FileManager.default.fileExists(atPath: dir.path) {
                try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
            }

            let stamp = ISO8601DateFormatter().string(from: Date())
                .replacingOccurrences(of: ":", with: "-")
                .replacingOccurrences(of: ".", with: "-")
            let url = dir.appendingPathComponent("buzhen_performance_\(stamp).csv")
            let header = "time_iso,elapsed_seconds,progress_percent,status,stage,cpu_percent,gpu_estimate_percent,memory_mb,frames_per_second,average_frame_second,peak_frame_second,lowest_frame_second,thermal_state,active_segments,completed_segments,total_segments,worker_count,processing_mode,target_fps,quality,bitrate_mbps,platform,cpu_cores,total_system_memory,is_benchmark,benchmark_resolution,benchmark_source_fps,marker" + "\n"
            try header.write(to: url, atomically: true, encoding: .utf8)
            performanceLogURL = url
            performanceLogSampleCount = 0
        } catch {
            performanceLogURL = nil
            performanceLogSampleCount = 0
        }
    }

    private func appendPerformanceLogSample(final: Bool = false) {
        guard let url = performanceLogURL else { return }

        let elapsed = max(0, Date().timeIntervalSince(processingStartDate ?? Date()))
        let timestamp = ISO8601DateFormatter().string(from: Date())
        let bitrateText = bitrateMode == .customMbps
            ? String(format: "%.3f", customBitrateMbps)
            : (recommendedBitrateMbps.map { String(format: "%.3f", $0) } ?? "automatic")

        let fields = [
            timestamp,
            String(format: "%.3f", elapsed),
            String(format: "%.2f", min(max(progress, 0), 1) * 100),
            status,
            currentStageText ?? "",
            String(format: "%.2f", cpuUsagePercent),
            String(format: "%.2f", gpuEstimatePercent),
            String(format: "%.2f", memoryUsageMB),
            String(format: "%.3f", processingFPS),
            String(format: "%.3f", averageProcessingFPS),
            String(format: "%.3f", peakProcessingFPS),
            String(format: "%.3f", lowestProcessingFPS),
            thermalStateText,
            "\(activeSegmentCount)",
            "\(completedSegmentCount)",
            "\(segmentRows.count)",
            "\(workerCount)",
            processingMode.title,
            String(format: "%.3f", targetFPS),
            quality.title,
            bitrateText,
            platformText,
            cpuCoreText,
            totalSystemMemoryText,
            isBenchmarkMode ? "true" : "false",
            benchmarkResolution.title,
            benchmarkSourceFPS.title,
            final ? "FINAL" : ""
        ]

        let line = fields.map(Self.csvEscape).joined(separator: ",") + "\n"

        guard let data = line.data(using: .utf8), let handle = try? FileHandle(forWritingTo: url) else { return }
        defer { try? handle.close() }
        handle.seekToEndOfFile()
        handle.write(data)
        performanceLogSampleCount += 1
    }

    private static func csvEscape(_ value: String) -> String {
        if value.contains(",") || value.contains("\n") || value.contains("\"") {
            return "\"" + value.replacingOccurrences(of: "\"", with: "\"\"") + "\""
        }
        return value
    }

    private static func timeText(_ seconds: TimeInterval) -> String {
        let total = max(0, Int(seconds.rounded()))
        let hours = total / 3600
        let minutes = (total % 3600) / 60
        let secs = total % 60
        if hours > 0 {
            return String(format: "%02d:%02d:%02d", hours, minutes, secs)
        }
        return String(format: "%02d:%02d", minutes, secs)
    }

    private static func cpuCoreDescription() -> String {
        let process = ProcessInfo.processInfo
        return "\(process.activeProcessorCount)/\(process.processorCount) 核"
    }

    private static func totalSystemMemoryDescription() -> String {
        let bytes = Int64(ProcessInfo.processInfo.physicalMemory)
        let gb = Double(bytes) / 1_073_741_824.0
        return String(format: "%.1f GB", gb)
    }

    private static func performanceSourceDescription() -> String {
        #if targetEnvironment(macCatalyst)
        return "Mach + Metal"
        #else
        return "iOS App 采样"
        #endif
    }

    private static func platformDescription() -> String {
        #if targetEnvironment(macCatalyst)
        return "Mac"
        #else
        return "iOS"
        #endif
    }

    private static func thermalText(_ state: ProcessInfo.ThermalState) -> String {
        switch state {
        case .nominal:
            return "正常"
        case .fair:
            return "偏热"
        case .serious:
            return "过热"
        case .critical:
            return "严重过热"
        @unknown default:
            return "未知"
        }
    }

    private func applyProcessorProgress(_ rawProgress: Double, _ message: String) {
        let clamped = min(max(rawProgress, 0), 1)

        if parseSegmentEvent(message) {
            setProgressSmooth(max(progress, clamped))
            return
        }

        if message.hasPrefix("STAGE|") {
            let text = String(message.dropFirst("STAGE|".count))
            status = text
            currentStageText = text
            setProgressSmooth(max(progress, clamped))
            return
        }

        status = message
        currentStageText = message
        setProgressSmooth(max(progress, clamped))
    }

    private func setProgressSmooth(_ value: Double) {
        let target = min(max(value, 0), 1)
        guard target >= progress else { return }

        withAnimation(.linear(duration: target >= 0.999 ? 0.20 : 0.38)) {
            progress = target
        }
    }

    private func parseSegmentEvent(_ message: String) -> Bool {
        let parts = message.split(separator: "|", omittingEmptySubsequences: false).map(String.init)
        guard let kind = parts.first else { return false }

        switch kind {
        case "SEGMENT_SETUP":
            let count = Int(parts[safe: 1] ?? "") ?? 0
            let workers = Int(parts[safe: 2] ?? "") ?? 1
            let mode = parts[safe: 3] ?? processingMode.rawValue

            workerCount = max(1, workers)
            progressModeText = mode
            status = mode == "parallel" ? "并行分段准备中：共 \(count) 段" : "分段准备中：共 \(count) 段"
            currentStageText = "准备分段"

            segmentRows = (0..<max(0, count)).map { index in
                TaskProgressRow(
                    id: index,
                    title: "第 \(index + 1) 段",
                    detail: "等待中",
                    progress: 0,
                    state: .waiting
                )
            }
            return true

        case "SEGMENT_START":
            guard let index = Int(parts[safe: 1] ?? "") else { return true }
            updateSegment(index: index, progress: nil, state: .running, detail: "处理中")
            status = "第 \(index + 1) 段开始处理"
            currentStageText = "处理视频帧"
            return true

        case "SEGMENT_PROGRESS":
            guard let index = Int(parts[safe: 1] ?? "") else { return true }
            let local = Double(parts[safe: 2] ?? "") ?? 0
            let percent = Int((min(max(local, 0), 1) * 100).rounded())
            updateSegment(index: index, progress: local, state: .running, detail: "\(percent)%")
            status = "第 \(index + 1) 段：\(percent)%"
            currentStageText = "光流补帧中"
            return true

        case "SEGMENT_DONE":
            guard let index = Int(parts[safe: 1] ?? "") else { return true }
            updateSegment(index: index, progress: 1, state: .done, detail: "完成")
            status = "第 \(index + 1) 段完成"
            currentStageText = "分段处理中"
            return true

        default:
            return false
        }
    }

    private func updateSegment(index: Int, progress localProgress: Double?, state: TaskProgressState, detail: String) {
        guard index >= 0 else { return }

        if let existingIndex = segmentRows.firstIndex(where: { $0.id == index }) {
            if let localProgress {
                let target = max(segmentRows[existingIndex].progress, min(max(localProgress, 0), 1))
                withAnimation(.linear(duration: target >= 0.999 ? 0.20 : 0.32)) {
                    segmentRows[existingIndex].progress = target
                }
            }
            segmentRows[existingIndex].state = state
            segmentRows[existingIndex].detail = detail
        } else {
            segmentRows.append(
                TaskProgressRow(
                    id: index,
                    title: "第 \(index + 1) 段",
                    detail: detail,
                    progress: min(max(localProgress ?? 0, 0), 1),
                    state: state
                )
            )
            segmentRows.sort { $0.id < $1.id }
        }
    }

    private func markAllSegmentsDone() {
        for index in segmentRows.indices {
            segmentRows[index].progress = 1
            segmentRows[index].state = .done
            segmentRows[index].detail = "完成"
        }
    }
}

enum BenchmarkResolution: String, CaseIterable, Identifiable, Sendable {
    case p720
    case p1080
    case p2k
    case p4k

    var id: String { rawValue }

    var title: String {
        switch self {
        case .p720: return "720p"
        case .p1080: return "1080p"
        case .p2k: return "2K"
        case .p4k: return "4K"
        }
    }

    var size: CGSize {
        switch self {
        case .p720: return CGSize(width: 1280, height: 720)
        case .p1080: return CGSize(width: 1920, height: 1080)
        case .p2k: return CGSize(width: 2560, height: 1440)
        case .p4k: return CGSize(width: 3840, height: 2160)
        }
    }

    var bitrate: Int {
        switch self {
        case .p720: return 8_000_000
        case .p1080: return 16_000_000
        case .p2k: return 32_000_000
        case .p4k: return 70_000_000
        }
    }
}

enum BenchmarkSourceFPS: Int, CaseIterable, Identifiable, Sendable {
    case fps24 = 24
    case fps60 = 60

    var id: Int { rawValue }
    var title: String { "\(rawValue) fps" }
    var doubleValue: Double { Double(rawValue) }
}

enum BenchmarkSampleVideoGenerator {
    static let durationSeconds: Double = 4.0

    static func generate(resolution: BenchmarkResolution, fps: BenchmarkSourceFPS) throws -> URL {
        let size = resolution.size
        let width = Int(size.width)
        let height = Int(size.height)

        let url = FileManager.default.temporaryDirectory
            .appendingPathComponent("buzhen_benchmark_\(resolution.rawValue)_\(fps.rawValue)_\(UUID().uuidString)")
            .appendingPathExtension("mp4")

        if FileManager.default.fileExists(atPath: url.path) {
            try FileManager.default.removeItem(at: url)
        }

        let writer = try AVAssetWriter(outputURL: url, fileType: .mp4)
        let settings: [String: Any] = [
            AVVideoCodecKey: AVVideoCodecType.h264,
            AVVideoWidthKey: width,
            AVVideoHeightKey: height,
            AVVideoCompressionPropertiesKey: [
                AVVideoAverageBitRateKey: resolution.bitrate,
                AVVideoExpectedSourceFrameRateKey: fps.rawValue,
                AVVideoMaxKeyFrameIntervalKey: fps.rawValue
            ]
        ]

        let input = AVAssetWriterInput(mediaType: .video, outputSettings: settings)
        input.expectsMediaDataInRealTime = false

        let pixelAttributes: [String: Any] = [
            kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA,
            kCVPixelBufferWidthKey as String: width,
            kCVPixelBufferHeightKey as String: height,
            kCVPixelBufferIOSurfacePropertiesKey as String: [:]
        ]

        let adaptor = AVAssetWriterInputPixelBufferAdaptor(
            assetWriterInput: input,
            sourcePixelBufferAttributes: pixelAttributes
        )

        guard writer.canAdd(input) else {
            throw NSError(domain: "BuzhenBenchmark", code: 3001, userInfo: [
                NSLocalizedDescriptionKey: "无法创建 sample 视频写入器。"
            ])
        }

        writer.add(input)

        guard writer.startWriting() else {
            throw writer.error ?? NSError(domain: "BuzhenBenchmark", code: 3002, userInfo: [
                NSLocalizedDescriptionKey: "无法开始写入 sample 视频。"
            ])
        }

        writer.startSession(atSourceTime: .zero)

        let context = CIContext(options: [.workingColorSpace: NSNull()])
        let frameCount = max(1, Int(durationSeconds * fps.doubleValue))
        let timescale = CMTimeScale(fps.rawValue)

        for frame in 0..<frameCount {
            while !input.isReadyForMoreMediaData {
                Thread.sleep(forTimeInterval: 0.002)
            }

            var pixelBuffer: CVPixelBuffer?
            if let pool = adaptor.pixelBufferPool {
                CVPixelBufferPoolCreatePixelBuffer(nil, pool, &pixelBuffer)
            }

            if pixelBuffer == nil {
                CVPixelBufferCreate(
                    kCFAllocatorDefault,
                    width,
                    height,
                    kCVPixelFormatType_32BGRA,
                    pixelAttributes as CFDictionary,
                    &pixelBuffer
                )
            }

            guard let pixelBuffer else {
                throw NSError(domain: "BuzhenBenchmark", code: 3003, userInfo: [
                    NSLocalizedDescriptionKey: "无法创建 sample 视频帧。"
                ])
            }

            let image = makeFrameImage(frame: frame, width: width, height: height)
            context.render(image, to: pixelBuffer)

            let presentationTime = CMTime(value: CMTimeValue(frame), timescale: timescale)
            if !adaptor.append(pixelBuffer, withPresentationTime: presentationTime) {
                throw writer.error ?? NSError(domain: "BuzhenBenchmark", code: 3004, userInfo: [
                    NSLocalizedDescriptionKey: "sample 视频帧写入失败。"
                ])
            }
        }

        input.markAsFinished()

        let semaphore = DispatchSemaphore(value: 0)
        writer.finishWriting {
            semaphore.signal()
        }
        semaphore.wait()

        guard writer.status == .completed else {
            throw writer.error ?? NSError(domain: "BuzhenBenchmark", code: 3005, userInfo: [
                NSLocalizedDescriptionKey: "sample 视频生成失败。"
            ])
        }

        return url
    }

    private static func makeFrameImage(frame: Int, width: Int, height: Int) -> CIImage {
        let extent = CGRect(x: 0, y: 0, width: width, height: height)

        let checker = CIFilter(name: "CICheckerboardGenerator")!
        checker.setValue(CIColor(red: 0.05, green: 0.08, blue: 0.14), forKey: "inputColor0")
        checker.setValue(CIColor(red: 0.16, green: 0.24, blue: 0.42), forKey: "inputColor1")
        checker.setValue(CIVector(x: CGFloat((frame * 9) % max(width, 1)), y: CGFloat((frame * 5) % max(height, 1))), forKey: "inputCenter")
        checker.setValue(max(36, width / 28), forKey: "inputWidth")

        let base = (checker.outputImage ?? CIImage(color: .black)).cropped(to: extent)

        let barWidth = max(120, width / 8)
        let x = CGFloat((frame * max(10, width / 90)) % (width + barWidth)) - CGFloat(barWidth)
        let y = CGFloat(height / 4)
        let movingBar = CIImage(color: CIColor(red: 1.0, green: 0.72, blue: 0.20, alpha: 0.86))
            .cropped(to: CGRect(x: x, y: y, width: barWidth, height: height / 2))

        let smallBoxSize = max(60, min(width, height) / 10)
        let orbitX = CGFloat(width / 2) + cos(CGFloat(frame) * 0.11) * CGFloat(width / 4) - CGFloat(smallBoxSize / 2)
        let orbitY = CGFloat(height / 2) + sin(CGFloat(frame) * 0.09) * CGFloat(height / 4) - CGFloat(smallBoxSize / 2)
        let box = CIImage(color: CIColor(red: 0.18, green: 0.85, blue: 1.0, alpha: 0.82))
            .cropped(to: CGRect(x: orbitX, y: orbitY, width: CGFloat(smallBoxSize), height: CGFloat(smallBoxSize)))

        return box.composited(over: movingBar.composited(over: base)).cropped(to: extent)
    }
}

struct TaskProgressRow: Identifiable, Equatable {
    let id: Int
    var title: String
    var detail: String
    var progress: Double
    var state: TaskProgressState

    var stateText: String {
        switch state {
        case .waiting: return "等待"
        case .running: return "进行中"
        case .done: return "完成"
        case .failed: return "失败"
        }
    }

    var symbolName: String {
        switch state {
        case .waiting: return "clock"
        case .running: return "arrow.triangle.2.circlepath"
        case .done: return "checkmark.circle"
        case .failed: return "xmark.circle"
        }
    }
}

enum TaskProgressState: Equatable {
    case waiting
    case running
    case done
    case failed
}

struct PickedVideo: Transferable {
    let url: URL

    static var transferRepresentation: some TransferRepresentation {
        FileRepresentation(contentType: .movie) { video in
            SentTransferredFile(video.url)
        } importing: { received in
            let copied = try ImportStore.copyIntoAppSandbox(from: received.file, preferredExtension: received.file.pathExtension)
            return PickedVideo(url: copied)
        }
    }
}

enum ImportStore {
    static let supportedVideoTypes: [UTType] = [
        .movie,
        .video,
        .audiovisualContent,
        .mpeg4Movie,
        .quickTimeMovie,
        UTType(filenameExtension: "mov") ?? .quickTimeMovie,
        UTType(filenameExtension: "mp4") ?? .mpeg4Movie,
        UTType(filenameExtension: "m4v") ?? .mpeg4Movie
    ]

    static func copyIntoAppSandbox(from source: URL, preferredExtension: String? = nil) throws -> URL {
        let importDir = try importDirectory()
        let ext = normalizedExtension(source: source, preferred: preferredExtension)
        let filename = "input_\(Int(Date().timeIntervalSince1970))_\(String(UUID().uuidString.prefix(8))).\(ext)"
        let destination = importDir.appendingPathComponent(filename)

        if FileManager.default.fileExists(atPath: destination.path) {
            try FileManager.default.removeItem(at: destination)
        }

        let scoped = source.startAccessingSecurityScopedResource()
        defer {
            if scoped {
                source.stopAccessingSecurityScopedResource()
            }
        }

        var coordinationError: NSError?
        var copyError: Error?

        let coordinator = NSFileCoordinator(filePresenter: nil)
        coordinator.coordinate(readingItemAt: source, options: [], error: &coordinationError) { readableURL in
            do {
                try FileManager.default.copyItem(at: readableURL, to: destination)
            } catch {
                copyError = error
            }
        }

        if let coordinationError {
            throw coordinationError
        }

        if let copyError {
            throw copyError
        }

        guard FileManager.default.fileExists(atPath: destination.path) else {
            throw NSError(domain: "BuzhenLocal", code: 1102, userInfo: [
                NSLocalizedDescriptionKey: "视频没有成功复制到 App 沙盒。"
            ])
        }

        return destination
    }

    private static func importDirectory() throws -> URL {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        let dir = docs.appendingPathComponent("ImportedVideos", isDirectory: true)
        if !FileManager.default.fileExists(atPath: dir.path) {
            try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        }
        return dir
    }

    private static func normalizedExtension(source: URL, preferred: String?) -> String {
        let preferredExt = (preferred ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        let sourceExt = source.pathExtension.trimmingCharacters(in: .whitespacesAndNewlines)
        let ext = preferredExt.isEmpty ? sourceExt : preferredExt

        if ext.isEmpty { return "mov" }
        return ext.lowercased()
    }
}

private enum PerformanceSampler {
    static func appCPUUsagePercent() -> Double {
        var threadList: thread_act_array_t?
        var threadCount = mach_msg_type_number_t(0)

        let result = task_threads(mach_task_self_, &threadList, &threadCount)
        guard result == KERN_SUCCESS, let threadList else { return 0 }

        defer {
            let size = vm_size_t(Int(threadCount) * MemoryLayout<thread_t>.stride)
            vm_deallocate(mach_task_self_, vm_address_t(UInt(bitPattern: threadList)), size)
        }

        var total: Double = 0

        for index in 0..<Int(threadCount) {
            var info = thread_basic_info()
            var count = mach_msg_type_number_t(THREAD_INFO_MAX)

            let kr = withUnsafeMutablePointer(to: &info) { pointer in
                pointer.withMemoryRebound(to: integer_t.self, capacity: Int(count)) { rebound in
                    thread_info(threadList[index], thread_flavor_t(THREAD_BASIC_INFO), rebound, &count)
                }
            }

            if kr == KERN_SUCCESS, (info.flags & Int32(TH_FLAGS_IDLE)) == 0 {
                total += Double(info.cpu_usage) / Double(TH_USAGE_SCALE) * 100.0
            }
        }

        return max(0, total)
    }

    static func memoryFootprintMB() -> Double {
        var info = task_vm_info_data_t()
        var count = mach_msg_type_number_t(MemoryLayout<task_vm_info_data_t>.size / MemoryLayout<natural_t>.size)

        let result = withUnsafeMutablePointer(to: &info) { pointer in
            pointer.withMemoryRebound(to: integer_t.self, capacity: Int(count)) { rebound in
                task_info(mach_task_self_, task_flavor_t(TASK_VM_INFO), rebound, &count)
            }
        }

        guard result == KERN_SUCCESS else { return 0 }
        return Double(info.phys_footprint) / 1_048_576.0
    }
}

private struct PreciseDoubleInput: View {
    let title: String
    @Binding var value: Double
    let range: ClosedRange<Double>
    let unit: String
    let fractionDigits: Int

    @State private var draftText: String = ""
    @FocusState private var isFocused: Bool

    var body: some View {
        ViewThatFits(in: .horizontal) {
            horizontalLayout
            verticalLayout
        }
        .padding(10)
        .liquidGlassCard(cornerRadius: 14)
        .onAppear {
            draftText = formatted(value)
        }
        .onChange(of: value) { newValue in
            if !isFocused {
                draftText = formatted(newValue)
            }
        }
        .onChange(of: isFocused) { focused in
            if focused {
                draftText = rawEditingText(from: value)
            } else {
                commitDraft()
            }
        }
    }

    private var horizontalLayout: some View {
        HStack(spacing: 10) {
            titleLabel

            Spacer(minLength: 8)

            valueField
                .frame(minWidth: 104, idealWidth: 140, maxWidth: 190)

            unitLabel
            confirmButton
        }
    }

    private var verticalLayout: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                titleLabel
                Spacer(minLength: 8)
                unitLabel
            }

            HStack(spacing: 8) {
                valueField
                confirmButton
            }
        }
    }

    private var titleLabel: some View {
        Text(title)
            .font(.footnote.weight(.medium))
            .lineLimit(1)
            .minimumScaleFactor(0.82)
    }

    private var unitLabel: some View {
        Text(unit)
            .font(.footnote)
            .foregroundStyle(.secondary)
            .lineLimit(1)
            .minimumScaleFactor(0.82)
            .frame(minWidth: 32, alignment: .leading)
    }

    private var valueField: some View {
        TextField(title, text: $draftText)
            .keyboardType(.decimalPad)
            .textInputAutocapitalization(.never)
            .autocorrectionDisabled(true)
            .focused($isFocused)
            .multilineTextAlignment(.trailing)
            .font(.body.monospacedDigit())
            .submitLabel(.done)
            .liquidGlassTextField(cornerRadius: 12)
            .onSubmit {
                commitDraft()
            }
    }

    private var confirmButton: some View {
        Button {
            commitDraft()
            isFocused = false
        } label: {
            Text("确认")
                .font(.footnote.weight(.semibold))
        }
        .buttonStyle(.bordered)
        .controlSize(.small)
        .disabled(parsedValue == nil)
    }

    private var parsedValue: Double? {
        let normalized = draftText
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .replacingOccurrences(of: ",", with: ".")

        guard !normalized.isEmpty, let parsed = Double(normalized), parsed.isFinite else {
            return nil
        }

        return min(max(parsed, range.lowerBound), range.upperBound)
    }

    private func commitDraft() {
        guard let parsed = parsedValue else {
            draftText = formatted(value)
            return
        }

        value = parsed
        draftText = formatted(parsed)
    }

    private func formatted(_ number: Double) -> String {
        let clamped = min(max(number, range.lowerBound), range.upperBound)
        return String(format: "%.\(fractionDigits)f", clamped)
    }

    private func rawEditingText(from number: Double) -> String {
        let rounded = number.rounded()
        if abs(number - rounded) < 0.000001 {
            return String(Int(rounded))
        }
        return formatted(number)
    }
}

private struct PreciseIntInput: View {
    let title: String
    @Binding var value: Int
    let range: ClosedRange<Int>
    let unit: String

    @State private var draftText: String = ""
    @FocusState private var isFocused: Bool

    var body: some View {
        ViewThatFits(in: .horizontal) {
            horizontalLayout
            verticalLayout
        }
        .padding(10)
        .liquidGlassCard(cornerRadius: 14)
        .onAppear {
            draftText = "\(value)"
        }
        .onChange(of: value) { newValue in
            if !isFocused {
                draftText = "\(newValue)"
            }
        }
        .onChange(of: isFocused) { focused in
            if !focused {
                commitDraft()
            }
        }
    }

    private var horizontalLayout: some View {
        HStack(spacing: 10) {
            titleLabel

            Spacer(minLength: 8)

            valueField
                .frame(minWidth: 96, idealWidth: 128, maxWidth: 175)

            unitLabel
            confirmButton
        }
    }

    private var verticalLayout: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                titleLabel
                Spacer(minLength: 8)
                unitLabel
            }

            HStack(spacing: 8) {
                valueField
                confirmButton
            }
        }
    }

    private var titleLabel: some View {
        Text(title)
            .font(.footnote.weight(.medium))
            .lineLimit(1)
            .minimumScaleFactor(0.82)
    }

    private var unitLabel: some View {
        Text(unit)
            .font(.footnote)
            .foregroundStyle(.secondary)
            .lineLimit(1)
            .minimumScaleFactor(0.82)
            .frame(minWidth: 28, alignment: .leading)
    }

    private var valueField: some View {
        TextField(title, text: $draftText)
            .keyboardType(.numberPad)
            .textInputAutocapitalization(.never)
            .autocorrectionDisabled(true)
            .focused($isFocused)
            .multilineTextAlignment(.trailing)
            .font(.body.monospacedDigit())
            .submitLabel(.done)
            .liquidGlassTextField(cornerRadius: 12)
            .onSubmit {
                commitDraft()
            }
    }

    private var confirmButton: some View {
        Button {
            commitDraft()
            isFocused = false
        } label: {
            Text("确认")
                .font(.footnote.weight(.semibold))
        }
        .buttonStyle(.bordered)
        .controlSize(.small)
        .disabled(parsedValue == nil)
    }

    private var parsedValue: Int? {
        let normalized = draftText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !normalized.isEmpty, let parsed = Int(normalized) else { return nil }
        return min(max(parsed, range.lowerBound), range.upperBound)
    }

    private func commitDraft() {
        guard let parsed = parsedValue else {
            draftText = "\(value)"
            return
        }

        value = parsed
        draftText = "\(parsed)"
    }
}

private struct MetricTile: View {
    let title: String
    let value: String
    let systemImage: String

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Label(title, systemImage: systemImage)
                .font(.caption.weight(.semibold))
                .foregroundStyle(.secondary)

            Text(value)
                .font(.headline.monospacedDigit())
                .lineLimit(1)
                .minimumScaleFactor(0.72)
        }
        .padding(10)
        .frame(maxWidth: .infinity, alignment: .leading)
        .liquidGlassCard(cornerRadius: 16)
    }
}

private struct Card<Content: View>: View {
    let title: String
    let systemImage: String
    let content: Content

    init(_ title: String, systemImage: String, @ViewBuilder content: () -> Content) {
        self.title = title
        self.systemImage = systemImage
        self.content = content()
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack(spacing: 8) {
                Image(systemName: systemImage)
                    .foregroundStyle(.secondary)
                Text(title)
                    .font(.headline)
            }

            content
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .topLeading)
        .liquidGlassCard(cornerRadius: 22)
    }
}

private struct InfoRow: View {
    let title: String
    let value: String

    init(_ title: String, _ value: String) {
        self.title = title
        self.value = value
    }

    var body: some View {
        HStack(alignment: .firstTextBaseline) {
            Text(title)
                .foregroundStyle(.secondary)
            Spacer(minLength: 12)
            Text(value)
                .multilineTextAlignment(.trailing)
                .textSelection(.enabled)
        }
        .font(.footnote)
        .lineLimit(2)
        .minimumScaleFactor(0.72)
    }
}

private struct EmptyState: View {
    let text: String
    let systemImage: String

    var body: some View {
        HStack(spacing: 8) {
            Image(systemName: systemImage)
            Text(text)
        }
        .font(.footnote)
        .foregroundStyle(.secondary)
        .padding(10)
        .frame(maxWidth: .infinity, alignment: .leading)
        .liquidGlassCard(cornerRadius: 14)
    }
}

private struct StatusBadge: View {
    let text: String
    let systemImage: String

    var body: some View {
        Label(text, systemImage: systemImage)
            .font(.caption.weight(.semibold))
            .padding(.horizontal, 10)
            .padding(.vertical, 6)
            .liquidGlassCapsule()
    }
}

private struct QualityLine: View {
    let index: String
    let title: String
    let detail: String

    var body: some View {
        HStack {
            Text(index)
                .font(.caption.bold())
                .frame(width: 22, height: 22)
                .liquidGlassCircle()

            Text(title)
                .font(.footnote.weight(.medium))

            Spacer()

            Text(detail)
                .font(.caption)
                .foregroundStyle(.secondary)
        }
    }
}

private struct ProcessingProgressRing: View {
    let value: Double
    let percentText: String
    let isComplete: Bool

    @State private var spin = false
    @State private var pulse = false

    private var clamped: Double {
        min(max(value, 0), 1)
    }

    var body: some View {
        ZStack {
            Circle()
                .stroke(.secondary.opacity(0.16), lineWidth: 14)
                .liquidGlassCircle()

            Circle()
                .trim(from: 0, to: clamped)
                .stroke(
                    .tint.opacity(0.82),
                    style: StrokeStyle(lineWidth: 14, lineCap: .round, lineJoin: .round)
                )
                .rotationEffect(.degrees(-90))
                .animation(.easeInOut(duration: 0.42), value: clamped)

            Circle()
                .trim(from: 0, to: 0.16)
                .stroke(.white.opacity(0.58), style: StrokeStyle(lineWidth: 5, lineCap: .round))
                .rotationEffect(.degrees(spin ? 360 : 0))
                .opacity(isComplete ? 0 : 0.92)
                .animation(isComplete ? .default : .linear(duration: 1.25).repeatForever(autoreverses: false), value: spin)

            VStack(spacing: 4) {
                Image(systemName: isComplete ? "checkmark" : "bolt.horizontal.fill")
                    .font(.title2.weight(.bold))
                    .symbolRenderingMode(.hierarchical)
                    .scaleEffect(isComplete ? (pulse ? 1.12 : 1.0) : 1.0)

                Text(percentText)
                    .font(.title3.monospacedDigit().bold())
            }
        }
        .frame(width: 118, height: 118)
        .scaleEffect(isComplete ? (pulse ? 1.03 : 0.98) : 1.0)
        .onAppear {
            spin = true
        }
        .onChange(of: isComplete) { done in
            if done {
                withAnimation(.spring(response: 0.45, dampingFraction: 0.48)) {
                    pulse = true
                }
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) {
                    withAnimation(.spring(response: 0.52, dampingFraction: 0.72)) {
                        pulse = false
                    }
                }
            }
        }
    }
}

private struct SuccessPulseView: View {
    @State private var show = false
    @State private var ripple = false

    var body: some View {
        VStack(spacing: 10) {
            ZStack {
                Circle()
                    .stroke(.tint.opacity(ripple ? 0 : 0.32), lineWidth: 7)
                    .scaleEffect(ripple ? 1.55 : 0.72)
                    .opacity(ripple ? 0 : 1)

                Circle()
                    .fill(.tint.opacity(0.16))
                    .liquidGlassCircle()
                    .frame(width: 70, height: 70)

                Image(systemName: "checkmark.circle.fill")
                    .font(.system(size: 50, weight: .semibold))
                    .symbolRenderingMode(.hierarchical)
                    .scaleEffect(show ? 1 : 0.55)
                    .opacity(show ? 1 : 0)
            }
            .frame(width: 104, height: 104)

            Text("处理完成")
                .font(.headline)

            Text("可以导出视频或下载性能日志。")
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .padding(.vertical, 8)
        .onAppear {
            withAnimation(.spring(response: 0.50, dampingFraction: 0.52)) {
                show = true
            }
            withAnimation(.easeOut(duration: 0.95).repeatCount(2, autoreverses: false)) {
                ripple = true
            }
        }
    }
}

private struct NonlinearEntranceModifier: ViewModifier {
    let index: Int
    let isReady: Bool

    @ViewBuilder
    func body(content: Content) -> some View {
        if #available(iOS 17.0, *) {
            base(content)
                .scrollTransition(axis: .vertical) { view, phase in
                    view
                        .scaleEffect(scrollScale(phase.value))
                        .opacity(scrollOpacity(phase.value))
                        .blur(radius: scrollBlur(phase.value))
                        .rotation3DEffect(
                            .degrees(scrollRotation(phase.value)),
                            axis: (x: 1, y: 0, z: 0),
                            perspective: 0.72
                        )
                        .offset(y: scrollOffset(phase.value))
                }
        } else {
            base(content)
        }
    }

    private func base(_ content: Content) -> some View {
        content
            .opacity(isReady ? 1 : 0)
            .scaleEffect(isReady ? 1 : 0.88, anchor: .center)
            .rotation3DEffect(
                .degrees(isReady ? 0 : 6),
                axis: (x: 1, y: -0.35, z: 0),
                perspective: 0.62
            )
            .blur(radius: isReady ? 0 : 10)
            .offset(y: isReady ? 0 : 46 + CGFloat(index % 3) * 8)
            .animation(
                .easeOut(duration: 0.48)
                    .delay(Double(index) * 0.035),
                value: isReady
            )
            .animation(
                .interpolatingSpring(stiffness: 155, damping: 20)
                    .delay(Double(index) * 0.045),
                value: isReady
            )
    }

    private func scrollCurve(_ value: Double) -> Double {
        let t = min(max(abs(value), 0), 1)
        return t * t * (3 - 2 * t)
    }

    private func scrollOpacity(_ value: Double) -> Double {
        max(0.18, 1.0 - scrollCurve(value) * 0.82)
    }

    private func scrollScale(_ value: Double) -> Double {
        1.0 - scrollCurve(value) * 0.12
    }

    private func scrollBlur(_ value: Double) -> Double {
        scrollCurve(value) * 8.0
    }

    private func scrollRotation(_ value: Double) -> Double {
        value * 6.5 * scrollCurve(value)
    }

    private func scrollOffset(_ value: Double) -> CGFloat {
        CGFloat(value * (18.0 + scrollCurve(value) * 22.0))
    }

    private func smoothstep(_ x: Double) -> Double {
        let t = min(max(x, 0), 1)
        return t * t * (3 - 2 * t)
    }
}

private struct LiquidGlassProgressBar: View {
    let title: String
    let value: Double
    let detail: String

    private var clamped: Double {
        min(max(value, 0), 1)
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 7) {
            HStack {
                Text(title)
                    .font(.caption.weight(.semibold))
                Spacer()
                Text(detail)
                    .font(.caption.monospacedDigit())
                    .foregroundStyle(.secondary)
            }

            GeometryReader { geometry in
                ZStack(alignment: .leading) {
                    Capsule()
                        .fill(.secondary.opacity(0.16))
                        .overlay(
                            Capsule()
                                .strokeBorder(.white.opacity(0.25), lineWidth: 0.6)
                        )
                        .liquidGlassCapsule()

                    Capsule()
                        .fill(.tint.opacity(0.72))
                        .frame(width: max(0, geometry.size.width * CGFloat(clamped)))
                        .animation(.linear(duration: clamped >= 0.999 ? 0.20 : 0.40), value: clamped)
                        .liquidGlassCapsule()
                }
            }
            .frame(height: 13)
        }
    }
}

private struct SegmentProgressRowView: View {
    let row: TaskProgressRow

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 8) {
                Image(systemName: row.symbolName)
                    .font(.caption.weight(.semibold))
                    .frame(width: 20)

                Text(row.title)
                    .font(.footnote.weight(.semibold))

                Spacer()

                Text(row.stateText)
                    .font(.caption)
                    .foregroundStyle(.secondary)

                Text("\(Int((min(max(row.progress, 0), 1) * 100).rounded()))%")
                    .font(.caption.monospacedDigit())
                    .foregroundStyle(.secondary)
            }

            LiquidGlassProgressBar(title: "", value: row.progress, detail: row.detail)
                .frame(height: 28)
        }
        .padding(10)
        .liquidGlassCard(cornerRadius: 16)
    }
}

// MARK: - UIKit 文件选择器

struct VideoDocumentPicker: UIViewControllerRepresentable {
    let onPick: ([URL]) -> Void

    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        let picker = UIDocumentPickerViewController(forOpeningContentTypes: ImportStore.supportedVideoTypes, asCopy: true)
        picker.allowsMultipleSelection = false
        picker.delegate = context.coordinator
        picker.shouldShowFileExtensions = true
        picker.modalPresentationStyle = .formSheet
        return picker
    }

    func updateUIViewController(_ uiViewController: UIDocumentPickerViewController, context: Context) {}

    func makeCoordinator() -> Coordinator {
        Coordinator(onPick: onPick)
    }

    final class Coordinator: NSObject, UIDocumentPickerDelegate {
        let onPick: ([URL]) -> Void

        init(onPick: @escaping ([URL]) -> Void) {
            self.onPick = onPick
        }

        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            DispatchQueue.main.async {
                self.onPick(urls)
            }
        }

        func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
            DispatchQueue.main.async {
                self.onPick([])
            }
        }
    }
}

// MARK: - Native Liquid Glass helpers

private struct LiquidGlassRoot<Content: View>: View {
    let spacing: CGFloat
    let content: Content

    init(spacing: CGFloat = 18, @ViewBuilder content: () -> Content) {
        self.spacing = spacing
        self.content = content()
    }

    var body: some View {
        if #available(iOS 26.0, *) {
            GlassEffectContainer(spacing: spacing) {
                content
            }
        } else {
            content
        }
    }
}

private extension View {
    @ViewBuilder
    func liquidGlassCard(cornerRadius: CGFloat) -> some View {
        if #available(iOS 26.0, *) {
            self
                .glassEffect(.regular, in: .rect(cornerRadius: cornerRadius))
        } else {
            self
                .background(.regularMaterial, in: RoundedRectangle(cornerRadius: cornerRadius, style: .continuous))
        }
    }

    @ViewBuilder
    func liquidGlassCapsule() -> some View {
        if #available(iOS 26.0, *) {
            self
                .glassEffect(.regular, in: .capsule)
        } else {
            self
                .background(.quaternary, in: Capsule())
        }
    }

    @ViewBuilder
    func liquidGlassCircle() -> some View {
        if #available(iOS 26.0, *) {
            self
                .glassEffect(.regular, in: .circle)
        } else {
            self
                .background(.quaternary, in: Circle())
        }
    }

    @ViewBuilder
    func liquidGlassTextField(cornerRadius: CGFloat) -> some View {
        if #available(iOS 26.0, *) {
            self
                .padding(.horizontal, 12)
                .padding(.vertical, 9)
                .glassEffect(.regular, in: .rect(cornerRadius: cornerRadius))
        } else {
            self
                .padding(.horizontal, 12)
                .padding(.vertical, 9)
                .background(.thinMaterial, in: RoundedRectangle(cornerRadius: cornerRadius, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
                        .strokeBorder(.quaternary, lineWidth: 0.7)
                )
        }
    }

    @ViewBuilder
    func liquidGlassButtonStyle(prominent: Bool) -> some View {
        if #available(iOS 26.0, *) {
            self
                .buttonStyle(.glass)
                .controlSize(.large)
        } else {
            if prominent {
                self
                    .buttonStyle(.borderedProminent)
                    .controlSize(.large)
            } else {
                self
                    .buttonStyle(.bordered)
                    .controlSize(.large)
            }
        }
    }
}

private extension Array {
    subscript(safe index: Int) -> Element? {
        guard indices.contains(index) else { return nil }
        return self[index]
    }
}
