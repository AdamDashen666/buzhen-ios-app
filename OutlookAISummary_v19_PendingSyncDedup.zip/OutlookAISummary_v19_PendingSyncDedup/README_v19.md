# OutlookAISummary v19

## 修复内容

- 云端同步新增本地去重，避免 `/summaries/pending` 反复返回同一条总结时重复保存历史卡片。
- `LocalSummaryRecord` 新增：
  - `backendSummaryId`
  - `fallbackDeduplicationKey`
- 同步流程现在会先检查：
  - 后端 summary id 是否已存在；
  - 如果 id 缺失，则用 `startTime + endTime + summary hash` 兜底判断是否重复。
- 已存在的总结会跳过：
  - 不重新保存文字总结；
  - 不重新生成 PDF。
- 新保存成功或已存在的云端总结会在处理完成后统一调用 `/summaries/mark-synced`。
- PDF 生成失败不会丢失文字总结，仍可同步标记，历史详情页继续支持重新生成 PDF。
- 同步 UI 增加重复跳过提示，例如：
  - `已同步 1 / 3`
  - `已跳过重复 1 条`

## 保持不变

- 不请求 `/config`
- 不保存 AI_MODEL / AI_BASE_URL / AI_API_KEY
- 不向后端发送 aiModel / aiBaseUrl / aiApiKey
- QQ IMAP 状态继续使用 `/imap/test`
- 测试 AI 模型继续使用 `/ai/test`
- 测试总结继续使用 `/summarize/run mode=test latestCount=3`
