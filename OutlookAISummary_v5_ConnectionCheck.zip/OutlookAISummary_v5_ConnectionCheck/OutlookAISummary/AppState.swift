import Foundation
import SwiftUI
import UserNotifications
import UIKit

@MainActor
final class AppState: ObservableObject {
    @Published var backendURL: String {
        didSet {
            UserDefaults.standard.set(backendURL, forKey: "backendURL")
            api.baseURL = backendURL.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        }
    }
    @Published var linkedUser: LinkedUser?
    @Published var summaries: [SummaryItem] = []
    @Published var settings = AppSettings()
    @Published var backendHealth: BackendHealthResponse?
    @Published var imapStatus: IMAPTestResponse?
    @Published var connectionStatus = "未检查后端连接"
    @Published var isLoading = false
    @Published var statusText = "未连接"
    @Published var lastError: String?
    @Published var pushToken: String?

    let deviceId: String
    let api: APIClient

    init() {
        let storedBackend = UserDefaults.standard.string(forKey: "backendURL")?.trimmingCharacters(in: .whitespacesAndNewlines)
        let savedBackend = (storedBackend?.isEmpty == false) ? storedBackend! : "https://outlook-ai-backend.onrender.com"
        self.backendURL = savedBackend
        self.api = APIClient(baseURL: savedBackend)
        if let savedDeviceId = UserDefaults.standard.string(forKey: "deviceId") {
            self.deviceId = savedDeviceId
        } else {
            let newId = UUID().uuidString
            UserDefaults.standard.set(newId, forKey: "deviceId")
            self.deviceId = newId
        }
    }

    func bootstrap() async {
        await registerDevice()
        await refreshAll()
    }

    var backendValidationMessage: String? {
        let raw = backendURL.trimmingCharacters(in: .whitespacesAndNewlines)
        if raw.isEmpty {
            return "先到设置里填写后端地址。真机需要 HTTPS 后端地址，不能直接用 localhost。"
        }
        guard let components = URLComponents(string: raw),
              let scheme = components.scheme?.lowercased(),
              let host = components.host?.lowercased(),
              ["http", "https"].contains(scheme) else {
            return "后端地址格式不正确。示例：https://你的后端域名"
        }

        #if targetEnvironment(simulator)
        return nil
        #else
        if host == "localhost" || host == "127.0.0.1" || host == "::1" {
            return "真机里的 localhost 是 iPad/iPhone 自己，不是后端服务器。请填部署后的 HTTPS 地址，或用 ngrok/Cloudflare Tunnel 暴露本地后端。"
        }
        return nil
        #endif
    }

    func registerDevice() async {
        guard backendValidationMessage == nil else {
            statusText = "请先配置后端地址"
            return
        }
        do {
            _ = try await api.registerDevice(deviceId: deviceId, deviceToken: pushToken)
        } catch {
            lastError = error.localizedDescription
        }
    }

    func refreshAll() async {
        await refreshBackendConnection()
        if let message = backendValidationMessage {
            linkedUser = nil
            statusText = "请先配置后端地址"
            lastError = message
            return
        }
        isLoading = true
        defer { isLoading = false }
        do {
            let status = try await api.authStatus(deviceId: deviceId)
            if status.linked {
                linkedUser = status.user
                statusText = status.user?.email ?? imapStatus?.account ?? "已连接"
                if let remoteSettings = status.user?.settings {
                    settings = remoteSettings
                }
                let response = try await api.summaries(deviceId: deviceId)
                summaries = response.summaries
            } else if imapStatus?.ok == true {
                linkedUser = LinkedUser(displayName: "QQ 邮箱", email: imapStatus?.account, settings: settings, lastRunAt: nil)
                statusText = imapStatus?.account ?? "QQ 邮箱已连接"
            } else {
                linkedUser = nil
                statusText = "未连接邮箱"
            }
            lastError = nil
        } catch {
            lastError = error.localizedDescription
        }
    }

    func refreshBackendConnection() async {
        if let message = backendValidationMessage {
            connectionStatus = "后端地址无效"
            lastError = message
            return
        }

        do {
            let health = try await api.health()
            backendHealth = health

            let imap = try await api.imapTest()
            imapStatus = imap

            if health.ok && imap.ok {
                connectionStatus = "后端正常，QQ 邮箱 IMAP 已连接"
                statusText = imap.account ?? "QQ 邮箱已连接"
                lastError = nil
            } else if health.ok {
                connectionStatus = "后端正常，但 QQ 邮箱未连接"
                lastError = imap.error ?? "IMAP 测试未通过"
            } else {
                connectionStatus = "后端异常"
                lastError = "后端健康检查失败"
            }
        } catch {
            backendHealth = nil
            imapStatus = nil
            connectionStatus = "无法连接后端"
            lastError = error.localizedDescription
        }
    }

    func openMailConnectionInfo() {
        if let message = backendValidationMessage {
            lastError = message
            return
        }
        guard let url = api.authStartURL(deviceId: deviceId) else {
            lastError = "后端连接说明地址生成失败。请检查后端地址。"
            return
        }
        UIApplication.shared.open(url)
    }

    func saveSettings() async {
        if let message = backendValidationMessage {
            lastError = message
            return
        }
        isLoading = true
        defer { isLoading = false }
        do {
            let response = try await api.updateSettings(deviceId: deviceId, settings: settings)
            settings = response.settings
            lastError = nil
            await refreshAll()
        } catch {
            lastError = error.localizedDescription
        }
    }

    func runNow() async {
        if let message = backendValidationMessage {
            lastError = message
            return
        }
        isLoading = true
        defer { isLoading = false }
        do {
            let response = try await api.runNow(deviceId: deviceId)
            if let summary = response.summary {
                summaries.insert(summary, at: 0)
            }
            lastError = nil
        } catch {
            lastError = error.localizedDescription
        }
    }

    func requestNotifications() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .badge, .sound]) { granted, error in
            DispatchQueue.main.async {
                if let error { self.lastError = error.localizedDescription }
                if granted { UIApplication.shared.registerForRemoteNotifications() }
            }
        }
    }

    func updatePushToken(_ token: String) {
        pushToken = token
        Task { await registerDevice() }
    }
}
