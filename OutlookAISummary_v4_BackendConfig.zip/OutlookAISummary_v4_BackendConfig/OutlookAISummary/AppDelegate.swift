import UIKit

final class AppDelegate: NSObject, UIApplicationDelegate {
    func application(_ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
        let token = deviceToken.map { String(format: "%02x", $0) }.joined()
        NotificationCenter.default.post(name: .didReceivePushToken, object: token)
    }

    func application(_ application: UIApplication, didFailToRegisterForRemoteNotificationsWithError error: Error) {
        NotificationCenter.default.post(name: .didFailPushToken, object: error.localizedDescription)
    }
}

extension Notification.Name {
    static let didReceivePushToken = Notification.Name("didReceivePushToken")
    static let didFailPushToken = Notification.Name("didFailPushToken")
}
