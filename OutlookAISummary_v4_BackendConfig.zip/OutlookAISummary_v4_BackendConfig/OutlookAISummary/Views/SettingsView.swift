import SwiftUI

struct SettingsView: View {
    @EnvironmentObject private var state: AppState

    var body: some View {
        ZStack {
            LiquidBackground()
            ScrollView {
                VStack(spacing: 18) {
                    SectionTitle(title: "设置", subtitle: "默认中文总结；AI 模型与接口从后端自动读取。")

                    backendCard
                    scheduleCard
                    cleanupCard
                    aiCard
                    saveCard
                }
                .padding()
                .frame(maxWidth: 860)
                .frame(maxWidth: .infinity)
            }
        }
        .navigationTitle("设置")
    }

    private var backendCard: some View {
        GlassCard {
            VStack(alignment: .leading, spacing: 12) {
                SectionTitle(title: "后端地址", subtitle: "真机不能用 localhost。推荐填部署后的 HTTPS 地址。")
                TextField("https://your-backend.example.com", text: $state.backendURL)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .keyboardType(.URL)
                    .padding(14)
                    .background(.white.opacity(0.10), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                if let warning = state.backendValidationMessage {
                    Text(warning)
                        .font(.footnote)
                        .foregroundStyle(.orange)
                        .textSelection(.enabled)
                }
            }
        }
    }

    private var scheduleCard: some View {
        GlassCard {
            VStack(alignment: .leading, spacing: 12) {
                SectionTitle(title: "总结频率", subtitle: "后端定时执行，完成后推送到 App。")
                Picker("频率", selection: $state.settings.frequency) {
                    ForEach(SummaryFrequency.allCases) { frequency in
                        Text(frequency.title).tag(frequency)
                    }
                }
                .pickerStyle(.segmented)

                Toggle("启用自动总结", isOn: $state.settings.enabled)
                    .toggleStyle(.switch)
                Toggle("包含转发邮件解析", isOn: $state.settings.includeJunkUnread)
                    .disabled(true)
                HStack {
                    Text("总结语言")
                    Spacer()
                    Text("中文")
                        .foregroundStyle(.secondary)
                }
            }
        }
    }

    private var cleanupCard: some View {
        GlassCard {
            VStack(alignment: .leading, spacing: 12) {
                SectionTitle(title: "自动清理", subtitle: "默认仅标记已读；如配置 IMAP_TRASH_MAILBOX 才会移动旧邮件。")
                Toggle("清理 QQ 邮箱已总结邮件", isOn: $state.settings.autoDeleteEnabled)
                    .toggleStyle(.switch)
                Stepper("已读/已总结超过 \(state.settings.deleteAfterDays) 天后删除", value: $state.settings.deleteAfterDays, in: 7...365)
                Stepper("删除邮件中保留 \(state.settings.permanentDeleteAfterDays) 天", value: $state.settings.permanentDeleteAfterDays, in: 1...60)

                Text("风险：开启并配置 IMAP_TRASH_MAILBOX 后会影响真实 QQ 邮箱。建议先用小号测试。")
                    .font(.footnote)
                    .foregroundStyle(.orange)
            }
        }
    }

    private var aiCard: some View {
        GlassCard {
            VStack(alignment: .leading, spacing: 12) {
                SectionTitle(title: "后端 AI 配置", subtitle: "AI 密钥只保存在 Render 环境变量；App 只显示模型和接口。")

                if let config = state.backendConfig {
                    infoRow("AI 模型", config.ai.model ?? "未配置")
                    infoRow("AI 接口", config.ai.baseUrl ?? "未配置")
                    infoRow("密钥状态", config.ai.configured == true ? "Render 已配置" : "Render 未配置")
                    infoRow("邮件模式", config.provider)
                    infoRow("邮箱", config.mail.email ?? "未返回")
                } else {
                    Text(state.backendConfigStatus)
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }

                Button {
                    Task { await state.refreshBackendConfig() }
                } label: {
                    Label("刷新后端配置", systemImage: "arrow.clockwise")
                }
                .buttonStyle(PrimaryButtonStyle())
            }
        }
    }

    private func infoRow(_ title: String, _ value: String) -> some View {
        HStack(alignment: .top) {
            Text(title)
                .foregroundStyle(.secondary)
                .frame(width: 86, alignment: .leading)
            Text(value)
                .frame(maxWidth: .infinity, alignment: .leading)
                .textSelection(.enabled)
        }
        .font(.footnote)
    }

    private var saveCard: some View {
        VStack(spacing: 12) {
            Button {
                Task { await state.saveSettings() }
            } label: {
                Label("保存设置", systemImage: "checkmark.circle.fill")
            }
            .buttonStyle(PrimaryButtonStyle())

            Button {
                Task { await state.refreshAll() }
            } label: {
                Label("刷新状态", systemImage: "arrow.clockwise")
            }
            .buttonStyle(PrimaryButtonStyle())
        }
    }
}
