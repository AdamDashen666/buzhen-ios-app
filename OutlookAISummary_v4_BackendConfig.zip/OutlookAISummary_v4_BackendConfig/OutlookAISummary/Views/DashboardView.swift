import SwiftUI

struct DashboardView: View {
    @EnvironmentObject private var state: AppState

    var body: some View {
        ZStack {
            LiquidBackground()
            ScrollView {
                VStack(spacing: 18) {
                    header
                    if let warning = state.backendValidationMessage {
                        backendWarningCard(warning)
                    }
                    statusCard
                    backendInfoCard
                    if state.linkedUser != nil {
                        controlCard
                        summariesList
                    } else {
                        loginCard
                    }
                    if let error = state.lastError, !error.isEmpty {
                        errorCard(error)
                    }
                }
                .padding()
                .frame(maxWidth: 860)
                .frame(maxWidth: .infinity)
            }
            .refreshable { await state.refreshAll() }
        }
        .navigationTitle("总览")
        .toolbar {
            Button("刷新") { Task { await state.refreshAll() } }
        }
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Mail AI Summary")
                .font(.largeTitle.bold())
            Text("自动总结转发到 QQ 邮箱的未读邮件；默认中文推送。")
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }


    private func backendWarningCard(_ message: String) -> some View {
        GlassCard {
            VStack(alignment: .leading, spacing: 10) {
                Label("需要先配置后端", systemImage: "server.rack")
                    .font(.headline)
                Text(message)
                    .font(.footnote)
                    .textSelection(.enabled)
                Text("设置 → 后端地址：填 Render/Railway/Vercel/自建服务器的 HTTPS 地址。")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
            }
            .foregroundStyle(.orange.opacity(0.95))
        }
    }

    private var statusCard: some View {
        GlassCard {
            VStack(alignment: .leading, spacing: 14) {
                HStack {
                    Image(systemName: state.linkedUser == nil ? "link.badge.plus" : "checkmark.seal.fill")
                        .font(.title2)
                    VStack(alignment: .leading, spacing: 3) {
                        Text(state.linkedUser == nil ? "未连接邮箱" : "已连接")
                            .font(.headline)
                        Text(state.statusText)
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                    }
                    Spacer()
                    if state.isLoading { ProgressView().tint(.white) }
                }
                HStack(spacing: 8) {
                    CapsuleTag(text: state.settings.frequency.title, systemImage: "clock")
                    CapsuleTag(text: "中文", systemImage: "textformat")
                    CapsuleTag(text: state.backendConfig?.provider ?? "后端未读", systemImage: "server.rack")
                    CapsuleTag(text: state.backendConfig?.ai.model ?? state.settings.aiModel, systemImage: "cpu")
                }
            }
        }
    }


    private var backendInfoCard: some View {
        GlassCard {
            VStack(alignment: .leading, spacing: 14) {
                HStack {
                    SectionTitle(title: "后端配置", subtitle: "从 Render 后端自动读取；不在 App 手动填写 AI 密钥。")
                    Spacer()
                    Button {
                        Task { await state.refreshBackendConfig() }
                    } label: {
                        Image(systemName: "arrow.clockwise")
                            .font(.headline)
                    }
                }

                if let config = state.backendConfig {
                    VStack(alignment: .leading, spacing: 8) {
                        infoRow("邮件模式", config.provider)
                        infoRow("邮箱", config.mail.email ?? "未返回")
                        infoRow("IMAP", config.mail.host ?? "未返回")
                        infoRow("AI 模型", config.ai.model ?? "未配置")
                        infoRow("AI 接口", config.ai.baseUrl ?? "未配置")
                        infoRow("AI 密钥", config.ai.configured == true ? "Render 已配置" : "Render 未配置")
                    }
                    .font(.footnote)
                    .textSelection(.enabled)
                } else {
                    Text(state.backendConfigStatus)
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
            }
        }
    }

    private func infoRow(_ title: String, _ value: String) -> some View {
        HStack(alignment: .top) {
            Text(title)
                .foregroundStyle(.secondary)
                .frame(width: 76, alignment: .leading)
            Text(value)
                .frame(maxWidth: .infinity, alignment: .leading)
        }
    }

    private var loginCard: some View {
        GlassCard {
            VStack(alignment: .leading, spacing: 14) {
                SectionTitle(title: "连接邮箱后端", subtitle: "QQ 邮箱模式不需要 Microsoft 登录；后端使用 QQ 邮箱授权码读取 IMAP。")
                Button {
                    state.openMailConnectionInfo()
                } label: {
                    Label("查看连接说明", systemImage: "person.crop.circle.badge.checkmark")
                }
                .buttonStyle(PrimaryButtonStyle())
                .disabled(state.backendValidationMessage != nil)
                .opacity(state.backendValidationMessage == nil ? 1 : 0.45)

                Button {
                    Task { await state.refreshAll() }
                } label: {
                    Label("我已配置，检查状态", systemImage: "arrow.clockwise")
                }
                .buttonStyle(PrimaryButtonStyle())
            }
        }
    }

    private var controlCard: some View {
        GlassCard {
            VStack(alignment: .leading, spacing: 14) {
                SectionTitle(title: "手动总结", subtitle: "立即拉取 QQ 邮箱收件箱里的未读邮件，并解析 Outlook 转发信息。")
                Button {
                    Task { await state.runNow() }
                } label: {
                    Label("现在总结一次", systemImage: "sparkles")
                }
                .buttonStyle(PrimaryButtonStyle())

                Button {
                    state.requestNotifications()
                } label: {
                    Label("开启推送通知", systemImage: "bell.badge.fill")
                }
                .buttonStyle(PrimaryButtonStyle())
            }
        }
    }

    private var summariesList: some View {
        VStack(alignment: .leading, spacing: 12) {
            SectionTitle(title: "历史总结", subtitle: state.summaries.isEmpty ? "暂无总结。" : nil)
            ForEach(state.summaries) { summary in
                GlassCard {
                    VStack(alignment: .leading, spacing: 12) {
                        HStack {
                            Text(summary.title)
                                .font(.headline)
                            Spacer()
                            Text(summary.createdAt.shortDisplayDate)
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                        HStack(spacing: 8) {
                            CapsuleTag(text: "未读 \(summary.unreadCount)", systemImage: "envelope.badge")
                            CapsuleTag(text: "转发 \(summary.junkUnreadCount)", systemImage: "trash")
                        }
                        Text(summary.content)
                            .font(.body)
                            .textSelection(.enabled)
                    }
                }
            }
        }
    }

    private func errorCard(_ message: String) -> some View {
        GlassCard {
            VStack(alignment: .leading, spacing: 8) {
                Label("错误", systemImage: "exclamationmark.triangle.fill")
                    .font(.headline)
                Text(message)
                    .font(.footnote)
                    .textSelection(.enabled)
            }
            .foregroundStyle(.red.opacity(0.9))
        }
    }
}

private extension String {
    var shortDisplayDate: String {
        let formatter = ISO8601DateFormatter()
        guard let date = formatter.date(from: self) else { return self }
        return date.formatted(date: .abbreviated, time: .shortened)
    }
}
