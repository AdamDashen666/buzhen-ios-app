# Outlook AI Summary v4 v3 QQ IMAP

This version changes the backend from Microsoft Graph OAuth to QQ Mail IMAP for the current workaround:

Outlook → forwarding/redirect rule → QQ Mail → backend IMAP reader → AI Chinese summary → iOS push/app history.

## What changed

- Removed the requirement for Azure/Microsoft app registration when `MAIL_PROVIDER=qq`.
- Added QQ Mail IMAP reader using `imap.qq.com:993`.
- Added forwarded-message parsing to recover original sender and subject from Outlook forwarded emails.
- Added `/imap/test` endpoint for checking mailbox connectivity.
- iOS UI text changed from Outlook OAuth wording to QQ IMAP wording.

## Render env variables

Use environment variables, not hardcoded secrets:

```text
MAIL_PROVIDER=qq
IMAP_HOST=imap.qq.com
IMAP_PORT=993
IMAP_SECURE=true
IMAP_USER=your_qq_email@qq.com
IMAP_PASS=your_qq_mail_authorization_code
AI_API_KEY=your_ai_key
AI_BASE_URL=https://api.openai.com/v1/chat/completions
AI_MODEL=gpt-4o-mini
```

After deploy, test:

```text
https://your-render-service.onrender.com/imap/test
```


## v4 更新

- App 默认使用 `https://outlook-ai-backend.onrender.com`。
- App 可通过“刷新后端配置”读取后端的邮件模式、IMAP 主机、AI 接口、AI 模型和密钥配置状态。
- AI API Key 不在 App 里填写，只放在 Render 环境变量。
- Backend 新增 `GET /config`，只返回安全配置，不返回密钥或 QQ 授权码。
