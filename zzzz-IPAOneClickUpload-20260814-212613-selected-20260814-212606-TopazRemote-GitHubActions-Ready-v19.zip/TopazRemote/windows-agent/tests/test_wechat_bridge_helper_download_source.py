from __future__ import annotations

import unittest
from pathlib import Path


class WeChatBridgeDownloadSourceTests(unittest.TestCase):
    def test_inspection_treats_a_missing_local_file_as_not_downloaded(self) -> None:
        source = (Path(__file__).resolve().parents[1] / "wechat-bridge" / "Program.cs").read_text(encoding="utf-8")
        start = source.index("private static BridgeResult InspectLatest")
        end = source.index("private static BridgeResult InspectSendControls", start)
        method = source[start:end]
        self.assertIn('new BridgeResult("not_downloaded", message.Filename)', method)
        self.assertIn("FindDownloaded(request.DownloadRoot, message.Filename, message.SizeBytes)", method)

    def test_download_retries_the_visible_latest_message_when_no_local_file_exists(self) -> None:
        source = (Path(__file__).resolve().parents[1] / "wechat-bridge" / "Program.cs").read_text(encoding="utf-8")
        start = source.index("private static BridgeResult DownloadLatest")
        end = source.index("private static BridgeResult? FindDownloaded", start)
        method = source[start:end]
        self.assertIn("var existing = FindDownloaded", method)
        self.assertIn("((InvokePattern)pattern).Invoke()", method)
        self.assertIn("Click(message.Item)", method)
        self.assertLess(method.index("var existing = FindDownloaded"), method.index("((InvokePattern)pattern).Invoke()"))
        self.assertLess(method.index("((InvokePattern)pattern).Invoke()"), method.index("Click(message.Item)"))
        self.assertLess(method.index("Activate(window)"), method.index("Click(message.Item)"))


if __name__ == "__main__":
    unittest.main()
