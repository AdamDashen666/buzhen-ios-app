from __future__ import annotations

import unittest
from pathlib import Path


class WeChatBridgeHelperSourceTests(unittest.TestCase):
    def test_pending_send_prefers_uia_invoke_over_coordinate_click(self) -> None:
        source = (Path(__file__).resolve().parents[1] / "wechat-bridge" / "Program.cs").read_text(encoding="utf-8")
        start = source.index("private static bool SendPendingFile")
        end = source.index("private static bool WaitForPendingFile", start)
        method = source[start:end]
        self.assertIn("((InvokePattern)invoke).Invoke()", method)
        self.assertIn("return Click(send)", method)
        self.assertLess(method.index("((InvokePattern)invoke).Invoke()"), method.index("return Click(send)"))

    def test_package_draft_retry_requires_the_named_pending_attachment(self) -> None:
        source = (Path(__file__).resolve().parents[1] / "wechat-bridge" / "Program.cs").read_text(encoding="utf-8")
        self.assertIn('"send-package-draft"', source)
        start = source.index("private static BridgeResult SendPackageDraft")
        end = source.index("private static BridgeResult SendFile", start)
        method = source[start:end]
        self.assertIn("!request.SkipPendingAttachmentCheck && !WaitForPendingFile(window, Path.GetFileName(path), 3)", method)
        self.assertLess(method.index("WaitForPendingFile(window, Path.GetFileName(path), 3)"), method.index("SendPendingFile(window)"))

    def test_manual_package_enter_send_uses_windows_input_injection(self) -> None:
        source = (Path(__file__).resolve().parents[1] / "wechat-bridge" / "Program.cs").read_text(encoding="utf-8")
        self.assertIn('"send-package-enter"', source)
        self.assertIn('"inspect-chat-inputs"', source)
        self.assertIn("private static extern uint SendInput", source)
        self.assertIn("private struct InputUnion", source)
        self.assertIn("public InputUnion Data", source)
        self.assertIn("private static bool PressEnter", source)
        start = source.index("private static BridgeResult SendFile")
        end = source.index("private static FilePicker? WaitForFilePicker", start)
        method = source[start:end]
        self.assertIn("if (submitWithEnter)", method)
        self.assertIn("PressEnter(window)", method)
        self.assertLess(method.index("PressEnter(window)"), method.index("SendPendingFile(window)"))

    def test_enter_injection_focuses_the_chat_composer_first(self) -> None:
        source = (Path(__file__).resolve().parents[1] / "wechat-bridge" / "Program.cs").read_text(encoding="utf-8")
        start = source.index("private static bool PressEnter")
        end = source.index("private static bool Click", start)
        method = source[start:end]
        self.assertIn("ChatComposer(window)", method)
        self.assertIn("composer.SetFocus()", method)
        self.assertIn('"chat_input_field"', source)
        self.assertIn("SendOutput(BridgeRequest request) => SendFile", source)
        self.assertIn("requirePendingAttachment: true, submitWithEnter: true", source)

    def test_package_attachment_confirms_the_file_picker_before_sending(self) -> None:
        source = (Path(__file__).resolve().parents[1] / "wechat-bridge" / "Program.cs").read_text(encoding="utf-8")
        start = source.index("private static BridgeResult SendFile")
        end = source.index("private static FilePicker? WaitForFilePicker", start)
        method = source[start:end]
        self.assertIn("ConfirmFilePickerSelection(picker)", method)
        self.assertIn("private static bool ConfirmFilePickerSelection", source)
        self.assertLess(method.index("ConfirmFilePickerSelection(picker)"), method.index("PressEnter(window)"))

    def test_programmatic_package_picker_sets_the_filename_value_directly(self) -> None:
        source = (Path(__file__).resolve().parents[1] / "wechat-bridge" / "Program.cs").read_text(encoding="utf-8")
        start = source.index("private static BridgeResult SendFile")
        end = source.index("private static FilePicker? WaitForFilePicker", start)
        method = source[start:end]
        self.assertIn("ValuePattern.Pattern", method)
        self.assertIn("((ValuePattern)value).SetValue(path)", method)
        self.assertLess(method.index("((ValuePattern)value).SetValue(path)"), method.index("ConfirmFilePickerSelection(picker)"))


if __name__ == "__main__":
    unittest.main()
