param(
    [int]$Port = 8123,
    [string]$DataDirectory = "$env:LOCALAPPDATA\TopazRemote",
    [string]$MediaDirectory = (Join-Path ([Environment]::GetFolderPath('Desktop')) (([char]0x8FDC).ToString() + ([char]0x7A0B).ToString() + 'topaz')),
    [string]$WeChatDownloadRoot = (Join-Path $env:USERPROFILE 'Documents\xwechat_files'),
    [switch]$EnableWeChatBridge
)

$scriptRoot = Split-Path -Parent $PSScriptRoot
$sourceRoot = Join-Path $scriptRoot "src"
if (-not (Test-Path -LiteralPath $sourceRoot)) { throw "Topaz Remote source folder not found: $sourceRoot" }
if ($Port -lt 1024 -or $Port -gt 65535) { throw "Port must be between 1024 and 65535." }
$env:PYTHONPATH = $sourceRoot
$arguments = @('--host','0.0.0.0','--port',$Port,'--data-dir',$DataDirectory,'--media-dir',$MediaDirectory)
if ($EnableWeChatBridge) {
    $bridge = Join-Path $scriptRoot 'wechat-bridge\bin\Release\net8.0-windows\TopazRemote.WeChatBridge.exe'
    if (-not (Test-Path -LiteralPath $bridge)) { throw "Build the WeChat bridge first: $bridge" }
    $arguments += @('--wechat-bridge',$bridge,'--wechat-download-root',$WeChatDownloadRoot)
}
python -m topazremote.main @arguments
