using System.Text.Json;
using System.IO;
using System.Text.RegularExpressions;
using System.Windows.Automation;
using System.Runtime.InteropServices;
using System.Windows.Forms;

record BridgeRequest(string Command, string? DownloadRoot, string? FilePath, string? MediaRoot = null, string? PackageRoot = null, int TimeoutSeconds = 120, bool SkipPendingAttachmentCheck = false);
record BridgeResult(string State, string? Filename = null, string? FilePath = null, string? Error = null);
record FileMessage(AutomationElement Item, string Filename, long? SizeBytes);

static class Program
{
    [DllImport("user32.dll")]
    private static extern bool SetForegroundWindow(IntPtr hWnd);
    [DllImport("user32.dll")]
    private static extern bool SetCursorPos(int x, int y);
    [DllImport("user32.dll")]
    private static extern void mouse_event(uint flags, uint dx, uint dy, uint data, UIntPtr extraInfo);
    [DllImport("user32.dll", SetLastError = true)]
    private static extern uint SendInput(uint inputCount, INPUT[] inputs, int inputSize);

    [StructLayout(LayoutKind.Sequential)]
    private struct INPUT
    {
        public uint Type;
        public InputUnion Data;
    }

    [StructLayout(LayoutKind.Explicit)]
    private struct InputUnion
    {
        [FieldOffset(0)] public MOUSEINPUT Mouse;
        [FieldOffset(0)] public KEYBDINPUT Keyboard;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct MOUSEINPUT
    {
        public int X;
        public int Y;
        public uint MouseData;
        public uint Flags;
        public uint Time;
        public IntPtr ExtraInfo;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct KEYBDINPUT
    {
        public ushort VirtualKey;
        public ushort ScanCode;
        public uint Flags;
        public uint Time;
        public IntPtr ExtraInfo;
    }

    private static readonly JsonSerializerOptions Json = new() { PropertyNamingPolicy = JsonNamingPolicy.CamelCase };
    private static readonly HashSet<string> Commands = new(StringComparer.Ordinal) { "inspect-latest", "inspect-latest-video-controls", "download-latest", "send-output", "send-package", "send-package-draft", "send-package-enter", "inspect-send-controls", "inspect-chat-inputs", "inspect-file-picker", "open-file-picker", "verify-file" };
    private static readonly string[] VideoExtensions = [".mp4", ".mov", ".m4v", ".mkv", ".avi", ".webm"];
    private const string WeChat = "\u5fae\u4fe1";
    private const string Assistant = "\u6587\u4ef6\u4f20\u8f93\u52a9\u624b";
    private const string NotDownloaded = "\u672a\u4e0b\u8f7d";
    private const string SendFileButton = "\u53d1\u9001\u6587\u4ef6";
    private const string Open = "\u6253\u5f00";

    [STAThread]
    static int Main()
    {
        try
        {
            var line = Console.In.ReadLine();
            var request = line is null ? null : JsonSerializer.Deserialize<BridgeRequest>(line, Json);
            if (request is null || !Commands.Contains(request.Command)) return Write(new BridgeResult("ui_changed", Error: "A supported bridge command is required."));
            if (request.TimeoutSeconds is < 1 or > 300) return Write(new BridgeResult("ui_changed", Error: "timeoutSeconds must be between 1 and 300."));
            if (request.Command == "send-output" && (string.IsNullOrWhiteSpace(request.FilePath) || string.IsNullOrWhiteSpace(request.MediaRoot))) return Write(new BridgeResult("send_failed", Error: "filePath and mediaRoot are required for send-output."));
            if ((request.Command is "send-package" or "send-package-draft" or "send-package-enter") && (string.IsNullOrWhiteSpace(request.FilePath) || string.IsNullOrWhiteSpace(request.PackageRoot))) return Write(new BridgeResult("send_failed", Error: "filePath and packageRoot are required for package sending."));
            if (request.Command == "verify-file" && string.IsNullOrWhiteSpace(request.FilePath)) return Write(new BridgeResult("ui_changed", Error: "filePath is required for verify-file."));
            return request.Command switch
            {
                "inspect-latest" => Write(InspectLatest(request)),
                "inspect-latest-video-controls" => Write(InspectLatestVideoControls()),
                "download-latest" => Write(DownloadLatest(request)),
                "send-output" => Write(SendOutput(request)),
                "send-package" => Write(SendPackage(request)),
                "send-package-draft" => Write(SendPackageDraft(request)),
                "send-package-enter" => Write(SendPackageWithEnter(request)),
                "inspect-send-controls" => Write(InspectSendControls()),
                "inspect-chat-inputs" => Write(InspectChatInputs()),
                "inspect-file-picker" => Write(InspectFilePicker()),
                "open-file-picker" => Write(OpenFilePicker()),
                "verify-file" => Write(VerifyFile(request)),
                _ => Write(new BridgeResult("ui_changed", Error: "Unsupported command.")),
            };
        }
        catch (JsonException) { return Write(new BridgeResult("ui_changed", Error: "Request must be one JSON object.")); }
        catch (Exception error) { return Write(new BridgeResult("ui_changed", Error: error.Message)); }
    }

    private static int Write(BridgeResult result) { Console.Out.WriteLine(JsonSerializer.Serialize(result, Json)); return 0; }

    private static BridgeResult InspectLatest(BridgeRequest request)
    {
        var window = WeChatWindow();
        if (window is null) return new BridgeResult("wechat_not_logged_in", Error: "No logged-in WeChat desktop window was found.");
        var selected = SelectAssistant(window);
        if (selected is not null) return selected;
        var message = LatestVideo(window);
        if (message is null) return new BridgeResult("not_found", Error: "No eligible video is visible in File Transfer Assistant.");
        if (message.Item.Current.Name.Contains(NotDownloaded, StringComparison.Ordinal)) return new BridgeResult("not_downloaded", message.Filename);
        if (!string.IsNullOrWhiteSpace(request.DownloadRoot) && Directory.Exists(request.DownloadRoot)) return FindDownloaded(request.DownloadRoot, message.Filename, message.SizeBytes) ?? new BridgeResult("not_downloaded", message.Filename);
        return new BridgeResult("download_failed", message.Filename, Error: "WeChat download root is unavailable.");
    }

    private static BridgeResult InspectSendControls()
    {
        var window = WeChatWindow();
        if (window is null) return new BridgeResult("wechat_not_logged_in", Error: "No logged-in WeChat desktop window was found.");
        var selected = SelectAssistant(window);
        if (selected is not null) return selected;
        var buttons = window.FindAll(TreeScope.Subtree, new PropertyCondition(AutomationElement.ControlTypeProperty, ControlType.Button));
        var values = buttons.Cast<AutomationElement>()
            .Where(button => button.Current.Name.Contains("\u53d1\u9001", StringComparison.Ordinal) || button.Current.Name.Contains("\u6587\u4ef6", StringComparison.Ordinal))
            .Take(8)
            .Select(button => $"name={button.Current.Name};id={button.Current.AutomationId};invoke={button.TryGetCurrentPattern(InvokePattern.Pattern, out _)}")
            .ToArray();
        return new BridgeResult("ready", Error: values.Length == 0 ? "No matching send/file buttons were exposed." : string.Join(" | ", values));
    }

    private static BridgeResult InspectLatestVideoControls()
    {
        var window = WeChatWindow();
        if (window is null) return new BridgeResult("wechat_not_logged_in", Error: "No logged-in WeChat desktop window was found.");
        var selected = SelectAssistant(window);
        if (selected is not null) return selected;
        var message = LatestVideo(window);
        if (message is null) return new BridgeResult("not_found", Error: "No eligible video is visible in File Transfer Assistant.");
        var controls = message.Item.FindAll(TreeScope.Descendants, Condition.TrueCondition).Cast<AutomationElement>()
            .Select(element => $"type={element.Current.ControlType.ProgrammaticName};name={element.Current.Name};id={element.Current.AutomationId};class={element.Current.ClassName};invoke={element.TryGetCurrentPattern(InvokePattern.Pattern, out _)}")
            .Where(value => !string.IsNullOrWhiteSpace(value))
            .Take(48)
            .ToArray();
        return new BridgeResult("ready", message.Filename, Error: string.Join(" | ", controls));
    }

    private static BridgeResult InspectChatInputs()
    {
        var window = WeChatWindow();
        if (window is null) return new BridgeResult("wechat_not_logged_in", Error: "No logged-in WeChat desktop window was found.");
        var selected = SelectAssistant(window);
        if (selected is not null) return selected;
        var edits = window.FindAll(TreeScope.Subtree, new PropertyCondition(AutomationElement.ControlTypeProperty, ControlType.Edit)).Cast<AutomationElement>()
            .Select(edit => $"name={edit.Current.Name};id={edit.Current.AutomationId};class={edit.Current.ClassName};enabled={edit.Current.IsEnabled};offscreen={edit.Current.IsOffscreen};bounds={edit.Current.BoundingRectangle}")
            .Take(12)
            .ToArray();
        return new BridgeResult("ready", Error: edits.Length == 0 ? "No editable chat controls were exposed." : string.Join(" | ", edits));
    }

    private static BridgeResult InspectFilePicker()
    {
        var window = WeChatWindow();
        if (window is null) return new BridgeResult("wechat_not_logged_in", Error: "No logged-in WeChat desktop window was found.");
        var newFolder = window.FindAll(TreeScope.Subtree, new PropertyCondition(AutomationElement.ControlTypeProperty, ControlType.Button)).Cast<AutomationElement>()
            .FirstOrDefault(button => button.Current.Name.Contains("\u65b0\u5efa", StringComparison.Ordinal) && button.Current.Name.Contains("\u6587\u4ef6\u5939", StringComparison.Ordinal));
        if (newFolder is null) return new BridgeResult("not_found", Error: "No embedded file picker is currently visible.");
        var current = newFolder;
        var walker = TreeWalker.ControlViewWalker;
        var descriptions = new List<string>();
        for (var index = 0; index < 5 && current is not null; index++)
        {
            var buttons = current.FindAll(TreeScope.Descendants, new PropertyCondition(AutomationElement.ControlTypeProperty, ControlType.Button)).Cast<AutomationElement>()
                .Select(button => $"{button.Current.Name}/{button.Current.AutomationId}/enabled={button.Current.IsEnabled}").Where(value => !string.IsNullOrWhiteSpace(value)).Take(24);
            var edits = current.FindAll(TreeScope.Descendants, new PropertyCondition(AutomationElement.ControlTypeProperty, ControlType.Edit)).Cast<AutomationElement>()
                .Select(edit => $"{edit.Current.Name}/{edit.Current.AutomationId}/value={edit.TryGetCurrentPattern(ValuePattern.Pattern, out _)}").Take(24);
            descriptions.Add($"level={index};type={current.Current.ControlType.ProgrammaticName};name={current.Current.Name};id={current.Current.AutomationId};class={current.Current.ClassName};buttons=[{string.Join(',', buttons)}];edits=[{string.Join(',', edits)}]");
            current = walker.GetParent(current);
        }
        return new BridgeResult("ready", Error: string.Join(" | ", descriptions));
    }

    private static BridgeResult VerifyFile(BridgeRequest request)
    {
        var window = WeChatWindow();
        if (window is null) return new BridgeResult("wechat_not_logged_in", Error: "No logged-in WeChat desktop window was found.");
        var selected = SelectAssistant(window);
        if (selected is not null) return selected;
        var filename = Path.GetFileName(request.FilePath!);
        var messages = MatchingMessageNames(window, filename);
        return messages.Length > 0
            ? new BridgeResult("sent", filename, Error: string.Join(" | ", messages))
            : new BridgeResult("not_found", filename, Error: "No matching File Transfer Assistant message is visible.");
    }

    private static BridgeResult OpenFilePicker()
    {
        var window = WeChatWindow();
        if (window is null) return new BridgeResult("wechat_not_logged_in", Error: "No logged-in WeChat desktop window was found.");
        var selected = SelectAssistant(window);
        if (selected is not null) return selected;
        var button = window.FindFirst(TreeScope.Subtree, new AndCondition(new PropertyCondition(AutomationElement.ControlTypeProperty, ControlType.Button), new PropertyCondition(AutomationElement.NameProperty, SendFileButton)));
        if (button is null || !button.TryGetCurrentPattern(InvokePattern.Pattern, out var invoke)) return new BridgeResult("ui_changed", Error: "WeChat Send File button is unavailable.");
        Activate(window);
        ((InvokePattern)invoke).Invoke();
        if (WaitForFilePicker(3) is not null || (Click(button) && WaitForFilePicker(7) is not null)) return new BridgeResult("ready", Error: "File picker is open for read-only inspection.");
        return new BridgeResult("send_failed", Error: "WeChat file picker did not open.");
    }

    private static AutomationElement? WeChatWindow()
    {
        var windows = AutomationElement.RootElement.FindAll(
            TreeScope.Children,
            new AndCondition(
                new PropertyCondition(AutomationElement.ControlTypeProperty, ControlType.Window),
                new PropertyCondition(AutomationElement.NameProperty, WeChat)));
        return windows.Cast<AutomationElement>()
            .Where(window => !window.Current.IsOffscreen && window.Current.NativeWindowHandle != 0)
            .Where(window => !window.Current.BoundingRectangle.IsEmpty && window.Current.BoundingRectangle.Width > 100 && window.Current.BoundingRectangle.Height > 100)
            .OrderByDescending(window => window.Current.BoundingRectangle.Width * window.Current.BoundingRectangle.Height)
            .FirstOrDefault();
    }

    private static BridgeResult? SelectAssistant(AutomationElement window)
    {
        var assistant = window.FindFirst(TreeScope.Subtree, new PropertyCondition(AutomationElement.AutomationIdProperty, "session_item_" + Assistant));
        if (assistant is null || !assistant.TryGetCurrentPattern(InvokePattern.Pattern, out var select)) return new BridgeResult("ui_changed", Error: "File Transfer Assistant selection is unavailable.");
        ((InvokePattern)select).Invoke();
        var until = DateTime.UtcNow.AddSeconds(3);
        while (DateTime.UtcNow < until)
        {
            if (window.FindFirst(TreeScope.Subtree, new PropertyCondition(AutomationElement.AutomationIdProperty, "chat_message_list")) is not null) return null;
            Thread.Sleep(100);
        }
        return new BridgeResult("ui_changed", Error: "WeChat did not open File Transfer Assistant.");
    }

    private static FileMessage? LatestVideo(AutomationElement window)
    {
        var messages = window.FindFirst(TreeScope.Subtree, new PropertyCondition(AutomationElement.AutomationIdProperty, "chat_message_list"));
        if (messages is null) return null;
        var items = messages.FindAll(TreeScope.Subtree, new PropertyCondition(AutomationElement.ControlTypeProperty, ControlType.ListItem));
        for (var index = items.Count - 1; index >= 0; index--)
        {
            var match = Regex.Match(items[index].Current.Name ?? string.Empty, @"(?:\u6587\u4ef6|File)\s+(?<name>[^\r\n]+?\.(mp4|mov|m4v|mkv|avi|webm))\b", RegexOptions.IgnoreCase);
            if (match.Success) return new FileMessage(items[index], match.Groups["name"].Value, DisplayedFileSize(items[index].Current.Name ?? string.Empty));
        }
        return null;
    }

    private static BridgeResult DownloadLatest(BridgeRequest request)
    {
        if (string.IsNullOrWhiteSpace(request.DownloadRoot) || !Directory.Exists(request.DownloadRoot)) return new BridgeResult("download_failed", Error: "Configured WeChat download root does not exist.");
        var window = WeChatWindow();
        if (window is null) return new BridgeResult("wechat_not_logged_in", Error: "WeChat desktop window is unavailable in this interactive session.");
        var selected = SelectAssistant(window);
        if (selected is not null) return selected;
        var message = LatestVideo(window);
        if (message is null) return new BridgeResult("not_found", Error: "No eligible video is visible in File Transfer Assistant.");
        var existing = FindDownloaded(request.DownloadRoot, message.Filename, message.SizeBytes);
        if (existing is not null) return existing;
        if (!message.Item.TryGetCurrentPattern(InvokePattern.Pattern, out var pattern)) return new BridgeResult("ui_changed", message.Filename, Error: "The newest WeChat file has no invoke action.");
        var requestedAt = DateTime.UtcNow;
        ((InvokePattern)pattern).Invoke();
        Thread.Sleep(600);
        if (FindDownloaded(request.DownloadRoot, message.Filename, message.SizeBytes, requestedAt) is null)
        {
            Activate(window);
            Click(message.Item);
        }
        var until = DateTime.UtcNow.AddSeconds(request.TimeoutSeconds);
        while (DateTime.UtcNow < until)
        {
            var found = FindDownloaded(request.DownloadRoot, message.Filename, message.SizeBytes, requestedAt);
            if (found is not null) return found;
            Thread.Sleep(1000);
        }
        return new BridgeResult("download_failed", message.Filename, Error: "WeChat did not finish downloading the latest file before timeout.");
    }

    private static BridgeResult? FindDownloaded(string root, string filename, long? expectedSize, DateTime? modifiedAfter = null)
    {
        try
        {
            var candidate = Directory.EnumerateFiles(root, filename, SearchOption.AllDirectories)
                .Where(path => !modifiedAfter.HasValue || File.GetLastWriteTimeUtc(path) >= modifiedAfter.Value)
                .Where(path => !expectedSize.HasValue || SizeMatches(path, expectedSize.Value))
                .OrderByDescending(File.GetLastWriteTimeUtc).FirstOrDefault();
            return candidate is null ? null : new BridgeResult("ready", filename, Path.GetFullPath(candidate));
        }
        catch (UnauthorizedAccessException) { return null; }
    }

    private static long? DisplayedFileSize(string name)
    {
        var match = Regex.Match(name, @"(?<size>\d+(?:\.\d+)?)\s*(?<unit>KB|MB|GB)\b", RegexOptions.IgnoreCase);
        if (!match.Success || !double.TryParse(match.Groups["size"].Value, System.Globalization.NumberStyles.AllowDecimalPoint, System.Globalization.CultureInfo.InvariantCulture, out var value)) return null;
        var multiplier = match.Groups["unit"].Value.ToUpperInvariant() switch { "KB" => 1_000d, "MB" => 1_000_000d, "GB" => 1_000_000_000d, _ => 0d };
        return multiplier == 0 ? null : (long)Math.Round(value * multiplier);
    }

    private static bool SizeMatches(string path, long expectedSize)
    {
        var actual = new FileInfo(path).Length;
        return Math.Abs(actual - expectedSize) <= Math.Max(1_000_000, expectedSize * 0.05);
    }

    private static BridgeResult SendOutput(BridgeRequest request) => SendFile(request, request.MediaRoot!, VideoExtensions, "Only an Agent-owned completed video can be sent.", waitForConfirmation: true, requirePendingAttachment: true, submitWithEnter: true);

    private static BridgeResult SendPackage(BridgeRequest request) => SendFile(request, request.PackageRoot!, [".zip"], "Only a package from the approved package directory can be sent.", waitForConfirmation: false, requirePendingAttachment: false, submitWithEnter: false);

    private static BridgeResult SendPackageWithEnter(BridgeRequest request) => SendFile(request, request.PackageRoot!, [".zip"], "Only a package from the approved package directory can be sent.", waitForConfirmation: false, requirePendingAttachment: false, submitWithEnter: true);

    private static BridgeResult SendPackageDraft(BridgeRequest request)
    {
        var path = Path.GetFullPath(request.FilePath!);
        if (!IsOwnedOutput(path, request.PackageRoot!) || !File.Exists(path) || !string.Equals(Path.GetExtension(path), ".zip", StringComparison.OrdinalIgnoreCase)) return new BridgeResult("send_failed", Error: "Only a package from the approved package directory can be sent.");
        var window = WeChatWindow();
        if (window is null) return new BridgeResult("wechat_not_logged_in", Error: "WeChat desktop window is unavailable in this interactive session.");
        var selected = SelectAssistant(window);
        if (selected is not null) return selected;
        if (!request.SkipPendingAttachmentCheck && !WaitForPendingFile(window, Path.GetFileName(path), 3)) return new BridgeResult("send_failed", Error: "The named package is not present in the current File Transfer Assistant draft.");
        if (!SendPendingFile(window)) return new BridgeResult("send_failed", Error: "WeChat Send button is unavailable.");
        return new BridgeResult("send_initiated", Path.GetFileName(path), Error: "The named package draft was submitted through the WeChat Send control; delivery was not inspected by request.");
    }

    private static BridgeResult SendFile(BridgeRequest request, string root, string[] extensions, string invalidFileMessage, bool waitForConfirmation, bool requirePendingAttachment, bool submitWithEnter)
    {
        var path = Path.GetFullPath(request.FilePath!);
        if (!IsOwnedOutput(path, root) || !File.Exists(path) || !extensions.Contains(Path.GetExtension(path), StringComparer.OrdinalIgnoreCase)) return new BridgeResult("send_failed", Error: invalidFileMessage);
        var window = WeChatWindow();
        if (window is null) return new BridgeResult("wechat_not_logged_in", Error: "WeChat desktop window is unavailable in this interactive session.");
        var selected = SelectAssistant(window);
        if (selected is not null) return selected;
        var previousCount = MessageCount(window, Path.GetFileName(path));
        var picker = FindFilePicker();
        if (picker is null)
        {
            var button = window.FindFirst(TreeScope.Subtree, new AndCondition(new PropertyCondition(AutomationElement.ControlTypeProperty, ControlType.Button), new PropertyCondition(AutomationElement.NameProperty, SendFileButton)));
            if (button is null || !button.TryGetCurrentPattern(InvokePattern.Pattern, out var invoke)) return new BridgeResult("ui_changed", Error: "WeChat Send File button is unavailable.");
            Activate(window);
            ((InvokePattern)invoke).Invoke();
            picker = WaitForFilePicker(3);
            if (picker is null && Click(button)) picker = WaitForFilePicker(7);
        }
        if (picker is null) return new BridgeResult("send_failed", Error: "WeChat file picker did not open.");
        if (!picker.Open.TryGetCurrentPattern(InvokePattern.Pattern, out _)) return new BridgeResult("ui_changed", Error: "Windows file picker confirmation control is unavailable.");
        if (!picker.Edit.TryGetCurrentPattern(ValuePattern.Pattern, out var value)) return new BridgeResult("ui_changed", Error: "Windows file picker filename field cannot accept a direct value.");
        ((ValuePattern)value).SetValue(path);
        if (!ConfirmFilePickerSelection(picker)) return new BridgeResult("send_failed", Error: "WeChat file picker did not confirm the selected package.");
        if (requirePendingAttachment && !WaitForPendingFile(window, Path.GetFileName(path), 8)) return new BridgeResult("send_failed", Error: "WeChat did not expose the selected output as a pending attachment.");
        Thread.Sleep(800);
        if (submitWithEnter)
        {
            if (!PressEnter(window)) return new BridgeResult("send_failed", Error: "Windows could not inject Enter into the active WeChat conversation.");
        }
        else if (!SendPendingFile(window)) return new BridgeResult("send_failed", Error: "WeChat Send button is unavailable.");
        if (!waitForConfirmation) return new BridgeResult("send_initiated", Path.GetFileName(path), Error: "The WeChat Send button was clicked; delivery was not inspected by request.");
        var until = DateTime.UtcNow.AddSeconds(request.TimeoutSeconds);
        while (DateTime.UtcNow < until)
        {
            if (MessageCount(window, Path.GetFileName(path)) > previousCount) return new BridgeResult("sent", Path.GetFileName(path));
            Thread.Sleep(500);
        }
        return new BridgeResult("send_failed", Error: "WeChat did not confirm the output in File Transfer Assistant before timeout.");
    }

    private static FilePicker? WaitForFilePicker(int seconds)
    {
        var until = DateTime.UtcNow.AddSeconds(seconds);
        while (DateTime.UtcNow < until)
        {
            var picker = FindFilePicker();
            if (picker is not null) return picker;
            Thread.Sleep(200);
        }
        return null;
    }

    private static bool ConfirmFilePickerSelection(FilePicker picker)
    {
        if (!picker.Open.TryGetCurrentPattern(InvokePattern.Pattern, out var open)) return false;
        ((InvokePattern)open).Invoke();
        var until = DateTime.UtcNow.AddSeconds(5);
        while (DateTime.UtcNow < until)
        {
            if (FindFilePicker() is null) return true;
            Thread.Sleep(100);
        }
        return false;
    }

    private static bool SendPendingFile(AutomationElement window)
    {
        var send = window.FindAll(TreeScope.Subtree, new PropertyCondition(AutomationElement.ControlTypeProperty, ControlType.Button)).Cast<AutomationElement>()
            .FirstOrDefault(button => string.Equals(button.Current.Name, "\u53d1\u9001", StringComparison.Ordinal) && button.Current.IsEnabled && !button.Current.IsOffscreen);
        if (send is null || !send.Current.IsEnabled) return false;
        Activate(window);
        if (send.TryGetCurrentPattern(InvokePattern.Pattern, out var invoke))
        {
            ((InvokePattern)invoke).Invoke();
            return true;
        }
        return Click(send);
    }

    private static bool WaitForPendingFile(AutomationElement window, string filename, int seconds)
    {
        var until = DateTime.UtcNow.AddSeconds(seconds);
        while (DateTime.UtcNow < until)
        {
            if (window.FindAll(TreeScope.Subtree, Condition.TrueCondition).Cast<AutomationElement>()
                .Any(element => element.Current.Name?.Contains(filename, StringComparison.OrdinalIgnoreCase) == true)) return true;
            Thread.Sleep(200);
        }
        return false;
    }

    private static void Activate(AutomationElement window)
    {
        if (window.Current.NativeWindowHandle != 0) SetForegroundWindow((IntPtr)window.Current.NativeWindowHandle);
        window.SetFocus();
        Thread.Sleep(150);
    }

    private static bool PressEnter(AutomationElement window)
    {
        Activate(window);
        var composer = ChatComposer(window);
        if (composer is null) return false;
        composer.SetFocus();
        Thread.Sleep(100);
        var inputs = new[]
        {
            new INPUT { Type = 1, Data = new InputUnion { Keyboard = new KEYBDINPUT { VirtualKey = 0x0D } } },
            new INPUT { Type = 1, Data = new InputUnion { Keyboard = new KEYBDINPUT { VirtualKey = 0x0D, Flags = 0x0002 } } },
        };
        return SendInput((uint)inputs.Length, inputs, Marshal.SizeOf<INPUT>()) == inputs.Length;
    }

    private static AutomationElement? ChatComposer(AutomationElement window)
    {
        var composer = window.FindFirst(TreeScope.Subtree, new PropertyCondition(AutomationElement.AutomationIdProperty, "chat_input_field"));
        return composer is not null && composer.Current.ControlType == ControlType.Edit && composer.Current.IsEnabled && !composer.Current.IsOffscreen && !composer.Current.BoundingRectangle.IsEmpty
            ? composer
            : null;
    }

    private static bool Click(AutomationElement element)
    {
        var bounds = element.Current.BoundingRectangle;
        if (bounds.IsEmpty || bounds.Width < 2 || bounds.Height < 2) return false;
        var x = (int)Math.Round(bounds.Left + bounds.Width / 2);
        var y = (int)Math.Round(bounds.Top + bounds.Height / 2);
        if (!SetCursorPos(x, y)) return false;
        mouse_event(0x0002, 0, 0, 0, UIntPtr.Zero);
        mouse_event(0x0004, 0, 0, 0, UIntPtr.Zero);
        return true;
    }

    private static FilePicker? FindFilePicker()
    {
        var parent = WeChatWindow() ?? AutomationElement.RootElement;
        var windows = parent.FindAll(TreeScope.Subtree, new PropertyCondition(AutomationElement.ControlTypeProperty, ControlType.Window));
        foreach (AutomationElement window in windows)
        {
            if (!string.Equals(window.Current.ClassName, "#32770", StringComparison.Ordinal)) continue;
            var edit = window.FindFirst(TreeScope.Subtree, new PropertyCondition(AutomationElement.AutomationIdProperty, "1148"));
            var open = window.FindFirst(TreeScope.Subtree, new AndCondition(new PropertyCondition(AutomationElement.ControlTypeProperty, ControlType.Button), new PropertyCondition(AutomationElement.AutomationIdProperty, "1")));
            if (edit is not null && open is not null) return new FilePicker(edit, open);
        }
        return null;
    }

    private static int MessageCount(AutomationElement window, string filename)
    {
        return MatchingMessageNames(window, filename).Length;
    }

    private static string[] MatchingMessageNames(AutomationElement window, string filename)
    {
        var messages = window.FindFirst(TreeScope.Subtree, new PropertyCondition(AutomationElement.AutomationIdProperty, "chat_message_list"));
        if (messages is null) return [];
        return messages.FindAll(TreeScope.Subtree, new PropertyCondition(AutomationElement.ControlTypeProperty, ControlType.ListItem))
            .Cast<AutomationElement>().Select(item => item.Current.Name ?? string.Empty)
            .Where(name => name.Contains(filename, StringComparison.OrdinalIgnoreCase)).Take(5).ToArray();
    }

    private static bool IsOwnedOutput(string path, string root)
    {
        try
        {
            var rootPath = Path.GetFullPath(root).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar) + Path.DirectorySeparatorChar;
            return path.StartsWith(rootPath, StringComparison.OrdinalIgnoreCase);
        }
        catch (Exception) { return false; }
    }

    private sealed record FilePicker(AutomationElement Edit, AutomationElement Open);
}
