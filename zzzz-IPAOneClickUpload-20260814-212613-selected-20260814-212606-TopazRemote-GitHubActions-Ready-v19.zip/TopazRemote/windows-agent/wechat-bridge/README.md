# Topaz Remote WeChat Bridge

This dependency-free .NET 8 helper accepts one JSON request on standard input and emits one JSON result. It is limited to the logged-in Windows WeChat File Transfer Assistant UI; it never uses an unofficial protocol or reads credentials.

```json
{"command":"inspect-latest","downloadRoot":"C:\\Users\\Admin\\Documents\\xwechat_files","timeoutSeconds":30}
```

Supported commands are `inspect-latest`, `download-latest`, and `send-output`. The helper uses bounded Windows UI Automation only against the logged-in user's File Transfer Assistant: it does not use an unofficial WeChat protocol or read credentials.

`send-output` additionally requires `mediaRoot`. The selected file must be inside that Agent-owned output directory. It is reported as `sent` only after the File Transfer Assistant message list contains a new message with the selected filename; otherwise it returns a retryable `send_failed` result.

A download starts only after the caller first receives `not_downloaded` from `inspect-latest`. It is bounded by `timeoutSeconds` and accepts only a newly written matching video beneath `downloadRoot`.

`send-package` is a separate manual-maintenance command, not an Agent API route. It requires `packageRoot` and accepts only an existing `.zip` below that exact directory; it exists for deliberate user-approved delivery of an iOS build handoff through File Transfer Assistant.
