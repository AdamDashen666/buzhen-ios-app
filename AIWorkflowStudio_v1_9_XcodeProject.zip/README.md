# AI Workflow Studio v1.9

SwiftUI iOS / iPadOS Xcode Project 骨架。

## v1.9 更新

- 修复 Build-logs-132 中的 SwiftUI 编译失败：`WorkflowEditorView.swift` 菜单表达式过复杂，已拆成独立方法，降低类型推断压力。
- 新增「意见提出者 / 优化者」模块。
- 优化者可以读取上游当前结果，输出问题、风险、遗漏点、修改建议和优先级。
- 优化者输出可以手动连接到通用工作者或代码工作者，让工作者根据意见继续改进。
- AI 自动选择模块已支持识别 optimizer / 优化 / 意见 / 改进建议。
- 自动建图在需要优化时会把检查通过后的结果接到优化者，再接到汇总者，避免默认生成无限返工循环。
- 保留 v1.8 的运行 Watchdog、进度日志、停止运行、动态画布、真实 ZIP 导出和缓存清理。

## 注意

需要在 Xcode 中设置 Team / Bundle ID 后运行。API 默认按 OpenAI-compatible `/v1/models` 与 `/v1/chat/completions` 设计。
