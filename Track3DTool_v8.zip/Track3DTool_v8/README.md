# Track3DTool v8

iOS / iPadOS 原生 SwiftUI 工程，用于把普通视频 / 游戏视频里的文字、贴图、字幕透视贴到墙面、地面、屏幕等平面上。

## v8 修复

- 修复 iPad 上“导入视频窗口能打开，但点击视频没反应”的问题。
- 移除单一 SwiftUI `.fileImporter` 路径，改为两个独立入口：
  - 从文件导入：`UIDocumentPickerViewController`，使用 `asCopy: true`，并放宽 UTType 过滤。
  - 从相册导入：`PHPickerViewController`，专门选择视频，并把相册临时文件复制到 App 沙盒。
- 加入 `NSPhotoLibraryUsageDescription`、`UIFileSharingEnabled`、`LSSupportsOpeningDocumentsInPlace`。
- 版本号更新为 `8.0 (8)`。

## 使用方法

1. 用 Xcode 打开 `Track3DTool.xcodeproj`
2. Signing & Capabilities 里换成自己的 Team
3. 选择真机 iPhone / iPad 运行
4. 点“从文件导入”或“从相册导入”
5. 在第一帧按顺序点四点：左上 → 右上 → 右下 → 左下
6. 输入要贴墙的文字
7. 选择追踪质量、导出格式
8. 点“开始追踪并导出 v8”

## 技术路线

- Patch Tracking：在你选中的平面内采样多个纹理点
- NCC 匹配：逐帧匹配纹理点
- Homography：估计真实平面透视变化
- RANSAC：过滤误匹配，降低漂移
- CI Perspective Transform：把文字透视变换到追踪平面
- AVAssetWriter：导出合成视频
- Audio Passthrough：复制原视频音频轨道
- Plane Pose Solver：根据平面 Homography 估算相机相对位姿

## 注意

- 从相册导入超大视频时，iOS 可能需要先复制到临时文件，会等几秒。
- 文件导入现在放宽类型过滤，非视频文件也可能能点；如果不是视频，会在读取第一帧时报错。
- 纯色墙如果没有纹理，追踪仍然容易漂移；尽量选择带墙角、纹理、边框、屏幕边缘的区域。
