import SwiftUI
import AVFoundation
import UniformTypeIdentifiers
import PhotosUI

private enum ActiveSheet: Identifiable {
    case fileImporter
    case photoImporter
    case shareOutput

    var id: Int {
        switch self {
        case .fileImporter: return 1
        case .photoImporter: return 2
        case .shareOutput: return 3
        }
    }
}

struct ContentView: View {
    @State private var inputURL: URL?
    @State private var firstFrame: UIImage?
    @State private var selectedQuad: [CGPoint] = []
    @State private var activeSheet: ActiveSheet?
    @State private var overlayText = "By LaoDeng666"
    @State private var status = "从文件或相册导入视频，然后在墙/地面/屏幕平面上按顺序点 4 个角。"
    @State private var progress: Double = 0
    @State private var isRendering = false
    @State private var outputURL: URL?
    @State private var trackingQuality = TrackingQuality.high
    @State private var outputProfile = OutputProfile.hevcHDRPriority
    @State private var preserveAudio = true
    @State private var exportCameraSolve = true

    var body: some View {
        NavigationStack {
            VStack(spacing: 14) {
                header
                videoArea
                controls
                statusBar
            }
            .padding()
            .navigationTitle("3D Plane Tracker v8")
            .sheet(item: $activeSheet) { sheet in
                switch sheet {
                case .fileImporter:
                    FileVideoPicker(
                        onPick: { url in
                            activeSheet = nil
                            importPickedVideo(url)
                        },
                        onCancel: {
                            activeSheet = nil
                            status = "已取消文件导入。"
                        },
                        onError: { message in
                            activeSheet = nil
                            status = "文件导入失败：\(message)"
                        }
                    )
                case .photoImporter:
                    PhotoVideoPicker(
                        onPick: { url in
                            activeSheet = nil
                            importPickedVideo(url)
                        },
                        onCancel: {
                            activeSheet = nil
                            status = "已取消相册导入。"
                        },
                        onError: { message in
                            activeSheet = nil
                            status = "相册导入失败：\(message)"
                        }
                    )
                case .shareOutput:
                    if let outputURL {
                        ShareSheet(items: [outputURL])
                    } else {
                        Text("没有可分享的导出文件")
                    }
                }
            }
        }
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("本地视频平面 3D 追踪 v8")
                .font(.title2.bold())
            Text("用于游戏视频、墙面字幕、贴图、屏幕替换。v8 修复 iPad 上导入窗口能打开但点击视频没反应的问题：新增文件导入器 + 相册视频导入器，并放宽视频类型过滤。")
                .font(.footnote)
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private var videoArea: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 18)
                .fill(.thinMaterial)
            if let image = firstFrame {
                QuadSelectionView(image: image, points: $selectedQuad)
                    .clipShape(RoundedRectangle(cornerRadius: 18))
            } else {
                VStack(spacing: 12) {
                    Image(systemName: "video.badge.plus")
                        .font(.system(size: 48))
                    Text("还没有导入视频")
                        .font(.headline)
                    Text("点下面的“从文件导入”或“从相册导入”开始")
                        .foregroundStyle(.secondary)
                }
            }
        }
        .frame(maxWidth: .infinity)
        .frame(height: 420)
    }

    private var controls: some View {
        VStack(spacing: 12) {
            HStack(spacing: 10) {
                Button("从文件导入") {
                    activeSheet = .fileImporter
                }
                .buttonStyle(.borderedProminent)

                Button("从相册导入") {
                    activeSheet = .photoImporter
                }
                .buttonStyle(.bordered)

                Button("重选四点") {
                    selectedQuad.removeAll()
                }
                .buttonStyle(.bordered)
                .disabled(firstFrame == nil || isRendering)
            }

            TextField("贴在墙上的文字", text: $overlayText)
                .textFieldStyle(.roundedBorder)
                .disabled(isRendering)

            Picker("追踪质量", selection: $trackingQuality) {
                ForEach(TrackingQuality.allCases, id: \.self) { q in
                    Text(q.title).tag(q)
                }
            }
            .pickerStyle(.segmented)
            .disabled(isRendering)

            Picker("导出格式", selection: $outputProfile) {
                ForEach(OutputProfile.allCases, id: \.self) { p in
                    Text(p.title).tag(p)
                }
            }
            .pickerStyle(.segmented)
            .disabled(isRendering)

            Toggle("保留原视频音频", isOn: $preserveAudio)
                .disabled(isRendering)

            Toggle("导出平面相机位姿 JSON", isOn: $exportCameraSolve)
                .disabled(isRendering)

            Button {
                render()
            } label: {
                HStack {
                    if isRendering { ProgressView().scaleEffect(0.8) }
                    Text(isRendering ? "处理中..." : "开始追踪并导出 v8")
                }
                .frame(maxWidth: .infinity)
            }
            .buttonStyle(.borderedProminent)
            .disabled(inputURL == nil || selectedQuad.count != 4 || overlayText.isEmpty || isRendering)

            if isRendering {
                ProgressView(value: progress)
            }

            if outputURL != nil {
                Button("分享 / 保存导出视频") {
                    activeSheet = .shareOutput
                }
                .buttonStyle(.bordered)
            }
        }
    }

    private var statusBar: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(status)
                .font(.footnote)
                .foregroundStyle(.secondary)
            Text("提示：四点顺序建议为 左上 → 右上 → 右下 → 左下。抗漂移模式更稳但更慢；纯色墙仍建议选有纹理边缘。")
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private func importPickedVideo(_ pickedURL: URL) {
        do {
            let localURL = try FileStore.copyIntoDocuments(pickedURL)
            inputURL = localURL
            firstFrame = nil
            selectedQuad.removeAll()
            outputURL = nil
            status = "已导入：\(localURL.lastPathComponent)。正在读取第一帧..."
            Task {
                do {
                    let image = try await FirstFrameLoader.load(url: localURL)
                    await MainActor.run {
                        firstFrame = image
                        status = "第一帧已读取。请在要贴字的平面上点 4 个角。"
                    }
                } catch {
                    await MainActor.run {
                        status = "读取第一帧失败：\(error.localizedDescription)"
                    }
                }
            }
        } catch {
            status = "导入失败：\(error.localizedDescription)"
        }
    }

    private func render() {
        guard let inputURL, selectedQuad.count == 4 else { return }
        isRendering = true
        progress = 0
        outputURL = nil
        status = "开始 v8 逐帧追踪。长视频会比较慢，建议先用 5-15 秒素材测试。"

        let text = overlayText
        let quad = selectedQuad
        let quality = trackingQuality
        let profile = outputProfile
        let keepAudio = preserveAudio
        let solveCamera = exportCameraSolve

        Task.detached(priority: .userInitiated) {
            do {
                let url = try await VideoPlaneCompositor.render(
                    inputURL: inputURL,
                    normalizedQuad: quad,
                    overlayText: text,
                    quality: quality,
                    outputProfile: profile,
                    preserveAudio: keepAudio,
                    exportCameraSolve: solveCamera
                ) { value, message in
                    Task { @MainActor in
                        progress = value
                        status = message
                    }
                }
                await MainActor.run {
                    outputURL = url
                    isRendering = false
                    progress = 1
                    status = "导出完成：\(url.lastPathComponent)"
                }
            } catch {
                await MainActor.run {
                    isRendering = false
                    status = "导出失败：\(error.localizedDescription)"
                }
            }
        }
    }
}

struct ShareSheet: UIViewControllerRepresentable {
    let items: [Any]
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: items, applicationActivities: nil)
    }
    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}
