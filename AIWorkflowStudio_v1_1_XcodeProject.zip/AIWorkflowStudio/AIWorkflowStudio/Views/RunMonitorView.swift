import SwiftUI

struct RunMonitorView: View {
    @EnvironmentObject private var store: AppStore

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    if let run = activeRun {
                        runHeader(run)
                        nodeTimeline(run)
                        logs(run)
                    } else {
                        ContentUnavailableView("暂无运行", systemImage: "play.slash", description: Text("从首页或工作流页面点击运行。"))
                    }
                }
                .padding()
            }
            .navigationTitle("运行监控")
            .toolbar {
                Button("运行当前项目") { Task { await store.runSelectedProject() } }
            }
        }
    }

    private var activeRun: RunRecord? {
        if let id = store.activeRunID, let run = store.runRecords.first(where: { $0.id == id }) { return run }
        return store.runRecords.first
    }

    private func runHeader(_ run: RunRecord) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(run.projectTitle).font(.title2.bold())
            FlowingStatusBar(progress: run.progress)
            HStack {
                Label(run.status.title, systemImage: "circle.fill")
                Spacer()
                Text("Token \(run.tokenUsage.total)")
            }
            .font(.caption)
            .foregroundStyle(.secondary)
        }
        .liquidGlass()
    }

    private func nodeTimeline(_ run: RunRecord) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("模块状态").font(.headline)
            ForEach(run.nodeRecords) { node in
                HStack(alignment: .top) {
                    Image(systemName: node.kind.icon)
                    VStack(alignment: .leading) {
                        Text(node.nodeTitle).font(.headline)
                        Text("\(node.status.title) · Token \(node.tokenUsage.total) · \(node.modelID ?? "本地/未配置")")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                        if let error = node.errorMessage { Text(error).font(.caption).foregroundStyle(.red) }
                    }
                    Spacer()
                }
                .padding()
                .background(.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
            }
        }
        .liquidGlass()
    }

    private func logs(_ run: RunRecord) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text("运行日志").font(.headline)
                Spacer()
                ShareLink("导出 Markdown", item: LogExportService.markdown(for: run))
                ShareLink("导出 ZIP", item: ZipArchiveService.shareableRunArchive(for: run))
            }
            ForEach(run.logs) { log in
                Text("\(log.level.symbol) \(log.nodeTitle.map { "[\($0)] " } ?? "")\(log.message)")
                    .font(.caption)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
        }
        .liquidGlass()
    }
}
