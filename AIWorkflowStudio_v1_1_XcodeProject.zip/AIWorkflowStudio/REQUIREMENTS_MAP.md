# PDF 要求对应表

| PDF 要求 | 本项目实现位置 |
|---|---|
| iPhone + iPad，优先 iPad 横屏画布 | `WorkflowEditorView`：宽屏画布，小屏列表 |
| Liquid Glass UI | `LiquidGlass.swift` |
| 多 API / 多模型管理 | `APIProviderConfig`、`SettingsView`、`APIConfigEditorView` |
| 刷新模型列表 | `AIClient.fetchModels` |
| 每个模块单独选模型 | `NodeDetailView` |
| 模块化工作流 | `WorkflowNodeKind`、`WorkflowModels` |
| AI 自动选择模块 | `WorkflowAutoBuilder` |
| 图片理解 / 识别模块 | `imageUnderstanding` 节点 + `completeVision` |
| 代码检查与自动修复 | `codeReviewer`、`autoFixer` 节点与系统提示词 |
| 多模型投票 | `multiModelVote` 节点与设置结构 |
| Token 估算和限制 | `TokenEstimator`、`AppSettings` |
| 日志导出 | `LogExportService`、`RunMonitorView` |
| 版本历史 | `VersionSnapshot`、`OutputHistoryView` |
| 输出系统 | `OutputFormat`、`output` 节点 |
| 死循环防护 | `maxReturnCount`、`retryLimit` 字段 |
| 隐私与 API Key 安全 | `KeychainService` |


## v1.1 新增

- 文件打包者 / 输出历史：已支持真实 ZIP 打包导出。
- 构建修复：移除错误的 DEVELOPMENT_ASSET_PATHS 设置。
