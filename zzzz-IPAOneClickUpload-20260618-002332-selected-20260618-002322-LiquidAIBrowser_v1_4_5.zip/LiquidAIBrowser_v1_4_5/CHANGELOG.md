# CHANGELOG

## v1.4.4

- 新增 AI 中途询问用户/等待用户输入能力：`askUser`、`requestInput`。
- 新增 App 内提示和本地通知：AI 等待用户、计时器结束会通知用户。
- 新增 AI 计时器插件：`startTimer`、`checkTimer`、`stopTimer`，支持倒计时和正计时。
- 倒计时等待不占用 AI 请求超时时间；到点后自动继续任务。
- 每轮读取页面、每次动作后、最终验收时都会缓存截图。
- 关闭“发送图片给 AI”时，截图仍缓存到任务中并用于 PDF 报告。
- PDF 报告重写：黑色/深色字体、加粗标题、等比例图片、不再压扁、按步骤放入截图。
- 新增 AppIcon.appiconset，并设置 Xcode App Icon。
- 版本号更新为 1.4.4，build 11。

# Changelog

## v1.4.3

- 修复 iPadOS 台前调度 / 窗口化无法尽量贴满窗口的问题。
- 新增 LaunchScreen.storyboard，降低 iPad letterbox / 尺寸识别异常风险。
- 新增 WindowSizingSupport.swift，设置 iPad 窗口最小/最大尺寸限制。
- 根视图改为忽略容器安全区，移除常规布局外层边距。
- AI navigate 改为 App 原生 WKWebView 加载，不再用网页 JS 直接跳转。
- WKNavigationDelegate 和 window.open 全面拦截外部 App scheme。
- 版本更新到 1.4.3 / build 10。

# CHANGELOG

## v1.4.2

- 修复 iPadOS 台前调度/窗口化 App 拉伸适配。
- 保持 `UIRequiresFullScreen=false`，支持窗口化和多 Scene。
- 背景改为单一深色，移除过亮蓝色渐变感。
- UI 调整为更简洁现代的低亮度玻璃风。
- 动画改为更自然的非线性 spring。
- 启动和新建页面默认空白页，不再默认 Google。
- Agent 设任务前会先扫描当前页面再规划。
- Agent 支持每轮动态修改当前/后续步骤。
- Agent 支持从头重新规划任务。
- 全部任务完成后新增最终验收检查。
- 最终验收失败会自动追加缺失步骤并继续执行。
- 移除敏感操作确认功能和设置项。
- 直接输入链接、navigate、createTab 不再触发确认。
- 新增直接修改网页 action：setText / setHTML / setStyle / modifyPage。
- 修复“去抖音搜索 macbook”误打开 iPad 抖音 App：阻止外部 scheme，规整为 Douyin Web 搜索 URL。

## v1.4

- 标签页重构为分组。
- 一个分组支持多个页面和多个任务。
- AI 可创建/切换页面，适合跨网页任务。
- 新增键盘动作。


## v1.4.5 - Build diagnostics fix

- 修复 `BrowserStore.swift` 中 `loadSelectedAddress(_:)` 调用 `@MainActor` 方法导致的编译错误。
- 将 `loadSelectedAddress(_:)` 标记为 `@MainActor`，确保从地址栏加载网页、AI 内置浏览器导航、创建/切换页面时都在主线程安全执行。
- 根据 `Build-Diagnostics-Newest-9-1.zip` 中的错误定位修复：`call to main actor-isolated instance method 'loadURLInTab(tabID:urlString:)' in a synchronous nonisolated context`。
- 版本号更新到 `1.4.5`，build 更新到 `12`。

