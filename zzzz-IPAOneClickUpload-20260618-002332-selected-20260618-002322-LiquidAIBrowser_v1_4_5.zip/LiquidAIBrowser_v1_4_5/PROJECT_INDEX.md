# LiquidAIBrowser v1.4.5 Project Index

## Package
- `LiquidAIBrowser_v1_4_5.zip`

## Main app
- `LiquidAIBrowser/LiquidAIBrowserApp.swift`：App 入口。
- `LiquidAIBrowser/ContentView.swift`：主界面、分组栏、浏览器区域、任务面板、设置页入口。
- `LiquidAIBrowser/BrowserModels.swift`：分组、页面、任务、AI 动作、日志、截图、计时器模型。
- `LiquidAIBrowser/BrowserStore.swift`：全局状态、分组/页面/任务管理、通知、计时器、报告导出。
- `LiquidAIBrowser/WebViewPool.swift`：WKWebView 池、页面加载、DOM 扫描、坐标/手势/键盘动作、外部 App 跳转拦截。
- `LiquidAIBrowser/AgentEngine.swift`：AI 任务循环、规划、执行、重规划、计时器、询问用户、每步截图缓存。
- `LiquidAIBrowser/AIClient.swift`：OpenAI-compatible API、模型刷新、文本/视觉请求。
- `LiquidAIBrowser/AISettings.swift`：API 设置、Base URL 预设、Keychain API Key。
- `LiquidAIBrowser/Panels.swift`：任务卡片、输入请求、计时器、日志、设置。
- `LiquidAIBrowser/PDFReportExporter.swift`：可视化 PDF 报告导出。
- `LiquidAIBrowser/NotificationService.swift`：App 内/本地通知。
- `LiquidAIBrowser/WindowSizingSupport.swift`：iPad Stage Manager / 窗口化尺寸支持。
- `LiquidAIBrowser/LiquidGlassSupport.swift`：Liquid Glass / Material fallback。
- `LiquidAIBrowser/Assets.xcassets`：App 图标与资源。
- `LiquidAIBrowser/LaunchScreen.storyboard`：启动屏幕。

## Reports
- `CHANGELOG.md`：版本更新记录。
- `QA_V14_5_BUILD_FIX_REPORT.md`：本次构建错误修复说明。
- `QA_CHECK_REPORT.md` / `QA_FIX_REPORT.md`：历史检查与修复报告。
- `AI_REVIEW_REQUIREMENTS.md`：需求与验收标准。

## v1.4.5 fix summary
- 修复 Build Diagnostics 中的 `BrowserStore.swift:221:9` MainActor 编译错误。
- `loadSelectedAddress(_:)` 已标记为 `@MainActor`。
- 版本号：`1.4.5`
- Build：`12`
