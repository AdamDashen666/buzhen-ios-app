# LiquidAIBrowser v1.4.5

# Liquid AI Browser v1.4.4

独立 iOS / iPadOS AI 浏览器。支持分组、多页面、多任务、AI 网页操作、动态重规划、键盘动作、坐标动作、计时器、用户输入等待、步骤截图缓存和 PDF 报告导出。

## 新增重点

- AI 可中途询问用户，任务会暂停等待用户输入。
- 支持 App 内提示和本地通知。
- 支持 AI 调用倒计时 / 正计时。
- 每一步都会缓存截图，PDF 报告按步骤插图。
- PDF 字体加深，图片按比例显示，不再压扁。
- 已添加 App 图标。

## 使用

1. 解压 zip。
2. 打开 `LiquidAIBrowser.xcodeproj`。
3. 设置 Team / Bundle ID。
4. 真机运行。
5. 在设置页填写 API Key、Base URL、模型。

## 注意

- 本地通知需要用户授权。
- 视觉截图只有开启设置后才会发送给 AI；但无论是否开启，截图都会缓存到任务报告。
- App 退后台后，iPadOS/iOS 仍可能挂起网页自动化任务。


## v1.4.5 Build Fix

修复 Xcode 26.3 / Swift 6.2 下 `BrowserStore.swift` 的 MainActor 编译错误。请使用本版本重新打包。
