import SwiftUI
import UIKit

struct NewTaskPanel: View {
    @EnvironmentObject private var store: BrowserStore

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            if let group = store.selectedGroup {
                HStack(spacing: 10) {
                    Image(systemName: "folder.fill.badge.gearshape")
                        .font(.title2)
                        .frame(width: 52, height: 42)
                        .background(.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                    VStack(alignment: .leading, spacing: 4) {
                        Text(group.displayName)
                            .font(.subheadline.weight(.semibold))
                            .lineLimit(1)
                        Text("\(store.selectedGroupTabs.count) 个页面 · AI 可按任务需要新建/切换页面")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                            .lineLimit(2)
                    }
                }
                .padding(9)
                .background(.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 20, style: .continuous))
            }

            Text("输入你想让 AI 在当前分组完成的任务。AI 会先分析最终目标，再把每一次点击、输入、按键、滚动、切换页面都拆成单独步骤；必要时可自己创建新页面并在多个页面之间来回切换。")
                .font(.caption)
                .foregroundStyle(.secondary)

            TextEditor(text: $store.newTaskPrompt)
                .frame(minHeight: 118, maxHeight: 150)
                .scrollContentBackground(.hidden)
                .padding(8)
                .background(.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                .overlay(alignment: .topLeading) {
                    if store.newTaskPrompt.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                        Text("例如：从这个网站复制资料到另一个网站；打开两个页面对比价格；搜索资料并填写到目标页面。")
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                            .padding(14)
                            .allowsHitTesting(false)
                    }
                }

            HStack {
                Button {
                    store.newTaskPrompt = "帮我总结当前分组中页面的重点，并告诉我有没有需要新建页面继续查看的内容。"
                } label: { Text("总结网页") }
                Button {
                    store.newTaskPrompt = "帮我在当前分组里查找目标资料，必要时新建页面搜索，并把结果整理成报告。"
                } label: { Text("跨页查找") }
            }
            .buttonStyle(.bordered)

            Button {
                store.createTask(goal: store.newTaskPrompt)
            } label: {
                Label("开始任务", systemImage: "play.fill")
                    .frame(maxWidth: .infinity)
            }
            .buttonStyle(.borderedProminent)
            .controlSize(.regular)
            .disabled(store.newTaskPrompt.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || store.selectedGroupID == nil)
        }
    }
}

struct TasksPanel: View {
    @EnvironmentObject private var store: BrowserStore

    var body: some View {
        ScrollView {
            LazyVStack(spacing: 8) {
                if !store.timers.filter({ $0.status == .running }).isEmpty {
                    VStack(alignment: .leading, spacing: 8) {
                        Label("正在计时", systemImage: "timer")
                            .font(.caption.weight(.bold))
                        ForEach(store.timers.filter { $0.status == .running }) { timer in
                            TimerRowView(timer: timer)
                        }
                    }
                    .padding(10)
                    .background(.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                }
                if store.tasks.isEmpty {
                    VStack(spacing: 12) {
                        Image(systemName: "checklist.unchecked")
                            .font(.largeTitle)
                        Text("还没有任务")
                            .font(.headline)
                        Text("在顶部工具栏点击“设任务”即可创建任务。")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 36)
                }
                ForEach(store.tasks) { task in
                    TaskCardView(task: task)
                }
            }
            .padding(.vertical, 4)
        }
    }
}

struct TaskCardView: View {
    @EnvironmentObject private var store: BrowserStore
    let task: AgentTask
    @State private var expanded = false

    var body: some View {
        let tab = store.tabs.first(where: { $0.id == task.tabID })
        let group = store.groups.first(where: { $0.id == task.groupID })
        let workingTabs = task.workingTabIDs.compactMap { id in store.tabs.first(where: { $0.id == id }) }
        VStack(alignment: .leading, spacing: 9) {
            HStack(alignment: .top, spacing: 10) {
                ThumbnailView(image: tab?.thumbnailImage, title: group?.displayName ?? "分组")
                    .frame(width: 70, height: 50)
                    .onTapGesture {
                        if let tab = tab { store.selectTab(tab.id) }
                    }
                VStack(alignment: .leading, spacing: 6) {
                    HStack {
                        Label(task.status.title, systemImage: task.status.symbolName)
                            .font(.caption.weight(.semibold))
                            .foregroundStyle(statusColor)
                        Spacer()
                        Text("\(Int(task.progress * 100))%")
                            .font(.caption.monospacedDigit())
                            .foregroundStyle(.secondary)
                    }
                    Text(task.goal)
                        .font(.caption.weight(.semibold))
                        .lineLimit(expanded ? 3 : 2)
                    Text("\(group?.displayName ?? "分组已关闭") · \(workingTabs.count) 个参与页面")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                    ProgressView(value: task.progress)
                }
            }

            Text(task.currentAction)
                .font(.caption)
                .foregroundStyle(.secondary)
                .lineLimit(expanded ? 4 : 2)

            if task.status == .waitingUser || !task.pendingUserQuestion.isEmpty {
                VStack(alignment: .leading, spacing: 8) {
                    Label("AI 需要你的输入", systemImage: "person.crop.circle.badge.questionmark")
                        .font(.caption.weight(.bold))
                    Text(task.pendingUserQuestion.isEmpty ? "AI 暂停等待你的处理。" : task.pendingUserQuestion)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .textSelection(.enabled)
                    TextField(task.pendingUserPlaceholder, text: Binding(
                        get: { store.task(for: task.id)?.pendingUserInput ?? task.pendingUserInput },
                        set: { store.updatePendingUserInput(taskID: task.id, value: $0) }
                    ), axis: .vertical)
                    .lineLimit(2...5)
                    .textFieldStyle(.roundedBorder)
                    HStack {
                        Button("提交并继续") {
                            let value = store.task(for: task.id)?.pendingUserInput ?? task.pendingUserInput
                            store.answerUserQuestion(taskID: task.id, answer: value)
                        }
                        .buttonStyle(.borderedProminent)
                        Button("只继续") { store.resumeTask(task.id) }
                            .buttonStyle(.bordered)
                    }
                    .font(.caption)
                }
                .padding(10)
                .background(.orange.opacity(0.12), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
            }

            VStack(alignment: .leading, spacing: 8) {
                ForEach(Array(task.checklist.enumerated()), id: \.element.id) { index, item in
                    HStack(alignment: .top, spacing: 8) {
                        Image(systemName: item.isDone ? "checkmark.circle.fill" : "circle")
                            .foregroundStyle(item.isDone ? .green : .secondary)
                        VStack(alignment: .leading, spacing: 2) {
                            Text("\(index + 1). \(item.title)")
                                .font(.caption.weight(.semibold))
                            if expanded && !item.detail.isEmpty {
                                Text(item.detail)
                                    .font(.caption2)
                                    .foregroundStyle(.secondary)
                            }
                        }
                    }
                }
            }
            .padding(10)
            .background(.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 16, style: .continuous))

            if expanded {
                if expanded && !task.goalAnalysis.isEmpty {
                    VStack(alignment: .leading, spacing: 6) {
                        Text("最终目标分析")
                            .font(.caption.weight(.bold))
                        Text(task.goalAnalysis)
                            .font(.caption)
                            .textSelection(.enabled)
                    }
                    .padding(10)
                    .background(.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                }

                if !workingTabs.isEmpty {
                    VStack(alignment: .leading, spacing: 6) {
                        Text("参与页面")
                            .font(.caption.weight(.bold))
                        ForEach(workingTabs) { page in
                            Button { store.selectTab(page.id) } label: {
                                HStack {
                                    Image(systemName: page.id == task.tabID ? "circle.fill" : "circle")
                                        .font(.caption2)
                                    Text(page.displayTitle)
                                        .lineLimit(1)
                                    Spacer()
                                }
                                .font(.caption2)
                            }
                            .buttonStyle(.plain)
                        }
                    }
                    .padding(10)
                    .background(.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                }

                if !task.report.isEmpty {
                    VStack(alignment: .leading, spacing: 6) {
                        Text("报告")
                            .font(.caption.weight(.bold))
                        Text(task.report)
                            .font(.caption)
                            .textSelection(.enabled)
                    }
                    .padding(10)
                    .background(.green.opacity(0.10), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                }

                if let data = task.lastScreenshotData, let image = UIImage(data: data) {
                    VStack(alignment: .leading, spacing: 6) {
                        Text("最近一次视觉截图")
                            .font(.caption.weight(.bold))
                        Image(uiImage: image)
                            .resizable()
                            .scaledToFit()
                            .frame(maxHeight: 120)
                            .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                        if let date = task.lastScreenshotAt {
                            Text("截图时间：\(date.formatted(date: .omitted, time: .standard))")
                                .font(.caption2)
                                .foregroundStyle(.secondary)
                        }
                    }
                    .padding(10)
                    .background(.blue.opacity(0.08), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                }

                if !store.timers.filter({ $0.taskID == task.id }).isEmpty {
                    VStack(alignment: .leading, spacing: 6) {
                        Text("计时器")
                            .font(.caption.weight(.bold))
                        ForEach(store.timers.filter { $0.taskID == task.id }) { timer in
                            TimerRowView(timer: timer)
                        }
                    }
                    .padding(10)
                    .background(.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                }

                if !task.stepSnapshots.isEmpty {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("步骤截图缓存")
                            .font(.caption.weight(.bold))
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: 8) {
                                ForEach(task.stepSnapshots.suffix(12)) { shot in
                                    VStack(alignment: .leading, spacing: 4) {
                                        if let image = shot.image {
                                            Image(uiImage: image)
                                                .resizable()
                                                .scaledToFit()
                                                .frame(width: 118, height: 82)
                                                .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                                        }
                                        Text(shot.title)
                                            .font(.caption2)
                                            .lineLimit(1)
                                        Text(String(format: "+%.1fs", shot.elapsedSeconds))
                                            .font(.caption2.monospacedDigit())
                                            .foregroundStyle(.secondary)
                                    }
                                    .frame(width: 124, alignment: .leading)
                                }
                            }
                        }
                    }
                    .padding(10)
                    .background(.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                }

                DisclosureGroup("详细运行日志") {
                    VStack(alignment: .leading, spacing: 8) {
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack {
                                ForEach(TaskLogLevel.allCases) { level in
                                    Toggle(level.title, isOn: Binding(
                                        get: { store.selectedLogLevels.contains(level) },
                                        set: { enabled in
                                            if enabled { store.selectedLogLevels.insert(level) }
                                            else { store.selectedLogLevels.remove(level) }
                                        }
                                    ))
                                    .toggleStyle(.button)
                                    .font(.caption2)
                                }
                            }
                        }
                        ForEach(task.log.filter { store.selectedLogLevels.contains($0.level) }.suffix(expanded ? 50 : 18)) { entry in
                            VStack(alignment: .leading, spacing: 2) {
                                Text(entry.compactLine)
                                    .font(.caption2.monospaced())
                                    .foregroundStyle(entry.level == .error ? .red : entry.level == .warning ? .orange : .secondary)
                                    .textSelection(.enabled)
                                if let result = entry.result, !result.isEmpty {
                                    Text(result)
                                        .font(.caption2.monospaced())
                                        .foregroundStyle(.tertiary)
                                        .lineLimit(3)
                                        .textSelection(.enabled)
                                }
                            }
                            .frame(maxWidth: .infinity, alignment: .leading)
                        }
                    }
                    .padding(.top, 6)
                }
            }

            HStack {
                Button(expanded ? "收起" : "详情") { expanded.toggle() }
                Spacer()
                if task.status == .running || task.status == .planning {
                    Button("暂停") { store.pauseTask(task.id) }
                } else if task.status == .paused || task.status == .waitingConfirmation || task.status == .waitingUser || task.status == .timerRunning {
                    Button("继续") { store.resumeTask(task.id) }
                }
                if !task.status.isTerminal {
                    Button("停止", role: .destructive) { store.stopTask(task.id) }
                }
                Button { store.copyTaskLog(task.id) } label: { Image(systemName: "doc.on.doc") }
                Button { store.exportReportPDF(taskID: task.id) } label: { Image(systemName: "doc.richtext") }
            }
            .buttonStyle(.bordered)
            .font(.caption)
        }
        .padding(9)
        .background(.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 18, style: .continuous)
                .stroke(.white.opacity(0.08), lineWidth: 1)
        }
    }

    private func pendingActionSummary(_ action: AgentAction) -> String {
        var lines = ["动作：\(action.type)"]
        if let selector = action.selector, !selector.isEmpty { lines.append("Selector：\(selector)") }
        if let text = action.text, !text.isEmpty { lines.append("目标文字：\(text)") }
        if let value = action.value, !value.isEmpty { lines.append("输入/选择：\(String(value.prefix(120)))") }
        if let url = action.url, !url.isEmpty { lines.append("URL：\(url)") }
        if let tabID = action.tabID, !tabID.isEmpty { lines.append("页面 ID：\(tabID)") }
        if let key = action.key, !key.isEmpty { lines.append("键盘：\(key)") }
        if let reason = action.reason, !reason.isEmpty { lines.append("原因：\(reason)") }
        return lines.joined(separator: "\n")
    }

    var statusColor: Color {
        switch task.status {
        case .completed: return .green
        case .failed, .stopped: return .red
        case .waitingConfirmation, .waitingUser: return .orange
        case .timerRunning: return .cyan
        case .paused: return .yellow
        default: return .blue
        }
    }
}

struct SettingsPanel: View {
    @EnvironmentObject private var store: BrowserStore
    @State private var isTesting = false
    @State private var testMessage = ""

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                GroupBox("API 预设") {
                    VStack(alignment: .leading, spacing: 10) {
                        Picker("Provider", selection: Binding(get: { store.settings.providerName }, set: { newValue in
                            if let preset = AISettings.presets.first(where: { $0.name == newValue }) {
                                store.settings.applyPreset(preset)
                            }
                        })) {
                            ForEach(AISettings.presets) { preset in
                                Text(preset.name).tag(preset.name)
                            }
                        }
                        .pickerStyle(.menu)

                        TextField("Base URL", text: Binding(get: { store.settings.baseURL }, set: { store.settings.baseURL = $0 }))
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled()
                            .textFieldStyle(.roundedBorder)

                        HStack {
                            SecureField("API Key", text: Binding(get: { store.settings.apiKey }, set: { store.settings.apiKey = $0 }))
                                .textInputAutocapitalization(.never)
                                .autocorrectionDisabled()
                                .textFieldStyle(.roundedBorder)
                            Button("清除") { store.settings.apiKey = "" }
                                .disabled(store.settings.apiKey.isEmpty)
                        }

                        HStack {
                            TextField("模型", text: Binding(get: { store.settings.model }, set: { store.settings.model = $0 }))
                                .textInputAutocapitalization(.never)
                                .autocorrectionDisabled()
                                .textFieldStyle(.roundedBorder)
                            Button("刷新模型") { refreshModels() }
                                .disabled(isTesting || store.settings.apiKey.isEmpty)
                        }

                        if !store.settings.availableModels.isEmpty {
                            Picker("可用模型", selection: Binding(get: { store.settings.model }, set: { store.settings.model = $0 })) {
                                ForEach(store.settings.availableModels, id: \.self) { model in
                                    Text(model).tag(model)
                                }
                            }
                            .pickerStyle(.menu)
                        }
                    }
                }
                .groupBoxStyle(.liquid)

                GroupBox("Agent 参数") {
                    VStack(alignment: .leading, spacing: 12) {
                        HStack {
                            Text("Temperature")
                            Slider(value: Binding(get: { store.settings.temperature }, set: { store.settings.temperature = $0 }), in: 0...1)
                            Text(String(format: "%.2f", store.settings.temperature))
                                .font(.caption.monospacedDigit())
                        }
                        Stepper("最大循环次数：\(store.settings.maxIterations)", value: Binding(get: { store.settings.maxIterations }, set: { store.settings.maxIterations = $0 }), in: 3...50)
                        Stepper("请求超时：\(Int(store.settings.requestTimeout)) 秒", value: Binding(get: { store.settings.requestTimeout }, set: { store.settings.requestTimeout = $0 }), in: 15...180, step: 5)
                        Toggle("使用 JSON Mode，失败自动降级", isOn: Binding(get: { store.settings.useJSONMode }, set: { store.settings.useJSONMode = $0 }))
                        Toggle("允许坐标点击 / 双击 / 滑动 / 拖动 fallback", isOn: Binding(get: { store.settings.allowCoordinateFallback }, set: { store.settings.allowCoordinateFallback = $0 }))
                        Toggle("每一步发送当前可视区域截图给 AI", isOn: Binding(get: { store.settings.enableVisionScreenshots }, set: { store.settings.enableVisionScreenshots = $0 }))
                        Toggle("保存分组、页面和任务历史", isOn: Binding(get: { store.settings.persistSessionHistory }, set: { store.settings.persistSessionHistory = $0 }))
                        Stepper("动作失败重试上限：\(store.settings.maxActionRetries)", value: Binding(get: { store.settings.maxActionRetries }, set: { store.settings.maxActionRetries = $0 }), in: 1...10)
                        Text("视觉截图辅助需要你选择的模型支持图片输入。坐标动作使用网页 viewport 坐标，仍是 JS 合成事件，不等于系统级真手指触摸。")
                            .font(.caption2)
                            .foregroundStyle(.secondary)
                        Text("隐私：Agent 会把当前网页文本、元素坐标和可选截图发送给你设置的模型服务。密码、验证码、信用卡、token 等字段会默认脱敏，但仍建议只在可信网页使用。")
                            .font(.caption2)
                            .foregroundStyle(.secondary)
                    }
                }
                .groupBoxStyle(.liquid)

                Button {
                    testConnection()
                } label: {
                    if isTesting {
                        ProgressView()
                            .frame(maxWidth: .infinity)
                    } else {
                        Label("测试连接", systemImage: "network")
                            .frame(maxWidth: .infinity)
                    }
                }
                .buttonStyle(.borderedProminent)
                .disabled(isTesting || store.settings.apiKey.isEmpty)

                if !testMessage.isEmpty {
                    Text(testMessage)
                        .font(.caption)
                        .foregroundStyle(testMessage.contains("成功") ? .green : .orange)
                        .textSelection(.enabled)
                }

                Text("说明：App 前台时，非当前页面/分组任务会继续运行；App 退到后台或锁屏后，iOS 可能挂起普通网页自动化任务。")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            .padding(.bottom, 20)
        }
    }

    private func refreshModels() {
        isTesting = true
        testMessage = ""
        let snapshot = store.settings.snapshot()
        Task {
            do {
                let models = try await AIClient().fetchModels(snapshot: snapshot)
                await MainActor.run {
                    store.settings.availableModels = models
                    if let first = models.first, store.settings.model.isEmpty { store.settings.model = first }
                    testMessage = "刷新成功：\(models.count) 个模型。"
                    isTesting = false
                }
            } catch {
                await MainActor.run {
                    testMessage = "刷新失败：\(error.localizedDescription)"
                    isTesting = false
                }
            }
        }
    }

    private func testConnection() {
        isTesting = true
        testMessage = ""
        let snapshot = store.settings.snapshot()
        Task {
            do {
                let raw = try await AIClient().chatJSON(snapshot: snapshot, messages: [
                    AIClient.ChatMessage(role: "system", content: "只输出 JSON：{\"ok\":true,\"message\":\"success\"}"),
                    AIClient.ChatMessage(role: "user", content: "测试连接")
                ])
                await MainActor.run {
                    testMessage = "连接成功：\(AIClient.extractJSONObject(from: raw))"
                    isTesting = false
                }
            } catch {
                await MainActor.run {
                    testMessage = "连接失败：\(error.localizedDescription)"
                    isTesting = false
                }
            }
        }
    }
}

struct TimerRowView: View {
    @EnvironmentObject private var store: BrowserStore
    let timer: AgentTimerEntry

    var body: some View {
        TimelineView(.periodic(from: Date(), by: 1)) { _ in
            HStack(spacing: 8) {
                Image(systemName: timer.mode == .countDown ? "timer" : "stopwatch")
                    .foregroundStyle(timer.status == .running ? .cyan : .secondary)
                VStack(alignment: .leading, spacing: 2) {
                    Text(timer.title)
                        .font(.caption.weight(.semibold))
                        .lineLimit(1)
                    Text("\(timer.status.rawValue) · \(timer.displayTime) · \(timer.note)")
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                        .lineLimit(2)
                }
                Spacer()
                if timer.status == .running {
                    Button("取消") { store.cancelTimer(timer.id) }
                        .buttonStyle(.bordered)
                        .font(.caption2)
                }
            }
        }
    }
}

struct ThumbnailView: View {
    let image: UIImage?
    let title: String

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .fill(.white.opacity(0.10))
            if let image = image {
                Image(uiImage: image)
                    .resizable()
                    .scaledToFill()
                    .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
            } else {
                VStack(spacing: 4) {
                    Image(systemName: "globe")
                    Text(String(title.prefix(8)))
                        .font(.caption2)
                        .lineLimit(1)
                }
                .foregroundStyle(.secondary)
            }
        }
        .clipped()
        .overlay {
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .stroke(.white.opacity(0.12), lineWidth: 1)
        }
    }
}

struct LiquidGroupBoxStyle: GroupBoxStyle {
    func makeBody(configuration: Configuration) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            configuration.label
                .font(.headline)
            configuration.content
        }
        .padding(12)
        .background(.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 20, style: .continuous))
    }
}

extension GroupBoxStyle where Self == LiquidGroupBoxStyle {
    static var liquid: LiquidGroupBoxStyle { LiquidGroupBoxStyle() }
}
