import Foundation
import AVFoundation
import Vision

enum OpticalFlowQuality: String, CaseIterable, Identifiable {
    case fast
    case extreme
    case supremeAI

    var id: String { rawValue }

    var title: String {
        switch self {
        case .fast:
            return "1 快速"
        case .extreme:
            return "2 极限光流"
        case .supremeAI:
            return "3 终极AI混合"
        }
    }

    var subtitle: String {
        switch self {
        case .fast:
            return "低精度光流，速度优先"
        case .extreme:
            return "原光流 4：最高精度 + 更高码率，画质优先"
        case .supremeAI:
            return "原光流 7：双向 veryHigh + 更强一致性抑制 + 更低混合拖影 + 更强锐化，最慢，适合最终导出"
        }
    }

    var visionAccuracy: VNGenerateOpticalFlowRequest.ComputationAccuracy {
        switch self {
        case .fast:
            return .low
        case .extreme, .supremeAI:
            return .veryHigh
        }
    }

    var bitrateMultiplier: Double {
        switch self {
        case .fast:
            return 1.00
        case .extreme:
            return 1.85
        case .supremeAI:
            return 2.85
        }
    }

    var blendStrength: Float {
        switch self {
        case .fast:
            return 1.00
        case .extreme:
            return 0.70
        case .supremeAI:
            return 0.34
        }
    }

    var sharpenAmount: Float {
        switch self {
        case .fast:
            return 0.00
        case .extreme:
            return 0.12
        case .supremeAI:
            return 0.30
        }
    }

    var consistencyStrength: Float {
        switch self {
        case .supremeAI:
            return 1.00
        case .extreme:
            return 0.25
        case .fast:
            return 0.00
        }
    }

    var usesBidirectionalConsistency: Bool {
        self == .supremeAI
    }
}
enum ProcessingMode: String, CaseIterable, Identifiable {
    case full
    case serialSegmented
    case parallelSegmented

    var id: String { rawValue }

    var title: String {
        switch self {
        case .full:
            return "单次完整处理"
        case .serialSegmented:
            return "串行分段处理"
        case .parallelSegmented:
            return "并行分段处理"
        }
    }

    var subtitle: String {
        switch self {
        case .full:
            return "最简单，但长视频更容易爆内存"
        case .serialSegmented:
            return "稳定优先，适合 iPad 长视频"
        case .parallelSegmented:
            return "速度优先，发热/内存压力更高"
        }
    }
}

enum PerformanceMode: String, CaseIterable, Identifiable, Sendable {
    case standard
    case high
    case extreme

    var id: String { rawValue }

    var title: String {
        switch self {
        case .standard:
            return "标准"
        case .high:
            return "高性能"
        case .extreme:
            return "极限"
        }
    }

    var subtitle: String {
        switch self {
        case .standard:
            return "稳温控，适合日常补帧"
        case .high:
            return "更积极调度，适合短片/中等时长"
        case .extreme:
            return "最高优先级和更激进并行，发热和耗电更高"
        }
    }

    var taskPriority: TaskPriority {
        switch self {
        case .standard:
            return .medium
        case .high, .extreme:
            return .high
        }
    }

    var autoWorkerCap: Int {
        switch self {
        case .standard:
            return 2
        case .high:
            return 6
        case .extreme:
            return 32
        }
    }

    var memoryBudgetFraction: Double {
        switch self {
        case .standard:
            return 0.35
        case .high:
            return 0.60
        case .extreme:
            return 0.90
        }
    }
}

enum ParallelTuningMode: String, CaseIterable, Identifiable, Sendable {
    case manual
    case automatic
    case extreme

    var id: String { rawValue }

    var title: String {
        switch self {
        case .manual:
            return "手动"
        case .automatic:
            return "自动"
        case .extreme:
            return "极限"
        }
    }

    var subtitle: String {
        switch self {
        case .manual:
            return "手动输入分段数量和并行任务数"
        case .automatic:
            return "均衡稳定：参考性能测试结果，选择稳定但不明显慢的配置"
        case .extreme:
            return "极限：按 CPU 核心 ×2 作为并行任务数，并自动分段"
        }
    }
}

enum OutputMode: String, CaseIterable, Identifiable {
    case appleHEVC
    case h264Compatible
    case hdrPreserve

    var id: String { rawValue }

    var title: String {
        switch self {
        case .appleHEVC:
            return "Apple HEVC 兼容"
        case .h264Compatible:
            return "H.264 最稳兼容"
        case .hdrPreserve:
            return "HDR 保留模式"
        }
    }

    var fileType: AVFileType {
        switch self {
        case .appleHEVC, .hdrPreserve:
            return .mov
        case .h264Compatible:
            return .mp4
        }
    }

    var fileExtension: String {
        switch self {
        case .appleHEVC, .hdrPreserve:
            return "mov"
        case .h264Compatible:
            return "mp4"
        }
    }

    var codec: AVVideoCodecType {
        switch self {
        case .appleHEVC, .hdrPreserve:
            return .hevc
        case .h264Compatible:
            return .h264
        }
    }

    var wantsHDR: Bool {
        self == .hdrPreserve
    }
}

enum BitrateMode: String, CaseIterable, Identifiable {
    case automatic
    case customMbps

    var id: String { rawValue }

    var title: String {
        switch self {
        case .automatic:
            return "自动推荐"
        case .customMbps:
            return "手动 Mbps"
        }
    }
}

struct ProcessingOptions: Sendable {
    let targetFPS: Double
    let quality: OpticalFlowQuality
    let processingMode: ProcessingMode
    let segmentSeconds: Double
    let maxParallelJobs: Int
    let performanceMode: PerformanceMode
    let outputMode: OutputMode
    let bitrateMode: BitrateMode
    let customBitrateMbps: Double
    let keepAudio: Bool
    let keepMetadata: Bool
    let preserveHDRTags: Bool
    let enableSceneChangeDetection: Bool
    let enableDuplicateFrameDetection: Bool
    let enableMotionSafety: Bool
}

struct VideoFrame {
    let pixelBuffer: CVPixelBuffer
    let pts: CMTime
}

struct SegmentJob: Sendable {
    let index: Int
    let start: Double
    let duration: Double
}
