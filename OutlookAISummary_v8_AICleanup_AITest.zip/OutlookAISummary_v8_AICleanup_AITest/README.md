# Outlook AI Summary v8 QQ IMAP

QQ IMAP + Render 后端模式：

Outlook 转发/重定向 → QQ 邮箱 → Render 后端 IMAP 读取 → AI 中文总结 → iOS 推送/App 历史记录。

## v8 修改

- iOS 前端不再保存、显示或上传 `aiModel`、`aiBaseUrl`、`aiApiKey`。
- 设置页只保留后端地址、总结频率、自动总结、转发邮件解析、自动清理相关开关。
- 前端不再请求旧配置接口。
- QQ IMAP 邮箱连接状态只看 `GET /imap/test`。
- 新增“测试 AI 模型”按钮，调用 `POST /ai/test`，不读取邮件、不标记已读。
- 后端 `/settings` 会过滤旧 AI 字段，AI 配置只从 Render 环境变量读取。

## Render 环境变量

```text
MAIL_PROVIDER=qq
IMAP_HOST=imap.qq.com
IMAP_PORT=993
IMAP_SECURE=true
IMAP_USER=your_qq_email@qq.com
IMAP_PASS=your_qq_mail_authorization_code
AI_API_KEY=your_ai_key
AI_BASE_URL=https://your-ai-provider.example.com/v1/chat/completions
AI_MODEL=your-model-name
```

## 测试接口

```text
GET  https://your-render-service.onrender.com/health
GET  https://your-render-service.onrender.com/imap/test
POST https://your-render-service.onrender.com/ai/test
```

## 风险提醒

- `IMAP_PASS` 是 QQ 邮箱授权码，泄露后别人可能读取邮箱。
- 开启并配置 `IMAP_TRASH_MAILBOX` 后，自动清理会影响真实邮箱，建议先用小号测试。
