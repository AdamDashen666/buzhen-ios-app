import SwiftUI

struct QuadSelectionView: View {
    let image: UIImage
    @Binding var points: [CGPoint]   // normalized, image-space, 0...1
    @Binding var textPlaneCenter: CGPoint
    let overlayText: String
    let textScale: Double

    var body: some View {
        GeometryReader { geo in
            let imageRect = fittedRect(imageSize: image.size, container: geo.size)
            ZStack(alignment: .topLeading) {
                Image(uiImage: image)
                    .resizable()
                    .scaledToFit()
                    .frame(width: geo.size.width, height: geo.size.height)

                Path { path in
                    let display = (points.count == 4 ? QuadNormalizer.canonical(points) : points).map { toViewPoint($0, in: imageRect) }
                    if let first = display.first {
                        path.move(to: first)
                        for p in display.dropFirst() { path.addLine(to: p) }
                        if display.count == 4 { path.closeSubpath() }
                    }
                }
                .stroke(.yellow, lineWidth: 3)

                ForEach(Array(points.enumerated()), id: \.offset) { index, p in
                    let vp = toViewPoint(p, in: imageRect)
                    ZStack {
                        Circle().fill(.yellow).frame(width: 10, height: 10)
                        Circle().stroke(.black.opacity(0.75), lineWidth: 1).frame(width: 10, height: 10)
                        Text("\(index + 1)")
                            .font(.system(size: 7, weight: .bold))
                            .foregroundStyle(.black)
                    }
                    .frame(width: 28, height: 28)
                    .contentShape(Circle())
                    .position(vp)
                    .highPriorityGesture(
                        DragGesture(minimumDistance: 0, coordinateSpace: .named("quadSpace"))
                            .onChanged { value in
                                let n = toNormalized(value.location, in: imageRect)
                                guard points.indices.contains(index) else { return }
                                points[index] = CGPoint(
                                    x: min(max(n.x, 0), 1),
                                    y: min(max(n.y, 0), 1)
                                )
                            }
                            .onEnded { _ in
                                if points.count == 4 { points = QuadNormalizer.canonical(points) }
                            }
                    )
                }

                if points.count == 4 {
                    let display = QuadNormalizer.canonical(points).map { toViewPoint($0, in: imageRect) }
                    PerspectiveTextPreview(
                        text: overlayText.isEmpty ? "TEXT" : overlayText,
                        quad: display,
                        planeCenter: textPlaneCenter,
                        scale: textScale,
                        onDragChanged: { location in
                            if let planePoint = planePoint(for: location, in: display) {
                                textPlaneCenter = planePoint
                            }
                        }
                    )
                }
            }
            .coordinateSpace(name: "quadSpace")
            .contentShape(Rectangle())
            .gesture(
                SpatialTapGesture().onEnded { value in
                    let normalized = toNormalized(value.location, in: imageRect)
                    guard normalized.x >= 0, normalized.x <= 1, normalized.y >= 0, normalized.y <= 1 else { return }
                    if points.count >= 4 { points.removeAll() }
                    points.append(normalized)
                    if points.count == 4 {
                        points = QuadNormalizer.canonical(points)
                        textPlaneCenter = CGPoint(x: 0.5, y: 0.5)
                    }
                }
            )
        }
    }

    private func fittedRect(imageSize: CGSize, container: CGSize) -> CGRect {
        guard imageSize.width > 0, imageSize.height > 0 else { return CGRect(origin: .zero, size: container) }
        let imageAspect = imageSize.width / imageSize.height
        let containerAspect = container.width / container.height
        if imageAspect > containerAspect {
            let width = container.width
            let height = width / imageAspect
            return CGRect(x: 0, y: (container.height - height) / 2, width: width, height: height)
        } else {
            let height = container.height
            let width = height * imageAspect
            return CGRect(x: (container.width - width) / 2, y: 0, width: width, height: height)
        }
    }

    private func toNormalized(_ p: CGPoint, in rect: CGRect) -> CGPoint {
        CGPoint(x: (p.x - rect.minX) / rect.width, y: (p.y - rect.minY) / rect.height)
    }

    private func toViewPoint(_ p: CGPoint, in rect: CGRect) -> CGPoint {
        CGPoint(x: rect.minX + p.x * rect.width, y: rect.minY + p.y * rect.height)
    }

    private func planePoint(for viewPoint: CGPoint, in quad: [CGPoint]) -> CGPoint? {
        guard quad.count == 4 else { return nil }
        let src = [CGPoint(x: 0, y: 0), CGPoint(x: 1, y: 0), CGPoint(x: 1, y: 1), CGPoint(x: 0, y: 1)]
        guard let homography = HomographyEstimator.estimate(from: src, to: quad),
              let inverse = homography.inverted() else { return nil }
        return inverse.apply(viewPoint)
    }
}

struct PerspectiveTextPreview: View {
    let text: String
    let quad: [CGPoint]
    let planeCenter: CGPoint
    let scale: Double
    let onDragChanged: (CGPoint) -> Void

    var body: some View {
        if quad.count == 4 {
            let center = projectedCenter
            Text(text)
                .font(.system(size: CGFloat(max(12.0, 22.0 * scale)), weight: .heavy))
                .foregroundStyle(.white)
                .shadow(color: .black, radius: 4, x: 0, y: 1)
                .lineLimit(3)
                .multilineTextAlignment(.center)
                .frame(width: max(120, quadWidth * CGFloat(0.65 * scale)))
                .padding(.horizontal, 14)
                .padding(.vertical, 8)
                .background(.black.opacity(0.18), in: RoundedRectangle(cornerRadius: 12))
                .overlay(alignment: .topTrailing) {
                    Image(systemName: "hand.point.up.left.fill")
                        .font(.caption2)
                        .foregroundStyle(.yellow)
                        .padding(5)
                }
                .position(center)
                .gesture(
                    DragGesture(minimumDistance: 0)
                        .onChanged { value in
                            onDragChanged(value.location)
                        }
                )
        }
    }

    private var projectedCenter: CGPoint {
        let src = [CGPoint(x: 0, y: 0), CGPoint(x: 1, y: 0), CGPoint(x: 1, y: 1), CGPoint(x: 0, y: 1)]
        guard let h = HomographyEstimator.estimate(from: src, to: quad) else {
            return CGPoint(x: quad.map(\.x).reduce(0, +) / 4, y: quad.map(\.y).reduce(0, +) / 4)
        }
        return h.apply(planeCenter)
    }

    private var quadWidth: CGFloat {
        guard quad.count == 4 else { return 160 }
        let top = hypot(quad[1].x - quad[0].x, quad[1].y - quad[0].y)
        let bottom = hypot(quad[2].x - quad[3].x, quad[2].y - quad[3].y)
        return max(80, (top + bottom) / 2)
    }
}
