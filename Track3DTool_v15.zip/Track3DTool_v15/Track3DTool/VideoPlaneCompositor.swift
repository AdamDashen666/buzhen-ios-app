import Foundation
import AVFoundation
import CoreImage
import UIKit
import VideoToolbox

// v15 renderer:
// - Homography + RANSAC tracking for lower drift.
// - Optional original audio passthrough.
// - Safer staged initialization and H.264 default to reduce launch-time export crashes.
// - Plane-pose JSON export for AE / NodeVideo-style downstream workflows.

enum RenderError: LocalizedError {
    case missingVideoTrack
    case readerFailed
    case writerFailed
    case cannotCreateBuffer
    case invalidQuad
    case trackerInitFailed
    case audioCopyFailed

    var errorDescription: String? {
        switch self {
        case .missingVideoTrack: return "找不到视频轨道"
        case .readerFailed: return "读取视频失败"
        case .writerFailed: return "写入视频失败"
        case .cannotCreateBuffer: return "创建输出帧失败"
        case .invalidQuad: return "四点选择无效"
        case .trackerInitFailed: return "追踪初始化失败：选四点区域需要更清晰纹理"
        case .audioCopyFailed: return "音频复制失败"
        }
    }
}

struct VideoPlaneCompositor {
    static func render(
        inputURL: URL,
        normalizedQuad: [CGPoint],
        overlayText: String,
        overlaySettings: TextOverlaySettings,
        startTimeSeconds: Double,
        quality: TrackingQuality,
        outputProfile: OutputProfile,
        preserveAudio: Bool,
        exportCameraSolve: Bool,
        outputMaxDimension: Int? = nil,
        outputPrefix: String = "tracked_wall_text_v15",
        progress: @escaping @Sendable (Double, String) -> Void
    ) async throws -> URL {
        try await Task.detached(priority: .userInitiated) {
            try renderSync(
                inputURL: inputURL,
                normalizedQuad: normalizedQuad,
                overlayText: overlayText,
                overlaySettings: overlaySettings,
                startTimeSeconds: startTimeSeconds,
                quality: quality,
                outputProfile: outputProfile,
                preserveAudio: preserveAudio,
                exportCameraSolve: exportCameraSolve,
                outputMaxDimension: outputMaxDimension,
                outputPrefix: outputPrefix,
                progress: progress
            )
        }.value
    }

    static func buildPreviewFrames(
        inputURL: URL,
        normalizedQuad: [CGPoint],
        overlayText: String,
        overlaySettings: TextOverlaySettings,
        startTimeSeconds: Double,
        quality: TrackingQuality,
        outputMaxDimension: Int = 720,
        progress: @escaping @Sendable (Double, String) -> Void
    ) async throws -> [UIImage] {
        try await Task.detached(priority: .userInitiated) {
            try buildPreviewFramesSync(
                inputURL: inputURL,
                normalizedQuad: normalizedQuad,
                overlayText: overlayText,
                overlaySettings: overlaySettings,
                startTimeSeconds: startTimeSeconds,
                quality: quality,
                outputMaxDimension: outputMaxDimension,
                progress: progress
            )
        }.value
    }

    private static func renderSync(
        inputURL: URL,
        normalizedQuad: [CGPoint],
        overlayText: String,
        overlaySettings: TextOverlaySettings,
        startTimeSeconds: Double,
        quality: TrackingQuality,
        outputProfile: OutputProfile,
        preserveAudio: Bool,
        exportCameraSolve: Bool,
        outputMaxDimension: Int?,
        outputPrefix: String,
        progress: @escaping @Sendable (Double, String) -> Void
    ) throws -> URL {
        guard normalizedQuad.count == 4 else { throw RenderError.invalidQuad }
        let canonicalNormalizedQuad = QuadNormalizer.canonical(normalizedQuad)
        progress(0.13, "初始化 6/6：读取视频轨道...")
        let asset = AVAsset(url: inputURL)
        guard let videoTrack = asset.tracks(withMediaType: .video).first else { throw RenderError.missingVideoTrack }

        let naturalSize = videoTrack.naturalSize
        let sourceWidth = max(2, Int(abs(naturalSize.width)))
        let sourceHeight = max(2, Int(abs(naturalSize.height)))
        let sourceVideoSize = CGSize(width: CGFloat(sourceWidth), height: CGFloat(sourceHeight))
        let durationSeconds = max(0.1, asset.duration.seconds.isFinite ? asset.duration.seconds : 0.1)
        let safeStartSeconds = min(max(startTimeSeconds, 0), max(0, durationSeconds - 0.05))

        func evenDimension(_ value: Int) -> Int { max(2, value - (value % 2)) }
        let renderScale: CGFloat
        if let outputMaxDimension, outputMaxDimension > 0 {
            renderScale = min(1.0, CGFloat(outputMaxDimension) / CGFloat(max(sourceWidth, sourceHeight)))
        } else {
            renderScale = 1.0
        }
        let width = evenDimension(Int((CGFloat(sourceWidth) * renderScale).rounded()))
        let height = evenDimension(Int((CGFloat(sourceHeight) * renderScale).rounded()))
        let videoSize = CGSize(width: CGFloat(width), height: CGFloat(height))
        let targetScaleX = CGFloat(width) / CGFloat(sourceWidth)
        let targetScaleY = CGFloat(height) / CGFloat(sourceHeight)
        let sourceExtent = CGRect(x: 0, y: 0, width: CGFloat(sourceWidth), height: CGFloat(sourceHeight))
        let videoExtent = CGRect(x: 0, y: 0, width: CGFloat(width), height: CGFloat(height))

        let outputURL = try FileStore.outputURL(prefix: outputPrefix, ext: outputProfile.fileExtension)
        if FileManager.default.fileExists(atPath: outputURL.path) {
            try FileManager.default.removeItem(at: outputURL)
        }

        progress(0.15, "初始化：创建视频读取器...")
        let reader = try AVAssetReader(asset: asset)
        let readerOutput = AVAssetReaderTrackOutput(track: videoTrack, outputSettings: [
            kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA
        ])
        readerOutput.alwaysCopiesSampleData = false
        guard reader.canAdd(readerOutput) else { throw RenderError.readerFailed }
        reader.add(readerOutput)

        progress(0.17, outputMaxDimension == nil ? "初始化：创建原片导出写入器..." : "初始化：创建 720p 预览写入器...")
        let fileType: AVFileType = outputProfile == .hevcHDRPriority ? .mov : .mp4
        let writer = try AVAssetWriter(outputURL: outputURL, fileType: fileType)
        let videoSettings = makeVideoSettings(videoTrack: videoTrack, width: width, height: height, outputProfile: outputProfile)
        let writerInput = AVAssetWriterInput(mediaType: .video, outputSettings: videoSettings)
        writerInput.expectsMediaDataInRealTime = false
        writerInput.transform = videoTrack.preferredTransform

        let outputPixelFormat: OSType = kCVPixelFormatType_32BGRA
        let adaptor = AVAssetWriterInputPixelBufferAdaptor(
            assetWriterInput: writerInput,
            sourcePixelBufferAttributes: [
                kCVPixelBufferPixelFormatTypeKey as String: outputPixelFormat,
                kCVPixelBufferWidthKey as String: width,
                kCVPixelBufferHeightKey as String: height,
                kCVPixelBufferCGImageCompatibilityKey as String: true,
                kCVPixelBufferCGBitmapContextCompatibilityKey as String: true,
                kCVPixelBufferIOSurfacePropertiesKey as String: [:]
            ]
        )
        guard writer.canAdd(writerInput) else { throw RenderError.writerFailed }
        writer.add(writerInput)

        var audioOutput: AVAssetReaderTrackOutput?
        var audioInput: AVAssetWriterInput?
        if preserveAudio, let audioTrack = asset.tracks(withMediaType: .audio).first {
            let out = AVAssetReaderTrackOutput(track: audioTrack, outputSettings: nil)
            out.alwaysCopiesSampleData = false
            let input = AVAssetWriterInput(mediaType: .audio, outputSettings: nil)
            input.expectsMediaDataInRealTime = false
            if reader.canAdd(out), writer.canAdd(input) {
                reader.add(out)
                writer.add(input)
                audioOutput = out
                audioInput = input
            }
        }

        progress(0.20, "初始化：启动读取和写入会话...")
        guard reader.startReading() else { throw reader.error ?? RenderError.readerFailed }
        guard writer.startWriting() else { throw writer.error ?? RenderError.writerFailed }
        writer.startSession(atSourceTime: .zero)

        let workingColorSpace: CGColorSpace = outputProfile == .hevcHDRPriority
            ? (CGColorSpace(name: CGColorSpace.extendedLinearDisplayP3) ?? CGColorSpaceCreateDeviceRGB())
            : CGColorSpaceCreateDeviceRGB()
        let ciContext = CIContext(options: [.cacheIntermediates: false, .workingColorSpace: workingColorSpace])
        progress(0.22, "初始化：生成文字贴图...")
        guard let overlay = TextOverlayFactory.make(text: overlayText, videoSize: videoSize, settings: overlaySettings) else {
            throw RenderError.writerFailed
        }

        var tracker: PatchPlaneTracker?
        var frameIndex = 0
        var trackingRecords: [TrackedFrame] = []
        var audioWasCopied = false
        let selectedQuadPixels = canonicalNormalizedQuad.map { CGPoint(x: $0.x * CGFloat(sourceWidth), y: $0.y * CGFloat(sourceHeight)) }

        while let sample = readerOutput.copyNextSampleBuffer() {
            while !writerInput.isReadyForMoreMediaData {
                Thread.sleep(forTimeInterval: 0.002)
            }

            guard let srcBuffer = CMSampleBufferGetImageBuffer(sample) else { continue }
            let time = CMSampleBufferGetPresentationTimeStamp(sample)
            let timeSeconds = time.seconds.isFinite ? time.seconds : 0
            let shouldOverlay = timeSeconds + 0.0001 >= safeStartSeconds

            let sourceImage = CIImage(cvPixelBuffer: srcBuffer).cropped(to: sourceExtent)
            let baseImage: CIImage
            if width == sourceWidth && height == sourceHeight {
                baseImage = sourceImage.cropped(to: videoExtent)
            } else {
                baseImage = sourceImage
                    .transformed(by: CGAffineTransform(scaleX: targetScaleX, y: targetScaleY))
                    .cropped(to: videoExtent)
            }

            var composited = baseImage
            var statusText = "保留原视频，等待文字出现帧"
            var confidence = 0.0
            var inlierCount = 0

            if shouldOverlay, let gray = ImageGray.from(pixelBuffer: srcBuffer, maxWidth: quality.maxTrackWidth) {
                if tracker == nil {
                    progress(0.24, "初始化 Homography/RANSAC 追踪点...")
                    tracker = PatchPlaneTracker(initialImage: gray, quadInOriginalPixels: selectedQuadPixels, quality: quality)
                    let initialQuad = clampQuad(selectedQuadPixels, width: sourceWidth, height: sourceHeight)
                    let outputQuad = initialQuad.map { CGPoint(x: $0.x * targetScaleX, y: $0.y * targetScaleY) }
                    let pose = exportCameraSolve ? PlanePoseSolver.solve(imageQuad: initialQuad, videoSize: sourceVideoSize) : nil
                    trackingRecords.append(TrackedFrame(
                        frameIndex: frameIndex,
                        timeSeconds: timeSeconds,
                        quad: initialQuad.map(CGPointCodable.init),
                        confidence: 1.0,
                        inlierCount: initialQuad.count,
                        trackerStatus: "初始化帧",
                        planePose: pose
                    ))
                    let warpedOverlay = warp(overlay: overlay, baseQuad: outputQuad, settings: overlaySettings, frameHeight: CGFloat(height))
                    composited = warpedOverlay.composited(over: baseImage).cropped(to: videoExtent)
                    statusText = "初始化帧"
                    confidence = 1.0
                    inlierCount = initialQuad.count
                } else {
                    let tracked = tracker?.track(nextImage: gray) ?? PatchTrackResult(quadOriginalPixels: selectedQuadPixels, confidence: 0, inlierCount: 0, status: "未初始化")
                    confidence = tracked.confidence
                    inlierCount = tracked.inlierCount
                    statusText = tracked.status
                    let currentQuad = clampQuad(tracked.quadOriginalPixels, width: sourceWidth, height: sourceHeight)
                    let outputQuad = currentQuad.map { CGPoint(x: $0.x * targetScaleX, y: $0.y * targetScaleY) }
                    let pose = exportCameraSolve ? PlanePoseSolver.solve(imageQuad: currentQuad, videoSize: sourceVideoSize) : nil
                    trackingRecords.append(TrackedFrame(
                        frameIndex: frameIndex,
                        timeSeconds: timeSeconds,
                        quad: currentQuad.map(CGPointCodable.init),
                        confidence: confidence,
                        inlierCount: tracked.inlierCount,
                        trackerStatus: tracked.status,
                        planePose: pose
                    ))
                    let warpedOverlay = warp(overlay: overlay, baseQuad: outputQuad, settings: overlaySettings, frameHeight: CGFloat(height))
                    composited = warpedOverlay.composited(over: baseImage).cropped(to: videoExtent)
                }
            } else if shouldOverlay {
                statusText = "当前帧无法提取追踪特征，保留原画面"
            }

            guard let pool = adaptor.pixelBufferPool else { throw RenderError.cannotCreateBuffer }
            var outBufferOptional: CVPixelBuffer?
            CVPixelBufferPoolCreatePixelBuffer(nil, pool, &outBufferOptional)
            guard let outBuffer = outBufferOptional else { throw RenderError.cannotCreateBuffer }

            ciContext.render(composited, to: outBuffer, bounds: videoExtent, colorSpace: workingColorSpace)
            if !adaptor.append(outBuffer, withPresentationTime: time) {
                throw writer.error ?? RenderError.writerFailed
            }

            frameIndex += 1
            if frameIndex % 10 == 0 {
                let p = min(0.93, max(0.24, 0.24 + timeSeconds / durationSeconds * 0.69))
                if shouldOverlay {
                    progress(p, "第 \(frameIndex) 帧：\(statusText)，置信度 \(String(format: "%.2f", confidence))，内点 \(inlierCount)")
                } else {
                    progress(p, "第 \(frameIndex) 帧：保留原视频，文字将从 \(String(format: "%.2f", safeStartSeconds))s 出现")
                }
            }
        }

        writerInput.markAsFinished()

        if let audioOutput, let audioInput {
            progress(0.96, "正在保留原视频音频...")
            while let audioSample = audioOutput.copyNextSampleBuffer() {
                while !audioInput.isReadyForMoreMediaData {
                    Thread.sleep(forTimeInterval: 0.002)
                }
                if !audioInput.append(audioSample) {
                    throw writer.error ?? RenderError.audioCopyFailed
                }
                audioWasCopied = true
            }
            audioInput.markAsFinished()
        }

        writer.finishWriting {}
        while writer.status == .writing { Thread.sleep(forTimeInterval: 0.03) }
        if writer.status != .completed { throw writer.error ?? RenderError.writerFailed }
        if reader.status == .failed { throw reader.error ?? RenderError.readerFailed }

        if exportCameraSolve || outputMaxDimension == nil {
            try exportTrackingJSON(records: trackingRecords, beside: outputURL)
        }
        let audioText = preserveAudio ? (audioWasCopied ? "，已保留音频" : "，未检测到可复制音频") : ""
        let hdrText = outputProfile == .hevcHDRPriority ? "，HEVC/HDR 优先" : ""
        let previewText = outputMaxDimension == nil ? "" : "720p 预览"
        progress(1.0, "\(previewText)导出完成\(audioText)\(hdrText)")
        return outputURL
    }

    private static func buildPreviewFramesSync(
        inputURL: URL,
        normalizedQuad: [CGPoint],
        overlayText: String,
        overlaySettings: TextOverlaySettings,
        startTimeSeconds: Double,
        quality: TrackingQuality,
        outputMaxDimension: Int,
        progress: @escaping @Sendable (Double, String) -> Void
    ) throws -> [UIImage] {
        guard normalizedQuad.count == 4 else { throw RenderError.invalidQuad }
        let canonicalNormalizedQuad = QuadNormalizer.canonical(normalizedQuad)
        progress(0.14, "预览初始化：使用缓存抽帧器读取视频，不写入文件...")
        let asset = AVAsset(url: inputURL)
        guard let videoTrack = asset.tracks(withMediaType: .video).first else { throw RenderError.missingVideoTrack }
        let durationSeconds = max(0.1, asset.duration.seconds.isFinite ? asset.duration.seconds : 0.1)
        let safeStartSeconds = min(max(startTimeSeconds, 0), max(0, durationSeconds - 0.05))

        let generator = AVAssetImageGenerator(asset: asset)
        generator.appliesPreferredTrackTransform = false
        generator.requestedTimeToleranceBefore = CMTime(seconds: 0.025, preferredTimescale: 600)
        generator.requestedTimeToleranceAfter = CMTime(seconds: 0.025, preferredTimescale: 600)
        let naturalSize = videoTrack.naturalSize
        generator.maximumSize = CGSize(width: max(2, abs(naturalSize.width)), height: max(2, abs(naturalSize.height)))

        let firstTime = CMTime(seconds: safeStartSeconds, preferredTimescale: 600)
        let firstCG = try generator.copyCGImage(at: firstTime, actualTime: nil)
        let sourceWidth = max(2, firstCG.width)
        let sourceHeight = max(2, firstCG.height)
        let sourceVideoSize = CGSize(width: CGFloat(sourceWidth), height: CGFloat(sourceHeight))

        func evenDimension(_ value: Int) -> Int { max(2, value - (value % 2)) }
        let renderScale = min(1.0, CGFloat(max(2, outputMaxDimension)) / CGFloat(max(sourceWidth, sourceHeight)))
        let width = evenDimension(Int((CGFloat(sourceWidth) * renderScale).rounded()))
        let height = evenDimension(Int((CGFloat(sourceHeight) * renderScale).rounded()))
        let videoSize = CGSize(width: CGFloat(width), height: CGFloat(height))
        let targetScaleX = CGFloat(width) / CGFloat(sourceWidth)
        let targetScaleY = CGFloat(height) / CGFloat(sourceHeight)
        let videoExtent = CGRect(x: 0, y: 0, width: CGFloat(width), height: CGFloat(height))

        let workingColorSpace = CGColorSpaceCreateDeviceRGB()
        let ciContext = CIContext(options: [.cacheIntermediates: false, .workingColorSpace: workingColorSpace])
        guard let overlay = TextOverlayFactory.make(text: overlayText, videoSize: videoSize, settings: overlaySettings) else {
            throw RenderError.writerFailed
        }

        var tracker: PatchPlaneTracker?
        var frames: [UIImage] = []
        let selectedQuadPixels = canonicalNormalizedQuad.map { CGPoint(x: $0.x * CGFloat(sourceWidth), y: $0.y * CGFloat(sourceHeight)) }
        let previewSeconds = min(7.0, max(1.0, durationSeconds - safeStartSeconds))
        let previewEnd = min(durationSeconds, safeStartSeconds + previewSeconds)
        let frameInterval = 1.0 / 12.0
        let maxStoredFrames = 96
        var timeSeconds = safeStartSeconds
        var frameIndex = 0

        progress(0.18, "预览：开始本地抽帧追踪，失败会生成可复制日志...")
        while timeSeconds <= previewEnd + 0.0001 && frames.count < maxStoredFrames {
            let cg: CGImage
            if frameIndex == 0 {
                cg = firstCG
            } else {
                cg = try generator.copyCGImage(at: CMTime(seconds: timeSeconds, preferredTimescale: 600), actualTime: nil)
            }

            let sourceImage = CIImage(cgImage: cg)
            let baseImage = sourceImage
                .transformed(by: CGAffineTransform(scaleX: targetScaleX, y: targetScaleY))
                .cropped(to: videoExtent)

            var composited = baseImage
            var statusText = "抽帧追踪中"
            var confidence = 0.0
            var inlierCount = 0

            if let gray = ImageGray.from(cgImage: cg, maxWidth: quality.maxTrackWidth) {
                if tracker == nil {
                    tracker = PatchPlaneTracker(initialImage: gray, quadInOriginalPixels: selectedQuadPixels, quality: quality)
                    let initialQuad = clampQuad(selectedQuadPixels, width: sourceWidth, height: sourceHeight)
                    let outputQuad = initialQuad.map { CGPoint(x: $0.x * targetScaleX, y: $0.y * targetScaleY) }
                    let warpedOverlay = warp(overlay: overlay, baseQuad: outputQuad, settings: overlaySettings, frameHeight: CGFloat(height))
                    composited = warpedOverlay.composited(over: baseImage).cropped(to: videoExtent)
                    statusText = "初始化帧"
                    confidence = 1.0
                    inlierCount = 4
                    _ = PlanePoseSolver.solve(imageQuad: initialQuad, videoSize: sourceVideoSize)
                } else {
                    let tracked = tracker?.track(nextImage: gray) ?? PatchTrackResult(quadOriginalPixels: selectedQuadPixels, confidence: 0, inlierCount: 0, status: "未初始化")
                    let currentQuad = clampQuad(tracked.quadOriginalPixels, width: sourceWidth, height: sourceHeight)
                    let outputQuad = currentQuad.map { CGPoint(x: $0.x * targetScaleX, y: $0.y * targetScaleY) }
                    let warpedOverlay = warp(overlay: overlay, baseQuad: outputQuad, settings: overlaySettings, frameHeight: CGFloat(height))
                    composited = warpedOverlay.composited(over: baseImage).cropped(to: videoExtent)
                    statusText = tracked.status
                    confidence = tracked.confidence
                    inlierCount = tracked.inlierCount
                }
            } else {
                statusText = "当前帧无法转灰度，保留画面"
            }

            if let outCG = ciContext.createCGImage(composited, from: videoExtent) {
                frames.append(UIImage(cgImage: outCG))
            }

            frameIndex += 1
            if frameIndex % 4 == 0 {
                let local = min(1.0, max(0.0, (timeSeconds - safeStartSeconds) / max(0.1, previewEnd - safeStartSeconds)))
                progress(0.20 + local * 0.76, "预览抽帧 \(frameIndex)：\(statusText)，置信度 \(String(format: "%.2f", confidence))，内点 \(inlierCount)")
            }
            timeSeconds += frameInterval
        }

        if frames.isEmpty { throw RenderError.readerFailed }
        progress(1.0, "720p 内存预览完成，共 \(frames.count) 帧")
        return frames
    }

    private static func makeVideoSettings(videoTrack: AVAssetTrack, width: Int, height: Int, outputProfile: OutputProfile) -> [String: Any] {
        let bitrate = min(80_000_000, max(6_000_000, width * height * (outputProfile == .hevcHDRPriority ? 8 : 5)))
        var settings: [String: Any] = [
            AVVideoCodecKey: outputProfile == .hevcHDRPriority ? AVVideoCodecType.hevc : AVVideoCodecType.h264,
            AVVideoWidthKey: width,
            AVVideoHeightKey: height,
            AVVideoCompressionPropertiesKey: outputProfile == .hevcHDRPriority ? [
                AVVideoAverageBitRateKey: bitrate,
                AVVideoProfileLevelKey: kVTProfileLevel_HEVC_Main10_AutoLevel as String
            ] : [
                AVVideoAverageBitRateKey: bitrate,
                AVVideoProfileLevelKey: AVVideoProfileLevelH264HighAutoLevel
            ]
        ]

        if outputProfile == .hevcHDRPriority {
            var colorProps = HDRMetadataReader.colorProperties(from: videoTrack)
            if colorProps.isEmpty {
                colorProps = [
                    AVVideoColorPrimariesKey: AVVideoColorPrimaries_P3_D65,
                    AVVideoTransferFunctionKey: AVVideoTransferFunction_ITU_R_709_2,
                    AVVideoYCbCrMatrixKey: AVVideoYCbCrMatrix_ITU_R_709_2
                ]
            }
            settings[AVVideoColorPropertiesKey] = colorProps
            settings[AVVideoAllowWideColorKey] = true
        }
        return settings
    }

    private static func warp(overlay: CIImage, baseQuad quad: [CGPoint], settings: TextOverlaySettings, frameHeight: CGFloat) -> CIImage {
        func ci(_ p: CGPoint) -> CIVector { CIVector(x: p.x, y: frameHeight - p.y) }
        let canonical = [CGPoint(x: 0, y: 0), CGPoint(x: 1, y: 0), CGPoint(x: 1, y: 1), CGPoint(x: 0, y: 1)]
        let destinationQuad: [CGPoint]
        if let h = HomographyEstimator.estimate(from: canonical, to: quad) {
            let cx = CGFloat(settings.planeCenterX)
            let cy = CGFloat(settings.planeCenterY)
            let localRect = [
                CGPoint(x: cx - 0.5, y: cy - 0.5),
                CGPoint(x: cx + 0.5, y: cy - 0.5),
                CGPoint(x: cx + 0.5, y: cy + 0.5),
                CGPoint(x: cx - 0.5, y: cy + 0.5)
            ]
            destinationQuad = localRect.map { h.apply($0) }
        } else {
            destinationQuad = quad
        }
        return overlay.applyingFilter("CIPerspectiveTransform", parameters: [
            "inputTopLeft": ci(destinationQuad[0]),
            "inputTopRight": ci(destinationQuad[1]),
            "inputBottomRight": ci(destinationQuad[2]),
            "inputBottomLeft": ci(destinationQuad[3])
        ])
    }

    private static func clampQuad(_ q: [CGPoint], width: Int, height: Int) -> [CGPoint] {
        q.map { p in
            CGPoint(
                x: min(max(p.x, 0), CGFloat(width - 1)),
                y: min(max(p.y, 0), CGFloat(height - 1))
            )
        }
    }

    private static func exportTrackingJSON(records: [TrackedFrame], beside videoURL: URL) throws {
        let jsonURL = videoURL.deletingPathExtension().appendingPathExtension("json")
        let data = try JSONEncoder.pretty.encode(records)
        try data.write(to: jsonURL)
    }
}

private enum HDRMetadataReader {
    static func colorProperties(from track: AVAssetTrack) -> [String: Any] {
        guard let rawDescription = track.formatDescriptions.first else {
            return [:]
        }

        // AVAssetTrack.formatDescriptions is exposed as [Any] on some SDKs.
        // CMFormatDescription is a CoreFoundation type, so use a forced bridge here
        // instead of `as?`, which Xcode 26.2 can treat as an invalid conditional cast.
        let description = rawDescription as! CMFormatDescription

        guard let rawExtensions = CMFormatDescriptionGetExtensions(description) else {
            return [:]
        }
        let extensions = rawExtensions as NSDictionary

        var props: [String: Any] = [:]
        let colorPrimaries = value(for: kCMFormatDescriptionExtension_ColorPrimaries as String, in: extensions)
        let transfer = value(for: kCMFormatDescriptionExtension_TransferFunction as String, in: extensions)
        let matrix = value(for: kCMFormatDescriptionExtension_YCbCrMatrix as String, in: extensions)

        props[AVVideoColorPrimariesKey] = mapColorPrimaries(colorPrimaries)
        props[AVVideoTransferFunctionKey] = mapTransfer(transfer)
        props[AVVideoYCbCrMatrixKey] = mapMatrix(matrix)
        return props
    }

    private static func value(for key: String, in dict: NSDictionary) -> String? {
        if let v = dict[key] as? String { return v }
        if let v = dict[key] { return "\(v)" }
        return nil
    }

    private static func mapColorPrimaries(_ value: String?) -> String {
        guard let value else { return AVVideoColorPrimaries_P3_D65 }
        if value.contains("2020") { return AVVideoColorPrimaries_ITU_R_2020 }
        if value.lowercased().contains("p3") { return AVVideoColorPrimaries_P3_D65 }
        return AVVideoColorPrimaries_ITU_R_709_2
    }

    private static func mapTransfer(_ value: String?) -> String {
        guard let value else { return AVVideoTransferFunction_ITU_R_709_2 }
        let lower = value.lowercased()
        if lower.contains("2084") || lower.contains("pq") { return AVVideoTransferFunction_SMPTE_ST_2084_PQ }
        if lower.contains("hlg") || lower.contains("2100") { return AVVideoTransferFunction_ITU_R_2100_HLG }
        return AVVideoTransferFunction_ITU_R_709_2
    }

    private static func mapMatrix(_ value: String?) -> String {
        guard let value else { return AVVideoYCbCrMatrix_ITU_R_709_2 }
        if value.contains("2020") { return AVVideoYCbCrMatrix_ITU_R_2020 }
        return AVVideoYCbCrMatrix_ITU_R_709_2
    }
}

private extension JSONEncoder {
    static var pretty: JSONEncoder {
        let e = JSONEncoder()
        e.outputFormatting = [.prettyPrinted, .sortedKeys]
        return e
    }
}
