import Foundation
import CoreGraphics

struct PatchTrackResult {
    let quadOriginalPixels: [CGPoint]
    let confidence: Double
    let inlierCount: Int
    let status: String
}

final class PatchPlaneTracker {
    private struct TrackPoint {
        let initial: CGPoint
        var current: CGPoint
        let template: [UInt8]
        let texture: Double
        var lostFrames: Int
    }

    private var points: [TrackPoint] = []
    private let initialQuad: [CGPoint]
    private let quality: TrackingQuality
    private var lastHomography: Homography2D = .identity
    private var lastGoodQuad: [CGPoint]
    private var frameCounter = 0
    private var lockMode = false

    init(initialImage: ImageGray, quadInOriginalPixels: [CGPoint], quality: TrackingQuality) {
        self.quality = quality
        let ordered = QuadNormalizer.canonical(quadInOriginalPixels)
        let s = initialImage.scaleFromOriginal
        self.initialQuad = ordered.map { CGPoint(x: $0.x * s, y: $0.y * s) }
        self.lastGoodQuad = self.initialQuad
        self.points = Self.makeTrackPoints(image: initialImage, quad: self.initialQuad, quality: quality)
        self.lockMode = self.points.count < 4
    }

    func track(nextImage: ImageGray) -> PatchTrackResult {
        frameCounter += 1
        if lockMode || points.count < 4 {
            return result(quad: lastGoodQuad, scale: nextImage.scaleFromOriginal, confidence: 0.12, inliers: points.count, status: "低纹理：锁定初始平面")
        }

        let radius = quality.patchRadius
        let baseSearch = quality.searchRadius
        var src: [CGPoint] = []
        var dst: [CGPoint] = []
        var pointIndices: [Int] = []
        var newPoints = points
        var scores: [Double] = []

        for i in 0..<newPoints.count {
            let predicted = lastHomography.apply(newPoints[i].initial)
            let backupPredicted = newPoints[i].current
            let search = min(baseSearch * 2, baseSearch + newPoints[i].lostFrames * 5)
            let first = bestMatch(image: nextImage, template: newPoints[i].template, predicted: predicted, radius: radius, search: search)
            let second = bestMatch(image: nextImage, template: newPoints[i].template, predicted: backupPredicted, radius: radius, search: max(8, baseSearch / 2))

            let candidate: (CGPoint, Double)?
            if let first, let second {
                candidate = first.1 >= second.1 ? first : second
            } else {
                candidate = first ?? second
            }

            let relaxedThreshold = max(0.34, quality.minNCC - 0.10)
            if let candidate, candidate.1 >= relaxedThreshold {
                src.append(newPoints[i].initial)
                dst.append(candidate.0)
                pointIndices.append(i)
                scores.append(candidate.1)
                newPoints[i].current = candidate.0
                newPoints[i].lostFrames = 0
            } else {
                newPoints[i].lostFrames += 1
            }
        }

        if src.count >= 4,
           let robust = HomographyEstimator.robust(from: src, to: dst, threshold: quality.ransacError * 1.25) {
            let proposedQuad = initialQuad.map { robust.model.apply($0) }
            if isSaneQuad(proposedQuad, image: nextImage) {
                var inlierScores: [Double] = []
                for inlier in robust.inliers {
                    if inlier < scores.count { inlierScores.append(scores[inlier]) }
                    if inlier < pointIndices.count {
                        let idx = pointIndices[inlier]
                        newPoints[idx].current = robust.model.apply(newPoints[idx].initial)
                        newPoints[idx].lostFrames = 0
                    }
                }

                lastHomography = robust.model
                lastGoodQuad = proposedQuad
                self.points = newPoints

                let rawScore = inlierScores.isEmpty ? 0 : inlierScores.reduce(0, +) / Double(inlierScores.count)
                let coverage = min(1.0, Double(robust.inliers.count) / Double(max(4, points.count / 2)))
                let confidence = max(0.0, min(1.0, rawScore * coverage))
                let status: String
                if confidence > 0.70 {
                    status = "稳定"
                } else if confidence > 0.45 {
                    status = "可用，轻微漂移风险"
                } else {
                    status = "低置信度，已锁定防漂移"
                }
                return result(quad: proposedQuad, scale: nextImage.scaleFromOriginal, confidence: confidence, inliers: robust.inliers.count, status: status)
            }
        }

        self.points = newPoints
        return result(quad: lastGoodQuad, scale: nextImage.scaleFromOriginal, confidence: 0.18, inliers: src.count, status: "追踪不可靠：锁定上一帧防乱飞")
    }

    private func result(quad: [CGPoint], scale: CGFloat, confidence: Double, inliers: Int, status: String) -> PatchTrackResult {
        let inv = 1 / scale
        let originalQ = QuadNormalizer.canonical(quad.map { CGPoint(x: $0.x * inv, y: $0.y * inv) })
        return PatchTrackResult(quadOriginalPixels: originalQ, confidence: confidence, inlierCount: inliers, status: status)
    }

    private static func makeTrackPoints(image: ImageGray, quad: [CGPoint], quality: TrackingQuality) -> [TrackPoint] {
        let radius = quality.patchRadius
        var candidates: [TrackPoint] = []

        // 1) Points inside the selected plane.
        for gy in 0..<max(quality.gridY, 6) {
            for gx in 0..<max(quality.gridX, 8) {
                let u = CGFloat(gx + 1) / CGFloat(max(quality.gridX, 8) + 1)
                let v = CGFloat(gy + 1) / CGFloat(max(quality.gridY, 6) + 1)
                let p = bilinear(quad, u: u, v: v)
                if let patch = image.patch(center: p, radius: radius) {
                    let energy = textureEnergy(patch)
                    if energy > 2.5 {
                        candidates.append(TrackPoint(initial: p, current: p, template: patch, texture: energy, lostFrames: 0))
                    }
                }
            }
        }

        // 2) If the plane is too flat, search a slightly expanded bounding box.
        if candidates.count < 10 {
            let xs = quad.map(\.x)
            let ys = quad.map(\.y)
            let rawMinX = xs.min() ?? 0
            let rawMaxX = xs.max() ?? 0
            let rawMinY = ys.min() ?? 0
            let rawMaxY = ys.max() ?? 0
            let padX = max(CGFloat(16), rawMaxX - rawMinX) * 0.35
            let padY = max(CGFloat(16), rawMaxY - rawMinY) * 0.35
            let minX = max(CGFloat(radius + 2), rawMinX - padX)
            let maxX = min(CGFloat(image.width - radius - 2), rawMaxX + padX)
            let minY = max(CGFloat(radius + 2), rawMinY - padY)
            let maxY = min(CGFloat(image.height - radius - 2), rawMaxY + padY)
            let gxCount = max(10, quality.gridX + 4)
            let gyCount = max(8, quality.gridY + 3)
            for gy in 0..<gyCount {
                for gx in 0..<gxCount {
                    let x = minX + (maxX - minX) * CGFloat(gx) / CGFloat(max(1, gxCount - 1))
                    let y = minY + (maxY - minY) * CGFloat(gy) / CGFloat(max(1, gyCount - 1))
                    let p = CGPoint(x: x, y: y)
                    if let patch = image.patch(center: p, radius: radius) {
                        let energy = textureEnergy(patch)
                        if energy > 3.5 {
                            candidates.append(TrackPoint(initial: p, current: p, template: patch, texture: energy, lostFrames: 0))
                        }
                    }
                }
            }
        }

        // Stronger corners first, but cap count to keep iPad interactive.
        var unique: [TrackPoint] = []
        for c in candidates.sorted(by: { $0.texture > $1.texture }) {
            if unique.contains(where: { hypot($0.initial.x - c.initial.x, $0.initial.y - c.initial.y) < CGFloat(radius * 2) }) { continue }
            unique.append(c)
            if unique.count >= 72 { break }
        }
        return unique
    }

    private func isSaneQuad(_ q: [CGPoint], image: ImageGray) -> Bool {
        guard q.count == 4 else { return false }
        if q.contains(where: { !$0.x.isFinite || !$0.y.isFinite }) { return false }
        let margin = CGFloat(max(image.width, image.height)) * 0.20
        for p in q {
            if p.x < -margin || p.y < -margin || p.x > CGFloat(image.width) + margin || p.y > CGFloat(image.height) + margin { return false }
        }
        let initialArea = abs(polygonArea(initialQuad))
        let proposedArea = abs(polygonArea(q))
        if initialArea > 1 {
            if proposedArea < initialArea * 0.18 || proposedArea > initialArea * 5.0 { return false }
        }
        let jumpLimit = CGFloat(max(image.width, image.height)) * 0.28
        let maxJump = zip(q, lastGoodQuad).map { pair in hypot(pair.0.x - pair.1.x, pair.0.y - pair.1.y) }.max() ?? 0
        return maxJump <= jumpLimit
    }

    private func bestMatch(image: ImageGray, template: [UInt8], predicted: CGPoint, radius: Int, search: Int) -> (CGPoint, Double)? {
        var bestScore = -Double.greatestFiniteMagnitude
        var best = predicted
        let centerX = Int(round(predicted.x))
        let centerY = Int(round(predicted.y))
        let step = search > 24 ? 2 : 1

        for dy in stride(from: -search, through: search, by: step) {
            for dx in stride(from: -search, through: search, by: step) {
                let candidate = CGPoint(x: CGFloat(centerX + dx), y: CGFloat(centerY + dy))
                guard let patch = image.patch(center: candidate, radius: radius) else { continue }
                let score = ncc(template, patch)
                if score > bestScore {
                    bestScore = score
                    best = candidate
                }
            }
        }

        if step > 1 {
            let coarse = best
            for dy in -2...2 {
                for dx in -2...2 {
                    let candidate = CGPoint(x: coarse.x + CGFloat(dx), y: coarse.y + CGFloat(dy))
                    guard let patch = image.patch(center: candidate, radius: radius) else { continue }
                    let score = ncc(template, patch)
                    if score > bestScore {
                        bestScore = score
                        best = candidate
                    }
                }
            }
        }
        return bestScore.isFinite ? (best, bestScore) : nil
    }

    private static func bilinear(_ q: [CGPoint], u: CGFloat, v: CGFloat) -> CGPoint {
        let top = CGPoint(x: q[0].x + (q[1].x - q[0].x) * u, y: q[0].y + (q[1].y - q[0].y) * u)
        let bottom = CGPoint(x: q[3].x + (q[2].x - q[3].x) * u, y: q[3].y + (q[2].y - q[3].y) * u)
        return CGPoint(x: top.x + (bottom.x - top.x) * v, y: top.y + (bottom.y - top.y) * v)
    }

    private static func textureEnergy(_ patch: [UInt8]) -> Double {
        guard !patch.isEmpty else { return 0 }
        let mean = patch.reduce(0.0) { $0 + Double($1) } / Double(patch.count)
        let variance = patch.reduce(0.0) { acc, px in
            let d = Double(px) - mean
            return acc + d * d
        } / Double(patch.count)
        return sqrt(variance)
    }

    private func ncc(_ a: [UInt8], _ b: [UInt8]) -> Double {
        guard a.count == b.count, !a.isEmpty else { return -1 }
        let n = Double(a.count)
        var meanA = 0.0
        var meanB = 0.0
        for i in 0..<a.count {
            meanA += Double(a[i])
            meanB += Double(b[i])
        }
        meanA /= n
        meanB /= n
        var num = 0.0
        var da = 0.0
        var db = 0.0
        for i in 0..<a.count {
            let x = Double(a[i]) - meanA
            let y = Double(b[i]) - meanB
            num += x * y
            da += x * x
            db += y * y
        }
        let denom = sqrt(da * db)
        guard denom > 1e-6 else { return -1 }
        return num / denom
    }

    private func polygonArea(_ q: [CGPoint]) -> CGFloat {
        guard q.count >= 3 else { return 0 }
        var a: CGFloat = 0
        for i in 0..<q.count {
            let j = (i + 1) % q.count
            a += q[i].x * q[j].y - q[j].x * q[i].y
        }
        return a * 0.5
    }
}
