# 第三方 API 连接说明

## 网易云 NeteaseCloudMusicApi

### 1. 启动服务

```bash
git clone https://github.com/Binaryify/NeteaseCloudMusicApi.git
cd NeteaseCloudMusicApi
npm install
node app.js
```

默认端口通常是：

```text
http://localhost:3000
```

### 2. iOS 端填写 Base URL

- 模拟器：`http://127.0.0.1:3000`
- 真机 / iPad：`http://电脑局域网IP:3000`

例子：

```text
http://192.168.1.23:3000
```

### 3. 登录流程

进入 App：

```text
Settings → NetEase API Base URL → QR 登录
```

扫码成功后，App 会保存服务返回的 Cookie，并在搜索、获取播放 URL、歌词请求里带上。

## QQ / Custom API

不同 QQ 音乐第三方 API 的接口差异很大，所以当前版本只留了：

- QQ / Custom Base URL
- Cookie / Token 输入位

后续可以按你实际用的服务，把接口模板补进 `QQGenericService.swift`。
