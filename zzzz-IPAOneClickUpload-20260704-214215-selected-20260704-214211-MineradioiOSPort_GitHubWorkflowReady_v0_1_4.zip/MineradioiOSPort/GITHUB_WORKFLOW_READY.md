# GitHub Workflow Ready Notes

这个版本已经按 GitHub Actions 打包 iOS IPA 的常见结构整理。

## 固定信息

```text
Project: MineradioiOS.xcodeproj
Scheme: MineradioiOS
Configuration: Release
SDK: iphoneos
Output: unsigned IPA
```

## 已适配点

- 已添加共享 scheme：`MineradioiOS.xcodeproj/xcshareddata/xcschemes/MineradioiOS.xcscheme`
- 已确保 `SettingsView.swift` 加入 Xcode target，否则 CI 会找不到 `SettingsView`
- 已附带独立 workflow：`.github/workflows/build-app.yml`
- workflow 使用 `CODE_SIGNING_ALLOWED=NO`，适合打 unsigned IPA
- workflow 会生成：
  - `MineradioiOS-unsigned.ipa`
  - `MineradioiOS-unsigned.ipa.sha256`
  - diagnostics artifact：`build.log` / `app-info.txt`

## 如果用你已有的仓库 workflow

把这个 zip 上传到你的打包仓库即可。你的旧 workflow 只要是“自动找 zip → 解压 → 找 `.xcodeproj` → 找 scheme → xcodebuild → Payload 打 IPA”的逻辑，就应该能识别：

```text
MineradioiOSPort/MineradioiOS.xcodeproj
MineradioiOS
```

如果 workflow 需要手动填参数，就填：

```text
FILE=MineradioiOS.xcodeproj
SCHEME=MineradioiOS
```

若 workflow 是递归找项目，通常不用手动改路径。
