# Changelog

## 0.1.4 - 2026-07-04

- Replaced SwiftUI `fileImporter` with a UIKit `UIDocumentPickerViewController` bridge to fix the issue where tapping Open in Files may do nothing on sideloaded/imported builds.
- Added robust security-scoped + `NSFileCoordinator` copy logic for Files/iCloud audio import.
- Added visible import status and per-file failure messages.
- Expanded accepted audio extensions: MP3, FLAC, M4A, AAC, WAV, AIFF, OGG, OPUS.
- Enabled document sharing/open-in-place Info.plist flags for easier Files access.
- Upgraded the particle background to a higher-fidelity Mineradio-style stage: denser particle field, nebula glow, link lines, drifting dust, and pulse rings.
- Updated marketing version to `0.1.4`.

## 0.1.3 - 2026-07-04

- 修复 unsigned IPA 导入失败：补齐 Info.plist 的 `CFBundleExecutable`。
- 补齐 iOS App Bundle 必需字段：`CFBundleIdentifier`、`CFBundlePackageType`、`CFBundleShortVersionString`、`CFBundleVersion`、`LSRequiresIPhoneOS`。
- 保持 GitHub Actions workflow-ready 结构不变。


## 0.1.2 - CI Compile Fix

- Fixed Xcode 26 / SwiftUI compile error in `ParticleBackgroundView.swift` caused by accessing `LinearGradient.gradient`.
- Replaced deprecated `AVAudioSession.CategoryOptions.allowBluetooth` with `allowBluetoothHFP`.
- Updated local audio metadata reading to the modern async AVFoundation loading API.
- Updated project marketing version to `0.1.2`.

## 0.1.1 - GitHub Workflow Ready

- Added shared Xcode scheme: `MineradioiOS.xcscheme`.
- Added GitHub Actions workflow for unsigned IPA build.
- Added CI hints file: `ci/PROJECT_INFO.env`.
- Fixed Xcode target membership for `SettingsView.swift`.
- Updated project marketing version to `0.1.1`.
- Added workflow usage notes.

## 0.1.0 - Initial iOS Port MVP

- Added native SwiftUI Xcode project.
- Added local audio import and playback using AVFoundation.
- Added Mineradio-style particle background and lyric stage.
- Added 3D playlist shelf cards.
- Added settings for third-party API base URLs.
- Added NetEase QR login, search, stream URL, and lyric API client.
- Added placeholder QQ / custom provider settings for future adapter work.
- Added app icon, default cover, and stage backdrop assets.
