import Foundation

struct SongItem: Identifiable, Codable, Hashable {
    var id: String
    var provider: MusicProvider
    var title: String
    var artist: String
    var album: String?
    var coverURL: String?
    var localFileName: String?
    var remoteSongID: String?
    var remoteURL: String?

    var subtitle: String {
        if let album, !album.isEmpty {
            return "\(artist) · \(album)"
        }
        return artist
    }
}

enum MusicProvider: String, Codable, CaseIterable, Identifiable {
    case local
    case netease
    case qq
    case custom

    var id: String { rawValue }
    var displayName: String {
        switch self {
        case .local: return "Local"
        case .netease: return "NetEase"
        case .qq: return "QQ / Custom"
        case .custom: return "Custom"
        }
    }
}

enum ProviderKind: String, CaseIterable, Identifiable {
    case local
    case netease
    case qq

    var id: String { rawValue }
}

struct LyricLine: Identifiable, Hashable {
    let id = UUID()
    let time: TimeInterval
    let text: String
}

enum MineradioError: LocalizedError {
    case invalidBaseURL
    case invalidResponse
    case missingStreamURL
    case unsupportedProvider
    case fileImportFailed

    var errorDescription: String? {
        switch self {
        case .invalidBaseURL: return "API 地址无效。"
        case .invalidResponse: return "接口返回格式不符合预期。"
        case .missingStreamURL: return "没有拿到可播放链接，可能受版权、会员或地区限制。"
        case .unsupportedProvider: return "当前服务暂未实现这个接口。"
        case .fileImportFailed: return "文件导入失败。"
        }
    }
}
