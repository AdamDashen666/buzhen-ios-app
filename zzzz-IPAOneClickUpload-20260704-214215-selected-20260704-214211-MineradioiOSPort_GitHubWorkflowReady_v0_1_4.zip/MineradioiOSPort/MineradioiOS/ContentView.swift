import SwiftUI

struct ContentView: View {
    @EnvironmentObject private var settings: SettingsStore

    var body: some View {
        TabView(selection: $settings.selectedProvider) {
            HomeView()
                .tabItem { Label("Stage", systemImage: "music.note.house") }
                .tag(ProviderKind.local)

            SearchView()
                .tabItem { Label("Online", systemImage: "sparkle.magnifyingglass") }
                .tag(ProviderKind.netease)

            SettingsView()
                .tabItem { Label("Settings", systemImage: "slider.horizontal.3") }
                .tag(ProviderKind.qq)
        }
        .tint(.white)
    }
}
