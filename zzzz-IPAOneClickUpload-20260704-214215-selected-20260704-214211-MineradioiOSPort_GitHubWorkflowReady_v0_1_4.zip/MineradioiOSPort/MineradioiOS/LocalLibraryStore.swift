import AVFoundation
import Combine
import Foundation

@MainActor
final class LocalLibraryStore: ObservableObject {
    @Published private(set) var songs: [SongItem] = []

    private let fileManager = FileManager.default
    private var libraryDirectory: URL {
        let docs = fileManager.urls(for: .documentDirectory, in: .userDomainMask).first!
        return docs.appendingPathComponent("MineradioLibrary", isDirectory: true)
    }
    private var indexURL: URL {
        libraryDirectory.appendingPathComponent("library.json")
    }

    func load() async {
        do {
            try createLibraryIfNeeded()
            guard fileManager.fileExists(atPath: indexURL.path) else { return }
            let data = try Data(contentsOf: indexURL)
            songs = try JSONDecoder().decode([SongItem].self, from: data)
        } catch {
            print("Library load error:", error.localizedDescription)
        }
    }

    func importAudioFile(from sourceURL: URL) async throws {
        try createLibraryIfNeeded()

        let didStart = sourceURL.startAccessingSecurityScopedResource()
        defer {
            if didStart { sourceURL.stopAccessingSecurityScopedResource() }
        }

        let ext = normalizedExtension(for: sourceURL)
        let destinationName = "\(UUID().uuidString).\(ext)"
        let destinationURL = libraryDirectory.appendingPathComponent(destinationName)
        if fileManager.fileExists(atPath: destinationURL.path) {
            try fileManager.removeItem(at: destinationURL)
        }

        try coordinatedCopy(from: sourceURL, to: destinationURL)
        let asset = AVURLAsset(url: destinationURL)
        let isPlayable = (try? await asset.load(.isPlayable)) ?? true
        if !isPlayable {
            try? fileManager.removeItem(at: destinationURL)
            throw MineradioError.fileImportFailed
        }

        let metadata = await readMetadata(from: destinationURL)
        let title = metadata.title?.isEmpty == false ? metadata.title! : sourceURL.deletingPathExtension().lastPathComponent
        let artist = metadata.artist?.isEmpty == false ? metadata.artist! : "Local File"

        let item = SongItem(
            id: UUID().uuidString,
            provider: .local,
            title: title,
            artist: artist,
            album: metadata.album,
            coverURL: nil,
            localFileName: destinationName,
            remoteSongID: nil,
            remoteURL: nil
        )
        songs.insert(item, at: 0)
        try save()
    }

    func fileURL(for song: SongItem) -> URL? {
        guard let localFileName = song.localFileName else { return nil }
        return libraryDirectory.appendingPathComponent(localFileName)
    }

    func delete(_ song: SongItem) {
        if let fileURL = fileURL(for: song), fileManager.fileExists(atPath: fileURL.path) {
            try? fileManager.removeItem(at: fileURL)
        }
        songs.removeAll { $0.id == song.id }
        try? save()
    }

    private func save() throws {
        let data = try JSONEncoder().encode(songs)
        try data.write(to: indexURL, options: [.atomic])
    }

    private func createLibraryIfNeeded() throws {
        if !fileManager.fileExists(atPath: libraryDirectory.path) {
            try fileManager.createDirectory(at: libraryDirectory, withIntermediateDirectories: true)
        }
    }

    private func normalizedExtension(for url: URL) -> String {
        let ext = url.pathExtension.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        return ext.isEmpty ? "audio" : ext
    }

    private func coordinatedCopy(from sourceURL: URL, to destinationURL: URL) throws {
        var coordinationError: NSError?
        var copyError: Error?
        let coordinator = NSFileCoordinator(filePresenter: nil)
        coordinator.coordinate(readingItemAt: sourceURL, options: [], error: &coordinationError) { readableURL in
            do {
                if fileManager.fileExists(atPath: destinationURL.path) {
                    try fileManager.removeItem(at: destinationURL)
                }
                try fileManager.copyItem(at: readableURL, to: destinationURL)
            } catch {
                copyError = error
            }
        }

        if let coordinationError { throw coordinationError }
        if let copyError { throw copyError }
        guard fileManager.fileExists(atPath: destinationURL.path) else {
            throw MineradioError.fileImportFailed
        }
    }

    private func readMetadata(from url: URL) async -> (title: String?, artist: String?, album: String?) {
        let asset = AVURLAsset(url: url)
        let metadata = (try? await asset.load(.commonMetadata)) ?? []

        func value(_ identifier: AVMetadataIdentifier) async -> String? {
            guard let item = AVMetadataItem.metadataItems(from: metadata, filteredByIdentifier: identifier).first else {
                return nil
            }
            return try? await item.load(.stringValue)
        }

        let title = await value(.commonIdentifierTitle)
        let artist = await value(.commonIdentifierArtist)
        let album = await value(.commonIdentifierAlbumName)
        return (title, artist, album)
    }
}
