import Foundation

enum LyricParser {
    static func parse(_ raw: String) -> [LyricLine] {
        raw.split(separator: "\n").flatMap { line -> [LyricLine] in
            parseLine(String(line))
        }
        .sorted { $0.time < $1.time }
    }

    private static func parseLine(_ line: String) -> [LyricLine] {
        let pattern = #"\[(\d{1,2}):(\d{1,2})(?:\.(\d{1,3}))?\]"#
        guard let regex = try? NSRegularExpression(pattern: pattern) else { return [] }
        let nsRange = NSRange(line.startIndex..<line.endIndex, in: line)
        let matches = regex.matches(in: line, range: nsRange)
        guard !matches.isEmpty else { return [] }

        let lyricTextStart = matches.last?.range.upperBound ?? 0
        let text = String(line[String.Index(utf16Offset: lyricTextStart, in: line)...]).trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty else { return [] }

        return matches.compactMap { match in
            guard
                let minuteRange = Range(match.range(at: 1), in: line),
                let secondRange = Range(match.range(at: 2), in: line),
                let minutes = Double(line[minuteRange]),
                let seconds = Double(line[secondRange])
            else { return nil }
            var fraction: Double = 0
            if match.range(at: 3).location != NSNotFound, let range = Range(match.range(at: 3), in: line) {
                let rawFraction = String(line[range])
                fraction = (Double(rawFraction) ?? 0) / pow(10, Double(rawFraction.count))
            }
            return LyricLine(time: minutes * 60 + seconds + fraction, text: text)
        }
    }
}
