import Foundation

struct NetEaseService {
    let client: APIClient

    init(baseURL: String, cookie: String = "") {
        self.client = APIClient(baseURLString: baseURL, cookie: cookie.isEmpty ? nil : cookie)
    }

    func createQRCode() async throws -> QRCodePayload {
        let keyResponse: QRKeyResponse = try await client.getJSON("/login/qr/key")
        guard let key = keyResponse.data?.unikey else { throw MineradioError.invalidResponse }
        let createResponse: QRCreateResponse = try await client.getJSON(
            "/login/qr/create",
            query: [
                URLQueryItem(name: "key", value: key),
                URLQueryItem(name: "qrimg", value: "true")
            ]
        )
        return QRCodePayload(key: key, qrImageDataURL: createResponse.data?.qrimg, qrURL: createResponse.data?.qrurl)
    }

    func checkQRCode(key: String) async throws -> QRCheckResponse {
        try await client.getJSON("/login/qr/check", query: [URLQueryItem(name: "key", value: key)])
    }

    func loginStatus() async throws -> LoginStatusResponse {
        try await client.getJSON("/login/status")
    }

    func search(keyword: String) async throws -> [SongItem] {
        let response: SearchResponse = try await client.getJSON(
            "/cloudsearch",
            query: [
                URLQueryItem(name: "keywords", value: keyword),
                URLQueryItem(name: "limit", value: "30")
            ]
        )
        return response.result?.songs?.map { song in
            SongItem(
                id: "netease-\(song.id)",
                provider: .netease,
                title: song.name,
                artist: song.ar?.map(\.name).joined(separator: " / ") ?? "Unknown Artist",
                album: song.al?.name,
                coverURL: song.al?.picUrl,
                localFileName: nil,
                remoteSongID: String(song.id),
                remoteURL: nil
            )
        } ?? []
    }

    func streamURL(for song: SongItem) async throws -> URL {
        guard let id = song.remoteSongID else { throw MineradioError.missingStreamURL }
        let response: SongURLResponse = try await client.getJSON(
            "/song/url",
            query: [URLQueryItem(name: "id", value: id)]
        )
        guard let value = response.data?.first?.url, let url = URL(string: value) else {
            throw MineradioError.missingStreamURL
        }
        return url
    }

    func lyrics(for song: SongItem) async throws -> [LyricLine] {
        guard let id = song.remoteSongID else { return [] }
        let response: LyricResponse = try await client.getJSON(
            "/lyric",
            query: [URLQueryItem(name: "id", value: id)]
        )
        return LyricParser.parse(response.lrc?.lyric ?? "")
    }
}

struct QRCodePayload {
    let key: String
    let qrImageDataURL: String?
    let qrURL: String?

    var imageData: Data? {
        guard let qrImageDataURL else { return nil }
        if let comma = qrImageDataURL.firstIndex(of: ",") {
            let payload = String(qrImageDataURL[qrImageDataURL.index(after: comma)...])
            return Data(base64Encoded: payload)
        }
        return Data(base64Encoded: qrImageDataURL)
    }
}

struct QRKeyResponse: Decodable {
    let code: Int?
    let data: QRKeyData?
}

struct QRKeyData: Decodable {
    let code: Int?
    let unikey: String?
}

struct QRCreateResponse: Decodable {
    let code: Int?
    let data: QRCreateData?
}

struct QRCreateData: Decodable {
    let qrurl: String?
    let qrimg: String?
}

struct QRCheckResponse: Decodable {
    let code: Int
    let message: String?
    let cookie: String?
    let avatarUrl: String?
    let nickname: String?
}

struct LoginStatusResponse: Decodable {
    let data: LoginStatusData?
}

struct LoginStatusData: Decodable {
    let code: Int?
    let account: AccountData?
    let profile: ProfileData?
}

struct AccountData: Decodable { let id: Int64? }
struct ProfileData: Decodable {
    let userId: Int64?
    let nickname: String?
    let avatarUrl: String?
}

struct SearchResponse: Decodable {
    let result: SearchResult?
}

struct SearchResult: Decodable {
    let songs: [NetEaseSong]?
}

struct NetEaseSong: Decodable {
    let id: Int64
    let name: String
    let ar: [NetEaseArtist]?
    let al: NetEaseAlbum?
}

struct NetEaseArtist: Decodable { let name: String }
struct NetEaseAlbum: Decodable {
    let name: String?
    let picUrl: String?
}

struct SongURLResponse: Decodable {
    let data: [SongURLData]?
}

struct SongURLData: Decodable {
    let id: Int64?
    let url: String?
    let code: Int?
    let type: String?
}

struct LyricResponse: Decodable {
    let lrc: LyricPayload?
}

struct LyricPayload: Decodable {
    let lyric: String?
}
