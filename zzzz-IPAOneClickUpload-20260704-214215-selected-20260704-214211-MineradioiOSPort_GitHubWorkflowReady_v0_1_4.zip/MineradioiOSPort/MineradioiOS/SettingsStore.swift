import Foundation
import Combine

final class SettingsStore: ObservableObject {
    @Published var selectedProvider: ProviderKind {
        didSet { UserDefaults.standard.set(selectedProvider.rawValue, forKey: Keys.selectedProvider) }
    }

    @Published var netEaseBaseURL: String {
        didSet { UserDefaults.standard.set(netEaseBaseURL, forKey: Keys.netEaseBaseURL) }
    }

    @Published var netEaseCookie: String {
        didSet { UserDefaults.standard.set(netEaseCookie, forKey: Keys.netEaseCookie) }
    }

    @Published var qqBaseURL: String {
        didSet { UserDefaults.standard.set(qqBaseURL, forKey: Keys.qqBaseURL) }
    }

    @Published var qqCookieOrToken: String {
        didSet { UserDefaults.standard.set(qqCookieOrToken, forKey: Keys.qqCookieOrToken) }
    }

    init() {
        let savedProvider = UserDefaults.standard.string(forKey: Keys.selectedProvider)
        self.selectedProvider = ProviderKind(rawValue: savedProvider ?? "local") ?? .local
        self.netEaseBaseURL = UserDefaults.standard.string(forKey: Keys.netEaseBaseURL) ?? "http://127.0.0.1:3000"
        self.netEaseCookie = UserDefaults.standard.string(forKey: Keys.netEaseCookie) ?? ""
        self.qqBaseURL = UserDefaults.standard.string(forKey: Keys.qqBaseURL) ?? ""
        self.qqCookieOrToken = UserDefaults.standard.string(forKey: Keys.qqCookieOrToken) ?? ""
    }

    private enum Keys {
        static let selectedProvider = "selectedProvider"
        static let netEaseBaseURL = "netEaseBaseURL"
        static let netEaseCookie = "netEaseCookie"
        static let qqBaseURL = "qqBaseURL"
        static let qqCookieOrToken = "qqCookieOrToken"
    }
}
