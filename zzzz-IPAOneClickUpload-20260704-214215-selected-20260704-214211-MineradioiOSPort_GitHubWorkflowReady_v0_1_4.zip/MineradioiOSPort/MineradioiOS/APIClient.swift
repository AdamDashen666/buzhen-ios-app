import Foundation

struct APIClient {
    let baseURLString: String
    var cookie: String?

    func getJSON<T: Decodable>(_ path: String, query: [URLQueryItem] = []) async throws -> T {
        let data = try await getData(path, query: query)
        do {
            return try JSONDecoder().decode(T.self, from: data)
        } catch {
            print("Decode error:", error)
            if let body = String(data: data, encoding: .utf8) {
                print("Body:", body.prefix(500))
            }
            throw MineradioError.invalidResponse
        }
    }

    func getData(_ path: String, query: [URLQueryItem] = []) async throws -> Data {
        guard var components = makeComponents(path: path) else {
            throw MineradioError.invalidBaseURL
        }
        var items = query
        items.append(URLQueryItem(name: "timestamp", value: String(Int(Date().timeIntervalSince1970 * 1000))))
        if let cookie, !cookie.isEmpty {
            items.append(URLQueryItem(name: "cookie", value: cookie))
        }
        components.queryItems = (components.queryItems ?? []) + items
        guard let url = components.url else { throw MineradioError.invalidBaseURL }

        var request = URLRequest(url: url)
        request.timeoutInterval = 20
        request.setValue("MineradioiOS/0.1", forHTTPHeaderField: "User-Agent")
        if let cookie, !cookie.isEmpty {
            request.setValue(cookie, forHTTPHeaderField: "Cookie")
        }

        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            throw MineradioError.invalidResponse
        }
        return data
    }

    private func makeComponents(path: String) -> URLComponents? {
        let cleanBase = baseURLString.trimmingCharacters(in: .whitespacesAndNewlines).trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        guard !cleanBase.isEmpty else { return nil }
        let cleanPath = path.hasPrefix("/") ? path : "/\(path)"
        return URLComponents(string: cleanBase + cleanPath)
    }
}
