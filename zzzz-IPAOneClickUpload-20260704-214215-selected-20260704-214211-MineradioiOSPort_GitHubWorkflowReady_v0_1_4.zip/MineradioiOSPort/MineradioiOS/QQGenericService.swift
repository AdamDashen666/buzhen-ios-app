import Foundation

/// 不同 QQ 音乐第三方 API 的路径和返回格式差异较大。
/// 这里先保留一个轻量适配层，后续可以按你实际使用的服务修改 endpoint 和 Codable model。
struct QQGenericService {
    let client: APIClient

    init(baseURL: String, cookieOrToken: String = "") {
        self.client = APIClient(baseURLString: baseURL, cookie: cookieOrToken.isEmpty ? nil : cookieOrToken)
    }

    func search(keyword: String) async throws -> [SongItem] {
        throw MineradioError.unsupportedProvider
    }

    func streamURL(for song: SongItem) async throws -> URL {
        throw MineradioError.unsupportedProvider
    }
}
