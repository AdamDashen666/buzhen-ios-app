import SwiftUI

struct NowPlayingView: View {
    @EnvironmentObject private var player: PlayerController

    var body: some View {
        GlassPanel {
            VStack(spacing: 18) {
                HStack(alignment: .center, spacing: 18) {
                    cover
                    VStack(alignment: .leading, spacing: 8) {
                        Text(player.currentSong?.title ?? "Mineradio iOS")
                            .font(.system(size: 30, weight: .bold, design: .rounded))
                            .foregroundStyle(.white)
                            .lineLimit(1)
                        Text(player.currentSong?.subtitle ?? "Local + NetEase third-party API")
                            .font(.subheadline)
                            .foregroundStyle(.white.opacity(0.70))
                            .lineLimit(1)
                    }
                    Spacer()
                    Button(action: player.togglePlayPause) {
                        Image(systemName: player.isPlaying ? "pause.fill" : "play.fill")
                            .font(.system(size: 28, weight: .bold))
                            .foregroundStyle(.black)
                            .frame(width: 68, height: 68)
                            .background(.white, in: Circle())
                    }
                    .disabled(player.currentSong == nil)
                }

                VStack(spacing: 10) {
                    Text(player.activeLyric)
                        .font(.system(size: 26, weight: .semibold, design: .rounded))
                        .foregroundStyle(.white)
                        .multilineTextAlignment(.center)
                        .frame(maxWidth: .infinity, minHeight: 56)
                        .contentTransition(.numericText())

                    Slider(value: Binding(
                        get: { player.currentTime },
                        set: { player.seek(to: $0) }
                    ), in: 0...max(player.duration, 1))
                    .tint(.white)

                    HStack {
                        Text(timeString(player.currentTime))
                        Spacer()
                        Text(timeString(player.duration))
                    }
                    .font(.caption.monospacedDigit())
                    .foregroundStyle(.white.opacity(0.62))
                }
            }
        }
    }

    private var cover: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 24, style: .continuous)
                .fill(.white.opacity(0.12))
            if let coverURL = player.currentSong?.coverURL, let url = URL(string: coverURL) {
                AsyncImage(url: url) { phase in
                    switch phase {
                    case .success(let image): image.resizable().scaledToFill()
                    default: Image("DefaultCover").resizable().scaledToFill()
                    }
                }
            } else {
                Image("DefaultCover").resizable().scaledToFill()
            }
        }
        .frame(width: 92, height: 92)
        .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
    }

    private func timeString(_ seconds: TimeInterval) -> String {
        guard seconds.isFinite else { return "0:00" }
        let value = Int(seconds)
        return String(format: "%d:%02d", value / 60, value % 60)
    }
}
