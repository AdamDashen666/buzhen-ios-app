import SwiftUI

struct SearchView: View {
    @EnvironmentObject private var settings: SettingsStore
    @EnvironmentObject private var player: PlayerController
    @State private var keyword = ""
    @State private var results: [SongItem] = []
    @State private var isLoading = false
    @State private var message: String?

    var body: some View {
        ZStack {
            ParticleBackgroundView()
            VStack(spacing: 18) {
                header
                searchBar
                if let message {
                    Text(message)
                        .font(.callout)
                        .foregroundStyle(.white.opacity(0.78))
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
                resultList
            }
            .padding(22)
        }
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Online Radio")
                .font(.system(size: 40, weight: .black, design: .rounded))
                .foregroundStyle(.white)
            Text("使用你自己运行的第三方 NetEase API 服务搜索和播放。")
                .foregroundStyle(.white.opacity(0.66))
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private var searchBar: some View {
        GlassPanel {
            HStack(spacing: 12) {
                Image(systemName: "magnifyingglass")
                    .foregroundStyle(.white.opacity(0.75))
                TextField("搜索歌曲 / 歌手", text: $keyword)
                    .textInputAutocapitalization(.never)
                    .foregroundStyle(.white)
                    .submitLabel(.search)
                    .onSubmit { Task { await search() } }
                Button {
                    Task { await search() }
                } label: {
                    if isLoading {
                        ProgressView().tint(.black)
                    } else {
                        Text("Search")
                    }
                }
                .font(.headline)
                .foregroundStyle(.black)
                .padding(.horizontal, 16)
                .padding(.vertical, 10)
                .background(.white, in: Capsule())
                .disabled(keyword.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || isLoading)
            }
        }
    }

    private var resultList: some View {
        ScrollView {
            LazyVStack(spacing: 12) {
                ForEach(results) { song in
                    SearchResultRow(song: song) {
                        Task { await play(song) }
                    }
                }
            }
            .padding(.bottom, 110)
        }
    }

    @MainActor
    private func search() async {
        let trimmed = keyword.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }
        isLoading = true
        message = nil
        defer { isLoading = false }
        do {
            let service = NetEaseService(baseURL: settings.netEaseBaseURL, cookie: settings.netEaseCookie)
            results = try await service.search(keyword: trimmed)
            message = results.isEmpty ? "没有搜到结果，检查 API 服务或关键词。" : "找到 \(results.count) 首歌。"
        } catch {
            message = error.localizedDescription
        }
    }

    @MainActor
    private func play(_ song: SongItem) async {
        message = "正在获取播放链接…"
        do {
            let service = NetEaseService(baseURL: settings.netEaseBaseURL, cookie: settings.netEaseCookie)
            let url = try await service.streamURL(for: song)
            let lyrics = (try? await service.lyrics(for: song)) ?? []
            player.playRemote(song: song, url: url, lyrics: lyrics)
            message = "正在播放：\(song.title)"
        } catch {
            message = error.localizedDescription
        }
    }
}

private struct SearchResultRow: View {
    let song: SongItem
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 14) {
                cover
                VStack(alignment: .leading, spacing: 5) {
                    Text(song.title)
                        .font(.headline)
                        .foregroundStyle(.white)
                        .lineLimit(1)
                    Text(song.subtitle)
                        .font(.caption)
                        .foregroundStyle(.white.opacity(0.64))
                        .lineLimit(1)
                }
                Spacer()
                Image(systemName: "play.circle.fill")
                    .font(.system(size: 32))
                    .foregroundStyle(.white)
            }
            .padding(12)
            .background(.white.opacity(0.10), in: RoundedRectangle(cornerRadius: 24, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 24, style: .continuous).stroke(.white.opacity(0.12)))
        }
        .buttonStyle(.plain)
    }

    private var cover: some View {
        Group {
            if let coverURL = song.coverURL, let url = URL(string: coverURL) {
                AsyncImage(url: url) { phase in
                    switch phase {
                    case .success(let image): image.resizable().scaledToFill()
                    default: Image("DefaultCover").resizable().scaledToFill()
                    }
                }
            } else {
                Image("DefaultCover").resizable().scaledToFill()
            }
        }
        .frame(width: 58, height: 58)
        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
    }
}
