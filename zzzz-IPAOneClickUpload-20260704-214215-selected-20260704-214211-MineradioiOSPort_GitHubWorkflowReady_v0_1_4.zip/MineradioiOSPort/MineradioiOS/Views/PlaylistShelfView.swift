import SwiftUI
import UniformTypeIdentifiers
import UIKit

struct PlaylistShelfView: View {
    @EnvironmentObject private var library: LocalLibraryStore
    @EnvironmentObject private var player: PlayerController
    @State private var isImporterPresented = false
    @State private var errorMessage: String?
    @State private var importStatus: String?
    @State private var isImporting = false

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text("3D Local Shelf")
                        .font(.title2.bold())
                        .foregroundStyle(.white)
                    Text(importStatus ?? "导入本地音乐后会出现在这里")
                        .font(.caption)
                        .foregroundStyle(.white.opacity(0.62))
                        .lineLimit(2)
                }
                Spacer()
                Button {
                    importStatus = nil
                    isImporterPresented = true
                } label: {
                    Label(isImporting ? "Importing" : "Import", systemImage: isImporting ? "hourglass" : "plus")
                        .font(.headline)
                        .padding(.horizontal, 16)
                        .padding(.vertical, 10)
                        .background(.white.opacity(0.16), in: Capsule())
                }
                .foregroundStyle(.white)
                .disabled(isImporting)
            }

            if library.songs.isEmpty {
                GlassPanel {
                    VStack(spacing: 10) {
                        Image(systemName: isImporting ? "arrow.down.doc.fill" : "music.note.list")
                            .font(.system(size: 38))
                        Text(isImporting ? "正在导入音乐…" : "还没有本地音乐")
                            .font(.headline)
                        Text("支持 MP3 / FLAC / M4A / AAC / WAV / AIFF，也可以从 Files/iCloud 选择")
                            .font(.caption)
                            .foregroundStyle(.white.opacity(0.7))
                            .multilineTextAlignment(.center)
                    }
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity)
                }
            } else {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 18) {
                        ForEach(library.songs) { song in
                            LocalSongCard(song: song) {
                                guard let url = library.fileURL(for: song) else { return }
                                player.playLocal(song: song, fileURL: url)
                            }
                            .contextMenu {
                                Button(role: .destructive) {
                                    library.delete(song)
                                    importStatus = "已删除：\(song.title)"
                                } label: {
                                    Label("Delete", systemImage: "trash")
                                }
                            }
                        }
                    }
                    .padding(.vertical, 14)
                }
            }
        }
        .sheet(isPresented: $isImporterPresented) {
            AudioDocumentPicker { urls in
                Task { await importFiles(urls) }
            } onCancel: {
                importStatus = "已取消导入"
            }
            .ignoresSafeArea()
        }
        .alert("导入失败", isPresented: Binding(get: { errorMessage != nil }, set: { if !$0 { errorMessage = nil } })) {
            Button("OK", role: .cancel) { errorMessage = nil }
        } message: {
            Text(errorMessage ?? "")
        }
    }

    @MainActor
    private func importFiles(_ urls: [URL]) async {
        guard !urls.isEmpty else {
            importStatus = "没有选择文件"
            return
        }

        isImporting = true
        importStatus = "正在导入 \(urls.count) 个文件…"
        defer { isImporting = false }

        var imported = 0
        var failures: [String] = []
        for url in urls {
            do {
                try await library.importAudioFile(from: url)
                imported += 1
            } catch {
                failures.append("\(url.lastPathComponent)：\(error.localizedDescription)")
            }
        }

        if failures.isEmpty {
            importStatus = "已导入 \(imported) 首音乐"
        } else {
            importStatus = "已导入 \(imported) 首，失败 \(failures.count) 个"
            errorMessage = failures.joined(separator: "\n")
        }
    }
}

private struct AudioDocumentPicker: UIViewControllerRepresentable {
    let onPick: ([URL]) -> Void
    let onCancel: () -> Void

    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        let picker = UIDocumentPickerViewController(forOpeningContentTypes: Self.supportedTypes, asCopy: true)
        picker.allowsMultipleSelection = true
        picker.shouldShowFileExtensions = true
        picker.delegate = context.coordinator
        return picker
    }

    func updateUIViewController(_ uiViewController: UIDocumentPickerViewController, context: Context) {}

    func makeCoordinator() -> Coordinator {
        Coordinator(onPick: onPick, onCancel: onCancel)
    }

    private static var supportedTypes: [UTType] {
        var types: [UTType] = [.audio, .item]
        for ext in ["mp3", "flac", "m4a", "mp4", "aac", "wav", "wave", "aiff", "aif", "ogg", "opus"] {
            if let type = UTType(filenameExtension: ext), !types.contains(type) {
                types.append(type)
            }
        }
        return types
    }

    final class Coordinator: NSObject, UIDocumentPickerDelegate {
        let onPick: ([URL]) -> Void
        let onCancel: () -> Void

        init(onPick: @escaping ([URL]) -> Void, onCancel: @escaping () -> Void) {
            self.onPick = onPick
            self.onCancel = onCancel
        }

        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            DispatchQueue.main.async {
                self.onPick(urls)
            }
        }

        func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
            DispatchQueue.main.async {
                self.onCancel()
            }
        }
    }
}

private struct LocalSongCard: View {
    let song: SongItem
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            VStack(alignment: .leading, spacing: 12) {
                Image("DefaultCover")
                    .resizable()
                    .scaledToFill()
                    .frame(width: 160, height: 160)
                    .clipShape(RoundedRectangle(cornerRadius: 28, style: .continuous))
                    .overlay(alignment: .bottomTrailing) {
                        Image(systemName: "play.fill")
                            .foregroundStyle(.black)
                            .padding(10)
                            .background(.white, in: Circle())
                            .padding(10)
                    }

                Text(song.title)
                    .font(.headline)
                    .foregroundStyle(.white)
                    .lineLimit(1)
                Text(song.artist)
                    .font(.caption)
                    .foregroundStyle(.white.opacity(0.62))
                    .lineLimit(1)
            }
            .frame(width: 180)
            .padding(14)
            .background(.white.opacity(0.10), in: RoundedRectangle(cornerRadius: 34, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 34, style: .continuous).stroke(.white.opacity(0.12)))
            .rotation3DEffect(.degrees(-7), axis: (x: 0, y: 1, z: 0))
        }
        .buttonStyle(.plain)
    }
}
