import SwiftUI

struct SettingsView: View {
    @EnvironmentObject private var settings: SettingsStore
    @State private var showLogin = false
    @State private var loginStatus = "未检查"

    var body: some View {
        ZStack {
            ParticleBackgroundView()
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    Text("Settings")
                        .font(.system(size: 40, weight: .black, design: .rounded))
                        .foregroundStyle(.white)
                        .padding(.top, 18)

                    netEaseSection
                    qqSection
                    safetySection
                }
                .padding(22)
                .padding(.bottom, 110)
            }
        }
        .sheet(isPresented: $showLogin) {
            LoginQRView().environmentObject(settings)
        }
    }

    private var netEaseSection: some View {
        GlassPanel {
            VStack(alignment: .leading, spacing: 14) {
                Label("NetEase API", systemImage: "music.quarternote.3")
                    .font(.title3.bold())
                    .foregroundStyle(.white)

                TextField("http://127.0.0.1:3000", text: $settings.netEaseBaseURL)
                    .textInputAutocapitalization(.never)
                    .keyboardType(.URL)
                    .padding(12)
                    .background(.black.opacity(0.22), in: RoundedRectangle(cornerRadius: 14))
                    .foregroundStyle(.white)

                HStack {
                    Button("QR 登录") { showLogin = true }
                    Button("检查状态") { Task { await checkStatus() } }
                    Spacer()
                }
                .buttonStyle(.borderedProminent)
                .tint(.white)
                .foregroundStyle(.black)

                Text("Cookie: \(settings.netEaseCookie.isEmpty ? "未保存" : "已保存") · \(loginStatus)")
                    .font(.caption)
                    .foregroundStyle(.white.opacity(0.66))
            }
        }
    }

    private var qqSection: some View {
        GlassPanel {
            VStack(alignment: .leading, spacing: 14) {
                Label("QQ / Custom API", systemImage: "switch.2")
                    .font(.title3.bold())
                    .foregroundStyle(.white)

                Text("不同 QQ 音乐第三方 API 不统一，这里先保留配置入口。后续按你选的 API 文档改 QQGenericService.swift。")
                    .font(.caption)
                    .foregroundStyle(.white.opacity(0.68))

                TextField("Custom Base URL", text: $settings.qqBaseURL)
                    .textInputAutocapitalization(.never)
                    .keyboardType(.URL)
                    .padding(12)
                    .background(.black.opacity(0.22), in: RoundedRectangle(cornerRadius: 14))
                    .foregroundStyle(.white)

                TextField("Cookie / Token", text: $settings.qqCookieOrToken)
                    .textInputAutocapitalization(.never)
                    .padding(12)
                    .background(.black.opacity(0.22), in: RoundedRectangle(cornerRadius: 14))
                    .foregroundStyle(.white)
            }
        }
    }

    private var safetySection: some View {
        GlassPanel {
            VStack(alignment: .leading, spacing: 10) {
                Label("Notes", systemImage: "exclamationmark.triangle")
                    .font(.headline)
                    .foregroundStyle(.white)
                Text("第三方登录和播放链接可能受平台规则、版权、会员、地区限制影响。本项目只适合学习和个人自用，不要用来绕过付费或公开分发。")
                    .font(.callout)
                    .foregroundStyle(.white.opacity(0.72))
            }
        }
    }

    @MainActor
    private func checkStatus() async {
        do {
            let service = NetEaseService(baseURL: settings.netEaseBaseURL, cookie: settings.netEaseCookie)
            let status = try await service.loginStatus()
            if let nickname = status.data?.profile?.nickname {
                loginStatus = "当前账号：\(nickname)"
            } else {
                loginStatus = "未登录或 Cookie 已失效"
            }
        } catch {
            loginStatus = error.localizedDescription
        }
    }
}
