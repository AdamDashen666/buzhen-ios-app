import SwiftUI

struct ParticleBackgroundView: View {
    private let stars = MineradioParticle.makeStars(count: 520)
    private let dust = MineradioParticle.makeDust(count: 220)
    private let links = MineradioParticle.makeLinkSeeds(count: 120)

    var body: some View {
        TimelineView(.animation) { timeline in
            Canvas(opaque: true, colorMode: .linear) { context, size in
                let time = timeline.date.timeIntervalSinceReferenceDate
                let bounds = CGRect(origin: .zero, size: size)
                drawDeepStage(in: &context, bounds: bounds, time: time)
                drawNebula(in: &context, size: size, time: time)
                drawDust(in: &context, size: size, time: time)
                drawStarField(in: &context, size: size, time: time)
                drawLightLinks(in: &context, size: size, time: time)
                drawPulseRings(in: &context, size: size, time: time)
            }
        }
        .ignoresSafeArea()
    }

    private func drawDeepStage(in context: inout GraphicsContext, bounds: CGRect, time: TimeInterval) {
        let shimmer = 0.5 + 0.5 * sin(time * 0.10)
        let gradient = Gradient(stops: [
            .init(color: Color(red: 0.005, green: 0.006, blue: 0.015), location: 0.00),
            .init(color: Color(red: 0.020, green: 0.025, blue: 0.070 + 0.015 * shimmer), location: 0.36),
            .init(color: Color(red: 0.090 + 0.020 * shimmer, green: 0.038, blue: 0.155), location: 0.72),
            .init(color: Color(red: 0.010, green: 0.012, blue: 0.026), location: 1.00)
        ])
        context.fill(Path(bounds), with: .linearGradient(gradient, startPoint: bounds.origin, endPoint: CGPoint(x: bounds.maxX, y: bounds.maxY)))
    }

    private func drawNebula(in context: inout GraphicsContext, size: CGSize, time: TimeInterval) {
        let centers = [
            CGPoint(x: size.width * (0.18 + 0.04 * sin(time * 0.13)), y: size.height * (0.22 + 0.04 * cos(time * 0.11))),
            CGPoint(x: size.width * (0.78 + 0.05 * cos(time * 0.10)), y: size.height * (0.34 + 0.05 * sin(time * 0.09))),
            CGPoint(x: size.width * (0.48 + 0.04 * sin(time * 0.08)), y: size.height * (0.78 + 0.04 * cos(time * 0.12)))
        ]
        let colors: [Color] = [
            Color(red: 0.25, green: 0.14, blue: 0.85).opacity(0.32),
            Color(red: 0.05, green: 0.65, blue: 0.95).opacity(0.22),
            Color(red: 0.95, green: 0.15, blue: 0.70).opacity(0.20)
        ]
        let radius = max(size.width, size.height) * 0.62
        for index in centers.indices {
            let rect = CGRect(x: centers[index].x - radius * 0.5, y: centers[index].y - radius * 0.5, width: radius, height: radius)
            context.fill(
                Path(ellipseIn: rect),
                with: .radialGradient(
                    Gradient(colors: [colors[index], .clear]),
                    center: centers[index],
                    startRadius: 0,
                    endRadius: radius * 0.52
                )
            )
        }
    }

    private func drawDust(in context: inout GraphicsContext, size: CGSize, time: TimeInterval) {
        for particle in dust {
            let point = particle.position(in: size, time: time, driftScale: 0.55)
            let radius = particle.radius * 0.75
            let rect = CGRect(x: point.x - radius * 0.5, y: point.y - radius * 0.5, width: radius, height: radius)
            context.opacity = particle.opacity * 0.38
            context.fill(Path(ellipseIn: rect), with: .color(particle.color.opacity(0.82)))
        }
        context.opacity = 1
    }

    private func drawStarField(in context: inout GraphicsContext, size: CGSize, time: TimeInterval) {
        for particle in stars {
            let point = particle.position(in: size, time: time, driftScale: 1.0)
            let pulse = 0.72 + 0.28 * sin(time * particle.waveSpeed + particle.phase)
            let radius = particle.radius * pulse
            let rect = CGRect(x: point.x - radius * 0.5, y: point.y - radius * 0.5, width: radius, height: radius)
            context.opacity = particle.opacity * (0.60 + 0.40 * pulse)
            context.fill(Path(ellipseIn: rect), with: .color(particle.color))

            if particle.radius > 2.6 {
                let glow = radius * 4.8
                let glowRect = CGRect(x: point.x - glow * 0.5, y: point.y - glow * 0.5, width: glow, height: glow)
                context.opacity = particle.opacity * 0.20
                context.fill(
                    Path(ellipseIn: glowRect),
                    with: .radialGradient(Gradient(colors: [particle.color.opacity(0.55), .clear]), center: point, startRadius: 0, endRadius: glow * 0.5)
                )
            }
        }
        context.opacity = 1
    }

    private func drawLightLinks(in context: inout GraphicsContext, size: CGSize, time: TimeInterval) {
        for seed in links {
            let a = stars[seed.a].position(in: size, time: time, driftScale: 1.0)
            let b = stars[seed.b].position(in: size, time: time, driftScale: 1.0)
            let dx = a.x - b.x
            let dy = a.y - b.y
            let distance = sqrt(dx * dx + dy * dy)
            let maxDistance = min(size.width, size.height) * 0.28
            guard distance < maxDistance else { continue }
            var path = Path()
            path.move(to: a)
            path.addLine(to: b)
            let alpha = max(0, 1 - distance / maxDistance) * 0.24
            context.opacity = alpha
            context.stroke(path, with: .color(.white), lineWidth: 0.7)
        }
        context.opacity = 1
    }

    private func drawPulseRings(in context: inout GraphicsContext, size: CGSize, time: TimeInterval) {
        let center = CGPoint(x: size.width * 0.5, y: size.height * 0.52)
        for index in 0..<4 {
            let phase = (time * 0.16 + Double(index) * 0.24).truncatingRemainder(dividingBy: 1)
            let radius = min(size.width, size.height) * CGFloat(0.20 + phase * 0.58)
            let rect = CGRect(x: center.x - radius, y: center.y - radius, width: radius * 2, height: radius * 2)
            context.opacity = (1 - phase) * 0.10
            context.stroke(Path(ellipseIn: rect), with: .color(Color(red: 0.75, green: 0.86, blue: 1.0)), lineWidth: 1.2)
        }
        context.opacity = 1
    }
}

private struct MineradioParticle {
    let x: CGFloat
    let y: CGFloat
    let radius: CGFloat
    let opacity: Double
    let speedX: Double
    let speedY: Double
    let waveSpeed: Double
    let waveAmplitude: Double
    let phase: Double
    let color: Color

    func position(in size: CGSize, time: TimeInterval, driftScale: Double) -> CGPoint {
        let width = max(size.width, 1)
        let height = max(size.height, 1)
        let driftX = CGFloat(time * speedX * driftScale)
        let driftY = CGFloat(time * speedY * driftScale)
        let waveX = CGFloat(sin(time * waveSpeed + phase) * waveAmplitude)
        let waveY = CGFloat(cos(time * waveSpeed * 0.74 + phase) * waveAmplitude * 0.52)
        let px = wrap(x + driftX + waveX, limit: width)
        let py = wrap(y + driftY + waveY, limit: height)
        return CGPoint(x: px, y: py)
    }

    private func wrap(_ value: CGFloat, limit: CGFloat) -> CGFloat {
        let result = value.truncatingRemainder(dividingBy: limit)
        return result < 0 ? result + limit : result
    }

    static func makeStars(count: Int) -> [MineradioParticle] {
        (0..<count).map { index in
            let palette = [
                Color.white,
                Color(red: 0.63, green: 0.86, blue: 1.0),
                Color(red: 0.95, green: 0.75, blue: 1.0),
                Color(red: 0.70, green: 0.62, blue: 1.0)
            ]
            return MineradioParticle(
                x: CGFloat.random(in: 0...1400),
                y: CGFloat.random(in: 0...2200),
                radius: CGFloat.random(in: 1.0...5.2),
                opacity: Double.random(in: 0.16...0.86),
                speedX: Double.random(in: -7.5...15.0),
                speedY: Double.random(in: -3.0...7.5),
                waveSpeed: Double.random(in: 0.35...1.85),
                waveAmplitude: Double.random(in: 6...52),
                phase: Double(index) * 0.618,
                color: palette[index % palette.count]
            )
        }
    }

    static func makeDust(count: Int) -> [MineradioParticle] {
        (0..<count).map { index in
            MineradioParticle(
                x: CGFloat.random(in: 0...1400),
                y: CGFloat.random(in: 0...2200),
                radius: CGFloat.random(in: 0.5...2.0),
                opacity: Double.random(in: 0.08...0.36),
                speedX: Double.random(in: -3...6),
                speedY: Double.random(in: -2...3),
                waveSpeed: Double.random(in: 0.2...0.9),
                waveAmplitude: Double.random(in: 3...26),
                phase: Double(index) * 1.414,
                color: Color(red: 0.72, green: 0.86, blue: 1.0)
            )
        }
    }

    static func makeLinkSeeds(count: Int) -> [ParticleLinkSeed] {
        (0..<count).map { index in
            ParticleLinkSeed(a: (index * 7) % 520, b: (index * 19 + 41) % 520)
        }
    }
}

private struct ParticleLinkSeed {
    let a: Int
    let b: Int
}
