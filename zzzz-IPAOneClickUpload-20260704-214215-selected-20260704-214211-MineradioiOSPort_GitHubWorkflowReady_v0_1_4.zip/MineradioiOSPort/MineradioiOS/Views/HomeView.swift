import SwiftUI

struct HomeView: View {
    var body: some View {
        ZStack {
            ParticleBackgroundView()
            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    header
                    NowPlayingView()
                    WeatherRadioCard()
                    PlaylistShelfView()
                }
                .padding(.horizontal, 22)
                .padding(.top, 18)
                .padding(.bottom, 110)
            }
        }
    }

    private var header: some View {
        HStack {
            VStack(alignment: .leading, spacing: 6) {
                Text("Mineradio")
                    .font(.system(size: 44, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                Text("iOS Port · Immersive Music Stage")
                    .font(.headline)
                    .foregroundStyle(.white.opacity(0.66))
            }
            Spacer()
            Image(systemName: "sparkles")
                .font(.system(size: 30, weight: .bold))
                .foregroundStyle(.white)
                .padding(18)
                .background(.white.opacity(0.12), in: Circle())
        }
    }
}

private struct WeatherRadioCard: View {
    var body: some View {
        GlassPanel {
            HStack(spacing: 16) {
                Image(systemName: "cloud.moon.bolt.fill")
                    .font(.system(size: 42))
                    .foregroundStyle(.white)
                    .frame(width: 72, height: 72)
                    .background(.white.opacity(0.10), in: RoundedRectangle(cornerRadius: 22, style: .continuous))
                VStack(alignment: .leading, spacing: 6) {
                    Text("Weather Radio")
                        .font(.title3.bold())
                        .foregroundStyle(.white)
                    Text("保留了 Mineradio 的天气电台概念；下一步可接 OpenWeather / 彩云天气。")
                        .font(.subheadline)
                        .foregroundStyle(.white.opacity(0.72))
                        .lineLimit(2)
                }
                Spacer()
            }
        }
    }
}
