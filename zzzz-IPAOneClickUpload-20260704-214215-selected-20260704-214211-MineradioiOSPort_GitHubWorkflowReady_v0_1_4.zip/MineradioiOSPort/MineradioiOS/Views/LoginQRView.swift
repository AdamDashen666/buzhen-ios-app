import SwiftUI
import UIKit

struct LoginQRView: View {
    @EnvironmentObject private var settings: SettingsStore
    @Environment(\.dismiss) private var dismiss
    @State private var qrPayload: QRCodePayload?
    @State private var status = "正在生成二维码…"
    @State private var isPolling = false

    var body: some View {
        NavigationStack {
            ZStack {
                ParticleBackgroundView()
                VStack(spacing: 22) {
                    Text("NetEase QR Login")
                        .font(.system(size: 32, weight: .black, design: .rounded))
                        .foregroundStyle(.white)

                    qrView

                    Text(status)
                        .font(.headline)
                        .foregroundStyle(.white.opacity(0.82))
                        .multilineTextAlignment(.center)

                    Button("重新生成") {
                        Task { await createAndPoll() }
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.white)
                    .foregroundStyle(.black)
                }
                .padding(24)
            }
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Done") { dismiss() }
                        .foregroundStyle(.white)
                }
            }
            .task { await createAndPoll() }
            .onDisappear { isPolling = false }
        }
    }

    @ViewBuilder
    private var qrView: some View {
        if let data = qrPayload?.imageData, let image = UIImage(data: data) {
            Image(uiImage: image)
                .interpolation(.none)
                .resizable()
                .scaledToFit()
                .padding(18)
                .frame(width: 260, height: 260)
                .background(.white, in: RoundedRectangle(cornerRadius: 28, style: .continuous))
                .shadow(radius: 24)
        } else if let urlString = qrPayload?.qrURL, let url = URL(string: urlString) {
            VStack(spacing: 12) {
                Image(systemName: "qrcode")
                    .font(.system(size: 74))
                Link("打开二维码链接", destination: url)
            }
            .foregroundStyle(.white)
            .frame(width: 260, height: 260)
            .background(.white.opacity(0.12), in: RoundedRectangle(cornerRadius: 28, style: .continuous))
        } else {
            ProgressView()
                .tint(.white)
                .frame(width: 260, height: 260)
                .background(.white.opacity(0.12), in: RoundedRectangle(cornerRadius: 28, style: .continuous))
        }
    }

    @MainActor
    private func createAndPoll() async {
        isPolling = false
        status = "正在生成二维码…"
        let service = NetEaseService(baseURL: settings.netEaseBaseURL, cookie: settings.netEaseCookie)
        do {
            let payload = try await service.createQRCode()
            qrPayload = payload
            status = "用网易云音乐 App 扫码确认登录。"
            isPolling = true
            await poll(key: payload.key)
        } catch {
            status = error.localizedDescription
        }
    }

    @MainActor
    private func poll(key: String) async {
        let service = NetEaseService(baseURL: settings.netEaseBaseURL, cookie: settings.netEaseCookie)
        for _ in 0..<48 where isPolling {
            do {
                try await Task.sleep(nanoseconds: 2_500_000_000)
                let check = try await service.checkQRCode(key: key)
                switch check.code {
                case 800:
                    status = "二维码已过期，请重新生成。"
                    isPolling = false
                    return
                case 801:
                    status = "等待扫码…"
                case 802:
                    status = "已扫码，等待手机确认…"
                case 803:
                    if let cookie = check.cookie, !cookie.isEmpty {
                        settings.netEaseCookie = cookie
                    }
                    status = "登录成功：\(check.nickname ?? "NetEase")"
                    isPolling = false
                    return
                default:
                    status = check.message ?? "状态码：\(check.code)"
                }
            } catch {
                status = error.localizedDescription
                isPolling = false
                return
            }
        }
    }
}
