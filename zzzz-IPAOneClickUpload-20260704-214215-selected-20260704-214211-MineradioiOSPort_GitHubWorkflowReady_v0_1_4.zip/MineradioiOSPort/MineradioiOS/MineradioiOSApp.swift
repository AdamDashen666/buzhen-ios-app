import SwiftUI

@main
struct MineradioiOSApp: App {
    @StateObject private var settings = SettingsStore()
    @StateObject private var player = PlayerController()
    @StateObject private var library = LocalLibraryStore()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(settings)
                .environmentObject(player)
                .environmentObject(library)
                .task {
                    await library.load()
                }
        }
    }
}
