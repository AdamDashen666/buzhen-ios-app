# Buzhen Local v2

参考 `buzhen.py v27` 做的 iPadOS Xcode 原生补帧 App 工程。

## v2 新增

- 4 档光流质量：
  - 1 快速
  - 2 平衡
  - 3 高质量
  - 4 极限光流
- 处理模式：
  - 单次完整处理
  - 串行分段处理
  - 并行分段处理
- 输出模式：
  - Apple HEVC 兼容
  - H.264 最稳兼容
  - HDR 保留模式
- 码率：
  - 自动推荐
  - 手动 Mbps
- 音频/元数据/HDR 色彩标签选项
- 视频信息检测：
  - 分辨率
  - 帧率
  - 时长
  - 编码
  - HDR 状态
  - 音频状态

## 和 Python 版的区别

Python 版用 FFmpeg `minterpolate`。  
这个 iPad App 用：

- AVFoundation：读取/写入视频
- Vision：生成光流
- Metal：按光流生成中间帧

所以它不是直接运行 Python，也不是 FFmpeg 套壳。

## 重要限制

1. 这是 v2 原型，未在真实 Xcode 环境编译测试。
2. HDR 保留目前是“尝试保留色彩标签”，不是完整杜比视界元数据复制。
3. 并行分段可能更快，但 iPad 上也更容易发热/内存压力大。
4. 建议先用 720p / 5 秒测试。
5. 真正想接近 RIFE/GMFSS，需要下一步加入 Core ML 模型。

## 使用方法

1. 解压 zip
2. 用 Xcode 打开 `BuzhenLocal.xcodeproj`
3. 修改 Bundle Identifier
4. Signing & Capabilities 选择你的 Team
5. 连接 iPad 后 Run

## 推荐设置

### 稳定测试
- 输出模式：Apple HEVC 兼容
- 光流质量：1 快速
- 处理模式：串行分段
- 每段：3 秒

### 画质优先
- 输出模式：HDR 保留模式
- 光流质量：4 极限光流
- 处理模式：串行分段
- 每段：2～3 秒
- 码率：自动或手动 120～250 Mbps

### 速度优先
- 输出模式：Apple HEVC 兼容
- 光流质量：2 平衡
- 处理模式：并行分段
- 并行任务：2


## v3 修复

- 修复 Xcode 编译错误：`composition.metadata` 是只读属性，已改为在 `AVAssetExportSession` 上写入 metadata。
## v4 更新

- 优化 iPad UI：从 Form 改为卡片式自适应布局，横屏/竖屏都会自动排版。
- 修复导入视频：新增“从相册选择视频”和“从文件选择视频”两个入口。
- 文件导入改为安全拷贝到 App 沙盒，提升 iCloud Drive / Files 导入成功率。
- 支持更多视频类型入口：MOV / MP4 / M4V / movie / video / audiovisualContent。
- 版本号已递增到 v4，显示名为 `Buzhen Local v4`。
## v5 更新

- 检查结果：v4 没有调用 Apple Liquid Glass API，只用了 `.thinMaterial` / `.regularMaterial`。
- v5 已加入原生 Liquid Glass：
  - `GlassEffectContainer`
  - `.glassEffect(.regular, in:)`
  - `.buttonStyle(.glass)`
- 应用范围：
  - 顶部标题卡片
  - 所有功能卡片
  - 所有主要按钮
  - 状态徽标
  - 空状态提示
  - 光流质量数字圆标
- iOS 26 以下自动回退到 SwiftUI Material。
- 需要 Xcode 26 / iOS 26 SDK 才能编译 Liquid Glass API。
## v6 更新

- 修复“从文件选择视频时点视频没反应”。
- 文件选择从 SwiftUI `.fileImporter` 改为 UIKit `UIDocumentPickerViewController`。
- `asCopy: true`，选择后直接复制到 App 沙盒，避免 iCloud/Files 权限问题。
- 保留 v5 原生 Liquid Glass 适配。
- 版本号递增到 `6.0`，显示名为 `Buzhen Local v6`。
## v7 更新

- 加入完整进度系统：
  - 总进度条
  - 当前阶段
  - 分段任务列表
  - 每段独立进度条
  - 并行任务数显示
  - 已完成段数显示
- 并行分段处理现在会回传每个 segment 的实时进度，不再只显示“完成几个”。
- 进度条、分段任务卡、状态徽标全部使用 Liquid Glass 包装：
  - `GlassEffectContainer`
  - `.glassEffect(.regular, in:)`
  - `.buttonStyle(.glass)`
- 修复 iPad 屏幕比例适配：
  - 使用 `GeometryReader`
  - 横屏最多 3 列
  - 中等宽度 2 列
  - 窄屏/竖屏 1 列
  - 根据屏幕宽度自动调整边距和最大内容宽度
- 历史版本：v7 曾修复进度与 iPad 布局问题；当前版本为 `8.0` / `Buzhen Local v8`。

## v8 更新

- 点击开始补帧后进入独立进度页，处理中不可返回。
- 完成后才显示返回设置和导出/保存按钮。
- 新增实时 CPU、GPU估算、内存、温度、处理速度、预计剩余时间。
- 帧率、码率、分段秒数、并行任务数支持精确输入。
- 加入 By LaoDeng666 App 图标。
- 版本升级为 8.0，继续支持 iPhone/iPad Universal，并强制 iPad 全屏。


## v10
- 新增性能日志 CSV 导出。
- 速度显示改为 frame/s。
- 新增 5 抗模糊极限光流，减少高速运动拖影。


## v10 更新
- 加入 iPad Stage Manager / 分屏 / 浮窗窗口自适应。
- 设置 iPad 最小窗口尺寸 680×520 pt，避免台前调度窗口过小时 UI 挤爆。
- 将精确数字输入框改为 Liquid Glass 样式，窄窗口自动从横排切换为竖排。
- 性能面板改为 adaptive grid，适配 iPhone、iPad 全屏、分屏和台前调度。
- 版本号更新到 10.0 / build 10。

## v11 更新

- 新增“6 终极质量+抗模糊”。
- 该模式使用双向 veryHigh 光流，增加正反向一致性检查，尽量减少高速运动中的鬼影、拖影和双帧混合模糊。
- 4 仍是极限质量/最慢，5 是清晰抗模糊优先，6 是质量与抗模糊同时拉满。
- 版本号更新到 11.0 / build 11。


## v139
- 修复 1000fps 样本级封装阶段“无法创建样本级读取器”的失败。
- 高帧率音频先直拷，失败后自动 PCM 解码 + AAC 重封装。
- 不回退到会导致 600fps / 慢放 / 音画错位的旧合并路径。
