import SwiftUI
import UniformTypeIdentifiers

struct ContentView: View {
    @StateObject private var manager = BuildManager()
    @State private var showFileImporter = false
    @State private var showToken = false
    @State private var showAdvanced = false

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 18) {
                    header
                    fileCard
                    githubCard
                    workflowCard
                    buildCard
                    outputCard
                    logCard
                }
                .padding()
            }
            .navigationTitle("IPA 一键打包器")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("保存配置") { manager.saveSettings() }
                }
            }
            .sheet(isPresented: $showFileImporter) {
                CompatibleDocumentPicker(
                    allowedTypes: importPickerContentTypes,
                    allowsMultipleSelection: false
                ) { result in
                    showFileImporter = false
                    handleFileImport(result)
                }
                .ignoresSafeArea()
            }
        }
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("iPad 上一键运行你的 buzhen-ios-app 打包 workflow")
                .font(.title2.weight(.bold))
            Text("默认适配你给的 GitHub Actions run：选择 Xcode 项目 ZIP → 上传到仓库根目录 → 触发同一个 workflow → 下载 Built-IPA / Diagnostics；失败自动下载日志。")
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding()
        .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
    }

    private var fileCard: some View {
        card(title: "1. 选择项目 ZIP") {
            HStack(spacing: 12) {
                Button {
                    showFileImporter = true
                } label: {
                    Label("选择 ZIP", systemImage: "doc.badge.plus")
                }
                .buttonStyle(.borderedProminent)

                VStack(alignment: .leading, spacing: 4) {
                    Text(manager.selectedFileURL?.lastPathComponent ?? "还没有选择文件")
                        .font(.headline)
                    Text("你的现有 workflow 会自动找仓库根目录最新 zip，所以 App 会把这个 zip 上传到根目录再触发构建。")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                Spacer()
            }
        }
    }

    private var githubCard: some View {
        card(title: "2. GitHub 设置") {
            Grid(alignment: .leading, horizontalSpacing: 12, verticalSpacing: 12) {
                GridRow {
                    Text("Owner")
                    TextField("AdamDashen666", text: $manager.settings.owner)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                }
                GridRow {
                    Text("Repo")
                    TextField("buzhen-ios-app", text: $manager.settings.repo)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                }
                GridRow {
                    Text("Branch")
                    TextField("main", text: $manager.settings.branch)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                }
                GridRow {
                    Text("GitHub Token")
                    HStack {
                        Group {
                            if showToken {
                                TextField("ghp_xxx / github_pat_xxx", text: $manager.githubToken)
                                    .textInputAutocapitalization(.never)
                                    .autocorrectionDisabled()
                            } else {
                                SecureField("ghp_xxx / github_pat_xxx", text: $manager.githubToken)
                                    .textInputAutocapitalization(.never)
                                    .autocorrectionDisabled()
                            }
                        }
                        Button(showToken ? "隐藏" : "显示") { showToken.toggle() }
                    }
                }
            }
            Text("Token 需要 repo contents 写入权限和 actions workflow 权限。")
                .font(.caption)
                .foregroundStyle(.secondary)
        }
    }

    private var workflowCard: some View {
        card(title: "3. Workflow 设置") {
            VStack(alignment: .leading, spacing: 12) {
                Grid(alignment: .leading, horizontalSpacing: 12, verticalSpacing: 12) {
                    GridRow {
                        Text("参考 Run")
                        TextField("actions/runs/.../workflow", text: $manager.settings.referenceRunURL)
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled()
                    }
                    GridRow {
                        Text("Workflow ID/文件")
                        TextField("可留空，自动从参考 Run 解析", text: $manager.settings.workflowIdentifier)
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled()
                    }
                    GridRow {
                        Text("上传名前缀")
                        TextField("zzzz-IPAOneClickUpload", text: $manager.settings.uploadedZipPrefix)
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled()
                    }
                }

                Toggle("上传 ZIP 到仓库根目录", isOn: $manager.settings.uploadSourceZipToRepoRoot)
                Toggle("触发后删除刚上传的 ZIP", isOn: $manager.settings.deleteUploadedZipAfterDispatch)
                Toggle("上传前删除根目录旧 ZIP", isOn: $manager.settings.deletePreviousRootZipsBeforeUpload)
                Toggle("失败时自动下载 GitHub 日志 ZIP", isOn: $manager.settings.downloadLogsOnFailure)
                Toggle("成功/失败都下载 artifacts", isOn: $manager.settings.downloadArtifactsAfterBuild)
                Toggle("开始前删除旧 Built-IPA / Diagnostics artifacts", isOn: $manager.settings.deletePreviousBuildArtifacts)
            }
        }
    }

    private var buildCard: some View {
        card(title: "4. 开始打包") {
            VStack(spacing: 12) {
                VStack(alignment: .leading, spacing: 8) {
                    HStack {
                        Text("状态：\(manager.phase.rawValue)")
                            .font(.headline)
                        Spacer()
                        Text("\(Int(manager.progress * 100))%")
                            .monospacedDigit()
                            .foregroundStyle(.secondary)
                    }
                    ProgressView(value: manager.progress)
                }

                HStack {
                    Button {
                        Task { await manager.startBuild() }
                    } label: {
                        Label(manager.isRunning ? "正在打包" : "开始打包", systemImage: "play.fill")
                    }
                    .buttonStyle(.borderedProminent)
                    .disabled(!manager.canStart)

                    if let runURL = manager.activeRunURL {
                        Link(destination: runURL) {
                            Label("打开 Actions", systemImage: "safari")
                        }
                        .buttonStyle(.bordered)
                    }
                }
                .frame(maxWidth: .infinity, alignment: .leading)

                DisclosureGroup("高级兼容模式", isExpanded: $showAdvanced) {
                    VStack(alignment: .leading, spacing: 10) {
                        Toggle("使用旧版 Release Asset workflow 模式", isOn: $manager.settings.useReleaseUploadMode)
                        TextField("旧 workflow 文件名，例如 ios-ipa-builder.yml", text: $manager.settings.workflowFile)
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled()
                            .textFieldStyle(.roundedBorder)
                        TextField("Scheme，旧模式需要", text: $manager.settings.scheme)
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled()
                            .textFieldStyle(.roundedBorder)
                        TextField("Configuration", text: $manager.settings.configuration)
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled()
                            .textFieldStyle(.roundedBorder)
                    }
                    .padding(.top, 8)
                }
            }
        }
    }

    private var outputCard: some View {
        card(title: "输出文件") {
            VStack(alignment: .leading, spacing: 10) {
                if manager.downloadedIPAURL == nil && manager.downloadedReportURL == nil && manager.downloadedLogsURL == nil && manager.downloadedArtifactURLs.isEmpty {
                    Text("暂无输出")
                        .foregroundStyle(.secondary)
                }

                if let url = manager.downloadedIPAURL {
                    ShareLink(item: url) {
                        Label("分享 / 保存 IPA Artifact ZIP", systemImage: "square.and.arrow.up")
                    }
                    .buttonStyle(.borderedProminent)
                    Text(url.lastPathComponent)
                        .font(.caption.monospaced())
                        .foregroundStyle(.secondary)
                }

                if let url = manager.downloadedLogsURL {
                    ShareLink(item: url) {
                        Label("分享失败日志 ZIP", systemImage: "doc.zipper")
                    }
                    .buttonStyle(.bordered)
                    Text(url.lastPathComponent)
                        .font(.caption.monospaced())
                        .foregroundStyle(.secondary)
                }

                if let url = manager.downloadedReportURL, isDistinctReport(url) {
                    ShareLink(item: url) {
                        Label("分享 Diagnostics / Report", systemImage: "doc.text")
                    }
                    .buttonStyle(.bordered)
                    Text(url.lastPathComponent)
                        .font(.caption.monospaced())
                        .foregroundStyle(.secondary)
                }

                ForEach(extraArtifactURLs, id: \.self) { url in
                    ShareLink(item: url) {
                        Label(url.lastPathComponent, systemImage: "archivebox")
                    }
                    .buttonStyle(.bordered)
                }
            }
        }
    }


    private var extraArtifactURLs: [URL] {
        manager.downloadedArtifactURLs.filter { isDistinctOutput($0) }
    }


    private func isDistinctReport(_ url: URL) -> Bool {
        if manager.downloadedIPAURL == url { return false }
        if manager.downloadedLogsURL == url { return false }
        return true
    }

    private func isDistinctOutput(_ url: URL) -> Bool {
        if manager.downloadedIPAURL == url { return false }
        if manager.downloadedReportURL == url { return false }
        if manager.downloadedLogsURL == url { return false }
        return true
    }

    private var logCard: some View {
        card(title: "运行日志") {
            VStack(alignment: .leading, spacing: 8) {
                if manager.logs.isEmpty {
                    Text("暂无日志")
                        .foregroundStyle(.secondary)
                } else {
                    ForEach(manager.logs) { entry in
                        Text("• \(entry.message)")
                            .font(.footnote.monospaced())
                            .frame(maxWidth: .infinity, alignment: .leading)
                    }
                }
            }
            .textSelection(.enabled)
        }
    }


    private var importPickerContentTypes: [UTType] {
        var types: [UTType] = [.zip, .archive, .data, .item]
        if let publicZip = UTType(filenameExtension: "zip") {
            types.insert(publicZip, at: 0)
        }
        return types
    }

    private func handleFileImport(_ result: Result<[URL], Error>) {
        switch result {
        case .success(let urls):
            guard let url = urls.first else {
                manager.logs.append(BuildLogEntry(message: "没有选中文件。"))
                return
            }
            manager.logs.append(BuildLogEntry(message: "已点选文件：\(url.lastPathComponent)"))
            do {
                let copied = try copyIntoDocuments(url)
                manager.selectedFileURL = copied
                manager.logs.append(BuildLogEntry(message: "ZIP 已导入：\(copied.lastPathComponent)"))
            } catch {
                manager.logs.append(BuildLogEntry(message: "导入失败：\(error.localizedDescription)"))
            }
        case .failure(let error):
            if let pickerError = error as? CompatibleDocumentPicker.PickerError, pickerError == .cancelled {
                manager.logs.append(BuildLogEntry(message: "已取消选择文件。"))
            } else {
                manager.logs.append(BuildLogEntry(message: "选择文件失败：\(error.localizedDescription)"))
            }
        }
    }

    private func card<Content: View>(title: String, @ViewBuilder content: () -> Content) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(title)
                .font(.headline)
            content()
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding()
        .background(.background, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 18, style: .continuous)
                .stroke(.quaternary, lineWidth: 1)
        }
    }

    private func copyIntoDocuments(_ sourceURL: URL) throws -> URL {
        let ext = sourceURL.pathExtension.lowercased()
        guard ext == "zip" else {
            throw NSError(
                domain: "IPAOneClickBuilder.Import",
                code: 1001,
                userInfo: [NSLocalizedDescriptionKey: "请选择 .zip 文件，当前文件是：\(sourceURL.lastPathComponent)"]
            )
        }

        let fileManager = FileManager.default
        let documents = fileManager.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let importsDirectory = documents.appendingPathComponent("ImportedZips", isDirectory: true)
        try fileManager.createDirectory(at: importsDirectory, withIntermediateDirectories: true)

        let safeName = sanitizeImportedFilename(sourceURL.lastPathComponent)
        let destination = importsDirectory.appendingPathComponent("selected-\(timestampForImport())-\(safeName)")

        let didAccess = sourceURL.startAccessingSecurityScopedResource()
        defer {
            if didAccess { sourceURL.stopAccessingSecurityScopedResource() }
        }

        var coordinatorError: NSError?
        var copyError: Error?
        NSFileCoordinator().coordinate(readingItemAt: sourceURL, options: [], error: &coordinatorError) { coordinatedURL in
            do {
                if fileManager.fileExists(atPath: destination.path) {
                    try fileManager.removeItem(at: destination)
                }
                try fileManager.copyItem(at: coordinatedURL, to: destination)
            } catch {
                copyError = error
            }
        }

        if let copyError {
            throw copyError
        }
        if let coordinatorError {
            throw coordinatorError
        }

        return destination
    }

    private func sanitizeImportedFilename(_ filename: String) -> String {
        let allowed = CharacterSet.alphanumerics.union(CharacterSet(charactersIn: "._-"))
        let scalars = filename.unicodeScalars.map { allowed.contains($0) ? Character($0) : "-" }
        let cleaned = String(scalars).trimmingCharacters(in: CharacterSet(charactersIn: ".-"))
        return cleaned.isEmpty ? "Project.zip" : cleaned
    }

    private func timestampForImport() -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyyMMdd-HHmmss"
        return formatter.string(from: Date())
    }
}

#Preview {
    ContentView()
}
