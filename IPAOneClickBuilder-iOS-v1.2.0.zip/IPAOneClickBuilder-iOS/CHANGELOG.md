# Changelog

## v1.2.0 - 2026-06-17

### Fixed

- 修复 iPadOS 文件选择器点 ZIP 后没反应的问题。
- 从 SwiftUI `.fileImporter` 改为 UIKit `UIDocumentPickerViewController` 兼容选择器。
- 放宽选择器类型到 `.zip / archive / data / item`，避免部分 iCloud Drive / 文件 App 里的 ZIP 类型识别失败。
- 选择后会立即写入运行日志：`已点选文件`、`ZIP 已导入` 或具体错误。
- 导入时会先复制到 App 文档目录 `ImportedZips/`，避免安全作用域权限失效导致后续上传失败。

### Notes

- 仍然只允许真正的 `.zip` 文件进入打包流程；如果选了非 ZIP，会在日志里提示。

## v1.1.0 - 2026-06-17

### Added

- 默认适配 `AdamDashen666/buzhen-ios-app`。
- 支持从参考 run 链接自动解析 workflow id：`actions/runs/27696458167/workflow`。
- 新增“仓库根目录 ZIP 上传模式”，匹配现有 `Build newest source zip` workflow。
- 新增触发后自动删除刚上传 ZIP 的选项，保持仓库干净。
- 新增上传前删除根目录旧 ZIP 的选项。
- 新增成功后下载 GitHub Actions artifacts：
  - `Built-IPA-Newest-*`
  - `Build-Diagnostics-Newest-*`
- 新增失败后自动下载：
  - GitHub run logs ZIP
  - diagnostics artifacts
  - failure summary txt
- 新增 job / step 失败摘要显示。
- 新增旧 artifacts 清理选项。

### Changed

- 默认不再依赖 Release asset workflow，而是优先使用你现有仓库里的打包 workflow。
- 首页文案、设置项和输出按钮已改成适合 buzhen-ios-app 的一键打包流程。

### Notes

- GitHub artifact 下载结果本身是 ZIP，里面才是 `.ipa`。
- GitHub Contents API 不适合超过约 95 MB 的 ZIP。

## v1.0.0 - 2026-06-17

### Added

- 初版 iPadOS / iOS IPA 一键打包器。
- 支持选择 ZIP、上传 Release asset、触发 workflow、下载 IPA、基础日志显示。
