import SwiftUI

struct CreationView: View {
    @EnvironmentObject private var store: ProjectStore
    @EnvironmentObject private var apiSettings: APISettings

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                SectionHeader(
                    title: "AI 漫画制作",
                    subtitle: "输入故事或关键词，自动提取角色、完善设定、规划分镜，再生成每页漫画图。"
                )

                GlassCard(title: "基础设置") {
                    TextField("项目标题", text: Binding(get: { store.project.title }, set: { store.project.title = $0; store.save() }))
                        .textFieldStyle(.roundedBorder)

                    Picker("创作模式", selection: Binding(get: { store.project.mode }, set: { store.project.mode = $0; store.save() })) {
                        ForEach(CreationMode.allCases) { mode in
                            Text(mode.title).tag(mode)
                        }
                    }
                    .pickerStyle(.segmented)

                    Text(store.project.mode.explanation)
                        .font(.footnote)
                        .foregroundStyle(.secondary)

                    Picker("漫画风格", selection: Binding(get: { store.project.style }, set: { store.project.style = $0; store.save() })) {
                        ForEach(ComicStyle.allCases) { style in
                            Text(style.displayName).tag(style)
                        }
                    }

                    HStack(spacing: 18) {
                        Stepper("页数：\(store.project.pageCount)", value: Binding(get: { store.project.pageCount }, set: { store.project.pageCount = $0; store.save() }), in: 1...30)
                        Stepper("每页分镜：\(store.project.panelsPerPage)", value: Binding(get: { store.project.panelsPerPage }, set: { store.project.panelsPerPage = $0; store.save() }), in: 1...8)
                    }
                }

                GlassCard(title: store.project.mode == .story ? "粘贴故事" : "输入提示词 / 世界观 / 人物想法") {
                    TextEditor(text: Binding(get: { store.project.sourceInput }, set: { store.project.sourceInput = $0; store.save() }))
                        .frame(minHeight: 220)
                        .padding(10)
                        .background(Color(.secondarySystemBackground).opacity(0.5), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                        .overlay(RoundedRectangle(cornerRadius: 18).strokeBorder(.secondary.opacity(0.16)))

                    HStack {
                        LoadingButton(isLoading: store.isBusy) {
                            Task { await store.planComic(settings: apiSettings) }
                        } label: {
                            Label("自动规划漫画", systemImage: "sparkles")
                        }
                        .buttonStyle(.borderedProminent)

                        LoadingButton(isLoading: store.isBusy) {
                            Task { await store.generateAllPages(settings: apiSettings) }
                        } label: {
                            Label("一键生成所有页", systemImage: "photo.stack")
                        }
                        .buttonStyle(.bordered)

                        Spacer()
                        StatusPill(status: store.project.status)
                    }
                }

                if !store.project.logline.isEmpty || !store.project.generatedStory.isEmpty {
                    GlassCard(title: "AI 故事结果") {
                        if !store.project.logline.isEmpty {
                            Text(store.project.logline)
                                .font(.title3.weight(.semibold))
                        }
                        if !store.project.generatedStory.isEmpty {
                            Text(store.project.generatedStory)
                                .font(.body)
                                .foregroundStyle(.secondary)
                        }
                    }
                }
            }
            .padding(24)
        }
        .background(LinearGradient(colors: [.blue.opacity(0.12), .purple.opacity(0.10), .clear], startPoint: .topLeading, endPoint: .bottomTrailing))
    }
}
