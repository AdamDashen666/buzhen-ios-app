import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView {
            NavigationStack {
                CreationView()
                    .navigationTitle("创作")
            }
            .tabItem {
                Label("创作", systemImage: "sparkles.rectangle.stack")
            }

            NavigationStack {
                CharacterListView()
                    .navigationTitle("角色")
            }
            .tabItem {
                Label("角色", systemImage: "person.2")
            }

            NavigationStack {
                PageWorkspaceView()
                    .navigationTitle("页面")
            }
            .tabItem {
                Label("页面", systemImage: "square.grid.2x2")
            }

            NavigationStack {
                APISettingsView()
                    .navigationTitle("API 与模型")
            }
            .tabItem {
                Label("设置", systemImage: "slider.horizontal.3")
            }

            NavigationStack {
                LogsView()
                    .navigationTitle("日志")
            }
            .tabItem {
                Label("日志", systemImage: "doc.text")
            }
        }
    }
}
