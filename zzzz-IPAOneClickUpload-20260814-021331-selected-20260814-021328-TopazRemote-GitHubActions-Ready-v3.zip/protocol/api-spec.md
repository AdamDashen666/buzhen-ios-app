# Topaz Remote Agent API v1

`GET /api/v1/health` is public and returns `{"status":"ok","apiVersion":"v1"}`. Every other endpoint requires `Authorization: Bearer <pairing-token>`.

| Method | Path | Purpose |
| --- | --- | --- |
| GET | `/system` | Agent runtime information |
| GET | `/capabilities` | Effective Topaz model capability data |
| POST | `/uploads` | Create an upload; returns id and 8 MiB chunk size |
| PUT | `/uploads/{id}/chunks/{index}` | Store or retry one chunk |
| GET | `/uploads/{id}` | Inspect received chunk indexes |
| POST | `/uploads/{id}/complete` | Validate and atomically publish a source |
| GET / POST | `/jobs` | List jobs or queue a completed Agent-managed source |
| POST | `/jobs/{id}/cancel` | Cancel a queued job or request cancellation of its owned child process |
| GET | `/jobs/{id}/output` | Download a completed MP4, including HTTP Range requests |

All errors use `{ "error": { "code": "...", "message": "...", "recoverable": true } }`. The Agent rejects source paths outside its own data directory, does not accept arbitrary command arguments, and never runs a shell command from client input.
