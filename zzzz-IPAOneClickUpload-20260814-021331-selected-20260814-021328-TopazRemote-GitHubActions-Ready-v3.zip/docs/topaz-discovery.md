# Topaz discovery

Discovery date: 2026-08-13. This phase used read-only queries only. It did not modify Tailscale, proxy/VPN settings, DNS, routing, adapters, firewall rules, or the Topaz installation.

## Confirmed installation

- Product: Topaz Video 1.6.2.0 by Topaz Labs.
- Main executable: `D:\Program Files\Topaz Labs LLC\Topaz Video\Topaz Video.exe`.
- Signature: valid Topaz Labs code-signing certificate.
- Bundled FFmpeg: version 8.1, compiled with `--enable-tvai`.
- Bundled filters: `tvai_up`, `tvai_fi`, `tvai_pe`, `tvai_cpe`, and `tvai_stb`.

## Confirmed integration path

The native UI is not the preferred automation target. Topaz's own export log records an internal command contract with an input path, output path, output dimensions, encoding arguments, and model filter settings. The bundled FFmpeg exposes documented Topaz filters and their parameter ranges. The Agent will therefore implement a dedicated bundled-FFmpeg adapter whose command builder allows only capability-validated settings; it will not automate the GUI by default.

`neuroserver.exe` is an internal component rather than a standalone CLI. A help/version probe outside its installation working directory exited before doing work because its relative Python runtime could not resolve `torch`. It will not be invoked directly by the Agent.

## Capability sources

Bundled filter help confirms that the `tvai_up` and `tvai_fi` filters exist and exposes their option bounds. Historical export logs preserve model IDs and command shapes, but they do **not** prove a model package remains installed. A real one-frame, `download=0` probe on 2026-08-14 returned `Model not found` for `apo-8`, `chr-2`, and `prob-4`; no model is currently advertised as runnable. The Agent therefore merges evidence fail-closed: a model stays unavailable until a successful local probe or explicit verified local override.

## Progress sources

The existing `topaz-progress-notifier` is read-only and already parses `*.tzlog` records. It identifies structured `RUNNING`/`FINISHED` payloads, Topaz's `Video Export Started` event, legacy FFmpeg frame lines, and parent-child ownership for Topaz workers. The Agent will reuse this evidence format through its own isolated progress provider. It will leave the existing notifier, its PushPlus token file, and the prior Topaz UI patch artifacts untouched.

## Platform findings

- Windows 11 Pro x64; Python 3.10, .NET, Node.js, FFmpeg, FFprobe, Git, and Tailscale are available.
- The local Tailscale client is running and has a private IPv4 address. The Agent will discover and display its current address at runtime instead of persisting it in source-controlled files.
- Xcode is not installed on this Windows computer. The iOS project can be generated and statically validated here, but compiling it requires macOS CI or a Mac with Xcode.

## Discovery outcome

Integration mode: `ffmpeg` (confirmed). GUI automation: not selected. Dynamic model enumeration: filter support is confirmed; current runnable model enumeration is empty until Topaz has a locally installed model that passes a probe.
