# Security boundary

The Agent is intended for a private existing Tailscale tailnet. It does not configure, install, start, stop, or otherwise modify Tailscale, VPN/proxy settings, DNS, routes, network adapters, or firewall rules.

Pairing uses one locally generated bearer token stored under the Agent data directory. Keep it private. Health is deliberately unauthenticated for simple reachability checks; capabilities, filenames, jobs, uploads, and downloads require the token.

The iOS client allows HTTP because this private Agent is paired by a dynamic Tailscale address and does not provide a public TLS certificate. Keep the Agent private to the tailnet and do not expose it through public port forwarding. Pairing tokens remain mandatory on all non-health endpoints.

The Agent owns only media uploaded beneath its data directory and processes that it directly creates. It validates model settings against capabilities, constructs argv without a shell, disables Topaz model downloads, and only calls `terminate()` on a process object it registered for the active job. It never searches for or terminates arbitrary Topaz processes.
