# iOS signing

This repository contains no Apple credentials. In Xcode, set a unique `PRODUCT_BUNDLE_IDENTIFIER`, select your Apple development team, and let Xcode create the development provisioning profile. For GitHub Actions device archives, store the certificate, provisioning profile, and passwords only as repository secrets; do not put any of them in source control.

On this Windows computer the Xcode project has been structurally checked but cannot be compiled. Verify the project on macOS with `xcodebuild` before distributing an IPA.

The app uses the system Files and Photos pickers for videos and saves the Agent host/port in `UserDefaults` plus the bearer token in the iOS Keychain. It streams uploads in bounded Agent-sized chunks and saves completed downloads in the app's Documents directory. Its HTTP transport is intentionally limited to a private Tailscale Agent; do not expose the Agent through public port forwarding.
