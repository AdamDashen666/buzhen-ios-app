# Architecture

The Python Windows Agent owns all state in its own data directory. Its HTTP API is bearer-token protected except for health. Upload chunks are stored on disk and atomically published only after size/hash validation; jobs and observed progress persist in SQLite; output responses support byte ranges.

Topaz integration is isolated in `topaz_adapter.py` and `worker.py`. It builds list-form argv for the locally detected bundled FFmpeg filters, validates model IDs against effective capabilities, reads only its own child-process output, and persists recognized structured progress records. It does not invoke Topaz GUI automation, modify models, or request model downloads. Unavailable FPS and ETA remain null.
