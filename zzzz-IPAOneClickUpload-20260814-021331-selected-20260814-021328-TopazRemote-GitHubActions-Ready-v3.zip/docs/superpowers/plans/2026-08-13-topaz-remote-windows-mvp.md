# Topaz Remote Windows MVP Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use `superpowers:executing-plans` to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Deliver a private, token-protected Windows Agent that exposes dynamic Topaz Video capabilities, resumable transfer, persistent single-job execution, reliable log-derived progress, and range-download APIs for a SwiftUI iOS client.

**Architecture:** Implement the Agent in Python 3.10 using only the standard library so it has no unavailable package dependency. A threaded HTTP server owns authentication and transport; isolated domain modules own SQLite persistence, filesystem operations, capability merging, FFmpeg command construction, and Topaz-log parsing. The iOS project is a generated SwiftUI source project plus fixtures and CI workflow; Xcode compilation is deferred to macOS CI because this host has no Xcode.

**Tech Stack:** Python 3.10 standard library (`http.server`, `sqlite3`, `hashlib`, `subprocess`, `unittest`); bundled Topaz FFmpeg; Swift/SwiftUI source; GitHub Actions macOS runner.

## Global Constraints

- Never modify Tailscale, proxy/VPN, DNS, routing, adapters, firewall, or Topaz installation.
- All Agent-created runtime data belongs under `%LOCALAPPDATA%\TopazRemote` by default.
- All settings passed to Topaz must originate from effective capabilities and be command-validated.
- Only the Agent-owned process group for a job may be stopped.
- Uploads stream chunks to disk; completed media uses atomic rename; output download supports HTTP Range.
- A single worker processes jobs FIFO. Existing user-started Topaz processes are never controlled.
- Tokens, personal paths, and proxy credentials must never be written to logs or source control.

---

### Task 1: Protocol contracts and capability merge

**Files:**
- Create: `protocol/capability-schema.json`, `protocol/job-schema.json`, `protocol/api-spec.md`
- Create: `windows-agent/src/topazremote/capabilities.py`
- Create: `windows-agent/tests/test_capabilities.py`
- Create: `windows-agent/config/fallback-capabilities.json`, `windows-agent/config/capability-overrides.json`

**Interfaces:** `merge_capabilities(detected, fallback, overrides) -> dict`; each effective value carries `source` and unavailable overrides remove a model or parameter.

- [ ] Write tests for fallback-only capability, detected preference, override replacement, and override disablement.
- [ ] Run `python -m unittest windows-agent/tests/test_capabilities.py -v`; expect import failure because the module does not exist.
- [ ] Implement a strict JSON merge with schema-version validation and source provenance.
- [ ] Re-run the targeted tests and `python -m json.tool` on every protocol/config JSON file; expect success.

### Task 2: Persistent state, safe storage, and authentication

**Files:**
- Create: `windows-agent/src/topazremote/database.py`, `storage.py`, `auth.py`, `models.py`
- Create: `windows-agent/tests/test_storage_and_auth.py`

**Interfaces:** `Database(path)`, `create_job`, `list_jobs`, `get_job`, `create_upload`, `record_chunk`, `complete_upload`; `TokenStore(path).load_or_create()`; `Storage.complete_upload(upload_id, expected_size, expected_sha256)`.

- [ ] Write tests proving token stability, bearer rejection, restart persistence, traversal rejection, upload size/hash validation, and atomic completion.
- [ ] Run the tests before implementation; expect missing-module failures.
- [ ] Implement SQLite transactions and path containment checks, with no full-file in-memory load.
- [ ] Re-run the tests; inspect that a completed upload resides beneath the Agent source directory.

### Task 3: Topaz discovery, command builder, and progress provider

**Files:**
- Create: `windows-agent/src/topazremote/discovery.py`, `topaz_adapter.py`, `progress.py`
- Create: `windows-agent/tests/test_discovery_and_topaz.py`, `windows-agent/tests/fixtures/topaz-progress.tzlog`

**Interfaces:** `discover_capabilities() -> dict`; `TopazFfmpegAdapter.validate_job(settings)`; `build_command(job) -> list[str]`; `parse_progress_lines(lines) -> ProgressSnapshot`.

- [ ] Write tests for runtime Topaz path discovery, confirmed `tvai_up`/`tvai_fi` parameter bounds, safe argv construction, log JSON progress parsing, and absent FPS/ETA.
- [ ] Run them before implementation; expect missing-module failures.
- [ ] Implement read-only local discovery and allowlisted FFmpeg filter construction. The adapter must reject unknown model IDs and must not set model download on behalf of a job.
- [ ] Re-run tests and a read-only `ffmpeg -h filter=tvai_up` smoke probe. Record the exact integration mode in discovery data.

### Task 4: Authenticated HTTP API and resumable transfers

**Files:**
- Create: `windows-agent/src/topazremote/server.py`, `api.py`, `main.py`
- Create: `windows-agent/tests/test_api.py`, `windows-agent/scripts/mock_ios_client.py`

**Interfaces:** `/api/v1/health`, `/system`, `/capabilities`, upload lifecycle endpoints, job CRUD/cancel endpoints, `/output`, and settings endpoints.

- [ ] Write tests for health anonymity, bearer protection, capability response, interrupted chunk retry, malformed range, valid range response, and JSON error envelope.
- [ ] Run before implementation; expect missing-server failures.
- [ ] Implement routing, request-size bounds, JSON validation, `Authorization: Bearer`, `206` range responses, and direct local sockets without proxy-aware HTTP clients.
- [ ] Re-run tests and execute `mock_ios_client.py` against a local ephemeral Agent instance.

### Task 5: FIFO job runner and restart recovery

**Files:**
- Create: `windows-agent/src/topazremote/jobs.py`
- Create: `windows-agent/tests/test_jobs.py`

**Interfaces:** `JobRunner.enqueue(job_id)`, `start_next()`, `cancel(job_id)`, `recover_after_restart()`.

- [ ] Write tests for legal state transitions, FIFO dispatch, queued cancellation, tracked-PID cancellation ownership, missing-output failure, and restart recovery.
- [ ] Verify they fail before implementation.
- [ ] Implement one-worker scheduling and an injectable test adapter. The production adapter collects output only after file, size, and FFprobe validation.
- [ ] Re-run the complete Python suite, then run a generated tiny-video smoke only if the selected locally installed Topaz model can be invoked without any model download.

### Task 6: iOS project, dynamic controls, and CI

**Files:**
- Create: `ios/TopazRemote.xcodeproj`, `ios/TopazRemote/**`, `ios/TopazRemoteTests/**`
- Create: `.github/workflows/ios-build.yml`, `docs/ios-signing.md`

**Interfaces:** Codable models matching protocol JSON; `AgentClient`; `DynamicParameterView`; `UploadCoordinator`; `DownloadCoordinator`; Keychain token storage.

- [ ] Add Swift tests for capability decoding, dynamic number/enum/boolean controls, persisted pairing, authenticated request construction, and job parsing.
- [ ] Generate the project and run source/plist structural validation on Windows; expect no missing asset or file reference.
- [ ] On macOS CI, run simulator build/tests unsigned and upload the artifact. Keep signing values exclusively in GitHub Secrets.
- [ ] Document the required Apple signing values and the exact 3–5 device checks that cannot be performed from Windows.

### Task 7: Documentation, launch configuration, and acceptance verification

**Files:**
- Create: `README.md`, `docs/architecture.md`, `docs/security.md`, `docs/troubleshooting.md`, `windows-agent/scripts/start-agent.ps1`
- Modify: `docs/topaz-discovery.md`

**Interfaces:** start script emits only the local Agent endpoint, setup documentation explains pairing and non-modification guarantee.

- [ ] Write acceptance tests for startup/health/auth/capability/fallback/override/upload-resume/range-download/restart/job queue.
- [ ] Run the full test suite and a loopback smoke test.
- [ ] Verify no command or changed file touches Tailscale, proxy/VPN, DNS, routes, adapters, firewall, or Topaz installation.
- [ ] Record passed and unverified items in an implementation report; do not claim an iOS device test from this Windows host.

## Plan self-review

Coverage: Tasks 1–5 cover the Windows MVP and its required validation; Task 6 isolates iOS and CI; Task 7 covers operational documentation and safety evidence. Scope deliberately defers batch jobs, profiles, thumbnails, and remote notifications. All tasks state files, interfaces, tests, and verification commands. No unsupported GUI automation, network reconfiguration, or global dependency installation is included.
