import SwiftUI

@main
struct TopazRemoteApp: App {
    @StateObject private var pairing = PairingSettings()

    var body: some Scene {
        WindowGroup { ContentView(pairing: pairing) }
    }
}
