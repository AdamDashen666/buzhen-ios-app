import Foundation

struct AgentSettings: Hashable {
    var host: String
    var port: Int
    var token: String

    init(host: String = "", port: Int = 8123, token: String = "") {
        self.host = host
        self.port = port
        self.token = token
    }
}

struct CapabilityResponse: Codable { let apiVersion: String; let agentVersion: String; let capabilitySchemaVersion: Int; let enhancementModels: [TopazModel]; let interpolationModels: [TopazModel] }
struct TopazModel: Codable, Identifiable, Hashable { let id: String; let displayName: String; let available: Bool?; let parameters: [CapabilityParameter] }
struct CapabilityParameter: Codable, Identifiable, Hashable { let id: String; let displayName: String?; let type: String; let min: Double?; let max: Double?; let step: Double?; let `default`: ParameterValue?; let options: [ParameterOption]? }
struct ParameterOption: Codable, Hashable { let value: String; let label: String }

enum ParameterValue: Codable, Hashable {
    case string(String), number(Double), bool(Bool)
    init(from decoder: Decoder) throws { let container = try decoder.singleValueContainer(); if let value = try? container.decode(Bool.self) { self = .bool(value) } else if let value = try? container.decode(Double.self) { self = .number(value) } else { self = .string(try container.decode(String.self)) } }
    func encode(to encoder: Encoder) throws { var container = encoder.singleValueContainer(); switch self { case .string(let value): try container.encode(value); case .number(let value): try container.encode(value); case .bool(let value): try container.encode(value) } }
}

struct Job: Codable, Identifiable, Hashable { let id: String; let status: String; let sourceFilename: String?; let progress: JobProgress?; let failureReason: String? }
struct JobProgress: Codable, Hashable { let stage: String?; let overallProgress: Double?; let fps: Double?; let etaSeconds: Int? }
struct UploadTicket: Codable { let id: String; let chunkSize: Int }
struct UploadStatus: Codable { let id: String; let filename: String; let size: Int; let receivedChunks: [Int] }
struct CompletedUpload: Codable { let sourceFilename: String }

func parameterJSON(_ parameter: CapabilityParameter, value: ParameterValue) -> Any {
    switch value { case .string(let value): return value; case .number(let value): return parameter.type == "integer" ? Int(value) : value; case .bool(let value): return value }
}
