import Foundation

enum DownloadCoordinator {
    static func download(jobID: String, client: AgentClient, to directory: URL) async throws -> URL {
        let (temporaryURL, response) = try await URLSession.shared.download(for: client.outputRequest(jobID: jobID))
        guard let http = response as? HTTPURLResponse, http.statusCode == 200 || http.statusCode == 206 else { throw AgentClientError.badResponse((response as? HTTPURLResponse)?.statusCode ?? -1) }
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        let destination = directory.appendingPathComponent("TopazRemote-\(jobID).mp4")
        try? FileManager.default.removeItem(at: destination)
        try FileManager.default.moveItem(at: temporaryURL, to: destination)
        return destination
    }
}
