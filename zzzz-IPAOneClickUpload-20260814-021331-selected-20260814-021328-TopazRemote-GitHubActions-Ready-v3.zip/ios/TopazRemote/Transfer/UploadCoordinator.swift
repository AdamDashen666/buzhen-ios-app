import CryptoKit
import Foundation

enum UploadCoordinator {
    static func upload(url: URL, client: AgentClient, progress: @escaping @MainActor (Double) -> Void) async throws -> String {
        let hasSecurityScope = url.startAccessingSecurityScopedResource()
        defer { if hasSecurityScope { url.stopAccessingSecurityScopedResource() } }
        let values = try url.resourceValues(forKeys: [.fileSizeKey, .nameKey, .isRegularFileKey])
        guard values.isRegularFile == true, let size = values.fileSize, size > 0 else { throw CocoaError(.fileReadUnknown) }
        let name = values.name ?? "video.mp4"
        let digest = try sha256(url: url)
        let ticket = try await client.createUpload(filename: name, size: size, sha256: digest)
        return try await upload(url: url, size: size, ticket: ticket, client: client, progress: progress)
    }

    static func resume(url: URL, ticket: UploadTicket, client: AgentClient, progress: @escaping @MainActor (Double) -> Void) async throws -> String {
        let hasSecurityScope = url.startAccessingSecurityScopedResource()
        defer { if hasSecurityScope { url.stopAccessingSecurityScopedResource() } }
        let values = try url.resourceValues(forKeys: [.fileSizeKey, .isRegularFileKey])
        guard values.isRegularFile == true, let size = values.fileSize, size > 0 else { throw CocoaError(.fileReadUnknown) }
        return try await upload(url: url, size: size, ticket: ticket, client: client, progress: progress)
    }

    private static func upload(url: URL, size: Int, ticket: UploadTicket, client: AgentClient, progress: @escaping @MainActor (Double) -> Void) async throws -> String {
        let received = Set(try await client.uploadStatus(uploadID: ticket.id).receivedChunks)
        let handle = try FileHandle(forReadingFrom: url)
        defer { try? handle.close() }
        var index = 0
        var sent = 0
        while true {
            let chunk = try handle.read(upToCount: ticket.chunkSize) ?? Data()
            if chunk.isEmpty { break }
            if received.contains(index) { sent += chunk.count; index += 1; continue }
            try await client.uploadChunk(uploadID: ticket.id, index: index, data: chunk)
            index += 1
            sent += chunk.count
            await progress(min(1, Double(sent) / Double(size)))
        }
        return try await client.completeUpload(uploadID: ticket.id).sourceFilename
    }

    private static func sha256(url: URL) throws -> String {
        let handle = try FileHandle(forReadingFrom: url)
        defer { try? handle.close() }
        var hash = SHA256()
        while true {
            let data = try handle.read(upToCount: 1024 * 1024) ?? Data()
            if data.isEmpty { break }
            hash.update(data: data)
        }
        return hash.finalize().map { String(format: "%02x", $0) }.joined()
    }
}
