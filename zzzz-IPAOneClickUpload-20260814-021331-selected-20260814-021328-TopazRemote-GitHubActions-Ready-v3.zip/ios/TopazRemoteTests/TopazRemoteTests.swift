import XCTest
@testable import TopazRemote

final class TopazRemoteTests: XCTestCase {
    func testDecodesCapabilityParameters() throws {
        let data = #"{"apiVersion":"v1","agentVersion":"0.1.0","capabilitySchemaVersion":1,"enhancementModels":[{"id":"prob-4","displayName":"Proteus","available":true,"parameters":[]}],"interpolationModels":[{"id":"chr-2","displayName":"Chronos","available":true,"parameters":[{"id":"fps","type":"number","min":1,"max":480,"step":1}]}]}"#.data(using: .utf8)!
        let response = try JSONDecoder().decode(CapabilityResponse.self, from: data)
        XCTAssertEqual(response.enhancementModels.first?.id, "prob-4")
        XCTAssertEqual(response.interpolationModels.first?.parameters.first?.max, 480)
    }

    func testBuildsTokenProtectedAgentURL() throws {
        let client = AgentClient(settings: AgentSettings(host: "100.64.0.2", port: 8123, token: "secret"))
        let request = try client.makeRequest(path: "/jobs")
        XCTAssertEqual(request.url?.absoluteString, "http://100.64.0.2:8123/api/v1/jobs")
        XCTAssertEqual(request.value(forHTTPHeaderField: "Authorization"), "Bearer secret")
    }

    func testRejectsAddressWithSchemeOrPath() {
        let client = AgentClient(settings: AgentSettings(host: "http://bad/path", port: 8123, token: "secret"))
        XCTAssertThrowsError(try client.makeRequest(path: "/jobs"))
    }

    func testSerializesDynamicIntegerAndBooleanParameters() {
        let integer = CapabilityParameter(id: "passes", displayName: nil, type: "integer", min: 1, max: 4, step: 1, default: nil, options: nil)
        let boolean = CapabilityParameter(id: "recover", displayName: nil, type: "boolean", min: nil, max: nil, step: nil, default: nil, options: nil)
        XCTAssertEqual(parameterJSON(integer, value: .number(2)) as? Int, 2)
        XCTAssertEqual(parameterJSON(boolean, value: .bool(true)) as? Bool, true)
    }
}
