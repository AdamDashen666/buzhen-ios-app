# Topaz Remote

Private iPhone/iPad remote control project for the locally installed Topaz Video Windows workstation. It uses an existing Tailscale connection only; it never changes Tailscale, VPN, proxy, DNS, routes, network adapters, or firewall rules.

## What is ready on Windows

- Token-protected HTTP Agent foundations: health, system, capabilities, jobs, resumable chunk upload, byte-range output download, and observed Topaz structured-progress persistence.
- SQLite-persisted jobs/uploads, editable fallback capabilities, capability overrides, and a one-worker FIFO queue with restart recovery.
- A Topaz bundled-FFmpeg command adapter and owned-process worker: allowlisted argv, no shell, no automatic model download, no control over user-started Topaz processes, and FFprobe-validated output publication.
- Observed structured and direct-FFmpeg Topaz progress parsing, persisted failure reasons, and fail-closed model availability: historical logs and filter help never make a model runnable by themselves.

## Start the Agent

From this repository root:

```powershell
$env:PYTHONPATH = (Resolve-Path .\windows-agent\src).Path
python -m topazremote.main --host 0.0.0.0 --port 8123
```

Or use the launcher:

```powershell
.\windows-agent\scripts\start-agent.ps1 -Port 8123
```

The first run writes its data and pairing token below `%LOCALAPPDATA%\TopazRemote` unless `--data-dir` is supplied. Retrieve the token only from that local data directory; never commit or share it.

For API-only inspection without starting Topaz child processes, add `--no-job-execution`.

## iOS project

Open `ios/TopazRemote.xcodeproj` in Xcode 16 or later, set your own bundle identifier and Apple signing team, then build for your device. The client persists its Tailscale host/port and Keychain token, can choose videos from Files or Photos, streams uploads in Agent-sized chunks, submits a job, shows observed progress, cancels jobs, and saves completed output. The included GitHub Actions workflow runs unsigned simulator tests on macOS.

## Current verification

Run:

```powershell
python -m unittest discover -s windows-agent/tests -v
python windows-agent\scripts\mock_ios_client.py
```

The current suite contains 42 tests covering token persistence, capability precedence, atomic upload completion, threaded authenticated HTTP endpoints, Range download, queue semantics and recovery, owned-process cancellation, structured/direct-FFmpeg progress persistence, failure-reason persistence, output validation, and Topaz command validation.

See [the implementation report](docs/implementation-report.md) for the exact local evidence and the remaining macOS/device checks.

## Important remaining validation

This Windows host cannot compile Swift/Xcode or validate an iPhone on a real Tailscale connection. Real short probes on 2026-08-14 confirmed that `apo-8`, `chr-2`, and `prob-4` are currently missing on this Topaz installation, so no successful model export is claimed. After installing a model through the normal Topaz UI, restart the Agent and run the GitHub Actions build or Xcode locally; do not enable GUI automation or alter network settings to work around a failed connection.
