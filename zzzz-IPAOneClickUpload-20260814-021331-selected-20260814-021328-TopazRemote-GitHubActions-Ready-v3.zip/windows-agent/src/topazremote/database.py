from __future__ import annotations

import json
import sqlite3
import uuid
import threading
from pathlib import Path
from typing import Any


class Database:
    def __init__(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        self.connection = sqlite3.connect(path, check_same_thread=False)
        self.lock = threading.RLock()
        self.connection.row_factory = sqlite3.Row
        self.connection.execute(
            """CREATE TABLE IF NOT EXISTS jobs (
                id TEXT PRIMARY KEY, source_filename TEXT NOT NULL,
                settings_json TEXT NOT NULL, status TEXT NOT NULL,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                output_path TEXT,
                progress_json TEXT,
                failure_reason TEXT
            )"""
        )
        self.connection.execute("CREATE TABLE IF NOT EXISTS uploads (id TEXT PRIMARY KEY, filename TEXT NOT NULL, size INTEGER NOT NULL, sha256 TEXT, chunks_json TEXT NOT NULL DEFAULT '[]')")
        if "output_path" not in {row[1] for row in self.connection.execute("PRAGMA table_info(jobs)")}:
            self.connection.execute("ALTER TABLE jobs ADD COLUMN output_path TEXT")
        if "progress_json" not in {row[1] for row in self.connection.execute("PRAGMA table_info(jobs)")}:
            self.connection.execute("ALTER TABLE jobs ADD COLUMN progress_json TEXT")
        if "failure_reason" not in {row[1] for row in self.connection.execute("PRAGMA table_info(jobs)")}:
            self.connection.execute("ALTER TABLE jobs ADD COLUMN failure_reason TEXT")
        self.connection.commit()

    def create_job(self, source_filename: str, settings: dict[str, Any]) -> str:
        job_id = str(uuid.uuid4())
        with self.lock:
            self.connection.execute(
                "INSERT INTO jobs (id, source_filename, settings_json, status) VALUES (?, ?, ?, 'created')",
                (job_id, source_filename, json.dumps(settings, separators=(",", ":"))),
            )
            self.connection.commit()
        return job_id

    def get_job(self, job_id: str) -> dict[str, Any]:
        with self.lock:
            row = self.connection.execute("SELECT * FROM jobs WHERE id = ?", (job_id,)).fetchone()
        if row is None:
            raise KeyError(job_id)
        return {
            "id": row["id"],
            "sourceFilename": row["source_filename"],
            "settings": json.loads(row["settings_json"]),
            "status": row["status"],
            "createdAt": row["created_at"],
            "updatedAt": row["updated_at"],
            "outputPath": row["output_path"],
            "progress": json.loads(row["progress_json"]) if row["progress_json"] else None,
            "failureReason": row["failure_reason"],
        }

    def list_jobs(self) -> list[dict[str, Any]]:
        with self.lock:
            rows = self.connection.execute("SELECT id FROM jobs ORDER BY rowid ASC").fetchall()
        return [self.get_job(row["id"]) for row in rows]

    def set_status(self, job_id: str, status: str) -> None:
        with self.lock:
            result = self.connection.execute("UPDATE jobs SET status=?, updated_at=CURRENT_TIMESTAMP WHERE id=?", (status, job_id))
            self.connection.commit()
        if result.rowcount != 1: raise KeyError(job_id)

    def close(self) -> None:
        with self.lock:
            self.connection.close()

    def set_output_path(self, job_id: str, output: Path) -> None:
        with self.lock:
            self.connection.execute("UPDATE jobs SET output_path=?, status='completed', updated_at=CURRENT_TIMESTAMP WHERE id=?", (str(output), job_id)); self.connection.commit()

    def set_progress(self, job_id: str, progress: dict[str, Any]) -> None:
        with self.lock:
            result = self.connection.execute("UPDATE jobs SET progress_json=?, updated_at=CURRENT_TIMESTAMP WHERE id=?", (json.dumps(progress, separators=(",", ":")), job_id))
            self.connection.commit()
        if result.rowcount != 1: raise KeyError(job_id)

    def set_failure_reason(self, job_id: str, reason: str | None) -> None:
        with self.lock:
            result = self.connection.execute("UPDATE jobs SET failure_reason=?, updated_at=CURRENT_TIMESTAMP WHERE id=?", (reason, job_id))
            self.connection.commit()
        if result.rowcount != 1: raise KeyError(job_id)

    def create_upload(self, upload_id: str, filename: str, size: int, sha256: str | None) -> None:
        with self.lock:
            self.connection.execute("INSERT INTO uploads (id,filename,size,sha256) VALUES (?,?,?,?)", (upload_id, filename, size, sha256)); self.connection.commit()
    def get_upload(self, upload_id: str) -> dict[str, Any]:
        with self.lock: row = self.connection.execute("SELECT * FROM uploads WHERE id=?", (upload_id,)).fetchone()
        if row is None: raise KeyError(upload_id)
        return {"id": row["id"], "filename": row["filename"], "size": row["size"], "sha256": row["sha256"], "receivedChunks": json.loads(row["chunks_json"])}
    def record_chunk(self, upload_id: str, index: int) -> None:
        upload = self.get_upload(upload_id); chunks = sorted(set(upload["receivedChunks"] + [index]))
        with self.lock: self.connection.execute("UPDATE uploads SET chunks_json=? WHERE id=?", (json.dumps(chunks), upload_id)); self.connection.commit()
    def delete_upload(self, upload_id: str) -> None:
        with self.lock: self.connection.execute("DELETE FROM uploads WHERE id=?", (upload_id,)); self.connection.commit()
