from __future__ import annotations

import json
import re
from typing import Any

_RECORD = re.compile(r"FF Process Output:\s+\d+\s+(\{.*\})")
_FFMPEG_RECORD = re.compile(r"\bframe=\s*(?P<frame>\d+).*?\bfps=\s*(?P<fps>[0-9.]+)")

def parse_progress_line(line: str) -> dict[str, Any] | None:
    match = _RECORD.search(line)
    if not match:
        ffmpeg_match = _FFMPEG_RECORD.search(line)
        if not ffmpeg_match:
            return None
        return {
            "stage": "topaz",
            "processedFrames": int(ffmpeg_match.group("frame")),
            "totalFrames": None,
            "overallProgress": None,
            "fps": float(ffmpeg_match.group("fps")),
            "etaSeconds": None,
            "message": None,
        }
    try: message = json.loads(match.group(1)).get("message", {})
    except json.JSONDecodeError: return None
    if not isinstance(message, dict) or not isinstance(message.get("frame"), int) or not isinstance(message.get("progress"), int): return None
    return {"stage": "topaz", "processedFrames": message["frame"], "totalFrames": None, "overallProgress": max(0, min(100, message["progress"])) / 100, "fps": None, "etaSeconds": None, "message": message.get("message") or None}
