from __future__ import annotations

from collections.abc import Callable
from typing import Any

from .database import Database


class JobRunner:
    """Single-worker FIFO queue; process execution remains injected and Agent-owned."""
    def __init__(
        self,
        database: Database,
        start: Callable[[dict[str, Any]], None],
        cancel_active: Callable[[str], None] | None = None,
    ) -> None:
        self.database, self.start, self.cancel_active, self.active_id = database, start, cancel_active, None

    def start_next(self) -> str | None:
        if self.active_id is not None: return None
        while True:
            job = next((item for item in self.database.list_jobs() if item["status"] == "created"), None)
            if job is None: return None
            self.database.set_status(job["id"], "processing"); self.active_id = job["id"]
            try:
                self.start(job)
                return self.active_id
            except Exception:
                self.database.set_status(job["id"], "failed")
                self.active_id = None

    def finish(self, job_id: str, succeeded: bool) -> None:
        if job_id != self.active_id: raise ValueError("job is not active")
        current = self.database.get_job(job_id)["status"]
        if current == "cancel_requested": status = "cancelled"
        else: status = "completed" if succeeded else "failed"
        self.database.set_status(job_id, status); self.active_id = None

    def cancel(self, job_id: str) -> None:
        job = self.database.get_job(job_id)
        if job["status"] == "created": self.database.set_status(job_id, "cancelled"); return
        if job_id == self.active_id:
            self.database.set_status(job_id, "cancel_requested")
            if self.cancel_active is not None: self.cancel_active(job_id)
            return
        raise ValueError("job cannot be cancelled")

    def recover_after_restart(self) -> list[str]:
        """Fail jobs left in active states because no child process ownership survives a restart."""
        recovered: list[str] = []
        for job in self.database.list_jobs():
            if job["status"] in {"processing", "cancel_requested"}:
                self.database.set_status(job["id"], "failed")
                recovered.append(job["id"])
        return recovered
