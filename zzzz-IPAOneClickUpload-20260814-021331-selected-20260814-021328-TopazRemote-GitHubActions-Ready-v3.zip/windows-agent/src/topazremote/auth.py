from __future__ import annotations

import secrets
from pathlib import Path


class TokenStore:
    def __init__(self, path: Path) -> None:
        self.path = path

    def load_or_create(self) -> str:
        try:
            value = self.path.read_text(encoding="utf-8").strip()
        except FileNotFoundError:
            value = ""
        if value:
            return value
        self.path.parent.mkdir(parents=True, exist_ok=True)
        value = secrets.token_urlsafe(32)
        self.path.write_text(value + "\n", encoding="utf-8")
        return value
