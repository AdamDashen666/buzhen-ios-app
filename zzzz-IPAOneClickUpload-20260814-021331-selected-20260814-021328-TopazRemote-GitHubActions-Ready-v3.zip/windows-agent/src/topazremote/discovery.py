from __future__ import annotations

import re
import subprocess
from collections.abc import Callable
from pathlib import Path
from typing import Any


_MODEL = re.compile(r"tvai_(?P<filter>up|fi)\s*=\s*model=(?P<id>[A-Za-z0-9._-]+)", re.IGNORECASE)


def _default_help_reader(executable: Path) -> str:
    return subprocess.run(
        [str(executable), "-hide_banner", "-h", "filter=tvai_up"],
        cwd=str(executable.parent),
        stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=15,
        check=False,
    ).stdout + "\n" + subprocess.run(
        [str(executable), "-hide_banner", "-h", "filter=tvai_fi"],
        cwd=str(executable.parent),
        stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=15,
        check=False,
    ).stdout


def _filter_support(help_text: str) -> dict[str, Any]:
    support: dict[str, Any] = {}
    if "tvai_up" in help_text:
        support["tvai_up"] = {"scale": {"min": 0, "max": 4, "type": "integer"}}
    if "tvai_fi" in help_text:
        support["tvai_fi"] = {"fps": {"min": 1, "max": 480, "type": "number"}, "slowmo": {"min": 0.1, "max": 16, "type": "number"}}
    return support


def _models_from_logs(logs_root: Path, group: str, filter_name: str, parameters: list[dict[str, Any]]) -> list[dict[str, Any]]:
    if not logs_root.is_dir():
        return []
    ids: set[str] = set()
    try:
        paths = logs_root.rglob("*.tzlog")
        for path in paths:
            try:
                for match in _MODEL.finditer(path.read_text(encoding="utf-8", errors="replace")):
                    if match.group("filter").lower() == filter_name:
                        ids.add(match.group("id"))
            except OSError:
                continue
    except OSError:
        return []
    # Export logs establish a command shape, but Topaz can later remove a model
    # package. Do not advertise it to a client until a local probe verifies it.
    return [{"id": model_id, "displayName": model_id, "available": False, "parameters": parameters, "source": "detected-log"} for model_id in sorted(ids)]


def discover_capabilities(
    executable: Path,
    logs_root: Path | None = None,
    help_reader: Callable[[Path], str] | None = None,
) -> dict[str, Any]:
    """Read local Topaz filter support and observed model IDs without changing Topaz state."""
    reader = help_reader or _default_help_reader
    try:
        help_text = reader(executable)
    except (OSError, subprocess.SubprocessError):
        help_text = ""
    support = _filter_support(help_text)
    logs = logs_root or Path.home() / "AppData/Roaming/Topaz Labs LLC/Topaz Video/logs"
    enhancement_parameters: list[dict[str, Any]] = []
    interpolation_parameters: list[dict[str, Any]] = []
    if "tvai_up" in support:
        scale = support["tvai_up"]["scale"]
        enhancement_parameters.append({"id": "scale", "displayName": "Scale", **scale})
    if "tvai_fi" in support:
        fps = support["tvai_fi"]["fps"]
        interpolation_parameters.append({"id": "fps", "displayName": "Output FPS", **fps})
    return {
        "capabilitySchemaVersion": 1,
        "filterSupport": support,
        "enhancementModels": _models_from_logs(logs, "enhancementModels", "up", enhancement_parameters),
        "interpolationModels": _models_from_logs(logs, "interpolationModels", "fi", interpolation_parameters),
    }
