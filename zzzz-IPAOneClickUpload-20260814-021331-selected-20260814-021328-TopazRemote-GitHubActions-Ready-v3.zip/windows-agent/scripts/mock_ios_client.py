"""Loopback smoke client for the Topaz Remote Agent; never starts Topaz processing."""
from __future__ import annotations

import hashlib
import json
import sys
import tempfile
import threading
from pathlib import Path
from urllib.request import Request, urlopen

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from topazremote.server import create_server


def request(base: str, path: str, token: str | None = None, method: str = "GET", body: bytes | None = None, content_type: str | None = None) -> tuple[int, bytes]:
    headers: dict[str, str] = {}
    if token: headers["Authorization"] = f"Bearer {token}"
    if content_type: headers["Content-Type"] = content_type
    with urlopen(Request(base + path, data=body, headers=headers, method=method)) as response:
        return response.status, response.read()


def main() -> int:
    with tempfile.TemporaryDirectory(prefix="topazremote-smoke-") as temp:
        server = create_server(Path(temp), "127.0.0.1", 0)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        base = f"http://127.0.0.1:{server.server_port}/api/v1"
        try:
            assert request(base, "/health")[0] == 200
            payload = b"topaz remote loopback smoke"
            metadata = json.dumps({"filename": "smoke.mp4", "size": len(payload), "sha256": hashlib.sha256(payload).hexdigest()}).encode()
            status, body = request(base, "/uploads", server.token, "POST", metadata, "application/json")
            assert status == 201
            upload_id = json.loads(body)["id"]
            assert request(base, f"/uploads/{upload_id}/chunks/0", server.token, "PUT", payload, "application/octet-stream")[0] == 204
            status, body = request(base, f"/uploads/{upload_id}/complete", server.token, "POST", b"{}", "application/json")
            assert status == 200 and json.loads(body)["sourceFilename"] == "smoke.mp4"
            job = json.dumps({"sourceFilename": "smoke.mp4", "settings": {"enhancement": {"model": "prob-4", "scale": 1}}}).encode()
            status, body = request(base, "/jobs", server.token, "POST", job, "application/json")
            assert status == 201 and json.loads(body)["status"] == "created"
            print("Topaz Remote loopback smoke passed (health, authenticated upload, completion, job creation).")
            return 0
        finally:
            server.shutdown()
            server.server_close()


if __name__ == "__main__":
    raise SystemExit(main())
