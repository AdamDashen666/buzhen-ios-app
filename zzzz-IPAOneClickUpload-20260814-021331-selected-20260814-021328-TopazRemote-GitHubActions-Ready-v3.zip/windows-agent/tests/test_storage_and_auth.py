from __future__ import annotations

import hashlib
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from topazremote.auth import TokenStore
from topazremote.database import Database
from topazremote.storage import Storage, StorageError


class StorageAndAuthTests(unittest.TestCase):
    def setUp(self) -> None:
        self.tempdir = tempfile.TemporaryDirectory()
        self.root = Path(self.tempdir.name)

    def tearDown(self) -> None:
        self.tempdir.cleanup()

    def test_token_is_created_once_and_reused(self) -> None:
        """Regenerating the token would silently disconnect every paired iOS device."""
        path = self.root / "config" / "token"
        self.assertEqual(TokenStore(path).load_or_create(), TokenStore(path).load_or_create())

    def test_completed_upload_is_atomic_and_hash_checked(self) -> None:
        """Publishing data before all chunks and its digest validate would corrupt a Topaz job source."""
        storage = Storage(self.root)
        storage.write_chunk("upload-1", 0, b"hello ")
        storage.write_chunk("upload-1", 1, b"world")

        output = storage.complete_upload(
            "upload-1", "clip.mp4", 11, hashlib.sha256(b"hello world").hexdigest()
        )

        self.assertEqual(output.read_bytes(), b"hello world")
        self.assertFalse((self.root / "uploads" / "upload-1").exists())

    def test_rejects_traversal_filename(self) -> None:
        """Accepting a parent path would allow an authenticated client to overwrite files outside Agent storage."""
        storage = Storage(self.root)
        storage.write_chunk("upload-2", 0, b"data")

        with self.assertRaises(StorageError):
            storage.complete_upload("upload-2", "..\\outside.mp4", 4, None)

    def test_rejects_upload_with_missing_chunk_index_even_when_size_matches(self) -> None:
        """Accepting a sparse chunk map could publish reordered or truncated video without a supplied hash."""
        storage = Storage(self.root)
        storage.write_chunk("upload-3", 0, b"hello ")
        storage.write_chunk("upload-3", 2, b"world")
        with self.assertRaises(StorageError):
            storage.complete_upload("upload-3", "clip.mp4", 11, None)

    def test_refuses_to_overwrite_existing_source(self) -> None:
        """A second upload named like an active source must not replace media used by an existing job."""
        storage = Storage(self.root); existing = storage.sources / "clip.mp4"; existing.write_bytes(b"original")
        storage.write_chunk("upload-4", 0, b"replacement")
        with self.assertRaises(StorageError): storage.complete_upload("upload-4", "clip.mp4", 11, None)
        self.assertEqual(existing.read_bytes(), b"original")

    def test_jobs_survive_database_reopen(self) -> None:
        """Losing a queued job after an Agent restart would make remote processing unreliable."""
        path = self.root / "db" / "agent.sqlite3"
        database = Database(path)
        job_id = database.create_job("clip.mp4", {"enhancement": {"model": "prob-4"}})
        database.close()

        reopened = Database(path)
        self.assertEqual(reopened.get_job(job_id)["status"], "created")
        self.assertEqual(reopened.get_job(job_id)["sourceFilename"], "clip.mp4")
        reopened.close()


if __name__ == "__main__":
    unittest.main()
