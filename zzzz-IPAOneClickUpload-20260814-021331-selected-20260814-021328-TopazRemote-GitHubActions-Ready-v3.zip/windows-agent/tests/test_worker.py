from __future__ import annotations

import io
import sys
import tempfile
import threading
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from topazremote.database import Database
from topazremote.storage import Storage
from topazremote.topaz_adapter import TopazFfmpegAdapter
from topazremote.worker import TopazProcessWorker


class FakeProcess:
    def __init__(self, output: str = "") -> None:
        self.stdout = io.StringIO(output)
        self.returncode: int | None = None
        self.released = threading.Event()
        self.terminated = False

    def poll(self) -> int | None:
        return self.returncode

    def wait(self) -> int:
        self.released.wait(1)
        return -15 if self.terminated else 0

    def terminate(self) -> None:
        self.terminated = True
        self.returncode = -15
        self.released.set()


class TopazProcessWorkerTests(unittest.TestCase):
    def test_terminates_only_registered_process_and_fails_cancelled_job(self) -> None:
        """The worker must never seek or kill a process by executable name or arbitrary PID."""
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp); database = Database(root / "db.sqlite3"); storage = Storage(root)
            try:
                job_id = database.create_job("clip.mp4", {"enhancement": {"model": "prob-4", "scale": 1}})
                storage.sources.joinpath("clip.mp4").write_bytes(b"source")
                finished = threading.Event(); process = FakeProcess()
                adapter = TopazFfmpegAdapter(Path("C:/Topaz/ffmpeg.exe"), {"enhancementModels": [{"id": "prob-4"}], "interpolationModels": []})
                worker = TopazProcessWorker(database, storage, adapter, lambda _id, _success: finished.set(), popen_factory=lambda *args, **kwargs: process, output_validator=lambda _: True)
                worker.start(database.get_job(job_id))
                self.assertFalse(worker.cancel("unknown-job")); self.assertFalse(process.terminated)
                self.assertTrue(worker.cancel(job_id)); self.assertTrue(process.terminated)
                self.assertTrue(finished.wait(1)); self.assertFalse(worker.is_owned(job_id))
            finally: database.close()

    def test_marks_success_only_when_owned_process_writes_valid_output(self) -> None:
        """A zero exit code without a validated video must not expose a corrupt download as completed."""
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp); database = Database(root / "db.sqlite3"); storage = Storage(root)
            try:
                job_id = database.create_job("clip.mp4", {"enhancement": {"model": "prob-4", "scale": 1}})
                storage.sources.joinpath("clip.mp4").write_bytes(b"source")
                finished: list[tuple[str, bool]] = []; process = FakeProcess(); process.released.set()
                adapter = TopazFfmpegAdapter(Path("C:/Topaz/ffmpeg.exe"), {"enhancementModels": [{"id": "prob-4"}], "interpolationModels": []})
                worker = TopazProcessWorker(database, storage, adapter, lambda identifier, success: finished.append((identifier, success)), popen_factory=lambda *args, **kwargs: process, output_validator=lambda path: path.write_bytes(b"video") is not None)
                worker.start(database.get_job(job_id))
                for _ in range(100):
                    if finished: break
                    threading.Event().wait(0.01)
                self.assertEqual(finished, [(job_id, True)])
                self.assertEqual(database.get_job(job_id)["outputPath"], str(storage.outputs / f"{job_id}.mp4"))
            finally: database.close()

    def test_treats_output_validation_exception_as_failed_export(self) -> None:
        """A broken local probe must fail closed instead of publishing an unchecked output."""
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp); database = Database(root / "db.sqlite3"); storage = Storage(root)
            try:
                job_id = database.create_job("clip.mp4", {"enhancement": {"model": "prob-4", "scale": 1}})
                storage.sources.joinpath("clip.mp4").write_bytes(b"source")
                process = FakeProcess(); process.released.set(); finished: list[bool] = []
                adapter = TopazFfmpegAdapter(Path("C:/Topaz/ffmpeg.exe"), {"enhancementModels": [{"id": "prob-4"}], "interpolationModels": []})
                worker = TopazProcessWorker(database, storage, adapter, lambda _id, success: finished.append(success), popen_factory=lambda *args, **kwargs: process, output_validator=lambda _: (_ for _ in ()).throw(RuntimeError("probe failed")))
                worker.start(database.get_job(job_id))
                for _ in range(100):
                    if finished: break
                    threading.Event().wait(0.01)
                self.assertEqual(finished, [False]); self.assertIsNone(database.get_job(job_id)["outputPath"])
            finally: database.close()

    def test_persists_owned_topaz_failure_reason(self) -> None:
        """A failed export must expose Topaz's own last error instead of a generic failed status."""
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp); database = Database(root / "db.sqlite3"); storage = Storage(root)
            try:
                job_id = database.create_job("clip.mp4", {"enhancement": {"model": "prob-4", "scale": 1}})
                storage.sources.joinpath("clip.mp4").write_bytes(b"source")
                process = FakeProcess("[Parsed_tvai_up] Model not found: prob-4\\n"); process.returncode = -22; process.released.set()
                adapter = TopazFfmpegAdapter(Path("C:/Topaz/ffmpeg.exe"), {"enhancementModels": [{"id": "prob-4"}], "interpolationModels": []})
                finished = threading.Event()
                worker = TopazProcessWorker(database, storage, adapter, lambda _id, _success: finished.set(), popen_factory=lambda *args, **kwargs: process, output_validator=lambda _: False)
                worker.start(database.get_job(job_id)); self.assertTrue(finished.wait(1))
                self.assertIn("Model not found", database.get_job(job_id)["failureReason"])
            finally: database.close()

    def test_persists_structured_topaz_progress_from_owned_process_output(self) -> None:
        """The iOS job list needs observed Topaz progress, not a client-side guessed percentage."""
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp); database = Database(root / "db.sqlite3"); storage = Storage(root)
            try:
                job_id = database.create_job("clip.mp4", {"enhancement": {"model": "prob-4", "scale": 1}})
                storage.sources.joinpath("clip.mp4").write_bytes(b"source")
                output = 'Info FF Process Output: 147 {"message":{"status":"RUNNING","frame":42,"progress":5,"message":""}}\n'
                process = FakeProcess(output); process.released.set(); finished = threading.Event()
                adapter = TopazFfmpegAdapter(Path("C:/Topaz/ffmpeg.exe"), {"enhancementModels": [{"id": "prob-4"}], "interpolationModels": []})
                worker = TopazProcessWorker(database, storage, adapter, lambda _id, _success: finished.set(), popen_factory=lambda *args, **kwargs: process, output_validator=lambda _: True)
                worker.start(database.get_job(job_id))
                self.assertTrue(finished.wait(1))
                self.assertEqual(database.get_job(job_id)["progress"]["processedFrames"], 42)
                self.assertEqual(database.get_job(job_id)["progress"]["overallProgress"], 0.05)
            finally: database.close()


if __name__ == "__main__": unittest.main()
