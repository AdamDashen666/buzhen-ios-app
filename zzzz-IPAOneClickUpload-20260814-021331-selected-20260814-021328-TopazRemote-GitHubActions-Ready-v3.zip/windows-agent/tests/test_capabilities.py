from __future__ import annotations

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from topazremote.capabilities import merge_capabilities


class CapabilityMergeTests(unittest.TestCase):
    def test_uses_fallback_model_when_detection_is_empty(self) -> None:
        """Removing fallback handling would leave the remote UI without a usable model."""
        effective = merge_capabilities(
            {"enhancementModels": [], "interpolationModels": []},
            {"enhancementModels": [{"id": "proteus-4", "displayName": "Proteus", "parameters": []}]},
            {},
        )

        self.assertEqual(effective["enhancementModels"][0]["id"], "proteus-4")
        self.assertEqual(effective["enhancementModels"][0]["source"], "fallback")

    def test_prefers_detected_definition_over_fallback(self) -> None:
        """Replacing a detected model with stale fallback parameters would run the wrong command."""
        effective = merge_capabilities(
            {
                "enhancementModels": [
                    {"id": "proteus-4", "displayName": "Proteus 4", "parameters": [{"id": "detail"}]}
                ],
                "interpolationModels": [],
            },
            {
                "enhancementModels": [
                    {"id": "proteus-4", "displayName": "Old Proteus", "parameters": []}
                ],
                "interpolationModels": [],
            },
            {},
        )

        model = effective["enhancementModels"][0]
        self.assertEqual(model["displayName"], "Proteus 4")
        self.assertEqual(model["parameters"], [{"id": "detail"}])
        self.assertEqual(model["source"], "detected")

    def test_override_replaces_detected_parameter_and_can_disable_model(self) -> None:
        """Ignoring a local override would expose a parameter that this Topaz install cannot use."""
        effective = merge_capabilities(
            {
                "enhancementModels": [
                    {
                        "id": "proteus-4",
                        "displayName": "Proteus 4",
                        "parameters": [{"id": "detail", "max": 1}],
                    },
                    {"id": "unstable-1", "displayName": "Unstable", "parameters": []},
                ],
                "interpolationModels": [],
            },
            {"enhancementModels": [], "interpolationModels": []},
            {
                "enhancementModels": {
                    "proteus-4": {"parameters": {"detail": {"max": 2}}},
                    "unstable-1": {"available": False},
                }
            },
        )

        self.assertEqual([model["id"] for model in effective["enhancementModels"]], ["proteus-4"])
        model = effective["enhancementModels"][0]
        self.assertEqual(model["parameters"], [{"id": "detail", "max": 2}])
        self.assertEqual(model["source"], "override")

    def test_override_can_enable_a_model_after_a_local_operator_has_verified_it(self) -> None:
        """Log-only discovery stays fail-closed until an explicit local verification override is recorded."""
        effective = merge_capabilities(
            {"enhancementModels": [{"id": "prob-4", "available": False, "parameters": []}], "interpolationModels": []},
            {"enhancementModels": [], "interpolationModels": []},
            {"enhancementModels": {"prob-4": {"available": True}}},
        )
        self.assertTrue(effective["enhancementModels"][0]["available"])


if __name__ == "__main__":
    unittest.main()
