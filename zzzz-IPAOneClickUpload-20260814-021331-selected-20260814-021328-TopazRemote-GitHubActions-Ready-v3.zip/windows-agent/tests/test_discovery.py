from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from topazremote.discovery import discover_capabilities


class DiscoveryTests(unittest.TestCase):
    def test_marks_models_seen_only_in_local_logs_as_unavailable_until_probed(self) -> None:
        """A historical export proves syntax, not that its model package is installed today."""
        with tempfile.TemporaryDirectory() as temp:
            executable = Path(temp) / "ffmpeg.exe"; executable.write_bytes(b"placeholder")
            log = Path(temp) / "recent.tzlog"
            log.write_text('Info CMD: ffmpeg -vf tvai_fi=model=apo-8:fps=60:download=0\n')
            detected = discover_capabilities(
                executable,
                logs_root=Path(temp),
                help_reader=lambda _: """Filter tvai_fi\ntvai_fi AVOptions:\n   fps <video_rate> output's frame rate\n   slowmo <double> (from 0.1 to 16)\n""",
            )
        interpolation = detected["interpolationModels"]
        self.assertEqual(interpolation[0]["id"], "apo-8")
        self.assertEqual(interpolation[0]["source"], "detected-log")
        self.assertFalse(interpolation[0]["available"])
        self.assertEqual(interpolation[0]["parameters"][0]["id"], "fps")
        self.assertEqual(interpolation[0]["parameters"][0]["max"], 480)

    def test_returns_filter_contract_even_when_no_local_model_is_observed(self) -> None:
        """Filter discovery must remain useful without guessing a model ID or causing a model download."""
        with tempfile.TemporaryDirectory() as temp:
            executable = Path(temp) / "ffmpeg.exe"; executable.write_bytes(b"placeholder")
            detected = discover_capabilities(executable, logs_root=Path(temp), help_reader=lambda _: "Filter tvai_up\nscale <int> (from 0 to 4)\n")
        self.assertEqual(detected["filterSupport"]["tvai_up"]["scale"]["max"], 4)
        self.assertEqual(detected["enhancementModels"], [])


if __name__ == "__main__":
    unittest.main()
