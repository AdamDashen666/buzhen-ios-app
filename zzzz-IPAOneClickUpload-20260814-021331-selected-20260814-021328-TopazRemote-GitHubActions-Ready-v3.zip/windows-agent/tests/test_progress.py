from __future__ import annotations

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from topazremote.progress import parse_progress_line

class ProgressTests(unittest.TestCase):
    def test_parses_real_topaz_structured_progress_without_inventing_fps(self) -> None:
        """Treating unavailable metrics as zero would show users a false Topaz speed or ETA."""
        line = 'Info FF Process Output: 147 {"timestamp":"2026-08-12 09:19:13,180","message":{"status":"RUNNING","frame":42,"progress":5,"message":""}}'
        value = parse_progress_line(line)
        self.assertEqual(value["processedFrames"], 42); self.assertEqual(value["overallProgress"], 0.05); self.assertIsNone(value["fps"])

    def test_parses_ffmpeg_frame_and_speed_when_structured_topaz_messages_are_unavailable(self) -> None:
        """Direct bundled FFmpeg exports still need visible, persisted progress."""
        value = parse_progress_line("frame=  120 fps=24.5 q=23.0 size=10kB time=00:00:05.00 speed=1.02x")
        self.assertEqual(value["processedFrames"], 120)
        self.assertEqual(value["fps"], 24.5)
        self.assertIsNone(value["overallProgress"])

if __name__ == "__main__": unittest.main()
