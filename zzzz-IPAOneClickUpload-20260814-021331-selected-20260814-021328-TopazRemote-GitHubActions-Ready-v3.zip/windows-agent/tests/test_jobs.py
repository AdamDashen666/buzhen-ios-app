from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from topazremote.database import Database
from topazremote.jobs import JobRunner


class JobsTests(unittest.TestCase):
    def test_runs_created_jobs_fifo_and_never_starts_two(self) -> None:
        """Starting a second Topaz job would contend for the same GPU and violate queue ordering."""
        with tempfile.TemporaryDirectory() as temp:
            db = Database(Path(temp) / "agent.sqlite3"); started: list[str] = []
            first = db.create_job("first.mp4", {}); second = db.create_job("second.mp4", {})
            runner = JobRunner(db, lambda job: started.append(job["id"]))
            self.assertEqual(runner.start_next(), first); self.assertIsNone(runner.start_next())
            self.assertEqual(started, [first]); runner.finish(first, True); self.assertEqual(runner.start_next(), second); db.close()
    def test_cancels_queued_job_without_calling_worker(self) -> None:
        """A queued cancellation must not terminate an unrelated or future Topaz process."""
        with tempfile.TemporaryDirectory() as temp:
            db = Database(Path(temp) / "agent.sqlite3"); called: list[str] = []
            job = db.create_job("clip.mp4", {}); runner = JobRunner(db, lambda value: called.append(value["id"]))
            runner.cancel(job)
            self.assertEqual(db.get_job(job)["status"], "cancelled"); self.assertIsNone(runner.start_next()); self.assertEqual(called, []); db.close()

    def test_cancels_only_the_active_agent_owned_process(self) -> None:
        """Cancellation must target the process object registered for this job, never a global Topaz process."""
        with tempfile.TemporaryDirectory() as temp:
            db = Database(Path(temp) / "agent.sqlite3"); cancelled: list[str] = []
            try:
                first = db.create_job("first.mp4", {}); second = db.create_job("second.mp4", {})
                runner = JobRunner(db, lambda job: None, cancel_active=lambda job_id: cancelled.append(job_id))
                runner.start_next(); runner.cancel(first)
                self.assertEqual(cancelled, [first]); self.assertEqual(db.get_job(first)["status"], "cancel_requested")
                self.assertEqual(db.get_job(second)["status"], "created")
            finally: db.close()

    def test_marks_cancel_requested_before_terminating_child(self) -> None:
        """A synchronous child-exit callback must see cancellation, not misclassify the job as failed."""
        with tempfile.TemporaryDirectory() as temp:
            db = Database(Path(temp) / "agent.sqlite3")
            try:
                job = db.create_job("clip.mp4", {})
                runner: JobRunner
                def cancel_active(job_id: str) -> None:
                    runner.finish(job_id, False)
                runner = JobRunner(db, lambda value: None, cancel_active=cancel_active)
                runner.start_next(); runner.cancel(job)
                self.assertEqual(db.get_job(job)["status"], "cancelled")
            finally: db.close()

    def test_recovers_interrupted_processing_job_after_restart(self) -> None:
        """An Agent restart cannot safely resume an untracked child process, so it must mark the job failed."""
        with tempfile.TemporaryDirectory() as temp:
            db = Database(Path(temp) / "agent.sqlite3"); job = db.create_job("clip.mp4", {})
            try:
                db.set_status(job, "processing")
                runner = JobRunner(db, lambda value: None)
                self.assertEqual(runner.recover_after_restart(), [job])
                self.assertEqual(db.get_job(job)["status"], "failed")
            finally: db.close()

    def test_completion_callback_can_dispatch_next_fifo_job(self) -> None:
        """A finished export must immediately advance the next queued job instead of leaving it stranded."""
        with tempfile.TemporaryDirectory() as temp:
            db = Database(Path(temp) / "agent.sqlite3"); started: list[str] = []
            try:
                first = db.create_job("first.mp4", {}); second = db.create_job("second.mp4", {})
                runner: JobRunner
                def start(job: dict[str, object]) -> None:
                    started.append(str(job["id"])); runner.finish(str(job["id"]), True); runner.start_next()
                runner = JobRunner(db, start)
                runner.start_next()
                self.assertEqual(started, [first, second])
                self.assertEqual(db.get_job(second)["status"], "completed")
            finally: db.close()

    def test_start_failure_marks_job_failed_and_releases_queue(self) -> None:
        """A rejected Topaz command must not leave the only worker permanently occupied."""
        with tempfile.TemporaryDirectory() as temp:
            db = Database(Path(temp) / "agent.sqlite3")
            try:
                job = db.create_job("clip.mp4", {})
                runner = JobRunner(db, lambda value: (_ for _ in ()).throw(RuntimeError("Topaz unavailable")))
                self.assertIsNone(runner.start_next())
                self.assertEqual(db.get_job(job)["status"], "failed")
                self.assertIsNone(runner.active_id)
            finally: db.close()

    def test_start_failure_advances_to_next_queued_job(self) -> None:
        """One invalid export cannot strand later valid FIFO work behind it."""
        with tempfile.TemporaryDirectory() as temp:
            db = Database(Path(temp) / "agent.sqlite3"); started: list[str] = []
            try:
                first = db.create_job("bad.mp4", {}); second = db.create_job("good.mp4", {})
                def start(job: dict[str, object]) -> None:
                    if job["id"] == first: raise RuntimeError("invalid Topaz settings")
                    started.append(str(job["id"]))
                runner = JobRunner(db, start)
                self.assertEqual(runner.start_next(), second)
                self.assertEqual(db.get_job(first)["status"], "failed")
                self.assertEqual(started, [second])
            finally: db.close()

if __name__ == "__main__": unittest.main()
