from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from topazremote.main import default_topaz_ffmpeg


class MainTests(unittest.TestCase):
    def test_default_topaz_ffmpeg_uses_an_installed_non_system_drive(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            c_program_files = root / "C" / "Program Files"
            d_program_files = root / "D" / "Program Files"
            installed = d_program_files / "Topaz Labs LLC" / "Topaz Video" / "ffmpeg.exe"
            installed.parent.mkdir(parents=True)
            installed.write_bytes(b"ffmpeg")

            self.assertEqual(default_topaz_ffmpeg((c_program_files, d_program_files)), installed)
