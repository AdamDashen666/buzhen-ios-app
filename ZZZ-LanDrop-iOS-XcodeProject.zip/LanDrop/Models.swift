import Foundation

enum PeerPlatform: String, Codable, Equatable {
    case ios
    case windows

    var displayName: String {
        switch self {
        case .ios:
            return "iOS"
        case .windows:
            return "Windows"
        }
    }
}

struct DiscoveredDevice: Identifiable, Equatable {
    let id: String
    let name: String
    let platform: PeerPlatform
    let host: String
    let port: Int
}

struct PairedDevice: Identifiable, Codable, Equatable {
    var id: String { pairId }

    let pairId: String
    let token: String
    let deviceId: String
    let name: String
    let platform: PeerPlatform
    let createdAt: Date
}

struct TransferSnapshot: Identifiable, Equatable {
    enum Direction: Equatable {
        case send
        case receive
    }

    enum Status: Equatable {
        case offered
        case transferring
        case complete
        case failed(String)
    }

    let id: String
    let fileName: String
    let direction: Direction
    let status: Status
    let transferredBytes: Int64
    let totalBytes: Int64
    let speedBytesPerSecond: Int64

    var progress: Double {
        guard totalBytes > 0 else { return 0 }
        return min(1, Double(transferredBytes) / Double(totalBytes))
    }
}
