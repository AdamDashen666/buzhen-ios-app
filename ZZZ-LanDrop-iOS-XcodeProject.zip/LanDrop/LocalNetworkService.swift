import Foundation
import Network
import UIKit

@MainActor
final class LocalNetworkService: NSObject, ObservableObject {
    @Published private(set) var discoveredDevices: [DiscoveredDevice] = []

    var onPairedDevice: ((PairedDevice) -> Void)?
    var onTransferUpdated: ((TransferSnapshot) -> Void)?

    private let serviceType = "_landrop._tcp."
    private let listenerQueue = DispatchQueue(label: "LanDrop.LocalHTTP")
    private let deviceId: String
    private let deviceName: String
    private let receiveDirectory: URL

    private var browser: NetServiceBrowser?
    private var listener: NWListener?
    private var publisher: NetService?
    private var resolvingServices: [String: NetService] = [:]
    private var discoveredById: [String: DiscoveredDevice] = [:]
    private var activeConnections: [UUID: HTTPConnectionHandler] = [:]
    private var pendingTransfers: [String: TransferOffer] = [:]
    private var pairings: [PairedDevice] = []
    private var pairingSession: PairingSession?

    init(deviceId: String, deviceName: String, receiveDirectory: URL) {
        self.deviceId = deviceId
        self.deviceName = deviceName
        self.receiveDirectory = receiveDirectory
        super.init()
    }

    func start() {
        startListener()
        startBrowser()
    }

    func updatePairings(_ pairings: [PairedDevice]) {
        self.pairings = pairings
    }

    func setPairingSession(_ session: PairingSession?) {
        pairingSession = session
        refreshTXTRecord()
    }

    func pair(with device: DiscoveredDevice, code: String) async throws -> PairedDevice {
        let response: PairResponse = try await postJSON(
            path: "/v1/pair",
            to: device,
            body: [
                "code": code,
                "nowMs": Int(Date().timeIntervalSince1970 * 1000),
                "remoteDevice": helloPayload(pairingAvailable: false)
            ],
            bearerToken: nil
        )

        return PairedDevice(
            pairId: response.pairId,
            token: response.token,
            deviceId: device.id,
            name: device.name,
            platform: device.platform,
            createdAt: Date()
        )
    }

    func sendFile(_ fileURL: URL, to pair: PairedDevice) async throws {
        guard let device = discoveredById[pair.deviceId] else {
            throw LanDropNetworkError.peerOffline
        }

        let fileSize = try fileURL.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0
        guard fileSize > 0 else {
            throw LanDropNetworkError.emptyFile
        }

        let transferId = "transfer_\(UUID().uuidString.replacingOccurrences(of: "-", with: ""))"
        let fileName = fileURL.lastPathComponent
        emitTransfer(
            TransferSnapshot(
                id: transferId,
                fileName: fileName,
                direction: .send,
                status: .offered,
                transferredBytes: 0,
                totalBytes: Int64(fileSize),
                speedBytesPerSecond: 0
            )
        )

        let _: EmptyResponse = try await postJSON(
            path: "/v1/transfers/offer",
            to: device,
            body: [
                "transferId": transferId,
                "fileName": fileName,
                "fileSize": fileSize,
                "mimeType": "application/octet-stream",
                "pairId": pair.pairId
            ],
            bearerToken: pair.token
        )

        let delegate = UploadProgressDelegate(totalBytes: Int64(fileSize)) { [weak self] sent, speed in
            Task { @MainActor in
                self?.emitTransfer(
                    TransferSnapshot(
                        id: transferId,
                        fileName: fileName,
                        direction: .send,
                        status: .transferring,
                        transferredBytes: sent,
                        totalBytes: Int64(fileSize),
                        speedBytesPerSecond: speed
                    )
                )
            }
        }
        let session = URLSession(configuration: .ephemeral, delegate: delegate, delegateQueue: nil)
        defer {
            session.invalidateAndCancel()
        }

        var request = try makeRequest(path: "/v1/transfers/\(transferId)/bytes", device: device)
        request.httpMethod = "PUT"
        request.setValue("Bearer \(pair.token)", forHTTPHeaderField: "Authorization")
        request.setValue("application/octet-stream", forHTTPHeaderField: "Content-Type")
        request.setValue(String(fileSize), forHTTPHeaderField: "Content-Length")

        let (_, response) = try await session.upload(for: request, fromFile: fileURL)
        guard (response as? HTTPURLResponse)?.statusCode == 200 else {
            throw LanDropNetworkError.transferRejected
        }

        emitTransfer(
            TransferSnapshot(
                id: transferId,
                fileName: fileName,
                direction: .send,
                status: .complete,
                transferredBytes: Int64(fileSize),
                totalBytes: Int64(fileSize),
                speedBytesPerSecond: 0
            )
        )
    }

    private func startListener() {
        do {
            try FileManager.default.createDirectory(
                at: receiveDirectory,
                withIntermediateDirectories: true
            )
            let listener = try NWListener(using: .tcp)
            listener.newConnectionHandler = { [weak self] connection in
                guard let self else { return }
                let handler = HTTPConnectionHandler(connection: connection, owner: self)
                handler.onComplete = { [weak self] id in
                    Task { @MainActor in
                        self?.activeConnections.removeValue(forKey: id)
                    }
                }
                Task { @MainActor in
                    self.activeConnections[handler.id] = handler
                }
                handler.start(on: self.listenerQueue)
            }
            listener.stateUpdateHandler = { [weak self] state in
                guard case .ready = state, let port = listener.port else { return }
                Task { @MainActor in
                    self?.publishService(port: Int(port.rawValue))
                }
            }
            listener.start(queue: listenerQueue)
            self.listener = listener
        } catch {
            print("LanDrop listener failed: \(error)")
        }
    }

    private func publishService(port: Int) {
        publisher?.stop()
        let service = NetService(
            domain: "local.",
            type: serviceType,
            name: deviceName,
            port: Int32(port)
        )
        service.includesPeerToPeer = false
        service.delegate = self
        service.setTXTRecord(Self.makeTXTRecord(
            deviceId: deviceId,
            deviceName: deviceName,
            pairingAvailable: pairingSession != nil
        ))
        service.publish()
        publisher = service
    }

    private func refreshTXTRecord() {
        publisher?.setTXTRecord(Self.makeTXTRecord(
            deviceId: deviceId,
            deviceName: deviceName,
            pairingAvailable: pairingSession != nil
        ))
    }

    private func startBrowser() {
        let browser = NetServiceBrowser()
        browser.includesPeerToPeer = false
        browser.delegate = self
        browser.searchForServices(ofType: serviceType, inDomain: "local.")
        self.browser = browser
    }

    private func addResolvedService(_ service: NetService) {
        guard let host = service.hostName, service.port > 0 else { return }
        let txt = NetService.dictionary(fromTXTRecord: service.txtRecordData() ?? Data())
        let remoteDeviceId = Self.txtString(txt, "deviceId") ?? service.name
        guard remoteDeviceId != deviceId else { return }
        let platform = PeerPlatform(rawValue: Self.txtString(txt, "platform") ?? "") ?? .windows
        let name = Self.txtString(txt, "deviceName") ?? service.name

        let device = DiscoveredDevice(
            id: remoteDeviceId,
            name: name,
            platform: platform,
            host: host.trimmingCharacters(in: CharacterSet(charactersIn: ".")),
            port: service.port
        )
        discoveredById[device.id] = device
        discoveredDevices = discoveredById.values.sorted { $0.name < $1.name }
    }

    private func removeService(_ service: NetService) {
        let txt = NetService.dictionary(fromTXTRecord: service.txtRecordData() ?? Data())
        let remoteDeviceId = Self.txtString(txt, "deviceId") ?? service.name
        discoveredById.removeValue(forKey: remoteDeviceId)
        discoveredDevices = discoveredById.values.sorted { $0.name < $1.name }
    }

    private func handleBufferedRequest(_ request: HTTPRequest) -> HTTPResponse {
        switch (request.method, request.path) {
        case ("GET", "/v1/hello"):
            return .json(status: 200, body: helloPayload(pairingAvailable: pairingSession != nil))
        case ("POST", "/v1/pair"):
            return handlePair(request)
        case ("POST", "/v1/transfers/offer"):
            return handleTransferOffer(request)
        default:
            return .json(status: 404, body: ["error": "not_found"])
        }
    }

    private func prepareIncomingTransfer(
        transferId: String,
        authorization: String?
    ) -> Result<IncomingTransferPlan, HTTPResponse> {
        guard let offer = pendingTransfers[transferId] else {
            return .failure(.json(status: 404, body: ["error": "unknown_transfer"]))
        }
        guard pairings.contains(where: { $0.pairId == offer.pairId && bearerToken(authorization) == $0.token }) else {
            return .failure(.json(status: 401, body: ["error": "invalid_pair_token"]))
        }

        do {
            let fileURL = try uniqueReceiveURL(fileName: offer.fileName)
            return .success(IncomingTransferPlan(offer: offer, fileURL: fileURL))
        } catch {
            return .failure(.json(status: 500, body: ["error": "file_prepare_failed"]))
        }
    }

    private func incomingTransferDidProgress(
        plan: IncomingTransferPlan,
        transferredBytes: Int64,
        speedBytesPerSecond: Int64,
        status: TransferSnapshot.Status
    ) {
        emitTransfer(
            TransferSnapshot(
                id: plan.offer.transferId,
                fileName: plan.offer.fileName,
                direction: .receive,
                status: status,
                transferredBytes: transferredBytes,
                totalBytes: Int64(plan.offer.fileSize),
                speedBytesPerSecond: speedBytesPerSecond
            )
        )
        if status == .complete || status == .failed("failed") {
            pendingTransfers.removeValue(forKey: plan.offer.transferId)
        }
    }

    private func handlePair(_ request: HTTPRequest) -> HTTPResponse {
        guard let body = try? JSONDecoder().decode(PairRequest.self, from: request.body) else {
            return .json(status: 400, body: ["error": "invalid_json"])
        }
        guard let pairingSession, pairingSession.accepts(body.code) else {
            return .json(status: 401, body: ["error": "invalid_pairing_code"])
        }

        let pair = PairedDevice(
            pairId: "pair_\(UUID().uuidString.replacingOccurrences(of: "-", with: ""))",
            token: Self.randomToken(),
            deviceId: body.remoteDevice.deviceId,
            name: body.remoteDevice.deviceName,
            platform: body.remoteDevice.platform,
            createdAt: Date()
        )
        self.pairingSession = nil
        refreshTXTRecord()
        onPairedDevice?(pair)
        return .json(status: 200, body: ["pairId": pair.pairId, "token": pair.token])
    }

    private func handleTransferOffer(_ request: HTTPRequest) -> HTTPResponse {
        guard let offer = try? JSONDecoder().decode(TransferOffer.self, from: request.body) else {
            return .json(status: 400, body: ["error": "invalid_json"])
        }
        guard pairings.contains(where: { $0.pairId == offer.pairId && bearerToken(request.headers["authorization"]) == $0.token }) else {
            return .json(status: 401, body: ["error": "invalid_pair_token"])
        }

        pendingTransfers[offer.transferId] = offer
        emitTransfer(
            TransferSnapshot(
                id: offer.transferId,
                fileName: offer.fileName,
                direction: .receive,
                status: .offered,
                transferredBytes: 0,
                totalBytes: Int64(offer.fileSize),
                speedBytesPerSecond: 0
            )
        )
        return .json(status: 202, body: ["transferId": offer.transferId, "status": "accepted"])
    }

    private func postJSON<T: Decodable>(
        path: String,
        to device: DiscoveredDevice,
        body: [String: Any],
        bearerToken: String?
    ) async throws -> T {
        var request = try makeRequest(path: path, device: device)
        request.httpMethod = "POST"
        request.setValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")
        if let bearerToken {
            request.setValue("Bearer \(bearerToken)", forHTTPHeaderField: "Authorization")
        }
        request.httpBody = try JSONSerialization.data(withJSONObject: body)

        let (data, response) = try await URLSession.shared.data(for: request)
        guard let httpResponse = response as? HTTPURLResponse, (200..<300).contains(httpResponse.statusCode) else {
            throw LanDropNetworkError.requestRejected
        }
        if T.self == EmptyResponse.self {
            return EmptyResponse() as! T
        }
        return try JSONDecoder().decode(T.self, from: data)
    }

    private func makeRequest(path: String, device: DiscoveredDevice) throws -> URLRequest {
        var components = URLComponents()
        components.scheme = "http"
        components.host = device.host
        components.port = device.port
        components.path = path
        guard let url = components.url else {
            throw LanDropNetworkError.invalidURL
        }
        var request = URLRequest(url: url)
        request.timeoutInterval = 30
        request.setValue("close", forHTTPHeaderField: "Connection")
        return request
    }

    private func helloPayload(pairingAvailable: Bool) -> [String: Any] {
        [
            "deviceId": deviceId,
            "deviceName": deviceName,
            "platform": "ios",
            "protocolVersion": 1,
            "pairingAvailable": pairingAvailable
        ]
    }

    private func uniqueReceiveURL(fileName: String) throws -> URL {
        let safeName = URL(fileURLWithPath: fileName).lastPathComponent
        let ext = URL(fileURLWithPath: safeName).pathExtension
        let stem = ext.isEmpty ? safeName : String(safeName.dropLast(ext.count + 1))
        for index in 0..<1000 {
            let candidateName = index == 0 ? safeName : "\(stem) (\(index)).\(ext)"
            let candidate = receiveDirectory.appendingPathComponent(candidateName)
            if !FileManager.default.fileExists(atPath: candidate.path) {
                return candidate
            }
        }
        throw LanDropNetworkError.fileNameUnavailable
    }

    private func emitTransfer(_ snapshot: TransferSnapshot) {
        onTransferUpdated?(snapshot)
    }

    private static func makeTXTRecord(
        deviceId: String,
        deviceName: String,
        pairingAvailable: Bool
    ) -> Data {
        NetService.data(fromTXTRecord: [
            "deviceId": Data(deviceId.utf8),
            "deviceName": Data(deviceName.utf8),
            "platform": Data("ios".utf8),
            "protocolVersion": Data("1".utf8),
            "pairingAvailable": Data((pairingAvailable ? "true" : "false").utf8)
        ])
    }

    private static func txtString(_ txt: [String: Data], _ key: String) -> String? {
        txt[key].flatMap { String(data: $0, encoding: .utf8) }
    }

    private static func randomToken() -> String {
        UUID().uuidString.replacingOccurrences(of: "-", with: "")
            + UUID().uuidString.replacingOccurrences(of: "-", with: "")
    }
}

extension LocalNetworkService: NetServiceBrowserDelegate, NetServiceDelegate {
    nonisolated func netServiceBrowser(
        _ browser: NetServiceBrowser,
        didFind service: NetService,
        moreComing: Bool
    ) {
        Task { @MainActor in
            let key = "\(service.name).\(service.type).\(service.domain)"
            resolvingServices[key] = service
            service.delegate = self
            service.resolve(withTimeout: 5)
        }
    }

    nonisolated func netServiceBrowser(
        _ browser: NetServiceBrowser,
        didRemove service: NetService,
        moreComing: Bool
    ) {
        Task { @MainActor in
            removeService(service)
        }
    }

    nonisolated func netServiceDidResolveAddress(_ sender: NetService) {
        Task { @MainActor in
            addResolvedService(sender)
        }
    }
}

private final class HTTPConnectionHandler {
    let id = UUID()
    var onComplete: ((UUID) -> Void)?

    private weak var owner: LocalNetworkService?
    private let connection: NWConnection
    private var buffer = Data()
    private var requestHead: HTTPRequestHead?
    private var incomingPlan: IncomingTransferPlan?
    private var fileHandle: FileHandle?
    private var transferredBytes: Int64 = 0
    private var stats: TransferStatsWindow?
    private var expectedBodyBytes = 0
    private var lastProgressAt = Date.distantPast

    init(connection: NWConnection, owner: LocalNetworkService) {
        self.connection = connection
        self.owner = owner
    }

    func start(on queue: DispatchQueue) {
        connection.stateUpdateHandler = { [weak self] state in
            if case .cancelled = state {
                self?.finish()
            }
        }
        connection.start(queue: queue)
        receive()
    }

    private func receive() {
        connection.receive(minimumIncompleteLength: 1, maximumLength: 64 * 1024) { [weak self] data, _, isComplete, error in
            guard let self else { return }
            if let data, !data.isEmpty {
                self.buffer.append(data)
                self.processBuffer()
            }
            if isComplete || error != nil {
                self.finish()
                return
            }
            self.receive()
        }
    }

    private func processBuffer() {
        if incomingPlan != nil {
            writeIncomingBytesIfPossible()
            return
        }

        if requestHead == nil {
            guard let range = buffer.range(of: Data("\r\n\r\n".utf8)) else { return }
            let headerData = buffer[..<range.lowerBound]
            let bodyStart = range.upperBound
            guard let head = HTTPRequestHead(data: Data(headerData)) else {
                send(.json(status: 400, body: ["error": "bad_request"]))
                return
            }
            requestHead = head
            expectedBodyBytes = Int(head.headers["content-length"] ?? "0") ?? 0
            buffer.removeSubrange(..<bodyStart)

            if head.method == "PUT", let transferId = head.transferBytesId {
                prepareIncomingBytes(transferId: transferId, head: head)
                return
            }
        }

        guard let head = requestHead else { return }
        if head.transferBytesId != nil {
            return
        }
        if buffer.count >= expectedBodyBytes {
            let body = Data(buffer.prefix(expectedBodyBytes))
            let request = HTTPRequest(method: head.method, path: head.path, headers: head.headers, body: body)
            Task { @MainActor [weak self] in
                guard let self, let owner = self.owner else { return }
                self.send(owner.handleBufferedRequest(request))
            }
        }
    }

    private func prepareIncomingBytes(transferId: String, head: HTTPRequestHead) {
        guard expectedBodyBytes > 0 else {
            send(.json(status: 411, body: ["error": "content_length_required"]))
            return
        }

        Task { @MainActor [weak self] in
            guard let self, let owner = self.owner else { return }
            switch owner.prepareIncomingTransfer(
                transferId: transferId,
                authorization: head.headers["authorization"]
            ) {
            case .success(let plan):
                self.incomingPlan = plan
                self.stats = TransferStatsWindow(totalBytes: Int64(plan.offer.fileSize))
                FileManager.default.createFile(atPath: plan.fileURL.path, contents: nil)
                guard let fileHandle = try? FileHandle(forWritingTo: plan.fileURL) else {
                    self.send(.json(status: 500, body: ["error": "file_open_failed"]))
                    return
                }
                self.fileHandle = fileHandle
                self.writeIncomingBytesIfPossible()
            case .failure(let response):
                self.send(response)
            }
        }
    }

    private func writeIncomingBytesIfPossible() {
        guard let plan = incomingPlan, let fileHandle else { return }
        while !buffer.isEmpty {
            let remaining = expectedBodyBytes - Int(transferredBytes)
            guard remaining > 0 else { break }
            let chunkSize = min(buffer.count, remaining)
            let chunk = Data(buffer.prefix(chunkSize))
            buffer.removeSubrange(..<chunkSize)
            fileHandle.write(chunk)
            transferredBytes += Int64(chunk.count)
            emitIncomingProgress(plan: plan, status: .transferring)
        }

        if Int(transferredBytes) == expectedBodyBytes {
            try? fileHandle.close()
            emitIncomingProgress(plan: plan, status: .complete, force: true)
            send(.json(status: 200, body: ["transferId": plan.offer.transferId, "status": "complete"]))
        }
    }

    private func emitIncomingProgress(
        plan: IncomingTransferPlan,
        status: TransferSnapshot.Status,
        force: Bool = false
    ) {
        let now = Date()
        stats?.addSample(date: now, bytes: transferredBytes)
        if !force && now.timeIntervalSince(lastProgressAt) < 0.18 {
            return
        }
        lastProgressAt = now
        let speed = stats?.speedBytesPerSecond() ?? 0
        Task { @MainActor [weak self] in
            self?.owner?.incomingTransferDidProgress(
                plan: plan,
                transferredBytes: self?.transferredBytes ?? 0,
                speedBytesPerSecond: speed,
                status: status
            )
        }
    }

    private func send(_ response: HTTPResponse) {
        let body = response.body
        var head = "HTTP/1.1 \(response.status) \(response.reason)\r\n"
        head += "Content-Type: application/json; charset=utf-8\r\n"
        head += "Content-Length: \(body.count)\r\n"
        head += "Connection: close\r\n\r\n"
        var data = Data(head.utf8)
        data.append(body)
        connection.send(content: data, completion: .contentProcessed { [weak self] _ in
            self?.connection.cancel()
            self?.finish()
        })
    }

    private func finish() {
        onComplete?(id)
    }
}

private struct HTTPRequestHead {
    let method: String
    let path: String
    let headers: [String: String]

    var transferBytesId: String? {
        let prefix = "/v1/transfers/"
        let suffix = "/bytes"
        guard path.hasPrefix(prefix), path.hasSuffix(suffix) else { return nil }
        return String(path.dropFirst(prefix.count).dropLast(suffix.count))
    }

    init?(data: Data) {
        guard let text = String(data: data, encoding: .utf8) else { return nil }
        let lines = text.components(separatedBy: "\r\n")
        guard let requestLine = lines.first else { return nil }
        let parts = requestLine.split(separator: " ")
        guard parts.count >= 2 else { return nil }
        method = String(parts[0])
        path = String(parts[1])
        var parsedHeaders: [String: String] = [:]
        for line in lines.dropFirst() {
            guard let separator = line.firstIndex(of: ":") else { continue }
            let name = line[..<separator].trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
            let value = line[line.index(after: separator)...].trimmingCharacters(in: .whitespacesAndNewlines)
            parsedHeaders[name] = value
        }
        headers = parsedHeaders
    }
}

private struct HTTPRequest {
    let method: String
    let path: String
    let headers: [String: String]
    let body: Data
}

private struct HTTPResponse {
    let status: Int
    let body: Data

    var reason: String {
        switch status {
        case 200:
            return "OK"
        case 202:
            return "Accepted"
        case 400:
            return "Bad Request"
        case 401:
            return "Unauthorized"
        case 404:
            return "Not Found"
        case 411:
            return "Length Required"
        default:
            return "Error"
        }
    }

    static func json(status: Int, body: [String: Any]) -> HTTPResponse {
        let data = (try? JSONSerialization.data(withJSONObject: body)) ?? Data("{}".utf8)
        return HTTPResponse(status: status, body: data)
    }
}

private struct HelloPayload: Codable {
    let deviceId: String
    let deviceName: String
    let platform: PeerPlatform
    let protocolVersion: Int
    let pairingAvailable: Bool
}

private struct PairRequest: Decodable {
    let code: String
    let remoteDevice: HelloPayload
}

private struct PairResponse: Decodable {
    let pairId: String
    let token: String
}

private struct EmptyResponse: Decodable {
    init() {}
}

private struct TransferOffer: Codable {
    let transferId: String
    let fileName: String
    let fileSize: Int
    let mimeType: String
    let pairId: String
}

private struct IncomingTransferPlan {
    let offer: TransferOffer
    let fileURL: URL
}

private final class UploadProgressDelegate: NSObject, URLSessionTaskDelegate {
    private let totalBytes: Int64
    private let onProgress: (Int64, Int64) -> Void
    private var stats: TransferStatsWindow

    init(totalBytes: Int64, onProgress: @escaping (Int64, Int64) -> Void) {
        self.totalBytes = totalBytes
        self.onProgress = onProgress
        self.stats = TransferStatsWindow(totalBytes: totalBytes)
    }

    func urlSession(
        _ session: URLSession,
        task: URLSessionTask,
        didSendBodyData bytesSent: Int64,
        totalBytesSent: Int64,
        totalBytesExpectedToSend: Int64
    ) {
        stats.addSample(date: Date(), bytes: min(totalBytesSent, totalBytes))
        onProgress(min(totalBytesSent, totalBytes), stats.speedBytesPerSecond())
    }
}

private enum LanDropNetworkError: LocalizedError {
    case emptyFile
    case fileNameUnavailable
    case invalidURL
    case peerOffline
    case requestRejected
    case transferRejected

    var errorDescription: String? {
        switch self {
        case .emptyFile:
            return "不能发送空文件。"
        case .fileNameUnavailable:
            return "无法创建唯一的接收文件名。"
        case .invalidURL:
            return "无法连接到对方设备。"
        case .peerOffline:
            return "设备当前不在线，请确认同一个 Wi-Fi 后重试。"
        case .requestRejected:
            return "对方设备拒绝了请求。"
        case .transferRejected:
            return "对方设备拒绝了文件传输。"
        }
    }
}

private func bearerToken(_ value: String?) -> String? {
    guard let value, value.hasPrefix("Bearer ") else { return nil }
    return String(value.dropFirst("Bearer ".count))
}
