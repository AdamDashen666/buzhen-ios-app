import SwiftUI
import UniformTypeIdentifiers

struct ContentView: View {
    @EnvironmentObject private var model: AppModel
    @State private var pairCodeInput = ""
    @State private var selectedPeerId: String?
    @State private var showingFileImporter = false
    @State private var fileImportPair: PairedDevice?

    var body: some View {
        ZStack {
            AuroraBackground()
            ScrollView {
                VStack(spacing: 20) {
                    header
                    hero
                    PairingPanel(code: model.pairingCode?.code)
                    DiscoveryPanel(
                        devices: model.discoveredDevices,
                        selectedPeerId: $selectedPeerId,
                        code: $pairCodeInput,
                        isBusy: model.isBusy,
                        onPair: pairSelectedDevice
                    )
                    PairedPanel(
                        devices: model.pairedDevices,
                        isBusy: model.isBusy,
                        onSend: { pair in
                            fileImportPair = pair
                            showingFileImporter = true
                        },
                        onUnpair: model.unpair
                    )
                    TransferStatusPanel(transfers: model.transfers)
                }
                .padding(22)
            }
        }
        .preferredColorScheme(.dark)
        .fileImporter(
            isPresented: $showingFileImporter,
            allowedContentTypes: [.item],
            allowsMultipleSelection: false
        ) { result in
            handleFileImport(result)
        }
        .onChange(of: model.discoveredDevices) { devices in
            guard selectedPeerId == nil || !devices.contains(where: { $0.id == selectedPeerId }) else {
                return
            }
            selectedPeerId = devices.first?.id
        }
    }

    private var header: some View {
        HStack {
            HStack(spacing: 12) {
                Image(systemName: "arrow.right.circle.fill")
                    .font(.system(size: 34, weight: .bold))
                    .symbolRenderingMode(.palette)
                    .foregroundStyle(.black, .cyan)
                VStack(alignment: .leading, spacing: 2) {
                    Text("LanDrop")
                        .font(.headline)
                    Text("同 Wi-Fi 文件直传")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
            Spacer()
            Label("无服务器", systemImage: "wifi")
                .font(.caption.weight(.semibold))
                .padding(.horizontal, 12)
                .padding(.vertical, 8)
                .glassCard(cornerRadius: 18)
        }
    }

    private var hero: some View {
        VStack(alignment: .leading, spacing: 18) {
            Text("安全配对 · 实时速度 · 流畅传输")
                .font(.caption.weight(.bold))
                .foregroundStyle(.cyan)
            Text(model.pairedDevices.first.map { "已连接 \($0.name)" } ?? "生成或输入 6 位配对码，开始局域网传输")
                .font(.system(size: 36, weight: .bold, design: .rounded))
                .lineLimit(3)
            Text(model.statusText)
                .font(.body)
                .foregroundStyle(.secondary)
            HStack {
                Button {
                    withAnimation(.spring(response: 0.52, dampingFraction: 0.82)) {
                        model.generatePairingCode()
                    }
                } label: {
                    Label("生成配对码", systemImage: "link")
                }
                .buttonStyle(.primaryLanDrop)
                .disabled(model.isBusy)

                Button {
                    if let pair = model.pairedDevices.first {
                        fileImportPair = pair
                        showingFileImporter = true
                    }
                } label: {
                    Label("选择文件", systemImage: "paperclip")
                }
                .buttonStyle(.secondaryLanDrop)
                .disabled(model.pairedDevices.isEmpty || model.isBusy)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(24)
        .glassCard(cornerRadius: 28)
    }

    private func pairSelectedDevice() {
        guard let id = selectedPeerId,
              let device = model.discoveredDevices.first(where: { $0.id == id })
        else {
            model.statusText = "请选择一台已发现设备。"
            return
        }
        Task {
            await model.pair(with: device, code: pairCodeInput)
            pairCodeInput = ""
        }
    }

    private func handleFileImport(_ result: Result<[URL], Error>) {
        switch result {
        case .success(let urls):
            guard let url = urls.first, let pair = fileImportPair else { return }
            Task {
                await model.sendFile(url, to: pair)
            }
        case .failure(let error):
            model.statusText = error.localizedDescription
        }
    }
}

private struct PairingPanel: View {
    let code: String?

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Label("本机配对码", systemImage: "shield.checkered")
                .font(.headline)
            Text(code ?? "------")
                .font(.system(size: 50, weight: .black, design: .rounded))
                .monospacedDigit()
                .tracking(8)
            Text("让 Windows 输入此号码，或在下方输入对方设备显示的号码。")
                .font(.footnote)
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(22)
        .glassCard(cornerRadius: 24)
    }
}

private struct DiscoveryPanel: View {
    let devices: [DiscoveredDevice]
    @Binding var selectedPeerId: String?
    @Binding var code: String
    let isBusy: Bool
    let onPair: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text("发现的设备")
                .font(.headline)
            if devices.isEmpty {
                EmptyState(text: "保持两台设备在同一个 Wi-Fi，并打开 LanDrop。")
            } else {
                ForEach(devices) { device in
                    Button {
                        selectedPeerId = device.id
                    } label: {
                        DeviceRow(
                            icon: device.platform == .ios ? "iphone.gen3" : "desktopcomputer",
                            name: device.name,
                            subtitle: "\(device.platform.displayName) · \(device.host):\(device.port)",
                            isSelected: selectedPeerId == device.id
                        )
                    }
                    .buttonStyle(.plain)
                }
            }

            HStack(spacing: 10) {
                TextField("输入对方 6 位码", text: $code)
                    .keyboardType(.numberPad)
                    .textContentType(.oneTimeCode)
                    .monospacedDigit()
                    .padding(.horizontal, 14)
                    .frame(height: 46)
                    .background(.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 15, style: .continuous))
                    .onChange(of: code) { value in
                        code = String(value.filter(\.isNumber).prefix(6))
                    }

                Button("配对", action: onPair)
                    .buttonStyle(.primaryLanDrop)
                    .disabled(isBusy || code.count != 6 || selectedPeerId == nil)
            }
        }
        .padding(18)
        .glassCard(cornerRadius: 22)
    }
}

private struct PairedPanel: View {
    let devices: [PairedDevice]
    let isBusy: Bool
    let onSend: (PairedDevice) -> Void
    let onUnpair: (PairedDevice) -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text("已配对")
                .font(.headline)
            if devices.isEmpty {
                EmptyState(text: "配对完成后，设备会显示在这里。")
            } else {
                ForEach(devices) { device in
                    HStack(spacing: 12) {
                        DeviceRow(
                            icon: device.platform == .ios ? "iphone.gen3" : "desktopcomputer",
                            name: device.name,
                            subtitle: "\(device.platform.displayName) · \(device.createdAt.formatted(date: .abbreviated, time: .omitted))",
                            isSelected: false
                        )
                        VStack(spacing: 8) {
                            Button {
                                onSend(device)
                            } label: {
                                Image(systemName: "paperplane.fill")
                            }
                            .buttonStyle(.roundIcon)
                            .disabled(isBusy)

                            Button {
                                onUnpair(device)
                            } label: {
                                Image(systemName: "trash")
                            }
                            .buttonStyle(.dangerRoundIcon)
                            .disabled(isBusy)
                        }
                    }
                }
            }
        }
        .padding(18)
        .glassCard(cornerRadius: 22)
    }
}

private struct DeviceRow: View {
    let icon: String
    let name: String
    let subtitle: String
    let isSelected: Bool

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: icon)
                .font(.title3)
                .foregroundStyle(.cyan)
                .frame(width: 30)
            VStack(alignment: .leading, spacing: 3) {
                Text(name).font(.subheadline.weight(.semibold))
                Text(subtitle).font(.caption).foregroundStyle(.secondary)
            }
            Spacer()
            if isSelected {
                Image(systemName: "checkmark.circle.fill")
                    .foregroundStyle(.cyan)
            }
        }
        .padding(14)
        .background(
            isSelected ? .cyan.opacity(0.16) : .white.opacity(0.08),
            in: RoundedRectangle(cornerRadius: 18, style: .continuous)
        )
        .overlay {
            RoundedRectangle(cornerRadius: 18, style: .continuous)
                .stroke(isSelected ? .cyan.opacity(0.8) : .clear, lineWidth: 1)
        }
    }
}

private struct EmptyState: View {
    let text: String

    var body: some View {
        Text(text)
            .frame(maxWidth: .infinity, minHeight: 72)
            .font(.footnote)
            .foregroundStyle(.secondary)
            .background(.white.opacity(0.05), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
            .overlay {
                RoundedRectangle(cornerRadius: 16, style: .continuous)
                    .stroke(.white.opacity(0.12), style: StrokeStyle(lineWidth: 1, dash: [5, 6]))
            }
    }
}

private struct TransferStatusPanel: View {
    let transfers: [TransferSnapshot]

    var body: some View {
        let transfer = transfers.first
        HStack(spacing: 18) {
            ZStack {
                Circle().stroke(.white.opacity(0.15), lineWidth: 9)
                Circle()
                    .trim(from: 0, to: transfer?.progress ?? 0)
                    .stroke(.cyan, style: StrokeStyle(lineWidth: 9, lineCap: .round))
                    .rotationEffect(.degrees(-90))
                    .animation(.spring(response: 0.42, dampingFraction: 0.84), value: transfer?.progress ?? 0)
                Text(transfer.map { "\(Int($0.progress * 100))%" } ?? "Ready")
                    .font(.caption.weight(.bold))
            }
            .frame(width: 86, height: 86)
            VStack(alignment: .leading, spacing: 6) {
                Text(transfer?.fileName ?? "等待传输")
                    .font(.headline)
                    .lineLimit(1)
                Text(transfer.map(transferSubtitle) ?? "传输进度和速度会在这里实时显示。")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
            }
            Spacer()
        }
        .padding(18)
        .glassCard(cornerRadius: 22)
    }

    private func transferSubtitle(_ transfer: TransferSnapshot) -> String {
        let direction = transfer.direction == .send ? "发送" : "接收"
        return "\(direction) · \(statusText(transfer.status)) · \(formatBytes(transfer.speedBytesPerSecond))/s"
    }

    private func statusText(_ status: TransferSnapshot.Status) -> String {
        switch status {
        case .offered:
            return "等待确认"
        case .transferring:
            return "传输中"
        case .complete:
            return "已完成"
        case .failed:
            return "失败"
        }
    }
}

private struct AuroraBackground: View {
    var body: some View {
        ZStack {
            LinearGradient(
                colors: [.black, Color(red: 0.04, green: 0.08, blue: 0.15)],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            Circle()
                .fill(.cyan.opacity(0.26))
                .frame(width: 260)
                .blur(radius: 44)
                .offset(x: -120, y: -260)
            Circle()
                .fill(.orange.opacity(0.18))
                .frame(width: 300)
                .blur(radius: 54)
                .offset(x: 150, y: 300)
        }
        .ignoresSafeArea()
    }
}

private func formatBytes(_ bytes: Int64) -> String {
    let formatter = ByteCountFormatter()
    formatter.countStyle = .file
    formatter.includesUnit = true
    formatter.includesCount = true
    return formatter.string(fromByteCount: bytes)
}

private extension View {
    func glassCard(cornerRadius: CGFloat) -> some View {
        background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: cornerRadius, style: .continuous))
            .overlay {
                RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
                    .stroke(.white.opacity(0.16), lineWidth: 1)
            }
            .shadow(color: .black.opacity(0.22), radius: 32, y: 20)
    }
}

private struct PrimaryLanDropButton: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.subheadline.weight(.bold))
            .padding(.horizontal, 16)
            .padding(.vertical, 12)
            .foregroundStyle(.black)
            .background(
                LinearGradient(
                    colors: [.cyan, Color(red: 0.58, green: 0.72, blue: 1)],
                    startPoint: .leading,
                    endPoint: .trailing
                ),
                in: Capsule()
            )
            .scaleEffect(configuration.isPressed ? 0.96 : 1)
            .animation(.spring(response: 0.28, dampingFraction: 0.74), value: configuration.isPressed)
    }
}

private struct SecondaryLanDropButton: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.subheadline.weight(.bold))
            .padding(.horizontal, 16)
            .padding(.vertical, 12)
            .foregroundStyle(.white)
            .background(.white.opacity(0.1), in: Capsule())
            .scaleEffect(configuration.isPressed ? 0.96 : 1)
            .animation(.spring(response: 0.28, dampingFraction: 0.74), value: configuration.isPressed)
    }
}

private struct RoundIconButton: ButtonStyle {
    let color: Color

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.subheadline.weight(.bold))
            .frame(width: 38, height: 38)
            .foregroundStyle(color)
            .background(color.opacity(0.14), in: Circle())
            .scaleEffect(configuration.isPressed ? 0.92 : 1)
            .animation(.spring(response: 0.28, dampingFraction: 0.74), value: configuration.isPressed)
    }
}

private extension ButtonStyle where Self == PrimaryLanDropButton {
    static var primaryLanDrop: PrimaryLanDropButton { PrimaryLanDropButton() }
}

private extension ButtonStyle where Self == SecondaryLanDropButton {
    static var secondaryLanDrop: SecondaryLanDropButton { SecondaryLanDropButton() }
}

private extension ButtonStyle where Self == RoundIconButton {
    static var roundIcon: RoundIconButton { RoundIconButton(color: .cyan) }
    static var dangerRoundIcon: RoundIconButton { RoundIconButton(color: .orange) }
}
