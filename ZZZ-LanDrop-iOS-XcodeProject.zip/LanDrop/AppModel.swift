import Combine
import Foundation
import SwiftUI
import UIKit

@MainActor
final class AppModel: ObservableObject {
    @Published var pairingCode: PairingSession?
    @Published var pairedDevices: [PairedDevice] = []
    @Published var discoveredDevices: [DiscoveredDevice] = []
    @Published var transfers: [TransferSnapshot] = []
    @Published var statusText = "保持两台设备在同一个 Wi-Fi，打开 LanDrop 即可发现。"
    @Published var isBusy = false

    private let network: LocalNetworkService
    private let pairingsKey = "landrop.pairings"
    private var cancellables = Set<AnyCancellable>()

    init() {
        let deviceId = Self.readOrCreateDeviceId()
        let receiveDirectory = FileManager.default
            .urls(for: .documentDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("LanDrop", isDirectory: true)
        network = LocalNetworkService(
            deviceId: deviceId,
            deviceName: UIDevice.current.name,
            receiveDirectory: receiveDirectory
        )

        pairedDevices = Self.loadPairings(key: pairingsKey)
        network.updatePairings(pairedDevices)
        network.onPairedDevice = { [weak self] pair in
            self?.addPair(pair)
            self?.pairingCode = nil
            self?.statusText = "已与 \(pair.name) 配对。"
        }
        network.onTransferUpdated = { [weak self] snapshot in
            self?.upsertTransfer(snapshot)
        }
        network.$discoveredDevices
            .sink { [weak self] devices in
                self?.discoveredDevices = devices
            }
            .store(in: &cancellables)
    }

    func start() {
        network.start()
    }

    func generatePairingCode() {
        let session = PairingCode.create(now: Date())
        pairingCode = session
        network.setPairingSession(session)
        statusText = "配对码已生成，5 分钟内有效。"
    }

    func pair(with device: DiscoveredDevice, code: String) async {
        guard code.count == 6 else {
            statusText = "请输入 6 位配对码。"
            return
        }

        isBusy = true
        defer { isBusy = false }

        do {
            let pair = try await network.pair(with: device, code: code)
            addPair(pair)
            statusText = "已与 \(pair.name) 配对。"
        } catch {
            statusText = error.localizedDescription
        }
    }

    func unpair(_ device: PairedDevice) {
        pairedDevices.removeAll { $0.pairId == device.pairId }
        savePairings()
        network.updatePairings(pairedDevices)
        statusText = "已解除与 \(device.name) 的配对。"
    }

    func sendFile(_ fileURL: URL, to pair: PairedDevice) async {
        isBusy = true
        defer { isBusy = false }

        let didAccess = fileURL.startAccessingSecurityScopedResource()
        defer {
            if didAccess {
                fileURL.stopAccessingSecurityScopedResource()
            }
        }

        do {
            try await network.sendFile(fileURL, to: pair)
            statusText = "文件已发送到 \(pair.name)。"
        } catch {
            statusText = error.localizedDescription
        }
    }

    private func addPair(_ pair: PairedDevice) {
        pairedDevices.removeAll { $0.deviceId == pair.deviceId || $0.pairId == pair.pairId }
        pairedDevices.insert(pair, at: 0)
        savePairings()
        network.updatePairings(pairedDevices)
    }

    private func upsertTransfer(_ snapshot: TransferSnapshot) {
        withAnimation(.spring(response: 0.44, dampingFraction: 0.82)) {
            transfers.removeAll { $0.id == snapshot.id }
            transfers.insert(snapshot, at: 0)
            transfers = Array(transfers.prefix(8))
        }
    }

    private func savePairings() {
        guard let data = try? JSONEncoder().encode(pairedDevices) else { return }
        UserDefaults.standard.set(data, forKey: pairingsKey)
    }

    private static func loadPairings(key: String) -> [PairedDevice] {
        guard let data = UserDefaults.standard.data(forKey: key),
              let pairings = try? JSONDecoder().decode([PairedDevice].self, from: data)
        else {
            return []
        }
        return pairings
    }

    private static func readOrCreateDeviceId() -> String {
        let key = "landrop.deviceId"
        if let existing = UserDefaults.standard.string(forKey: key) {
            return existing
        }

        let id = "ios_\(UUID().uuidString.replacingOccurrences(of: "-", with: "").prefix(16))"
        UserDefaults.standard.set(id, forKey: key)
        return id
    }
}
