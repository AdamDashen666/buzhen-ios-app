# Implementation and verification report

## Completed on this Windows workstation

| Requirement | Evidence |
| --- | --- |
| Private bearer-token Agent | `TokenStore`, authenticated API tests, and loopback smoke client |
| Existing-network-only boundary | Source audit finds no runtime Tailscale, proxy, DNS, route, adapter, or firewall control command |
| Resumable uploads | Disk chunks, received-index persistence, SHA-256/size validation, atomic source publish |
| Job queue and ownership | SQLite FIFO queue, restart recovery, direct child-process registry, no global Topaz process search/kill |
| Safe Topaz command | Allowlisted model settings, list-form argv, no shell, `download=0` |
| Progress and output | Structured and direct-FFmpeg owned-process progress, plus Topaz failure reason, persist in SQLite; output requires nonempty FFprobe validation and supports Range download |
| iOS source handoff | SwiftUI Xcode project, shared simulator test scheme, Keychain pairing token, Files/Photos selection, resumable chunk upload, enhancement/interpolation UI, job cancellation, output save/share/Photos, generated AppIcon |
| Optional WeChat route | Authenticated import/delivery API, persisted import and independent delivery state, Agent-owned staging, and a bounded File Transfer Assistant UI helper |

## Verification completed here

- `python -m unittest discover -s windows-agent/tests -v`: 42 passing tests.
- `python -m compileall -q windows-agent/src`, JSON parsing, and `git diff --check`: passed.
- `python windows-agent/scripts/mock_ios_client.py`: passed against an in-process loopback Agent without starting Topaz.
- Xcode project paths, target references, shared XCTest scheme, plist XML, and Swift placeholder/encoding scans: passed structurally.
- WeChat bridge unit/API paths and .NET Release build: covered without manipulating a real WeChat window.

## Requires macOS or your real Topaz environment

1. Run `xcodebuild test -project ios/TopazRemote.xcodeproj -scheme TopazRemote -destination 'platform=iOS Simulator,name=iPhone 16' CODE_SIGNING_ALLOWED=NO`, or let GitHub Actions run it.
2. Set a personal bundle identifier/signing team in Xcode and install on an iPhone/iPad.
3. Pair using your existing Tailscale address and private Agent token; upload and download a small video.
4. Run a short export with a model already installed locally, then confirm the result in the mobile app. The 2026-08-14 local probes did not find `apo-8`, `chr-2`, or `prob-4`; no successful Topaz export is claimed. No model download or network reconfiguration should be used to make this test pass.
5. With Windows unlocked and WeChat logged in, manually verify one already-downloaded import, one explicit not-downloaded import, metadata display, progress, and one output delivery. The real output-delivery click is intentionally deferred until the user approves that specific send.
