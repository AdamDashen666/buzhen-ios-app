# Troubleshooting

## Agent does not start

Confirm Python 3.10+ is available, then run `windows-agent\scripts\start-agent.ps1 -Port 8123`. The launcher validates the port. If the installed Topaz bundled FFmpeg is in a nonstandard location, start with `--topaz-ffmpeg "C:\path\to\ffmpeg.exe"`.

## Pairing or API requests fail

First check `GET /api/v1/health` locally. Then confirm the iOS client uses the current bearer token from the Agent data directory. Do not change network settings as a workaround; confirm the existing Tailscale connection separately.

## A job fails immediately

Verify the source was uploaded through the Agent and that the requested model is marked available by `/capabilities`. Filter help or old Topaz logs alone do not make a model available: install the model through the normal Topaz UI, then restart the Agent. The Agent deliberately sets `download=0`; it will not download models.

## Job remained processing after an Agent crash

On restart, the Agent marks interrupted processing jobs as failed because it cannot safely take ownership of a process from an earlier Agent instance. Queue the source again after investigating the local Topaz output.

## Progress is unavailable

Progress is populated only when the locally observed Topaz child process emits a recognized structured status record. The Agent does not invent FPS or ETA; those fields may remain blank even while frame/count progress is shown.

## iOS project cannot build

Open `ios/TopazRemote.xcodeproj` with Xcode 16+, choose a personal bundle identifier and signing team, then run the simulator build before testing on a device. Windows cannot validate Xcode compilation or iPhone behavior.

## WeChat import or delivery fails

Keep the Windows desktop unlocked and WeChat logged in. The helper can read only the File Transfer Assistant conversation and only when **Read latest WeChat video** is tapped in the paired iPad app. If the newest eligible message shows as not downloaded, the same action requests its download; files WeChat already downloaded are reused. A changed WeChat UI, unavailable download root, or missing file-picker control returns a visible, retryable error without changing any Tailscale, proxy, VPN, firewall, or routing setting.

For a completed WeChat-routed job, a delivery error does not invalidate the result. Leave the original output in the Agent media folder, restore the unlocked/logged-in WeChat desktop, and tap **Retry WeChat Send**. The bridge marks delivery successful only after it sees a new matching file message in File Transfer Assistant.
