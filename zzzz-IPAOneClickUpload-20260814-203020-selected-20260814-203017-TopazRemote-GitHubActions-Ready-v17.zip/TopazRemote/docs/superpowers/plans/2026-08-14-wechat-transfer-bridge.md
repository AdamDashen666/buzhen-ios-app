# WeChat File Transfer Assistant Bridge Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add WeChat File Transfer Assistant import/delivery while preserving Tailscale upload/download.

**Architecture:** A .NET 8 Windows UI Automation helper operates only the logged-in File Transfer Assistant chat and emits JSON. The Python Agent stages/probes files, persists import/delivery state, and retains queue/progress APIs. SwiftUI selects Tailscale or WeChat.

**Tech Stack:** Python 3.10 stdlib, SQLite, .NET 8 `net8.0-windows`, SwiftUI, URLSession, unittest/XCTest.

## Global Constraints

- Never alter Tailscale, proxy, firewall, DNS, routes, Topaz models, or existing direct transfer.
- Only act in File Transfer Assistant; accept only `.mp4 .mov .m4v .mkv .avi .webm`.
- Download begins only after the authenticated App request. Reuse an automatically downloaded copy when present.
- Locked desktop, logged-out WeChat, changed UI, ambiguity, and send failure are retryable states; never automate login/QR/security dialogs.
- Output send accepts only the completed Agent-owned file for that exact WeChat-routed job.

---

### Task 1: Build a bounded native WeChat helper

**Files:**
- Create: `windows-agent/wechat-bridge/TopazRemote.WeChatBridge.csproj`
- Create: `windows-agent/wechat-bridge/Program.cs`
- Create: `windows-agent/wechat-bridge/README.md`

**Interfaces:**
- Input JSON: `{"command":"inspect-latest"|"download-latest"|"send-output","downloadRoot":"...","filePath":"...","timeoutSeconds":120}`
- Output JSON: `{"state":"ready|not_downloaded|sent|not_found|unsupported_file|wechat_not_logged_in|desktop_locked|ui_changed|download_failed|send_failed","filename":"...","filePath":"...","error":"..."}`

- [x] **Step 1: Create the Windows UI Automation project**

```xml
<Project Sdk="Microsoft.NET.Sdk">
  <PropertyGroup>
    <OutputType>Exe</OutputType><TargetFramework>net8.0-windows</TargetFramework>
    <UseWPF>true</UseWPF><Nullable>enable</Nullable><ImplicitUsings>enable</ImplicitUsings>
  </PropertyGroup>
</Project>
```

- [x] **Step 2: Build it before adding UI calls**

Run: `dotnet build windows-agent/wechat-bridge/TopazRemote.WeChatBridge.csproj -c Release`

Expected: PASS using the locally installed .NET 8 SDK.

- [x] **Step 3: Implement the JSON command contract**

```csharp
record BridgeRequest(string Command, string? DownloadRoot, string? FilePath, int TimeoutSeconds = 120);
record BridgeResult(string State, string? Filename = null, string? FilePath = null, string? Error = null);
```

Find the WeChat window and require the File Transfer Assistant AutomationId/name. `inspect-latest` reads only the newest eligible file message and returns `not_downloaded` without clicking it.

- [x] **Step 4: Implement bounded UI actions**

`download-latest` invokes only the just-inspected newest eligible item, waits at most `timeoutSeconds`, and returns `ready` only after a matching regular file appears below `downloadRoot`. `send-output` rejects a non-Agent path, uses only the visible **发送文件** control, and returns `sent` only after the message list contains the filename. Missing identities/modals return `ui_changed`; use `finally` to re-minimize WeChat if it was minimized.

- [x] **Step 5: Run harmless contract smoke checks**

Run: `'{"command":"unknown"}' | dotnet run --project windows-agent/wechat-bridge/TopazRemote.WeChatBridge.csproj --no-build`

Expected: exactly one validation JSON result and no WeChat input.

- [ ] **Step 6: Commit**

```bash
git add windows-agent/wechat-bridge
git commit -m "feat: add constrained WeChat UI bridge"
```

### Task 2: Stage and inspect WeChat videos in Python

**Files:**
- Create: `windows-agent/src/topazremote/wechat_bridge.py`
- Modify: `windows-agent/src/topazremote/storage.py`
- Create: `windows-agent/tests/test_wechat_bridge.py`

**Interfaces:**
- Produces: `WeChatImportResult(state, source_filename, video_info, error)` and `WeChatBridge.send_output(job_id, output)`.
- Consumed by: Task 3 server.

- [x] **Step 1: Write fake-helper tests**

Inject:

```python
class BridgeRunner(Protocol):
    def run(self, request: dict[str, object]) -> dict[str, object]: ...
```

Assert a `ready` `clip.mov` is staged, metadata returns `fileName,width,height,frameRate,duration,fileSize`, a `.zip` is `unsupported_file`, and a path outside the configured WeChat root is rejected.

- [ ] **Step 2: Run the failing test**

Run: `python -m unittest windows-agent.tests.test_wechat_bridge -v`

Expected: FAIL because `topazremote.wechat_bridge` is missing.

- [x] **Step 3: Add `Storage.stage_external_source`**

Implement `stage_external_source(source: Path, preferred_name: str) -> Path`: resolve and require the allowlisted regular source under the configured WeChat root; copy with a unique temporary file and `os.replace`; hash 1 MiB chunks; reuse identical Agent-owned copies; never delete the source.

- [x] **Step 4: Implement WeChatBridge**

`import_latest()` runs `inspect-latest`, runs `download-latest` only for `not_downloaded`, stages the validated path, and calls `ffprobe -v error -show_entries format=duration,size:stream=codec_name,width,height,r_frame_rate -of json` without a shell. Normalize to the iOS camel-case metadata keys.

- [x] **Step 5: Verify**

Run: `python -m unittest windows-agent.tests.test_wechat_bridge -v`

Expected: PASS without opening WeChat.

### Task 3: Add persisted API import and delivery state

**Files:**
- Modify: `windows-agent/src/topazremote/database.py`
- Modify: `windows-agent/src/topazremote/server.py`
- Create: `windows-agent/tests/test_wechat_api.py`
- Modify: `protocol/api-spec.md`

**Interfaces:**
- Add `POST /wechat/imports/latest`, `GET /wechat/imports/{id}`, `POST /jobs/{id}/wechat-send`.
- Extend `POST /jobs` with optional `deliveryRoute: "wechat"`.

- [x] **Step 1: Write authenticated endpoint tests**

With an injected fake bridge, assert import POST returns 202, status GET returns the staged filename/metadata, unauthenticated requests return 401, invalid routes return 400, and send failure leaves the job `completed` with `delivery.state == "send_failed"`.

- [ ] **Step 2: Run the failing test**

Run: `python -m unittest windows-agent.tests.test_wechat_api -v`

Expected: FAIL because the endpoints do not exist.

- [x] **Step 3: Add migrations and methods**

Create `imports(id,state,source_filename,video_info_json,error,created_at,updated_at)`. Add nullable `delivery_route,delivery_state,delivery_error` to `jobs` behind `PRAGMA table_info` checks. Define `create_wechat_import`, `set_wechat_import_result`, `get_wechat_import`, and `set_delivery`. Keep `delivery` absent from legacy job JSON when no route is set.

- [x] **Step 4: Implement async dispatch**

Inject `wechat_bridge` into `create_server`. Import POST starts a daemon bridge task. After `runner.finish(job_id, succeeded)`, a successful WeChat-routed job gets `sending` and a separate daemon calls `send_output`; failures become `send_failed`, never a failed Topaz job. Retry validates completed status, `wechat` route, and an output inside `storage.outputs`.

- [x] **Step 5: Verify Agent regressions**

Run:

```powershell
$env:PYTHONPATH = (Resolve-Path .\windows-agent\src).Path
python -m unittest discover -s windows-agent/tests -v
```

Expected: PASS including uploads, ranges, cancellation, FIFO, WeChat states.

### Task 4: Add iPad route selection and delivery UI

**Files:**
- Modify: `ios/TopazRemote/Models/Domain.swift`
- Modify: `ios/TopazRemote/Networking/AgentClient.swift`
- Modify: `ios/TopazRemote/Features/ContentView.swift`
- Modify: `ios/TopazRemoteTests/TopazRemoteTests.swift`

**Interfaces:**
- Define `SourceRoute.tailscale/.wechat`, Codable `WeChatImport`, `Delivery`, and Codable `VideoInfo`.
- Add `startWeChatImport()`, `wechatImport(id:)`, `retryWeChatDelivery(jobID:)`, and optional `deliveryRoute` to `createJob`.

- [x] **Step 1: Write decoding regression tests**

Decode ready import metadata and a job with `delivery.state == "send_failed"`; also decode the current job JSON lacking delivery.

- [x] **Step 2: Implement models and client calls**

Use existing `makeRequest`/ `decode`. Include `deliveryRoute` only when non-nil, so existing Tailscale jobs retain their wire format.

- [x] **Step 3: Implement the two-route source section**

Add a segmented picker. Tailscale retains Files/Photos upload exactly. WeChat shows **Read latest WeChat video**; it starts import only on that tap, polls once per second while downloading, and populates the existing metadata/settings UI only when ready. Display safe errors for every bridge state.

- [x] **Step 4: Implement completed delivery status**

WeChat jobs call `createJob(..., deliveryRoute: "wechat")`. JobRow shows sending/sent/send-failed and a retry button. Tailscale jobs keep current **Save Video** controls.

- [ ] **Step 5: Verify**

Run the current simulator test workflow/Xcode test command and the Windows Agent suite. Expected: no test sends or downloads through real WeChat.

### Task 5: Document and manually verify with user control

**Files:**
- Modify: `README.md`, `docs/architecture.md`, `docs/troubleshooting.md`, `docs/implementation-report.md`

- [x] **Step 1: Document prerequisites**

State logged-in WeChat, unlocked Windows, File Transfer Assistant-only scope, automatic-download detection, manual-download fallback, UI-update failure behavior, and retryable output delivery.

- [x] **Step 2: Document manual checks**

Cover already-downloaded import, not-downloaded import, metadata round-trip, Topaz progress, send failure/retry. Mark the one real output send as requiring the user's explicit approval at action time.

- [x] **Step 3: Run final verification**

Run:

```powershell
$env:PYTHONPATH = (Resolve-Path .\windows-agent\src).Path
python -m unittest discover -s windows-agent/tests -v
dotnet build windows-agent/wechat-bridge/TopazRemote.WeChatBridge.csproj -c Release
```

Expected: both pass without real WeChat UI input.

## Plan Self-Review

- Coverage: Tasks 1–2 implement scoped UI automation, automatic/manual download detection, staging and metadata; Task 3 adds authenticated persistence and independent delivery state; Task 4 preserves Tailscale while adding the iPad route; Task 5 covers prerequisites and manual validation.
- Placeholder scan: no unresolved placeholders or undefined interfaces.
- Compatibility: `deliveryRoute` and `delivery` are optional, retaining legacy client JSON.
