# WeChat File Transfer Assistant Bridge

## Goal

Keep the existing Tailscale transfer workflow intact and add a WeChat File Transfer Assistant route for large videos whose transfer speed is poor over Tailscale/DERP.

The iPad app presents two source routes:

- **Tailscale**: existing upload and output-download flow, unchanged.
- **WeChat**: the user sends a video from the iPad to their own File Transfer Assistant conversation. The app explicitly asks the Windows Agent to read the latest eligible video only when the user taps a button.

After a WeChat-imported video is processed, the Windows Agent automatically sends the completed output to the same File Transfer Assistant conversation. Job progress, settings, errors, and metadata remain on the existing authenticated Topaz Remote HTTP API; these messages are small enough that they remain usable even when Tailscale is relayed.

## Constraints

- Windows WeChat 4.1.12.26 is installed, logged in, and exposes File Transfer Assistant, file-message state, and a Send File button through UI Automation.
- WeChat has no supported command-line File Transfer Assistant API. The bridge therefore uses only the logged-in desktop client's visible UI; it must not use an unofficial Web WeChat protocol, scrape credentials, or modify WeChat data stores.
- The desktop session must be unlocked. The bridge may restore WeChat when action is required and minimize it when idle; minimized operation is an optimization, not a reliability guarantee.
- A WeChat download must never start merely because a file arrives. It starts only from the authenticated iPad App action.
- The bridge handles only the File Transfer Assistant conversation and an allowlist of video extensions (`.mp4`, `.mov`, `.m4v`, `.mkv`, `.avi`, `.webm`). It does not inspect or send to other chats.
- No existing Tailscale, proxy, firewall, or Topaz processing configuration is changed.

## Architecture

### Windows Agent

Add a `wechat_bridge` adapter with a narrow interface:

1. Focus/restore the existing WeChat window and select File Transfer Assistant by its stable accessible name/ID.
2. Inspect the newest eligible incoming video message.
3. If WeChat has already downloaded it, resolve the local file. If it is marked not downloaded, invoke its download action and wait for the UI state and local file to become ready.
4. Copy or atomically stage the resolved file into the Agent-owned source directory, then use the existing FFprobe-based inspector to return filename, size, duration, dimensions, and frame rate.
5. Send an Agent-owned completed output file through File Transfer Assistant after its Topaz job has succeeded.

The adapter returns structured states rather than throwing UI text at callers: `ready`, `downloading`, `not_found`, `unsupported_file`, `wechat_not_logged_in`, `desktop_locked`, `ui_changed`, `download_failed`, `send_pending`, `sent`, and `send_failed`.

Automation is limited to a dedicated Windows interactive-session helper. The HTTP server must not assume that a background service can control the logged-in desktop; when the helper is unavailable, it reports a retryable error.

### API

Keep all existing endpoints compatible. Add authenticated, asynchronous endpoints:

- `POST /api/v1/wechat/imports/latest`: request an explicit import of the newest eligible File Transfer Assistant video; returns an import ID and initial state.
- `GET /api/v1/wechat/imports/{id}`: returns state, staged source filename when ready, metadata when available, and a retryable error when applicable.
- `POST /api/v1/jobs/{id}/wechat-send`: retries delivery of a completed output. Automatic delivery uses the same internal operation after a successful job.
- `GET /api/v1/jobs/{id}` gains an optional `delivery` object without changing existing job fields.

Import IDs and delivery status persist in the existing SQLite database. An already-staged file is deduplicated by hash and size so a retry cannot queue or import a second copy unintentionally.

### iPad App

The existing source section becomes a two-option selector:

- **Tailscale transfer** keeps the current Files/Photos picker and resumable upload.
- **WeChat File Transfer Assistant** shows “Read latest WeChat video”. It starts the import, polls its state, then displays the returned filename and metadata in the existing parameter screen.

The existing enhancement, denoise, and interpolation controls remain unchanged. The app queues the staged source by filename through the existing jobs endpoint. For WeChat sources, the completed-job screen shows delivery state (`sending`, `sent`, `failed`) and a retry-send button. Tailscale sources keep their existing output download action.

## Data Flow

1. User sends a video on iPad WeChat to File Transfer Assistant.
2. User opens Topaz Remote and selects **WeChat File Transfer Assistant** -> **Read latest WeChat video**.
3. The Agent reads only that conversation's latest eligible video. It uses the existing automatically downloaded local copy when available; otherwise it triggers the download, waits, stages the file, and returns metadata.
4. User selects enhancement / interpolation / denoise settings and queues the job as today.
5. The existing worker processes the staged source and persists progress. The iPad app continues polling job status over the present Tailscale connection.
6. On success, the Agent asks the bridge to send the output to File Transfer Assistant. Send failure does not change the Topaz job from `completed`; it creates a retryable delivery failure.

## Failure Handling and Safety

- Never select a chat based only on visual position. Require File Transfer Assistant's accessible identity.
- Never choose an arbitrary “latest file” from a download folder. Correlate the visible newest eligible message with its resolved local file and stage it under an Agent-owned, uniquely named path.
- Do not delete WeChat originals or any user files. The Agent may clean only its own staged copies according to existing retention rules.
- If more than one candidate could be interpreted as newest, return `not_found`/`ambiguous` and ask the user to retry after opening the intended message; do not guess.
- If WeChat is locked, logged out, updated incompatibly, or shows an unexpected modal, stop and return a retryable error. Do not automate login, QR approval, security prompts, or other chats.
- Automatic output sending is restricted to the completed output generated by the matching Agent job and the user's own File Transfer Assistant conversation. The delivery retry endpoint cannot accept arbitrary paths or recipient names.

## Verification

- Unit tests use a fake WeChat bridge; no test opens WeChat or sends a file.
- Agent tests cover import state transitions, extension checks, metadata response, source staging, deduplication, persistence, automatic delivery initiation, and failed-delivery retry without changing completed job status.
- iOS tests cover route selection, import polling, metadata display, existing Tailscale path regression, and delivery-state presentation.
- Manual smoke tests are explicitly split into: already-downloaded import, not-downloaded import, imported metadata, successful/failed UI states, and one user-approved real File Transfer Assistant send. No automated test sends a real file.

## Out of Scope

- Replacing Tailscale globally, optimizing DERP, or changing network settings.
- Reading messages or files from any non-File Transfer Assistant chat.
- Headless WeChat operation while Windows is locked.
- Automatic model installation, Topaz GUI automation, or changing Topaz model availability.
