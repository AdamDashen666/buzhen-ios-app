# Architecture

The Python Windows Agent owns all state in its own data directory. Its HTTP API is bearer-token protected except for health. Upload chunks are stored on disk and atomically published only after size/hash validation; jobs and observed progress persist in SQLite; output responses support byte ranges.

Topaz integration is isolated in `topaz_adapter.py` and `worker.py`. It builds list-form argv for the locally detected bundled FFmpeg filters, validates model IDs against effective capabilities, reads only its own child-process output, and persists recognized structured progress records. It does not invoke Topaz GUI automation, modify models, or request model downloads. Unavailable FPS and ETA remain null.

The optional WeChat bridge is a separate .NET desktop-session helper. It is constrained to the visible File Transfer Assistant UI, a video-extension allowlist, and a configured WeChat download root. Imported media is copied into Agent storage before FFprobe metadata is returned. Delivery uses only an Agent-owned completed output path and has independent `pending`/`sending`/`sent`/`send_failed` state, so a WeChat problem cannot change a completed Topaz job into a failed one.
