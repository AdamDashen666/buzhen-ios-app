param(
    [Parameter(Mandatory = $true)]
    [string]$OutputPath
)

$repoRoot = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$stageRoot = Join-Path ([System.IO.Path]::GetTempPath()) ("TopazRemote-package-" + [guid]::NewGuid().ToString('N'))
$packageRoot = Join-Path $stageRoot 'TopazRemote'
$output = [System.IO.Path]::GetFullPath($OutputPath)

New-Item -ItemType Directory -Path $packageRoot -Force | Out-Null
try {
    Get-ChildItem -LiteralPath $repoRoot -Recurse -File | Where-Object {
        $_.FullName -notmatch '\\.git\\|\\bin\\|\\obj\\|__pycache__|\\data\\|\\uploads\\'
    } | ForEach-Object {
        $relative = $_.FullName.Substring($repoRoot.Length).TrimStart('\')
        $destination = Join-Path $packageRoot $relative
        New-Item -ItemType Directory -Path (Split-Path -Parent $destination) -Force | Out-Null
        Copy-Item -LiteralPath $_.FullName -Destination $destination -Force
    }
    if (Test-Path -LiteralPath $output) { throw "Refusing to overwrite existing package: $output" }
    Add-Type -AssemblyName System.IO.Compression
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $archive = [System.IO.Compression.ZipFile]::Open($output, [System.IO.Compression.ZipArchiveMode]::Create)
    try {
        Get-ChildItem -LiteralPath $packageRoot -Recurse -File | ForEach-Object {
            $relative = $_.FullName.Substring($packageRoot.Length).TrimStart('\').Replace('\', '/')
            $entry = $archive.CreateEntry("TopazRemote/$relative", [System.IO.Compression.CompressionLevel]::Optimal)
            $input = [System.IO.File]::OpenRead($_.FullName)
            try {
                $target = $entry.Open()
                try { $input.CopyTo($target) }
                finally { $target.Dispose() }
            }
            finally { $input.Dispose() }
        }
    }
    finally { $archive.Dispose() }
    Write-Output $output
}
finally {
    if (Test-Path -LiteralPath $stageRoot) { Remove-Item -LiteralPath $stageRoot -Recurse -Force }
}
