from __future__ import annotations

import json
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Protocol


VIDEO_EXTENSIONS = {".mp4", ".mov", ".m4v", ".mkv", ".avi", ".webm"}


class BridgeRunner(Protocol):
    def run(self, request: dict[str, object]) -> dict[str, object]: ...


@dataclass(frozen=True)
class WeChatImportResult:
    state: str
    source_filename: str | None = None
    video_info: dict[str, object] | None = None
    error: str | None = None


class SubprocessBridgeRunner:
    def __init__(self, executable: Path) -> None:
        self.executable = executable

    def run(self, request: dict[str, object]) -> dict[str, object]:
        try:
            completed = subprocess.run(
                [str(self.executable)], input=json.dumps(request), text=True,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=305, check=False,
            )
            if completed.returncode != 0:
                return {"state": "ui_changed", "error": completed.stderr.strip() or "WeChat bridge failed."}
            return json.loads(completed.stdout.strip())
        except (OSError, ValueError, subprocess.TimeoutExpired) as error:
            return {"state": "ui_changed", "error": str(error)}


class WeChatBridge:
    def __init__(self, runner: BridgeRunner, storage: Any, download_root: Path) -> None:
        self.runner, self.storage, self.download_root = runner, storage, download_root.resolve()

    def import_latest(self) -> WeChatImportResult:
        result = self.runner.run({"command": "inspect-latest", "downloadRoot": str(self.download_root), "timeoutSeconds": 30})
        if result.get("state") == "not_downloaded":
            result = self.runner.run({"command": "download-latest", "downloadRoot": str(self.download_root), "timeoutSeconds": 120})
        if result.get("state") != "ready":
            return WeChatImportResult(str(result.get("state", "ui_changed")), error=self._error(result))
        path = Path(str(result.get("filePath", ""))).resolve()
        if not self._inside_download_root(path) or not path.is_file() or path.suffix.lower() not in VIDEO_EXTENSIONS:
            return WeChatImportResult("unsupported_file", error="WeChat did not return an eligible downloaded video.")
        staged = self.storage.stage_external_source(path, str(result.get("filename") or path.name))
        return WeChatImportResult("ready", staged.name, self._probe(staged))

    def send_output(self, output: Path) -> WeChatImportResult:
        output = output.resolve()
        if output.parent != self.storage.outputs.resolve() or not output.is_file():
            return WeChatImportResult("send_failed", error="Output is not an Agent-owned completed file.")
        result = self.runner.run({"command": "send-output", "filePath": str(output), "mediaRoot": str(self.storage.outputs.resolve()), "timeoutSeconds": 120})
        return WeChatImportResult(str(result.get("state", "send_failed")), error=self._error(result))

    def _inside_download_root(self, path: Path) -> bool:
        try:
            path.relative_to(self.download_root)
            return True
        except ValueError:
            return False

    @staticmethod
    def _error(result: dict[str, object]) -> str | None:
        value = result.get("error")
        return value if isinstance(value, str) and value else None

    @staticmethod
    def _probe(path: Path) -> dict[str, object]:
        command = ["ffprobe", "-v", "error", "-show_entries", "format=duration,size:stream=codec_name,width,height,r_frame_rate", "-of", "json", str(path)]
        completed = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=30, check=False)
        if completed.returncode != 0:
            raise ValueError("FFprobe could not read the staged video.")
        payload = json.loads(completed.stdout); stream = next((item for item in payload.get("streams", []) if item.get("width") and item.get("height")), {})
        rate = str(stream.get("r_frame_rate", "0/1")).split("/")
        fps = float(rate[0]) / float(rate[1]) if len(rate) == 2 and float(rate[1]) else 0.0
        form = payload.get("format", {})
        return {"fileName": path.name, "fileExtension": path.suffix.removeprefix(".").upper(), "codec": stream.get("codec_name", "Unknown"), "width": int(stream.get("width", 0)), "height": int(stream.get("height", 0)), "frameRate": fps, "duration": float(form.get("duration", 0)), "fileSize": int(form.get("size", path.stat().st_size))}
