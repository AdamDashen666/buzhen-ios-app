from __future__ import annotations

import subprocess
import threading
from collections.abc import Callable
from pathlib import Path
from typing import Any, Protocol

from .database import Database
from .storage import Storage
from .topaz_adapter import TopazFfmpegAdapter
from .progress import parse_progress_line


class OwnedProcess(Protocol):
    stdout: Any
    def poll(self) -> int | None: ...
    def wait(self) -> int: ...
    def terminate(self) -> None: ...


class TopazProcessWorker:
    """Runs only child processes it created; cancellation never searches for a global process."""

    def __init__(
        self,
        database: Database,
        storage: Storage,
        adapter: TopazFfmpegAdapter,
        finished: Callable[[str, bool], None],
        popen_factory: Callable[..., OwnedProcess] = subprocess.Popen,
        output_validator: Callable[[Path], bool] | None = None,
    ) -> None:
        self.database = database
        self.storage = storage
        self.adapter = adapter
        self.finished = finished
        self.popen_factory = popen_factory
        self.output_validator = output_validator or self._default_output_validator
        self._lock = threading.RLock()
        self._processes: dict[str, OwnedProcess] = {}
        self._cancelled: set[str] = set()
        self._last_output: dict[str, str] = {}

    def start(self, job: dict[str, Any]) -> None:
        source = self.storage.sources / job["sourceFilename"]
        output = self.storage.outputs / f"{job['id']}.mp4"
        command = self.adapter.build_command(source, output, job["settings"])
        process = self.popen_factory(
            command,
            shell=False,
            cwd=str(self.adapter.working_directory(command)),
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
        )
        with self._lock:
            if job["id"] in self._processes:
                raise RuntimeError("job already has an owned process")
            self._processes[job["id"]] = process
            self._last_output[job["id"]] = ""
        reader = threading.Thread(target=self._collect_progress, args=(job["id"], process), daemon=True)
        reader.start()
        threading.Thread(target=self._wait_for_completion, args=(job["id"], output, process, reader), daemon=True).start()

    def is_owned(self, job_id: str) -> bool:
        with self._lock:
            return job_id in self._processes

    def cancel(self, job_id: str) -> bool:
        with self._lock:
            process = self._processes.get(job_id)
            if process is None:
                return False
            self._cancelled.add(job_id)
        if process.poll() is None:
            process.terminate()
        return True

    def _wait_for_completion(self, job_id: str, output: Path, process: OwnedProcess, reader: threading.Thread) -> None:
        return_code = process.wait()
        reader.join(timeout=5)
        with self._lock:
            cancelled = job_id in self._cancelled
            self._cancelled.discard(job_id)
            self._processes.pop(job_id, None)
            failure_reason = self._last_output.pop(job_id, "").strip()[-1000:]
        try:
            output_valid = self.output_validator(output)
        except Exception:
            output_valid = False
        succeeded = return_code == 0 and not cancelled and output_valid
        if succeeded:
            self.database.set_output_path(job_id, output)
        elif cancelled:
            self.database.set_failure_reason(job_id, "Cancelled by the paired client.")
        elif failure_reason:
            self.database.set_failure_reason(job_id, failure_reason)
        self.finished(job_id, succeeded)

    def _collect_progress(self, job_id: str, process: OwnedProcess) -> None:
        stream = getattr(process, "stdout", None)
        if stream is None:
            return
        try:
            for line in stream:
                if "error" in line.lower() or "failed" in line.lower() or "model not found" in line.lower():
                    with self._lock:
                        self._last_output[job_id] = (self._last_output.get(job_id, "") + line)[-4000:]
                progress = parse_progress_line(line)
                if progress is not None:
                    self.database.set_progress(job_id, progress)
        except (OSError, ValueError):
            return

    @staticmethod
    def _default_output_validator(output: Path) -> bool:
        """Publish only a non-empty media file that FFprobe can inspect."""
        if not output.is_file() or output.stat().st_size == 0:
            return False
        try:
            probe = subprocess.run(
                ["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "default=nw=1", str(output)],
                stdin=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=30,
                check=False,
            )
        except (OSError, subprocess.TimeoutExpired):
            return False
        return probe.returncode == 0
