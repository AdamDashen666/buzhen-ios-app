from __future__ import annotations

import argparse
import os
from pathlib import Path

from .server import create_server
from .storage import Storage
from .wechat_bridge import SubprocessBridgeRunner, WeChatBridge


def default_topaz_ffmpeg(program_files_roots: tuple[Path, ...] | None = None) -> Path:
    if program_files_roots is None:
        program_files_roots = tuple(
            Path(value)
            for value in (
                os.environ.get("ProgramFiles"),
                r"C:\\Program Files",
                r"D:\\Program Files",
            )
            if value
        )
    candidates = tuple(root / "Topaz Labs LLC" / "Topaz Video" / "ffmpeg.exe" for root in program_files_roots)
    return next((candidate for candidate in candidates if candidate.is_file()), candidates[0])


def configure_topaz_model_environment(data_root: Path | None = None) -> bool:
    """Match the model paths that the installed Topaz Video GUI gives its FFmpeg children."""
    root = data_root or Path(os.environ.get("ProgramData", r"C:\ProgramData")) / "Topaz Labs LLC" / "Topaz Video"
    models = root / "models"
    if not models.is_dir():
        return False
    os.environ["TVAI_MODEL_DIR"] = str(models)
    os.environ["TVAI_MODEL_DATA_DIR"] = str(root)
    return True


def main() -> int:
    parser = argparse.ArgumentParser(description="Topaz Remote Windows Agent")
    parser.add_argument("--data-dir", type=Path, default=Path.home() / "AppData/Local/TopazRemote")
    parser.add_argument("--media-dir", type=Path, default=Path.home() / "Desktop" / "远程topaz")
    parser.add_argument("--host", default="0.0.0.0"); parser.add_argument("--port", type=int, default=8123)
    default_ffmpeg = default_topaz_ffmpeg()
    parser.add_argument("--topaz-ffmpeg", type=Path, default=default_ffmpeg)
    parser.add_argument("--no-job-execution", action="store_true", help="Expose the API without launching Topaz child processes.")
    parser.add_argument("--wechat-bridge", type=Path, help="Interactive-session WeChat bridge executable; omit to disable WeChat transfer.")
    parser.add_argument("--wechat-download-root", type=Path, default=Path.home() / "Documents" / "xwechat_files")
    args = parser.parse_args()
    configure_topaz_model_environment()
    bridge = None if args.wechat_bridge is None else WeChatBridge(SubprocessBridgeRunner(args.wechat_bridge), Storage(args.data_dir, media_root=args.media_dir), args.wechat_download_root)
    server = create_server(args.data_dir, args.host, args.port, None if args.no_job_execution else args.topaz_ffmpeg, media_root=args.media_dir, wechat_bridge=bridge)
    print(f"Topaz Remote Agent listening on {args.host}:{server.server_port}")
    try: server.serve_forever()
    except KeyboardInterrupt: pass
    finally: server.server_close()
    return 0

if __name__ == "__main__": raise SystemExit(main())
