from __future__ import annotations

from pathlib import Path
from typing import Any
import json
import subprocess


class TopazValidationError(ValueError):
    pass


class TopazFfmpegAdapter:
    """Build shell-free commands from the current effective capability contract."""

    def __init__(self, executable: Path, capabilities: dict[str, Any], video_probe: Any | None = None) -> None:
        self.executable = executable
        self.enhancement = self._model_specs(capabilities.get("enhancementModels", []))
        self.denoise = self._model_specs(capabilities.get("denoiseModels", []))
        self.interpolation = self._model_specs(capabilities.get("interpolationModels", []))
        self.enhancement_metadata = {model["id"]: model for model in capabilities.get("enhancementModels", []) if isinstance(model, dict) and isinstance(model.get("id"), str) and model.get("available") is not False}
        self.video_probe = video_probe or self._video_probe

    @staticmethod
    def _model_specs(models: Any) -> dict[str, dict[str, dict[str, Any]]]:
        result: dict[str, dict[str, dict[str, Any]]] = {}
        if not isinstance(models, list):
            return result
        for model in models:
            if not isinstance(model, dict) or not isinstance(model.get("id"), str) or model.get("available") is False:
                continue
            parameter_specs: dict[str, dict[str, Any]] = {}
            for parameter in model.get("parameters", []):
                if isinstance(parameter, dict) and isinstance(parameter.get("id"), str):
                    parameter_specs[parameter["id"]] = parameter
            result[model["id"]] = parameter_specs
        return result

    @staticmethod
    def _format_value(parameter: dict[str, Any], value: Any) -> str:
        kind = parameter.get("type")
        if kind == "boolean":
            if not isinstance(value, bool):
                raise TopazValidationError("boolean parameter required")
            return "1" if value else "0"
        if kind == "enum":
            options = parameter.get("options", [])
            allowed = {item.get("value") for item in options if isinstance(item, dict)}
            if not isinstance(value, str) or value not in allowed:
                raise TopazValidationError("invalid enum parameter")
            return value
        if kind == "integer":
            if not isinstance(value, int) or isinstance(value, bool):
                raise TopazValidationError("integer parameter required")
            numeric = value
        elif kind == "number":
            if not isinstance(value, (int, float)) or isinstance(value, bool):
                raise TopazValidationError("numeric parameter required")
            numeric = float(value)
        else:
            raise TopazValidationError("unsupported parameter type")
        minimum, maximum = parameter.get("min"), parameter.get("max")
        if isinstance(minimum, (int, float)) and numeric < minimum or isinstance(maximum, (int, float)) and numeric > maximum:
            raise TopazValidationError("parameter out of range")
        return f"{numeric:g}"

    def _stage_filter(self, filter_name: str, supplied: Any, models: dict[str, dict[str, dict[str, Any]]], required: dict[str, dict[str, Any]]) -> str | None:
        if supplied is None:
            return None
        if not isinstance(supplied, dict) or not isinstance(supplied.get("model"), str):
            raise TopazValidationError("invalid stage settings")
        model = supplied["model"]
        if model not in models:
            raise TopazValidationError("unknown model")
        parts = [f"model={model}"]
        standard = dict(required)
        standard.update(models[model])
        for parameter_id, parameter in standard.items():
            if parameter_id in supplied:
                parts.append(f"{parameter_id}={self._format_value(parameter, supplied[parameter_id])}")
            elif parameter_id in required:
                default = parameter.get("default")
                if default is None:
                    raise TopazValidationError(f"missing required {parameter_id}")
                parts.append(f"{parameter_id}={self._format_value(parameter, default)}")
        permitted = {"model", *standard}
        if any(key not in permitted for key in supplied):
            raise TopazValidationError("unknown parameter")
        parts.append("download=0")
        return f"{filter_name}=" + ":".join(parts)

    @staticmethod
    def _video_probe(source: Path) -> tuple[int, int, int]:
        result = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries", "stream=width,height,nb_frames", "-of", "json", str(source)], stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True, timeout=30, check=False)
        try:
            stream = json.loads(result.stdout)["streams"][0]
            return int(stream["width"]), int(stream["height"]), int(stream.get("nb_frames") or 0)
        except (KeyError, ValueError, TypeError, json.JSONDecodeError, IndexError):
            raise TopazValidationError("unable to inspect source video frames")

    def working_directory(self, command: list[str]) -> Path:
        return Path(command[0]).parent

    @staticmethod
    def _gui_high_dynamic_h264_args() -> list[str]:
        """Match Topaz Video's Windows/NVIDIA H.264 High dynamic-quality preset."""
        return [
            "-c:v", "h264_nvenc", "-pix_fmt", "yuv420p", "-profile:v", "high", "-g", "30",
            "-preset", "p7", "-tune", "hq", "-rc", "constqp", "-qp", "18",
            "-rc-lookahead", "20", "-spatial_aq", "1", "-aq-strength", "15", "-b:v", "0",
        ]

    def _neuroserver_command(self, source: Path, output: Path, enhancement: dict[str, Any]) -> list[str]:
        model = enhancement["model"]
        metadata = self.enhancement_metadata[model]
        width, height, frames = self.video_probe(source)
        if frames < 1:
            raise TopazValidationError("source video frame count is required for neuroserver")
        scale = enhancement.get("scale", 1)
        if not isinstance(scale, int) or isinstance(scale, bool) or scale < 1 or scale > 4:
            raise TopazValidationError("invalid scale")
        return [str(self.executable.parent / "neuroserver" / "neuroserver.exe"), "--once", "--input-path", str(source), "--output-path", str(output), "--start-frame-idx", "0", "--end-frame-idx", str(frames - 1), "--ffmpeg-preproc-filters", "", "--max-gpu-mem", "12", "--filters", json.dumps([{"model": metadata["executorModel"]}], separators=(",", ":")), "--output-width", str(width * scale), "--output-height", str(height * scale), "--upscale-factor", str(scale), "--ffmpeg-encoding", " ".join(self._gui_high_dynamic_h264_args())]

    def build_command(self, source: Path, output: Path, settings: dict[str, Any]) -> list[str]:
        enhancement_settings = settings.get("enhancement")
        if isinstance(enhancement_settings, dict) and isinstance(enhancement_settings.get("model"), str):
            metadata = self.enhancement_metadata.get(enhancement_settings["model"], {})
            if metadata.get("executor") == "neuroserver":
                if settings.get("interpolation") is not None or settings.get("denoise") is not None:
                    raise TopazValidationError("neuroserver enhancement cannot be combined with denoise or interpolation")
                return self._neuroserver_command(source, output, enhancement_settings)
        enhancement = self._stage_filter(
            "tvai_up", settings.get("enhancement"), self.enhancement,
            {"scale": {"type": "integer", "min": 0, "max": 4, "default": 1}},
        )
        interpolation = self._stage_filter(
            "tvai_fi", settings.get("interpolation"), self.interpolation,
            {"fps": {"type": "number", "min": 1, "max": 480}},
        )
        denoise = self._stage_filter(
            "tvai_up", settings.get("denoise"), self.denoise,
            {"scale": {"type": "integer", "min": 1, "max": 1, "default": 1}},
        )
        filters = [value for value in (enhancement, denoise, interpolation) if value is not None]
        if not filters:
            raise TopazValidationError("at least one Topaz stage is required")
        return [str(self.executable), "-hide_banner", "-nostdin", "-y", "-i", str(source), "-vf", ",".join(filters), "-map", "0:v:0", "-map", "0:a?", *self._gui_high_dynamic_h264_args(), "-c:a", "copy", str(output)]
