from __future__ import annotations

import hashlib
import os
import re
import shutil
import uuid
from pathlib import Path


class StorageError(ValueError):
    pass


class Storage:
    def __init__(self, root: Path, media_root: Path | None = None) -> None:
        self.root = root.resolve()
        self.media_root = (media_root or self.root).resolve()
        self.uploads = self.root / "uploads"
        self.sources = self.media_root
        self.outputs = self.media_root
        self.uploads.mkdir(parents=True, exist_ok=True)
        self.media_root.mkdir(parents=True, exist_ok=True)

    def _upload_dir(self, upload_id: str) -> Path:
        if not re.fullmatch(r"[A-Za-z0-9-]{1,128}", upload_id):
            raise StorageError("invalid upload id")
        return self.uploads / upload_id

    def write_chunk(self, upload_id: str, index: int, body: bytes) -> None:
        if index < 0:
            raise StorageError("invalid chunk index")
        directory = self._upload_dir(upload_id)
        directory.mkdir(parents=True, exist_ok=True)
        temporary = directory / f"{index}.part"
        completed = directory / f"{index}.chunk"
        with temporary.open("wb") as handle:
            handle.write(body)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, completed)

    def discard_upload(self, upload_id: str) -> None:
        """Remove only the validated temporary directory for an abandoned upload."""
        directory = self._upload_dir(upload_id)
        if directory.is_dir():
            shutil.rmtree(directory)

    def stage_external_source(self, source: Path, preferred_name: str) -> Path:
        source = source.resolve()
        if not source.is_file() or source.suffix.lower() not in {".mp4", ".mov", ".m4v", ".mkv", ".avi", ".webm"}:
            raise StorageError("external source is not a supported video")
        name = Path(preferred_name).name
        if not name or name in {".", ".."}:
            raise StorageError("invalid external source filename")
        destination = self.sources / name
        if destination.exists():
            if destination.is_file() and destination.stat().st_size == source.stat().st_size:
                if self._digest(destination) == self._digest(source):
                    return destination
            destination = self.sources / f"{destination.stem}-{uuid.uuid4().hex[:8]}{destination.suffix}"
        temporary = self.sources / f".{uuid.uuid4()}.part"
        shutil.copyfile(source, temporary)
        os.replace(temporary, destination)
        return destination

    @staticmethod
    def _digest(path: Path) -> bytes:
        digest = hashlib.sha256()
        with path.open("rb") as handle:
            while data := handle.read(1024 * 1024):
                digest.update(data)
        return digest.digest()

    def complete_upload(self, upload_id: str, filename: str, expected_size: int, expected_sha256: str | None) -> Path:
        if Path(filename).name != filename or filename in {"", ".", ".."}:
            raise StorageError("invalid filename")
        destination = self.sources / filename
        if destination.exists():
            if destination.is_file() and expected_sha256 and destination.stat().st_size == expected_size:
                digest = hashlib.sha256()
                with destination.open("rb") as source:
                    while data := source.read(1024 * 1024):
                        digest.update(data)
                if digest.hexdigest().lower() == expected_sha256.lower():
                    self.discard_upload(upload_id)
                    return destination
            raise StorageError("source filename already exists")
        directory = self._upload_dir(upload_id)
        chunks = sorted(directory.glob("*.chunk"), key=lambda path: int(path.stem))
        if not chunks:
            raise StorageError("upload has no chunks")
        if [int(chunk.stem) for chunk in chunks] != list(range(len(chunks))):
            raise StorageError("upload chunk map is incomplete")
        temporary = self.sources / f".{upload_id}.part"
        digest = hashlib.sha256()
        size = 0
        with temporary.open("wb") as target:
            for chunk in chunks:
                with chunk.open("rb") as source:
                    while data := source.read(1024 * 1024):
                        target.write(data)
                        digest.update(data)
                        size += len(data)
            target.flush()
            os.fsync(target.fileno())
        if size != expected_size or (expected_sha256 and digest.hexdigest().lower() != expected_sha256.lower()):
            temporary.unlink(missing_ok=True)
            raise StorageError("upload integrity validation failed")
        os.replace(temporary, destination)
        for chunk in directory.glob("*"):
            chunk.unlink()
        directory.rmdir()
        return destination
