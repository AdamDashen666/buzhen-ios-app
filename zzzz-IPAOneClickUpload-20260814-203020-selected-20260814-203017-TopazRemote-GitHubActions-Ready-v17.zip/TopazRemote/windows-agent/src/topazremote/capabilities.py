from __future__ import annotations

from copy import deepcopy
from typing import Any


MODEL_GROUPS = ("enhancementModels", "denoiseModels", "interpolationModels")


def _models(value: dict[str, Any], group: str) -> list[dict[str, Any]]:
    models = value.get(group, [])
    if not isinstance(models, list):
        return []
    return [deepcopy(model) for model in models if isinstance(model, dict) and isinstance(model.get("id"), str)]


def _apply_override(model: dict[str, Any], override: dict[str, Any]) -> dict[str, Any] | None:
    if override.get("available") is False:
        return None

    merged = deepcopy(model)
    parameters = merged.get("parameters", [])
    parameter_map = {
        parameter["id"]: deepcopy(parameter)
        for parameter in parameters
        if isinstance(parameter, dict) and isinstance(parameter.get("id"), str)
    }
    parameter_overrides = override.get("parameters", {})
    if isinstance(parameter_overrides, dict):
        for parameter_id, parameter_override in parameter_overrides.items():
            if not isinstance(parameter_id, str) or not isinstance(parameter_override, dict):
                continue
            parameter_map[parameter_id] = {**parameter_map.get(parameter_id, {"id": parameter_id}), **parameter_override}
    merged["parameters"] = list(parameter_map.values())

    if "available" in override:
        merged["available"] = override["available"]
    for key, value in override.items():
        if key not in {"available", "parameters"}:
            merged[key] = deepcopy(value)
    if override:
        merged["source"] = "override"
    return merged


def merge_capabilities(
    detected: dict[str, Any], fallback: dict[str, Any], overrides: dict[str, Any]
) -> dict[str, Any]:
    """Combine local discovery, durable fallback, and user overrides by model ID."""
    effective: dict[str, Any] = {
        "capabilitySchemaVersion": 1,
        "source": {"mode": "mixed"},
    }
    for group in MODEL_GROUPS:
        models_by_id: dict[str, dict[str, Any]] = {}
        for model in _models(fallback, group):
            model["source"] = "fallback"
            models_by_id[model["id"]] = model
        for model in _models(detected, group):
            model["source"] = "detected"
            models_by_id[model["id"]] = model

        group_overrides = overrides.get(group, {})
        if isinstance(group_overrides, dict):
            for model_id, override in group_overrides.items():
                if model_id not in models_by_id or not isinstance(override, dict):
                    continue
                resolved = _apply_override(models_by_id[model_id], override)
                if resolved is None:
                    del models_by_id[model_id]
                else:
                    models_by_id[model_id] = resolved
        effective[group] = list(models_by_id.values())
    return effective
