from __future__ import annotations

import re
import json
import subprocess
from collections.abc import Callable
from pathlib import Path
from typing import Any


_MODEL = re.compile(r"tvai_(?P<filter>up|fi)\s*=\s*model=(?P<id>[A-Za-z0-9._-]+)", re.IGNORECASE)


def _default_help_reader(executable: Path) -> str:
    return subprocess.run(
        [str(executable), "-hide_banner", "-h", "filter=tvai_up"],
        cwd=str(executable.parent),
        stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=15,
        check=False,
    ).stdout + "\n" + subprocess.run(
        [str(executable), "-hide_banner", "-h", "filter=tvai_fi"],
        cwd=str(executable.parent),
        stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=15,
        check=False,
    ).stdout


def _filter_support(help_text: str) -> dict[str, Any]:
    support: dict[str, Any] = {}
    if "tvai_up" in help_text:
        support["tvai_up"] = {"scale": {"min": 0, "max": 4, "type": "integer"}}
    if "tvai_fi" in help_text:
        support["tvai_fi"] = {"fps": {"min": 1, "max": 480, "type": "number"}, "slowmo": {"min": 0.1, "max": 16, "type": "number"}}
    return support


def _models_from_logs(logs_root: Path, group: str, filter_name: str, parameters: list[dict[str, Any]]) -> list[dict[str, Any]]:
    if not logs_root.is_dir():
        return []
    ids: set[str] = set()
    try:
        paths = logs_root.rglob("*.tzlog")
        for path in paths:
            try:
                for match in _MODEL.finditer(path.read_text(encoding="utf-8", errors="replace")):
                    if match.group("filter").lower() == filter_name:
                        ids.add(match.group("id"))
            except OSError:
                continue
    except OSError:
        return []
    # Export logs establish a command shape, but Topaz can later remove a model
    # package. Do not advertise it to a client until a local probe verifies it.
    return [{"id": model_id, "displayName": model_id, "available": False, "parameters": parameters, "source": "detected-log"} for model_id in sorted(ids)]


def _neuroserver_models(executable: Path, model_config_root: Path) -> list[dict[str, Any]]:
    neuroserver = executable.parent / "neuroserver" / "neuroserver.exe"
    installed_root = neuroserver.parent / "models"
    if not neuroserver.is_file() or not installed_root.is_dir() or not model_config_root.is_dir():
        return []
    models: list[dict[str, Any]] = []
    for path in model_config_root.glob("*.json"):
        try:
            config = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        if not isinstance(config, dict) or config.get("isNeuroserverModel") is not True:
            continue
        model_id = path.stem
        executor_model = {"slp-2.5": "slp-25"}.get(model_id, model_id)
        installed_directory = {"slp-2.5": "slp25"}.get(model_id, executor_model.replace("-", ""))
        if not (installed_root / installed_directory).is_dir():
            continue
        display_name = config.get("name") if isinstance(config.get("name"), str) else model_id
        models.append({
            "id": model_id, "displayName": display_name, "available": True,
            "parameters": [{"id": "scale", "displayName": "Scale", "type": "integer", "min": 1, "max": 4}],
            "executor": "neuroserver", "executorModel": executor_model,
        })
    return sorted(models, key=lambda model: model["id"])


def _legacy_interpolation_models(
    model_config_root: Path, model_data_root: Path, parameters: list[dict[str, Any]]
) -> list[dict[str, Any]]:
    """Discover installed tvai_fi packages from their local Topaz payload files."""
    if not model_config_root.is_dir() or not model_data_root.is_dir():
        return []
    models: list[dict[str, Any]] = []
    for path in model_config_root.glob("*.json"):
        try:
            config = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        if not isinstance(config, dict) or not config.get("changesFPS"):
            continue
        short_name = config.get("shortName")
        version = config.get("version")
        if not isinstance(short_name, str) or not isinstance(version, (str, int)):
            continue
        pattern = f"{short_name}-v{version}-*.tz*"
        try:
            installed = any(
                candidate.is_file() and candidate.suffix.lower() in {".tz", ".tz3"}
                for candidate in model_data_root.rglob(pattern)
            )
        except OSError:
            installed = False
        if not installed:
            continue
        display_name = config.get("displayName") or config.get("name") or path.stem
        models.append({
            "id": path.stem, "displayName": display_name if isinstance(display_name, str) else path.stem,
            "available": True, "parameters": parameters, "source": "installed-payload",
        })
    return sorted(models, key=lambda model: model["id"])


def _nyx_denoise_models(model_config_root: Path, model_data_root: Path) -> list[dict[str, Any]]:
    """Expose Nyx only when the configured Nyx 3 payload is actually installed."""
    path = model_config_root / "nyx-3.json"
    if not path.is_file() or not model_data_root.is_dir():
        return []
    try:
        config = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return []
    if not isinstance(config, dict) or config.get("shortName") != "nyx" or str(config.get("version")) != "3":
        return []
    try:
        installed = any(candidate.is_file() and candidate.suffix.lower() in {".tz", ".tz3"} for candidate in model_data_root.rglob("nyx-v3-*.tz*"))
    except OSError:
        installed = False
    if not installed:
        return []
    parameter = next((value for value in config.get("parameters", []) if isinstance(value, dict) and value.get("name") == "noise"), {})
    gui = config.get("gui")
    display_name = config.get("displayName") or (gui.get("name") if isinstance(gui, dict) else None) or "Nyx"
    return [{
        "id": "nyx-3", "displayName": display_name if isinstance(display_name, str) else "Nyx", "available": True,
        "parameters": [
            {"id": "scale", "displayName": "Scale", "type": "integer", "min": 1, "max": 1, "default": 1},
            {
                "id": "noise", "displayName": parameter.get("guiName") if isinstance(parameter.get("guiName"), str) else "Reduce Noise",
                "type": "number", "min": parameter.get("min", 0), "max": parameter.get("max", 1), "default": parameter.get("default", 0.5),
            },
        ],
        "source": "installed-payload",
    }]


def _unique_models(*model_lists: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Keep the first observation of a model, preferring local installation evidence."""
    models_by_id: dict[str, dict[str, Any]] = {}
    for models in model_lists:
        for model in models:
            model_id = model.get("id")
            if isinstance(model_id, str) and model_id not in models_by_id:
                models_by_id[model_id] = model
    return list(models_by_id.values())


def discover_capabilities(
    executable: Path,
    logs_root: Path | None = None,
    help_reader: Callable[[Path], str] | None = None,
    model_config_root: Path | None = None,
    model_data_root: Path | None = None,
) -> dict[str, Any]:
    """Read local Topaz filter support and observed model IDs without changing Topaz state."""
    reader = help_reader or _default_help_reader
    try:
        help_text = reader(executable)
    except (OSError, subprocess.SubprocessError):
        help_text = ""
    support = _filter_support(help_text)
    logs = logs_root or Path.home() / "AppData/Roaming/Topaz Labs LLC/Topaz Video/logs"
    config_root = model_config_root or Path(r"C:\\ProgramData\\Topaz Labs LLC\\Topaz Video\\models")
    data_root = model_data_root or config_root.parent
    enhancement_parameters: list[dict[str, Any]] = []
    interpolation_parameters: list[dict[str, Any]] = []
    if "tvai_up" in support:
        scale = support["tvai_up"]["scale"]
        enhancement_parameters.append({"id": "scale", "displayName": "Scale", **scale})
    if "tvai_fi" in support:
        fps = support["tvai_fi"]["fps"]
        interpolation_parameters.append({"id": "fps", "displayName": "Output FPS", **fps})
    return {
        "capabilitySchemaVersion": 1,
        "filterSupport": support,
        "enhancementModels": _unique_models(
            _neuroserver_models(executable, config_root),
            _models_from_logs(logs, "enhancementModels", "up", enhancement_parameters),
        ),
        "denoiseModels": _nyx_denoise_models(config_root, data_root),
        "interpolationModels": _unique_models(
            _legacy_interpolation_models(config_root, data_root, interpolation_parameters),
            _models_from_logs(logs, "interpolationModels", "fi", interpolation_parameters),
        ),
    }
