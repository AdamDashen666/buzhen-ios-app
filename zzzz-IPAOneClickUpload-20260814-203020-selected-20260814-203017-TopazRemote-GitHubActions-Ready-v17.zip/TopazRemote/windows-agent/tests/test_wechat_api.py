from __future__ import annotations

import json
import sys
import tempfile
import threading
import time
import unittest
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from topazremote.server import create_server
from topazremote.wechat_bridge import WeChatImportResult


class FakeBridge:
    def import_latest(self) -> WeChatImportResult:
        return WeChatImportResult("ready", "clip.mov", {"fileName":"clip.mov", "fileExtension":"MOV", "codec":"H.264", "width":1920, "height":1080, "frameRate":60.0, "duration":1.0, "fileSize":5})
    def send_output(self, output: Path) -> WeChatImportResult:
        return WeChatImportResult("sent")


class FailingBridge(FakeBridge):
    def import_latest(self) -> WeChatImportResult:
        raise ValueError("ffprobe could not read the staged video")

    def send_output(self, output: Path) -> WeChatImportResult:
        return WeChatImportResult("send_failed", error="WeChat file picker did not open")


class WeChatApiTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory(); root = Path(self.temp.name)
        self.server = create_server(root, "127.0.0.1", 0, media_root=root / "media", wechat_bridge=FakeBridge())
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True); self.thread.start()
        self.base = f"http://127.0.0.1:{self.server.server_port}/api/v1"; self.headers = {"Authorization": f"Bearer {self.server.token}", "Content-Type":"application/json"}
    def tearDown(self) -> None:
        self.server.shutdown(); self.server.server_close(); self.temp.cleanup()

    def test_import_is_authenticated_and_persists_ready_metadata(self) -> None:
        with self.assertRaises(HTTPError) as error: urlopen(Request(self.base + "/wechat/imports/latest", data=b"{}", method="POST"))
        self.assertEqual(error.exception.code, 401)
        with urlopen(Request(self.base + "/wechat/imports/latest", data=b"{}", headers=self.headers, method="POST")) as response: ticket = json.load(response)
        self.assertEqual(ticket["state"], "downloading")
        for _ in range(20):
            with urlopen(Request(self.base + f"/wechat/imports/{ticket['id']}", headers=self.headers)) as response: result = json.load(response)
            if result["state"] != "downloading": break
            time.sleep(.01)
        self.assertEqual(result["state"], "ready"); self.assertEqual(result["sourceFilename"], "clip.mov"); self.assertEqual(result["videoInfo"]["width"], 1920)

    def test_completed_wechat_job_can_retry_delivery_without_changing_completion(self) -> None:
        output = self.server.storage.outputs / "finished.mp4"; output.write_bytes(b"video")
        job_id = self.server.database.create_job("clip.mov", {}, "wechat")
        self.server.database.set_output_path(job_id, output)
        with urlopen(Request(self.base + f"/jobs/{job_id}/wechat-send", data=b"{}", headers=self.headers, method="POST")) as response: queued = json.load(response)
        self.assertEqual(queued["status"], "completed")
        for _ in range(20):
            with urlopen(Request(self.base + f"/jobs/{job_id}", headers=self.headers)) as response: job = json.load(response)
            if job["delivery"]["state"] == "sent": break
            time.sleep(.01)
        self.assertEqual(job["status"], "completed"); self.assertEqual(job["delivery"]["state"], "sent")

    def test_import_failure_finishes_ticket_and_send_failure_stays_retryable(self) -> None:
        self.server.shutdown(); self.server.server_close()
        root = Path(self.temp.name)
        self.server = create_server(root, "127.0.0.1", 0, media_root=root / "media", wechat_bridge=FailingBridge())
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True); self.thread.start()
        self.base = f"http://127.0.0.1:{self.server.server_port}/api/v1"; self.headers = {"Authorization": f"Bearer {self.server.token}", "Content-Type":"application/json"}
        with urlopen(Request(self.base + "/wechat/imports/latest", data=b"{}", headers=self.headers, method="POST")) as response: ticket = json.load(response)
        for _ in range(20):
            with urlopen(Request(self.base + f"/wechat/imports/{ticket['id']}", headers=self.headers)) as response: result = json.load(response)
            if result["state"] != "downloading": break
            time.sleep(.01)
        self.assertEqual(result["state"], "download_failed")
        output = self.server.storage.outputs / "finished.mp4"; output.write_bytes(b"video")
        job_id = self.server.database.create_job("clip.mov", {}, "wechat"); self.server.database.set_output_path(job_id, output)
        with urlopen(Request(self.base + f"/jobs/{job_id}/wechat-send", data=b"{}", headers=self.headers, method="POST")):
            pass
        for _ in range(20):
            with urlopen(Request(self.base + f"/jobs/{job_id}", headers=self.headers)) as response: job = json.load(response)
            if job["delivery"]["state"] != "sending": break
            time.sleep(.01)
        self.assertEqual(job["status"], "completed"); self.assertEqual(job["delivery"]["state"], "send_failed")


if __name__ == "__main__": unittest.main()
