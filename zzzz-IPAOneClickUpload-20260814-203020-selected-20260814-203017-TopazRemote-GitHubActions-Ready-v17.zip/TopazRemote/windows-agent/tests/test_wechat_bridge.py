from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from topazremote.storage import Storage
from topazremote.wechat_bridge import WeChatBridge


class FakeRunner:
    def __init__(self, result: dict[str, object]) -> None:
        self.result, self.calls = result, []
    def run(self, request: dict[str, object]) -> dict[str, object]:
        self.calls.append(request); return self.result


class WeChatBridgeTests(unittest.TestCase):
    def test_rejects_ready_file_outside_wechat_root_without_copying(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary); outside = root / "outside.mov"; outside.write_bytes(b"not-a-video")
            runner = FakeRunner({"state": "ready", "filename": outside.name, "filePath": str(outside)})
            bridge = WeChatBridge(runner, Storage(root / "agent"), root / "wechat")
            result = bridge.import_latest()
            self.assertEqual(result.state, "unsupported_file")
            self.assertFalse((root / "agent" / outside.name).exists())

    def test_not_downloaded_requests_download_only_after_inspection(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary); runner = FakeRunner({"state": "not_downloaded"})
            bridge = WeChatBridge(runner, Storage(root / "agent"), root / "wechat")
            result = bridge.import_latest()
            self.assertEqual(result.state, "not_downloaded")
            self.assertEqual([call["command"] for call in runner.calls], ["inspect-latest", "download-latest"])

    def test_send_passes_only_agent_owned_output_root_to_helper(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary); storage = Storage(root / "agent")
            output = storage.outputs / "finished.mp4"; output.write_bytes(b"video")
            runner = FakeRunner({"state": "sent"})
            result = WeChatBridge(runner, storage, root / "wechat").send_output(output)
            self.assertEqual(result.state, "sent")
            self.assertEqual(runner.calls[0]["mediaRoot"], str(storage.outputs.resolve()))


if __name__ == "__main__":
    unittest.main()
