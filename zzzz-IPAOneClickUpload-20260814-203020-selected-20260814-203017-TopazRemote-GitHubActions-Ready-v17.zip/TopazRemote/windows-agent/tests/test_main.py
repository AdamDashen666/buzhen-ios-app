from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from topazremote.main import configure_topaz_model_environment, default_topaz_ffmpeg


class MainTests(unittest.TestCase):
    def test_default_topaz_ffmpeg_uses_an_installed_non_system_drive(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            c_program_files = root / "C" / "Program Files"
            d_program_files = root / "D" / "Program Files"
            installed = d_program_files / "Topaz Labs LLC" / "Topaz Video" / "ffmpeg.exe"
            installed.parent.mkdir(parents=True)
            installed.write_bytes(b"ffmpeg")

            self.assertEqual(default_topaz_ffmpeg((c_program_files, d_program_files)), installed)

    def test_configures_topaz_model_environment_for_child_ffmpeg(self) -> None:
        """A scheduled Agent must pass Topaz's model locations to its child FFmpeg process."""
        with tempfile.TemporaryDirectory() as temp, patch.dict("os.environ", {}, clear=True):
            data_root = Path(temp) / "Topaz Video"
            (data_root / "models").mkdir(parents=True)

            self.assertTrue(configure_topaz_model_environment(data_root))

            self.assertEqual(Path(__import__("os").environ["TVAI_MODEL_DIR"]), data_root / "models")
            self.assertEqual(Path(__import__("os").environ["TVAI_MODEL_DATA_DIR"]), data_root)
