using System.Text.Json;
using System.IO;
using System.Text.RegularExpressions;
using System.Windows.Automation;

record BridgeRequest(string Command, string? DownloadRoot, string? FilePath, string? MediaRoot = null, int TimeoutSeconds = 120);
record BridgeResult(string State, string? Filename = null, string? FilePath = null, string? Error = null);
record FileMessage(AutomationElement Item, string Filename, long? SizeBytes);

static class Program
{
    private static readonly JsonSerializerOptions Json = new() { PropertyNamingPolicy = JsonNamingPolicy.CamelCase };
    private static readonly HashSet<string> Commands = new(StringComparer.Ordinal) { "inspect-latest", "download-latest", "send-output" };
    private static readonly string[] VideoExtensions = [".mp4", ".mov", ".m4v", ".mkv", ".avi", ".webm"];
    private const string WeChat = "\u5fae\u4fe1";
    private const string Assistant = "\u6587\u4ef6\u4f20\u8f93\u52a9\u624b";
    private const string NotDownloaded = "\u672a\u4e0b\u8f7d";
    private const string SendFile = "\u53d1\u9001\u6587\u4ef6";
    private const string Open = "\u6253\u5f00";

    [STAThread]
    static int Main()
    {
        try
        {
            var line = Console.In.ReadLine();
            var request = line is null ? null : JsonSerializer.Deserialize<BridgeRequest>(line, Json);
            if (request is null || !Commands.Contains(request.Command)) return Write(new BridgeResult("ui_changed", Error: "A supported bridge command is required."));
            if (request.TimeoutSeconds is < 1 or > 300) return Write(new BridgeResult("ui_changed", Error: "timeoutSeconds must be between 1 and 300."));
            if (request.Command == "send-output" && (string.IsNullOrWhiteSpace(request.FilePath) || string.IsNullOrWhiteSpace(request.MediaRoot))) return Write(new BridgeResult("send_failed", Error: "filePath and mediaRoot are required for send-output."));
            return request.Command switch
            {
                "inspect-latest" => Write(InspectLatest(request)),
                "download-latest" => Write(DownloadLatest(request)),
                "send-output" => Write(SendOutput(request)),
                _ => Write(new BridgeResult("ui_changed", Error: "Unsupported command.")),
            };
        }
        catch (JsonException) { return Write(new BridgeResult("ui_changed", Error: "Request must be one JSON object.")); }
        catch (Exception error) { return Write(new BridgeResult("ui_changed", Error: error.Message)); }
    }

    private static int Write(BridgeResult result) { Console.Out.WriteLine(JsonSerializer.Serialize(result, Json)); return 0; }

    private static BridgeResult InspectLatest(BridgeRequest request)
    {
        var window = WeChatWindow();
        if (window is null) return new BridgeResult("wechat_not_logged_in", Error: "No logged-in WeChat desktop window was found.");
        var selected = SelectAssistant(window);
        if (selected is not null) return selected;
        var message = LatestVideo(window);
        if (message is null) return new BridgeResult("not_found", Error: "No eligible video is visible in File Transfer Assistant.");
        if (message.Item.Current.Name.Contains(NotDownloaded, StringComparison.Ordinal)) return new BridgeResult("not_downloaded", message.Filename);
        if (!string.IsNullOrWhiteSpace(request.DownloadRoot) && Directory.Exists(request.DownloadRoot)) return FindDownloaded(request.DownloadRoot, message.Filename, message.SizeBytes) ?? new BridgeResult("download_failed", message.Filename, Error: "WeChat marks the file downloaded but no matching local file was found.");
        return new BridgeResult("download_failed", message.Filename, Error: "WeChat download root is unavailable.");
    }

    private static AutomationElement? WeChatWindow() => AutomationElement.RootElement.FindFirst(TreeScope.Subtree, new PropertyCondition(AutomationElement.NameProperty, WeChat));

    private static BridgeResult? SelectAssistant(AutomationElement window)
    {
        var assistant = window.FindFirst(TreeScope.Subtree, new PropertyCondition(AutomationElement.AutomationIdProperty, "session_item_" + Assistant));
        if (assistant is null || !assistant.TryGetCurrentPattern(InvokePattern.Pattern, out var select)) return new BridgeResult("ui_changed", Error: "File Transfer Assistant selection is unavailable.");
        ((InvokePattern)select).Invoke();
        var until = DateTime.UtcNow.AddSeconds(3);
        while (DateTime.UtcNow < until)
        {
            if (window.FindFirst(TreeScope.Subtree, new PropertyCondition(AutomationElement.AutomationIdProperty, "chat_message_list")) is not null) return null;
            Thread.Sleep(100);
        }
        return new BridgeResult("ui_changed", Error: "WeChat did not open File Transfer Assistant.");
    }

    private static FileMessage? LatestVideo(AutomationElement window)
    {
        var messages = window.FindFirst(TreeScope.Subtree, new PropertyCondition(AutomationElement.AutomationIdProperty, "chat_message_list"));
        if (messages is null) return null;
        var items = messages.FindAll(TreeScope.Subtree, new PropertyCondition(AutomationElement.ControlTypeProperty, ControlType.ListItem));
        for (var index = items.Count - 1; index >= 0; index--)
        {
            var match = Regex.Match(items[index].Current.Name ?? string.Empty, @"(?:\u6587\u4ef6|File)\s+(?<name>[^\r\n]+?\.(mp4|mov|m4v|mkv|avi|webm))\b", RegexOptions.IgnoreCase);
            if (match.Success) return new FileMessage(items[index], match.Groups["name"].Value, DisplayedFileSize(items[index].Current.Name ?? string.Empty));
        }
        return null;
    }

    private static BridgeResult DownloadLatest(BridgeRequest request)
    {
        if (string.IsNullOrWhiteSpace(request.DownloadRoot) || !Directory.Exists(request.DownloadRoot)) return new BridgeResult("download_failed", Error: "Configured WeChat download root does not exist.");
        var window = WeChatWindow();
        if (window is null) return new BridgeResult("wechat_not_logged_in", Error: "WeChat desktop window is unavailable in this interactive session.");
        var selected = SelectAssistant(window);
        if (selected is not null) return selected;
        var message = LatestVideo(window);
        if (message is null) return new BridgeResult("not_found", Error: "No eligible video is visible in File Transfer Assistant.");
        if (!message.Item.Current.Name.Contains(NotDownloaded, StringComparison.Ordinal)) return FindDownloaded(request.DownloadRoot, message.Filename, message.SizeBytes) ?? new BridgeResult("download_failed", message.Filename, Error: "WeChat marks the file downloaded but no matching local file was found.");
        if (!message.Item.TryGetCurrentPattern(InvokePattern.Pattern, out var pattern)) return new BridgeResult("ui_changed", message.Filename, Error: "The newest WeChat file has no invoke action.");
        var requestedAt = DateTime.UtcNow;
        ((InvokePattern)pattern).Invoke();
        var until = DateTime.UtcNow.AddSeconds(request.TimeoutSeconds);
        while (DateTime.UtcNow < until)
        {
            var found = FindDownloaded(request.DownloadRoot, message.Filename, message.SizeBytes, requestedAt);
            if (found is not null) return found;
            Thread.Sleep(1000);
        }
        return new BridgeResult("download_failed", message.Filename, Error: "WeChat did not finish downloading the latest file before timeout.");
    }

    private static BridgeResult? FindDownloaded(string root, string filename, long? expectedSize, DateTime? modifiedAfter = null)
    {
        try
        {
            var candidate = Directory.EnumerateFiles(root, filename, SearchOption.AllDirectories)
                .Where(path => !modifiedAfter.HasValue || File.GetLastWriteTimeUtc(path) >= modifiedAfter.Value)
                .Where(path => !expectedSize.HasValue || SizeMatches(path, expectedSize.Value))
                .OrderByDescending(File.GetLastWriteTimeUtc).FirstOrDefault();
            return candidate is null ? null : new BridgeResult("ready", filename, Path.GetFullPath(candidate));
        }
        catch (UnauthorizedAccessException) { return null; }
    }

    private static long? DisplayedFileSize(string name)
    {
        var match = Regex.Match(name, @"(?<size>\d+(?:\.\d+)?)\s*(?<unit>KB|MB|GB)\b", RegexOptions.IgnoreCase);
        if (!match.Success || !double.TryParse(match.Groups["size"].Value, System.Globalization.NumberStyles.AllowDecimalPoint, System.Globalization.CultureInfo.InvariantCulture, out var value)) return null;
        var multiplier = match.Groups["unit"].Value.ToUpperInvariant() switch { "KB" => 1_000d, "MB" => 1_000_000d, "GB" => 1_000_000_000d, _ => 0d };
        return multiplier == 0 ? null : (long)Math.Round(value * multiplier);
    }

    private static bool SizeMatches(string path, long expectedSize)
    {
        var actual = new FileInfo(path).Length;
        return Math.Abs(actual - expectedSize) <= Math.Max(1_000_000, expectedSize * 0.05);
    }

    private static BridgeResult SendOutput(BridgeRequest request)
    {
        var path = Path.GetFullPath(request.FilePath!);
        if (!IsOwnedOutput(path, request.MediaRoot!) || !File.Exists(path) || !VideoExtensions.Contains(Path.GetExtension(path), StringComparer.OrdinalIgnoreCase)) return new BridgeResult("send_failed", Error: "Only an Agent-owned completed video can be sent.");
        var window = WeChatWindow();
        if (window is null) return new BridgeResult("wechat_not_logged_in", Error: "WeChat desktop window is unavailable in this interactive session.");
        var selected = SelectAssistant(window);
        if (selected is not null) return selected;
        var previousCount = MessageCount(window, Path.GetFileName(path));
        var button = window.FindFirst(TreeScope.Subtree, new AndCondition(new PropertyCondition(AutomationElement.ControlTypeProperty, ControlType.Button), new PropertyCondition(AutomationElement.NameProperty, SendFile)));
        if (button is null || !button.TryGetCurrentPattern(InvokePattern.Pattern, out var invoke)) return new BridgeResult("ui_changed", Error: "WeChat Send File button is unavailable.");
        ((InvokePattern)invoke).Invoke();
        var dialogUntil = DateTime.UtcNow.AddSeconds(10); AutomationElement? dialog = null;
        while (DateTime.UtcNow < dialogUntil && dialog is null)
        {
            dialog = AutomationElement.RootElement.FindFirst(TreeScope.Subtree, new AndCondition(new PropertyCondition(AutomationElement.ControlTypeProperty, ControlType.Window), new PropertyCondition(AutomationElement.NameProperty, Open)));
            Thread.Sleep(200);
        }
        if (dialog is null) return new BridgeResult("send_failed", Error: "WeChat file picker did not open.");
        var edit = dialog.FindFirst(TreeScope.Subtree, new PropertyCondition(AutomationElement.ControlTypeProperty, ControlType.Edit));
        var open = dialog.FindFirst(TreeScope.Subtree, new AndCondition(new PropertyCondition(AutomationElement.ControlTypeProperty, ControlType.Button), new PropertyCondition(AutomationElement.NameProperty, Open)));
        if (edit is null || open is null || !edit.TryGetCurrentPattern(ValuePattern.Pattern, out var value) || !open.TryGetCurrentPattern(InvokePattern.Pattern, out var openInvoke)) return new BridgeResult("ui_changed", Error: "Windows file picker controls are unavailable.");
        ((ValuePattern)value).SetValue(path); ((InvokePattern)openInvoke).Invoke();
        var until = DateTime.UtcNow.AddSeconds(request.TimeoutSeconds);
        while (DateTime.UtcNow < until)
        {
            if (MessageCount(window, Path.GetFileName(path)) > previousCount) return new BridgeResult("sent", Path.GetFileName(path));
            Thread.Sleep(500);
        }
        return new BridgeResult("send_failed", Error: "WeChat did not confirm the output in File Transfer Assistant before timeout.");
    }

    private static int MessageCount(AutomationElement window, string filename)
    {
        var messages = window.FindFirst(TreeScope.Subtree, new PropertyCondition(AutomationElement.AutomationIdProperty, "chat_message_list"));
        if (messages is null) return 0;
        return messages.FindAll(TreeScope.Subtree, new PropertyCondition(AutomationElement.ControlTypeProperty, ControlType.ListItem))
            .Cast<AutomationElement>().Count(item => item.Current.Name?.Contains(filename, StringComparison.OrdinalIgnoreCase) == true);
    }

    private static bool IsOwnedOutput(string path, string root)
    {
        try
        {
            var rootPath = Path.GetFullPath(root).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar) + Path.DirectorySeparatorChar;
            return path.StartsWith(rootPath, StringComparison.OrdinalIgnoreCase);
        }
        catch (Exception) { return false; }
    }
}
