import Combine
import Foundation

enum DownloadProgress {
    static func fraction(written: Int64, expected: Int64) -> Double? {
        guard expected > 0 else { return nil }
        return min(1, max(0, Double(written) / Double(expected)))
    }
}

enum OutputDownloadState: Equatable {
    case idle
    case downloading(progress: Double?)
    case completed(URL)
    case failed(String)
}

final class DownloadCoordinator: NSObject, ObservableObject {
    static let backgroundSessionIdentifier = "com.local.topazremote.output-downloads"
    static let shared = DownloadCoordinator()
    private static let activeJobIDsKey = "TopazRemote.activeOutputDownloadJobIDs"

    @Published private var states: [String: OutputDownloadState] = [:]
    private var backgroundEventsCompletionHandler: (() -> Void)?

    private lazy var session: URLSession = {
        let configuration = URLSessionConfiguration.background(withIdentifier: Self.backgroundSessionIdentifier)
        configuration.sessionSendsLaunchEvents = true
        configuration.isDiscretionary = false
        configuration.timeoutIntervalForRequest = AgentClient.agentSession.configuration.timeoutIntervalForRequest
        configuration.timeoutIntervalForResource = AgentClient.agentSession.configuration.timeoutIntervalForResource
        return URLSession(configuration: configuration, delegate: self, delegateQueue: OperationQueue.main)
    }()

    private override init() {
        super.init()
        _ = session
        restoreExistingDownloads()
    }

    func downloadState(for jobID: String) -> OutputDownloadState {
        if let state = states[jobID] { return state }
        let output = savedOutputURL(for: jobID)
        if FileManager.default.fileExists(atPath: output.path) { return .completed(output) }
        return activeJobIDs.contains(jobID) ? .downloading(progress: nil) : .idle
    }

    func startDownload(jobID: String, client: AgentClient) throws {
        if case .downloading = downloadState(for: jobID) { return }

        let task = session.downloadTask(with: try client.outputRequest(jobID: jobID))
        task.taskDescription = jobID
        markDownloadActive(jobID)
        states[jobID] = .downloading(progress: nil)
        task.resume()
    }

    func handleBackgroundEvents(for identifier: String, completionHandler: @escaping () -> Void) {
        guard identifier == Self.backgroundSessionIdentifier else {
            completionHandler()
            return
        }
        backgroundEventsCompletionHandler = completionHandler
    }

    private func restoreExistingDownloads() {
        session.getAllTasks { [weak self] tasks in
            DispatchQueue.main.async {
                guard let self else { return }
                var restoredJobIDs = Set<String>()
                for task in tasks where task.state == .running || task.state == .suspended {
                    guard let jobID = Self.jobID(for: task) else { continue }
                    restoredJobIDs.insert(jobID)
                    self.states[jobID] = .downloading(
                        progress: DownloadProgress.fraction(
                            written: task.countOfBytesReceived,
                            expected: task.countOfBytesExpectedToReceive
                        )
                    )
                }
                for jobID in self.activeJobIDs where !restoredJobIDs.contains(jobID) {
                    self.markDownloadInactive(jobID)
                }
            }
        }
    }

    private static func jobID(for task: URLSessionTask) -> String? {
        if let taskDescription = task.taskDescription, !taskDescription.isEmpty { return taskDescription }
        let pathComponents = task.originalRequest?.url?.pathComponents ?? []
        guard let jobsIndex = pathComponents.firstIndex(of: "jobs"), pathComponents.count > jobsIndex + 1 else { return nil }
        return pathComponents[jobsIndex + 1]
    }

    private func savedOutputURL(for jobID: String) -> URL {
        let directory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        return directory.appendingPathComponent("TopazRemote-\(jobID).mp4")
    }

    private var activeJobIDs: Set<String> {
        Set(UserDefaults.standard.stringArray(forKey: Self.activeJobIDsKey) ?? [])
    }

    private func markDownloadActive(_ jobID: String) {
        var jobIDs = activeJobIDs
        jobIDs.insert(jobID)
        UserDefaults.standard.set(jobIDs.sorted(), forKey: Self.activeJobIDsKey)
    }

    private func markDownloadInactive(_ jobID: String) {
        var jobIDs = activeJobIDs
        jobIDs.remove(jobID)
        UserDefaults.standard.set(jobIDs.sorted(), forKey: Self.activeJobIDsKey)
    }
}

extension DownloadCoordinator: URLSessionDownloadDelegate {
    func urlSession(
        _ session: URLSession,
        downloadTask: URLSessionDownloadTask,
        didWriteData bytesWritten: Int64,
        totalBytesWritten: Int64,
        totalBytesExpectedToWrite: Int64
    ) {
        guard let jobID = Self.jobID(for: downloadTask) else { return }
        states[jobID] = .downloading(
            progress: DownloadProgress.fraction(written: totalBytesWritten, expected: totalBytesExpectedToWrite)
        )
    }

    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didFinishDownloadingTo location: URL) {
        guard let jobID = Self.jobID(for: downloadTask) else { return }
        let statusCode = (downloadTask.response as? HTTPURLResponse)?.statusCode ?? -1
        guard statusCode == 200 || statusCode == 206 else {
            states[jobID] = .failed("The PC returned HTTP \(statusCode).")
            markDownloadInactive(jobID)
            return
        }

        let destination = savedOutputURL(for: jobID)
        do {
            try? FileManager.default.removeItem(at: destination)
            try FileManager.default.moveItem(at: location, to: destination)
            states[jobID] = .completed(destination)
            markDownloadInactive(jobID)
        } catch {
            states[jobID] = .failed(error.localizedDescription)
            markDownloadInactive(jobID)
        }
    }

    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        guard let jobID = Self.jobID(for: task), let error else { return }
        states[jobID] = .failed(error.localizedDescription)
        markDownloadInactive(jobID)
    }

    func urlSessionDidFinishEvents(forBackgroundURLSession session: URLSession) {
        guard session.configuration.identifier == Self.backgroundSessionIdentifier else { return }
        let completionHandler = backgroundEventsCompletionHandler
        backgroundEventsCompletionHandler = nil
        completionHandler?()
    }
}
