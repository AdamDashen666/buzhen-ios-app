import AVFoundation
import Foundation

struct AgentSettings: Hashable {
    var host: String
    var port: Int
    var token: String

    init(host: String = "", port: Int = 8123, token: String = "") {
        self.host = host
        self.port = port
        self.token = token
    }
}

struct CapabilityResponse: Codable {
    let apiVersion: String
    let agentVersion: String
    let capabilitySchemaVersion: Int
    let enhancementModels: [TopazModel]
    let denoiseModels: [TopazModel]
    let interpolationModels: [TopazModel]

    enum CodingKeys: String, CodingKey { case apiVersion, agentVersion, capabilitySchemaVersion, enhancementModels, denoiseModels, interpolationModels }
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        apiVersion = try values.decode(String.self, forKey: .apiVersion)
        agentVersion = try values.decode(String.self, forKey: .agentVersion)
        capabilitySchemaVersion = try values.decode(Int.self, forKey: .capabilitySchemaVersion)
        enhancementModels = try values.decode([TopazModel].self, forKey: .enhancementModels)
        denoiseModels = try values.decodeIfPresent([TopazModel].self, forKey: .denoiseModels) ?? []
        interpolationModels = try values.decode([TopazModel].self, forKey: .interpolationModels)
    }
}
struct TopazModel: Codable, Identifiable, Hashable { let id: String; let displayName: String; let available: Bool?; let parameters: [CapabilityParameter] }
struct CapabilityParameter: Codable, Identifiable, Hashable { let id: String; let displayName: String?; let type: String; let min: Double?; let max: Double?; let step: Double?; let `default`: ParameterValue?; let options: [ParameterOption]? }
struct ParameterOption: Codable, Hashable { let value: String; let label: String }

enum ParameterValue: Codable, Hashable {
    case string(String), number(Double), bool(Bool)
    init(from decoder: Decoder) throws { let container = try decoder.singleValueContainer(); if let value = try? container.decode(Bool.self) { self = .bool(value) } else if let value = try? container.decode(Double.self) { self = .number(value) } else { self = .string(try container.decode(String.self)) } }
    func encode(to encoder: Encoder) throws { var container = encoder.singleValueContainer(); switch self { case .string(let value): try container.encode(value); case .number(let value): try container.encode(value); case .bool(let value): try container.encode(value) } }
}

enum SourceRoute: String, CaseIterable, Identifiable { case tailscale, wechat; var id: String { rawValue } }
struct Delivery: Codable, Hashable { let route: String; let state: String?; let error: String? }
struct Job: Codable, Identifiable, Hashable { let id: String; let status: String; let sourceFilename: String?; let outputFilename: String?; let progress: JobProgress?; let failureReason: String?; let delivery: Delivery? }
struct JobProgress: Codable, Hashable { let stage: String?; let overallProgress: Double?; let fps: Double?; let etaSeconds: Int? }
struct UploadTicket: Codable { let id: String; let chunkSize: Int }
struct UploadStatus: Codable { let id: String; let filename: String; let size: Int; let receivedChunks: [Int] }
struct CompletedUpload: Codable { let sourceFilename: String }

func parameterJSON(_ parameter: CapabilityParameter, value: ParameterValue) -> Any {
    switch value { case .string(let value): return value; case .number(let value): return parameter.type == "integer" ? Int(value) : value; case .bool(let value): return value }
}

struct RemoteVideoSource: Hashable, Identifiable {
    let filename: String
    let deliveryRoute: SourceRoute?
    let videoInfo: VideoInfo?

    init(filename: String, deliveryRoute: SourceRoute? = nil, videoInfo: VideoInfo? = nil) {
        self.filename = filename
        self.deliveryRoute = deliveryRoute
        self.videoInfo = videoInfo
    }

    var id: String { filename }
}

struct VideoInfo: Codable, Hashable {
    let fileName: String
    let fileExtension: String
    let codec: String
    let width: Int
    let height: Int
    let frameRate: Double
    let duration: Double
    let fileSize: Int

    var resolutionText: String { "\(width) × \(height)" }
    var frameRateText: String { "\(Int(frameRate.rounded())) fps" }
    var durationText: String { Duration.seconds(duration).formatted(.time(pattern: .minuteSecond)) }
    var fileSizeText: String { ByteCountFormatter.string(fromByteCount: Int64(fileSize), countStyle: .file) }
}

struct WeChatImport: Codable, Identifiable {
    let id: String
    let state: String
    let sourceFilename: String?
    let videoInfo: VideoInfo?
    let error: String?

    var failureDescription: String {
        switch state {
        case "not_found": return "No supported video was found in File Transfer Assistant."
        case "not_downloaded": return "WeChat has not finished downloading the selected video. Try again after the download completes."
        case "unsupported_file": return "The latest WeChat file is not a supported video."
        case "wechat_not_logged_in": return "Open and sign in to WeChat on the unlocked PC, then try again."
        case "desktop_locked": return "Unlock the Windows desktop, then try reading the WeChat video again."
        case "ui_changed": return "WeChat's desktop controls are unavailable. Keep WeChat open and update the bridge if its UI changed."
        case "download_failed": return "WeChat could not make the video available on the PC. Check WeChat's download and try again."
        default: return error ?? "The WeChat video could not be read."
        }
    }
}

struct OutputEstimate: Hashable {
    let width: Int
    let height: Int
    let frameRate: Int

    init(source: VideoInfo, scale: Int, frameRate: Int) {
        width = source.width * max(scale, 1)
        height = source.height * max(scale, 1)
        self.frameRate = frameRate
    }

    var resolutionText: String { "\(width) × \(height)" }
    var frameRateText: String { "\(frameRate) fps" }
}

enum VideoInspector {
    static func inspect(url: URL) async throws -> VideoInfo {
        let hasSecurityScope = url.startAccessingSecurityScopedResource()
        defer { if hasSecurityScope { url.stopAccessingSecurityScopedResource() } }
        let resource = try url.resourceValues(forKeys: [.fileSizeKey, .nameKey])
        let asset = AVURLAsset(url: url)
        let duration = try await asset.load(.duration)
        guard let track = try await asset.loadTracks(withMediaType: .video).first else { throw CocoaError(.fileReadCorruptFile) }
        let size = try await track.load(.naturalSize)
        let frameRate = try await track.load(.nominalFrameRate)
        let descriptions = try await track.load(.formatDescriptions)
        return VideoInfo(
            fileName: resource.name ?? url.lastPathComponent,
            fileExtension: url.pathExtension.uppercased(),
            codec: codecName(descriptions.first),
            width: Int(abs(size.width.rounded())),
            height: Int(abs(size.height.rounded())),
            frameRate: Double(frameRate),
            duration: duration.seconds,
            fileSize: resource.fileSize ?? 0
        )
    }

    private static func codecName(_ description: CMFormatDescription?) -> String {
        guard let description else { return "Unknown" }
        let subtype = CMFormatDescriptionGetMediaSubType(description)
        switch subtype {
        case 0x31637661: return "H.264"
        case 0x68766331, 0x68657631: return "HEVC"
        case 0x6D703476: return "MPEG-4 Video"
        default:
            let bytes = [UInt8((subtype >> 24) & 0xFF), UInt8((subtype >> 16) & 0xFF), UInt8((subtype >> 8) & 0xFF), UInt8(subtype & 0xFF)]
            return String(bytes: bytes, encoding: .ascii)?.trimmingCharacters(in: .whitespacesAndNewlines) ?? "Unknown"
        }
    }
}
