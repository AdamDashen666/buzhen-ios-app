import SwiftUI
import UIKit

final class AppDelegate: NSObject, UIApplicationDelegate {
    func application(
        _ application: UIApplication,
        handleEventsForBackgroundURLSession identifier: String,
        completionHandler: @escaping () -> Void
    ) {
        DownloadCoordinator.shared.handleBackgroundEvents(for: identifier, completionHandler: completionHandler)
    }
}

@main
struct TopazRemoteApp: App {
    @UIApplicationDelegateAdaptor(AppDelegate.self) private var appDelegate
    @StateObject private var pairing = PairingSettings()

    var body: some Scene {
        WindowGroup { ContentView(pairing: pairing) }
    }
}
