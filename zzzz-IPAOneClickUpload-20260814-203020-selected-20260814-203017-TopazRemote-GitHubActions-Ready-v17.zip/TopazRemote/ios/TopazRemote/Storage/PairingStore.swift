import Foundation
import Security

enum PairingStore {
    private static let service = "com.local.topazremote.pairing"
    private static let tokenAccount = "agent-token"

    static func loadToken() -> String {
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: service, kSecAttrAccount as String: tokenAccount, kSecReturnData as String: true, kSecMatchLimit as String: kSecMatchLimitOne]
        var result: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess, let data = result as? Data else { return "" }
        return String(decoding: data, as: UTF8.self)
    }

    static func saveToken(_ token: String) {
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: service, kSecAttrAccount as String: tokenAccount]
        SecItemDelete(query as CFDictionary)
        guard !token.isEmpty else { return }
        var insert = query
        insert[kSecValueData as String] = Data(token.utf8)
        SecItemAdd(insert as CFDictionary, nil)
    }
}

@MainActor
final class PairingSettings: ObservableObject {
    static let defaultAgentHost = "desktop-inn4klw-1.taildee45d.ts.net"
    @Published var host: String { didSet { defaults.set(host, forKey: "agent-host") } }
    @Published var port: Int { didSet { defaults.set(port, forKey: "agent-port") } }
    @Published var token: String { didSet { PairingStore.saveToken(token) } }

    private let defaults: UserDefaults

    init(defaults: UserDefaults = .standard) {
        self.defaults = defaults
        self.host = defaults.string(forKey: "agent-host") ?? Self.defaultAgentHost
        let savedPort = defaults.integer(forKey: "agent-port")
        self.port = savedPort == 0 ? 8123 : savedPort
        self.token = PairingStore.loadToken()
    }

    var agentSettings: AgentSettings { AgentSettings(host: host.trimmingCharacters(in: .whitespacesAndNewlines), port: port, token: token.trimmingCharacters(in: .whitespacesAndNewlines)) }
}
