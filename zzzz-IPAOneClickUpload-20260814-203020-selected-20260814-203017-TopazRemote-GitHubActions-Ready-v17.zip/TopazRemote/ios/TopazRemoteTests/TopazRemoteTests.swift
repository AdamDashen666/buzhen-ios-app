import XCTest
@testable import TopazRemote

final class TopazRemoteTests: XCTestCase {
    func testDecodesCapabilityParameters() throws {
        let data = #"{"apiVersion":"v1","agentVersion":"0.1.0","capabilitySchemaVersion":1,"enhancementModels":[{"id":"prob-4","displayName":"Proteus","available":true,"parameters":[]}],"denoiseModels":[{"id":"nyx-3","displayName":"Nyx","available":true,"parameters":[]}],"interpolationModels":[{"id":"chr-2","displayName":"Chronos","available":true,"parameters":[{"id":"fps","type":"number","min":1,"max":480,"step":1}]}]}"#.data(using: .utf8)!
        let response = try JSONDecoder().decode(CapabilityResponse.self, from: data)
        XCTAssertEqual(response.enhancementModels.first?.id, "prob-4")
        XCTAssertEqual(response.denoiseModels.first?.id, "nyx-3")
        XCTAssertEqual(response.interpolationModels.first?.parameters.first?.max, 480)
    }

    func testPredictsOutputDetailsFromTheSelectedScaleAndFrameRate() {
        let input = VideoInfo(fileName: "clip.mov", fileExtension: "mov", codec: "H.264", width: 1920, height: 1080, frameRate: 60, duration: 12, fileSize: 1024)
        let output = OutputEstimate(source: input, scale: 2, frameRate: 120)
        XCTAssertEqual(output.width, 3840)
        XCTAssertEqual(output.height, 2160)
        XCTAssertEqual(output.frameRate, 120)
    }

    func testCompletedJobDecodesTheSafeReusableOutputFilename() throws {
        let data = #"{"id":"job-1","status":"completed","sourceFilename":"clip.mov","outputFilename":"job-1.mp4"}"#.data(using: .utf8)!
        let job = try JSONDecoder().decode(Job.self, from: data)
        XCTAssertEqual(job.outputFilename, "job-1.mp4")
    }

    func testDecodesReadyWeChatImportAndRetryableDelivery() throws {
        let importData = #"{"id":"import-1","state":"ready","sourceFilename":"clip.mov","videoInfo":{"fileName":"clip.mov","fileExtension":"MOV","codec":"H.264","width":1920,"height":1080,"frameRate":60,"duration":1,"fileSize":5},"error":null}"#.data(using: .utf8)!
        let ticket = try JSONDecoder().decode(WeChatImport.self, from: importData)
        XCTAssertEqual(ticket.videoInfo?.width, 1920)

        let unavailable = try JSONDecoder().decode(WeChatImport.self, from: #"{"id":"import-2","state":"wechat_not_logged_in","sourceFilename":null,"videoInfo":null,"error":"No logged-in WeChat desktop window was found."}"#.data(using: .utf8)!)
        XCTAssertEqual(unavailable.failureDescription, "Open and sign in to WeChat on the unlocked PC, then try again.")

        let jobData = #"{"id":"job-1","status":"completed","sourceFilename":"clip.mov","outputFilename":"job-1.mp4","delivery":{"route":"wechat","state":"send_failed","error":"WeChat file picker did not open"}}"#.data(using: .utf8)!
        let job = try JSONDecoder().decode(Job.self, from: jobData)
        XCTAssertEqual(job.delivery?.state, "send_failed")

        let legacy = try JSONDecoder().decode(Job.self, from: #"{"id":"job-2","status":"created"}"#.data(using: .utf8)!)
        XCTAssertNil(legacy.delivery)
    }

    func testBuildsTokenProtectedAgentURL() throws {
        let client = AgentClient(settings: AgentSettings(host: "100.64.0.2", port: 8123, token: "secret"))
        let request = try client.makeRequest(path: "/jobs")
        XCTAssertEqual(request.url?.absoluteString, "http://100.64.0.2:8123/api/v1/jobs")
        XCTAssertEqual(request.value(forHTTPHeaderField: "Authorization"), "Bearer secret")
    }

    func testAgentRequestsAllowSlowTailscaleTransfers() throws {
        let client = AgentClient(settings: AgentSettings(host: "100.64.0.2", port: 8123, token: "secret"))
        let request = try client.makeRequest(path: "/uploads/example/chunks/0", method: "PUT", body: Data(repeating: 0, count: 1024))
        XCTAssertEqual(request.timeoutInterval, 300)
        XCTAssertEqual(AgentClient.agentSession.configuration.timeoutIntervalForRequest, 300)
        XCTAssertEqual(AgentClient.agentSession.configuration.timeoutIntervalForResource, 3600)
    }

    func testDownloadProgressFractionIsBoundedAndHandlesUnknownSize() {
        XCTAssertEqual(DownloadProgress.fraction(written: 50, expected: 100), 0.5)
        XCTAssertEqual(DownloadProgress.fraction(written: 120, expected: 100), 1)
        XCTAssertEqual(DownloadProgress.fraction(written: -1, expected: 100), 0)
        XCTAssertNil(DownloadProgress.fraction(written: 10, expected: 0))
    }

    func testOutputDownloadsUseOneStableBackgroundSession() {
        XCTAssertEqual(DownloadCoordinator.backgroundSessionIdentifier, "com.local.topazremote.output-downloads")
    }

    func testRejectsAddressWithSchemeOrPath() {
        let client = AgentClient(settings: AgentSettings(host: "http://bad/path", port: 8123, token: "secret"))
        XCTAssertThrowsError(try client.makeRequest(path: "/jobs"))
    }

    func testSerializesDynamicIntegerAndBooleanParameters() {
        let integer = CapabilityParameter(id: "passes", displayName: nil, type: "integer", min: 1, max: 4, step: 1, default: nil, options: nil)
        let boolean = CapabilityParameter(id: "recover", displayName: nil, type: "boolean", min: nil, max: nil, step: nil, default: nil, options: nil)
        XCTAssertEqual(parameterJSON(integer, value: .number(2)) as? Int, 2)
        XCTAssertEqual(parameterJSON(boolean, value: .bool(true)) as? Bool, true)
    }
}
