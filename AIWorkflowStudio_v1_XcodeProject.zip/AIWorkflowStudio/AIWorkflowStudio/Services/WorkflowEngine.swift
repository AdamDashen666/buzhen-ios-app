import Foundation

final class WorkflowEngine {
    func run(project: WorkflowProject, apiConfigs: [APIProviderConfig], settings: AppSettings, aiClient: AIClient, onUpdate: @escaping (RunRecord) -> Void) async throws -> RunRecord {
        var record = RunRecord(projectID: project.id, projectTitle: project.title)
        var context = "用户需求：\n\(project.userPrompt)"
        let orderedNodes = topologicalFallback(project.nodes)
        var completed = 0

        record.logs.append(RunLogEntry(level: .info, message: "开始运行工作流：\(project.title)"))
        onUpdate(record)

        for node in orderedNodes {
            var nodeRecord = NodeRunRecord(nodeID: node.id, nodeTitle: node.title, kind: node.kind, status: .running)
            nodeRecord.inputPreview = String(context.prefix(800))
            record.nodeRecords.append(nodeRecord)
            record.logs.append(RunLogEntry(level: .info, nodeTitle: node.title, message: "开始执行模块"))
            onUpdate(record)

            do {
                let response = try await execute(node: node, project: project, context: context, apiConfigs: apiConfigs, settings: settings, aiClient: aiClient)
                let output = response.text
                context += "\n\n## \(node.title) 输出\n\(output)"
                record.output = output
                record.tokenUsage = record.tokenUsage + response.tokenUsage

                if let index = record.nodeRecords.firstIndex(where: { $0.nodeID == node.id }) {
                    record.nodeRecords[index].status = .passed
                    record.nodeRecords[index].endedAt = Date()
                    record.nodeRecords[index].output = output
                    record.nodeRecords[index].tokenUsage = response.tokenUsage
                    record.nodeRecords[index].providerName = apiConfigs.first(where: { $0.id == node.providerID })?.name
                    record.nodeRecords[index].modelID = node.modelID
                }
                record.logs.append(RunLogEntry(level: .success, nodeTitle: node.title, message: "模块完成，Token：\(response.tokenUsage.total)"))
            } catch {
                if let index = record.nodeRecords.firstIndex(where: { $0.nodeID == node.id }) {
                    record.nodeRecords[index].status = .failed
                    record.nodeRecords[index].endedAt = Date()
                    record.nodeRecords[index].errorMessage = error.localizedDescription
                }
                record.logs.append(RunLogEntry(level: .error, nodeTitle: node.title, message: error.localizedDescription))
                record.status = .failed
                record.endedAt = Date()
                onUpdate(record)
                throw error
            }

            completed += 1
            record.progress = Double(completed) / Double(max(orderedNodes.count, 1))
            onUpdate(record)
        }

        record.status = .completed
        record.endedAt = Date()
        record.output = context
        record.logs.append(RunLogEntry(level: .success, message: "工作流运行完成"))
        return record
    }

    private func execute(node: WorkflowNode, project: WorkflowProject, context: String, apiConfigs: [APIProviderConfig], settings: AppSettings, aiClient: AIClient) async throws -> AITextResponse {
        switch node.kind {
        case .start:
            let text = "已接收需求。\n\n\(project.userPrompt)"
            return AITextResponse(text: text, tokenUsage: TokenUsage(input: TokenEstimator.roughCount(project.userPrompt), output: TokenEstimator.roughCount(text)))
        case .logger:
            let text = "日志记录模块已记录当前上下文、模块输出、Token 与状态。"
            return AITextResponse(text: text, tokenUsage: TokenUsage(input: 0, output: TokenEstimator.roughCount(text)))
        case .versionSnapshot:
            let text = "版本快照模块已保存工作流结构、提示词、模型配置和当前输出。"
            return AITextResponse(text: text, tokenUsage: TokenUsage(input: 0, output: TokenEstimator.roughCount(text)))
        case .output:
            let text = "# 最终输出\n\n\(context)"
            return AITextResponse(text: text, tokenUsage: TokenUsage(input: TokenEstimator.roughCount(context), output: TokenEstimator.roughCount(text)))
        default:
            guard let providerID = node.providerID, let config = apiConfigs.first(where: { $0.id == providerID }), let model = node.modelID, !model.isEmpty else {
                let simulated = localFallbackOutput(for: node, context: context)
                return AITextResponse(text: simulated, tokenUsage: TokenUsage(input: TokenEstimator.roughCount(context), output: TokenEstimator.roughCount(simulated)))
            }
            let apiKey = try KeychainService.read(account: config.keychainAccount)
            let system = systemPrompt(for: node)
            let user = """
            当前工作流上下文：
            \(context)

            当前模块任务：
            \(node.prompt.isEmpty ? node.kind.defaultPrompt : node.prompt)

            输出要求：结构化、可执行、指出不确定内容和风险。不要泄露 API Key。
            """

            if node.kind == .imageUnderstanding, let image = project.resources.first(where: { $0.kind == .image })?.base64Preview {
                return try await aiClient.completeVision(baseURL: config.baseURL, apiKey: apiKey, model: model, prompt: user, imageBase64: image, maxTokens: min(node.maxTokens, settings.singleModuleTokenLimit), temperature: node.temperature, timeoutSeconds: node.timeoutSeconds)
            } else {
                let messages = [AIMessage(role: "system", content: system), AIMessage(role: "user", content: user)]
                return try await aiClient.completeText(baseURL: config.baseURL, apiKey: apiKey, model: model, messages: messages, maxTokens: min(node.maxTokens, settings.singleModuleTokenLimit), temperature: node.temperature, timeoutSeconds: node.timeoutSeconds)
            }
        }
    }

    private func systemPrompt(for node: WorkflowNode) -> String {
        switch node.kind {
        case .codeReviewer:
            return "你是严格的代码检查者。必须检查语法、依赖、架构、安全、入口文件、iOS 适配、固定像素风险和输出格式。用 passed: true/false 开头。"
        case .autoFixer:
            return "你是自动修复者。只根据检查意见修复代码，不要引入无关功能。"
        case .qualityReviewer:
            return "你是质量评估者。按准确性、完整性、格式、风险评分，低于阈值必须给返工建议。"
        case .imageUnderstanding:
            return "你是图片理解模块。输出图片摘要、关键文字、可操作信息、不确定内容。"
        case .multiModelVote:
            return "你是裁判模型。比较多个答案，选择更可靠结果，并解释理由。"
        default:
            return "你是 AI Workflow Studio 的 \(node.kind.title)。严格完成当前模块职责。"
        }
    }

    private func localFallbackOutput(for node: WorkflowNode, context: String) -> String {
        switch node.kind {
        case .planner:
            return "未配置模型，使用本地占位计划：1. 拆解需求；2. 执行核心任务；3. 检查质量；4. 导出结果。"
        case .codeReviewer:
            return "passed: false\n未配置模型，无法进行真实代码检查。建议配置代码能力强的模型，并重新运行。"
        case .imageUnderstanding:
            return "未配置 Vision 模型，无法识别图片。请在设置中添加支持图片输入的模型。"
        default:
            return "未配置模型，\(node.kind.title) 已跳过真实 AI 调用，仅生成占位输出。"
        }
    }

    private func topologicalFallback(_ nodes: [WorkflowNode]) -> [WorkflowNode] {
        let order: [WorkflowNodeKind] = [.start, .autoGraph, .planner, .imageUnderstanding, .dispatcher, .worker, .codeWorker, .codeReviewer, .autoFixer, .imageGenerator, .visualReviewer, .multiModelVote, .qualityReviewer, .aggregator, .formatter, .filePackager, .humanApproval, .logger, .versionSnapshot, .output]
        return nodes.sorted { lhs, rhs in
            (order.firstIndex(of: lhs.kind) ?? 99) < (order.firstIndex(of: rhs.kind) ?? 99)
        }
    }
}
