import Foundation

// 完整模块系统：覆盖 PDF 里的计划者、工作者、检查者、代码检查者、图片理解、多模型投票、日志、版本快照、输出等。
enum WorkflowNodeKind: String, Codable, CaseIterable, Identifiable {
    case start
    case autoGraph
    case planner
    case dispatcher
    case worker
    case codeWorker
    case codeReviewer
    case autoFixer
    case imageUnderstanding
    case imageGenerator
    case multiModelVote
    case qualityReviewer
    case visualReviewer
    case aggregator
    case formatter
    case filePackager
    case humanApproval
    case logger
    case versionSnapshot
    case output

    var id: String { rawValue }

    var title: String {
        switch self {
        case .start: return "开始模块"
        case .autoGraph: return "AI 自动建图"
        case .planner: return "计划者"
        case .dispatcher: return "任务分配者"
        case .worker: return "通用工作者"
        case .codeWorker: return "代码工作者"
        case .codeReviewer: return "代码检查者"
        case .autoFixer: return "自动修复者"
        case .imageUnderstanding: return "图片理解 / 识别"
        case .imageGenerator: return "图片生成者"
        case .multiModelVote: return "多模型投票"
        case .qualityReviewer: return "检查者 / 质量评估"
        case .visualReviewer: return "视觉检查者"
        case .aggregator: return "汇总者"
        case .formatter: return "格式转换者"
        case .filePackager: return "文件打包者"
        case .humanApproval: return "人工确认"
        case .logger: return "日志记录"
        case .versionSnapshot: return "版本快照"
        case .output: return "输出模块"
        }
    }

    var icon: String {
        switch self {
        case .start: return "play.circle"
        case .autoGraph: return "wand.and.stars"
        case .planner: return "list.bullet.clipboard"
        case .dispatcher: return "arrow.triangle.branch"
        case .worker: return "person.text.rectangle"
        case .codeWorker: return "chevron.left.forwardslash.chevron.right"
        case .codeReviewer: return "checkmark.seal"
        case .autoFixer: return "wrench.and.screwdriver"
        case .imageUnderstanding: return "photo.on.rectangle.angled"
        case .imageGenerator: return "paintbrush.pointed"
        case .multiModelVote: return "person.3.sequence"
        case .qualityReviewer: return "star.leadinghalf.filled"
        case .visualReviewer: return "eye"
        case .aggregator: return "square.stack.3d.up"
        case .formatter: return "doc.richtext"
        case .filePackager: return "archivebox"
        case .humanApproval: return "hand.raised"
        case .logger: return "list.clipboard"
        case .versionSnapshot: return "clock.arrow.circlepath"
        case .output: return "tray.and.arrow.down"
        }
    }

    var defaultPrompt: String {
        switch self {
        case .start:
            return "接收用户目标、文件、图片和参数。"
        case .autoGraph:
            return "根据用户目标生成节点、连线、返工规则和输出格式，必须包含检查者。"
        case .planner:
            return "拆解目标，列出阶段、风险、所需模块和交付物。"
        case .dispatcher:
            return "把任务拆给多个工作者，说明每个工作者的输入、输出和检查标准。"
        case .worker:
            return "执行普通写作、总结、整理、分析任务。"
        case .codeWorker:
            return "生成代码、项目结构、文件内容和运行说明。"
        case .codeReviewer:
            return "检查语法、依赖、架构、安全、可运行性和 iOS 适配风险，输出通过/不通过与修复建议。"
        case .autoFixer:
            return "根据代码检查者意见修复代码，并说明修复点。"
        case .imageUnderstanding:
            return "识别图片内容，输出图片摘要、关键文字、可操作信息和不确定内容。"
        case .imageGenerator:
            return "根据需求生成图片提示词、图标或 UI 草图方案。"
        case .multiModelVote:
            return "汇总多个模型回答，用多数票、评分制或裁判模型选择结果。"
        case .qualityReviewer:
            return "从准确性、完整性、格式、风险四项评分；低于阈值时打回返工。"
        case .visualReviewer:
            return "检查 UI、排版、颜色、可读性和移动端适配。"
        case .aggregator:
            return "合并多个模块输出，去重，统一风格。"
        case .formatter:
            return "把内容转换为 Markdown、JSON、TXT、HTML 或代码文件。"
        case .filePackager:
            return "整理多文件目录结构，生成 README、日志和 ZIP 打包清单。"
        case .humanApproval:
            return "暂停流程，等待用户确认后继续。"
        case .logger:
            return "记录模块输入、输出、模型、Token、错误、耗时和返工记录。"
        case .versionSnapshot:
            return "保存工作流结构、提示词、模型配置和输出快照。"
        case .output:
            return "整理最终结果并导出文本、代码、图片说明或项目包。"
        }
    }

    var requiresVisionModel: Bool {
        self == .imageUnderstanding || self == .visualReviewer
    }

    var isCodeRelated: Bool {
        self == .codeWorker || self == .codeReviewer || self == .autoFixer
    }
}
