import Foundation

struct RunRecord: Identifiable, Codable, Hashable {
    var id: UUID = UUID()
    var projectID: UUID
    var projectTitle: String
    var startedAt: Date = Date()
    var endedAt: Date?
    var status: RunStatus = .running
    var progress: Double = 0
    var nodeRecords: [NodeRunRecord] = []
    var output: String = ""
    var tokenUsage: TokenUsage = .zero
    var logs: [RunLogEntry] = []

    var displayDate: String {
        startedAt.formatted(date: .abbreviated, time: .shortened)
    }
}

enum RunStatus: String, Codable, CaseIterable, Identifiable {
    case running
    case completed
    case failed
    case cancelled

    var id: String { rawValue }
    var title: String {
        switch self {
        case .running: return "运行中"
        case .completed: return "完成"
        case .failed: return "失败"
        case .cancelled: return "已取消"
        }
    }
}

struct NodeRunRecord: Identifiable, Codable, Hashable {
    var id: UUID = UUID()
    var nodeID: UUID
    var nodeTitle: String
    var kind: WorkflowNodeKind
    var status: NodeStatus
    var startedAt: Date = Date()
    var endedAt: Date?
    var inputPreview: String = ""
    var output: String = ""
    var errorMessage: String?
    var tokenUsage: TokenUsage = .zero
    var providerName: String?
    var modelID: String?
    var returnCount: Int = 0
}

struct RunLogEntry: Identifiable, Codable, Hashable {
    var id: UUID = UUID()
    var date: Date = Date()
    var level: LogLevel
    var nodeTitle: String?
    var message: String
}

enum LogLevel: String, Codable, CaseIterable, Identifiable {
    case info
    case warning
    case error
    case success

    var id: String { rawValue }
    var symbol: String {
        switch self {
        case .info: return "ℹ️"
        case .warning: return "⚠️"
        case .error: return "❌"
        case .success: return "✅"
        }
    }
}

struct TokenUsage: Codable, Hashable {
    var input: Int
    var output: Int

    var total: Int { input + output }

    static let zero = TokenUsage(input: 0, output: 0)

    static func + (lhs: TokenUsage, rhs: TokenUsage) -> TokenUsage {
        TokenUsage(input: lhs.input + rhs.input, output: lhs.output + rhs.output)
    }
}

struct VersionSnapshot: Identifiable, Codable, Hashable {
    var id: UUID = UUID()
    var projectID: UUID
    var createdAt: Date = Date()
    var title: String
    var project: WorkflowProject
    var output: String
    var note: String
}

struct AppSettings: Codable, Hashable {
    var dailyTokenLimit: Int = 300_000
    var singleWorkflowTokenLimit: Int = 80_000
    var singleModuleTokenLimit: Int = 16_000
    var maxVoteModels: Int = 5
    var maxReturnCount: Int = 2
    var confirmWhenEstimatedCostOver: Double = 1.0
    var forceDarkMode: Bool = false
    var privacyModeForLogs: Bool = false
}
