import Foundation

struct APIProviderConfig: Identifiable, Codable, Hashable {
    var id: UUID = UUID()
    var name: String
    var baseURL: String
    var keychainAccount: String
    var interfaceTypes: Set<AIInterfaceType> = [.chat]
    var models: [AIModelInfo] = []
    var defaultTextModel: String = ""
    var defaultVisionModel: String = ""
    var defaultImageModel: String = ""
    var inputPricePerMillionTokens: Double = 0
    var outputPricePerMillionTokens: Double = 0
    var createdAt: Date = Date()
    var updatedAt: Date = Date()

    static let empty = APIProviderConfig(
        name: "OpenAI Compatible",
        baseURL: "https://api.openai.com/v1",
        keychainAccount: UUID().uuidString
    )
}

enum AIInterfaceType: String, Codable, CaseIterable, Identifiable, Hashable {
    case chat
    case responses
    case vision
    case imageGeneration
    case embedding

    var id: String { rawValue }
    var title: String {
        switch self {
        case .chat: return "Chat"
        case .responses: return "Responses"
        case .vision: return "Vision"
        case .imageGeneration: return "Image Generation"
        case .embedding: return "Embedding"
        }
    }
}

struct AIModelInfo: Identifiable, Codable, Hashable {
    var id: String
    var name: String
    var supportsVision: Bool = false
    var supportsImageGeneration: Bool = false
    var contextLength: Int? = nil
}

struct OpenAIModelListResponse: Decodable {
    let data: [OpenAIModelItem]
}

struct OpenAIModelItem: Decodable {
    let id: String
}
