import SwiftUI

struct SettingsView: View {
    @EnvironmentObject private var store: AppStore
    @State private var editingConfig: APIProviderConfig?
    @State private var addingConfig = false

    var body: some View {
        NavigationStack {
            Form {
                Section("多 API 与模型库") {
                    ForEach(store.apiConfigs) { config in
                        Button { editingConfig = config } label: {
                            VStack(alignment: .leading) {
                                Text(config.name).font(.headline)
                                Text(config.baseURL).font(.caption).foregroundStyle(.secondary)
                                Text("模型 \(config.models.count) · 文本默认：\(config.defaultTextModel.isEmpty ? "未设置" : config.defaultTextModel)")
                                    .font(.caption2)
                                    .foregroundStyle(.secondary)
                            }
                        }
                    }
                    Button { addingConfig = true } label: { Label("添加 API 配置", systemImage: "plus.circle") }
                }

                Section("Token 限制") {
                    Stepper("每日 Token：\(store.settings.dailyTokenLimit)", value: $store.settings.dailyTokenLimit, in: 10_000...5_000_000, step: 10_000)
                    Stepper("单次工作流：\(store.settings.singleWorkflowTokenLimit)", value: $store.settings.singleWorkflowTokenLimit, in: 10_000...1_000_000, step: 5_000)
                    Stepper("单模块：\(store.settings.singleModuleTokenLimit)", value: $store.settings.singleModuleTokenLimit, in: 1_000...128_000, step: 1_000)
                    Stepper("多模型投票上限：\(store.settings.maxVoteModels)", value: $store.settings.maxVoteModels, in: 2...8)
                    Stepper("最大返工次数：\(store.settings.maxReturnCount)", value: $store.settings.maxReturnCount, in: 0...5)
                }

                Section("外观与隐私") {
                    Toggle("强制深色 Liquid Glass", isOn: $store.settings.forceDarkMode)
                    Toggle("日志导出前默认脱敏", isOn: $store.settings.privacyModeForLogs)
                }
            }
            .navigationTitle("设置")
            .sheet(isPresented: $addingConfig) { APIConfigEditorView(config: .empty, isNew: true) }
            .sheet(item: $editingConfig) { config in APIConfigEditorView(config: config, isNew: false) }
        }
    }
}
