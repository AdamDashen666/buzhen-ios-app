import SwiftUI
import PhotosUI

struct HomeView: View {
    @EnvironmentObject private var store: AppStore
    @State private var newPrompt = ""
    @State private var autoSelect = true
    @State private var selectedPhoto: PhotosPickerItem?

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    hero
                    quickStart
                    recentProjects
                }
                .padding()
            }
            .navigationTitle("AI Workflow Studio")
        }
    }

    private var hero: some View {
        VStack(alignment: .leading, spacing: 12) {
            Label("可视化多 AI 工作流", systemImage: "sparkles")
                .font(.title.bold())
            Text("把计划者、工作者、代码检查者、图片理解、多模型投票、日志和输出模块组成一个可控的 AI 团队。")
                .foregroundStyle(.secondary)
            HStack {
                Button {
                    store.createProject(title: "AI 工作流项目")
                } label: {
                    Label("新建项目", systemImage: "plus.circle.fill")
                        .font(.headline)
                }
                .buttonStyle(.borderedProminent)

                Button("自动建图") {
                    if let project = store.selectedProject {
                        store.updatePrompt(projectID: project.id, prompt: newPrompt, autoSelect: autoSelect)
                        store.autoBuildSelectedProject()
                    }
                }
                .buttonStyle(.bordered)
            }
        }
        .liquidGlass()
    }

    private var quickStart: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("开始模块")
                .font(.headline)
            TextEditor(text: $newPrompt)
                .frame(minHeight: 140)
                .padding(8)
                .background(.black.opacity(0.08), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
            Toggle("AI 自动选择模块", isOn: $autoSelect)
            PhotosPicker(selection: $selectedPhoto, matching: .images) {
                Label("上传图片到图片理解模块", systemImage: "photo.badge.plus")
            }
            .onChange(of: selectedPhoto) { _, newItem in
                Task { await importPhoto(newItem) }
            }
            HStack {
                Button {
                    guard var project = store.selectedProject else { return }
                    project.userPrompt = newPrompt
                    project.autoSelectModules = autoSelect
                    store.updateProject(project)
                    if autoSelect { store.autoBuildSelectedProject() }
                } label: {
                    Label("保存到当前项目", systemImage: "square.and.arrow.down")
                }
                .buttonStyle(.bordered)

                Button {
                    Task { await store.runSelectedProject() }
                } label: {
                    Label("确认并运行", systemImage: "play.fill")
                }
                .buttonStyle(.borderedProminent)
            }
        }
        .liquidGlass()
    }

    private var recentProjects: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("最近项目")
                .font(.headline)
            ForEach(store.projects) { project in
                Button {
                    store.selectedProjectID = project.id
                    newPrompt = project.userPrompt
                    autoSelect = project.autoSelectModules
                } label: {
                    HStack {
                        VStack(alignment: .leading) {
                            Text(project.title).font(.headline)
                            Text("节点 \(project.nodes.count) · 更新 \(project.updatedAt.formatted(date: .abbreviated, time: .shortened))")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                        Spacer()
                        if store.selectedProjectID == project.id { Image(systemName: "checkmark.circle.fill") }
                    }
                }
                .buttonStyle(.plain)
                .padding()
                .background(.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
            }
        }
        .liquidGlass()
    }

    private func importPhoto(_ item: PhotosPickerItem?) async {
        guard let item, let data = try? await item.loadTransferable(type: Data.self), var project = store.selectedProject else { return }
        let resource = ProjectResource(name: "Image-\(Date().timeIntervalSince1970).jpg", kind: .image, base64Preview: data.base64EncodedString())
        project.resources.append(resource)
        if !project.nodes.contains(where: { $0.kind == .imageUnderstanding }) {
            var imageNode = WorkflowNode(kind: .imageUnderstanding, title: WorkflowNodeKind.imageUnderstanding.title, x: 380, y: 300)
            imageNode.prompt = WorkflowNodeKind.imageUnderstanding.defaultPrompt
            project.nodes.insert(imageNode, at: min(1, project.nodes.count))
        }
        store.updateProject(project)
    }
}
