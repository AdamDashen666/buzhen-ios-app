import SwiftUI

struct APIConfigEditorView: View {
    @EnvironmentObject private var store: AppStore
    @Environment(\.dismiss) private var dismiss
    @State var config: APIProviderConfig
    var isNew: Bool
    @State private var apiKey = ""
    @State private var refreshMessage = ""
    @State private var refreshing = false

    var body: some View {
        NavigationStack {
            Form {
                Section("基础") {
                    TextField("配置名称", text: $config.name)
                    TextField("API Base URL", text: $config.baseURL)
                        .textInputAutocapitalization(.never)
                        .keyboardType(.URL)
                    SecureField(isNew ? "API Key" : "新 API Key（不填则保留）", text: $apiKey)
                }
                Section("接口类型") {
                    ForEach(AIInterfaceType.allCases) { type in
                        Toggle(type.title, isOn: Binding(
                            get: { config.interfaceTypes.contains(type) },
                            set: { enabled in
                                if enabled { config.interfaceTypes.insert(type) } else { config.interfaceTypes.remove(type) }
                            }
                        ))
                    }
                }
                Section("模型") {
                    Button(refreshing ? "刷新中..." : "刷新模型列表") {
                        Task { await refreshModels() }
                    }
                    if !refreshMessage.isEmpty { Text(refreshMessage).font(.caption).foregroundStyle(.secondary) }
                    Picker("默认文本模型", selection: $config.defaultTextModel) {
                        Text("未设置").tag("")
                        ForEach(config.models) { model in Text(model.name).tag(model.id) }
                    }
                    Picker("默认视觉模型", selection: $config.defaultVisionModel) {
                        Text("未设置").tag("")
                        ForEach(config.models) { model in Text(model.name).tag(model.id) }
                    }
                    Picker("默认图片生成模型", selection: $config.defaultImageModel) {
                        Text("未设置").tag("")
                        ForEach(config.models) { model in Text(model.name).tag(model.id) }
                    }
                    ForEach(config.models) { model in
                        Text(model.id).font(.caption)
                    }
                }
                Section("价格 / Token") {
                    TextField("输入 Token 每百万价格", value: $config.inputPricePerMillionTokens, format: .number)
                        .keyboardType(.decimalPad)
                    TextField("输出 Token 每百万价格", value: $config.outputPricePerMillionTokens, format: .number)
                        .keyboardType(.decimalPad)
                }
            }
            .navigationTitle(isNew ? "添加 API" : "编辑 API")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("取消") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("保存") {
                        if isNew { store.addAPIConfig(config, apiKey: apiKey) }
                        else { store.updateAPIConfig(config, apiKey: apiKey.isEmpty ? nil : apiKey) }
                        dismiss()
                    }
                }
            }
        }
    }

    private func refreshModels() async {
        refreshing = true
        defer { refreshing = false }
        do {
            let key = apiKey.isEmpty ? (try? KeychainService.read(account: config.keychainAccount)) ?? "" : apiKey
            let models = try await store.aiClient.fetchModels(baseURL: config.baseURL, apiKey: key)
            config.models = models
            if config.defaultTextModel.isEmpty { config.defaultTextModel = models.first?.id ?? "" }
            if config.defaultVisionModel.isEmpty { config.defaultVisionModel = models.first(where: { $0.supportsVision })?.id ?? models.first?.id ?? "" }
            refreshMessage = "已刷新 \(models.count) 个模型"
        } catch {
            refreshMessage = error.localizedDescription
        }
    }
}
