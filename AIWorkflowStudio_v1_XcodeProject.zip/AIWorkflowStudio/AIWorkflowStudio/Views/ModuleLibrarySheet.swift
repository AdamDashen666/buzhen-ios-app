import SwiftUI

struct ModuleLibrarySheet: View {
    @EnvironmentObject private var store: AppStore
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            List(WorkflowNodeKind.allCases) { kind in
                Button {
                    if let project = store.selectedProject {
                        store.addNode(kind, to: project.id)
                    }
                    dismiss()
                } label: {
                    HStack {
                        Image(systemName: kind.icon)
                            .frame(width: 28)
                        VStack(alignment: .leading) {
                            Text(kind.title)
                                .font(.headline)
                            Text(kind.defaultPrompt)
                                .font(.caption)
                                .foregroundStyle(.secondary)
                                .lineLimit(2)
                        }
                    }
                }
            }
            .navigationTitle("模块库")
            .toolbar { Button("关闭") { dismiss() } }
        }
    }
}
