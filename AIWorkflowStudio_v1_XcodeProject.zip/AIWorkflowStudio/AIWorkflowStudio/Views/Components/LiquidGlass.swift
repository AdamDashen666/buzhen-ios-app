import SwiftUI

struct LiquidGlassCard: ViewModifier {
    var cornerRadius: CGFloat = 28
    var glow: Bool = true

    func body(content: Content) -> some View {
        content
            .padding()
            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: cornerRadius, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
                    .stroke(.white.opacity(0.22), lineWidth: 1)
            )
            .shadow(color: .cyan.opacity(glow ? 0.18 : 0), radius: 22, x: 0, y: 8)
    }
}

extension View {
    func liquidGlass(cornerRadius: CGFloat = 28, glow: Bool = true) -> some View {
        modifier(LiquidGlassCard(cornerRadius: cornerRadius, glow: glow))
    }
}

struct FlowingStatusBar: View {
    var progress: Double

    var body: some View {
        GeometryReader { geometry in
            ZStack(alignment: .leading) {
                Capsule().fill(.white.opacity(0.12))
                Capsule()
                    .fill(.linearGradient(colors: [.cyan, .blue, .purple], startPoint: .leading, endPoint: .trailing))
                    .frame(width: max(8, geometry.size.width * progress))
            }
        }
        .frame(height: 10)
    }
}
