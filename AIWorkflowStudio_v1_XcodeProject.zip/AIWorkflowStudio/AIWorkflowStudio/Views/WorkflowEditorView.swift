import SwiftUI

struct WorkflowEditorView: View {
    @EnvironmentObject private var store: AppStore
    @State private var showingLibrary = false
    @State private var selectedNode: WorkflowNode?
    @State private var connectFrom: UUID?

    var body: some View {
        NavigationStack {
            Group {
                if let project = store.selectedProject {
                    GeometryReader { proxy in
                        if proxy.size.width > 720 {
                            canvas(project: project)
                        } else {
                            listEditor(project: project)
                        }
                    }
                } else {
                    ContentUnavailableView("没有项目", systemImage: "folder.badge.plus", description: Text("先在首页新建一个工作流。"))
                }
            }
            .navigationTitle(store.selectedProject?.title ?? "工作流")
            .toolbar {
                ToolbarItemGroup(placement: .topBarTrailing) {
                    Button { showingLibrary = true } label: { Image(systemName: "plus") }
                    Button("自动建图") { store.autoBuildSelectedProject() }
                    Button { Task { await store.runSelectedProject() } } label: { Image(systemName: "play.fill") }
                }
            }
            .sheet(isPresented: $showingLibrary) { ModuleLibrarySheet() }
            .sheet(item: $selectedNode) { node in
                if let project = store.selectedProject {
                    NodeDetailView(projectID: project.id, node: node)
                }
            }
        }
    }

    private func canvas(project: WorkflowProject) -> some View {
        ZStack {
            LinearGradient(colors: [.black.opacity(0.96), .blue.opacity(0.32), .purple.opacity(0.22)], startPoint: .topLeading, endPoint: .bottomTrailing)
                .ignoresSafeArea()
            Canvas { context, _ in
                for edge in project.edges {
                    guard let from = project.nodes.first(where: { $0.id == edge.from }), let to = project.nodes.first(where: { $0.id == edge.to }) else { continue }
                    var path = Path()
                    path.move(to: CGPoint(x: from.x + 84, y: from.y))
                    path.addCurve(
                        to: CGPoint(x: to.x - 84, y: to.y),
                        control1: CGPoint(x: from.x + 150, y: from.y),
                        control2: CGPoint(x: to.x - 150, y: to.y)
                    )
                    context.stroke(path, with: .color(.cyan.opacity(0.55)), lineWidth: 2)
                }
            }
            ForEach(project.nodes) { node in
                NodeCard(node: node, isConnecting: connectFrom == node.id)
                    .position(x: node.x, y: node.y)
                    .gesture(
                        DragGesture()
                            .onChanged { value in
                                store.moveNode(projectID: project.id, nodeID: node.id, x: value.location.x, y: value.location.y)
                            }
                    )
                    .onTapGesture { selectedNode = node }
                    .contextMenu {
                        Button("从此节点连线") { connectFrom = node.id }
                        if let connectFrom, connectFrom != node.id {
                            Button("连接到此节点") {
                                store.connect(projectID: project.id, from: connectFrom, to: node.id)
                                self.connectFrom = nil
                            }
                        }
                        Button(role: .destructive) { store.removeNode(projectID: project.id, nodeID: node.id) } label: { Text("删除节点") }
                    }
            }
        }
    }

    private func listEditor(project: WorkflowProject) -> some View {
        List {
            Section("节点") {
                ForEach(project.nodes) { node in
                    Button { selectedNode = node } label: {
                        Label(node.title, systemImage: node.kind.icon)
                    }
                }
                .onDelete { offsets in
                    for index in offsets { store.removeNode(projectID: project.id, nodeID: project.nodes[index].id) }
                }
            }
            Section("连线") {
                ForEach(project.edges) { edge in
                    Text("\(project.nodes.first(where: { $0.id == edge.from })?.title ?? "?") → \(project.nodes.first(where: { $0.id == edge.to })?.title ?? "?")")
                }
            }
        }
    }
}

struct NodeCard: View {
    var node: WorkflowNode
    var isConnecting: Bool

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Image(systemName: node.kind.icon)
                Text(node.title).font(.headline)
            }
            Text(node.kind.title)
                .font(.caption)
                .foregroundStyle(.secondary)
            Text(node.status.title)
                .font(.caption2.bold())
                .padding(.horizontal, 8)
                .padding(.vertical, 4)
                .background(.cyan.opacity(0.18), in: Capsule())
        }
        .frame(width: 185, alignment: .leading)
        .liquidGlass(cornerRadius: 22, glow: isConnecting)
        .scaleEffect(isConnecting ? 1.05 : 1)
    }
}
