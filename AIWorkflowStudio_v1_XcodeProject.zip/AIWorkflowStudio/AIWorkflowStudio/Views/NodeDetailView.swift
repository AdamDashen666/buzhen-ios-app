import SwiftUI

struct NodeDetailView: View {
    @EnvironmentObject private var store: AppStore
    @Environment(\.dismiss) private var dismiss
    var projectID: UUID
    @State var node: WorkflowNode

    var body: some View {
        NavigationStack {
            Form {
                Section("基础") {
                    TextField("节点名称", text: $node.title)
                    Text(node.kind.title)
                    Stepper("最大返工：\(node.maxReturnCount)", value: $node.maxReturnCount, in: 0...5)
                    Stepper("重试次数：\(node.retryLimit)", value: $node.retryLimit, in: 0...5)
                }
                Section("提示词") {
                    TextEditor(text: $node.prompt)
                        .frame(minHeight: 150)
                }
                Section("模型设置") {
                    Picker("API 配置", selection: Binding(get: { node.providerID }, set: { node.providerID = $0 })) {
                        Text("未配置").tag(Optional<UUID>.none)
                        ForEach(store.apiConfigs) { config in
                            Text(config.name).tag(Optional(config.id))
                        }
                    }
                    if let providerID = node.providerID, let config = store.apiConfigs.first(where: { $0.id == providerID }) {
                        Picker("模型", selection: Binding(get: { node.modelID ?? "" }, set: { node.modelID = $0 })) {
                            Text("未选择").tag("")
                            ForEach(config.models) { model in
                                Text(model.name).tag(model.id)
                            }
                        }
                    }
                    Stepper("最大 Token：\(node.maxTokens)", value: $node.maxTokens, in: 256...64000, step: 256)
                    Slider(value: $node.temperature, in: 0...1) {
                        Text("Temperature")
                    }
                    Text("Temperature：\(node.temperature, specifier: "%.2f")")
                    Stepper("超时：\(node.timeoutSeconds)s", value: $node.timeoutSeconds, in: 15...300, step: 15)
                }
                Section("输出") {
                    Picker("输出格式", selection: $node.outputFormat) {
                        ForEach(OutputFormat.allCases) { format in
                            Text(format.title).tag(format)
                        }
                    }
                    Stepper("质量阈值：\(node.scoreThreshold)", value: $node.scoreThreshold, in: 0...100, step: 5)
                }
            }
            .navigationTitle(node.title)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("取消") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("保存") {
                        store.updateNode(node, in: projectID)
                        dismiss()
                    }
                }
            }
        }
    }
}
