# AI Workflow Studio v1

这是按 `AI Workflow Studio iOS Xcode Project Plan v2` 制作的 SwiftUI Xcode Project 骨架。

## 已实现

- iPhone + iPad SwiftUI 项目骨架
- Liquid Glass 风格 UI：半透明卡片、毛玻璃、发光进度条
- 首页：新建项目、输入提示词、AI 自动选择模块、图片上传入口
- 工作流编辑器：iPad 画布式节点、iPhone 列表式节点
- 完整模块库：计划者、工作者、代码工作者、代码检查者、自动修复者、图片理解、多模型投票、日志、版本快照、输出等
- 多 API 配置：Base URL、Keychain 保存 API Key、刷新模型列表、默认文本/视觉/图片模型
- 每个模块可单独设置模型、最大 Token、Temperature、超时、重试、返工次数
- Token 粗略估算：运行前检查单次工作流限制
- 工作流运行引擎雏形：顺序执行节点、记录 Token、状态、错误和输出
- 运行日志：Markdown 分享导出
- 版本历史：运行完成后自动保存快照
- 图片理解模块：可上传图片，并在有 Vision 模型时用 OpenAI-compatible `chat/completions` 的 image_url 格式发送

## 打开方式

1. 解压 zip。
2. 用 Xcode 打开 `AIWorkflowStudio.xcodeproj`。
3. 选择自己的 Team / Bundle ID。
4. 在 iPhone 或 iPad 模拟器运行。
5. 进入设置，添加 OpenAI-compatible API Base URL 和 API Key。
6. 点击“刷新模型列表”，设置默认文本模型和视觉模型。

## 注意

- 第一版主打 OpenAI-compatible `/v1/models` 与 `/v1/chat/completions`。
- Anthropic、Gemini 原生接口、Volcengine Responses 等需要后续写 Provider Adapter。
- iOS 本地真正 ZIP 压缩需要额外实现或引入库；当前项目先保留“文件打包者 / ZIP 项目包草案”模块结构。
- 图片生成接口差异很大，当前先保留模块与模型设置入口。
