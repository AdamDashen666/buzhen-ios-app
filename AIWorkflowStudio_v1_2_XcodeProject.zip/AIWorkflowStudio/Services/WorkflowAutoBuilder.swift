import Foundation

enum WorkflowAutoBuilder {
    static func build(from project: WorkflowProject) -> WorkflowProject {
        var newProject = project
        let lower = project.userPrompt.lowercased()
        let hasImage = !project.resources.filter { $0.kind == .image }.isEmpty || lower.contains("图片") || lower.contains("截图") || lower.contains("image") || lower.contains("ocr")
        let isCode = lower.contains("代码") || lower.contains("app") || lower.contains("xcode") || lower.contains("swift") || lower.contains("python") || lower.contains("javascript") || lower.contains("网页") || lower.contains("项目")
        let wantsImageGeneration = lower.contains("生成图片") || lower.contains("图标") || lower.contains("插图") || lower.contains("image generation")
        let complex = lower.count > 120 || lower.contains("复杂") || lower.contains("多模型") || lower.contains("投票") || lower.contains("工作流")

        var kinds: [WorkflowNodeKind] = [.start, .planner]
        if hasImage { kinds.append(.imageUnderstanding) }
        if complex { kinds.append(.dispatcher) }
        if isCode {
            kinds += [.codeWorker, .codeReviewer, .autoFixer]
        } else {
            kinds += [.worker, .qualityReviewer]
        }
        if wantsImageGeneration { kinds += [.imageGenerator, .visualReviewer] }
        if complex { kinds += [.multiModelVote] }
        kinds += [.aggregator, .logger, .versionSnapshot, .output]

        var seen = Set<WorkflowNodeKind>()
        kinds = kinds.filter { seen.insert($0).inserted }

        var nodes: [WorkflowNode] = []
        for (index, kind) in kinds.enumerated() {
            var node = WorkflowNode(kind: kind, title: kind.title, x: 150 + Double(index % 4) * 250, y: 180 + Double(index / 4) * 190)
            node.prompt = kind.defaultPrompt
            node.maxReturnCount = 0
            node.retryLimit = 0
            node.temperature = kind == .codeReviewer || kind == .qualityReviewer ? 0.1 : 0.3
            nodes.append(node)
        }

        newProject.nodes = nodes
        // v1.2：AI 自动选择模块只创建模块，不再自动连线。用户必须手动拖拽端口连接。
        newProject.edges = []
        newProject.updatedAt = Date()
        return newProject
    }
}
