from __future__ import annotations

import plistlib
import unittest
from pathlib import Path


class IOSBundleTests(unittest.TestCase):
    def test_ats_allows_the_paired_tailscale_agent_only(self) -> None:
        root = Path(__file__).resolve().parents[2]
        plist = plistlib.loads((root / "ios" / "TopazRemote" / "Resources" / "Info.plist").read_bytes())
        ats = plist["NSAppTransportSecurity"]

        self.assertNotIn("NSAllowsLocalNetworking", ats)
        self.assertEqual(
            ats["NSExceptionDomains"]["desktop-inn4klw-1.taildee45d.ts.net"]["NSTemporaryExceptionAllowsInsecureHTTPLoads"],
            True,
        )

    def test_completed_video_download_reports_streaming_progress(self) -> None:
        root = Path(__file__).resolve().parents[2]
        coordinator = (root / "ios" / "TopazRemote" / "Transfer" / "DownloadCoordinator.swift").read_text(encoding="utf-8")
        job_row = (root / "ios" / "TopazRemote" / "Features" / "ContentView.swift").read_text(encoding="utf-8")

        self.assertIn("URLSessionDownloadDelegate", coordinator)
        self.assertIn("didWriteData", coordinator)
        self.assertIn("DownloadProgress.fraction", coordinator)
        self.assertIn("case downloading(progress: Double?)", coordinator)
        self.assertIn("downloadState(for: job.id)", job_row)
        self.assertIn("ProgressView(value: progress)", job_row)

    def test_completed_video_download_uses_a_background_session(self) -> None:
        root = Path(__file__).resolve().parents[2]
        coordinator = (root / "ios" / "TopazRemote" / "Transfer" / "DownloadCoordinator.swift").read_text(encoding="utf-8")
        app = (root / "ios" / "TopazRemote" / "App" / "TopazRemoteApp.swift").read_text(encoding="utf-8")

        self.assertIn("backgroundSessionIdentifier", coordinator)
        self.assertIn("URLSessionConfiguration.background", coordinator)
        self.assertIn("handleEventsForBackgroundURLSession", app)

    def test_background_download_state_survives_an_app_relaunch(self) -> None:
        root = Path(__file__).resolve().parents[2]
        coordinator = (root / "ios" / "TopazRemote" / "Transfer" / "DownloadCoordinator.swift").read_text(encoding="utf-8")

        self.assertIn("activeJobIDsKey", coordinator)
        self.assertIn("UserDefaults.standard", coordinator)
        self.assertIn("activeJobIDs.contains(jobID)", coordinator)
