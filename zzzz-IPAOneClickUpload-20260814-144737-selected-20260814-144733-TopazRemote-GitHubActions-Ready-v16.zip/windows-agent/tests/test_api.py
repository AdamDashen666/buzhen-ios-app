from __future__ import annotations

import json
from http.client import HTTPConnection
import sys
import tempfile
import threading
import unittest
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from topazremote.server import create_server


class ApiTests(unittest.TestCase):
    def setUp(self) -> None:
        self.tempdir = tempfile.TemporaryDirectory()
        self.server = create_server(Path(self.tempdir.name), "127.0.0.1", 0)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.base = f"http://127.0.0.1:{self.server.server_port}/api/v1"

    def tearDown(self) -> None:
        self.server.shutdown(); self.server.server_close(); self.tempdir.cleanup()

    def test_health_is_public_but_capabilities_require_bearer_token(self) -> None:
        """Removing authentication would expose Topaz capability details to any reachable client."""
        with urlopen(self.base + "/health") as response:
            self.assertEqual(json.load(response)["status"], "ok")
        with self.assertRaises(HTTPError) as error:
            urlopen(self.base + "/capabilities")
        self.assertEqual(error.exception.code, 401)
        request = Request(self.base + "/capabilities", headers={"Authorization": f"Bearer {self.server.token}"})
        with urlopen(request) as response:
            body = json.load(response)
        self.assertEqual(body["apiVersion"], "v1")
        self.assertIn("enhancementModels", body)

    def test_capabilities_can_include_runtime_detection(self) -> None:
        """The Agent must not silently merge an empty detection object when Topaz evidence is available."""
        self.server.shutdown(); self.server.server_close()
        self.server = create_server(Path(self.tempdir.name), "127.0.0.1", 0, detected_capabilities={"enhancementModels": [{"id": "local-up", "displayName": "Local", "available": True, "parameters": []}], "interpolationModels": []})
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True); self.thread.start()
        self.base = f"http://127.0.0.1:{self.server.server_port}/api/v1"
        request = Request(self.base + "/capabilities", headers={"Authorization": f"Bearer {self.server.token}"})
        with urlopen(request) as response: body = json.load(response)
        self.assertIn("local-up", [model["id"] for model in body["enhancementModels"]])

    def test_server_routes_media_to_explicit_media_directory(self) -> None:
        """A user's chosen media folder must be independent from Agent configuration and database files."""
        self.server.shutdown(); self.server.server_close()
        media_root = Path(self.tempdir.name) / "Desktop" / "远程topaz"
        self.server = create_server(Path(self.tempdir.name) / "agent-data", "127.0.0.1", 0, media_root=media_root)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True); self.thread.start()

        self.assertEqual(self.server.storage.sources, media_root)
        self.assertEqual(self.server.storage.outputs, media_root)
        self.assertEqual(self.server.storage.uploads, Path(self.tempdir.name) / "agent-data" / "uploads")

    def test_jobs_returns_persisted_jobs(self) -> None:
        """Returning an in-memory list would hide jobs after a restart."""
        self.server.database.create_job("clip.mp4", {"enhancement": {"model": "prob-4"}})
        request = Request(self.base + "/jobs", headers={"Authorization": f"Bearer {self.server.token}"})
        with urlopen(request) as response:
            jobs = json.load(response)
        self.assertEqual(jobs[0]["sourceFilename"], "clip.mp4")

    def test_returns_one_persisted_job_with_progress(self) -> None:
        """Polling a single job must expose SQLite-backed progress after the app returns to foreground."""
        job_id = self.server.database.create_job("clip.mp4", {"enhancement": {"model": "prob-4", "scale": 1}})
        self.server.database.set_progress(job_id, {"stage": "topaz", "overallProgress": 0.25, "processedFrames": 10, "totalFrames": None, "fps": None, "etaSeconds": None})
        request = Request(self.base + f"/jobs/{job_id}", headers={"Authorization": f"Bearer {self.server.token}"})
        with urlopen(request) as response: job = json.load(response)
        self.assertEqual(job["id"], job_id)
        self.assertEqual(job["progress"]["overallProgress"], 0.25)

    def test_upload_resumes_and_completes_without_loading_whole_file(self) -> None:
        """Dropping the received-chunk map would force an iPhone to restart a large upload."""
        headers = {"Authorization": f"Bearer {self.server.token}", "Content-Type": "application/json"}
        create = Request(self.base + "/uploads", data=b'{"filename":"clip.mp4","size":11}', headers=headers, method="POST")
        with urlopen(create) as response: upload_id = json.load(response)["id"]
        chunk = Request(self.base + f"/uploads/{upload_id}/chunks/0", data=b"hello world", headers={"Authorization": f"Bearer {self.server.token}"}, method="PUT")
        with urlopen(chunk) as response: self.assertEqual(response.status, 204)
        status = Request(self.base + f"/uploads/{upload_id}", headers={"Authorization": f"Bearer {self.server.token}"})
        with urlopen(status) as response: self.assertEqual(json.load(response)["receivedChunks"], [0])
        complete = Request(self.base + f"/uploads/{upload_id}/complete", data=b"{}", headers=headers, method="POST")
        with urlopen(complete) as response: self.assertEqual(json.load(response)["sourceFilename"], "clip.mp4")

    def test_upload_chunks_close_the_connection_after_an_acknowledgement(self) -> None:
        """A later control POST must not be parsed as leftover bytes from a prior upload request."""
        headers = {"Authorization": f"Bearer {self.server.token}", "Content-Type": "application/json"}
        create = Request(self.base + "/uploads", data=b'{"filename":"clip.mp4","size":2}', headers=headers, method="POST")
        with urlopen(create) as response:
            ticket = json.load(response)
        self.assertEqual(ticket["chunkSize"], 1024 * 1024)

        connection = HTTPConnection("127.0.0.1", self.server.server_port, timeout=2)
        connection.request("PUT", f"/api/v1/uploads/{ticket['id']}/chunks/0", body=b"hi", headers={"Authorization": f"Bearer {self.server.token}"})
        response = connection.getresponse()
        self.assertEqual(response.version, 11)
        self.assertEqual(response.getheader("Content-Length"), "0")
        self.assertEqual(response.getheader("Connection"), "close")
        response.read()
        connection.close()

    def test_completed_output_supports_byte_range_resume(self) -> None:
        """Ignoring Range would make large finished videos restart from byte zero on every iOS interruption."""
        job_id = self.server.database.create_job("clip.mp4", {})
        output = Path(self.tempdir.name) / "output.mp4"; output.write_bytes(b"abcdefghij")
        self.server.database.set_output_path(job_id, output)
        request = Request(self.base + f"/jobs/{job_id}/output", headers={"Authorization": f"Bearer {self.server.token}", "Range": "bytes=3-6"})
        with urlopen(request) as response:
            self.assertEqual(response.status, 206); self.assertEqual(response.headers["Content-Range"], "bytes 3-6/10"); self.assertEqual(response.read(), b"defg")

    def test_creates_persisted_job_from_completed_source(self) -> None:
        """Creating a job without a completed Agent source would let clients point processing at arbitrary files."""
        self.server.storage.sources.joinpath("clip.mp4").write_bytes(b"source")
        request = Request(self.base + "/jobs", data=b'{"sourceFilename":"clip.mp4","settings":{"enhancement":{"model":"prob-4","scale":1}}}', headers={"Authorization": f"Bearer {self.server.token}", "Content-Type":"application/json"}, method="POST")
        with urlopen(request) as response: job = json.load(response)
        self.assertEqual(job["status"], "created"); self.assertEqual(job["sourceFilename"], "clip.mp4")

    def test_cancels_only_queued_job(self) -> None:
        """A broad cancellation could kill a Topaz task that this Agent did not start."""
        job_id = self.server.database.create_job("clip.mp4", {})
        request = Request(self.base + f"/jobs/{job_id}/cancel", data=b"{}", headers={"Authorization": f"Bearer {self.server.token}"}, method="POST")
        with urlopen(request) as response: self.assertEqual(json.load(response)["status"], "cancelled")

    def test_rejects_chunk_larger_than_declared_transport_limit(self) -> None:
        """Reading an unbounded request body would let one paired client exhaust Agent memory."""
        headers = {"Authorization": f"Bearer {self.server.token}", "Content-Type": "application/json"}
        with urlopen(Request(self.base + "/uploads", data=b'{"filename":"clip.mp4","size":9000000}', headers=headers, method="POST")) as response: upload_id = json.load(response)["id"]
        request = Request(self.base + f"/uploads/{upload_id}/chunks/0", data=b"x" * (8 * 1024 * 1024 + 1), headers={"Authorization": f"Bearer {self.server.token}"}, method="PUT")
        with self.assertRaises(HTTPError) as error: urlopen(request)
        self.assertEqual(error.exception.code, 413)


if __name__ == "__main__": unittest.main()
