import SwiftUI
import PhotosUI
import Photos
import UniformTypeIdentifiers

struct ContentView: View {
    @ObservedObject var pairing: PairingSettings
    @State private var capabilities: CapabilityResponse?
    @State private var jobs: [Job] = []
    @State private var error: String?

    var body: some View {
        TabView {
            NavigationStack { dashboard }.tabItem { Label("Dashboard", systemImage: "gauge.with.dots.needle.50percent") }
            NavigationStack { NewJobView(settings: pairing.agentSettings, capabilities: capabilities, submitted: refresh) }.tabItem { Label("New Job", systemImage: "plus.circle.fill") }
            NavigationStack { jobsView }.tabItem { Label("Jobs", systemImage: "list.bullet.rectangle") }
            NavigationStack { SettingsView(pairing: pairing, refresh: refresh) }.tabItem { Label("Settings", systemImage: "gearshape") }
        }
        .task { await refresh() }
        .alert("Connection problem", isPresented: Binding(get: { error != nil }, set: { if !$0 { error = nil } })) { Button("OK", role: .cancel) {} } message: { Text(error ?? "") }
    }

    private var dashboard: some View {
        List {
            Section("Your PC") {
                LabeledContent("Address", value: pairing.host.isEmpty ? "Not paired" : pairing.host)
                LabeledContent("Topaz", value: capabilities?.agentVersion ?? "Connect to load")
            }
            Section("Active Jobs") {
                if jobs.isEmpty { ContentUnavailableView("No jobs yet", systemImage: "film", description: Text("Choose New Job to upload a video.")) }
                else { ForEach(jobs.prefix(3)) { JobRow(job: $0, settings: pairing.agentSettings, cancel: cancel) } }
            }
        }
        .navigationTitle("Topaz Remote")
        .toolbar { Button("Refresh", systemImage: "arrow.clockwise") { Task { await refresh() } }.accessibilityLabel("Refresh PC status") }
    }

    private var jobsView: some View { List(jobs) { JobRow(job: $0, settings: pairing.agentSettings, cancel: cancel) }.navigationTitle("Jobs") }

    @MainActor private func refresh() async {
        let settings = pairing.agentSettings
        guard !settings.host.isEmpty, !settings.token.isEmpty else { return }
        do {
            async let loadedCapabilities = AgentClient(settings: settings).capabilities()
            async let loadedJobs = AgentClient(settings: settings).jobs()
            capabilities = try await loadedCapabilities
            jobs = try await loadedJobs
        } catch { self.error = error.localizedDescription }
    }

    @MainActor private func cancel(_ job: Job) async {
        do { _ = try await AgentClient(settings: pairing.agentSettings).cancelJob(id: job.id); await refresh() }
        catch { self.error = error.localizedDescription }
    }
}

struct JobRow: View {
    let job: Job
    let settings: AgentSettings
    let cancel: (Job) async -> Void
    @ObservedObject private var downloads = DownloadCoordinator.shared
    @State private var downloadError: String?

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(job.sourceFilename ?? "Video job").font(.headline)
            Text(job.status.replacingOccurrences(of: "_", with: " ").capitalized).foregroundStyle(.secondary)
            if let progress = job.progress?.overallProgress { ProgressView(value: progress) }
            if let failureReason = job.failureReason, job.status == "failed" { Text(failureReason).font(.footnote).foregroundStyle(.red).lineLimit(3) }
            if ["created", "processing"].contains(job.status) { Button("Cancel", role: .destructive) { Task { await cancel(job) } } }
            if job.status == "completed" {
                downloadControls
            }
        }.accessibilityElement(children: .combine)
        .alert("Unable to save video", isPresented: Binding(get: { downloadError != nil }, set: { if !$0 { downloadError = nil } })) { Button("OK", role: .cancel) {} } message: { Text(downloadError ?? "") }
    }

    @ViewBuilder private var downloadControls: some View {
        switch downloads.downloadState(for: job.id) {
        case .idle:
            Button("Save Video") { startDownload() }
        case .downloading(let progress):
            Button(downloadButtonTitle(for: progress)) {}.disabled(true)
            if let progress {
                ProgressView(value: progress) {
                    Text("Downloading \(Int((progress * 100).rounded()))%")
                }
                .accessibilityLabel("Video download progress")
                .accessibilityValue("\(Int((progress * 100).rounded())) percent")
            } else {
                ProgressView("Downloading video…")
                    .accessibilityLabel("Downloading video")
            }
            Text("Continues when Topaz Remote is in the background.")
                .font(.footnote)
                .foregroundStyle(.secondary)
        case .completed(let savedURL):
            Label("Downloaded on this iPad", systemImage: "checkmark.circle.fill")
                .foregroundStyle(.green)
            ShareLink(item: savedURL) { Label("Share", systemImage: "square.and.arrow.up") }
            Button("Save to Photos") { Task { await saveToPhotos(savedURL) } }
        case .failed(let message):
            Button("Retry Download") { startDownload() }
            Text(message).font(.footnote).foregroundStyle(.red).lineLimit(2)
        }
    }

    private func startDownload() {
        do { try downloads.startDownload(jobID: job.id, client: AgentClient(settings: settings)) }
        catch { downloadError = error.localizedDescription }
    }

    private func downloadButtonTitle(for progress: Double?) -> String {
        guard let progress else { return "Downloading…" }
        return "Downloading \(Int((progress * 100).rounded()))%"
    }

    @MainActor private func saveToPhotos(_ url: URL) async {
        do { try await PHPhotoLibrary.shared().performChanges { PHAssetChangeRequest.creationRequestForAssetFromVideo(atFileURL: url) } }
        catch { downloadError = error.localizedDescription }
    }
}

struct NewJobView: View {
    let settings: AgentSettings
    let capabilities: CapabilityResponse?
    let submitted: () async -> Void
    @State private var importerPresented = false
    @State private var photoItem: PhotosPickerItem?
    @State private var enhancementEnabled = true
    @State private var selectedModel = ""
    @State private var interpolationEnabled = false
    @State private var selectedInterpolationModel = ""
    @State private var outputFPS = 60.0
    @State private var scale = 1
    @State private var parameterValues: [String: ParameterValue] = [:]
    @State private var selectedURL: URL?
    @State private var uploadProgress = 0.0
    @State private var isSubmitting = false
    @State private var error: String?

    var body: some View {
        Form {
            Section("Source") {
                Button(selectedURL == nil ? "Choose video from Files" : "Change selected video") { importerPresented = true }
                PhotosPicker(selection: $photoItem, matching: .videos) { Text("Choose video from Photos") }
                if let selectedURL { Text(selectedURL.lastPathComponent).lineLimit(1).foregroundStyle(.secondary) }
                Text("To select a video from Photos, save it to Files first. Uploads stream in chunks and do not load the full video into memory.").font(.footnote).foregroundStyle(.secondary)
            }
            Section("Processing") {
                Toggle("Enhancement", isOn: $enhancementEnabled)
                if enhancementEnabled, let capabilities {
                    let models = capabilities.enhancementModels.filter { $0.available != false }
                    if models.isEmpty { ContentUnavailableView("No verified enhancement model", systemImage: "exclamationmark.triangle", description: Text("Install a Topaz model locally, then rescan the Agent.")) }
                    else {
                    Picker("Model", selection: $selectedModel) {
                        ForEach(models) { Text($0.displayName).tag($0.id) }
                    }
                    Stepper("Scale: \(scale)x", value: $scale, in: 0...4)
                    if let model = models.first(where: { $0.id == selectedModel }) { DynamicParameterForm(parameters: model.parameters.filter { $0.id != "scale" }, values: $parameterValues) }
                    }
                } else if enhancementEnabled {
                    ContentUnavailableView("Connect to your PC", systemImage: "wifi.exclamationmark", description: Text("Available models appear after pairing."))
                }
                Toggle("Frame Interpolation", isOn: $interpolationEnabled)
                if interpolationEnabled, let capabilities {
                    let models = capabilities.interpolationModels.filter { $0.available != false }
                    if models.isEmpty { ContentUnavailableView("No verified interpolation model", systemImage: "exclamationmark.triangle", description: Text("Install a Topaz model locally, then rescan the Agent.")) }
                    else {
                        Picker("Interpolation model", selection: $selectedInterpolationModel) { ForEach(models) { Text($0.displayName).tag($0.id) } }
                        Stepper(value: $outputFPS, in: 1...480, step: 1) { Text("Output FPS: \(Int(outputFPS))") }
                    }
                }
            }
            if isSubmitting { Section("Upload") { ProgressView(value: uploadProgress) { Text("Uploading") } } }
            Section { Button(isSubmitting ? "Submitting..." : "Upload & Queue") { Task { await uploadAndQueue() } }.disabled(!canSubmit) }
        }
        .navigationTitle("New Job")
        .fileImporter(isPresented: $importerPresented, allowedContentTypes: [.movie]) { result in
            switch result { case .success(let url): selectedURL = url; case .failure(let error): self.error = error.localizedDescription }
        }
        .onChange(of: photoItem) { _, item in
            guard let item else { return }
            Task { await importPhotoVideo(item) }
        }
        .onChange(of: capabilities?.enhancementModels) { _, models in
            if selectedModel.isEmpty { selectedModel = models?.first(where: { $0.available != false })?.id ?? "" }
        }
        .onChange(of: capabilities?.interpolationModels) { _, models in
            if selectedInterpolationModel.isEmpty { selectedInterpolationModel = models?.first(where: { $0.available != false })?.id ?? "" }
        }
        .alert("Unable to queue job", isPresented: Binding(get: { error != nil }, set: { if !$0 { error = nil } })) { Button("OK", role: .cancel) {} } message: { Text(error ?? "") }
    }

    private var canSubmit: Bool { selectedURL != nil && (enhancementEnabled ? !selectedModel.isEmpty : interpolationEnabled && !selectedInterpolationModel.isEmpty) && !settings.host.isEmpty && !settings.token.isEmpty && !isSubmitting }

    @MainActor private func uploadAndQueue() async {
        guard let selectedURL else { return }
        isSubmitting = true; uploadProgress = 0
        defer { isSubmitting = false }
        do {
            let client = AgentClient(settings: settings)
            let sourceFilename = try await UploadCoordinator.upload(url: selectedURL, client: client) { value in self.uploadProgress = value }
            var processing: [String: Any] = [:]
            if enhancementEnabled {
                var enhancement: [String: Any] = ["model": selectedModel, "scale": scale]
                for parameter in capabilities?.enhancementModels.first(where: { $0.id == selectedModel })?.parameters ?? [] {
                    if let value = parameterValues[parameter.id] { enhancement[parameter.id] = parameterJSON(parameter, value: value) }
                }
                processing["enhancement"] = enhancement
            }
            if interpolationEnabled { processing["interpolation"] = ["model": selectedInterpolationModel, "fps": outputFPS] }
            _ = try await client.createJob(sourceFilename: sourceFilename, settings: processing)
            await submitted()
        } catch { self.error = error.localizedDescription }
    }

    @MainActor private func importPhotoVideo(_ item: PhotosPickerItem) async {
        do { selectedURL = try await item.loadTransferable(type: VideoTransferable.self)?.url }
        catch { self.error = error.localizedDescription }
    }
}

struct DynamicParameterForm: View {
    let parameters: [CapabilityParameter]
    @Binding var values: [String: ParameterValue]

    var body: some View {
        ForEach(parameters) { parameter in
            switch parameter.type {
            case "boolean":
                Toggle(parameter.displayName ?? parameter.id, isOn: Binding(get: { boolValue(parameter) }, set: { values[parameter.id] = .bool($0) }))
            case "enum":
                Picker(parameter.displayName ?? parameter.id, selection: Binding(get: { stringValue(parameter) }, set: { values[parameter.id] = .string($0) })) {
                    ForEach(parameter.options ?? [], id: \.value) { Text($0.label).tag($0.value) }
                }
            case "number", "integer":
                Stepper(value: Binding(get: { numberValue(parameter) }, set: { values[parameter.id] = .number($0) }), in: (parameter.min ?? 0)...(parameter.max ?? 100), step: parameter.step ?? 1) { Text("\(parameter.displayName ?? parameter.id): \(numberValue(parameter), specifier: "%.2f")") }
            default: EmptyView()
            }
        }
    }

    private func boolValue(_ parameter: CapabilityParameter) -> Bool { if case .bool(let value) = values[parameter.id] ?? parameter.default { return value }; return false }
    private func stringValue(_ parameter: CapabilityParameter) -> String { if case .string(let value) = values[parameter.id] ?? parameter.default { return value }; return parameter.options?.first?.value ?? "" }
    private func numberValue(_ parameter: CapabilityParameter) -> Double { if case .number(let value) = values[parameter.id] ?? parameter.default { return value }; return parameter.min ?? 0 }
}

struct SettingsView: View {
    @ObservedObject var pairing: PairingSettings
    let refresh: () async -> Void

    var body: some View {
        Form {
            Section("Computer") {
                TextField("Tailscale address", text: $pairing.host).textInputAutocapitalization(.never).autocorrectionDisabled().keyboardType(.URL)
                Stepper("Port: \(pairing.port)", value: $pairing.port, in: 1024...65535)
                SecureField("Pairing token", text: $pairing.token)
                Button("Test Connection") { Task { await refresh() } }.disabled(pairing.host.isEmpty || pairing.token.isEmpty)
            }
            Section("Privacy") { Text("Topaz Remote never changes Tailscale, VPN, proxy, DNS, routing, or firewall settings.").font(.footnote).foregroundStyle(.secondary) }
        }.navigationTitle("Settings")
    }
}
