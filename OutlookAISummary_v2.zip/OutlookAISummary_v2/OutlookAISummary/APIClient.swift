import Foundation

final class APIClient {
    var baseURL: String
    let session: URLSession

    init(baseURL: String, session: URLSession = .shared) {
        self.baseURL = baseURL.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        self.session = session
    }

    private func url(_ path: String, query: [URLQueryItem] = []) throws -> URL {
        guard var components = URLComponents(string: baseURL + path) else {
            throw URLError(.badURL)
        }
        if !query.isEmpty { components.queryItems = query }
        guard let url = components.url else { throw URLError(.badURL) }
        return url
    }

    private func request<T: Decodable>(_ path: String, method: String = "GET", body: Encodable? = nil, query: [URLQueryItem] = []) async throws -> T {
        var request = URLRequest(url: try url(path, query: query))
        request.httpMethod = method
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        if let body {
            request.httpBody = try JSONEncoder().encode(AnyEncodable(body))
        }

        let (data, response) = try await session.data(for: request)
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            let text = String(data: data, encoding: .utf8) ?? "Unknown error"
            throw NSError(domain: "Backend", code: 1, userInfo: [NSLocalizedDescriptionKey: text])
        }
        return try JSONDecoder().decode(T.self, from: data)
    }

    func registerDevice(deviceId: String, deviceToken: String?) async throws -> DeviceRegisterResponse {
        try await request("/devices/register", method: "POST", body: DeviceRegisterRequest(
            deviceId: deviceId,
            deviceToken: deviceToken ?? "",
            platform: "iOS"
        ))
    }

    func authStartURL(deviceId: String) -> URL? {
        var components = URLComponents(string: baseURL + "/auth/start")
        components?.queryItems = [URLQueryItem(name: "deviceId", value: deviceId)]
        return components?.url
    }

    func authStatus(deviceId: String) async throws -> AuthStatusResponse {
        try await request("/auth/status", query: [URLQueryItem(name: "deviceId", value: deviceId)])
    }

    func updateSettings(deviceId: String, settings: AppSettings) async throws -> SettingsResponse {
        try await request("/settings", method: "POST", body: SettingsUpdateRequest(deviceId: deviceId, settings: settings))
    }

    func summaries(deviceId: String) async throws -> SummariesResponse {
        try await request("/summaries", query: [URLQueryItem(name: "deviceId", value: deviceId)])
    }

    func runNow(deviceId: String) async throws -> RunSummaryResponse {
        try await request("/summarize/run", method: "POST", body: DeviceOnlyRequest(deviceId: deviceId))
    }
}

private struct DeviceRegisterRequest: Encodable {
    let deviceId: String
    let deviceToken: String
    let platform: String
}

private struct SettingsUpdateRequest: Encodable {
    let deviceId: String
    let settings: AppSettings
}

private struct DeviceOnlyRequest: Encodable {
    let deviceId: String
}

struct AnyEncodable: Encodable {
    private let encodeClosure: (Encoder) throws -> Void

    init(_ wrapped: Encodable) {
        encodeClosure = wrapped.encode
    }

    func encode(to encoder: Encoder) throws {
        try encodeClosure(encoder)
    }
}
