import Foundation
import SwiftUI
import UserNotifications
import UIKit

@MainActor
final class AppState: ObservableObject {
    @Published var backendURL: String {
        didSet {
            UserDefaults.standard.set(backendURL, forKey: "backendURL")
            api.baseURL = backendURL.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        }
    }
    @Published var linkedUser: LinkedUser?
    @Published var summaries: [SummaryItem] = []
    @Published var settings = AppSettings()
    @Published var isLoading = false
    @Published var statusText = "未连接"
    @Published var lastError: String?
    @Published var pushToken: String?

    let deviceId: String
    let api: APIClient

    init() {
        let savedBackend = UserDefaults.standard.string(forKey: "backendURL") ?? ""
        self.backendURL = savedBackend
        self.api = APIClient(baseURL: savedBackend)
        if let savedDeviceId = UserDefaults.standard.string(forKey: "deviceId") {
            self.deviceId = savedDeviceId
        } else {
            let newId = UUID().uuidString
            UserDefaults.standard.set(newId, forKey: "deviceId")
            self.deviceId = newId
        }
    }

    func bootstrap() async {
        await registerDevice()
        await refreshAll()
    }

    var backendValidationMessage: String? {
        let raw = backendURL.trimmingCharacters(in: .whitespacesAndNewlines)
        if raw.isEmpty {
            return "先到设置里填写后端地址。真机需要 HTTPS 后端地址，不能直接用 localhost。"
        }
        guard let components = URLComponents(string: raw),
              let scheme = components.scheme?.lowercased(),
              let host = components.host?.lowercased(),
              ["http", "https"].contains(scheme) else {
            return "后端地址格式不正确。示例：https://你的后端域名"
        }

        #if targetEnvironment(simulator)
        return nil
        #else
        if host == "localhost" || host == "127.0.0.1" || host == "::1" {
            return "真机里的 localhost 是 iPad/iPhone 自己，不是后端服务器。请填部署后的 HTTPS 地址，或用 ngrok/Cloudflare Tunnel 暴露本地后端。"
        }
        return nil
        #endif
    }

    func registerDevice() async {
        guard backendValidationMessage == nil else {
            statusText = "请先配置后端地址"
            return
        }
        do {
            _ = try await api.registerDevice(deviceId: deviceId, deviceToken: pushToken)
        } catch {
            lastError = error.localizedDescription
        }
    }

    func refreshAll() async {
        if let message = backendValidationMessage {
            linkedUser = nil
            statusText = "请先配置后端地址"
            lastError = message
            return
        }
        isLoading = true
        defer { isLoading = false }
        do {
            let status = try await api.authStatus(deviceId: deviceId)
            if status.linked {
                linkedUser = status.user
                statusText = status.user?.email ?? "已连接"
                if let remoteSettings = status.user?.settings {
                    settings = remoteSettings
                }
                let response = try await api.summaries(deviceId: deviceId)
                summaries = response.summaries
            } else {
                linkedUser = nil
                statusText = "未连接 Outlook"
            }
            lastError = nil
        } catch {
            lastError = error.localizedDescription
        }
    }

    func openMicrosoftLogin() {
        if let message = backendValidationMessage {
            lastError = message
            return
        }
        guard let url = api.authStartURL(deviceId: deviceId) else {
            lastError = "后端登录地址生成失败。请检查后端地址。"
            return
        }
        UIApplication.shared.open(url)
    }

    func saveSettings() async {
        if let message = backendValidationMessage {
            lastError = message
            return
        }
        isLoading = true
        defer { isLoading = false }
        do {
            let response = try await api.updateSettings(deviceId: deviceId, settings: settings)
            settings = response.settings
            lastError = nil
            await refreshAll()
        } catch {
            lastError = error.localizedDescription
        }
    }

    func runNow() async {
        if let message = backendValidationMessage {
            lastError = message
            return
        }
        isLoading = true
        defer { isLoading = false }
        do {
            let response = try await api.runNow(deviceId: deviceId)
            if let summary = response.summary {
                summaries.insert(summary, at: 0)
            }
            lastError = nil
        } catch {
            lastError = error.localizedDescription
        }
    }

    func requestNotifications() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .badge, .sound]) { granted, error in
            DispatchQueue.main.async {
                if let error { self.lastError = error.localizedDescription }
                if granted { UIApplication.shared.registerForRemoteNotifications() }
            }
        }
    }

    func updatePushToken(_ token: String) {
        pushToken = token
        Task { await registerDevice() }
    }
}
