import SwiftUI

struct RootView: View {
    @EnvironmentObject private var state: AppState

    var body: some View {
        ZStack {
            LiquidBackground()
            NavigationSplitView {
                List {
                    NavigationLink {
                        DashboardView()
                    } label: {
                        Label("总览", systemImage: "mail.stack.fill")
                    }
                    NavigationLink {
                        SettingsView()
                    } label: {
                        Label("设置", systemImage: "slider.horizontal.3")
                    }
                }
                .scrollContentBackground(.hidden)
                .navigationTitle("Outlook AI")
            } detail: {
                DashboardView()
            }
            .tint(.white)
        }
        .preferredColorScheme(.dark)
    }
}
