# Outlook AI Summary v2

An iOS SwiftUI app + Node.js backend for scheduled Outlook email summaries.

## Included

- `OutlookAISummary.xcodeproj` — iOS SwiftUI app skeleton with Liquid Glass style UI.
- `Backend/` — Node.js backend for Microsoft OAuth, Outlook Graph mail reading, AI summaries, APNs push, and cleanup.

## v1 defaults

- Chinese summaries.
- Frequency: daily / every 6 hours / monthly.
- Includes unread Junk Email messages.
- Auto cleanup enabled:
  - read or summarized mail older than 30 days -> Deleted Items
  - keep there for 7 days -> permanent delete attempt

## Run locally

1. Start backend:

```bash
cd Backend
cp .env.example .env
npm install
npm start
```

2. Open `OutlookAISummary.xcodeproj` in Xcode.
3. Change signing team and bundle id if needed.
4. Run on iPhone/iPad.
5. In the app Settings, set Backend URL. For a physical iPhone/iPad, use your computer LAN IP, e.g. `http://192.168.1.20:3000`.

## Risk note

This app can delete real Outlook mail after the retention window. Test with a secondary mailbox first.


## v2 fix

- The app no longer opens `localhost` on real iPhone/iPad.
- First launch now asks for a backend URL before Microsoft login.
- Use a deployed HTTPS backend URL, or expose local port 3000 with ngrok/Cloudflare Tunnel.
