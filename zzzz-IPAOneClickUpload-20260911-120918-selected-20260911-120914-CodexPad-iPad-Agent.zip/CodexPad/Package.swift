// swift-tools-version: 6.0
import PackageDescription

let package = Package(
    name: "CodexPad",
    platforms: [.iOS(.v18), .macOS(.v15)],
    products: [
        .library(name: "CodexPadCore", targets: ["CodexPadCore"])
    ],
    targets: [
        .target(name: "CodexPadCore"),
        .testTarget(name: "CodexPadCoreTests", dependencies: ["CodexPadCore"])
    ]
)
