import Foundation
import SwiftUI

@MainActor
final class AppSettings: ObservableObject {
    @Published var baseURL: String { didSet { defaults.set(baseURL, forKey: Keys.baseURL) } }
    @Published var model: String { didSet { defaults.set(model, forKey: Keys.model) } }
    @Published var reasoningEffort: String { didSet { defaults.set(reasoningEffort, forKey: Keys.reasoningEffort) } }
    @Published var autoApply: Bool { didSet { defaults.set(autoApply, forKey: Keys.autoApply) } }
    @Published var allowSensitiveFiles: Bool { didSet { defaults.set(allowSensitiveFiles, forKey: Keys.allowSensitiveFiles) } }

    private let defaults: UserDefaults

    private enum Keys {
        static let baseURL = "api.baseURL"
        static let model = "api.model"
        static let reasoningEffort = "api.reasoningEffort"
        static let autoApply = "agent.autoApply"
        static let allowSensitiveFiles = "agent.allowSensitiveFiles"
    }

    init(defaults: UserDefaults = .standard) {
        self.defaults = defaults
        baseURL = defaults.string(forKey: Keys.baseURL) ?? "https://api.openai.com/v1"
        model = defaults.string(forKey: Keys.model) ?? "gpt-6-astra"
        reasoningEffort = defaults.string(forKey: Keys.reasoningEffort) ?? "high"
        autoApply = defaults.object(forKey: Keys.autoApply) as? Bool ?? false
        allowSensitiveFiles = defaults.object(forKey: Keys.allowSensitiveFiles) as? Bool ?? false
    }
}
