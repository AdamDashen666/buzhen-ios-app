import SwiftUI

struct SettingsView: View {
    @EnvironmentObject private var settings: AppSettings
    @Environment(\.dismiss) private var dismiss
    @State private var apiKey = ""
    @State private var keyStatus = ""

    var body: some View {
        NavigationStack {
            Form {
                Section("API") {
                    SecureField("API key", text: $apiKey)
                        .textContentType(.password)
                        .autocorrectionDisabled()
                    HStack {
                        Button("Save API Key") { saveKey() }
                        Button("Remove", role: .destructive) { removeKey() }
                        Spacer()
                        Text(keyStatus).foregroundStyle(.secondary)
                    }
                    TextField("Base URL", text: $settings.baseURL)
                        .textInputAutocapitalization(.never).autocorrectionDisabled()
                    TextField("Model", text: $settings.model)
                        .textInputAutocapitalization(.never).autocorrectionDisabled()
                    Picker("Reasoning", selection: $settings.reasoningEffort) {
                        Text("Low").tag("low")
                        Text("Medium").tag("medium")
                        Text("High").tag("high")
                        Text("Extra High").tag("xhigh")
                    }
                }

                Section("Agent Safety") {
                    Toggle("Auto Apply Edits", isOn: $settings.autoApply)
                    Text("When off, every write/create/delete/move pauses for your approval.")
                        .font(.caption).foregroundStyle(.secondary)
                    Toggle("Allow Agent to Read Sensitive Files", isOn: $settings.allowSensitiveFiles)
                    Text("Off by default. Blocks common secrets such as .env, .p8, .p12, private SSH keys, and .git contents from agent tools.")
                        .font(.caption).foregroundStyle(.secondary)
                }

                Section("iPadOS Limitations") {
                    Text("CodexPad can read and edit the folder you choose in Files. iPadOS does not grant arbitrary filesystem access or a general shell, so this app cannot run local xcodebuild, git, package managers, or arbitrary processes.")
                }
            }
            .navigationTitle("Settings")
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Done") { dismiss() } } }
            .onAppear { loadKeyStatus() }
        }
    }

    private func loadKeyStatus() {
        do { keyStatus = (try KeychainStore().loadAPIKey()) == nil ? "Not set" : "Saved" }
        catch { keyStatus = "Error" }
    }

    private func saveKey() {
        do {
            try KeychainStore().saveAPIKey(apiKey.trimmingCharacters(in: .whitespacesAndNewlines))
            apiKey = ""
            keyStatus = "Saved"
        } catch { keyStatus = error.localizedDescription }
    }

    private func removeKey() {
        KeychainStore().deleteAPIKey()
        apiKey = ""
        keyStatus = "Removed"
    }
}
