import SwiftUI

struct EditorView: View {
    @EnvironmentObject private var workspace: WorkspaceStore

    var body: some View {
        Group {
            if let path = workspace.selectedPath {
                VStack(spacing: 0) {
                    HStack {
                        Text(path).font(.caption.monospaced()).lineLimit(1).truncationMode(.middle)
                        if workspace.isDirty {
                            Circle().frame(width: 7, height: 7).foregroundStyle(.orange)
                        }
                        Spacer()
                        Button("Revert", systemImage: "arrow.uturn.backward") {
                            do { try workspace.revertEditor() }
                            catch { workspace.errorMessage = error.localizedDescription }
                        }
                        .disabled(!workspace.isDirty)
                        Button("Save", systemImage: "square.and.arrow.down") {
                            do { try workspace.saveEditor() }
                            catch { workspace.errorMessage = error.localizedDescription }
                        }
                        .keyboardShortcut("s", modifiers: .command)
                        .disabled(!workspace.isDirty)
                    }
                    .padding(.horizontal, 12).padding(.vertical, 8)
                    Divider()
                    TextEditor(text: $workspace.editorText)
                        .font(.system(.body, design: .monospaced))
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .padding(8)
                }
            } else {
                ContentUnavailableView(
                    "No File Open",
                    systemImage: "doc.text.magnifyingglass",
                    description: Text("Choose a text file from the project browser.")
                )
            }
        }
        .navigationTitle("Editor")
        .navigationBarTitleDisplayMode(.inline)
    }
}
