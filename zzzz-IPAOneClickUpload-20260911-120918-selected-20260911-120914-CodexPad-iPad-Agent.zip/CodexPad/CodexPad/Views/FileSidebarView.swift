import SwiftUI

struct FileSidebarView: View {
    @EnvironmentObject private var app: AppState
    @EnvironmentObject private var workspace: WorkspaceStore
    let onOpenFile: (String) -> Void

    var body: some View {
        VStack(spacing: 0) {
            header
            Divider()
            if workspace.rootURL == nil {
                ContentUnavailableView(
                    "Open a Project",
                    systemImage: "folder.badge.plus",
                    description: Text("Choose a Files folder. CodexPad only receives access to the folder you select.")
                )
            } else if workspace.entries.isEmpty {
                ContentUnavailableView("Empty Folder", systemImage: "folder")
            } else {
                List {
                    OutlineGroup(workspace.entries, children: \.children) { entry in
                        HStack(spacing: 7) {
                            Image(systemName: entry.isDirectory ? "folder" : icon(for: entry.name))
                                .foregroundStyle(entry.isDirectory ? .secondary : .primary)
                            Text(entry.name).lineLimit(1)
                        }
                        .contentShape(Rectangle())
                        .onTapGesture {
                            if !entry.isDirectory { onOpenFile(entry.path) }
                        }
                    }
                }
                .listStyle(.sidebar)
            }
        }
        .toolbar {
            ToolbarItemGroup(placement: .topBarTrailing) {
                Button { try? workspace.refreshTree() } label: { Image(systemName: "arrow.clockwise") }
                    .disabled(workspace.rootURL == nil)
                Button { app.showingSettings = true } label: { Image(systemName: "gearshape") }
            }
        }
    }

    private var header: some View {
        HStack {
            VStack(alignment: .leading, spacing: 2) {
                Text(workspace.displayName).font(.headline).lineLimit(1)
                Text(workspace.rootURL == nil ? "No folder selected" : "Local workspace")
                    .font(.caption).foregroundStyle(.secondary)
            }
            Spacer()
            Menu {
                Button("Open Folder…", systemImage: "folder.badge.plus") { app.showingFolderImporter = true }
                if workspace.rootURL != nil {
                    Button("Close Folder", systemImage: "xmark.circle", role: .destructive) { workspace.closeFolder() }
                }
            } label: {
                Image(systemName: "ellipsis.circle")
            }
        }
        .padding(12)
    }

    private func icon(for name: String) -> String {
        let ext = (name as NSString).pathExtension.lowercased()
        switch ext {
        case "swift": return "swift"
        case "json", "yaml", "yml", "plist": return "curlybraces"
        case "md", "txt": return "doc.text"
        case "png", "jpg", "jpeg", "webp", "heic": return "photo"
        default: return "doc"
        }
    }
}
