import SwiftUI

struct AgentView: View {
    @EnvironmentObject private var agent: AgentController
    @EnvironmentObject private var settings: AppSettings
    @State private var prompt = ""

    var body: some View {
        VStack(spacing: 0) {
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text("Agent").font(.headline)
                    Text(settings.model).font(.caption.monospaced()).foregroundStyle(.secondary).lineLimit(1)
                }
                Spacer()
                if agent.isRunning { ProgressView().controlSize(.small) }
                Button { agent.newChat() } label: { Image(systemName: "plus.bubble") }
            }
            .padding(12)
            Divider()

            ScrollViewReader { proxy in
                ScrollView {
                    LazyVStack(alignment: .leading, spacing: 10) {
                        if agent.messages.isEmpty {
                            ContentUnavailableView(
                                "Ask CodexPad",
                                systemImage: "sparkles",
                                description: Text("It can inspect and edit files inside the folder you authorized.")
                            )
                            .padding(.top, 50)
                        }
                        ForEach(agent.messages) { message in
                            MessageBubble(message: message).id(message.id)
                        }
                        if let pending = agent.pendingChange {
                            PendingChangeCard(pending: pending).id(pending.id)
                        }
                    }
                    .padding(12)
                }
                .onChange(of: agent.messages.count) { _, _ in
                    if let id = agent.messages.last?.id { withAnimation { proxy.scrollTo(id, anchor: .bottom) } }
                }
            }

            Divider()
            VStack(spacing: 8) {
                HStack(alignment: .bottom, spacing: 8) {
                    TextField("Ask about this project…", text: $prompt, axis: .vertical)
                        .lineLimit(1...6)
                        .textFieldStyle(.roundedBorder)
                        .onSubmit { send() }
                    if agent.isRunning {
                        Button(role: .destructive) { agent.stop() } label: { Image(systemName: "stop.fill") }
                            .buttonStyle(.borderedProminent)
                    } else {
                        Button { send() } label: { Image(systemName: "arrow.up") }
                            .buttonStyle(.borderedProminent)
                            .disabled(prompt.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || agent.pendingChange != nil)
                    }
                }
                HStack {
                    Label(settings.autoApply ? "Auto Apply" : "Review edits", systemImage: settings.autoApply ? "bolt.fill" : "checkmark.shield")
                    Spacer()
                    if !settings.allowSensitiveFiles {
                        Label("Secrets blocked", systemImage: "lock.shield")
                    }
                }
                .font(.caption).foregroundStyle(.secondary)
            }
            .padding(10)
        }
    }

    private func send() {
        let value = prompt
        prompt = ""
        agent.send(value)
    }
}

private struct MessageBubble: View {
    let message: ChatMessage

    var body: some View {
        HStack {
            if message.role == .user { Spacer(minLength: 36) }
            Text(message.text)
                .textSelection(.enabled)
                .padding(10)
                .background(background, in: RoundedRectangle(cornerRadius: 12))
            if message.role != .user { Spacer(minLength: 36) }
        }
    }

    private var background: Color {
        switch message.role {
        case .user: return Color.accentColor.opacity(0.16)
        case .assistant: return Color.secondary.opacity(0.10)
        case .system: return Color.orange.opacity(0.12)
        }
    }
}

private struct PendingChangeCard: View {
    @EnvironmentObject private var agent: AgentController
    let pending: PendingAgentChange

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Image(systemName: "exclamationmark.triangle.fill").foregroundStyle(.orange)
                Text(title).font(.headline)
                Spacer()
            }
            Text(pending.change.path).font(.caption.monospaced()).foregroundStyle(.secondary)
            ScrollView(.horizontal) {
                Text(pending.change.diff)
                    .font(.caption.monospaced())
                    .textSelection(.enabled)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
            .frame(maxHeight: 280)
            HStack {
                Button("Reject", role: .destructive) { agent.rejectPendingChange() }
                Spacer()
                Button("Apply") { agent.approvePendingChange() }.buttonStyle(.borderedProminent)
            }
        }
        .padding(12)
        .background(Color.orange.opacity(0.08), in: RoundedRectangle(cornerRadius: 14))
        .overlay(RoundedRectangle(cornerRadius: 14).stroke(Color.orange.opacity(0.25)))
    }

    private var title: String {
        switch pending.change.kind {
        case .write: return "Review file edit"
        case .create: return "Review new file"
        case .delete: return "Review deletion"
        case .move: return "Review move"
        }
    }
}
