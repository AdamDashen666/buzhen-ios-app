import SwiftUI
import UniformTypeIdentifiers

struct RootView: View {
    @EnvironmentObject private var app: AppState
    @EnvironmentObject private var workspace: WorkspaceStore
    @EnvironmentObject private var agent: AgentController
    @State private var pendingPath: String?
    @State private var showUnsavedAlert = false

    var body: some View {
        NavigationSplitView {
            FileSidebarView(onOpenFile: requestOpenFile)
                .navigationSplitViewColumnWidth(min: 220, ideal: 280, max: 360)
        } content: {
            EditorView()
                .navigationSplitViewColumnWidth(min: 360, ideal: 620)
        } detail: {
            AgentView()
                .navigationSplitViewColumnWidth(min: 320, ideal: 420, max: 560)
        }
        .fileImporter(
            isPresented: $app.showingFolderImporter,
            allowedContentTypes: [.folder],
            allowsMultipleSelection: false
        ) { result in
            switch result {
            case .success(let urls):
                if let url = urls.first { workspace.openFolder(url) }
            case .failure(let error):
                workspace.errorMessage = error.localizedDescription
            }
        }
        .sheet(isPresented: $app.showingSettings) { SettingsView() }
        .alert("Unsaved Changes", isPresented: $showUnsavedAlert) {
            Button("Save & Open") {
                do {
                    try workspace.saveEditor()
                    if let pendingPath { try workspace.openFile(pendingPath) }
                } catch { workspace.errorMessage = error.localizedDescription }
                pendingPath = nil
            }
            Button("Discard & Open", role: .destructive) {
                do {
                    if let pendingPath { try workspace.openFile(pendingPath, discardUnsaved: true) }
                } catch { workspace.errorMessage = error.localizedDescription }
                pendingPath = nil
            }
            Button("Cancel", role: .cancel) { pendingPath = nil }
        } message: {
            Text("Save or discard the current editor changes before switching files.")
        }
        .alert("Error", isPresented: Binding(
            get: { workspace.errorMessage != nil || agent.errorMessage != nil },
            set: { if !$0 { workspace.errorMessage = nil; agent.errorMessage = nil } }
        )) {
            Button("OK") { workspace.errorMessage = nil; agent.errorMessage = nil }
        } message: {
            Text(workspace.errorMessage ?? agent.errorMessage ?? "Unknown error")
        }
    }

    private func requestOpenFile(_ path: String) {
        do {
            try workspace.openFile(path)
        } catch WorkspaceStore.EditorError.unsavedChanges {
            pendingPath = path
            showUnsavedAlert = true
        } catch {
            workspace.errorMessage = error.localizedDescription
        }
    }
}
