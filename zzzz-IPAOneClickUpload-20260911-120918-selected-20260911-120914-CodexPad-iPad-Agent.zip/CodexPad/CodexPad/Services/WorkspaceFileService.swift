import Foundation

struct WorkspaceEntry: Identifiable, Hashable {
    let name: String
    let path: String
    let isDirectory: Bool
    var children: [WorkspaceEntry]?
    var id: String { path.isEmpty ? "__root__" : path }
}

struct SearchHit: Codable, Sendable {
    let path: String
    let line: Int
    let preview: String
}

enum WorkspaceFileError: LocalizedError {
    case noWorkspace
    case binaryOrInvalidUTF8(String)
    case tooLarge(String)
    case symlinkNotAllowed(String)
    case notFound(String)
    case alreadyExists(String)
    case directoryNotEmpty(String)

    var errorDescription: String? {
        switch self {
        case .noWorkspace: return "No workspace is open."
        case .binaryOrInvalidUTF8(let path): return "\(path) is not a UTF-8 text file."
        case .tooLarge(let path): return "\(path) is too large to load into the editor."
        case .symlinkNotAllowed(let path): return "Symbolic links are blocked for workspace safety: \(path)"
        case .notFound(let path): return "Path not found: \(path)"
        case .alreadyExists(let path): return "Path already exists: \(path)"
        case .directoryNotEmpty(let path): return "Refusing to recursively delete non-empty directory: \(path)"
        }
    }
}

struct WorkspaceFileService {
    let rootURL: URL
    private let fileManager = FileManager.default
    private let maxTextBytes = 2 * 1024 * 1024

    func checkedURL(for rawPath: String, allowMissingLeaf: Bool = false) throws -> URL {
        let path = try WorkspacePathGuard.normalize(rawPath)
        if path.isEmpty { return rootURL }
        var cursor = rootURL
        let components = path.split(separator: "/").map(String.init)
        for (index, component) in components.enumerated() {
            cursor.appendPathComponent(component, isDirectory: false)
            if fileManager.fileExists(atPath: cursor.path) {
                let values = try cursor.resourceValues(forKeys: [.isSymbolicLinkKey])
                if values.isSymbolicLink == true { throw WorkspaceFileError.symlinkNotAllowed(path) }
            } else if !(allowMissingLeaf || index < components.count - 1) {
                throw WorkspaceFileError.notFound(path)
            }
        }
        return cursor
    }

    func listTree() throws -> [WorkspaceEntry] {
        try listDirectoryRecursively(path: "", depth: 0)
    }

    func listDirectory(path: String) throws -> [WorkspaceEntry] {
        let url = try checkedURL(for: path)
        return try coordinatedRead(url) { coordinatedURL in
            let urls = try fileManager.contentsOfDirectory(
                at: coordinatedURL,
                includingPropertiesForKeys: [.isDirectoryKey, .isSymbolicLinkKey],
                options: []
            )
            return try urls.compactMap { child in
                let values = try child.resourceValues(forKeys: [.isDirectoryKey, .isSymbolicLinkKey])
                if values.isSymbolicLink == true { return nil }
                let childPath = relativePath(for: child)
                return WorkspaceEntry(name: child.lastPathComponent, path: childPath, isDirectory: values.isDirectory == true, children: nil)
            }.sorted(by: entrySort)
        }
    }

    func readText(path: String) throws -> String {
        let url = try checkedURL(for: path)
        return try coordinatedRead(url) { coordinatedURL in
            let values = try coordinatedURL.resourceValues(forKeys: [.fileSizeKey, .isDirectoryKey])
            if values.isDirectory == true { throw WorkspaceFileError.binaryOrInvalidUTF8(path) }
            if (values.fileSize ?? 0) > maxTextBytes { throw WorkspaceFileError.tooLarge(path) }
            let data = try Data(contentsOf: coordinatedURL)
            guard let text = String(data: data, encoding: .utf8) else { throw WorkspaceFileError.binaryOrInvalidUTF8(path) }
            return text
        }
    }

    func writeText(path: String, content: String, createIfMissing: Bool) throws {
        let normalized = try WorkspacePathGuard.normalize(path)
        let url = try checkedURL(for: path, allowMissingLeaf: createIfMissing)
        let exists = fileManager.fileExists(atPath: url.path)
        if createIfMissing && exists { throw WorkspaceFileError.alreadyExists(path) }

        if createIfMissing && !exists {
            // Coordinate the already-authorized workspace root so creation of missing
            // intermediate directories and the new file occurs inside one coordinated write.
            try coordinatedWrite(rootURL) { coordinatedRoot in
                let target = normalized.isEmpty ? coordinatedRoot : coordinatedRoot.appendingPathComponent(normalized)
                let parent = target.deletingLastPathComponent()
                try ensureSafeParentDirectory(parent)
                try fileManager.createDirectory(at: parent, withIntermediateDirectories: true)
                try Data(content.utf8).write(to: target, options: .atomic)
            }
            return
        }

        try coordinatedWrite(url) { coordinatedURL in
            try Data(content.utf8).write(to: coordinatedURL, options: .atomic)
        }
    }

    func delete(path: String) throws {
        let url = try checkedURL(for: path)
        let values = try url.resourceValues(forKeys: [.isDirectoryKey])
        if values.isDirectory == true {
            let contents = try fileManager.contentsOfDirectory(atPath: url.path)
            if !contents.isEmpty { throw WorkspaceFileError.directoryNotEmpty(path) }
        }
        try coordinatedWrite(url, options: .forDeleting) { coordinatedURL in
            try fileManager.removeItem(at: coordinatedURL)
        }
    }

    func move(from: String, to: String) throws {
        let source = try checkedURL(for: from)
        let destination = try checkedURL(for: to, allowMissingLeaf: true)
        if fileManager.fileExists(atPath: destination.path) { throw WorkspaceFileError.alreadyExists(to) }
        try ensureSafeParentDirectory(destination.deletingLastPathComponent())
        try fileManager.createDirectory(at: destination.deletingLastPathComponent(), withIntermediateDirectories: true)
        var coordinationError: NSError?
        var operationError: Error?
        let coordinator = NSFileCoordinator(filePresenter: nil)
        coordinator.coordinate(writingItemAt: source, options: .forMoving, writingItemAt: destination, options: .forReplacing, error: &coordinationError) { sourceURL, destinationURL in
            do { try fileManager.moveItem(at: sourceURL, to: destinationURL) }
            catch { operationError = error }
        }
        if let coordinationError { throw coordinationError }
        if let operationError { throw operationError }
    }

    func searchText(query: String, under path: String, maxResults: Int = 100, excludeSensitive: Bool = false) throws -> [SearchHit] {
        let directory = try checkedURL(for: path)
        return try coordinatedRead(directory) { coordinatedDirectory in
            var hits: [SearchHit] = []
            let keys: [URLResourceKey] = [.isRegularFileKey, .isDirectoryKey, .isSymbolicLinkKey, .fileSizeKey]
            guard let enumerator = fileManager.enumerator(at: coordinatedDirectory, includingPropertiesForKeys: keys, options: [.skipsPackageDescendants], errorHandler: nil) else { return [] }
            for case let fileURL as URL in enumerator {
                if hits.count >= maxResults { break }
                let relative = relativePath(for: fileURL)
                if shouldSkip(relative) || (excludeSensitive && SensitivePathPolicy.isSensitive(relative)) {
                    if (try? fileURL.resourceValues(forKeys: [.isDirectoryKey]).isDirectory) == true { enumerator.skipDescendants() }
                    continue
                }
                let values = try fileURL.resourceValues(forKeys: Set(keys))
                if values.isSymbolicLink == true || values.isRegularFile != true || (values.fileSize ?? 0) > maxTextBytes { continue }
                guard let text = try? String(contentsOf: fileURL, encoding: .utf8) else { continue }
                for (index, line) in text.components(separatedBy: .newlines).enumerated() where line.localizedCaseInsensitiveContains(query) {
                    hits.append(SearchHit(path: relative, line: index + 1, preview: String(line.prefix(240))))
                    if hits.count >= maxResults { break }
                }
            }
            return hits
        }
    }

    private func listDirectoryRecursively(path: String, depth: Int) throws -> [WorkspaceEntry] {
        if depth > 20 { return [] }
        let flat = try listDirectory(path: path)
        return try flat.compactMap { entry in
            if shouldSkip(entry.path) { return nil }
            if entry.isDirectory {
                var copy = entry
                copy.children = try listDirectoryRecursively(path: entry.path, depth: depth + 1)
                return copy
            }
            return entry
        }
    }

    private func shouldSkip(_ path: String) -> Bool {
        let parts = path.split(separator: "/").map(String.init)
        let blocked = Set([".git", ".build", "DerivedData", "Pods", ".swiftpm"])
        return parts.contains(where: blocked.contains)
    }

    private func relativePath(for url: URL) -> String {
        let root = rootURL.standardizedFileURL.path
        let full = url.standardizedFileURL.path
        guard full.count > root.count else { return "" }
        return String(full.dropFirst(root.count)).trimmingCharacters(in: CharacterSet(charactersIn: "/"))
    }

    private func entrySort(_ lhs: WorkspaceEntry, _ rhs: WorkspaceEntry) -> Bool {
        if lhs.isDirectory != rhs.isDirectory { return lhs.isDirectory && !rhs.isDirectory }
        return lhs.name.localizedStandardCompare(rhs.name) == .orderedAscending
    }

    private func ensureSafeParentDirectory(_ parent: URL) throws {
        let rootPath = rootURL.standardizedFileURL.path
        let parentPath = parent.standardizedFileURL.path
        guard parentPath == rootPath || parentPath.hasPrefix(rootPath + "/") else { throw WorkspacePathError.traversal }
    }

    private func coordinatedRead<T>(_ url: URL, _ body: (URL) throws -> T) throws -> T {
        var coordinationError: NSError?
        var result: Result<T, Error>?
        let coordinator = NSFileCoordinator(filePresenter: nil)
        coordinator.coordinate(readingItemAt: url, options: [], error: &coordinationError) { coordinatedURL in
            result = Result { try body(coordinatedURL) }
        }
        if let coordinationError { throw coordinationError }
        guard let result else { throw CocoaError(.fileReadUnknown) }
        return try result.get()
    }

    private func coordinatedWrite(_ url: URL, options: NSFileCoordinator.WritingOptions = [], _ body: (URL) throws -> Void) throws {
        var coordinationError: NSError?
        var operationError: Error?
        let coordinator = NSFileCoordinator(filePresenter: nil)
        coordinator.coordinate(writingItemAt: url, options: options, error: &coordinationError) { coordinatedURL in
            do { try body(coordinatedURL) } catch { operationError = error }
        }
        if let coordinationError { throw coordinationError }
        if let operationError { throw operationError }
    }
}
