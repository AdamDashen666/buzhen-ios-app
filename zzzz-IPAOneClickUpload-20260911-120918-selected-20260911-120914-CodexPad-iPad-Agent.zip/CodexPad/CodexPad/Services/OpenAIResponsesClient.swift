import Foundation

struct OpenAIResponsesClient: Sendable {
    struct ToolOutput: Encodable, Sendable {
        let type = "function_call_output"
        let callID: String
        let output: String

        enum CodingKeys: String, CodingKey {
            case type, output
            case callID = "call_id"
        }
    }

    enum Input: Encodable, Sendable {
        case text(String)
        case toolOutputs([ToolOutput])

        func encode(to encoder: Encoder) throws {
            var container = encoder.singleValueContainer()
            switch self {
            case .text(let value): try container.encode(value)
            case .toolOutputs(let values): try container.encode(values)
            }
        }
    }

    struct Request: Encodable, Sendable {
        let model: String
        let input: Input
        let instructions: String
        let previousResponseID: String?
        let tools: [FunctionTool]
        let reasoning: Reasoning
        let parallelToolCalls = false

        struct Reasoning: Encodable, Sendable { let effort: String }

        enum CodingKeys: String, CodingKey {
            case model, input, instructions, tools, reasoning
            case previousResponseID = "previous_response_id"
            case parallelToolCalls = "parallel_tool_calls"
        }
    }

    let baseURL: URL
    let apiKey: String
    let session: URLSession

    init(baseURL: URL, apiKey: String, session: URLSession = .shared) {
        self.baseURL = baseURL
        self.apiKey = apiKey
        self.session = session
    }

    func create(request body: Request) async throws -> ResponsesEnvelope {
        let endpoint = baseURL.appendingPathComponent("responses")
        guard endpoint.scheme?.lowercased() == "https" else { throw APIError.httpsRequired }
        var request = URLRequest(url: endpoint)
        request.httpMethod = "POST"
        request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.timeoutInterval = 120
        request.httpBody = try JSONEncoder().encode(body)

        let (data, response) = try await session.data(for: request)
        guard let http = response as? HTTPURLResponse else { throw APIError.invalidResponse }
        guard (200..<300).contains(http.statusCode) else {
            let message = (try? JSONDecoder().decode(APIErrorEnvelope.self, from: data).error.message)
                ?? String(data: data, encoding: .utf8)
                ?? "Unknown API error"
            throw APIError.http(http.statusCode, message)
        }
        return try JSONDecoder().decode(ResponsesEnvelope.self, from: data)
    }

    private struct APIErrorEnvelope: Decodable { struct Detail: Decodable { let message: String }; let error: Detail }

    enum APIError: LocalizedError {
        case httpsRequired
        case invalidResponse
        case http(Int, String)

        var errorDescription: String? {
            switch self {
            case .httpsRequired: return "Only HTTPS API endpoints are allowed."
            case .invalidResponse: return "The API returned an invalid response."
            case .http(let code, let message): return "API error \(code): \(message)"
            }
        }
    }
}
