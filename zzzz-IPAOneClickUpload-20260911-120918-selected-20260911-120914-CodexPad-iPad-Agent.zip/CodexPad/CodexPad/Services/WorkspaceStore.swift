import Foundation
import SwiftUI
import UniformTypeIdentifiers

@MainActor
final class WorkspaceStore: ObservableObject {
    @Published private(set) var rootURL: URL?
    @Published private(set) var entries: [WorkspaceEntry] = []
    @Published var selectedPath: String?
    @Published var editorText = ""
    @Published private(set) var savedEditorText = ""
    @Published var errorMessage: String?

    private let bookmarkKey = "workspace.securityScopedBookmark"
    private var accessURL: URL?

    var isDirty: Bool { selectedPath != nil && editorText != savedEditorText }
    var displayName: String { rootURL?.lastPathComponent ?? "No Folder" }
    var service: WorkspaceFileService? { rootURL.map(WorkspaceFileService.init(rootURL:)) }

    init() {
        restoreBookmarkIfPossible()
    }


    func openFolder(_ url: URL) {
        do {
            try attach(url: url, persist: true)
            try refreshTree()
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    func closeFolder() {
        accessURL?.stopAccessingSecurityScopedResource()
        accessURL = nil
        rootURL = nil
        entries = []
        selectedPath = nil
        editorText = ""
        savedEditorText = ""
        UserDefaults.standard.removeObject(forKey: bookmarkKey)
    }

    func refreshTree() throws {
        guard let service else { throw WorkspaceFileError.noWorkspace }
        entries = try service.listTree()
    }

    func openFile(_ path: String, discardUnsaved: Bool = false) throws {
        if isDirty && !discardUnsaved { throw EditorError.unsavedChanges }
        guard let service else { throw WorkspaceFileError.noWorkspace }
        let text = try service.readText(path: path)
        selectedPath = path
        editorText = text
        savedEditorText = text
    }

    func saveEditor() throws {
        guard let selectedPath, let service else { return }
        try service.writeText(path: selectedPath, content: editorText, createIfMissing: false)
        savedEditorText = editorText
        try refreshTree()
    }

    func revertEditor() throws {
        guard let selectedPath, let service else { return }
        let text = try service.readText(path: selectedPath)
        editorText = text
        savedEditorText = text
    }

    func refreshSelectedFileIfUnmodified() {
        guard !isDirty, let selectedPath, let service else { return }
        if let text = try? service.readText(path: selectedPath) {
            editorText = text
            savedEditorText = text
        }
    }

    private func restoreBookmarkIfPossible() {
        guard let data = UserDefaults.standard.data(forKey: bookmarkKey) else { return }
        do {
            var stale = false
            let url = try URL(resolvingBookmarkData: data, options: [.withSecurityScope], relativeTo: nil, bookmarkDataIsStale: &stale)
            try attach(url: url, persist: stale)
            entries = try service?.listTree() ?? []
        } catch {
            UserDefaults.standard.removeObject(forKey: bookmarkKey)
        }
    }

    private func attach(url: URL, persist: Bool) throws {
        accessURL?.stopAccessingSecurityScopedResource()
        guard url.startAccessingSecurityScopedResource() else { throw WorkspaceError.permissionDenied }
        accessURL = url
        rootURL = url
        if persist {
            let bookmark = try url.bookmarkData(options: [.withSecurityScope], includingResourceValuesForKeys: nil, relativeTo: nil)
            UserDefaults.standard.set(bookmark, forKey: bookmarkKey)
        }
    }

    enum WorkspaceError: LocalizedError {
        case permissionDenied
        var errorDescription: String? { "Could not obtain permission for the selected folder." }
    }

    enum EditorError: LocalizedError {
        case unsavedChanges
        var errorDescription: String? { "This file has unsaved changes." }
    }
}
