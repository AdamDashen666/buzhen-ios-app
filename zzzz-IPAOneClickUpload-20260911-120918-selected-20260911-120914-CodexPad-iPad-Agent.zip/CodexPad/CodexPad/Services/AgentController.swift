import Foundation
import SwiftUI

struct ChatMessage: Identifiable, Equatable {
    enum Role: Equatable { case user, assistant, system }
    let id = UUID()
    let role: Role
    let text: String
}

struct PendingAgentChange: Identifiable {
    let id = UUID()
    let responseID: String
    let callID: String
    let change: PendingChange
}

@MainActor
final class AgentController: ObservableObject {
    @Published var messages: [ChatMessage] = []
    @Published var pendingChange: PendingAgentChange?
    @Published var isRunning = false
    @Published var errorMessage: String?

    private let workspace: WorkspaceStore
    private let settings: AppSettings
    private let keychain = KeychainStore()
    private var previousResponseID: String?
    private var runningTask: Task<Void, Never>?

    init(workspace: WorkspaceStore, settings: AppSettings) {
        self.workspace = workspace
        self.settings = settings
    }

    func send(_ prompt: String) {
        let trimmed = prompt.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty, !isRunning, pendingChange == nil else { return }
        messages.append(ChatMessage(role: .user, text: trimmed))
        isRunning = true
        runningTask = Task { [weak self] in
            guard let self else { return }
            do {
                try await self.run(input: .text(trimmed), previousID: self.previousResponseID)
            } catch is CancellationError {
                self.messages.append(ChatMessage(role: .system, text: "Stopped."))
            } catch {
                self.errorMessage = error.localizedDescription
            }
            self.isRunning = false
        }
    }

    func stop() {
        runningTask?.cancel()
        runningTask = nil
        isRunning = false
    }

    func newChat() {
        stop()
        previousResponseID = nil
        pendingChange = nil
        messages.removeAll()
    }

    func approvePendingChange() {
        guard let pendingChange else { return }
        do {
            try apply(pendingChange.change)
            self.pendingChange = nil
            isRunning = true
            runningTask = Task { [weak self] in
                guard let self else { return }
                do {
                    try await self.run(
                        input: .toolOutputs([.init(callID: pendingChange.callID, output: "Applied successfully.")]),
                        previousID: pendingChange.responseID
                    )
                } catch { self.errorMessage = error.localizedDescription }
                self.isRunning = false
            }
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    func rejectPendingChange() {
        guard let pendingChange else { return }
        self.pendingChange = nil
        isRunning = true
        runningTask = Task { [weak self] in
            guard let self else { return }
            do {
                try await self.run(
                    input: .toolOutputs([.init(callID: pendingChange.callID, output: "Rejected by the user. Do not assume the proposed change was applied.")]),
                    previousID: pendingChange.responseID
                )
            } catch { self.errorMessage = error.localizedDescription }
            self.isRunning = false
        }
    }

    private func run(input: OpenAIResponsesClient.Input, previousID: String?) async throws {
        guard workspace.rootURL != nil else { throw AgentError.noWorkspace }
        guard let apiKey = try keychain.loadAPIKey(), !apiKey.isEmpty else { throw AgentError.missingAPIKey }
        guard let baseURL = URL(string: settings.baseURL) else { throw AgentError.invalidBaseURL }
        let client = OpenAIResponsesClient(baseURL: baseURL, apiKey: apiKey)
        var nextInput = input
        var previousID = previousID

        for _ in 0..<24 {
            try Task.checkCancellation()
            let response = try await client.create(request: .init(
                model: settings.model,
                input: nextInput,
                instructions: instructions,
                previousResponseID: previousID,
                tools: AgentToolCatalog.all,
                reasoning: .init(effort: settings.reasoningEffort)
            ))
            self.previousResponseID = response.id

            if let call = response.functionCalls.first {
                if AgentToolCatalog.isMutation(call.name) {
                    let change = try prepareMutation(call)
                    if settings.autoApply {
                        try apply(change)
                        nextInput = .toolOutputs([.init(callID: call.callID, output: "Applied successfully.")])
                        previousID = response.id
                        continue
                    }
                    pendingChange = PendingAgentChange(responseID: response.id, callID: call.callID, change: change)
                    return
                }

                let output = try executeReadOnly(call)
                nextInput = .toolOutputs([.init(callID: call.callID, output: output)])
                previousID = response.id
                continue
            }

            let text = response.outputText.trimmingCharacters(in: .whitespacesAndNewlines)
            if !text.isEmpty { messages.append(ChatMessage(role: .assistant, text: text)) }
            return
        }
        throw AgentError.toolLoopLimit
    }

    private var instructions: String {
        """
        You are CodexPad, an iPad coding agent operating only inside a user-authorized project folder.
        Inspect files with tools before editing. Use workspace-relative paths only. Never request or expose secrets.
        Keep edits focused. Mutation tools may require explicit user approval, so do not claim a mutation succeeded until its tool result says it was applied.
        You cannot run shell commands, builds, tests, git, or arbitrary processes on iPadOS. Be explicit when verification requires an external Mac/CI runner.
        """
    }

    private func executeReadOnly(_ call: FunctionCall) throws -> String {
        guard let service = workspace.service else { throw AgentError.noWorkspace }
        let args = try decodeArguments(call.arguments)
        switch call.name {
        case "list_directory":
            let path = args["path"] ?? ""
            try enforceSensitivePolicy(path)
            let entries = try service.listDirectory(path: path)
            return entries.map { "\($0.isDirectory ? "dir" : "file")\t\($0.path)" }.joined(separator: "\n")
        case "read_file":
            let path = try required("path", args)
            try enforceSensitivePolicy(path)
            return try service.readText(path: path)
        case "search_text":
            let path = args["path"] ?? ""
            let query = try required("query", args)
            try enforceSensitivePolicy(path)
            let hits = try service.searchText(query: query, under: path, excludeSensitive: !settings.allowSensitiveFiles)
            return try encodeJSON(hits)
        default:
            throw AgentError.unknownTool(call.name)
        }
    }

    private func prepareMutation(_ call: FunctionCall) throws -> PendingChange {
        guard let service = workspace.service else { throw AgentError.noWorkspace }
        let args = try decodeArguments(call.arguments)
        switch call.name {
        case "write_file":
            let path = try required("path", args); try enforceSensitivePolicy(path)
            let content = try required("content", args)
            let old = try service.readText(path: path)
            return PendingChange(kind: .write, path: path, originalText: old, proposedText: content)
        case "create_file":
            let path = try required("path", args); try enforceSensitivePolicy(path)
            _ = try WorkspacePathGuard.normalize(path)
            let content = try required("content", args)
            return PendingChange(kind: .create, path: path, originalText: "", proposedText: content)
        case "delete_file":
            let path = try required("path", args); try enforceSensitivePolicy(path)
            let old = try? service.readText(path: path)
            return PendingChange(kind: .delete, path: path, originalText: old, proposedText: "")
        case "move_file":
            let from = try required("from", args); let to = try required("to", args)
            try enforceSensitivePolicy(from); try enforceSensitivePolicy(to)
            _ = try WorkspacePathGuard.normalize(from); _ = try WorkspacePathGuard.normalize(to)
            return PendingChange(kind: .move, path: from, destinationPath: to)
        default:
            throw AgentError.unknownTool(call.name)
        }
    }

    private func apply(_ change: PendingChange) throws {
        guard let service = workspace.service else { throw AgentError.noWorkspace }
        switch change.kind {
        case .write:
            try service.writeText(path: change.path, content: change.proposedText ?? "", createIfMissing: false)
        case .create:
            try service.writeText(path: change.path, content: change.proposedText ?? "", createIfMissing: true)
        case .delete:
            try service.delete(path: change.path)
        case .move:
            try service.move(from: change.path, to: change.destinationPath ?? "")
        }
        try workspace.refreshTree()
        workspace.refreshSelectedFileIfUnmodified()
    }

    private func enforceSensitivePolicy(_ path: String) throws {
        if !settings.allowSensitiveFiles && SensitivePathPolicy.isSensitive(path) {
            throw AgentError.sensitiveFile(path)
        }
    }

    private func decodeArguments(_ json: String) throws -> [String: String] {
        let data = Data(json.utf8)
        return try JSONDecoder().decode([String: String].self, from: data)
    }

    private func required(_ key: String, _ args: [String: String]) throws -> String {
        guard let value = args[key] else { throw AgentError.missingArgument(key) }
        return value
    }

    private func encodeJSON<T: Encodable>(_ value: T) throws -> String {
        let data = try JSONEncoder().encode(value)
        return String(decoding: data, as: UTF8.self)
    }

    enum AgentError: LocalizedError {
        case noWorkspace, missingAPIKey, invalidBaseURL, toolLoopLimit
        case unknownTool(String), missingArgument(String), sensitiveFile(String)

        var errorDescription: String? {
            switch self {
            case .noWorkspace: return "Open a project folder first."
            case .missingAPIKey: return "Add an API key in Settings first."
            case .invalidBaseURL: return "The API Base URL is invalid."
            case .toolLoopLimit: return "The agent exceeded the tool-call safety limit."
            case .unknownTool(let name): return "Unknown tool: \(name)"
            case .missingArgument(let name): return "Tool call is missing argument: \(name)"
            case .sensitiveFile(let path): return "Agent access to sensitive file is blocked: \(path). You can change this in Settings."
            }
        }
    }
}
