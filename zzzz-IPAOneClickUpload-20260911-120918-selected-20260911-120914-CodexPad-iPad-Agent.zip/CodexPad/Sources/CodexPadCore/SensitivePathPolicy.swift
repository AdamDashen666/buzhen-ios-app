import Foundation

public enum SensitivePathPolicy {
    public static func isSensitive(_ path: String) -> Bool {
        let normalized = path.replacingOccurrences(of: "\\", with: "/")
        let components = normalized.split(separator: "/").map(String.init)
        if components.contains(".git") || components.contains(".ssh") { return true }
        guard let last = components.last?.lowercased() else { return false }
        if last == ".env" || last.hasPrefix(".env.") { return true }
        if last.hasSuffix(".p8") || last.hasSuffix(".p12") || last.hasSuffix(".mobileprovision") { return true }
        if last == "id_rsa" || last == "id_ed25519" { return true }
        return false
    }
}
