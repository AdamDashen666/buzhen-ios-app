import Foundation

public enum TextDiff {
    /// A linear-time review diff. It keeps the common prefix/suffix as context and
    /// renders the changed middle as removals/additions, avoiding quadratic LCS
    /// memory usage on large source files.
    public static func unified(old: String, new: String, path: String) -> String {
        if old == new { return "No changes." }
        let a = lines(old)
        let b = lines(new)

        var prefix = 0
        while prefix < a.count, prefix < b.count, a[prefix] == b[prefix] { prefix += 1 }

        var suffix = 0
        while suffix < a.count - prefix,
              suffix < b.count - prefix,
              a[a.count - 1 - suffix] == b[b.count - 1 - suffix] {
            suffix += 1
        }

        let context = 3
        let beforeStart = max(0, prefix - context)
        let afterOldStart = a.count - suffix
        let afterNewStart = b.count - suffix
        let afterCount = min(context, suffix)

        var output = ["--- a/\(path)", "+++ b/\(path)", "@@ review diff @@"]
        if beforeStart > 0 { output.append(" … \(beforeStart) unchanged line(s)") }
        for line in a[beforeStart..<prefix] { output.append(" \(line)") }
        if prefix < afterOldStart {
            for line in a[prefix..<afterOldStart] { output.append("-\(line)") }
        }
        if prefix < afterNewStart {
            for line in b[prefix..<afterNewStart] { output.append("+\(line)") }
        }
        if afterCount > 0 {
            let start = a.count - suffix
            for line in a[start..<(start + afterCount)] { output.append(" \(line)") }
        }
        if suffix > afterCount { output.append(" … \(suffix - afterCount) unchanged line(s)") }
        return output.joined(separator: "\n")
    }

    private static func lines(_ text: String) -> [String] {
        guard !text.isEmpty else { return [] }
        var result = text.components(separatedBy: "\n")
        if text.hasSuffix("\n") { result.removeLast() }
        return result
    }
}
