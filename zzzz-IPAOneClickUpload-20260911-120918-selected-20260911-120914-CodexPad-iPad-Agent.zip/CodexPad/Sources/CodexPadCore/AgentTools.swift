import Foundation

public struct ToolProperty: Codable, Equatable, Sendable {
    public let type: String
    public let description: String

    public init(type: String = "string", description: String) {
        self.type = type
        self.description = description
    }
}

public struct ToolParameters: Codable, Equatable, Sendable {
    public let type: String
    public let properties: [String: ToolProperty]
    public let required: [String]
    public let additionalProperties: Bool

    public init(properties: [String: ToolProperty]) {
        self.type = "object"
        self.properties = properties
        self.required = Array(properties.keys).sorted()
        self.additionalProperties = false
    }
}

public struct FunctionTool: Codable, Equatable, Sendable {
    public let type: String
    public let name: String
    public let description: String
    public let parameters: ToolParameters
    public let strict: Bool

    public init(name: String, description: String, properties: [String: ToolProperty]) {
        self.type = "function"
        self.name = name
        self.description = description
        self.parameters = ToolParameters(properties: properties)
        self.strict = true
    }
}

public enum AgentToolCatalog {
    public static let all: [FunctionTool] = [
        .init(name: "list_directory", description: "List files and folders at a workspace-relative path. Use an empty path for the workspace root.", properties: [
            "path": .init(description: "Workspace-relative directory path, or empty string for root.")
        ]),
        .init(name: "read_file", description: "Read a UTF-8 text file from the authorized workspace.", properties: [
            "path": .init(description: "Workspace-relative file path.")
        ]),
        .init(name: "search_text", description: "Search UTF-8 text files under a workspace-relative directory for a literal string.", properties: [
            "path": .init(description: "Workspace-relative directory path, or empty string for root."),
            "query": .init(description: "Literal text to search for.")
        ]),
        .init(name: "write_file", description: "Propose replacing the complete UTF-8 contents of an existing file. The user may need to approve the change before it is applied.", properties: [
            "path": .init(description: "Workspace-relative file path."),
            "content": .init(description: "Complete new file contents.")
        ]),
        .init(name: "create_file", description: "Propose creating a new UTF-8 text file. Parent directories are created as needed after approval.", properties: [
            "path": .init(description: "Workspace-relative new file path."),
            "content": .init(description: "Complete file contents.")
        ]),
        .init(name: "delete_file", description: "Propose deleting a file or empty directory from the authorized workspace.", properties: [
            "path": .init(description: "Workspace-relative path to delete.")
        ]),
        .init(name: "move_file", description: "Propose moving or renaming a workspace file or directory.", properties: [
            "from": .init(description: "Current workspace-relative path."),
            "to": .init(description: "Destination workspace-relative path.")
        ])
    ]

    private static let mutationNames: Set<String> = ["write_file", "create_file", "delete_file", "move_file"]
    public static func isMutation(_ name: String) -> Bool { mutationNames.contains(name) }
}
