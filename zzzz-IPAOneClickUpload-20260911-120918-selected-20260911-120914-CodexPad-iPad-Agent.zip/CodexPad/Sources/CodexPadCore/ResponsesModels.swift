import Foundation

public struct ResponsesEnvelope: Codable, Equatable, Sendable {
    public let id: String
    public let output: [ResponseOutputItem]

    public init(id: String, output: [ResponseOutputItem]) {
        self.id = id
        self.output = output
    }

    public var functionCalls: [FunctionCall] {
        output.compactMap { item in
            guard item.type == "function_call", let callID = item.callID, let name = item.name, let arguments = item.arguments else { return nil }
            return FunctionCall(callID: callID, name: name, arguments: arguments)
        }
    }

    public var outputText: String {
        output
            .filter { $0.type == "message" }
            .flatMap { $0.content ?? [] }
            .filter { $0.type == "output_text" }
            .compactMap(\.text)
            .joined(separator: "\n")
    }
}

public struct ResponseOutputItem: Codable, Equatable, Sendable {
    public let type: String
    public let callID: String?
    public let name: String?
    public let arguments: String?
    public let content: [ResponseContent]?

    enum CodingKeys: String, CodingKey {
        case type
        case callID = "call_id"
        case name, arguments, content
    }
}

public struct ResponseContent: Codable, Equatable, Sendable {
    public let type: String
    public let text: String?
}

public struct FunctionCall: Equatable, Sendable {
    public let callID: String
    public let name: String
    public let arguments: String
}
