import Foundation

public enum WorkspacePathError: LocalizedError, Equatable, Sendable {
    case absolutePath
    case traversal
    case invalidComponent

    public var errorDescription: String? {
        switch self {
        case .absolutePath: return "Absolute paths are not allowed."
        case .traversal: return "Path traversal outside the workspace is not allowed."
        case .invalidComponent: return "The path contains an invalid component."
        }
    }
}

public enum WorkspacePathGuard {
    /// Converts a model-supplied path into a workspace-relative path.
    /// It intentionally rejects Windows separators as well as POSIX absolute paths.
    public static func normalize(_ raw: String) throws -> String {
        if raw == "." || raw.isEmpty { return "" }
        if raw.hasPrefix("/") || raw.hasPrefix("~") || raw.contains("\\") {
            throw WorkspacePathError.absolutePath
        }
        if raw.contains("\0") { throw WorkspacePathError.invalidComponent }

        let parts = raw.split(separator: "/", omittingEmptySubsequences: false)
        if parts.contains(where: { $0.isEmpty || $0 == ".." }) {
            if parts.contains(where: { $0 == ".." }) { throw WorkspacePathError.traversal }
            throw WorkspacePathError.invalidComponent
        }
        if parts.contains(where: { $0 == "." }) { throw WorkspacePathError.invalidComponent }
        return parts.joined(separator: "/")
    }
}
