import Foundation

enum ZipArchiveService {
    struct Entry {
        var path: String
        var data: Data
    }

    struct GeneratedFile: Identifiable, Hashable {
        var id: String { path }
        var path: String
        var data: Data
        var sourceNodeTitle: String
        var sourceKindTitle: String

        var fileName: String { URL(fileURLWithPath: path).lastPathComponent }
        var byteCountText: String { ByteCountFormatter.string(fromByteCount: Int64(data.count), countStyle: .file) }
    }

    enum ArchiveError: Error, LocalizedError {
        case entryNameTooLong(String)
        case entryTooLarge(String)
        case archiveTooLarge

        var errorDescription: String? {
            switch self {
            case .entryNameTooLong(let name): return "ZIP 条目名称过长：\(name)"
            case .entryTooLarge(let name): return "ZIP 条目过大，当前轻量打包器暂不支持 Zip64：\(name)"
            case .archiveTooLarge: return "ZIP 文件过大，当前轻量打包器暂不支持 Zip64"
            }
        }
    }

    static func shareableRunArchive(for run: RunRecord) -> URL {
        do {
            return try exportRunArchive(run)
        } catch {
            return exportFallbackReport(run: run, error: error)
        }
    }

    static func generatedFiles(for run: RunRecord) -> [GeneratedFile] {
        generatedFilesInternal(from: run)
    }

    static func shareableGeneratedFile(_ file: GeneratedFile, run: RunRecord) -> URL {
        let exportRoot = FileManager.default.temporaryDirectory
            .appendingPathComponent("AIWorkflowStudio-Files", isDirectory: true)
            .appendingPathComponent(run.id.uuidString, isDirectory: true)
        do {
            try FileManager.default.createDirectory(at: exportRoot, withIntermediateDirectories: true)
            let target = exportRoot.appendingPathComponent(normalizedPath(file.path))
            try FileManager.default.createDirectory(at: target.deletingLastPathComponent(), withIntermediateDirectories: true)
            try file.data.write(to: target, options: .atomic)
            return target
        } catch {
            let fallback = exportRoot.appendingPathComponent("export-failed-\(file.fileName).txt")
            try? "文件导出失败：\(error.localizedDescription)".write(to: fallback, atomically: true, encoding: .utf8)
            return fallback
        }
    }

    static func shareableGeneratedFilesArchive(for run: RunRecord) -> URL {
        do {
            let files = generatedFiles(for: run)
            let entries = files.map { Entry(path: "generated/\(normalizedPath($0.path))", data: $0.data) }
            let exportRoot = FileManager.default.temporaryDirectory
                .appendingPathComponent("AIWorkflowStudio-Files", isDirectory: true)
            try FileManager.default.createDirectory(at: exportRoot, withIntermediateDirectories: true)
            let destination = exportRoot.appendingPathComponent("generated-files-\(run.id.uuidString.prefix(8)).zip")
            try write(entries: entries.isEmpty ? [Entry(path: "NO_FILES_FOUND.txt", data: "未检测到可单独导出的文件。".utf8Data)] : entries, to: destination)
            return destination
        } catch {
            return exportFallbackReport(run: run, error: error)
        }
    }

    @discardableResult
    static func exportRunArchive(_ run: RunRecord) throws -> URL {
        let exportRoot = FileManager.default.temporaryDirectory
            .appendingPathComponent("AIWorkflowStudio-Exports", isDirectory: true)
        try FileManager.default.createDirectory(at: exportRoot, withIntermediateDirectories: true)

        let fileName = "\(safeFileName(run.projectTitle))-\(run.id.uuidString.prefix(8)).zip"
        let destination = exportRoot.appendingPathComponent(fileName)

        var entries: [Entry] = []
        entries.append(Entry(path: "README.md", data: readme(for: run).utf8Data))
        entries.append(Entry(path: "output/final-output.md", data: (run.output.isEmpty ? LogExportService.markdown(for: run) : run.output).utf8Data))
        entries.append(Entry(path: "logs/run-log.md", data: LogExportService.markdown(for: run).utf8Data))
        entries.append(Entry(path: "logs/events.json", data: try LogExportService.jsonData(for: run)))

        for (index, node) in run.nodeRecords.enumerated() {
            let number = String(format: "%02d", index + 1)
            let name = safeFileName(node.nodeTitle)
            let body = nodeMarkdown(node)
            entries.append(Entry(path: "nodes/\(number)-\(name).md", data: body.utf8Data))
        }

        entries.append(contentsOf: generatedFileEntries(from: run))

        try write(entries: entries, to: destination)
        return destination
    }

    static func write(entries: [Entry], to destination: URL) throws {
        var archive = Data()
        var centralDirectory = Data()
        var centralRecords: [(entry: Entry, crc: UInt32, offset: UInt32)] = []

        for entry in entries {
            let cleanPath = normalizedPath(entry.path)
            let nameData = cleanPath.utf8Data
            guard nameData.count <= Int(UInt16.max) else { throw ArchiveError.entryNameTooLong(cleanPath) }
            guard entry.data.count <= Int(UInt32.max) else { throw ArchiveError.entryTooLarge(cleanPath) }
            guard archive.count <= Int(UInt32.max) else { throw ArchiveError.archiveTooLarge }

            let crc = CRC32.checksum(entry.data)
            let offset = UInt32(archive.count)
            appendLocalHeader(to: &archive, nameData: nameData, crc: crc, size: UInt32(entry.data.count))
            archive.append(entry.data)
            centralRecords.append((Entry(path: cleanPath, data: entry.data), crc, offset))
        }

        let centralStart = UInt32(archive.count)
        for record in centralRecords {
            let nameData = record.entry.path.utf8Data
            appendCentralDirectoryHeader(
                to: &centralDirectory,
                nameData: nameData,
                crc: record.crc,
                size: UInt32(record.entry.data.count),
                localHeaderOffset: record.offset
            )
        }
        guard centralDirectory.count <= Int(UInt32.max), archive.count + centralDirectory.count <= Int(UInt32.max) else {
            throw ArchiveError.archiveTooLarge
        }
        archive.append(centralDirectory)
        appendEndOfCentralDirectory(
            to: &archive,
            entryCount: UInt16(min(centralRecords.count, Int(UInt16.max))),
            centralDirectorySize: UInt32(centralDirectory.count),
            centralDirectoryOffset: centralStart
        )

        if FileManager.default.fileExists(atPath: destination.path) {
            try FileManager.default.removeItem(at: destination)
        }
        try archive.write(to: destination, options: .atomic)
    }

    private static func appendLocalHeader(to data: inout Data, nameData: Data, crc: UInt32, size: UInt32) {
        data.appendUInt32LE(0x04034b50)
        data.appendUInt16LE(20)       // version needed
        data.appendUInt16LE(0)        // flags
        data.appendUInt16LE(0)        // compression method: stored / no compression
        data.appendUInt16LE(0)        // mod time
        data.appendUInt16LE(33)       // mod date: 1980-01-01
        data.appendUInt32LE(crc)
        data.appendUInt32LE(size)
        data.appendUInt32LE(size)
        data.appendUInt16LE(UInt16(nameData.count))
        data.appendUInt16LE(0)        // extra length
        data.append(nameData)
    }

    private static func appendCentralDirectoryHeader(to data: inout Data, nameData: Data, crc: UInt32, size: UInt32, localHeaderOffset: UInt32) {
        data.appendUInt32LE(0x02014b50)
        data.appendUInt16LE(20)       // version made by
        data.appendUInt16LE(20)       // version needed
        data.appendUInt16LE(0)        // flags
        data.appendUInt16LE(0)        // compression method
        data.appendUInt16LE(0)        // mod time
        data.appendUInt16LE(33)       // mod date: 1980-01-01
        data.appendUInt32LE(crc)
        data.appendUInt32LE(size)
        data.appendUInt32LE(size)
        data.appendUInt16LE(UInt16(nameData.count))
        data.appendUInt16LE(0)        // extra length
        data.appendUInt16LE(0)        // comment length
        data.appendUInt16LE(0)        // disk start
        data.appendUInt16LE(0)        // internal attributes
        data.appendUInt32LE(0)        // external attributes
        data.appendUInt32LE(localHeaderOffset)
        data.append(nameData)
    }

    private static func appendEndOfCentralDirectory(to data: inout Data, entryCount: UInt16, centralDirectorySize: UInt32, centralDirectoryOffset: UInt32) {
        data.appendUInt32LE(0x06054b50)
        data.appendUInt16LE(0)        // disk number
        data.appendUInt16LE(0)        // central dir disk
        data.appendUInt16LE(entryCount)
        data.appendUInt16LE(entryCount)
        data.appendUInt32LE(centralDirectorySize)
        data.appendUInt32LE(centralDirectoryOffset)
        data.appendUInt16LE(0)        // comment length
    }

    private static func readme(for run: RunRecord) -> String {
        """
        # \(run.projectTitle)

        这是 AI Workflow Studio 导出的真实 ZIP 项目包。

        - 状态：\(run.status.title)
        - 开始：\(run.startedAt.formatted(date: .abbreviated, time: .standard))
        - Token：\(run.tokenUsage.total)
        - 节点数：\(run.nodeRecords.count)

        ## 目录
        - `output/final-output.md`：最终输出
        - `logs/run-log.md`：Markdown 运行日志
        - `logs/events.json`：完整 JSON 运行记录
        - `nodes/`：每个模块的独立输出
        - `generated/`：从格式转换者/项目打包者/代码工作者输出中识别出的真实文件，例如 `.py`、`.md`、`.html`
        """
    }

    private static func nodeMarkdown(_ node: NodeRunRecord) -> String {
        """
        # \(node.nodeTitle)

        - 类型：\(node.kind.title)
        - 状态：\(node.status.title)
        - 模型：\(node.modelID ?? "未配置")
        - Provider：\(node.providerName ?? "未配置")
        - Token：\(node.tokenUsage.total)

        ## 输入预览

        ```text
        \(node.inputPreview)
        ```

        ## 输出

        ```text
        \(node.output)
        ```

        ## 错误

        \(node.errorMessage ?? "无")
        """
    }

    static func detectGeneratedFilePaths(in text: String) -> [String] {
        extractedFileEntries(from: text, preferredDefaultName: nil).map(\.path)
    }

    private static func generatedFileEntries(from run: RunRecord) -> [Entry] {
        generatedFilesInternal(from: run).map { file in
            let clean = normalizedPath(file.path)
            let generatedPath = clean.hasPrefix("generated/") ? clean : "generated/\(clean)"
            return Entry(path: generatedPath, data: file.data)
        }
    }

    private static func generatedFilesInternal(from run: RunRecord) -> [GeneratedFile] {
        // v8.3: 只从“最终产物节点”提取文件，避免把计划者/检查者/返工前工作者的历史草稿混入 generated/。
        // 优先级：项目打包者 > 格式转换者 > 输出模块 > 汇总者 > 代码工作者。
        // 只有更高优先级没有任何真实文件块时，才回退到下一级。
        let priorityGroups: [[WorkflowNodeKind]] = [
            [.filePackager],
            [.formatter],
            [.output],
            [.aggregator],
            [.codeWorker]
        ]

        for group in priorityGroups {
            let sourceNodes = latestPassedRecordsByNode(from: run.nodeRecords.filter { group.contains($0.kind) })
            let files = filesExtracted(from: sourceNodes)
            if !files.isEmpty { return files }
        }

        let fallbackEntries = extractedFileEntries(from: run.output, preferredDefaultName: nil)
        let fallbackFiles = fallbackEntries.map { entry in
            GeneratedFile(
                path: normalizedPath(entry.path),
                data: entry.data,
                sourceNodeTitle: "最终输出",
                sourceKindTitle: "输出模块"
            )
        }
        return normalizedAndDeduplicated(fallbackFiles)
    }

    private static func latestPassedRecordsByNode(from records: [NodeRunRecord]) -> [NodeRunRecord] {
        var latestByNode: [UUID: NodeRunRecord] = [:]
        var orderByNode: [UUID: Int] = [:]
        for (index, record) in records.enumerated() {
            latestByNode[record.nodeID] = record
            orderByNode[record.nodeID] = index
        }
        return latestByNode.values
            .filter { $0.status == .passed }
            .sorted { (orderByNode[$0.nodeID] ?? 0) < (orderByNode[$1.nodeID] ?? 0) }
    }

    private static func filesExtracted(from records: [NodeRunRecord]) -> [GeneratedFile] {
        var files: [GeneratedFile] = []
        for node in records {
            let entries = extractedFileEntries(from: node.output, preferredDefaultName: fallbackFileName(for: node))
            files.append(contentsOf: entries.map { entry in
                GeneratedFile(
                    path: normalizedPath(entry.path),
                    data: entry.data,
                    sourceNodeTitle: node.nodeTitle,
                    sourceKindTitle: node.kind.title
                )
            })
        }
        return normalizedAndDeduplicated(files)
    }

    private static func normalizedAndDeduplicated(_ files: [GeneratedFile]) -> [GeneratedFile] {
        var result: [GeneratedFile] = []
        var indexByPath: [String: Int] = [:]
        for file in files {
            let clean = normalizedPath(file.path)
            guard !clean.isEmpty else { continue }
            let normalized = clean.hasPrefix("generated/") ? String(clean.dropFirst("generated/".count)) : clean
            var next = file
            next.path = normalized
            if let index = indexByPath[normalized] {
                result[index] = next
            } else {
                indexByPath[normalized] = result.count
                result.append(next)
            }
        }
        return result.sorted { $0.path.localizedStandardCompare($1.path) == .orderedAscending }
    }

    private static func extractedFileEntries(from text: String, preferredDefaultName: String?) -> [Entry] {
        let lines = text.components(separatedBy: .newlines)
        var entries: [Entry] = []
        var pendingPathHint: String?
        var insideFence = false
        var fencePath: String?
        var fenceLanguage: String?
        var buffer: [String] = []

        for line in lines {
            let trimmed = line.trimmingCharacters(in: .whitespacesAndNewlines)
            if trimmed.hasPrefix("```") {
                if insideFence {
                    let body = buffer.joined(separator: "\n").trimmingCharacters(in: .whitespacesAndNewlines)
                    if !body.isEmpty {
                        let path = fencePath ?? pendingPathHint ?? preferredDefaultName ?? fallbackFileName(forLanguage: fenceLanguage)
                        if let path, isSupportedGeneratedFile(path), shouldAcceptGeneratedBody(body, forPath: path) {
                            entries.append(Entry(path: path, data: body.utf8Data))
                        }
                    }
                    insideFence = false
                    fencePath = nil
                    fenceLanguage = nil
                    buffer.removeAll()
                    pendingPathHint = nil
                } else {
                    insideFence = true
                    fencePath = pathHint(from: trimmed)
                    fenceLanguage = languageHint(fromFenceOpening: trimmed)
                    buffer.removeAll()
                }
                continue
            }

            if insideFence {
                buffer.append(line)
            } else if let hint = pathHint(from: line) {
                pendingPathHint = hint
            }
        }
        return entries
    }

    private static func pathHint(from line: String) -> String? {
        let cleaned = line
            .replacingOccurrences(of: "`", with: " ")
            .replacingOccurrences(of: "\"", with: " ")
            .replacingOccurrences(of: "'", with: " ")
            .replacingOccurrences(of: "=", with: " ")
            .replacingOccurrences(of: ":", with: " ")
            .replacingOccurrences(of: "，", with: " ")
            .replacingOccurrences(of: "：", with: " ")
        let parts = cleaned.split { ch in
            ch == " " || ch == "\t" || ch == "(" || ch == ")" || ch == "[" || ch == "]" || ch == "<" || ch == ">"
        }
        for part in parts {
            let candidate = String(part).trimmingCharacters(in: CharacterSet(charactersIn: "#*-•"))
            if isSupportedGeneratedFile(candidate) {
                return normalizedPath(candidate)
            }
        }
        return nil
    }

    private static func languageHint(fromFenceOpening opening: String) -> String? {
        let value = opening.replacingOccurrences(of: "```", with: "")
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .lowercased()
        return value.isEmpty ? nil : value
    }

    private static func fallbackFileName(for node: NodeRunRecord) -> String? {
        switch node.kind {
        case .codeWorker, .formatter:
            return "main.py"
        default:
            return nil
        }
    }

    private static func fallbackFileName(forLanguage language: String?) -> String? {
        let value = language?.lowercased() ?? ""
        if value.contains("python") || value == "py" { return "main.py" }
        if value.contains("swift") { return "Sources/App.swift" }
        if value.contains("javascript") || value == "js" { return "index.js" }
        if value.contains("typescript") || value == "ts" { return "index.ts" }
        if value.contains("html") { return "index.html" }
        if value.contains("css") { return "style.css" }
        if value.contains("markdown") || value == "md" { return "README.md" }
        if value.contains("json") { return "data.json" }
        return nil
    }

    private static func isSupportedGeneratedFile(_ path: String) -> Bool {
        let lower = normalizedPath(path).lowercased()
        guard !lower.isEmpty, !lower.contains(".."), lower.count < 180 else { return false }
        let supported = [".py", ".swift", ".js", ".ts", ".html", ".css", ".json", ".md", ".txt", ".plist", ".yml", ".yaml"]
        return supported.contains { lower.hasSuffix($0) }
    }

    private static func shouldAcceptGeneratedBody(_ body: String, forPath path: String) -> Bool {
        let lowerPath = normalizedPath(path).lowercased()
        if looksLikeDirectoryTree(body), !(lowerPath.hasSuffix(".md") || lowerPath.hasSuffix(".txt")) {
            return false
        }
        if looksLikeBareReviewerDecision(body) {
            return false
        }
        return true
    }

    private static func looksLikeDirectoryTree(_ body: String) -> Bool {
        let lines = body.components(separatedBy: .newlines).map { $0.trimmingCharacters(in: .whitespaces) }
        let treeMarkers = lines.filter { $0.contains("├──") || $0.contains("└──") || $0.contains("│") || $0.hasPrefix("|--") || $0.hasPrefix("`--") }
        return treeMarkers.count >= 2
    }

    private static func looksLikeBareReviewerDecision(_ body: String) -> Bool {
        let trimmed = body.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        return trimmed.hasPrefix("{\"passed\":") && trimmed.contains("\"feedback\"") && trimmed.count < 300
    }

    private static func exportFallbackReport(run: RunRecord, error: Error) -> URL {
        let exportRoot = FileManager.default.temporaryDirectory
            .appendingPathComponent("AIWorkflowStudio-Exports", isDirectory: true)
        try? FileManager.default.createDirectory(at: exportRoot, withIntermediateDirectories: true)
        let url = exportRoot.appendingPathComponent("zip-export-failed-\(run.id.uuidString.prefix(8)).txt")
        let text = "ZIP 导出失败：\(error.localizedDescription)\n\n" + LogExportService.markdown(for: run)
        try? text.write(to: url, atomically: true, encoding: .utf8)
        return url
    }

    private static func safeFileName(_ value: String) -> String {
        let allowed = CharacterSet.alphanumerics.union(CharacterSet(charactersIn: "-_ ."))
        let scalars = value.unicodeScalars.map { allowed.contains($0) ? Character($0) : "-" }
        let cleaned = String(scalars).trimmingCharacters(in: .whitespacesAndNewlines)
        return cleaned.isEmpty ? "AIWorkflowStudio" : String(cleaned.prefix(80))
    }

    private static func normalizedPath(_ path: String) -> String {
        path.replacingOccurrences(of: "\\", with: "/")
            .split(separator: "/")
            .filter { !$0.isEmpty && $0 != "." && $0 != ".." }
            .joined(separator: "/")
    }
}

private enum CRC32 {
    private static let table: [UInt32] = (0..<256).map { value in
        var crc = UInt32(value)
        for _ in 0..<8 {
            if crc & 1 == 1 {
                crc = 0xedb88320 ^ (crc >> 1)
            } else {
                crc >>= 1
            }
        }
        return crc
    }

    static func checksum(_ data: Data) -> UInt32 {
        var crc: UInt32 = 0xffffffff
        for byte in data {
            crc = table[Int((crc ^ UInt32(byte)) & 0xff)] ^ (crc >> 8)
        }
        return crc ^ 0xffffffff
    }
}

private extension String {
    var utf8Data: Data { Data(utf8) }
}

private extension Data {
    mutating func appendUInt16LE(_ value: UInt16) {
        append(UInt8(value & 0xff))
        append(UInt8((value >> 8) & 0xff))
    }

    mutating func appendUInt32LE(_ value: UInt32) {
        append(UInt8(value & 0xff))
        append(UInt8((value >> 8) & 0xff))
        append(UInt8((value >> 16) & 0xff))
        append(UInt8((value >> 24) & 0xff))
    }
}
