import SwiftUI

struct SettingsView: View {
    @EnvironmentObject private var state: AppState

    var body: some View {
        ZStack {
            LiquidBackground()
            ScrollView {
                VStack(spacing: 18) {
                    SectionTitle(title: "设置", subtitle: "默认中文总结；未读范围包含垃圾邮件。")

                    backendCard
                    scheduleCard
                    cleanupCard
                    aiCard
                    saveCard
                }
                .padding()
                .frame(maxWidth: 860)
                .frame(maxWidth: .infinity)
            }
        }
        .navigationTitle("设置")
    }

    private var backendCard: some View {
        GlassCard {
            VStack(alignment: .leading, spacing: 12) {
                SectionTitle(title: "后端地址", subtitle: "真机测试不要用 localhost，要填电脑局域网 IP。")
                TextField("http://192.168.1.20:3000", text: $state.backendURL)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .keyboardType(.URL)
                    .padding(14)
                    .background(.white.opacity(0.10), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
            }
        }
    }

    private var scheduleCard: some View {
        GlassCard {
            VStack(alignment: .leading, spacing: 12) {
                SectionTitle(title: "总结频率", subtitle: "后端定时执行，完成后推送到 App。")
                Picker("频率", selection: $state.settings.frequency) {
                    ForEach(SummaryFrequency.allCases) { frequency in
                        Text(frequency.title).tag(frequency)
                    }
                }
                .pickerStyle(.segmented)

                Toggle("启用自动总结", isOn: $state.settings.enabled)
                    .toggleStyle(.switch)
                Toggle("包含垃圾邮件未读", isOn: $state.settings.includeJunkUnread)
                    .disabled(true)
                HStack {
                    Text("总结语言")
                    Spacer()
                    Text("中文")
                        .foregroundStyle(.secondary)
                }
            }
        }
    }

    private var cleanupCard: some View {
        GlassCard {
            VStack(alignment: .leading, spacing: 12) {
                SectionTitle(title: "自动清理", subtitle: "30 天后移入已删除邮件，再保留 7 天。")
                Toggle("清理 Outlook 原邮件", isOn: $state.settings.autoDeleteEnabled)
                    .toggleStyle(.switch)
                Stepper("已读/已总结超过 \(state.settings.deleteAfterDays) 天后删除", value: $state.settings.deleteAfterDays, in: 7...365)
                Stepper("删除邮件中保留 \(state.settings.permanentDeleteAfterDays) 天", value: $state.settings.permanentDeleteAfterDays, in: 1...60)

                Text("风险：开启后会影响真实邮箱。建议先用小号测试。")
                    .font(.footnote)
                    .foregroundStyle(.orange)
            }
        }
    }

    private var aiCard: some View {
        GlassCard {
            VStack(alignment: .leading, spacing: 12) {
                SectionTitle(title: "AI API", subtitle: "支持 OpenAI-compatible chat completions 接口。")
                SecureField("AI API Key", text: $state.settings.aiApiKey)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .padding(14)
                    .background(.white.opacity(0.10), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                TextField("接口地址", text: $state.settings.aiBaseUrl)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .keyboardType(.URL)
                    .padding(14)
                    .background(.white.opacity(0.10), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                TextField("模型", text: $state.settings.aiModel)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .padding(14)
                    .background(.white.opacity(0.10), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
            }
        }
    }

    private var saveCard: some View {
        VStack(spacing: 12) {
            Button {
                Task { await state.saveSettings() }
            } label: {
                Label("保存设置", systemImage: "checkmark.circle.fill")
            }
            .buttonStyle(PrimaryButtonStyle())

            Button {
                Task { await state.refreshAll() }
            } label: {
                Label("刷新状态", systemImage: "arrow.clockwise")
            }
            .buttonStyle(PrimaryButtonStyle())
        }
    }
}
