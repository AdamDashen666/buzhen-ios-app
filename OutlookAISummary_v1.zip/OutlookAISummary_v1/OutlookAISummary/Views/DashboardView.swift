import SwiftUI

struct DashboardView: View {
    @EnvironmentObject private var state: AppState

    var body: some View {
        ZStack {
            LiquidBackground()
            ScrollView {
                VStack(spacing: 18) {
                    header
                    statusCard
                    if state.linkedUser != nil {
                        controlCard
                        summariesList
                    } else {
                        loginCard
                    }
                    if let error = state.lastError, !error.isEmpty {
                        errorCard(error)
                    }
                }
                .padding()
                .frame(maxWidth: 860)
                .frame(maxWidth: .infinity)
            }
            .refreshable { await state.refreshAll() }
        }
        .navigationTitle("总览")
        .toolbar {
            Button("刷新") { Task { await state.refreshAll() } }
        }
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Outlook AI Summary")
                .font(.largeTitle.bold())
            Text("自动总结未读邮件，包含垃圾邮件；默认中文推送。")
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private var statusCard: some View {
        GlassCard {
            VStack(alignment: .leading, spacing: 14) {
                HStack {
                    Image(systemName: state.linkedUser == nil ? "link.badge.plus" : "checkmark.seal.fill")
                        .font(.title2)
                    VStack(alignment: .leading, spacing: 3) {
                        Text(state.linkedUser == nil ? "未连接 Outlook" : "已连接")
                            .font(.headline)
                        Text(state.statusText)
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                    }
                    Spacer()
                    if state.isLoading { ProgressView().tint(.white) }
                }
                HStack(spacing: 8) {
                    CapsuleTag(text: state.settings.frequency.title, systemImage: "clock")
                    CapsuleTag(text: "中文", systemImage: "textformat")
                    CapsuleTag(text: "含垃圾邮件", systemImage: "exclamationmark.triangle")
                }
            }
        }
    }

    private var loginCard: some View {
        GlassCard {
            VStack(alignment: .leading, spacing: 14) {
                SectionTitle(title: "登录 Microsoft", subtitle: "使用官方 OAuth，不保存 Outlook 密码。")
                Button {
                    state.openMicrosoftLogin()
                } label: {
                    Label("连接 Outlook", systemImage: "person.crop.circle.badge.checkmark")
                }
                .buttonStyle(PrimaryButtonStyle())

                Button {
                    Task { await state.refreshAll() }
                } label: {
                    Label("我已登录，检查状态", systemImage: "arrow.clockwise")
                }
                .buttonStyle(PrimaryButtonStyle())
            }
        }
    }

    private var controlCard: some View {
        GlassCard {
            VStack(alignment: .leading, spacing: 14) {
                SectionTitle(title: "手动总结", subtitle: "立即拉取收件箱 + 垃圾邮件里的未读邮件。")
                Button {
                    Task { await state.runNow() }
                } label: {
                    Label("现在总结一次", systemImage: "sparkles")
                }
                .buttonStyle(PrimaryButtonStyle())

                Button {
                    state.requestNotifications()
                } label: {
                    Label("开启推送通知", systemImage: "bell.badge.fill")
                }
                .buttonStyle(PrimaryButtonStyle())
            }
        }
    }

    private var summariesList: some View {
        VStack(alignment: .leading, spacing: 12) {
            SectionTitle(title: "历史总结", subtitle: state.summaries.isEmpty ? "暂无总结。" : nil)
            ForEach(state.summaries) { summary in
                GlassCard {
                    VStack(alignment: .leading, spacing: 12) {
                        HStack {
                            Text(summary.title)
                                .font(.headline)
                            Spacer()
                            Text(summary.createdAt.shortDisplayDate)
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                        HStack(spacing: 8) {
                            CapsuleTag(text: "未读 \(summary.unreadCount)", systemImage: "envelope.badge")
                            CapsuleTag(text: "垃圾 \(summary.junkUnreadCount)", systemImage: "trash")
                        }
                        Text(summary.content)
                            .font(.body)
                            .textSelection(.enabled)
                    }
                }
            }
        }
    }

    private func errorCard(_ message: String) -> some View {
        GlassCard {
            VStack(alignment: .leading, spacing: 8) {
                Label("错误", systemImage: "exclamationmark.triangle.fill")
                    .font(.headline)
                Text(message)
                    .font(.footnote)
                    .textSelection(.enabled)
            }
            .foregroundStyle(.red.opacity(0.9))
        }
    }
}

private extension String {
    var shortDisplayDate: String {
        let formatter = ISO8601DateFormatter()
        guard let date = formatter.date(from: self) else { return self }
        return date.formatted(date: .abbreviated, time: .shortened)
    }
}
