import Foundation
import SwiftUI
import UserNotifications
import UIKit

@MainActor
final class AppState: ObservableObject {
    @Published var backendURL: String {
        didSet {
            UserDefaults.standard.set(backendURL, forKey: "backendURL")
            api.baseURL = backendURL.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        }
    }
    @Published var linkedUser: LinkedUser?
    @Published var summaries: [SummaryItem] = []
    @Published var settings = AppSettings()
    @Published var isLoading = false
    @Published var statusText = "未连接"
    @Published var lastError: String?
    @Published var pushToken: String?

    let deviceId: String
    let api: APIClient

    init() {
        let savedBackend = UserDefaults.standard.string(forKey: "backendURL") ?? "http://localhost:3000"
        self.backendURL = savedBackend
        self.api = APIClient(baseURL: savedBackend)
        if let savedDeviceId = UserDefaults.standard.string(forKey: "deviceId") {
            self.deviceId = savedDeviceId
        } else {
            let newId = UUID().uuidString
            UserDefaults.standard.set(newId, forKey: "deviceId")
            self.deviceId = newId
        }
    }

    func bootstrap() async {
        await registerDevice()
        await refreshAll()
    }

    func registerDevice() async {
        do {
            _ = try await api.registerDevice(deviceId: deviceId, deviceToken: pushToken)
        } catch {
            lastError = error.localizedDescription
        }
    }

    func refreshAll() async {
        isLoading = true
        defer { isLoading = false }
        do {
            let status = try await api.authStatus(deviceId: deviceId)
            if status.linked {
                linkedUser = status.user
                statusText = status.user?.email ?? "已连接"
                if let remoteSettings = status.user?.settings {
                    settings = remoteSettings
                }
                let response = try await api.summaries(deviceId: deviceId)
                summaries = response.summaries
            } else {
                linkedUser = nil
                statusText = "未连接 Outlook"
            }
            lastError = nil
        } catch {
            lastError = error.localizedDescription
        }
    }

    func openMicrosoftLogin() {
        guard let url = api.authStartURL(deviceId: deviceId) else { return }
        UIApplication.shared.open(url)
    }

    func saveSettings() async {
        isLoading = true
        defer { isLoading = false }
        do {
            let response = try await api.updateSettings(deviceId: deviceId, settings: settings)
            settings = response.settings
            lastError = nil
            await refreshAll()
        } catch {
            lastError = error.localizedDescription
        }
    }

    func runNow() async {
        isLoading = true
        defer { isLoading = false }
        do {
            let response = try await api.runNow(deviceId: deviceId)
            if let summary = response.summary {
                summaries.insert(summary, at: 0)
            }
            lastError = nil
        } catch {
            lastError = error.localizedDescription
        }
    }

    func requestNotifications() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .badge, .sound]) { granted, error in
            DispatchQueue.main.async {
                if let error { self.lastError = error.localizedDescription }
                if granted { UIApplication.shared.registerForRemoteNotifications() }
            }
        }
    }

    func updatePushToken(_ token: String) {
        pushToken = token
        Task { await registerDevice() }
    }
}
