# Outlook AI Summary Backend

This backend links an Outlook account through Microsoft OAuth, periodically reads unread Inbox + Junk Email messages, summarizes them with an OpenAI-compatible API, pushes the summary to the iOS app, and cleans old mail.

## Main behavior

- Summary language: Chinese by default.
- Frequency options: daily, every 6 hours, monthly.
- Unread scope: Inbox unread + Junk Email unread.
- Cleanup policy:
  - Read messages older than 30 days are moved to Deleted Items.
  - Summarized messages older than 30 days are moved to Deleted Items.
  - Messages moved by this app are permanently deleted after 7 more days.

## Setup

1. Create a Microsoft Entra app registration.
2. Add redirect URI: `http://localhost:3000/auth/callback` for local testing, or your production backend URL.
3. Give delegated permissions:
   - `offline_access`
   - `User.Read`
   - `Mail.ReadWrite`
4. Copy `.env.example` to `.env` and fill in values.
5. Install and run:

```bash
npm install
npm start
```

## Important production notes

- Replace the JSON file store with a real encrypted database.
- Encrypt per-user AI keys if you store them server-side.
- Put the backend behind HTTPS before using it outside local testing.
- Use APNs production credentials for App Store/TestFlight builds.
- Test cleanup with a dummy mailbox before enabling it on a real mailbox.
