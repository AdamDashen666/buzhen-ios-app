import SwiftUI
import UIKit

private struct ConnectionDraft: Equatable {
    var nodeID: UUID
    var condition: EdgeCondition
}

private struct ViewportFrameKey: PreferenceKey {
    static var defaultValue: CGRect = .zero
    static func reduce(value: inout CGRect, nextValue: () -> CGRect) { value = nextValue() }
}

private struct ModuleLibraryRequest: Identifiable, Equatable {
    let id = UUID()
    var spawnPoint: CGPoint
}

struct WorkflowEditorView: View {
    @EnvironmentObject private var store: AppStore
    @State private var moduleLibraryRequest: ModuleLibraryRequest?
    @State private var editingNode: WorkflowNode?
    @State private var selectedNodeIDs: Set<UUID> = []
    @State private var copiedNodes: [WorkflowNode] = []
    @State private var connectFrom: ConnectionDraft?
    @State private var dragPoint: CGPoint?
    @State private var zoom: CGFloat = 1.0
    @State private var lastZoom: CGFloat = 1.0
    @State private var nodePositions: [UUID: CGPoint] = [:]
    @State private var visualDragOffsets: [UUID: CGSize] = [:]
    @State private var dragStartPositions: [UUID: CGPoint] = [:]
    @State private var activeDragNodeIDs: Set<UUID> = []
    @State private var selectedEdgeID: UUID?
    @State private var edgeAwaitingDeleteID: UUID?
    @State private var moduleMenuNode: WorkflowNode?
    @State private var showingSelectionMenu = false
    @State private var lastKnownScreenCenterPoint = CGPoint(x: 1200, y: 800)
    @State private var viewportSize: CGSize = .zero
    @State private var contentFrame: CGRect = .zero
    @State private var isCommandPressed = false
    @State private var workflowDebugShareItem: WorkflowDebugShareItem?

    private let minimumCanvasSize = CGSize(width: 9600, height: 7600)
    private let minZoom: CGFloat = 0.40
    private let maxZoom: CGFloat = 1.80

    var body: some View {
        NavigationStack {
            Group {
                if let project = store.selectedProject {
                    GeometryReader { proxy in
                        if proxy.size.width > 720 {
                            canvas(project: project, viewport: proxy.size)
                        } else {
                            listEditor(project: project)
                        }
                    }
                } else {
                    ContentUnavailableView("没有项目", systemImage: "folder.badge.plus", description: Text("先在首页新建一个工作流。"))
                }
            }
            .studioBackground()
            .navigationTitle(store.selectedProject?.title ?? "工作流")
            .toolbar { editorToolbar }
            .sheet(item: $moduleLibraryRequest) { request in
                ModuleLibrarySheet(spawnPoint: request.spawnPoint)
            }
            .sheet(item: $editingNode) { node in
                if let project = store.selectedProject {
                    NodeDetailView(projectID: project.id, node: node)
                }
            }
            .overlay { autoBuildOverlay }
            .alert(item: $store.appAlert) { alert in
                Alert(title: Text(alert.title), message: Text(alert.message), dismissButton: .default(Text("知道了")))
            }
            .confirmationDialog("多选操作", isPresented: $showingSelectionMenu, titleVisibility: .visible) {
                selectionMenuActions
            } message: {
                Text("已选中 \(selectedNodeIDs.count) 个模块")
            }
            .sheet(item: $workflowDebugShareItem) { item in
                WorkflowDebugActivitySheet(activityItems: [item.url])
            }
        }
    }

    @ViewBuilder
    private var selectionMenuActions: some View {
        if let project = store.selectedProject {
            Button("复制选中模块") {
                copySelection(project: project)
                showingSelectionMenu = false
            }
            Button("粘贴到原模块附近") {
                pasteSelection(project: project)
                showingSelectionMenu = false
            }
            Button("删除选中模块", role: .destructive) {
                deleteSelection(project: project)
                showingSelectionMenu = false
            }
        }
        Button("取消", role: .cancel) {
            showingSelectionMenu = false
        }
    }

    @ToolbarContentBuilder
    private var editorToolbar: some ToolbarContent {
        ToolbarItemGroup(placement: .topBarTrailing) {
            Button("添加模块") {
                let point = screenCenterCanvasPoint()
                lastKnownScreenCenterPoint = point
                moduleLibraryRequest = ModuleLibraryRequest(spawnPoint: point)
            }
            Button("AI 自动选择") { store.startAutoBuildSelectedProject() }
            Button("一键应用默认模型") { store.applyDefaultModelsToSelectedProject() }
            Button { store.startSelectedProjectRun() } label: { Label("运行", systemImage: "play.fill") }
            Button(role: .destructive) { store.stopActiveRun() } label: { Label("停止", systemImage: "stop.fill") }
        }
    }

    @ViewBuilder
    private func moduleMenuOverlay(project: WorkflowProject) -> some View {
        if let node = moduleMenuNode, selectedNodeIDs.count == 1, selectedNodeIDs.contains(node.id) {
            let position = visualPosition(for: node)
            VStack(alignment: .leading, spacing: 8) {
                Text(node.kind.summary)
                    .font(.caption2)
                    .foregroundStyle(.white.opacity(0.78))
                    .lineLimit(3)
                    .frame(width: 210, alignment: .leading)
                Button { editingNode = node; moduleMenuNode = nil } label: {
                    Label("打开详情", systemImage: "slider.horizontal.3")
                }
                Button { copiedNodes = [node]; moduleMenuNode = nil } label: {
                    Label("复制", systemImage: "doc.on.doc")
                }
                if canDeleteNode(node) {
                    Button(role: .destructive) { deleteMenuNode(node) } label: {
                        Label("删除", systemImage: "trash")
                    }
                }
            }
            .font(.caption.weight(.semibold))
            .buttonStyle(.borderedProminent)
            .controlSize(.small)
            .padding(10)
            .background(.black.opacity(0.72), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous).stroke(.white.opacity(0.22), lineWidth: 1))
            .shadow(color: .black.opacity(0.35), radius: 16, x: 0, y: 8)
            .position(x: position.x, y: max(70, position.y - 120))
            .zIndex(60)
        }
    }

    private func canvas(project: WorkflowProject, viewport: CGSize) -> some View {
        let visibleRect = currentVisibleRect(viewport: viewport)
        let activeRun = store.selectedProjectActiveRun
        let runningIDs = Set(activeRun?.currentNodeIDs ?? [])
        let waitingIDs = Set(activeRun?.waitingNodeIDs ?? [])
        let staleIDs = Set(activeRun?.staleNodeIDs ?? [])
        let completedIDs = completedNodeIDs(from: activeRun).subtracting(waitingIDs).subtracting(staleIDs)
        // v5.8：先停止节点虚拟裁剪。之前 currentVisibleRect 在缩放/整理/拖拽后偶尔算偏，
        // 导致模块明明存在但被过滤掉，看起来像“模块消失”。节点数量在 iPad 画布里通常不大，
        // 比起少渲染几个卡片，保证不消失更重要。
        let visibleNodes = project.nodes
        let canvasSize = dynamicCanvasSize(for: project, viewport: viewport)
        let performanceMode = project.nodes.count > 14 || project.edges.count > 18 || activeRun?.status == .running

        return ScrollView([.horizontal, .vertical], showsIndicators: false) {
            ZStack(alignment: .topLeading) {
                GeometryReader { geo in
                    Color.clear.preference(key: ViewportFrameKey.self, value: geo.frame(in: .named("workflowScroll")))
                }
                .frame(width: 0, height: 0)

                Rectangle()
                    .fill(Color.clear)
                    .frame(width: canvasSize.width, height: canvasSize.height)
                    .contentShape(Rectangle())
                    .simultaneousGesture(backgroundTapGesture(project: project, visibleRect: visibleRect))

                edgeLayer(project: project, visibleRect: visibleRect, canvasSize: canvasSize, performanceMode: performanceMode)

                ForEach(visibleNodes) { node in
                    nodeCard(node: node, project: project, runningIDs: runningIDs, waitingIDs: waitingIDs, staleIDs: staleIDs, completedIDs: completedIDs, performanceMode: performanceMode)
                }

                moduleMenuOverlay(project: project)
            }
            .frame(width: canvasSize.width, height: canvasSize.height, alignment: .topLeading)
            .coordinateSpace(name: "workflowCanvas")
            .scaleEffect(zoom, anchor: .topLeading)
            .frame(width: canvasSize.width * zoom, height: canvasSize.height * zoom, alignment: .topLeading)
            .contentShape(Rectangle())
            .gesture(zoomGesture)
            .background(keyCommandLayer(project: project))
            .onAppear {
                viewportSize = viewport
                updateScreenCenterPoint(viewport: viewport)
                syncNodePositions(project)
            }
            .onChange(of: project.nodes) { _, _ in
                guard activeDragNodeIDs.isEmpty else { return }
                syncNodePositions(project)
            }
            .onPreferenceChange(ViewportFrameKey.self) { frame in
                contentFrame = frame
                viewportSize = viewport
                updateScreenCenterPoint(viewport: viewport)
            }
            .transaction { transaction in transaction.animation = nil }
        }
        .scrollDisabled(!activeDragNodeIDs.isEmpty || connectFrom != nil)
        .coordinateSpace(name: "workflowScroll")
        .overlay(alignment: .topLeading) { leftControls(project: project).padding(12) }
        .overlay(alignment: .topTrailing) { rightControls(project: project).padding(12) }
        .overlay(alignment: .bottomLeading) { hintBar.padding(12) }
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
    }

    private func completedNodeIDs(from run: RunRecord?) -> Set<UUID> {
        guard let run else { return [] }
        var latestStatusByNode: [UUID: NodeStatus] = [:]
        for nodeRecord in run.nodeRecords {
            latestStatusByNode[nodeRecord.nodeID] = nodeRecord.status
        }
        return Set(latestStatusByNode.compactMap { nodeID, status in
            status == .passed ? nodeID : nil
        })
    }

    private func nodeCard(node: WorkflowNode, project: WorkflowProject, runningIDs: Set<UUID>, waitingIDs: Set<UUID>, staleIDs: Set<UUID>, completedIDs: Set<UUID>, performanceMode: Bool) -> some View {
        let position = visualPosition(for: node)
        let selected = selectedNodeIDs.contains(node.id)
        let isRunning = runningIDs.contains(node.id)
        let isWaiting = waitingIDs.contains(node.id) && !isRunning
        let isStale = staleIDs.contains(node.id) && !isRunning
        let isCompleted = completedIDs.contains(node.id) && !isRunning && !isWaiting && !isStale
        return NodeCard(
            node: node,
            selected: selected,
            running: isRunning,
            waiting: isWaiting,
            stale: isStale,
            completed: isCompleted,
            isDragging: activeDragNodeIDs.contains(node.id),
            isConnecting: connectFrom?.nodeID == node.id,
            multiSelectedCount: selectedNodeIDs.count,
            performanceMode: performanceMode,
            onSelect: { handleNodeTap(node) },
            onDoubleSelect: { handleNodeDoubleTap(node) },
            onInputTap: { finishTapConnection(to: node, project: project) },
            onOutputTap: { condition in startPortConnection(from: node, condition: condition) },
            onOutputDragChanged: { condition, value in updatePortDrag(from: node, condition: condition, value: value) },
            onOutputDragEnded: { condition, value in finishPortDrag(from: node, condition: condition, value: value, project: project) },
            onCardDragChanged: { value in updateNodeDrag(node: node, value: value, project: project) },
            onCardDragEnded: { value in finishNodeDrag(node: node, value: value, project: project) }
        )
        .position(x: position.x, y: position.y)
        .zIndex(activeDragNodeIDs.contains(node.id) ? 30 : (selected ? 10 : (runningIDs.contains(node.id) ? 9 : (waitingIDs.contains(node.id) ? 8 : 0))))
        .transaction { transaction in
            transaction.disablesAnimations = true
            transaction.animation = nil
        }
    }

    private func keyCommandLayer(project: WorkflowProject) -> some View {
        KeyCommandReader(
            onDelete: { deleteSelection(project: project) },
            onCopy: { copySelection(project: project) },
            onPaste: { pasteSelection(project: project) },
            onUndo: { undo(project: project) },
            onRedo: { redo(project: project) },
            onCommandStateChange: { isDown in isCommandPressed = isDown }
        )
    }

    private var hintBar: some View {
        Text("空白取消选择 · 按住 ⌘ 点击多选 · 拖模块主体移动 · 只从小接口连线 · ⌘Z 回溯")
            .font(.caption2)
            .foregroundStyle(.white.opacity(0.72))
            .padding(.horizontal, 12)
            .padding(.vertical, 8)
            .background(.black.opacity(0.28), in: Capsule())
    }

    private var autoBuildOverlay: some View {
        Group {
            if store.isAutoBuilding {
                VStack(spacing: 12) {
                    ProgressView(value: store.autoBuildProgress)
                    Text(store.autoBuildMessage).font(.headline)
                    Text("正在把全部可用模块说明发给默认文本模型，并生成节点与连线")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                .padding(24)
                .frame(width: 390)
                .liquidGlass(cornerRadius: 26, glow: true)
            }
        }
    }

    private func leftControls(project: WorkflowProject) -> some View {
        HStack(spacing: 8) {
            Button { undo(project: project) } label: { Label("回溯", systemImage: "arrow.uturn.backward") }
                .disabled(!store.canUndoSelectedProject)
            Button { redo(project: project) } label: { Label("取消回溯", systemImage: "arrow.uturn.forward") }
                .disabled(!store.canRedoSelectedProject)
            Button(role: .destructive) { reset(project: project) } label: { Label("重置", systemImage: "arrow.counterclockwise") }
            Button(role: .destructive) { clearEdges(project: project) } label: { Label("清空连线", systemImage: "link.badge.minus") }
            Button { exportWorkflowDebugLog(project: project) } label: { Label("调试", systemImage: "wrench.and.screwdriver") }
        }
        .buttonStyle(.borderedProminent)
        .controlSize(.small)
    }

    private func rightControls(project: WorkflowProject) -> some View {
        HStack(spacing: 8) {
            Text("缩放 \(Int(zoom * 100))%")
                .font(.caption.weight(.semibold))
                .padding(.horizontal, 10)
                .padding(.vertical, 7)
                .background(.black.opacity(0.28), in: Capsule())
            Button("1:1") { zoom = 1.0; lastZoom = 1.0 }
            Button("整理") { arrange(project: project) }
            Button("一键默认模型") { store.applyDefaultModels(to: project.id) }
        }
        .buttonStyle(.bordered)
        .controlSize(.small)
    }

    private func reset(project: WorkflowProject) {
        store.resetWorkflow(projectID: project.id)
        selectedNodeIDs = []
        selectedEdgeID = nil
        edgeAwaitingDeleteID = nil
        moduleMenuNode = nil
    }

    private func clearEdges(project: WorkflowProject) {
        store.removeAllEdges(projectID: project.id)
        selectedEdgeID = nil
        edgeAwaitingDeleteID = nil
        moduleMenuNode = nil
    }

    private func exportWorkflowDebugLog(project: WorkflowProject) {
        let url = makeWorkflowDebugLogURL(project: project)
        workflowDebugShareItem = WorkflowDebugShareItem(url: url)
    }

    private func arrange(project: WorkflowProject) {
        store.arrangeWorkflow(projectID: project.id, around: visibleCenterPoint())
        // v5.1：整理后立即同步本地节点坐标，避免画布上的临时坐标和项目真实坐标短暂不一致，
        // 导致连线看起来从旧位置飞出或连到错误位置。
        if let updated = store.projects.first(where: { $0.id == project.id }) {
            syncNodePositions(updated)
        }
        DispatchQueue.main.async {
            if let updated = store.projects.first(where: { $0.id == project.id }) {
                syncNodePositions(updated)
            }
        }
        selectedNodeIDs = []
        selectedEdgeID = nil
        edgeAwaitingDeleteID = nil
        moduleMenuNode = nil
    }

    private func undo(project: WorkflowProject) {
        store.undoSelectedProject()
        selectedNodeIDs = []
        selectedEdgeID = nil
        edgeAwaitingDeleteID = nil
        activeDragNodeIDs = []
        moduleMenuNode = nil
    }

    private func redo(project: WorkflowProject) {
        store.redoSelectedProject()
        selectedNodeIDs = []
        selectedEdgeID = nil
        edgeAwaitingDeleteID = nil
        activeDragNodeIDs = []
        moduleMenuNode = nil
    }

    private func edgeLayer(project: WorkflowProject, visibleRect: CGRect, canvasSize: CGSize, performanceMode: Bool) -> some View {
        let visibleEdges = project.edges.filter { edgeVisible($0, in: project, visibleRect: visibleRect) }

        return ZStack(alignment: .topLeading) {
            if performanceMode {
                fastEdgeCanvas(edges: visibleEdges, project: project, canvasSize: canvasSize)
                ForEach(labeledEdges(visibleEdges, project: project, visibleRect: visibleRect)) { edge in
                    edgeLabelOverlay(edge: edge, project: project)
                }
                if let selectedID = selectedEdgeID,
                   let selectedEdge = project.edges.first(where: { $0.id == selectedID }) {
                    edgeSelectionOverlay(edge: selectedEdge, project: project)
                }
            } else {
                ForEach(visibleEdges) { edge in
                    edgeView(edge: edge, project: project)
                }
            }

            if let connectFrom,
               let source = project.nodes.first(where: { $0.id == connectFrom.nodeID }),
               let dragPoint {
                EdgeRouteShape(start: portPoint(for: source, condition: connectFrom.condition), end: dragPoint)
                    .stroke(edgeColor(connectFrom.condition).opacity(0.92), lineWidth: 3)
            }
        }
        .frame(width: canvasSize.width, height: canvasSize.height)
    }

    private func fastEdgeCanvas(edges: [WorkflowEdge], project: WorkflowProject, canvasSize: CGSize) -> some View {
        Canvas { context, _ in
            for edge in edges {
                let selected = selectedEdgeID == edge.id
                guard let route = edgeRoutePoints(edge, in: project) else { continue }
                let path = workflowEdgePath(points: route)
                context.stroke(
                    path,
                    with: .color(edgeColor(edge).opacity(selected ? 0.95 : 0.64)),
                    style: StrokeStyle(lineWidth: selected ? 4 : 2, lineCap: .round, lineJoin: .round)
                )
            }
        }
        .frame(width: canvasSize.width, height: canvasSize.height)
        .allowsHitTesting(false)
    }

    private func labeledEdges(_ edges: [WorkflowEdge], project: WorkflowProject, visibleRect: CGRect) -> [WorkflowEdge] {
        Array(edges.filter { edge in
            guard edge.condition != .always, let route = edgeRoutePoints(edge, in: project) else { return false }
            return visibleRect.insetBy(dx: -160, dy: -160).contains(edgeLabelPoint(route))
        }.prefix(18))
    }

    @ViewBuilder
    private func edgeLabelOverlay(edge: WorkflowEdge, project: WorkflowProject) -> some View {
        if let route = edgeRoutePoints(edge, in: project), edge.condition != .always {
            Text(edge.condition.title)
                .font(.caption2.bold())
                .foregroundStyle(edgeColor(edge))
                .padding(.horizontal, 5)
                .padding(.vertical, 2)
                .background(.black.opacity(0.38), in: Capsule())
                .position(edgeLabelPoint(route))
        }
    }

    @ViewBuilder
    private func edgeSelectionOverlay(edge: WorkflowEdge, project: WorkflowProject) -> some View {
        if let route = edgeRoutePoints(edge, in: project) {
            let label = edgeLabelPoint(route)
            if edge.condition != .always {
                Text(edge.condition.title)
                    .font(.caption2.bold())
                    .foregroundStyle(edgeColor(edge))
                    .padding(.horizontal, 6)
                    .padding(.vertical, 3)
                    .background(.black.opacity(0.55), in: Capsule())
                    .position(label)
            }
            if edgeAwaitingDeleteID == edge.id {
                Button(role: .destructive) { deleteEdge(edge, project: project) } label: {
                    Label("删除连线", systemImage: "trash").font(.caption.bold())
                }
                .buttonStyle(.borderedProminent)
                .controlSize(.small)
                .position(CGPoint(x: label.x, y: label.y - 34))
            }
        }
    }


    private func edgeView(edge: WorkflowEdge, project: WorkflowProject) -> some View {
        ZStack(alignment: .topLeading) {
            let selected = selectedEdgeID == edge.id

            if let route = edgeRoutePoints(edge, in: project) {
                EdgeRouteShape(points: route)
                    .stroke(
                        edgeColor(edge).opacity(selected ? 0.95 : 0.70),
                        style: StrokeStyle(lineWidth: selected ? 4 : 2.2, lineCap: .round, lineJoin: .round)
                    )
                let label = edgeLabelPoint(route)
                if edge.condition != .always {
                    Text(edge.condition.title)
                        .font(.caption2.bold())
                        .foregroundStyle(edgeColor(edge))
                        .padding(.horizontal, 5)
                        .padding(.vertical, 2)
                        .background(.black.opacity(0.38), in: Capsule())
                        .position(label)
                }
                if edgeAwaitingDeleteID == edge.id {
                    Button(role: .destructive) { deleteEdge(edge, project: project) } label: {
                        Label("删除连线", systemImage: "trash").font(.caption.bold())
                    }
                    .buttonStyle(.borderedProminent)
                    .controlSize(.small)
                    .position(CGPoint(x: label.x, y: label.y - 34))
                }
            }
        }
    }


    private func backgroundTapGesture(project: WorkflowProject, visibleRect: CGRect) -> some Gesture {
        DragGesture(minimumDistance: 0, coordinateSpace: .named("workflowCanvas"))
            .onEnded { value in
                let movement = hypot(value.translation.width, value.translation.height)
                guard movement < 8 else { return }
                if let edge = nearestEdge(to: value.location, in: project, visibleRect: visibleRect) {
                    handleEdgeTap(edge)
                } else {
                    clearSelection()
                }
            }
    }

    private func nearestEdge(to point: CGPoint, in project: WorkflowProject, visibleRect: CGRect) -> WorkflowEdge? {
        let candidateEdges = project.edges.filter { edgeVisible($0, in: project, visibleRect: visibleRect) }
        var bestEdge: WorkflowEdge?
        var bestDistance = CGFloat.greatestFiniteMagnitude

        for edge in candidateEdges {
            guard let route = edgeRoutePoints(edge, in: project) else { continue }
            let distance = distanceFromPointToRoute(point, route: route)
            if distance < bestDistance {
                bestDistance = distance
                bestEdge = edge
            }
        }

        // 选线阈值要比视觉线宽大，但不能大到抢到旁边线。缩放越小，视觉上越难点，阈值稍微放宽。
        let threshold = max(18, min(34, 24 / max(zoom, 0.65)))
        return bestDistance <= threshold ? bestEdge : nil
    }

    private func distanceFromPointToRoute(_ point: CGPoint, route: [CGPoint]) -> CGFloat {
        guard route.count > 1, let first = route.first else { return CGFloat.greatestFiniteMagnitude }
        var best = hypot(point.x - first.x, point.y - first.y)
        for index in 0..<(route.count - 1) {
            best = min(best, distanceFromPointToSegment(point, route[index], route[index + 1]))
        }
        return best
    }

    private func distanceFromPointToSegment(_ point: CGPoint, _ a: CGPoint, _ b: CGPoint) -> CGFloat {
        let vx = b.x - a.x
        let vy = b.y - a.y
        let wx = point.x - a.x
        let wy = point.y - a.y
        let lengthSquared = vx * vx + vy * vy
        if lengthSquared <= 0.0001 { return hypot(point.x - a.x, point.y - a.y) }
        let t = max(0, min(1, (wx * vx + wy * vy) / lengthSquared))
        let projection = CGPoint(x: a.x + t * vx, y: a.y + t * vy)
        return hypot(point.x - projection.x, point.y - projection.y)
    }

    private func edgeLabelPoint(_ route: [CGPoint]) -> CGPoint {
        workflowEdgeLabelPoint(points: route)
    }

    private func handleEdgeTap(_ edge: WorkflowEdge) {
        if selectedEdgeID == edge.id { edgeAwaitingDeleteID = edge.id } else {
            selectedEdgeID = edge.id
            selectedNodeIDs = []
            edgeAwaitingDeleteID = nil
        }
    }

    private func deleteEdge(_ edge: WorkflowEdge, project: WorkflowProject) {
        store.removeEdge(projectID: project.id, edgeID: edge.id)
        selectedEdgeID = nil
        edgeAwaitingDeleteID = nil
    }

    private func currentVisibleRect(viewport: CGSize) -> CGRect {
        // v6.0：画布按“近似无限画布”处理。这里给可见区更大的预渲染缓冲，
        // 不再因为线或节点稍微超出屏幕边缘就提前过滤掉。
        guard contentFrame != .zero else { return CGRect(x: 0, y: 0, width: 2600, height: 1800) }
        return CGRect(
            x: max(0, -contentFrame.minX / max(zoom, 0.1)),
            y: max(0, -contentFrame.minY / max(zoom, 0.1)),
            width: viewport.width / max(zoom, 0.1),
            height: viewport.height / max(zoom, 0.1)
        ).insetBy(dx: -1600, dy: -1200)
    }

    private func visibleCenterPoint() -> CGPoint {
        screenCenterCanvasPoint()
    }

    private func screenCenterCanvasPoint() -> CGPoint {
        let safeZoom = max(zoom, 0.1)
        guard contentFrame != .zero, viewportSize != .zero else {
            return unclampedPoint(x: lastKnownScreenCenterPoint.x, y: lastKnownScreenCenterPoint.y)
        }

        // v6.4：添加模块必须落在用户当前屏幕中心，而不是回到开始模块附近。
        // contentFrame 是画布内容在滚动视口里的位置；用屏幕中心减去内容原点，再除以缩放，
        // 得到“当前屏幕中心对应的画布坐标”。
        let x = (viewportSize.width * 0.5 - contentFrame.minX) / safeZoom
        let y = (viewportSize.height * 0.5 - contentFrame.minY) / safeZoom
        return unclampedPoint(x: x, y: y)
    }

    private func updateScreenCenterPoint(viewport: CGSize) {
        let safeZoom = max(zoom, 0.1)
        guard contentFrame != .zero, viewport != .zero else { return }
        let x = (viewport.width * 0.5 - contentFrame.minX) / safeZoom
        let y = (viewport.height * 0.5 - contentFrame.minY) / safeZoom
        lastKnownScreenCenterPoint = unclampedPoint(x: x, y: y)
    }

    private func dynamicCanvasSize(for project: WorkflowProject, viewport: CGSize) -> CGSize {
        let visible = currentVisibleRect(viewport: viewport)
        let safeZoom = max(zoom, 0.1)

        // v6.0：画布大小必须按“当前渲染坐标”扩展，而不是只看 project.nodes 里的持久坐标。
        // 否则拖拽中、整理后、连线路由超出旧边界时，线/模块会被 Canvas frame 裁掉。
        let visualNodeMaxX = project.nodes.map { visualPosition(for: $0).x + 360 }.max() ?? 0
        let visualNodeMaxY = project.nodes.map { visualPosition(for: $0).y + 260 }.max() ?? 0
        let persistedNodeMaxX = project.nodes.map { CGFloat($0.x) + 360 }.max() ?? 0
        let persistedNodeMaxY = project.nodes.map { CGFloat($0.y) + 260 }.max() ?? 0
        let routePoints = project.edges.flatMap { edgeRoutePoints($0, in: project) ?? [] }
        let routeMaxX = routePoints.map(\.x).max() ?? 0
        let routeMaxY = routePoints.map(\.y).max() ?? 0
        let maxX = max(visualNodeMaxX, persistedNodeMaxX, routeMaxX, visible.maxX)
        let maxY = max(visualNodeMaxY, persistedNodeMaxY, routeMaxY, visible.maxY)
        let expansionX = max(viewport.width / safeZoom * 2.0, 2400)
        let expansionY = max(viewport.height / safeZoom * 2.0, 2000)
        return CGSize(
            width: max(minimumCanvasSize.width, maxX + expansionX),
            height: max(minimumCanvasSize.height, maxY + expansionY)
        )
    }

    private func makeWorkflowDebugLogURL(project: WorkflowProject) -> URL {
        let visible = currentVisibleRect(viewport: viewportSize == .zero ? CGSize(width: 1200, height: 800) : viewportSize)
        let canvas = dynamicCanvasSize(for: project, viewport: viewportSize == .zero ? CGSize(width: 1200, height: 800) : viewportSize)
        var lines: [String] = []
        lines.append("# AI Workflow Studio 布线调试日志")
        lines.append("")
        lines.append("- 项目：\(project.title)")
        lines.append("- 导出时间：\(Date().formatted(date: .abbreviated, time: .standard))")
        lines.append("- 节点数：\(project.nodes.count)")
        lines.append("- 连线数：\(project.edges.count)")
        lines.append("- 缩放：\(Int(zoom * 100))%")
        lines.append("- 画布尺寸：\(Int(canvas.width)) × \(Int(canvas.height))")
        lines.append("- 可见区域：x=\(Int(visible.minX)), y=\(Int(visible.minY)), w=\(Int(visible.width)), h=\(Int(visible.height))")
        lines.append("")
        lines.append("## 节点位置")
        lines.append("| 标题 | 类型 | id | x | y | 本地x | 本地y | 是否可见 |")
        lines.append("|---|---|---|---:|---:|---:|---:|---|")
        for node in project.nodes.sorted(by: { $0.title < $1.title }) {
            let local = localPosition(for: node)
            let isVisible = visible.insetBy(dx: -260, dy: -220).contains(local)
            lines.append("| \(escapePipe(node.title)) | \(node.kind.title) | \(shortID(node.id)) | \(Int(node.x)) | \(Int(node.y)) | \(Int(local.x)) | \(Int(local.y)) | \(isVisible ? "是" : "否") |")
        }
        lines.append("")
        lines.append("## 连线与路线")
        lines.append("| 条件 | from | to | lane | 反馈线 | 路线点 | 包围盒 | 是否可见 |")
        lines.append("|---|---|---|---:|---|---|---|---|")
        for edge in project.edges {
            let from = project.nodes.first(where: { $0.id == edge.from })
            let to = project.nodes.first(where: { $0.id == edge.to })
            let route = edgeRoutePoints(edge, in: project) ?? []
            let xs = route.map(\.x)
            let ys = route.map(\.y)
            let box: String
            if let minX = xs.min(), let maxX = xs.max(), let minY = ys.min(), let maxY = ys.max() {
                box = "x:\(Int(minX))-\(Int(maxX)), y:\(Int(minY))-\(Int(maxY))"
            } else {
                box = "无"
            }
            let routeText = route.map { "(\(Int($0.x)),\(Int($0.y)))" }.joined(separator: " → ")
            let visibleEdge = edgeVisible(edge, in: project, visibleRect: visible)
            lines.append("| \(edge.condition.title) | \(escapePipe(from?.title ?? shortID(edge.from))) | \(escapePipe(to?.title ?? shortID(edge.to))) | \(edgeLane(edge, in: project)) | \(isFeedbackRoute(edge, in: project) ? "是" : "否") | \(escapePipe(routeText)) | \(box) | \(visibleEdge ? "是" : "否") |")
        }
        lines.append("")
        lines.append("## 原始工作流 JSON 摘要")
        lines.append("- 这个日志只记录位置、路由、可见性和连接关系，不包含 API Key。")
        lines.append("- 如果出现模块消失，先看“节点位置”的本地坐标和是否可见。")
        lines.append("- 如果出现线飞出屏幕，先看“连线与路线”的包围盒和路线点。")

        let text = lines.joined(separator: "\n")
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent("AIWorkflowStudio-Debug", isDirectory: true)
        try? FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        let url = directory.appendingPathComponent("workflow-routing-debug-\(project.id.uuidString.prefix(8)).md")
        do {
            try text.write(to: url, atomically: true, encoding: .utf8)
        } catch {
            try? "导出调试日志失败：\(error.localizedDescription)".write(to: url, atomically: true, encoding: .utf8)
        }
        return url
    }

    private func shortID(_ id: UUID) -> String {
        String(id.uuidString.prefix(8))
    }

    private func escapePipe(_ value: String) -> String {
        value.replacingOccurrences(of: "|", with: "\\|").replacingOccurrences(of: "\n", with: " ")
    }

    private func edgeVisible(_ edge: WorkflowEdge, in project: WorkflowProject, visibleRect: CGRect) -> Bool {
        guard let route = edgeRoutePoints(edge, in: project), !route.isEmpty else { return false }
        let expanded = visibleRect.insetBy(dx: -900, dy: -700)
        let xs = route.map(\.x)
        let ys = route.map(\.y)
        guard let minX = xs.min(), let maxX = xs.max(), let minY = ys.min(), let maxY = ys.max() else { return false }
        let routeRect = CGRect(x: minX, y: minY, width: max(1, maxX - minX), height: max(1, maxY - minY)).insetBy(dx: -80, dy: -80)
        return expanded.intersects(routeRect)
    }

    private func edgePoints(_ edge: WorkflowEdge, in project: WorkflowProject) -> (start: CGPoint, end: CGPoint)? {
        guard let from = project.nodes.first(where: { $0.id == edge.from }),
              let to = project.nodes.first(where: { $0.id == edge.to }) else { return nil }
        return (portPoint(for: from, condition: edge.condition), inputPortPoint(for: to))
    }

    private func edgeRoutePoints(_ edge: WorkflowEdge, in project: WorkflowProject) -> [CGPoint]? {
        guard let points = edgePoints(edge, in: project) else { return nil }
        return workflowEdgeRoutePoints(
            start: points.start,
            end: points.end,
            condition: edge.condition,
            lane: edgeLane(edge, in: project),
            isFeedback: isFeedbackRoute(edge, in: project)
        )
    }

    private func edgeLane(_ edge: WorkflowEdge, in project: WorkflowProject) -> Int {
        let feedback = isFeedbackRoute(edge, in: project)
        let candidates = project.edges
            .filter { other in
                if feedback != isFeedbackRoute(other, in: project) { return false }
                if feedback {
                    return other.condition == edge.condition || other.to == edge.to || other.from == edge.from
                }
                return other.from == edge.from || other.to == edge.to
            }
            .sorted { lhs, rhs in
                let lStart = edgePoints(lhs, in: project)?.start.y ?? 0
                let rStart = edgePoints(rhs, in: project)?.start.y ?? 0
                if abs(lStart - rStart) > 0.5 { return lStart < rStart }
                return lhs.id.uuidString < rhs.id.uuidString
            }
        return candidates.firstIndex(where: { $0.id == edge.id }) ?? 0
    }

    private func isFeedbackRoute(_ edge: WorkflowEdge, in project: WorkflowProject) -> Bool {
        // v5.7：不要因为用户把模块拖到目标右侧，就把普通线误判成“断链/虚线”。
        // 只有明确失败/低分条件，才按返工线处理；普通往回走也保持完整实线。
        return edge.condition == .failed || edge.condition == .scoreLow
    }

    private func portPoint(for node: WorkflowNode, condition: EdgeCondition) -> CGPoint {
        let p = visualPosition(for: node)
        if node.kind.isReviewer && condition == .failed { return CGPoint(x: p.x + 124, y: p.y + 46) }
        return CGPoint(x: p.x + 124, y: p.y - (node.kind.isReviewer ? 26 : 0))
    }

    private func inputPortPoint(for node: WorkflowNode) -> CGPoint {
        let p = visualPosition(for: node)
        return CGPoint(x: p.x - 124, y: p.y)
    }

    private func edgeColor(_ edge: WorkflowEdge) -> Color { edgeColor(edge.condition) }
    private func edgeColor(_ condition: EdgeCondition) -> Color {
        switch condition {
        case .failed, .scoreLow: return .red
        case .passed, .scoreHigh: return .mint
        case .always: return .cyan
        }
    }

    private func localPosition(for node: WorkflowNode) -> CGPoint {
        nodePositions[node.id] ?? CGPoint(x: CGFloat(node.x), y: CGFloat(node.y))
    }

    private func visualPosition(for node: WorkflowNode) -> CGPoint {
        let base = localPosition(for: node)
        let offset = visualDragOffsets[node.id] ?? .zero
        return CGPoint(x: base.x + offset.width, y: base.y + offset.height)
    }

    private func syncNodePositions(_ project: WorkflowProject) {
        var next = nodePositions
        let ids = Set(project.nodes.map(\.id))
        next = next.filter { ids.contains($0.key) }
        for node in project.nodes where !activeDragNodeIDs.contains(node.id) {
            next[node.id] = CGPoint(x: CGFloat(node.x), y: CGFloat(node.y))
        }
        withAnimation(nil) { nodePositions = next }
    }

    private func unclampedPoint(x: CGFloat, y: CGFloat) -> CGPoint {
        // 保证模块输入口不会落到 Canvas 负坐标之外，避免边缘附近的连线被左/上边界裁切。
        CGPoint(x: max(x, 220), y: max(y, 160))
    }

    private var zoomGesture: some Gesture {
        MagnificationGesture()
            .onChanged { value in
                guard activeDragNodeIDs.isEmpty && connectFrom == nil else { return }
                let softened = 1 + (value - 1) * 0.10
                zoom = min(max(lastZoom * softened, minZoom), maxZoom)
            }
            .onEnded { _ in
                lastZoom = zoom
                updateScreenCenterPoint(viewport: viewportSize == .zero ? CGSize(width: 1200, height: 800) : viewportSize)
            }
    }

    private func startPortConnection(from node: WorkflowNode, condition: EdgeCondition) {
        connectFrom = ConnectionDraft(nodeID: node.id, condition: condition)
        dragPoint = portPoint(for: node, condition: condition)
    }

    private func updatePortDrag(from node: WorkflowNode, condition: EdgeCondition, value: DragGesture.Value) {
        connectFrom = ConnectionDraft(nodeID: node.id, condition: condition)
        let start = portPoint(for: node, condition: condition)
        dragPoint = CGPoint(
            x: start.x + value.translation.width / max(zoom, 0.1),
            y: start.y + value.translation.height / max(zoom, 0.1)
        )
    }

    private func finishPortDrag(from node: WorkflowNode, condition: EdgeCondition, value: DragGesture.Value, project: WorkflowProject) {
        let start = portPoint(for: node, condition: condition)
        let endPoint = CGPoint(
            x: start.x + value.translation.width / max(zoom, 0.1),
            y: start.y + value.translation.height / max(zoom, 0.1)
        )
        if let target = targetNode(at: endPoint, in: project, excluding: node.id) {
            store.connect(projectID: project.id, from: node.id, to: target.id, condition: condition)
        }
        connectFrom = nil
        dragPoint = nil
    }

    private func finishTapConnection(to node: WorkflowNode, project: WorkflowProject) {
        if let connectFrom, connectFrom.nodeID != node.id {
            store.connect(projectID: project.id, from: connectFrom.nodeID, to: node.id, condition: connectFrom.condition)
        }
        connectFrom = nil
        dragPoint = nil
    }

    private func dragDelta(_ value: DragGesture.Value) -> CGPoint {
        CGPoint(
            x: value.translation.width / max(zoom, 0.1),
            y: value.translation.height / max(zoom, 0.1)
        )
    }

    private func rawDragDistance(_ value: DragGesture.Value) -> CGFloat {
        hypot(value.translation.width, value.translation.height)
    }

    private func updateNodeDrag(node: WorkflowNode, value: DragGesture.Value, project: WorkflowProject) {
        guard rawDragDistance(value) > 7 else { return }
        if activeDragNodeIDs.isEmpty {
            moduleMenuNode = nil
            selectedEdgeID = nil
            edgeAwaitingDeleteID = nil
            if !selectedNodeIDs.contains(node.id) { selectedNodeIDs = [node.id] }
            let group = selectedNodeIDs.isEmpty ? Set([node.id]) : selectedNodeIDs
            activeDragNodeIDs = group
            dragStartPositions = Dictionary(uniqueKeysWithValues: group.compactMap { id in
                guard let current = project.nodes.first(where: { $0.id == id }) else { return nil }
                return (id, localPosition(for: current))
            })
        }
        let delta = dragDelta(value)
        var nextOffsets = visualDragOffsets
        for id in activeDragNodeIDs {
            nextOffsets[id] = CGSize(width: delta.x, height: delta.y)
        }
        var transaction = Transaction()
        transaction.disablesAnimations = true
        transaction.animation = nil
        withTransaction(transaction) { visualDragOffsets = nextOffsets }
    }

    private func finishNodeDrag(node: WorkflowNode, value: DragGesture.Value, project: WorkflowProject) {
        defer {
            dragStartPositions = [:]
            activeDragNodeIDs = []
            visualDragOffsets = [:]
        }
        guard rawDragDistance(value) > 7 else { return }
        let delta = dragDelta(value)
        let draggedIDs = activeDragNodeIDs.isEmpty ? Set([node.id]) : activeDragNodeIDs
        var finalPositions: [UUID: CGPoint] = [:]
        for id in draggedIDs {
            guard let start = dragStartPositions[id] ?? project.nodes.first(where: { $0.id == id }).map({ localPosition(for: $0) }) else { continue }
            finalPositions[id] = unclampedPoint(x: start.x + delta.x, y: start.y + delta.y)
        }
        guard !finalPositions.isEmpty else { return }
        var transaction = Transaction()
        transaction.disablesAnimations = true
        transaction.animation = nil
        withTransaction(transaction) {
            for (id, point) in finalPositions { nodePositions[id] = point }
        }
        store.moveNodes(projectID: project.id, positions: finalPositions, persist: true)
    }

    private func targetNode(at point: CGPoint, in project: WorkflowProject, excluding sourceID: UUID) -> WorkflowNode? {
        project.nodes
            .filter { $0.id != sourceID }
            .min { lhs, rhs in distance(point, inputPortPoint(for: lhs)) < distance(point, inputPortPoint(for: rhs)) }
            .flatMap { candidate in
                let target = inputPortPoint(for: candidate)
                return distance(point, target) < 120 ? candidate : nil
            }
    }

    private func clearSelection() {
        guard activeDragNodeIDs.isEmpty && connectFrom == nil else { return }
        selectedNodeIDs = []
        selectedEdgeID = nil
        edgeAwaitingDeleteID = nil
        moduleMenuNode = nil
        showingSelectionMenu = false
    }

    private func handleNodeTap(_ node: WorkflowNode) {
        guard activeDragNodeIDs.isEmpty && connectFrom == nil else { return }
        selectedEdgeID = nil
        edgeAwaitingDeleteID = nil
        if isCommandPressed {
            moduleMenuNode = nil
            if selectedNodeIDs.contains(node.id) {
                selectedNodeIDs.remove(node.id)
            } else {
                selectedNodeIDs.insert(node.id)
            }
            return
        }
        if selectedNodeIDs.count == 1 && selectedNodeIDs.contains(node.id) {
            return
        }
        selectedNodeIDs = [node.id]
        moduleMenuNode = nil
    }

    private func handleNodeDoubleTap(_ node: WorkflowNode) {
        guard activeDragNodeIDs.isEmpty && connectFrom == nil else { return }
        guard !isCommandPressed else { return }
        selectedEdgeID = nil
        edgeAwaitingDeleteID = nil
        selectedNodeIDs = [node.id]
        moduleMenuNode = node
    }

    private func canDeleteNode(_ node: WorkflowNode) -> Bool {
        node.kind != .start && node.kind != .output && store.selectedProject != nil
    }

    private func deleteMenuNode(_ node: WorkflowNode) {
        guard let project = store.selectedProject else { return }
        store.removeNode(projectID: project.id, nodeID: node.id)
        selectedNodeIDs.remove(node.id)
        moduleMenuNode = nil
    }

    private func deleteSelection(project: WorkflowProject) {
        if let edgeID = selectedEdgeID {
            store.removeEdge(projectID: project.id, edgeID: edgeID)
            selectedEdgeID = nil
            edgeAwaitingDeleteID = nil
            return
        }
        store.removeNodes(projectID: project.id, nodeIDs: selectedNodeIDs)
        selectedNodeIDs = []
        moduleMenuNode = nil
    }

    private func copySelection(project: WorkflowProject) {
        copiedNodes = project.nodes.filter { selectedNodeIDs.contains($0.id) && $0.kind != .start && $0.kind != .output }
    }

    private func pasteSelection(project: WorkflowProject) {
        guard !copiedNodes.isEmpty else { return }
        selectedNodeIDs = store.pasteNodes(copiedNodes, to: project.id, near: nil)
    }

    private func midpoint(_ a: CGPoint, _ b: CGPoint) -> CGPoint {
        CGPoint(x: (a.x + b.x) / 2, y: (a.y + b.y) / 2)
    }

    private func distance(_ a: CGPoint, _ b: CGPoint) -> CGFloat {
        hypot(a.x - b.x, a.y - b.y)
    }

    private func listEditor(project: WorkflowProject) -> some View {
        List {
            Section("快速操作") {
                Button { store.applyDefaultModels(to: project.id) } label: { Label("一键应用全局默认模型", systemImage: "bolt.badge.checkmark") }
                Button { store.startSelectedProjectRun() } label: { Label("运行工作流", systemImage: "play.fill") }
                Button(role: .destructive) { store.stopActiveRun() } label: { Label("停止运行", systemImage: "stop.fill") }
                Button { store.undoSelectedProject() } label: { Label("回溯", systemImage: "arrow.uturn.backward") }
                Button { store.redoSelectedProject() } label: { Label("取消回溯", systemImage: "arrow.uturn.forward") }
                Button { store.arrangeWorkflow(projectID: project.id, around: CGPoint(x: 360, y: 240)) } label: { Label("整理布局", systemImage: "square.grid.2x2") }
                Button(role: .destructive) { store.resetWorkflow(projectID: project.id) } label: { Label("重置：清除所有模块", systemImage: "arrow.counterclockwise") }
                Button(role: .destructive) { store.removeAllEdges(projectID: project.id) } label: { Label("清空全部连线", systemImage: "link.badge.minus") }
            }
            Section("节点") {
                ForEach(project.nodes) { node in
                    Button { handleNodeTap(node) } label: {
                        Label(node.title, systemImage: node.kind.icon)
                    }
                }
                .onDelete { offsets in
                    let ids = Set(offsets.map { project.nodes[$0].id })
                    store.removeNodes(projectID: project.id, nodeIDs: ids)
                }
            }
            Section("连线") {
                if project.edges.isEmpty {
                    Text("暂无连线。iPad 横屏下从模块小接口拖动可以连线。")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                ForEach(project.edges) { edge in
                    HStack {
                        Text("\(project.nodes.first(where: { $0.id == edge.from })?.title ?? "?") → \(project.nodes.first(where: { $0.id == edge.to })?.title ?? "?")")
                        Text(edge.condition.title).font(.caption).foregroundStyle(.secondary)
                        Spacer()
                        Button(role: .destructive) { store.removeEdge(projectID: project.id, edgeID: edge.id) } label: { Image(systemName: "trash") }
                    }
                }
            }
        }
        .scrollContentBackground(.hidden)
    }
}


func workflowEdgeRoutePoints(start: CGPoint, end: CGPoint) -> [CGPoint] {
    workflowEdgeRoutePoints(
        start: start,
        end: end,
        condition: .always,
        lane: 0,
        isFeedback: false
    )
}

func workflowEdgeRoutePoints(start: CGPoint, end: CGPoint, condition: EdgeCondition, lane: Int, isFeedback: Bool) -> [CGPoint] {
    let safeLane = CGFloat(min(max(lane, 0), 6))
    let deltaX = end.x - start.x
    let deltaY = end.y - start.y
    let feedback = isFeedback || condition == .failed || condition == .scoreLow

    // v5.7：反馈线/往回走的线也保持完整实线，不再画成端点短线或虚线。
    // 所有线只在 start/end 的局部包围盒附近走，不使用图外总线。
    if feedback {
        let outX = start.x + 72 + safeLane * 18
        let inX = end.x - 72 - safeLane * 18
        let verticalDirection: CGFloat = deltaY >= 0 ? 1 : -1
        let bridgeY = (start.y + end.y) / 2 + verticalDirection * (34 + safeLane * 18)
        return compactOrthogonalRoute([
            start,
            CGPoint(x: outX, y: start.y),
            CGPoint(x: outX, y: bridgeY),
            CGPoint(x: inX, y: bridgeY),
            CGPoint(x: inX, y: end.y),
            end
        ])
    }

    // 正向但换行/目标在左：只使用 start/end 附近的右侧短通道，不再拉到全图右侧。
    if deltaX < 40 {
        let sideX = max(start.x, end.x) + 82 + safeLane * 18
        let bridgeY = (start.y + end.y) / 2
        return compactOrthogonalRoute([
            start,
            CGPoint(x: sideX, y: start.y),
            CGPoint(x: sideX, y: bridgeY),
            CGPoint(x: end.x - 74 - safeLane * 10, y: bridgeY),
            CGPoint(x: end.x - 74 - safeLane * 10, y: end.y),
            end
        ])
    }

    // 同行正向：直接连，最清晰。
    if abs(deltaY) < 22 && deltaX > 80 { return [start, end] }

    // 普通跨列：在两列之间走局部竖线。lane 只做小偏移，避免大范围飞线。
    let naturalMidX = start.x + deltaX * 0.50
    let laneOffset = CGFloat((lane % 5) - 2) * 12
    let minMidX = start.x + 72
    let maxMidX = end.x - 72
    let midX = min(max(naturalMidX + laneOffset, minMidX), maxMidX)
    return compactOrthogonalRoute([
        start,
        CGPoint(x: midX, y: start.y),
        CGPoint(x: midX, y: end.y),
        end
    ])
}
func compactOrthogonalRoute(_ points: [CGPoint]) -> [CGPoint] {
    var result: [CGPoint] = []
    for (index, rawPoint) in points.enumerated() {
        // Preserve real port coordinates for the first/last point; only keep intermediate route points
        // inside a small safety margin. Otherwise line endpoints can detach from the node port.
        let point: CGPoint
        if index == 0 || index == points.count - 1 {
            point = rawPoint
        } else {
            point = CGPoint(x: max(rawPoint.x, 32), y: max(rawPoint.y, 32))
        }
        if let last = result.last, abs(last.x - point.x) < 0.5, abs(last.y - point.y) < 0.5 { continue }
        result.append(point)
    }
    // Remove middle points that are perfectly collinear.
    var changed = true
    while changed && result.count >= 3 {
        changed = false
        var next: [CGPoint] = []
        for index in result.indices {
            if index > 0 && index < result.count - 1 {
                let a = result[index - 1]
                let b = result[index]
                let c = result[index + 1]
                let sameX = abs(a.x - b.x) < 0.5 && abs(b.x - c.x) < 0.5
                let sameY = abs(a.y - b.y) < 0.5 && abs(b.y - c.y) < 0.5
                if sameX || sameY { changed = true; continue }
            }
            next.append(result[index])
        }
        result = next
    }
    return result
}

func workflowEdgePath(start: CGPoint, end: CGPoint) -> Path {
    workflowEdgePath(points: workflowEdgeRoutePoints(start: start, end: end))
}

func workflowEdgePath(points: [CGPoint]) -> Path {
    var path = Path()
    guard let first = points.first else { return path }
    path.move(to: first)
    guard points.count > 1 else { return path }

    for index in 1..<points.count {
        let previous = points[index - 1]
        let current = points[index]
        let radius: CGFloat = 14
        if index < points.count - 1 {
            let next = points[index + 1]
            let incoming = CGPoint(x: current.x - previous.x, y: current.y - previous.y)
            let outgoing = CGPoint(x: next.x - current.x, y: next.y - current.y)
            let inLength = max(hypot(incoming.x, incoming.y), 0.001)
            let outLength = max(hypot(outgoing.x, outgoing.y), 0.001)
            let r = min(radius, inLength * 0.35, outLength * 0.35)
            let before = CGPoint(x: current.x - incoming.x / inLength * r, y: current.y - incoming.y / inLength * r)
            let after = CGPoint(x: current.x + outgoing.x / outLength * r, y: current.y + outgoing.y / outLength * r)
            path.addLine(to: before)
            path.addQuadCurve(to: after, control: current)
        } else {
            path.addLine(to: current)
        }
    }
    return path
}

func workflowEdgeLabelPoint(start: CGPoint, end: CGPoint) -> CGPoint {
    workflowEdgeLabelPoint(points: workflowEdgeRoutePoints(start: start, end: end))
}

func workflowEdgeLabelPoint(points: [CGPoint]) -> CGPoint {
    guard points.count > 1 else { return points.first ?? .zero }
    if points.count >= 4 { return points[min(points.count - 2, 3)] }
    let mid = points.count / 2
    if points.indices.contains(mid) && points.indices.contains(mid - 1) {
        return CGPoint(x: (points[mid].x + points[mid - 1].x) / 2, y: (points[mid].y + points[mid - 1].y) / 2)
    }
    return points[min(mid, points.count - 1)]
}

struct EdgeRouteShape: Shape {
    var points: [CGPoint]

    init(points: [CGPoint]) {
        self.points = points
    }

    init(start: CGPoint, end: CGPoint) {
        self.points = workflowEdgeRoutePoints(start: start, end: end)
    }

    func path(in rect: CGRect) -> Path {
        workflowEdgePath(points: points)
    }
}

private struct WorkflowDebugShareItem: Identifiable {
    let id = UUID()
    let url: URL
}

private struct WorkflowDebugActivitySheet: UIViewControllerRepresentable {
    let activityItems: [Any]

    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: activityItems, applicationActivities: nil)
    }

    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}

struct NodeCard: View {
    var node: WorkflowNode
    var selected: Bool
    var running: Bool
    var waiting: Bool
    var stale: Bool
    var completed: Bool
    var isDragging: Bool
    var isConnecting: Bool
    var multiSelectedCount: Int
    var performanceMode: Bool
    var onSelect: () -> Void
    var onDoubleSelect: () -> Void
    var onInputTap: () -> Void
    var onOutputTap: (EdgeCondition) -> Void
    var onOutputDragChanged: (EdgeCondition, DragGesture.Value) -> Void
    var onOutputDragEnded: (EdgeCondition, DragGesture.Value) -> Void
    var onCardDragChanged: (DragGesture.Value) -> Void
    var onCardDragEnded: (DragGesture.Value) -> Void

    var body: some View {
        let base = HStack(spacing: 10) {
            inputPort
            content
            outputPorts
        }
        .padding()
        .overlay(border)
        .transaction { transaction in transaction.animation = nil }

        base
            .background(
                RoundedRectangle(cornerRadius: 22, style: .continuous)
                    .fill(
                        LinearGradient(
                            colors: performanceMode
                                ? [Color.black.opacity(isDragging ? 0.92 : 0.80), Color.black.opacity(isDragging ? 0.86 : 0.72)]
                                : (isDragging
                                    ? [Color.black.opacity(0.92), Color.black.opacity(0.84)]
                                    : [Color.black.opacity(0.76), Color(red: 0.04, green: 0.11, blue: 0.15).opacity(0.82)]),
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
            )
            .overlay(
                RoundedRectangle(cornerRadius: 22, style: .continuous)
                    .stroke(isDragging ? Color.mint.opacity(0.95) : Color.white.opacity(0.24), lineWidth: isDragging ? 2 : 1)
            )
            .shadow(color: .black.opacity(performanceMode ? 0.10 : (isDragging ? 0.16 : 0.22)), radius: performanceMode ? 3 : (isDragging ? 4 : 12), x: 0, y: performanceMode ? 2 : (isDragging ? 3 : 8))
            .shadow(color: borderColor.opacity(performanceMode ? 0 : ((isConnecting || selected || running || waiting || stale) ? 0.16 : 0)), radius: isDragging ? 0 : 18, x: 0, y: 8)
            .opacity(completed ? 0.84 : 1.0)
            .animation(nil, value: isDragging)
    }

    private var inputPort: some View {
        port(title: "输入", systemImage: "arrow.down.circle.fill", color: .cyan)
            .onTapGesture(perform: onInputTap)
    }

    private var content: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 8) {
                Image(systemName: node.kind.icon)
                Text(node.title).font(.headline)
                Spacer(minLength: 4)
                if completed {
                    Image(systemName: "checkmark.circle.fill")
                        .foregroundStyle(.green)
                        .font(.title3)
                        .accessibilityLabel("已完成")
                }
            }
            HStack(spacing: 6) {
                Text(statusTitle)
                    .font(.caption2.bold())
                    .padding(.horizontal, 8)
                    .padding(.vertical, 4)
                    .foregroundStyle((running || waiting || stale) ? .white : .primary)
                    .background(statusColor.opacity((running || waiting || stale) ? 0.38 : 0.22), in: Capsule())
                    .overlay(Capsule().stroke(statusColor.opacity((running || waiting || stale) ? 0.70 : 0.0), lineWidth: 1))
                if selected {
                    Text(multiSelectedCount > 1 ? "多选中" : "已选中")
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                }
            }
        }
        .frame(width: 184, alignment: .leading)
        .contentShape(RoundedRectangle(cornerRadius: 18))
        .simultaneousGesture(
            TapGesture(count: 2)
                .onEnded { onDoubleSelect() }
        )
        .onTapGesture(perform: onSelect)
        .highPriorityGesture(
            DragGesture(minimumDistance: 8, coordinateSpace: .named("workflowCanvas"))
                .onChanged(onCardDragChanged)
                .onEnded(onCardDragEnded)
        )
    }

    @ViewBuilder
    private var outputPorts: some View {
        if node.kind == .output {
            VStack(spacing: 3) {
                Image(systemName: "flag.checkered.circle.fill")
                    .font(.title3)
                    .foregroundStyle(.green)
                    .padding(8)
                    .background(.black.opacity(0.24), in: Circle())
                    .overlay(Circle().stroke(Color.green.opacity(0.65), lineWidth: 1.5))
                Text("终点")
                    .font(.caption2)
                    .foregroundStyle(.secondary)
            }
        } else {
            VStack(spacing: 8) {
                outputPort(title: node.kind.isReviewer ? "通过" : "输出", condition: node.kind.isReviewer ? .passed : .always, color: .mint)
                if node.kind.isReviewer {
                    outputPort(title: "不合格", condition: .failed, color: .red)
                }
            }
        }
    }

    private var border: some View {
        RoundedRectangle(cornerRadius: 22, style: .continuous)
            .stroke(borderColor, lineWidth: (selected || running || waiting || stale || completed) ? 2.5 : 0)
    }

    private var statusTitle: String {
        if running { return "运行中" }
        if waiting || stale { return "等待上游" }
        if completed { return "已完成" }
        return node.status.title
    }

    private var runningColor: Color {
        Color(red: 1.00, green: 0.42, blue: 0.08)
    }

    private var waitingColor: Color {
        Color(red: 0.18, green: 0.54, blue: 1.00)
    }

    private var statusColor: Color {
        if running { return runningColor }
        if waiting || stale { return waitingColor }
        if completed { return .green }
        return .cyan
    }

    private var borderColor: Color {
        if running { return runningColor.opacity(0.98) }
        if waiting || stale { return waitingColor.opacity(0.95) }
        if selected { return .mint.opacity(0.90) }
        if completed { return .green.opacity(0.75) }
        return .clear
    }

    private func outputPort(title: String, condition: EdgeCondition, color: Color) -> some View {
        port(title: title, systemImage: condition == .failed ? "xmark.circle.fill" : "arrow.up.circle.fill", color: color)
            .onTapGesture { onOutputTap(condition) }
            .gesture(
                DragGesture(minimumDistance: 4, coordinateSpace: .named("workflowCanvas"))
                    .onChanged { onOutputDragChanged(condition, $0) }
                    .onEnded { onOutputDragEnded(condition, $0) }
            )
    }

    private func port(title: String, systemImage: String, color: Color) -> some View {
        VStack(spacing: 3) {
            Image(systemName: systemImage)
                .font(.title3)
                .foregroundStyle(color)
                .padding(8)
                .background(.black.opacity(0.24), in: Circle())
                .overlay(Circle().stroke(color.opacity(0.65), lineWidth: 1.5))
            Text(title)
                .font(.caption2)
                .foregroundStyle(.secondary)
        }
        .contentShape(Rectangle())
    }
}

struct KeyCommandReader: UIViewRepresentable {
    var onDelete: () -> Void
    var onCopy: () -> Void
    var onPaste: () -> Void
    var onUndo: () -> Void
    var onRedo: () -> Void
    var onCommandStateChange: (Bool) -> Void = { _ in }

    func makeUIView(context: Context) -> KeyCatcherView {
        let view = KeyCatcherView()
        update(view)
        DispatchQueue.main.async { view.becomeFirstResponder() }
        return view
    }

    func updateUIView(_ uiView: KeyCatcherView, context: Context) {
        update(uiView)
        DispatchQueue.main.async { uiView.becomeFirstResponder() }
    }

    private func update(_ view: KeyCatcherView) {
        view.onDelete = onDelete
        view.onCopy = onCopy
        view.onPaste = onPaste
        view.onUndo = onUndo
        view.onRedo = onRedo
        view.onCommandStateChange = onCommandStateChange
    }
}

final class KeyCatcherView: UIView {
    var onDelete: (() -> Void)?
    var onCopy: (() -> Void)?
    var onPaste: (() -> Void)?
    var onUndo: (() -> Void)?
    var onRedo: (() -> Void)?
    var onCommandStateChange: ((Bool) -> Void)?

    override var canBecomeFirstResponder: Bool { true }

    override func pressesBegan(_ presses: Set<UIPress>, with event: UIPressesEvent?) {
        if event?.modifierFlags.contains(.command) == true { onCommandStateChange?(true) }
        super.pressesBegan(presses, with: event)
    }

    override func pressesEnded(_ presses: Set<UIPress>, with event: UIPressesEvent?) {
        if event?.modifierFlags.contains(.command) != true { onCommandStateChange?(false) }
        super.pressesEnded(presses, with: event)
    }

    override func pressesCancelled(_ presses: Set<UIPress>, with event: UIPressesEvent?) {
        onCommandStateChange?(false)
        super.pressesCancelled(presses, with: event)
    }

    override var keyCommands: [UIKeyCommand]? {
        [
            UIKeyCommand(input: UIKeyCommand.inputDelete, modifierFlags: [], action: #selector(deletePressed)),
            UIKeyCommand(input: "c", modifierFlags: .command, action: #selector(copyPressed)),
            UIKeyCommand(input: "v", modifierFlags: .command, action: #selector(pastePressed)),
            UIKeyCommand(input: "z", modifierFlags: .command, action: #selector(undoPressed)),
            UIKeyCommand(input: "z", modifierFlags: [.command, .shift], action: #selector(redoPressed)),
            UIKeyCommand(input: "y", modifierFlags: .command, action: #selector(redoPressed))
        ]
    }

    @objc private func deletePressed() { onDelete?() }
    @objc private func copyPressed() { onCopy?() }
    @objc private func pastePressed() { onPaste?() }
    @objc private func undoPressed() { onUndo?() }
    @objc private func redoPressed() { onRedo?() }
}
