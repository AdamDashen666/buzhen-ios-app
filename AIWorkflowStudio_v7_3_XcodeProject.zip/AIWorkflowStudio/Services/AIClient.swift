import Foundation
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif

struct AIMessage: Codable, Hashable {
    var role: String
    var content: String
}

struct AITextResponse: Hashable {
    var text: String
    var tokenUsage: TokenUsage
}

enum AIClientError: Error, LocalizedError {
    case invalidBaseURL
    case emptyAPIKey
    case badResponse
    case providerNotConfigured

    var errorDescription: String? {
        switch self {
        case .invalidBaseURL: return "API Base URL 无效"
        case .emptyAPIKey: return "API Key 为空"
        case .badResponse: return "模型接口返回格式无法解析"
        case .providerNotConfigured: return "当前模块没有配置 API 或模型"
        }
    }
}

final class AIClient {
    func fetchModels(baseURL: String, apiKey: String) async throws -> [AIModelInfo] {
        guard !apiKey.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { throw AIClientError.emptyAPIKey }
        guard let url = URL(string: normalized(baseURL) + "/models") else { throw AIClientError.invalidBaseURL }
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
        let (data, response) = try await URLSession.shared.data(for: request)
        guard (response as? HTTPURLResponse)?.statusCode ?? 500 < 400 else {
            let status = (response as? HTTPURLResponse)?.statusCode ?? -1
            let body = String(data: data, encoding: .utf8) ?? ""
            throw NSError(domain: "AIClient", code: status, userInfo: [NSLocalizedDescriptionKey: "刷新模型失败：HTTP \(status)\n\(body)"])
        }
        let decoded = try JSONDecoder().decode(OpenAIModelListResponse.self, from: data)
        return decoded.data.map { item in
            let lower = item.id.lowercased()
            return AIModelInfo(
                id: item.id,
                name: item.id,
                supportsVision: lower.contains("vision") || lower.contains("gpt-4o") || lower.contains("gemini") || lower.contains("vl") || lower.contains("doubao-seed"),
                supportsImageGeneration: lower.contains("image") || lower.contains("dall") || lower.contains("gpt-image")
            )
        }.sorted { $0.id < $1.id }
    }

    func completeText(baseURL: String, apiKey: String, model: String, messages: [AIMessage], maxTokens: Int, temperature: Double, timeoutSeconds: Int) async throws -> AITextResponse {
        guard !apiKey.isEmpty else { throw AIClientError.emptyAPIKey }
        guard let url = URL(string: normalized(baseURL) + "/chat/completions") else { throw AIClientError.invalidBaseURL }
        var request = URLRequest(url: url, timeoutInterval: TimeInterval(timeoutSeconds))
        request.httpMethod = "POST"
        request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        let payload = ChatCompletionRequest(model: model, messages: messages, max_tokens: maxTokens, temperature: temperature, stream: false)
        request.httpBody = try JSONEncoder().encode(payload)

        let (data, response) = try await URLSession.shared.data(for: request)
        guard (response as? HTTPURLResponse)?.statusCode ?? 500 < 400 else {
            let body = String(data: data, encoding: .utf8) ?? ""
            throw NSError(domain: "AIClient", code: 1, userInfo: [NSLocalizedDescriptionKey: "API 请求失败：\(body)"])
        }
        let decoded = try JSONDecoder().decode(ChatCompletionResponse.self, from: data)
        guard let text = decoded.choices.first?.message.content else { throw AIClientError.badResponse }
        let usage = TokenUsage(input: decoded.usage?.prompt_tokens ?? TokenEstimator.roughCount(messages.map(\.content).joined(separator: "\n")), output: decoded.usage?.completion_tokens ?? TokenEstimator.roughCount(text))
        return AITextResponse(text: text, tokenUsage: usage)
    }

    func completeVision(baseURL: String, apiKey: String, model: String, prompt: String, imageBase64: String, maxTokens: Int, temperature: Double, timeoutSeconds: Int) async throws -> AITextResponse {
        guard !apiKey.isEmpty else { throw AIClientError.emptyAPIKey }
        guard let url = URL(string: normalized(baseURL) + "/chat/completions") else { throw AIClientError.invalidBaseURL }
        var request = URLRequest(url: url, timeoutInterval: TimeInterval(timeoutSeconds))
        request.httpMethod = "POST"
        request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        let payload: [String: Any] = [
            "model": model,
            "max_tokens": maxTokens,
            "temperature": temperature,
            "messages": [[
                "role": "user",
                "content": [
                    ["type": "text", "text": prompt],
                    ["type": "image_url", "image_url": ["url": "data:image/jpeg;base64,\(imageBase64)"]]
                ]
            ]]
        ]
        request.httpBody = try JSONSerialization.data(withJSONObject: payload)
        let (data, response) = try await URLSession.shared.data(for: request)
        guard (response as? HTTPURLResponse)?.statusCode ?? 500 < 400 else {
            let body = String(data: data, encoding: .utf8) ?? ""
            throw NSError(domain: "AIClient", code: 2, userInfo: [NSLocalizedDescriptionKey: "图片理解接口请求失败：\(body)"])
        }
        let decoded = try JSONDecoder().decode(ChatCompletionResponse.self, from: data)
        let text = decoded.choices.first?.message.content ?? ""
        let usage = TokenUsage(input: decoded.usage?.prompt_tokens ?? TokenEstimator.roughCount(prompt) + 1200, output: decoded.usage?.completion_tokens ?? TokenEstimator.roughCount(text))
        return AITextResponse(text: text, tokenUsage: usage)
    }

    private func normalized(_ baseURL: String) -> String {
        baseURL.trimmingCharacters(in: .whitespacesAndNewlines).trimmingCharacters(in: CharacterSet(charactersIn: "/"))
    }
}

private struct ChatCompletionRequest: Codable {
    var model: String
    var messages: [AIMessage]
    var max_tokens: Int
    var temperature: Double
    var stream: Bool
}

private struct ChatCompletionResponse: Decodable {
    struct Choice: Decodable {
        struct Message: Decodable { let role: String?; let content: String }
        let message: Message
    }
    struct Usage: Decodable {
        let prompt_tokens: Int?
        let completion_tokens: Int?
        let total_tokens: Int?
    }
    let choices: [Choice]
    let usage: Usage?
}
