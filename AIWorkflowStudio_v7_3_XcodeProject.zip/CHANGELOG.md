# CHANGELOG

## v7.3 (Build 64)

### 修复
- 修复 `WorkflowEngine.swift` 中代码工作者系统提示词的 Swift 字符串转义错误。
- 修复 Xcode 构建报错：`cannot convert return expression of type ClosedRange<String> to return type String`。
- 将包含 `file path="..."` 示例的系统提示词改为 Swift raw string，避免双引号被误解析。

### 检查
- 已根据上传的 Build Logs 定位到 `WorkflowEngine.swift:676`。
- 已检查 `Info.plist` 版本号。
- 已检查 ZIP 完整性。

# AI Workflow Studio Changelog

## v7.2 / Build 63

### Fixed
- Removed the hard-coded "stop after 3 returns" reviewer loop protection.
- A return/rework loop now stops only when the target module has a user-configured maximum return count greater than 0.
- `maxReturnCount = 0` and `retryLimit = 0` are respected as infinite rework.
- The general loop reference limit now writes a warning log only; it no longer fails the workflow by itself.
- Removed v7.1 hard-coded minimum token floors for code worker, formatter, packager, and reviewers.

### Changed
- Token output limit now respects the module/user setting exactly.
- Logs now explicitly state whether rework is infinite or limited by user configuration.

### Notes
- If a user wants automatic stop protection, set a module's maximum return count to a value greater than 0.
- If the value remains 0, the workflow continues until manually stopped, cancelled, or a real upstream/API error occurs.
