# AI Workflow Studio v7.3 / Build 64

## 本版修改

本版用于修复 v7.2 的 Xcode 构建失败。

## 修复内容

- 修复 `WorkflowEngine.swift` 第 676 行字符串转义问题。
- 原因：普通 Swift 字符串里包含 `path="..."` 示例，内部双引号导致 Swift 将 `...` 解析成 `ClosedRange<String>`。
- 处理：改用 Swift raw string。

## 未改动

- 没有修改运行逻辑。
- 没有修改返工次数逻辑。
- 没有修改 Token 上限逻辑。

## 检查

- ZIP 完整性 OK。
- `Info.plist`：7.3 / Build 64。
- 已针对上传的 Build Logs 定位并修复真实编译错误。
