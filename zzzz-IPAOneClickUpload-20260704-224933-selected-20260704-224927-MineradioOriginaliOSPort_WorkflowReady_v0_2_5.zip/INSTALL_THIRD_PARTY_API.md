# Mineradio iOS API 连接说明

## 推荐方式：运行原 Mineradio 后端

iOS App 视觉层运行原 `public/index.html`，但登录、搜索、播放链接、歌词等功能仍需要原项目的 `/api/...` 后端。

原项目后端是 `server.js`，内部使用 `NeteaseCloudMusicApi`。

### 1. 在电脑启动服务

```bash
git clone https://github.com/XxHuberrr/Mineradio.git
cd Mineradio
npm install
HOST=0.0.0.0 PORT=3000 node server.js
```

Windows PowerShell：

```powershell
$env:HOST="0.0.0.0"
$env:PORT="3000"
node server.js
```

### 2. 查电脑局域网 IP

Windows：

```powershell
ipconfig
```

找类似：

```text
IPv4 Address . . . . . . . . . . : 192.168.1.23
```

### 3. iPad App 里填写

点左下角：

```text
API
```

填写：

```text
http://192.168.1.23:3000
```

保存后重新点“刷新二维码”。

### 4. 如果测试失败

检查：

- iPad 和电脑是否在同一个 Wi‑Fi / Tailscale 网络。
- Windows 防火墙是否放行 Node.js / 3000 端口。
- 服务是否用 `HOST=0.0.0.0` 启动，而不是只监听 `127.0.0.1`。
- 浏览器在 iPad 上能不能打开 `http://电脑IP:3000/api/app/version`。

## 不推荐直接填普通 NeteaseCloudMusicApi

普通 `Binaryify/NeteaseCloudMusicApi` 的接口路径和返回格式与 Mineradio 原后端不完全一样。原前端期待的是：

```text
/api/login/qr/key
/api/login/qr/create
/api/login/qr/check
/api/search
/api/song/url
/api/lyric
```

所以最稳的是运行原 Mineradio 的 `server.js`。
