import SwiftUI
import UIKit

@main
struct MineradioiOSApp: App {
    var body: some Scene {
        WindowGroup {
            MineradioOriginalRootView()
                .ignoresSafeArea()
                .background(Color.black)
                .preferredColorScheme(.dark)
                .persistentSystemOverlays(.hidden)
                .onAppear {
                    UIApplication.shared.isIdleTimerDisabled = true
                }
        }
    }
}

struct MineradioOriginalRootView: View {
    var body: some View {
        MineradioWebShellView()
            .ignoresSafeArea()
            .background(Color.black)
            .statusBar(hidden: true)
    }
}
