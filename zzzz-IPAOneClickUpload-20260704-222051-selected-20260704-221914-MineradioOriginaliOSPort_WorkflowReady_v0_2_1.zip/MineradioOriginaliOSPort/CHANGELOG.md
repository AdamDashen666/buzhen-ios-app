# Changelog

## 0.2.1

- 彻底停止 SwiftUI 仿版方向。
- 改为 WKWebView 原版前端移植：构建时下载并打包 `XxHuberrr/Mineradio/public`。
- 加入 Electron `window.desktopWindow` 兼容桥，让原版桌面 shell / fullscreen 相关逻辑能走。
- 保留原版 `three.js / gsap / music-tempo / index.html` 视觉链路。
- 加入 iOS 文件选择桥，兼容原版 `<input type="file">` 导入音乐 / 封面。
- `/api/...` 请求桥接到可配置 API Base，默认 `http://127.0.0.1:3000`。

## 0.1.4

- 旧 SwiftUI 仿版，已废弃。

## v0.2.1 - Build syntax fix

- Fixed Swift raw string terminator in `ContentView.swift` (`#"""` now closes with `"""#`).
- No visual/UI changes. Original Mineradio WebView migration direction remains unchanged.
