# Image2Forge

一个 SwiftUI iOS/iPadOS Xcode Project，用来调用 OpenAI-compatible 图片生成接口，默认面向 APIYI 的 `gpt-image-2-vip`。

## 已内置

- 默认 Base URL：`https://api.apiyi.com/v1`
- 默认模型：`gpt-image-2-vip`
- 支持刷新模型：`GET {baseURL}/models`
- 支持文生图：`POST {baseURL}/images/generations`
- 支持上传参考图 / 图片编辑：`POST {baseURL}/images/edits`
- 支持 1K / 2K / 4K 预设尺寸，包含 4K：`3840x2160`、`2160x3840`、`2880x2880` 等
- 支持自动适配尺寸：根据第一张参考图比例自动选择 4K 横屏、竖屏、照片或方图
- 支持从相册多选图片，也支持从文件多选图片
- API Key 存 Keychain，不写进项目源码
- 生成历史自动保存到 App 文档目录，可分享、导出、保存到相册

## 使用方式

1. 用 Xcode 打开 `Image2Forge.xcodeproj`
2. 选择你的 iPhone/iPad 或模拟器
3. 如果真机运行，需要在 Signing & Capabilities 里选择自己的 Team
4. 运行 App
5. 进入「设置」输入 API Key
6. 点「刷新模型」查看可用模型
7. 回到「生成」输入提示词，选择分辨率，开始生成

## 推荐设置

- 想要便宜 4K：选择 `gpt-image-2-vip`
- 4K 横屏：`3840x2160`
- 4K 竖屏：`2160x3840`
- 普通社媒：2K 通常更稳定

## 注意

- `gpt-image-2-vip` 的图片编辑/参考图模式可能比纯文生图更依赖 APIYI 当前接口支持情况，如果 `/images/edits` 返回错误，可先用文生图模式测试。
- `gpt-image-2-all` 可能不能稳定锁定 `size`，不建议作为 4K 固定输出首选。
- 4K 输出大图可能等待更久，App 默认超时 180 秒，可在设置里调到 600 秒。

## v1.1 构建修复说明

如果自动打包脚本提示 `No shared scheme found` 或 `project is damaged`，请使用本版本。已加入共享 Scheme：`Image2Forge`。

Xcode 打开：`Image2Forge.xcodeproj`  
Scheme 选择：`Image2Forge`  
默认 Base URL：`https://api.apiyi.com/v1`


## v1.2 任务队列
- 点击开始生成后，先创建本地任务，再后台提交到 API。
- 支持多任务并行（默认最多 3 个），不会因为一个任务生成中就堵住其他任务。
- 任务列表会显示排队中 / 生成中 / 已完成 / 失败 / 已取消。
- 完成后提供保存和“下载 / 分享”入口。


## v1.3 上传图 4K 说明
APIYI 文档写明 gpt-image-2-vip 支持 size 锁定 4K，但 quality 参数不支持。App 会自动过滤不兼容参数。
如果上传图片后第三方接口实际只返回 1MP，开启“严格导出所选尺寸”后，App 会把最终保存/分享的文件补齐到请求尺寸，并显示“API 原生返回尺寸”和“导出尺寸”。
注意：本地补齐只能保证文件像素尺寸，不等于 API 原生 4K 细节。真正稳定原生 4K 图生图仍建议使用官方 gpt-image-2 或 APIYI 企业分组。

## v1.4 UI 方向
- 后续这个项目默认按 iOS 27 液态玻璃视觉方向做。
- 优先使用系统玻璃 API、Material fallback、响应式宽度、非线性弹簧动画。
- UI 目标：更像系统原生 App，而不是简单表单页面。


## v1.5 构建兼容说明
当前 IPA Builder 使用 Xcode 16.4 / iOS 18.5 SDK，暂时不能直接编译 iOS 27 SDK 的 GlassEffectContainer / glassEffect 符号。本版本改为自定义兼容玻璃层，保留接近 Liquid Glass 的 UI 和非线性动画。

## GitHub Actions newest SDK build

v1.6 includes a GitHub Actions workflow at:

`.github/workflows/ios-newest-xcode-build.yml`

It tries to use the newest GitHub macOS runner and selects the newest installed Xcode before building. This is the correct way to make GitHub builds recognize newer Apple APIs, but it still depends on GitHub actually providing a runner with the required SDK.
