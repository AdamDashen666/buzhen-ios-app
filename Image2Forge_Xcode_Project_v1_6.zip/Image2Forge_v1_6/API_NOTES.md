# API Notes

## Base URL

默认：

```text
https://api.apiyi.com/v1
```

App 会自动去掉末尾 `/`，再拼接：

```text
/models
/images/generations
/images/edits
```

## 文生图 JSON 示例

```json
{
  "model": "gpt-image-2-vip",
  "prompt": "A cinematic city street after rain...",
  "size": "3840x2160",
  "n": 1
}
```

## 参考图 / 编辑模式

App 使用 multipart/form-data：

- `model`
- `prompt`
- `size`
- `n`
- `image` 或多图 `image[]`

## 返回解析

App 同时兼容：

- `data[0].url`
- `data[0].b64_json`
- `data[0].revised_prompt`

## 4K 预设

- `3840x2160`：16:9 横屏 4K
- `2160x3840`：9:16 竖屏 4K
- `2880x2880`：1:1 方图 4K，约 8.29MP
- `3520x2336`：3:2 照片 4K
- `2336x3520`：2:3 海报 4K


## v1.3 API 兼容处理
- gpt-image-2-vip / gpt-image-2-all: 不发送 quality。
- gpt-image-2-vip / gpt-image-2-all: 不发送 n。
- 图片编辑上传: 参考图统一压缩为 JPEG，目标单张 <= 1.5MB。
- b64_json: 支持带 data URL 前缀的返回。
