# GitHub Actions / New Apple SDK Notes

This project includes `.github/workflows/ios-newest-xcode-build.yml`.

What it does:

- Runs on `macos-26` first.
- Selects the newest installed Xcode it can find.
- Prints the selected Xcode and iPhoneOS SDK version.
- Builds the app without code signing.

Important:

- A workflow file cannot magically make old Xcode understand new Apple APIs.
- New APIs compile only when the GitHub runner actually has the matching Xcode / iPhoneOS SDK installed.
- If `macos-26` is unavailable in your GitHub account, change `runs-on: macos-26` to `macos-latest`, or use a self-hosted Mac runner with the required Xcode installed.
- Real iOS 27 / Liquid Glass APIs should only be enabled when the selected SDK contains them.

Recommended setup:

1. Push this project to GitHub.
2. Go to Actions.
3. Run **iOS Build - Newest Xcode SDK** manually.
4. Check the log lines:
   - `xcodebuild -version`
   - `xcrun --sdk iphoneos --show-sdk-version`
5. If the SDK is still old, the only real fix is changing the runner or installing newer Xcode on a self-hosted runner.
