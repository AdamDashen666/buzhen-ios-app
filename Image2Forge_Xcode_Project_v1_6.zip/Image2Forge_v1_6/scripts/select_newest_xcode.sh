#!/bin/bash
set -euo pipefail

echo "== Available Xcodes =="
find /Applications -maxdepth 1 -name 'Xcode*.app' -print | sort || true

pick_xcode() {
  # Prefer future/new SDK toolchains first. These names cover common GitHub runner naming patterns.
  local candidates=(
    /Applications/Xcode_27*.app
    /Applications/Xcode-27*.app
    /Applications/Xcode_26*.app
    /Applications/Xcode-26*.app
    /Applications/Xcode.app
  )

  for pattern in "${candidates[@]}"; do
    for app in $pattern; do
      if [ -d "$app/Contents/Developer" ]; then
        echo "$app/Contents/Developer"
        return 0
      fi
    done
  done

  # Fallback: newest visible Xcode by version-ish name.
  local newest
  newest=$(find /Applications -maxdepth 1 -name 'Xcode*.app' -print | sort -V | tail -n 1 || true)
  if [ -n "$newest" ] && [ -d "$newest/Contents/Developer" ]; then
    echo "$newest/Contents/Developer"
    return 0
  fi

  echo "No Xcode found" >&2
  return 1
}

DEVELOPER_DIR_PATH="$(pick_xcode)"
echo "Selecting: $DEVELOPER_DIR_PATH"
sudo xcode-select -s "$DEVELOPER_DIR_PATH"

echo "== Selected Xcode =="
xcodebuild -version

echo "== iPhoneOS SDK =="
SDK_VERSION="$(xcrun --sdk iphoneos --show-sdk-version)"
echo "$SDK_VERSION"

SDK_MAJOR="${SDK_VERSION%%.*}"
if [[ "$SDK_MAJOR" =~ ^[0-9]+$ ]] && [ "$SDK_MAJOR" -lt 26 ]; then
  echo "::warning::Selected iPhoneOS SDK is $SDK_VERSION. Real new Apple UI APIs will not compile until the runner has a newer SDK."
fi
