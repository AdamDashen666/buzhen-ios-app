import SwiftUI
import UIKit

struct HistoryView: View {
    @EnvironmentObject private var historyStore: HistoryStore
    @State private var showClearConfirm = false

    var body: some View {
        NavigationStack {
            PageScaffold(maxReadableWidth: 820) {
                if historyStore.records.isEmpty {
                    CardView {
                        ContentUnavailableView("暂无历史", systemImage: "photo.stack", description: Text("生成完成后会自动保存到这里，可分享或导出。"))
                            .frame(maxWidth: .infinity, minHeight: 240)
                    }
                } else {
                    ForEach(historyStore.records) { record in
                        NavigationLink {
                            HistoryDetailView(record: record)
                        } label: {
                            HistoryRow(record: record)
                        }
                        .buttonStyle(.plain)
                        .contextMenu {
                            ShareLink(item: record.fileURL) {
                                Label("分享 / 导出", systemImage: "square.and.arrow.up")
                            }
                            Button(role: .destructive) {
                                historyStore.delete(record)
                            } label: {
                                Label("删除", systemImage: "trash")
                            }
                        }
                    }
                }
            }
            .navigationTitle("历史")
            .toolbar {
                if !historyStore.records.isEmpty {
                    Button("清空", role: .destructive) { showClearConfirm = true }
                }
            }
            .confirmationDialog("确定清空所有历史图片？", isPresented: $showClearConfirm, titleVisibility: .visible) {
                Button("清空", role: .destructive) { historyStore.clear() }
                Button("取消", role: .cancel) {}
            }
            .animation(.spring(response: 0.46, dampingFraction: 0.74), value: historyStore.records)
        }
    }
}

struct HistoryRow: View {
    let record: GeneratedImageRecord

    var body: some View {
        HStack(spacing: 14) {
            if let image = UIImage(contentsOfFile: record.fileURL.path) {
                Image(uiImage: image)
                    .resizable()
                    .scaledToFill()
                    .frame(width: 82, height: 82)
                    .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
                    .shadow(color: .black.opacity(0.08), radius: 12, x: 0, y: 6)
            } else {
                RoundedRectangle(cornerRadius: 20, style: .continuous)
                    .fill(.secondary.opacity(0.15))
                    .frame(width: 82, height: 82)
                    .overlay(Image(systemName: "photo"))
            }

            VStack(alignment: .leading, spacing: 7) {
                Text(record.prompt)
                    .font(.headline)
                    .lineLimit(2)
                HStack {
                    PillLabel(title: record.model, systemImage: "cpu")
                    PillLabel(title: record.pixelSummary, systemImage: "rectangle.compress.vertical")
                }
                Text("请求 \(record.size) · \(record.createdAt.formatted(date: .abbreviated, time: .shortened))")
                    .font(.caption2)
                    .foregroundStyle(.secondary)
            }
            Spacer()
            Image(systemName: "chevron.right")
                .font(.caption.weight(.bold))
                .foregroundStyle(.secondary)
        }
        .padding(14)
        .liquidGlassSurface(cornerRadius: 26, interactive: true)
        .transition(.scale(scale: 0.985).combined(with: .opacity))
    }
}

struct HistoryDetailView: View {
    let record: GeneratedImageRecord

    var body: some View {
        PageScaffold(maxReadableWidth: 900) {
            if let image = UIImage(contentsOfFile: record.fileURL.path) {
                Image(uiImage: image)
                    .resizable()
                    .scaledToFit()
                    .clipShape(RoundedRectangle(cornerRadius: 28, style: .continuous))
                    .shadow(color: .black.opacity(0.12), radius: 24, x: 0, y: 14)

                ResponsiveButtonStack {
                    Button {
                        UIImageWriteToSavedPhotosAlbum(image, nil, nil, nil)
                    } label: {
                        Label("保存到相册", systemImage: "square.and.arrow.down")
                    }
                    .buttonStyle(LiquidGlassButtonStyle())

                    ShareLink(item: record.fileURL) {
                        Label("分享 / 导出", systemImage: "square.and.arrow.up")
                    }
                    .buttonStyle(LiquidGlassButtonStyle(prominent: true))
                }
            }

            CardView {
                VStack(alignment: .leading, spacing: 8) {
                    Text("提示词")
                        .font(.headline)
                    Text(record.prompt)
                        .textSelection(.enabled)
                }
            }

            CardView {
                VStack(alignment: .leading, spacing: 8) {
                    Text("参数")
                        .font(.headline)
                    Text("模型：\(record.model)")
                    Text("请求尺寸：\(record.size)")
                    Text("实际像素：\(record.pixelSummary)")
                    if let note = record.postprocessNote, !note.isEmpty {
                        Text("尺寸处理：\(note)")
                    }
                    Text("时间：\(record.createdAt.formatted())")
                }
            }

            if let revised = record.revisedPrompt, !revised.isEmpty {
                CardView {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Revised prompt")
                            .font(.headline)
                        Text(revised)
                            .textSelection(.enabled)
                    }
                }
            }
        }
        .navigationTitle("详情")
        .navigationBarTitleDisplayMode(.inline)
    }
}
