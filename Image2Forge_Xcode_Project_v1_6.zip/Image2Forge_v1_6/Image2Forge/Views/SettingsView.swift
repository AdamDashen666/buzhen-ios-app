import SwiftUI

struct SettingsView: View {
    @EnvironmentObject private var settings: AppSettings
    @State private var isRefreshing = false
    @State private var statusText = ""
    @State private var alertMessage: String?

    private let client = APIClient()

    var body: some View {
        NavigationStack {
            PageScaffold(maxReadableWidth: 760) {
                apiCard
                modelCard
                compatibilityCard
                notesCard
            }
            .navigationTitle("设置")
            .alert("提示", isPresented: Binding(get: { alertMessage != nil }, set: { if !$0 { alertMessage = nil } })) {
                Button("好", role: .cancel) { alertMessage = nil }
            } message: {
                Text(alertMessage ?? "")
            }
        }
    }

    private var apiCard: some View {
        CardView {
            VStack(alignment: .leading, spacing: 14) {
                Label("API 配置", systemImage: "key.viewfinder")
                    .font(.headline)

                VStack(spacing: 10) {
                    TextField("Base URL", text: $settings.baseURL)
                        .keyboardType(.URL)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .padding(14)
                        .liquidGlassSurface(cornerRadius: 18, interactive: true)

                    SecureField("API Key", text: $settings.apiKey)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .padding(14)
                        .liquidGlassSurface(cornerRadius: 18, interactive: true)
                }

                ResponsiveButtonStack {
                    Button {
                        Task { await refreshModels() }
                    } label: {
                        if isRefreshing {
                            Label("刷新中...", systemImage: "arrow.clockwise")
                        } else {
                            Label("刷新模型", systemImage: "arrow.clockwise")
                        }
                    }
                    .buttonStyle(LiquidGlassButtonStyle(prominent: true))
                    .disabled(isRefreshing || settings.apiKey.isEmpty || settings.baseURL.isEmpty)

                    Button {
                        settings.useFallbackModels()
                        statusText = "已载入默认模型列表"
                    } label: {
                        Label("恢复默认", systemImage: "arrow.uturn.backward")
                    }
                    .buttonStyle(LiquidGlassButtonStyle())
                }

                if !statusText.isEmpty {
                    Text(statusText)
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                        .transition(.opacity.combined(with: .move(edge: .top)))
                }
            }
            .animation(.spring(response: 0.42, dampingFraction: 0.72), value: statusText)
        }
    }

    private var modelCard: some View {
        CardView {
            VStack(alignment: .leading, spacing: 14) {
                Label("选择模型", systemImage: "cpu")
                    .font(.headline)

                Picker("当前模型", selection: $settings.selectedModel) {
                    ForEach(settings.availableModels) { model in
                        Text(model.id).tag(model.id)
                    }
                }
                .pickerStyle(.navigationLink)

                LazyVStack(spacing: 10) {
                    ForEach(settings.availableModels) { model in
                        Button {
                            withAnimation(.spring(response: 0.34, dampingFraction: 0.66)) {
                                settings.selectedModel = model.id
                            }
                        } label: {
                            HStack(alignment: .center, spacing: 12) {
                                Image(systemName: model.id == settings.selectedModel ? "checkmark.circle.fill" : "circle")
                                    .font(.title3)
                                    .foregroundStyle(model.id == settings.selectedModel ? Color.accentColor : .secondary)
                                    .contentTransition(.symbolEffect(.replace))
                                VStack(alignment: .leading, spacing: 4) {
                                    Text(model.id)
                                        .fontWeight(model.id == settings.selectedModel ? .bold : .regular)
                                    if let ownedBy = model.ownedBy, !ownedBy.isEmpty {
                                        Text(ownedBy)
                                            .font(.caption)
                                            .foregroundStyle(.secondary)
                                    }
                                }
                                Spacer()
                            }
                            .padding(12)
                            .liquidGlassSurface(cornerRadius: 18, interactive: true)
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
        }
    }

    private var compatibilityCard: some View {
        CardView {
            VStack(alignment: .leading, spacing: 14) {
                Label("兼容选项", systemImage: "slider.horizontal.3")
                    .font(.headline)

                Toggle("优先请求 b64_json 返回", isOn: $settings.preferB64JSON)
                    .padding(12)
                    .liquidGlassSurface(cornerRadius: 18, interactive: true)

                Toggle("发送 quality 参数", isOn: $settings.sendQualityParameter)
                    .padding(12)
                    .liquidGlassSurface(cornerRadius: 18, interactive: true)

                Toggle("严格导出所选尺寸", isOn: $settings.forceMatchOutputSize)
                    .padding(12)
                    .liquidGlassSurface(cornerRadius: 18, interactive: true)

                VStack(alignment: .leading, spacing: 8) {
                    HStack {
                        Text("超时秒数")
                        Spacer()
                        Text("\(Int(settings.timeoutSeconds))s")
                            .foregroundStyle(.secondary)
                            .contentTransition(.numericText())
                    }
                    Slider(value: $settings.timeoutSeconds, in: 60...600, step: 30)
                }
                .padding(12)
                .liquidGlassSurface(cornerRadius: 18, interactive: true)

                Text("gpt-image-2-vip / all 文档写明不支持 quality；即使这里打开，App 也会对这两个模型自动不发送，避免接口降级或忽略 size。")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
                Text("严格导出所选尺寸：如果上传图片后 API 原生只回 1MP，App 会检测实际像素，并本地补齐到你选择的 4K/2K 尺寸；任务状态会标明是否补齐。")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
            }
        }
    }

    private var notesCard: some View {
        CardView {
            VStack(alignment: .leading, spacing: 10) {
                Label("默认说明", systemImage: "info.circle")
                    .font(.headline)
                Text("默认 Base URL 已写入：https://api.apiyi.com/v1")
                Text("推荐模型：gpt-image-2-vip；4K 横屏尺寸：3840x2160。")
                Text("UI 已按 iOS 27 风格重做：液态玻璃卡片、响应式宽度、非线性弹簧动画。")
                    .foregroundStyle(.secondary)
            }
            .font(.footnote)
        }
    }

    private func refreshModels() async {
        guard !settings.apiKey.isEmpty else {
            alertMessage = "请先输入 API Key。"
            return
        }
        isRefreshing = true
        statusText = "正在请求 \(settings.normalizedBaseURL())/models"
        defer { isRefreshing = false }

        do {
            let models = try await client.refreshModels(baseURL: settings.normalizedBaseURL(), apiKey: settings.apiKey, timeout: settings.timeoutSeconds)
            settings.availableModels = models
            if !models.contains(where: { $0.id == settings.selectedModel }) {
                settings.selectedModel = models.first?.id ?? "gpt-image-2-vip"
            }
            statusText = "刷新成功：\(models.count) 个模型"
        } catch {
            statusText = "刷新失败，保留原模型列表"
            alertMessage = error.localizedDescription
        }
    }
}
