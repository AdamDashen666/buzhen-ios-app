import Foundation
import Combine
import UIKit

@MainActor
final class HistoryStore: ObservableObject {
    @Published var records: [GeneratedImageRecord] = []

    private let key = "generatedImageRecords"

    func load() {
        guard let data = UserDefaults.standard.data(forKey: key),
              let decoded = try? JSONDecoder().decode([GeneratedImageRecord].self, from: data) else {
            records = []
            return
        }
        records = decoded.filter { FileManager.default.fileExists(atPath: $0.fileURL.path) }
    }

    func add(imageData: Data, prompt: String, model: String, size: String, revisedPrompt: String?, postprocessNote: String? = nil) throws -> GeneratedImageRecord {
        let id = UUID()
        let fileName = "image2forge_\(id.uuidString).png"
        let url = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent(fileName)
        try imageData.write(to: url, options: [.atomic])
        let pixelSize = ImageOutputTools.pixelSize(of: imageData)
        let record = GeneratedImageRecord(
            id: id,
            createdAt: Date(),
            prompt: prompt,
            model: model,
            size: size,
            fileName: fileName,
            revisedPrompt: revisedPrompt,
            pixelWidth: pixelSize?.width,
            pixelHeight: pixelSize?.height,
            postprocessNote: postprocessNote
        )
        records.insert(record, at: 0)
        save()
        return record
    }

    func delete(_ record: GeneratedImageRecord) {
        try? FileManager.default.removeItem(at: record.fileURL)
        records.removeAll { $0.id == record.id }
        save()
    }

    func clear() {
        for record in records {
            try? FileManager.default.removeItem(at: record.fileURL)
        }
        records.removeAll()
        save()
    }

    private func save() {
        if let data = try? JSONEncoder().encode(records) {
            UserDefaults.standard.set(data, forKey: key)
        }
    }
}
