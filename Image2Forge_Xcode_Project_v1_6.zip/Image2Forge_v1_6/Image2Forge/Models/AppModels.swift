import Foundation
import UIKit

struct APIModel: Identifiable, Hashable, Codable {
    let id: String
    var ownedBy: String?
}

struct OpenAIModelListResponse: Decodable {
    let data: [OpenAIModel]
}

struct OpenAIModel: Decodable {
    let id: String
    let owned_by: String?
}

struct APIErrorResponse: Decodable, Error {
    let error: APIErrorDetail?

    var message: String {
        error?.message ?? "未知 API 错误"
    }
}

struct APIErrorDetail: Decodable {
    let message: String?
    let type: String?
    let code: String?
}

struct ImageAPIResponse: Decodable {
    let data: [ImageAPIData]?
    let error: APIErrorDetail?
}

struct ImageAPIData: Decodable {
    let url: String?
    let b64_json: String?
    let revised_prompt: String?
}

struct GeneratedImageRecord: Identifiable, Codable, Hashable {
    let id: UUID
    let createdAt: Date
    let prompt: String
    let model: String
    let size: String
    let fileName: String
    let revisedPrompt: String?
    var pixelWidth: Int? = nil
    var pixelHeight: Int? = nil
    var postprocessNote: String? = nil

    var fileURL: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            .appendingPathComponent(fileName)
    }

    var pixelSummary: String {
        guard let pixelWidth, let pixelHeight else { return "未知像素" }
        let mp = Double(pixelWidth * pixelHeight) / 1_000_000.0
        return "\(pixelWidth)x\(pixelHeight) · \(String(format: "%.2f", mp))MP"
    }
}

enum GenerationMode: String, CaseIterable, Identifiable {
    case textToImage = "文生图"
    case imageEdit = "参考图 / 图片编辑"

    var id: String { rawValue }
}

enum ImageQuality: String, CaseIterable, Identifiable {
    case auto = "auto"
    case low = "low"
    case medium = "medium"
    case high = "high"

    var id: String { rawValue }

    var title: String {
        switch self {
        case .auto: return "自动 / 不发送"
        case .low: return "Low"
        case .medium: return "Medium"
        case .high: return "High"
        }
    }
}

struct ImageSizePreset: Identifiable, Hashable {
    let id: String
    let title: String
    let size: String?
    let ratio: String
    let tier: String

    var displayTitle: String {
        if let size {
            return "\(title) · \(size)"
        }
        return title
    }

    static let auto = ImageSizePreset(id: "auto", title: "自动适配", size: nil, ratio: "Auto", tier: "Auto")

    static let presets: [ImageSizePreset] = [
        .auto,
        ImageSizePreset(id: "4k_16_9", title: "4K 横屏 16:9", size: "3840x2160", ratio: "16:9", tier: "4K"),
        ImageSizePreset(id: "4k_9_16", title: "4K 竖屏 9:16", size: "2160x3840", ratio: "9:16", tier: "4K"),
        ImageSizePreset(id: "4k_square", title: "4K 方图 1:1", size: "2880x2880", ratio: "1:1", tier: "4K"),
        ImageSizePreset(id: "4k_3_2", title: "4K 照片 3:2", size: "3520x2336", ratio: "3:2", tier: "4K"),
        ImageSizePreset(id: "4k_2_3", title: "4K 海报 2:3", size: "2336x3520", ratio: "2:3", tier: "4K"),
        ImageSizePreset(id: "4k_4_3", title: "4K 标准 4:3", size: "3312x2480", ratio: "4:3", tier: "4K"),
        ImageSizePreset(id: "4k_3_4", title: "4K 竖图 3:4", size: "2480x3312", ratio: "3:4", tier: "4K"),
        ImageSizePreset(id: "4k_4_5", title: "4K 社媒 4:5", size: "2560x3216", ratio: "4:5", tier: "4K"),
        ImageSizePreset(id: "4k_5_4", title: "4K 中画幅 5:4", size: "3216x2560", ratio: "5:4", tier: "4K"),
        ImageSizePreset(id: "4k_21_9", title: "4K 宽银幕 21:9", size: "3840x1632", ratio: "21:9", tier: "4K"),
        ImageSizePreset(id: "2k_16_9", title: "2K 横屏 16:9", size: "2048x1152", ratio: "16:9", tier: "2K"),
        ImageSizePreset(id: "2k_9_16", title: "2K 竖屏 9:16", size: "1152x2048", ratio: "9:16", tier: "2K"),
        ImageSizePreset(id: "2k_square", title: "2K 方图 1:1", size: "2048x2048", ratio: "1:1", tier: "2K"),
        ImageSizePreset(id: "2k_3_2", title: "2K 照片 3:2", size: "2048x1360", ratio: "3:2", tier: "2K"),
        ImageSizePreset(id: "2k_2_3", title: "2K 海报 2:3", size: "1360x2048", ratio: "2:3", tier: "2K"),
        ImageSizePreset(id: "2k_4_3", title: "2K 标准 4:3", size: "2048x1536", ratio: "4:3", tier: "2K"),
        ImageSizePreset(id: "2k_3_4", title: "2K 竖图 3:4", size: "1536x2048", ratio: "3:4", tier: "2K"),
        ImageSizePreset(id: "2k_4_5", title: "2K 社媒 4:5", size: "1632x2048", ratio: "4:5", tier: "2K"),
        ImageSizePreset(id: "2k_5_4", title: "2K 中画幅 5:4", size: "2048x1632", ratio: "5:4", tier: "2K"),
        ImageSizePreset(id: "2k_21_9", title: "2K 宽银幕 21:9", size: "2048x864", ratio: "21:9", tier: "2K"),
        ImageSizePreset(id: "1k_16_9", title: "1K 横屏 16:9", size: "1280x720", ratio: "16:9", tier: "1K"),
        ImageSizePreset(id: "1k_9_16", title: "1K 竖屏 9:16", size: "720x1280", ratio: "9:16", tier: "1K"),
        ImageSizePreset(id: "1k_square", title: "1K 方图 1:1", size: "1280x1280", ratio: "1:1", tier: "1K"),
        ImageSizePreset(id: "1k_3_2", title: "1K 照片 3:2", size: "1280x848", ratio: "3:2", tier: "1K"),
        ImageSizePreset(id: "1k_2_3", title: "1K 海报 2:3", size: "848x1280", ratio: "2:3", tier: "1K"),
        ImageSizePreset(id: "1k_4_3", title: "1K 标准 4:3", size: "1280x960", ratio: "4:3", tier: "1K"),
        ImageSizePreset(id: "1k_3_4", title: "1K 竖图 3:4", size: "960x1280", ratio: "3:4", tier: "1K"),
        ImageSizePreset(id: "1k_4_5", title: "1K 社媒 4:5", size: "1024x1280", ratio: "4:5", tier: "1K"),
        ImageSizePreset(id: "1k_5_4", title: "1K 中画幅 5:4", size: "1280x1024", ratio: "5:4", tier: "1K"),
        ImageSizePreset(id: "1k_21_9", title: "1K 宽银幕 21:9", size: "1280x544", ratio: "21:9", tier: "1K")
    ]
}

struct SelectedReferenceImage: Identifiable, Hashable {
    let id = UUID()
    let data: Data
    let fileName: String

    var uiImage: UIImage? { UIImage(data: data) }
    var aspectRatio: CGFloat? {
        guard let image = uiImage, image.size.height > 0 else { return nil }
        return image.size.width / image.size.height
    }
}


enum ImageOutputTools {
    static func pixelSize(of data: Data) -> (width: Int, height: Int)? {
        guard let image = UIImage(data: data), let cgImage = image.cgImage else { return nil }
        return (cgImage.width, cgImage.height)
    }

    static func targetPixelSize(from size: String) -> (width: Int, height: Int)? {
        let parts = size.lowercased().split(separator: "x")
        guard parts.count == 2,
              let width = Int(parts[0]),
              let height = Int(parts[1]),
              width > 0,
              height > 0 else { return nil }
        return (width, height)
    }

    static func ensureTargetSizeIfNeeded(_ data: Data, targetSize: String, enabled: Bool) -> (data: Data, note: String?) {
        guard enabled,
              let target = targetPixelSize(from: targetSize),
              let source = pixelSize(of: data),
              source.width != target.width || source.height != target.height,
              target.width > 0,
              target.height > 0,
              let image = UIImage(data: data) else {
            return (data, nil)
        }

        let targetPixels = target.width * target.height
        let sourcePixels = source.width * source.height
        guard targetPixels > sourcePixels else {
            return (data, "API 返回尺寸为 \(source.width)x\(source.height)，与请求 \(target.width)x\(target.height) 不一致，已保留原始返回。")
        }

        let format = UIGraphicsImageRendererFormat()
        format.scale = 1
        format.opaque = true
        let targetCGSize = CGSize(width: CGFloat(target.width), height: CGFloat(target.height))
        let renderer = UIGraphicsImageRenderer(size: targetCGSize, format: format)
        let outputImage = renderer.image { _ in
            UIColor.black.setFill()
            UIBezierPath(rect: CGRect(origin: .zero, size: targetCGSize)).fill()
            image.draw(in: CGRect(origin: .zero, size: targetCGSize))
        }

        guard let pngData = outputImage.pngData() else {
            return (data, "API 返回 \(source.width)x\(source.height)，本地补齐到 \(target.width)x\(target.height) 失败，已保留原图。")
        }

        return (pngData, "API 原生返回 \(source.width)x\(source.height)，已本地补齐导出为 \(target.width)x\(target.height)。")
    }
}

enum GenerationTaskStatus: String, Codable {
    case queued
    case running
    case completed
    case failed
    case cancelled

    var title: String {
        switch self {
        case .queued: return "排队中"
        case .running: return "生成中"
        case .completed: return "已完成"
        case .failed: return "失败"
        case .cancelled: return "已取消"
        }
    }
}

struct GenerationTaskPayload {
    let request: APIClient.GenerationRequest
    let prompt: String
    let model: String
    let size: String
    let forceMatchOutputSize: Bool
}

struct GenerationTaskItem: Identifiable, Equatable {
    let id: UUID
    let createdAt: Date
    let prompt: String
    let model: String
    let size: String
    var status: GenerationTaskStatus
    var progress: Double
    var statusMessage: String
    var revisedPrompt: String?
    var record: GeneratedImageRecord?
    var errorMessage: String?

    init(id: UUID = UUID(), createdAt: Date = Date(), prompt: String, model: String, size: String, status: GenerationTaskStatus = .queued, progress: Double = 0.02, statusMessage: String = "已创建任务，等待开始…", revisedPrompt: String? = nil, record: GeneratedImageRecord? = nil, errorMessage: String? = nil) {
        self.id = id
        self.createdAt = createdAt
        self.prompt = prompt
        self.model = model
        self.size = size
        self.status = status
        self.progress = progress
        self.statusMessage = statusMessage
        self.revisedPrompt = revisedPrompt
        self.record = record
        self.errorMessage = errorMessage
    }
}
