import SwiftUI

@main
struct Image2ForgeApp: App {
    @StateObject private var settings = AppSettings()
    @StateObject private var historyStore = HistoryStore()
    @StateObject private var taskStore = GenerationTaskStore()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(settings)
                .environmentObject(historyStore)
                .environmentObject(taskStore)
                .task {
                    historyStore.load()
                }
        }
    }
}
