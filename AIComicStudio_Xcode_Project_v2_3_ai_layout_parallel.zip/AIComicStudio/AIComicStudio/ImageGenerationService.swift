import Foundation

@MainActor
enum ImagePromptBuilder {
    static func build(project: ComicProject, page: ComicPage, settings: APISettings) -> String {
        let characterAnchors = project.characters.map { character in
            "\(character.name): \(character.promptAnchor). Visual: \(character.visualDescription). Role: \(character.role). Outfit: \(character.outfit). Palette: \(character.colorPalette). Personality: \(character.personality)."
        }.joined(separator: "\n")

        let panels = page.panels.map { panel in
            let dialogue = panel.dialogue.map { "\($0.speaker): \"\($0.text)\" (\($0.emotion))" }.joined(separator: " | ")
            return "Panel \(panel.panelNumber): \(panel.shotType). Setting: \(panel.setting). Action: \(panel.action). Camera: \(panel.camera). Mood: \(panel.mood). Visual: \(panel.visualPrompt). Narration: \(panel.narration). Dialogue: \(dialogue)."
        }.joined(separator: "\n")

        let dialogueInstruction = settings.includeDialogueInImagePrompt ? "Include short readable speech bubbles and narration boxes exactly where useful. Keep text minimal and clean." : "Do not render readable text; leave empty speech bubble space only."

        return """
        Create one complete comic page image.
        Style: \(project.style.promptStyle).
        Page title: \(page.title).
        Page summary: \(page.summary).
        Page layout prompt: \(page.pagePrompt).
        Continuity notes: \(page.continuityNotes).

        Character consistency anchors:
        \(characterAnchors)

        Panels:
        \(panels)

        Requirements:
        - A polished full comic page with clear panel borders and readable composition.
        - Character bible lock: every named character must match the anchors exactly.
        - Keep the same identity, face shape, hairstyle, age, body shape, outfit, accessories, color palette, and expression style across all panels.
        - Do not invent new versions of existing characters. Do not change clothing unless the page explicitly says so.
        - Use cinematic manga/comic framing, expressive acting, clean linework.
        - \(dialogueInstruction)
        - No watermarks, no UI, no extra unrelated characters, no distorted hands or faces.
        """
    }

    static func buildPanel(project: ComicProject, page: ComicPage, panel: ComicPanel, settings: APISettings) -> String {
        let characterAnchors = project.characters.map { character in
            "\(character.name): \(character.promptAnchor). Visual: \(character.visualDescription). Outfit: \(character.outfit). Palette: \(character.colorPalette)."
        }.joined(separator: "\n")
        let dialogue = panel.dialogue.map { "\($0.speaker): \"\($0.text)\" (\($0.emotion))" }.joined(separator: " | ")
        let dialogueInstruction = settings.includeDialogueInImagePrompt ? "Include only short readable speech bubbles if needed." : "Do not render readable text; leave empty speech bubble space only."

        return """
        Create one single comic panel image, not a full page.
        Style: \(project.style.promptStyle).
        Page: \(page.pageNumber) - \(page.title).
        Panel \(panel.panelNumber): \(panel.shotType).
        Setting: \(panel.setting).
        Action: \(panel.action).
        Visual prompt: \(panel.visualPrompt).
        Camera: \(panel.camera).
        Mood: \(panel.mood).
        Narration: \(panel.narration).
        Dialogue: \(dialogue).
        Continuity notes: \(page.continuityNotes).

        Character bible anchors:
        \(characterAnchors)

        Requirements:
        - Keep character identity exactly consistent with the anchors.
        - Keep hairstyle, face shape, outfit, accessories, color palette, and age unchanged.
        - Only draw the characters listed for this panel when possible: \(panel.characters.joined(separator: ", ")).
        - Clean comic panel composition with no page UI and no watermark.
        - \(dialogueInstruction)
        """
    }

}

enum ImageGenerationService {
    static func generateImage(prompt: String, config: ModelEndpointConfig, imageSize: String) async throws -> Data {
        guard !config.apiKey.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            throw AppError.emptyAPIKey(config.providerName)
        }

        switch config.transport {
        case .openAIImages, .openAICompatible:
            return try await generateOpenAIImage(prompt: prompt, config: config, imageSize: imageSize)
        case .stability:
            return try await generateStabilityImage(prompt: prompt, config: config, imageSize: imageSize)
        case .replicate:
            return try await generateReplicateImage(prompt: prompt, config: config, imageSize: imageSize)
        case .fal:
            return try await generateFalImage(prompt: prompt, config: config, imageSize: imageSize)
        default:
            throw AppError.unsupportedProvider("该接口类型不能用于图片生成。")
        }
    }

    private static func generateOpenAIImage(prompt: String, config: ModelEndpointConfig, imageSize: String) async throws -> Data {
        let url = try NetworkTools.url(base: config.baseURL, path: "/images/generations")
        let finalSize = normalizedOpenAIImageSize(requested: imageSize, config: config)
        let body: [String: Any] = [
            "model": config.model,
            "prompt": prompt,
            "size": finalSize,
            "n": 1,
            "response_format": "b64_json"
        ]
        let request = NetworkTools.request(
            url: url,
            method: "POST",
            apiKey: config.apiKey,
            headers: ["Content-Type": "application/json"],
            body: try NetworkTools.jsonData(body),
            timeout: config.timeoutSeconds
        )
        let data = try await NetworkTools.perform(request)
        let json = try NetworkTools.jsonObject(from: data)
        if let b64 = NetworkTools.extractString(json, paths: [["data", "0", "b64_json"]]), let imageData = Data(base64Encoded: b64) {
            return imageData
        }
        if let urlString = NetworkTools.extractString(json, paths: [["data", "0", "url"]]), let url = URL(string: urlString) {
            return try await NetworkTools.perform(NetworkTools.request(url: url, timeout: config.timeoutSeconds))
        }
        throw AppError.missingContent("图片接口没有返回 b64_json 或 url。")
    }

    private static func generateStabilityImage(prompt: String, config: ModelEndpointConfig, imageSize: String) async throws -> Data {
        let endpoint: String
        let model = config.model.lowercased()
        if model.contains("ultra") {
            endpoint = "/v2beta/stable-image/generate/ultra"
        } else if model.contains("sd3") {
            endpoint = "/v2beta/stable-image/generate/sd3"
        } else {
            endpoint = "/v2beta/stable-image/generate/core"
        }
        let url = try NetworkTools.url(base: config.baseURL, path: endpoint)
        let boundary = "Boundary-\(UUID().uuidString)"
        var fields: [String: String] = [
            "prompt": prompt,
            "output_format": "png"
        ]
        if model.contains("sd3") { fields["model"] = config.model }
        let body = NetworkTools.multipartFormData(fields: fields, boundary: boundary)
        let request = NetworkTools.request(
            url: url,
            method: "POST",
            apiKey: config.apiKey,
            headers: [
                "Accept": "image/*",
                "Content-Type": "multipart/form-data; boundary=\(boundary)"
            ],
            body: body,
            timeout: config.timeoutSeconds
        )
        return try await NetworkTools.perform(request)
    }

    private static func generateReplicateImage(prompt: String, config: ModelEndpointConfig, imageSize: String) async throws -> Data {
        let modelPath = config.model.trimmingCharacters(in: .whitespacesAndNewlines)
        guard modelPath.contains("/") else { throw AppError.unsupportedProvider("Replicate 模型请使用 owner/name 格式。") }
        let url = try NetworkTools.url(base: config.baseURL, path: "/models/\(modelPath)/predictions")
        let body: [String: Any] = [
            "input": [
                "prompt": prompt,
                "aspect_ratio": aspectRatio(from: imageSize),
                "output_format": "png"
            ]
        ]
        let request = NetworkTools.request(url: url, method: "POST", apiKey: config.apiKey, bearerPrefix: "Token", headers: ["Content-Type": "application/json"], body: try NetworkTools.jsonData(body), timeout: config.timeoutSeconds)
        let data = try await NetworkTools.perform(request)
        let json = try NetworkTools.jsonObject(from: data)
        guard let getURLString = NetworkTools.extractString(json, paths: [["urls", "get"]]), let getURL = URL(string: getURLString) else {
            throw AppError.missingContent("Replicate 没有返回轮询 URL。")
        }

        for _ in 0..<90 {
            try await Task.sleep(nanoseconds: 2_000_000_000)
            let poll = NetworkTools.request(url: getURL, apiKey: config.apiKey, bearerPrefix: "Token", timeout: config.timeoutSeconds)
            let pollData = try await NetworkTools.perform(poll)
            let pollJSON = try NetworkTools.jsonObject(from: pollData)
            let status = NetworkTools.extractString(pollJSON, paths: [["status"]]) ?? ""
            if status == "succeeded" {
                if let outputURL = extractImageURL(fromReplicateJSON: pollJSON), let url = URL(string: outputURL) {
                    return try await NetworkTools.perform(NetworkTools.request(url: url, timeout: config.timeoutSeconds))
                }
                throw AppError.missingContent("Replicate 成功但没有图片 URL。")
            }
            if status == "failed" || status == "canceled" {
                throw AppError.badResponse(500, "Replicate status: \(status)")
            }
        }
        throw AppError.badResponse(408, "Replicate 轮询超时。")
    }

    private static func generateFalImage(prompt: String, config: ModelEndpointConfig, imageSize: String) async throws -> Data {
        let base = NetworkTools.normalizedBase(config.baseURL)
        let model = config.model.trimmingCharacters(in: .whitespacesAndNewlines)
        guard let url = URL(string: base + "/" + model) else { throw AppError.invalidURL(base + "/" + model) }
        let size = sizeDictionary(from: imageSize)
        let body: [String: Any] = [
            "prompt": prompt,
            "image_size": size,
            "num_images": 1,
            "enable_safety_checker": true,
            "output_format": "png"
        ]
        let request = NetworkTools.request(url: url, method: "POST", apiKey: config.apiKey, bearerPrefix: "Key", headers: ["Content-Type": "application/json"], body: try NetworkTools.jsonData(body), timeout: config.timeoutSeconds)
        let data = try await NetworkTools.perform(request)
        let json = try NetworkTools.jsonObject(from: data)
        let urlString = NetworkTools.extractString(json, paths: [["images", "0", "url"], ["image", "url"], ["url"]])
        guard let urlString, let imageURL = URL(string: urlString) else { throw AppError.missingContent("fal.ai 没有返回图片 URL。") }
        return try await NetworkTools.perform(NetworkTools.request(url: imageURL, timeout: config.timeoutSeconds))
    }

    private static func normalizedOpenAIImageSize(requested: String, config: ModelEndpointConfig) -> String {
        let lowerBase = config.baseURL.lowercased()
        let lowerPreset = config.presetID.lowercased()
        let lowerModel = config.model.lowercased()
        let isSeedream = lowerPreset.contains("seedream") || lowerBase.contains("volces.com") || lowerModel.contains("seedream") || lowerModel.contains("doubao-seedream")
        guard isSeedream else { return requested }

        let parts = requested.lowercased().split(separator: "x").compactMap { Int($0) }
        let width = parts.count == 2 ? parts[0] : 1024
        let height = parts.count == 2 ? parts[1] : 1536
        if width * height >= 3_686_400 { return "\(width)x\(height)" }

        let ratio = Double(width) / Double(max(height, 1))
        if ratio > 1.2 { return "2400x1536" }
        if ratio < 0.8 { return "1536x2400" }
        return "1920x1920"
    }

    private static func aspectRatio(from size: String) -> String {
        let parts = size.lowercased().split(separator: "x").compactMap { Double($0) }
        guard parts.count == 2, parts[1] != 0 else { return "2:3" }
        let ratio = parts[0] / parts[1]
        if ratio > 1.2 { return "16:9" }
        if ratio < 0.8 { return "2:3" }
        return "1:1"
    }

    private static func sizeDictionary(from size: String) -> [String: Int] {
        let parts = size.lowercased().split(separator: "x").compactMap { Int($0) }
        if parts.count == 2 { return ["width": parts[0], "height": parts[1]] }
        return ["width": 1024, "height": 1536]
    }

    private static func extractImageURL(fromReplicateJSON json: Any) -> String? {
        if let output = NetworkTools.valueAtPath(json, path: ["output"]) as? [String], let first = output.first { return first }
        if let output = NetworkTools.valueAtPath(json, path: ["output"]) as? [[String: Any]] {
            return output.compactMap { $0["url"] as? String }.first
        }
        return NetworkTools.extractString(json, paths: [["output"], ["output", "0"], ["output", "url"]])
    }
}
