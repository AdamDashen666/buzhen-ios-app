import Foundation
import SwiftUI

@MainActor
final class APISettings: ObservableObject {
    @Published var textConfig: ModelEndpointConfig = .defaultText
    @Published var imageConfig: ModelEndpointConfig = .defaultImage
    @Published var imageSize: String = "1536x2400"
    @Published var includeDialogueInImagePrompt: Bool = true
    @Published var lastRefreshMessage: String = ""
    @Published var isRefreshingTextModels: Bool = false
    @Published var isRefreshingImageModels: Bool = false

    private let saveURL: URL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent("AIComicStudioSettings.json")

    struct Persisted: Codable {
        var textConfig: ModelEndpointConfig
        var imageConfig: ModelEndpointConfig
        var imageSize: String
        var includeDialogueInImagePrompt: Bool
    }

    private func normalizeTextLimits() {
        // Keep the user's own limit as entered. Do not clamp high values here.
        // The network request layer will cap the actual request to the provider/model limit.
        if textConfig.maxTokens < 1 { textConfig.maxTokens = 12000 }
        if textConfig.timeoutSeconds < 10 { textConfig.timeoutSeconds = 10 }
    }

    func applyTextPreset(_ preset: ProviderPreset) {
        textConfig.presetID = preset.id
        textConfig.providerName = preset.name
        textConfig.transport = preset.transport
        textConfig.baseURL = preset.baseURL
        textConfig.model = preset.defaultModel
        textConfig.availableModels = preset.fallbackModels
        if preset.transport == .anthropic { textConfig.maxTokens = 12000 }
        if preset.transport == .openAICompatible { textConfig.maxTokens = 12000 }
        if preset.transport == .gemini { textConfig.maxTokens = 12000 }
        normalizeTextLimits()
        save()
    }

    func applyImagePreset(_ preset: ProviderPreset) {
        imageConfig.presetID = preset.id
        imageConfig.providerName = preset.name
        imageConfig.transport = preset.transport
        imageConfig.baseURL = preset.baseURL
        imageConfig.model = preset.defaultModel
        imageConfig.availableModels = preset.fallbackModels
        if preset.id == "volc-seedream" {
            imageSize = "1536x2400"
            imageConfig.timeoutSeconds = max(imageConfig.timeoutSeconds, 300)
        }
        save()
    }

    func refreshTextModels() async {
        isRefreshingTextModels = true
        defer { isRefreshingTextModels = false }
        do {
            let models = try await ModelListService.fetchModels(for: textConfig, fallback: TextProviderPresets.all.first(where: { $0.id == textConfig.presetID })?.fallbackModels ?? [])
            textConfig.availableModels = models
            if !models.contains(textConfig.model), let first = models.first { textConfig.model = first }
            lastRefreshMessage = "文本模型已刷新：\(models.count) 个"
            save()
        } catch {
            let fallback = TextProviderPresets.all.first(where: { $0.id == textConfig.presetID })?.fallbackModels ?? textConfig.availableModels
            if !fallback.isEmpty { textConfig.availableModels = fallback }
            lastRefreshMessage = "文本模型刷新失败，已保留/恢复内置列表：\(error.localizedDescription)"
            save()
        }
    }

    func refreshImageModels() async {
        isRefreshingImageModels = true
        defer { isRefreshingImageModels = false }
        do {
            let models = try await ModelListService.fetchModels(for: imageConfig, fallback: ImageProviderPresets.all.first(where: { $0.id == imageConfig.presetID })?.fallbackModels ?? [])
            imageConfig.availableModels = models
            if !models.contains(imageConfig.model), let first = models.first { imageConfig.model = first }
            lastRefreshMessage = "图片模型已刷新：\(models.count) 个"
            save()
        } catch {
            let fallback = ImageProviderPresets.all.first(where: { $0.id == imageConfig.presetID })?.fallbackModels ?? imageConfig.availableModels
            if !fallback.isEmpty { imageConfig.availableModels = fallback }
            lastRefreshMessage = "图片模型刷新失败，已保留/恢复内置列表：\(error.localizedDescription)"
            save()
        }
    }

    func load() {
        guard let data = try? Data(contentsOf: saveURL), let decoded = try? JSONDecoder().decode(Persisted.self, from: data) else { return }
        textConfig = decoded.textConfig
        imageConfig = decoded.imageConfig
        imageSize = decoded.imageSize
        includeDialogueInImagePrompt = decoded.includeDialogueInImagePrompt
        normalizeTextLimits()
    }

    func save() {
        normalizeTextLimits()
        let data = Persisted(textConfig: textConfig, imageConfig: imageConfig, imageSize: imageSize, includeDialogueInImagePrompt: includeDialogueInImagePrompt)
        do {
            let encoded = try JSONEncoder.pretty.encode(data)
            try encoded.write(to: saveURL, options: .atomic)
        } catch {
            lastRefreshMessage = "设置保存失败：\(error.localizedDescription)"
        }
    }
}
