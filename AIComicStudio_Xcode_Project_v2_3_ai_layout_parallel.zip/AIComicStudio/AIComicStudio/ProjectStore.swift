import Foundation
import SwiftUI

@MainActor
final class ProjectStore: ObservableObject {
    @Published var project: ComicProject = .empty
    @Published var selectedPageID: ComicPage.ID?
    @Published var logs: [String] = []
    @Published var isBusy: Bool = false

    private let saveURL: URL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent("AIComicStudioProject.json")

    func newProject() {
        project = .empty
        selectedPageID = nil
        logs.removeAll()
        log("已创建新项目。")
        save()
    }

    func loadSample() {
        project = .sample
        selectedPageID = project.pages.first?.id
        log("已载入示例项目。")
        save()
    }

    func load() {
        guard let data = try? Data(contentsOf: saveURL), let decoded = try? JSONDecoder.iso.decode(ComicProject.self, from: data) else { return }
        project = decoded
        selectedPageID = project.pages.first?.id
    }

    func save() {
        project.updatedAt = Date()
        do {
            let encoded = try JSONEncoder.pretty.encode(project)
            try encoded.write(to: saveURL, options: .atomic)
        } catch {
            log("保存失败：\(error.localizedDescription)")
        }
    }

    func log(_ message: String) {
        let time = DateFormatter.logFormatter.string(from: Date())
        logs.append("[\(time)] \(message)")
    }

    func logsText() -> String { logs.joined(separator: "\n") }

    func pageBinding(for pageID: ComicPage.ID) -> Binding<ComicPage>? {
        guard let index = project.pages.firstIndex(where: { $0.id == pageID }) else { return nil }
        return Binding(
            get: { self.project.pages[index] },
            set: { self.project.pages[index] = $0; self.save() }
        )
    }

    func selectedPageBinding() -> Binding<ComicPage>? {
        guard let selectedPageID else { return nil }
        return pageBinding(for: selectedPageID)
    }

    func updatePage(_ page: ComicPage) {
        guard let index = project.pages.firstIndex(where: { $0.id == page.id }) else { return }
        project.pages[index] = page
        save()
    }

    func planComic(settings: APISettings) async {
        let trimmedInput = project.sourceInput.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmedInput.isEmpty else {
            log("请输入故事或提示词。")
            return
        }

        isBusy = true
        project.status = .planning
        log("开始自动规划：角色 → 故事 → 分镜 → 页面。")
        defer { isBusy = false; save() }

        do {
            let planned = try await ComicPlanningService.plan(project: project, settings: settings, logger: { [weak self] message in
                Task { @MainActor in self?.log(message) }
            })
            project = planned
            selectedPageID = project.pages.first?.id
            project.status = .planned
            log("规划完成：\(project.characters.count) 个角色，\(project.pages.count) 页。")
        } catch {
            project.status = .failed
            log("规划失败：\(error.localizedDescription)")
        }
    }

    func generateSelectedPage(settings: APISettings) async {
        guard let selectedPageID, let index = project.pages.firstIndex(where: { $0.id == selectedPageID }) else {
            log("请先选择页面。")
            return
        }
        await generatePage(at: index, settings: settings)
    }

    func generatePanel(pageID: ComicPage.ID, panelID: ComicPanel.ID, settings: APISettings) async {
        guard let pageIndex = project.pages.firstIndex(where: { $0.id == pageID }),
              let panelIndex = project.pages[pageIndex].panels.firstIndex(where: { $0.id == panelID }) else {
            log("没有找到要重画的分镜。")
            return
        }
        guard !settings.imageConfig.apiKey.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            project.pages[pageIndex].panels[panelIndex].status = .failed
            project.pages[pageIndex].panels[panelIndex].errorMessage = "未填写图片 API Key"
            log("分镜生成失败：未填写图片 API Key。")
            save()
            return
        }

        isBusy = true
        defer { isBusy = false; save() }

        project.pages[pageIndex].panels[panelIndex].status = .generating
        project.pages[pageIndex].panels[panelIndex].errorMessage = nil
        let page = project.pages[pageIndex]
        let panel = page.panels[panelIndex]
        log("开始单独重画第 \(page.pageNumber) 页 Panel \(panel.panelNumber)。")

        do {
            let prompt = ImagePromptBuilder.buildPanel(project: project, page: page, panel: panel, settings: settings)
            let data = try await ImageGenerationService.generateImage(prompt: prompt, config: settings.imageConfig, imageSize: settings.imageSize)
            project.pages[pageIndex].panels[panelIndex].imageData = data
            project.pages[pageIndex].panels[panelIndex].generatedAt = Date()
            project.pages[pageIndex].panels[panelIndex].status = .generated
            log("第 \(page.pageNumber) 页 Panel \(panel.panelNumber) 重画完成。")
        } catch {
            project.pages[pageIndex].panels[panelIndex].status = .failed
            project.pages[pageIndex].panels[panelIndex].errorMessage = error.localizedDescription
            log("第 \(page.pageNumber) 页 Panel \(panel.panelNumber) 重画失败：\(error.localizedDescription)")
        }
    }

    func generateAllPages(settings: APISettings) async {
        guard !project.pages.isEmpty else {
            log("请先自动规划页面。")
            return
        }
        guard !settings.imageConfig.apiKey.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            for index in project.pages.indices {
                project.pages[index].status = .failed
                project.pages[index].errorMessage = "未填写图片 API Key"
            }
            log("全部页面生成失败：未填写图片 API Key。")
            save()
            return
        }

        let concurrency = min(8, max(1, project.pageGenerationConcurrency))
        isBusy = true
        defer { isBusy = false; save() }

        struct PageJob: Sendable {
            let index: Int
            let pageNumber: Int
            let title: String
            let prompt: String
        }

        let jobs: [PageJob] = project.pages.enumerated().map { index, page in
            project.pages[index].status = .generating
            project.pages[index].errorMessage = nil
            let prompt = ImagePromptBuilder.build(project: project, page: page, settings: settings)
            return PageJob(index: index, pageNumber: page.pageNumber, title: page.title, prompt: prompt)
        }

        log("开始并行生成全部页面：共 \(jobs.count) 页，最大并发 \(concurrency)。")
        for job in jobs {
            log("已加入生成队列：第 \(job.pageNumber) 页图片：\(job.title)")
        }

        let imageConfig = settings.imageConfig
        let imageSize = settings.imageSize

        await withTaskGroup(of: (Int, Data?, String?).self) { group in
            var nextJobIndex = 0

            func addJob(_ job: PageJob, to group: inout TaskGroup<(Int, Data?, String?)>) {
                group.addTask {
                    do {
                        let data = try await ImageGenerationService.generateImage(prompt: job.prompt, config: imageConfig, imageSize: imageSize)
                        return (job.index, data, nil)
                    } catch {
                        return (job.index, nil, error.localizedDescription)
                    }
                }
            }

            while nextJobIndex < min(concurrency, jobs.count) {
                addJob(jobs[nextJobIndex], to: &group)
                nextJobIndex += 1
            }

            while let (pageIndex, data, errorText) = await group.next() {
                let pageNumber = project.pages[pageIndex].pageNumber
                if let data {
                    project.pages[pageIndex].imageData = data
                    project.pages[pageIndex].generatedAt = Date()
                    project.pages[pageIndex].status = .generated
                    project.pages[pageIndex].errorMessage = nil
                    log("第 \(pageNumber) 页图片生成完成。")
                } else {
                    let message = errorText ?? "未知错误"
                    project.pages[pageIndex].status = .failed
                    project.pages[pageIndex].errorMessage = message
                    log("第 \(pageNumber) 页图片生成失败：\(message)")
                }
                save()

                if nextJobIndex < jobs.count {
                    addJob(jobs[nextJobIndex], to: &group)
                    nextJobIndex += 1
                }
            }
        }

        log("全部页面生成流程结束。")
    }

    private func generatePage(at index: Int, settings: APISettings, manageBusy: Bool = true) async {
        if manageBusy { isBusy = true }
        defer { if manageBusy { isBusy = false; save() } }

        guard !settings.imageConfig.apiKey.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            project.pages[index].status = .failed
            project.pages[index].errorMessage = "未填写图片 API Key"
            log("第 \(project.pages[index].pageNumber) 页生成失败：未填写图片 API Key。")
            return
        }

        project.pages[index].status = .generating
        project.pages[index].errorMessage = nil
        let page = project.pages[index]
        log("开始生成第 \(page.pageNumber) 页图片：\(page.title)")

        do {
            let prompt = ImagePromptBuilder.build(project: project, page: page, settings: settings)
            let data = try await ImageGenerationService.generateImage(prompt: prompt, config: settings.imageConfig, imageSize: settings.imageSize)
            project.pages[index].imageData = data
            project.pages[index].generatedAt = Date()
            project.pages[index].status = .generated
            log("第 \(page.pageNumber) 页图片生成完成。")
        } catch {
            project.pages[index].status = .failed
            project.pages[index].errorMessage = error.localizedDescription
            log("第 \(page.pageNumber) 页图片生成失败：\(error.localizedDescription)")
        }
    }
}

extension JSONEncoder {
    static var pretty: JSONEncoder {
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        encoder.dateEncodingStrategy = .iso8601
        return encoder
    }
}

extension JSONDecoder {
    static var iso: JSONDecoder {
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        return decoder
    }
}

extension DateFormatter {
    static let logFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm:ss"
        return formatter
    }()
}
