import Foundation

enum TextGenerationService {
    static func generateText(prompt: String, systemPrompt: String, config: ModelEndpointConfig) async throws -> String {
        guard !config.apiKey.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            throw AppError.emptyAPIKey(config.providerName)
        }

        switch config.transport {
        case .openAICompatible:
            return try await generateOpenAICompatible(prompt: prompt, systemPrompt: systemPrompt, config: config)
        case .gemini:
            return try await generateGemini(prompt: prompt, systemPrompt: systemPrompt, config: config)
        case .anthropic:
            return try await generateAnthropic(prompt: prompt, systemPrompt: systemPrompt, config: config)
        default:
            throw AppError.unsupportedProvider("该文本接口类型不能用于故事规划。")
        }
    }

    private static let fallbackMaxTokens = 12000
    private static let providerRequestMaxTokens = 393216

    private static func safeMaxTokens(from rawValue: Int) -> Int {
        // The setting is the user's safety ceiling. It may be very large, such as 1,000,000.
        // The actual API field must still obey the selected provider/model hard limit,
        // otherwise many OpenAI-compatible endpoints return HTTP 400.
        if rawValue < 1 { return fallbackMaxTokens }
        return min(rawValue, providerRequestMaxTokens)
    }

    private static func generateOpenAICompatible(prompt: String, systemPrompt: String, config: ModelEndpointConfig) async throws -> String {
        let url = try NetworkTools.url(base: config.baseURL, path: "/chat/completions")
        let maxTokens = safeMaxTokens(from: config.maxTokens)
        let body: [String: Any] = [
            "model": config.model,
            "temperature": config.temperature,
            "max_tokens": maxTokens,
            "messages": [
                ["role": "system", "content": systemPrompt],
                ["role": "user", "content": prompt]
            ]
        ]
        var request = NetworkTools.request(
            url: url,
            method: "POST",
            apiKey: config.apiKey,
            headers: ["Content-Type": "application/json"],
            body: try NetworkTools.jsonData(body),
            timeout: config.timeoutSeconds
        )
        if config.presetID == "openrouter" {
            request.setValue("AIComicStudio", forHTTPHeaderField: "X-Title")
        }
        let data = try await NetworkTools.perform(request)
        let json = try NetworkTools.jsonObject(from: data)
        if let content = NetworkTools.extractString(json, paths: [["choices", "0", "message", "content"], ["choices", "0", "text"]]) {
            return content
        }
        throw AppError.missingContent("OpenAI-compatible response missing choices[0].message.content")
    }

    private static func generateGemini(prompt: String, systemPrompt: String, config: ModelEndpointConfig) async throws -> String {
        let modelName = config.model.hasPrefix("models/") ? String(config.model.dropFirst("models/".count)) : config.model
        let urlString = NetworkTools.normalizedBase(config.baseURL) + "/models/\(modelName):generateContent?key=" + config.apiKey
        guard let url = URL(string: urlString) else { throw AppError.invalidURL(urlString) }
        let fullPrompt = "\(systemPrompt)\n\n\(prompt)"
        let body: [String: Any] = [
            "contents": [[
                "role": "user",
                "parts": [["text": fullPrompt]]
            ]],
            "generationConfig": [
                "temperature": config.temperature,
                "maxOutputTokens": safeMaxTokens(from: config.maxTokens)
            ]
        ]
        let request = NetworkTools.request(url: url, method: "POST", headers: ["Content-Type": "application/json"], body: try NetworkTools.jsonData(body), timeout: config.timeoutSeconds)
        let data = try await NetworkTools.perform(request)
        let json = try NetworkTools.jsonObject(from: data)
        if let content = NetworkTools.extractString(json, paths: [["candidates", "0", "content", "parts", "0", "text"]]) {
            return content
        }
        throw AppError.missingContent("Gemini response missing candidates[0].content.parts[0].text")
    }

    private static func generateAnthropic(prompt: String, systemPrompt: String, config: ModelEndpointConfig) async throws -> String {
        let url = try NetworkTools.url(base: config.baseURL, path: "/messages")
        let body: [String: Any] = [
            "model": config.model,
            "system": systemPrompt,
            "max_tokens": safeMaxTokens(from: config.maxTokens),
            "temperature": config.temperature,
            "messages": [["role": "user", "content": prompt]]
        ]
        let request = NetworkTools.request(
            url: url,
            method: "POST",
            headers: [
                "x-api-key": config.apiKey,
                "anthropic-version": "2023-06-01",
                "Content-Type": "application/json"
            ],
            body: try NetworkTools.jsonData(body),
            timeout: config.timeoutSeconds
        )
        let data = try await NetworkTools.perform(request)
        let json = try NetworkTools.jsonObject(from: data)
        if let content = NetworkTools.extractString(json, paths: [["content", "0", "text"]]) { return content }
        throw AppError.missingContent("Anthropic response missing content[0].text")
    }
}
