import SwiftUI

struct APISettingsView: View {
    @EnvironmentObject private var settings: APISettings

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                SectionHeader(
                    title: "API 与模型",
                    subtitle: "文本模型负责写故事/角色/分镜；图片模型负责生成漫画页。数值项直接输入，不再用步进按钮。"
                )

                APIConfigCard(
                    title: "文本 API 模型",
                    presets: TextProviderPresets.all,
                    config: $settings.textConfig,
                    isRefreshing: settings.isRefreshingTextModels,
                    refreshAction: { Task { await settings.refreshTextModels() } },
                    applyPreset: { settings.applyTextPreset($0) }
                )

                APIConfigCard(
                    title: "图片生成 API 模型",
                    presets: ImageProviderPresets.all,
                    config: $settings.imageConfig,
                    isRefreshing: settings.isRefreshingImageModels,
                    refreshAction: { Task { await settings.refreshImageModels() } },
                    applyPreset: { settings.applyImagePreset($0) }
                )

                GlassCard(title: "生成选项") {
                    TextField("图片尺寸，例如 1536x2400", text: $settings.imageSize)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .textFieldStyle(.roundedBorder)
                    HStack {
                        Button("竖版 Seedream 1536×2400") { settings.imageSize = "1536x2400" }
                        Button("方图 1920×1920") { settings.imageSize = "1920x1920" }
                        Button("横版 2400×1536") { settings.imageSize = "2400x1536" }
                    }
                    .buttonStyle(.bordered)
                    .font(.caption)
                    Toggle("把 dialogue 写进图片 prompt", isOn: $settings.includeDialogueInImagePrompt)
                    Text("Seedream 要求图片像素至少 3,686,400。选择火山 Seedream 预设后，如果尺寸太小，App 会自动升到 1536×2400 / 1920×1920 / 2400×1536。")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }

                if !settings.lastRefreshMessage.isEmpty {
                    Text(settings.lastRefreshMessage)
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                        .padding(.horizontal, 4)
                }
            }
            .padding(24)
        }
        .background(LiquidGlassBackground())
        .onChange(of: settings.textConfig) { _ in settings.save() }
        .onChange(of: settings.imageConfig) { _ in settings.save() }
        .onChange(of: settings.imageSize) { _ in settings.save() }
        .onChange(of: settings.includeDialogueInImagePrompt) { _ in settings.save() }
    }
}

struct APIConfigCard: View {
    let title: String
    let presets: [ProviderPreset]
    @Binding var config: ModelEndpointConfig
    let isRefreshing: Bool
    let refreshAction: () -> Void
    let applyPreset: (ProviderPreset) -> Void

    var body: some View {
        GlassCard(title: title) {
            Picker("预设", selection: Binding(
                get: { config.presetID },
                set: { newID in
                    if let preset = presets.first(where: { $0.id == newID }) { applyPreset(preset) }
                }
            )) {
                ForEach(presets) { preset in Text(preset.name).tag(preset.id) }
            }

            HStack {
                Label(config.transport.title, systemImage: "point.3.connected.trianglepath.dotted")
                    .font(.caption.weight(.semibold))
                    .padding(.horizontal, 10)
                    .padding(.vertical, 6)
                    .background(.ultraThinMaterial, in: Capsule())
                Spacer()
                LoadingButton(isLoading: isRefreshing, action: refreshAction) {
                    Label("刷新模型", systemImage: "arrow.clockwise")
                }
                .buttonStyle(.bordered)
            }

            TextField("API Base URL", text: $config.baseURL)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .textFieldStyle(.roundedBorder)

            SecureField("API Key", text: $config.apiKey)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .textFieldStyle(.roundedBorder)

            Picker("模型", selection: $config.model) {
                ForEach(config.availableModels, id: \.self) { model in Text(model).tag(model) }
                if !config.availableModels.contains(config.model) { Text(config.model).tag(config.model) }
            }

            TextField("模型名（可手动输入）", text: $config.model)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .textFieldStyle(.roundedBorder)

            if config.transport == .openAICompatible || config.transport == .gemini || config.transport == .anthropic {
                VStack(alignment: .leading, spacing: 10) {
                    HStack {
                        Text("Temperature")
                            .frame(width: 110, alignment: .leading)
                        TextField("0.7", value: $config.temperature, format: .number.precision(.fractionLength(2)))
                            .keyboardType(.decimalPad)
                            .textFieldStyle(.roundedBorder)
                    }
                    HStack {
                        Text("Max Tokens")
                            .frame(width: 110, alignment: .leading)
                        TextField("12000", value: $config.maxTokens, format: .number)
                            .keyboardType(.numberPad)
                            .textFieldStyle(.roundedBorder)
                        Text("这是你的最高预算上限，可输入 1000000；真正请求时会按模型/服务商上限自动裁剪，例如接口最多 393216 就按 393216 发送，避免 400。")
                            .font(.caption2)
                            .foregroundStyle(.secondary)
                    }
                }
            }

            HStack {
                Text("超时秒数")
                    .frame(width: 110, alignment: .leading)
                TextField("300", value: $config.timeoutSeconds, format: .number.precision(.fractionLength(0)))
                    .keyboardType(.numberPad)
                    .textFieldStyle(.roundedBorder)
            }

            if let preset = presets.first(where: { $0.id == config.presetID }) {
                Text(preset.notes)
                    .font(.footnote)
                    .foregroundStyle(.secondary)
            }
        }
    }
}
