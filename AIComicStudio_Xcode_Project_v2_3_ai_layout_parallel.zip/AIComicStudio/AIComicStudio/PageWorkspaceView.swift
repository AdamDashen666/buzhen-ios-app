import SwiftUI
#if canImport(UIKit)
import UIKit
#endif

struct PageWorkspaceView: View {
    @EnvironmentObject private var store: ProjectStore
    @EnvironmentObject private var apiSettings: APISettings
    @State private var showingPDFExport = false

    var body: some View {
        HStack(spacing: 0) {
            pageList
                .frame(minWidth: 260, idealWidth: 300, maxWidth: 340)
                .background(.ultraThinMaterial)

            Divider()

            if let pageBinding = store.selectedPageBinding() {
                PageDetailView(page: pageBinding)
            } else {
                ContentUnavailableView("还没有页面", systemImage: "square.grid.2x2", description: Text("先点击“自动规划漫画”，或者载入示例项目。"))
            }
        }
        .navigationTitle("页面分镜")
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                Button { showingPDFExport = true } label: {
                    Label("导出 PDF", systemImage: "doc.richtext")
                }
                .disabled(store.project.pages.isEmpty)
            }
        }
        .sheet(isPresented: $showingPDFExport) {
            PDFExportSheet(project: store.project)
        }
    }

    private var pageList: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text("页面")
                    .font(.title2.bold())
                Spacer()
                Button { Task { await store.generateAllPages(settings: apiSettings) } } label: {
                    Image(systemName: "photo.stack")
                }
                .disabled(store.project.pages.isEmpty || store.isBusy)
            }
            .padding([.top, .horizontal], 16)

            if store.project.pages.isEmpty {
                Spacer()
                ContentUnavailableView("无页面", systemImage: "doc.badge.plus")
                Spacer()
            } else {
                ScrollView {
                    LazyVStack(spacing: 10) {
                        ForEach(store.project.pages) { page in
                            Button { store.selectedPageID = page.id } label: {
                                PageListRow(page: page, isSelected: page.id == store.selectedPageID)
                            }
                            .buttonStyle(.plain)
                        }
                    }
                    .padding(12)
                }
            }
        }
    }
}

struct PageListRow: View {
    let page: ComicPage
    let isSelected: Bool

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text("第 \(page.pageNumber) 页")
                    .font(.headline)
                Spacer()
                StatusPill(status: page.status)
            }
            Text(page.title)
                .font(.subheadline.weight(.semibold))
            Text(page.summary)
                .font(.caption)
                .foregroundStyle(.secondary)
                .lineLimit(2)
        }
        .padding(12)
        .background(isSelected ? Color.blue.opacity(0.18) : Color(.secondarySystemBackground).opacity(0.55), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 16).strokeBorder(isSelected ? Color.blue.opacity(0.4) : Color.secondary.opacity(0.12)))
    }
}

struct PageDetailView: View {
    @EnvironmentObject private var store: ProjectStore
    @EnvironmentObject private var apiSettings: APISettings
    @Binding var page: ComicPage

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                HStack(alignment: .top) {
                    SectionHeader(title: "第 \(page.pageNumber) 页 · \(page.title)", subtitle: "查看和修改这一页的规划；可生成整页，也可单独重画某个分镜。")
                    Spacer()
                    VStack(alignment: .trailing, spacing: 8) {
                        StatusPill(status: page.status)
                        LoadingButton(isLoading: store.isBusy) { Task { await store.generateSelectedPage(settings: apiSettings) } } label: {
                            Label("生成整页", systemImage: "photo")
                        }
                        .buttonStyle(.borderedProminent)
                    }
                }

                if let error = page.errorMessage, !error.isEmpty {
                    Text(error)
                        .font(.footnote)
                        .foregroundStyle(.red)
                        .padding(12)
                        .background(.red.opacity(0.08), in: RoundedRectangle(cornerRadius: 12))
                }

                if let data = page.imageData {
                    GlassCard(title: "整页生成结果") {
                        PlatformImageView(data: data)
                            .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                    }
                }

                GlassCard(title: "页面规划") {
                    TextField("页面标题", text: $page.title)
                        .textFieldStyle(.roundedBorder)
                    EditableTextBlock(title: "摘要", text: $page.summary, minHeight: 70)
                    EditableTextBlock(title: "整页图片 Prompt", text: $page.pagePrompt, minHeight: 120)
                    EditableTextBlock(title: "连续性备注", text: $page.continuityNotes, minHeight: 80)
                }

                GlassCard(title: "分镜 / Dialogue") {
                    ForEach($page.panels) { $panel in
                        PanelEditor(
                            pageID: page.id,
                            panel: $panel,
                            isBusy: store.isBusy,
                            regenerate: { panelID in
                                Task { await store.generatePanel(pageID: page.id, panelID: panelID, settings: apiSettings) }
                            }
                        )
                        if panel.id != page.panels.last?.id { Divider() }
                    }
                }
            }
            .padding(24)
        }
        .background(LiquidGlassBackground())
    }
}

struct PanelEditor: View {
    let pageID: ComicPage.ID
    @Binding var panel: ComicPanel
    let isBusy: Bool
    let regenerate: (ComicPanel.ID) -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text("Panel \(panel.panelNumber)")
                    .font(.headline)
                StatusPill(status: panel.status)
                Spacer()
                LoadingButton(isLoading: isBusy) { regenerate(panel.id) } label: {
                    Label("重画本分镜", systemImage: "arrow.triangle.2.circlepath.camera")
                }
                .buttonStyle(.bordered)
            }

            if let error = panel.errorMessage, !error.isEmpty {
                Text(error)
                    .font(.caption)
                    .foregroundStyle(.red)
                    .padding(8)
                    .background(.red.opacity(0.08), in: RoundedRectangle(cornerRadius: 10))
            }

            if let data = panel.imageData {
                PlatformImageView(data: data)
                    .frame(maxHeight: 260)
                    .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
            }

            TextField("镜头类型", text: $panel.shotType)
                .textFieldStyle(.roundedBorder)
            TextField("场景", text: $panel.setting)
                .textFieldStyle(.roundedBorder)
            EditableTextBlock(title: "动作", text: $panel.action, minHeight: 58)
            EditableTextBlock(title: "视觉 Prompt", text: $panel.visualPrompt, minHeight: 80)
            HStack {
                TextField("Camera", text: $panel.camera)
                    .textFieldStyle(.roundedBorder)
                TextField("Mood", text: $panel.mood)
                    .textFieldStyle(.roundedBorder)
            }
            EditableTextBlock(title: "旁白", text: $panel.narration, minHeight: 58)
            TextField("出现角色，用逗号分隔", text: Binding(
                get: { panel.characters.joined(separator: ", ") },
                set: { panel.characters = $0.split(separator: ",").map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }.filter { !$0.isEmpty } }
            ))
            .textFieldStyle(.roundedBorder)

            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    Text("Dialogue")
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(.secondary)
                    Spacer()
                    Button { panel.dialogue.append(DialogueLine(speaker: "", text: "", emotion: "")) } label: {
                        Label("添加台词", systemImage: "plus.bubble")
                    }
                    .font(.caption)
                }
                ForEach($panel.dialogue) { $line in
                    HStack {
                        TextField("角色", text: $line.speaker)
                            .textFieldStyle(.roundedBorder)
                            .frame(maxWidth: 130)
                        TextField("台词", text: $line.text)
                            .textFieldStyle(.roundedBorder)
                        TextField("情绪", text: $line.emotion)
                            .textFieldStyle(.roundedBorder)
                            .frame(maxWidth: 120)
                    }
                }
            }
        }
        .padding(.vertical, 8)
    }
}

struct PDFExportSheet: View {
    let project: ComicProject
    @Environment(\.dismiss) private var dismiss
    @State private var selectedIDs: Set<ComicPage.ID>
    @State private var pdfURL: URL?
    @State private var errorText: String?

    init(project: ComicProject) {
        self.project = project
        _selectedIDs = State(initialValue: Set(project.pages.map { $0.id }))
    }

    var body: some View {
        NavigationStack {
            VStack(alignment: .leading, spacing: 14) {
                Text("选择要导出的页面")
                    .font(.headline)
                HStack {
                    Button("全选") { selectedIDs = Set(project.pages.map { $0.id }) }
                    Button("全不选") { selectedIDs.removeAll() }
                }
                .buttonStyle(.bordered)

                List(project.pages) { page in
                    Toggle("第 \(page.pageNumber) 页 · \(page.title)", isOn: Binding(
                        get: { selectedIDs.contains(page.id) },
                        set: { on in
                            if on { selectedIDs.insert(page.id) } else { selectedIDs.remove(page.id) }
                        }
                    ))
                }

                if let errorText { Text(errorText).foregroundStyle(.red).font(.footnote) }

                HStack {
                    Button("生成 PDF") { generatePDF() }
                        .buttonStyle(.borderedProminent)
                        .disabled(selectedIDs.isEmpty)
                    if let pdfURL {
                        ShareLink(item: pdfURL) {
                            Label("分享/保存 PDF", systemImage: "square.and.arrow.up")
                        }
                        .buttonStyle(.bordered)
                    }
                }
            }
            .padding()
            .navigationTitle("导出 PDF")
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("关闭") { dismiss() } } }
        }
    }

    private func generatePDF() {
        let pages = project.pages.filter { selectedIDs.contains($0.id) }.sorted { $0.pageNumber < $1.pageNumber }
        do {
            pdfURL = try PDFComicExporter.render(project: project, pages: pages)
            errorText = nil
        } catch {
            errorText = error.localizedDescription
        }
    }
}

#if canImport(UIKit)
enum PDFComicExporter {
    static func render(project: ComicProject, pages: [ComicPage]) throws -> URL {
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("\(project.title.replacingOccurrences(of: " ", with: "_"))_Comic.pdf")
        let pageRect = CGRect(x: 0, y: 0, width: 595, height: 842)
        let renderer = UIGraphicsPDFRenderer(bounds: pageRect)
        try renderer.writePDF(to: url) { context in
            for page in pages {
                context.beginPage()
                draw(text: "\(project.title) · 第 \(page.pageNumber) 页", rect: CGRect(x: 36, y: 28, width: 523, height: 28), font: .boldSystemFont(ofSize: 18))
                draw(text: page.title, rect: CGRect(x: 36, y: 58, width: 523, height: 22), font: .boldSystemFont(ofSize: 15))
                var y: CGFloat = 88
                if let data = page.imageData, let image = UIImage(data: data) {
                    let maxRect = CGRect(x: 36, y: y, width: 523, height: 500)
                    image.draw(in: aspectFit(image.size, in: maxRect))
                    y += 514
                }
                draw(text: page.summary, rect: CGRect(x: 36, y: y, width: 523, height: 58), font: .systemFont(ofSize: 11))
                y += 68
                for panel in page.panels.prefix(6) {
                    let line = "Panel \(panel.panelNumber): \(panel.action)"
                    draw(text: line, rect: CGRect(x: 36, y: y, width: 523, height: 28), font: .systemFont(ofSize: 10))
                    y += 30
                }
            }
        }
        return url
    }

    private static func draw(text: String, rect: CGRect, font: UIFont) {
        let paragraph = NSMutableParagraphStyle()
        paragraph.lineBreakMode = .byWordWrapping
        let attributes: [NSAttributedString.Key: Any] = [.font: font, .foregroundColor: UIColor.label, .paragraphStyle: paragraph]
        NSString(string: text).draw(in: rect, withAttributes: attributes)
    }

    private static func aspectFit(_ size: CGSize, in rect: CGRect) -> CGRect {
        let scale = min(rect.width / max(size.width, 1), rect.height / max(size.height, 1))
        let width = size.width * scale
        let height = size.height * scale
        return CGRect(x: rect.midX - width / 2, y: rect.minY, width: width, height: height)
    }
}
#else
enum PDFComicExporter {
    static func render(project: ComicProject, pages: [ComicPage]) throws -> URL { throw AppError.unsupportedProvider("PDF export requires iOS/UIKit.") }
}
#endif
