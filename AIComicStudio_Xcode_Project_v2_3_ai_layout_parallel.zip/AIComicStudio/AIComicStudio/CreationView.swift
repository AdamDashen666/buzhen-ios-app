import SwiftUI

struct CreationView: View {
    @EnvironmentObject private var store: ProjectStore
    @EnvironmentObject private var apiSettings: APISettings

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                SectionHeader(
                    title: "AI 漫画制作",
                    subtitle: "输入故事或关键词。页数和每页分镜可由 AI 自动规划，也可以由你指定；一键生成全部页面时支持并行生成。"
                )

                GlassCard(title: "基础设置") {
                    TextField("项目标题", text: Binding(get: { store.project.title }, set: { store.project.title = $0; store.save() }))
                        .textFieldStyle(.roundedBorder)

                    Picker("创作模式", selection: Binding(get: { store.project.mode }, set: { store.project.mode = $0; store.save() })) {
                        ForEach(CreationMode.allCases) { mode in Text(mode.title).tag(mode) }
                    }
                    .pickerStyle(.segmented)

                    Text(store.project.mode.explanation)
                        .font(.footnote)
                        .foregroundStyle(.secondary)

                    VStack(alignment: .leading, spacing: 8) {
                        Picker("漫画风格", selection: Binding(get: { store.project.style }, set: { store.project.style = $0; store.save() })) {
                            ForEach(ComicStyle.allCases) { style in
                                Text(style.displayName).tag(style)
                            }
                        }
                        .pickerStyle(.menu)

                        Text(store.project.style.shortDescription)
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                    }

                    Picker("页数和分镜规划", selection: Binding(get: { store.project.layoutMode }, set: { store.project.layoutMode = $0; store.save() })) {
                        ForEach(LayoutPlanningMode.allCases) { mode in
                            Text(mode.title).tag(mode)
                        }
                    }
                    .pickerStyle(.menu)

                    Text(store.project.layoutMode.explanation)
                        .font(.footnote)
                        .foregroundStyle(.secondary)

                    switch store.project.layoutMode {
                    case .aiAutomatic:
                        EmptyView()
                    case .fixedPageCount:
                        VStack(alignment: .leading) {
                            Text("总页数")
                                .font(.caption.weight(.semibold))
                            TextField("例如 8", value: Binding(get: { store.project.pageCount }, set: { store.project.pageCount = max(1, min($0, 30)); store.save() }), format: .number)
                                .keyboardType(.numberPad)
                                .textFieldStyle(.roundedBorder)
                        }
                    case .customPagePanelPlan:
                        VStack(alignment: .leading, spacing: 8) {
                            Text("每页分镜设置")
                                .font(.caption.weight(.semibold))
                            TextEditor(text: Binding(get: { store.project.customPagePanelPlan }, set: { store.project.customPagePanelPlan = $0; store.save() }))
                                .frame(minHeight: 120)
                                .padding(10)
                                .background(Color(.secondarySystemBackground).opacity(0.5), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                                .overlay(RoundedRectangle(cornerRadius: 18).strokeBorder(.secondary.opacity(0.16)))
                            Text("示例：1:3\n2:4\n3:2\n表示第 1 页 3 格、第 2 页 4 格、第 3 页 2 格。")
                                .font(.footnote)
                                .foregroundStyle(.secondary)
                        }
                    }

                    VStack(alignment: .leading, spacing: 8) {
                        Text("全部页面生成并发数")
                            .font(.caption.weight(.semibold))
                        Picker("全部页面生成并发数", selection: Binding(get: { store.project.pageGenerationConcurrency }, set: { store.project.pageGenerationConcurrency = max(1, min($0, 8)); store.save() })) {
                            Text("2").tag(2)
                            Text("4（推荐）").tag(4)
                            Text("6").tag(6)
                            Text("8").tag(8)
                        }
                        .pickerStyle(.menu)
                        Text("一键生成所有页时会同时生成多页图片；页数越多，并发越高，速度越快，但更容易触发接口限流。")
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                    }
                }

                GlassCard(title: store.project.mode == .story ? "粘贴故事" : "输入提示词 / 世界观 / 人物想法") {
                    TextEditor(text: Binding(get: { store.project.sourceInput }, set: { store.project.sourceInput = $0; store.save() }))
                        .frame(minHeight: 220)
                        .padding(10)
                        .background(Color(.secondarySystemBackground).opacity(0.5), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                        .overlay(RoundedRectangle(cornerRadius: 18).strokeBorder(.secondary.opacity(0.16)))

                    HStack {
                        LoadingButton(isLoading: store.isBusy) { Task { await store.planComic(settings: apiSettings) } } label: {
                            Label("自动规划漫画", systemImage: "sparkles")
                        }
                        .buttonStyle(.borderedProminent)

                        LoadingButton(isLoading: store.isBusy) { Task { await store.generateAllPages(settings: apiSettings) } } label: {
                            Label("一键生成所有页", systemImage: "photo.stack")
                        }
                        .buttonStyle(.bordered)

                        Spacer()
                        StatusPill(status: store.project.status)
                    }
                }

                if !store.project.logline.isEmpty || !store.project.generatedStory.isEmpty {
                    GlassCard(title: "AI 故事结果") {
                        if !store.project.logline.isEmpty { Text(store.project.logline).font(.title3.weight(.semibold)) }
                        if !store.project.generatedStory.isEmpty { Text(store.project.generatedStory).font(.body).foregroundStyle(.secondary) }
                    }
                }
            }
            .padding(24)
        }
        .background(LiquidGlassBackground())
    }
}
