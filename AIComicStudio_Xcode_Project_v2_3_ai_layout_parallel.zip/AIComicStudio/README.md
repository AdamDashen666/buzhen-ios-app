# AIComicStudio

AI 漫画制作 iPadOS/iOS Xcode Project。

## v2 重点

- 文本和图片模型可分别配置 API Base URL、Key、模型名。
- 图片 API 新增火山方舟 Seedream 预设：`https://ark.cn-beijing.volces.com/api/v3`。
- Seedream 会自动使用更大的尺寸，避免 `image size must be at least 3686400 pixels`。
- AI 可自动规划页数与每页分镜；也可以用户手动输入页数和分镜数。
- 每页可生成整页图片，每个分镜也可单独重画。
- 页面可选择全部或部分导出 PDF。
- UI 使用 Liquid Glass 风格的 SwiftUI material 视觉。

## 注意

如果使用火山方舟 Seedream，模型名通常填控制台中的模型 ID 或 Endpoint ID。图片尺寸建议使用 1536x2400、1920x1920 或 2400x1536。
