# AI Workflow Studio v2.0

SwiftUI iOS / iPadOS Xcode Project 骨架。

## v2.0 更新

- 修复 Build-logs-133 中的 SwiftUI 编译失败：`confirmationDialog` 误用了不存在的 `item:` 参数，已改为 `isPresented` 绑定。
- 保留「意见提出者 / 优化者」模块。
- 优化者可以读取上游当前结果，输出问题、风险、遗漏点、修改建议和优先级。
- 优化者输出可以手动连接到通用工作者或代码工作者，让工作者根据意见继续改进。
- AI 自动选择模块支持识别 optimizer / 优化 / 意见 / 改进建议。
- 保留 v1.8/v1.9 的运行 Watchdog、进度日志、停止运行、动态画布、真实 ZIP 导出和缓存清理。

## 注意

需要在 Xcode 中设置 Team / Bundle ID 后运行。API 默认按 OpenAI-compatible `/v1/models` 与 `/v1/chat/completions` 设计。
