import Foundation
import CoreGraphics

struct TrackedFrame: Codable {
    let frameIndex: Int
    let timeSeconds: Double
    let quad: [CGPointCodable]
    let confidence: Double
    let inlierCount: Int
    let trackerStatus: String
    let planePose: PlanePose?
}

struct CGPointCodable: Codable, Hashable, Sendable {
    let x: Double
    let y: Double
    init(_ p: CGPoint) {
        self.x = Double(p.x)
        self.y = Double(p.y)
    }
    var cgPoint: CGPoint { CGPoint(x: CGFloat(x), y: CGFloat(y)) }
}


struct QuadNormalizer {
    static func canonical(_ points: [CGPoint]) -> [CGPoint] {
        guard points.count == 4 else { return points }
        let byY = points.sorted { lhs, rhs in
            if abs(lhs.y - rhs.y) > 0.0001 { return lhs.y < rhs.y }
            return lhs.x < rhs.x
        }
        let top = Array(byY.prefix(2)).sorted { $0.x < $1.x }
        let bottom = Array(byY.suffix(2)).sorted { $0.x < $1.x }
        guard top.count == 2, bottom.count == 2 else { return points }
        return [top[0], top[1], bottom[1], bottom[0]]
    }
}

struct PlanePose: Codable {
    let translationX: Double
    let translationY: Double
    let translationZ: Double
    let yawDegrees: Double
    let pitchDegrees: Double
    let rollDegrees: Double
    let focalLengthPixels: Double
    let note: String
}




enum AdvancedPlaneTrackingPreset: String, CaseIterable, Codable, Hashable, Sendable {
    case capcutPro
    case gameWall
    case hudHeavy
    case lowTexture
    case fastCamera
    case screen
    case floor
    case cinematicStable

    var title: String {
        switch self {
        case .capcutPro: return "剪映式"
        case .gameWall: return "游戏墙面"
        case .hudHeavy: return "HUD 多"
        case .lowTexture: return "低纹理"
        case .fastCamera: return "快速镜头"
        case .screen: return "屏幕/招牌"
        case .floor: return "地面"
        case .cinematicStable: return "稳定优先"
        }
    }

    var detail: String {
        switch self {
        case .capcutPro: return "特征点 + 光流 + 遮罩 + 防抖的综合模式。"
        case .gameWall: return "优先锁定墙面/建筑边缘，降低 HUD 和角色干扰。"
        case .hudHeavy: return "更强运动遮罩，尽量剔除手、枪、UI。"
        case .lowTexture: return "低纹理补偿更强，宁愿稳住也不乱飞。"
        case .fastCamera: return "搜索范围更大，适合快速转头/快速移动。"
        case .screen: return "适合屏幕、牌子、矩形物体。"
        case .floor: return "适合地面/路面透视贴字。"
        case .cinematicStable: return "更强平滑，适合慢镜头和成片导出。"
        }
    }
}

struct AdvancedTrackingConfiguration: Codable, Hashable, Sendable {
    var preset: AdvancedPlaneTrackingPreset
    var enableFeatureTracking: Bool
    var enableOpticalFlow: Bool
    var enablePlaneMotionMask: Bool
    var enableLowTextureCompensation: Bool
    var enableJitterSmoothing: Bool
    var enableManualKeyframes: Bool
    var enableMetalAcceleration: Bool
    var featureGridDensity: Int
    var opticalFlowWindow: Int
    var ransacIterations: Int
    var smoothStrength: Double
    var lowTextureHoldStrength: Double
    var hudRejectionStrength: Double

    static let capcutPro = AdvancedTrackingConfiguration.forPreset(.capcutPro)

    static func forPreset(_ preset: AdvancedPlaneTrackingPreset) -> AdvancedTrackingConfiguration {
        switch preset {
        case .capcutPro:
            return AdvancedTrackingConfiguration(preset: preset, enableFeatureTracking: true, enableOpticalFlow: true, enablePlaneMotionMask: true, enableLowTextureCompensation: true, enableJitterSmoothing: true, enableManualKeyframes: true, enableMetalAcceleration: true, featureGridDensity: 2, opticalFlowWindow: 2, ransacIterations: 520, smoothStrength: 0.42, lowTextureHoldStrength: 0.72, hudRejectionStrength: 0.64)
        case .gameWall:
            return AdvancedTrackingConfiguration(preset: preset, enableFeatureTracking: true, enableOpticalFlow: true, enablePlaneMotionMask: true, enableLowTextureCompensation: true, enableJitterSmoothing: true, enableManualKeyframes: true, enableMetalAcceleration: true, featureGridDensity: 3, opticalFlowWindow: 2, ransacIterations: 620, smoothStrength: 0.36, lowTextureHoldStrength: 0.66, hudRejectionStrength: 0.74)
        case .hudHeavy:
            return AdvancedTrackingConfiguration(preset: preset, enableFeatureTracking: true, enableOpticalFlow: true, enablePlaneMotionMask: true, enableLowTextureCompensation: true, enableJitterSmoothing: true, enableManualKeyframes: true, enableMetalAcceleration: true, featureGridDensity: 2, opticalFlowWindow: 1, ransacIterations: 680, smoothStrength: 0.50, lowTextureHoldStrength: 0.76, hudRejectionStrength: 0.92)
        case .lowTexture:
            return AdvancedTrackingConfiguration(preset: preset, enableFeatureTracking: true, enableOpticalFlow: true, enablePlaneMotionMask: true, enableLowTextureCompensation: true, enableJitterSmoothing: true, enableManualKeyframes: true, enableMetalAcceleration: true, featureGridDensity: 3, opticalFlowWindow: 3, ransacIterations: 460, smoothStrength: 0.62, lowTextureHoldStrength: 0.90, hudRejectionStrength: 0.50)
        case .fastCamera:
            return AdvancedTrackingConfiguration(preset: preset, enableFeatureTracking: true, enableOpticalFlow: true, enablePlaneMotionMask: true, enableLowTextureCompensation: true, enableJitterSmoothing: true, enableManualKeyframes: true, enableMetalAcceleration: true, featureGridDensity: 2, opticalFlowWindow: 4, ransacIterations: 720, smoothStrength: 0.30, lowTextureHoldStrength: 0.62, hudRejectionStrength: 0.58)
        case .screen:
            return AdvancedTrackingConfiguration(preset: preset, enableFeatureTracking: true, enableOpticalFlow: true, enablePlaneMotionMask: true, enableLowTextureCompensation: false, enableJitterSmoothing: true, enableManualKeyframes: true, enableMetalAcceleration: true, featureGridDensity: 2, opticalFlowWindow: 2, ransacIterations: 540, smoothStrength: 0.34, lowTextureHoldStrength: 0.58, hudRejectionStrength: 0.55)
        case .floor:
            return AdvancedTrackingConfiguration(preset: preset, enableFeatureTracking: true, enableOpticalFlow: true, enablePlaneMotionMask: true, enableLowTextureCompensation: true, enableJitterSmoothing: true, enableManualKeyframes: true, enableMetalAcceleration: true, featureGridDensity: 2, opticalFlowWindow: 2, ransacIterations: 560, smoothStrength: 0.48, lowTextureHoldStrength: 0.72, hudRejectionStrength: 0.58)
        case .cinematicStable:
            return AdvancedTrackingConfiguration(preset: preset, enableFeatureTracking: true, enableOpticalFlow: true, enablePlaneMotionMask: true, enableLowTextureCompensation: true, enableJitterSmoothing: true, enableManualKeyframes: true, enableMetalAcceleration: true, featureGridDensity: 2, opticalFlowWindow: 1, ransacIterations: 520, smoothStrength: 0.72, lowTextureHoldStrength: 0.82, hudRejectionStrength: 0.62)
        }
    }
}

struct ManualTrackingKeyframe: Codable, Hashable, Sendable, Identifiable {
    let id: UUID
    let timeSeconds: Double
    let points: [CGPointCodable]

    init(timeSeconds: Double, points: [CGPoint]) {
        self.id = UUID()
        self.timeSeconds = timeSeconds
        self.points = QuadNormalizer.canonical(points).map(CGPointCodable.init)
    }

    var cgPoints: [CGPoint] { points.map(\.cgPoint) }
}

struct TextOverlaySettings: Codable, Hashable, Sendable {
    let scale: Double
    let planeCenterX: Double
    let planeCenterY: Double

    static let `default` = TextOverlaySettings(scale: 1.0, planeCenterX: 0.5, planeCenterY: 0.5)
}

enum TrackingQuality: String, CaseIterable, Codable, Hashable, Sendable {
    case fast
    case balanced
    case high
    case ultra

    var title: String {
        switch self {
        case .fast: return "快"
        case .balanced: return "平衡"
        case .high: return "高质量"
        case .ultra: return "专业平面"
        }
    }

    var maxTrackWidth: Int {
        switch self {
        case .fast: return 520
        case .balanced: return 800
        case .high: return 1180
        case .ultra: return 1680
        }
    }

    var patchRadius: Int {
        switch self {
        case .fast: return 5
        case .balanced: return 7
        case .high: return 8
        case .ultra: return 12
        }
    }

    var searchRadius: Int {
        switch self {
        case .fast: return 18
        case .balanced: return 26
        case .high: return 38
        case .ultra: return 64
        }
    }

    var gridX: Int {
        switch self {
        case .fast: return 5
        case .balanced: return 8
        case .high: return 11
        case .ultra: return 18
        }
    }

    var gridY: Int {
        switch self {
        case .fast: return 4
        case .balanced: return 6
        case .high: return 8
        case .ultra: return 12
        }
    }

    var minNCC: Double {
        switch self {
        case .fast: return 0.42
        case .balanced: return 0.46
        case .high: return 0.50
        case .ultra: return 0.42
        }
    }

    var ransacError: CGFloat {
        switch self {
        case .fast: return 7.0
        case .balanced: return 6.0
        case .high: return 5.0
        case .ultra: return 5.5
        }
    }
}

enum OutputProfile: String, CaseIterable, Codable, Hashable, Sendable {
    case h264Compatibility
    case hevcHDRPriority

    var title: String {
        switch self {
        case .h264Compatibility: return "H.264 兼容"
        case .hevcHDRPriority: return "HEVC/HDR 优先"
        }
    }

    var fileExtension: String {
        switch self {
        case .h264Compatibility: return "mp4"
        case .hevcHDRPriority: return "mov"
        }
    }
}

struct Homography2D: Codable {
    let h11: Double
    let h12: Double
    let h13: Double
    let h21: Double
    let h22: Double
    let h23: Double
    let h31: Double
    let h32: Double
    let h33: Double

    static let identity = Homography2D(h11: 1, h12: 0, h13: 0, h21: 0, h22: 1, h23: 0, h31: 0, h32: 0, h33: 1)

    func apply(_ p: CGPoint) -> CGPoint {
        let x = Double(p.x)
        let y = Double(p.y)
        let w = h31 * x + h32 * y + h33
        if abs(w) < 1e-9 { return p }
        let u = (h11 * x + h12 * y + h13) / w
        let v = (h21 * x + h22 * y + h23) / w
        return CGPoint(x: CGFloat(u), y: CGFloat(v))
    }

    var array: [Double] { [h11, h12, h13, h21, h22, h23, h31, h32, h33] }

    func inverted() -> Homography2D? {
        let a = h11, b = h12, c = h13
        let d = h21, e = h22, f = h23
        let g = h31, h = h32, i = h33

        let A = e * i - f * h
        let B = -(d * i - f * g)
        let C = d * h - e * g
        let D = -(b * i - c * h)
        let E = a * i - c * g
        let F = -(a * h - b * g)
        let G = b * f - c * e
        let H = -(a * f - c * d)
        let I = a * e - b * d

        let det = a * A + b * B + c * C
        if abs(det) < 1e-9 { return nil }
        let inv = 1.0 / det
        return Homography2D(
            h11: A * inv, h12: D * inv, h13: G * inv,
            h21: B * inv, h22: E * inv, h23: H * inv,
            h31: C * inv, h32: F * inv, h33: I * inv
        )
    }
}

struct HomographyEstimator {
    static func estimate(from src: [CGPoint], to dst: [CGPoint]) -> Homography2D? {
        guard src.count == dst.count, src.count >= 4 else { return nil }
        var normal = Array(repeating: Array(repeating: 0.0, count: 8), count: 8)
        var rhs = Array(repeating: 0.0, count: 8)

        for i in 0..<src.count {
            let x = Double(src[i].x)
            let y = Double(src[i].y)
            let u = Double(dst[i].x)
            let v = Double(dst[i].y)
            let row1 = [x, y, 1, 0, 0, 0, -u * x, -u * y]
            let row2 = [0, 0, 0, x, y, 1, -v * x, -v * y]
            accumulate(row: row1, value: u, normal: &normal, rhs: &rhs)
            accumulate(row: row2, value: v, normal: &normal, rhs: &rhs)
        }

        guard let sol = solve(normal, rhs) else { return nil }
        return Homography2D(
            h11: sol[0], h12: sol[1], h13: sol[2],
            h21: sol[3], h22: sol[4], h23: sol[5],
            h31: sol[6], h32: sol[7], h33: 1
        )
    }

    static func robust(from src: [CGPoint], to dst: [CGPoint], threshold: CGFloat, maxIterations: Int = 180) -> (model: Homography2D, inliers: [Int], error: Double)? {
        guard src.count == dst.count, src.count >= 4 else { return nil }
        var seed = UInt64(src.count * 8191 + 31)
        var bestModel: Homography2D?
        var bestInliers: [Int] = []
        var bestError = Double.greatestFiniteMagnitude
        let iterations = min(maxIterations, max(24, src.count * 6))

        for _ in 0..<iterations {
            let idx = sampleFour(count: src.count, seed: &seed)
            let s = idx.map { src[$0] }
            let d = idx.map { dst[$0] }
            guard let model = estimate(from: s, to: d) else { continue }
            let evaluated = evaluate(model: model, src: src, dst: dst, threshold: threshold)
            if evaluated.inliers.count > bestInliers.count || (evaluated.inliers.count == bestInliers.count && evaluated.error < bestError) {
                bestModel = model
                bestInliers = evaluated.inliers
                bestError = evaluated.error
            }
        }

        if bestInliers.count >= 4 {
            let refinedSrc = bestInliers.map { src[$0] }
            let refinedDst = bestInliers.map { dst[$0] }
            if let refined = estimate(from: refinedSrc, to: refinedDst) {
                let refinedEval = evaluate(model: refined, src: src, dst: dst, threshold: threshold)
                return (refined, refinedEval.inliers, refinedEval.error)
            }
        }

        if let all = estimate(from: src, to: dst) {
            let evaluated = evaluate(model: all, src: src, dst: dst, threshold: threshold * 1.7)
            if evaluated.inliers.count >= 4 { return (all, evaluated.inliers, evaluated.error) }
        }

        if let bestModel, bestInliers.count >= 4 {
            return (bestModel, bestInliers, bestError)
        }
        return nil
    }

    private static func evaluate(model: Homography2D, src: [CGPoint], dst: [CGPoint], threshold: CGFloat) -> (inliers: [Int], error: Double) {
        var inliers: [Int] = []
        var err = 0.0
        for i in 0..<src.count {
            let p = model.apply(src[i])
            let dx = p.x - dst[i].x
            let dy = p.y - dst[i].y
            let e = sqrt(dx * dx + dy * dy)
            if e <= threshold {
                inliers.append(i)
                err += Double(e)
            }
        }
        return (inliers, inliers.isEmpty ? Double.greatestFiniteMagnitude : err / Double(inliers.count))
    }

    private static func sampleFour(count: Int, seed: inout UInt64) -> [Int] {
        var result: [Int] = []
        while result.count < 4 {
            seed = seed &* 6364136223846793005 &+ 1442695040888963407
            let v = Int(seed % UInt64(count))
            if !result.contains(v) { result.append(v) }
        }
        return result
    }

    private static func accumulate(row: [Double], value: Double, normal: inout [[Double]], rhs: inout [Double]) {
        for r in 0..<row.count {
            rhs[r] += row[r] * value
            for c in 0..<row.count {
                normal[r][c] += row[r] * row[c]
            }
        }
    }

    private static func solve(_ a: [[Double]], _ b: [Double]) -> [Double]? {
        let n = b.count
        var m = a
        var x = b

        for i in 0..<n {
            var pivot = i
            var best = abs(m[i][i])
            for r in i..<n {
                let v = abs(m[r][i])
                if v > best { best = v; pivot = r }
            }
            if best < 1e-9 { return nil }
            if pivot != i {
                m.swapAt(i, pivot)
                x.swapAt(i, pivot)
            }
            let div = m[i][i]
            for c in i..<n { m[i][c] /= div }
            x[i] /= div
            for r in 0..<n where r != i {
                let f = m[r][i]
                if f == 0 { continue }
                for c in i..<n { m[r][c] -= f * m[i][c] }
                x[r] -= f * x[i]
            }
        }
        return x
    }
}

struct PlanePoseSolver {
    static func solve(imageQuad: [CGPoint], videoSize: CGSize) -> PlanePose? {
        guard imageQuad.count == 4, videoSize.width > 0, videoSize.height > 0 else { return nil }
        let aspect = max(0.2, min(5.0, averageAspect(of: imageQuad)))
        let halfW = aspect
        let halfH = CGFloat(1.0)
        let plane = [
            CGPoint(x: -halfW, y: -halfH),
            CGPoint(x: halfW, y: -halfH),
            CGPoint(x: halfW, y: halfH),
            CGPoint(x: -halfW, y: halfH)
        ]
        guard let h = HomographyEstimator.estimate(from: plane, to: imageQuad) else { return nil }
        let f = Double(max(videoSize.width, videoSize.height)) * 0.95
        let cx = Double(videoSize.width) * 0.5
        let cy = Double(videoSize.height) * 0.5

        let col1 = Vec3((h.h11 - cx * h.h31) / f, (h.h21 - cy * h.h31) / f, h.h31)
        let col2 = Vec3((h.h12 - cx * h.h32) / f, (h.h22 - cy * h.h32) / f, h.h32)
        let col3 = Vec3((h.h13 - cx * h.h33) / f, (h.h23 - cy * h.h33) / f, h.h33)
        let scale = 1.0 / max(1e-6, (col1.length + col2.length) * 0.5)
        let r1 = col1 * scale
        let r2 = col2 * scale
        let r3 = Vec3.cross(r1, r2).normalized
        let t = col3 * scale

        let yaw = atan2(r1.z, r1.x) * 180.0 / .pi
        let pitch = atan2(-r2.z, sqrt(r2.x * r2.x + r2.y * r2.y)) * 180.0 / .pi
        let roll = atan2(r1.y, r2.y) * 180.0 / .pi
        return PlanePose(
            translationX: t.x,
            translationY: t.y,
            translationZ: t.z,
            yawDegrees: yaw,
            pitchDegrees: pitch,
            rollDegrees: roll,
            focalLengthPixels: f,
            note: "Plane-based local camera pose. Good for wall/screen text lock; not global scene reconstruction."
        )
    }

    private static func averageAspect(of q: [CGPoint]) -> CGFloat {
        let top = distance(q[0], q[1])
        let bottom = distance(q[3], q[2])
        let left = distance(q[0], q[3])
        let right = distance(q[1], q[2])
        let w = max(1, (top + bottom) * 0.5)
        let h = max(1, (left + right) * 0.5)
        return w / h
    }

    private static func distance(_ a: CGPoint, _ b: CGPoint) -> CGFloat {
        let dx = a.x - b.x
        let dy = a.y - b.y
        return sqrt(dx * dx + dy * dy)
    }
}

private struct Vec3 {
    let x: Double
    let y: Double
    let z: Double

    init(_ x: Double, _ y: Double, _ z: Double) {
        self.x = x
        self.y = y
        self.z = z
    }

    var length: Double { sqrt(x * x + y * y + z * z) }
    var normalized: Vec3 {
        let l = max(1e-9, length)
        return Vec3(x / l, y / l, z / l)
    }

    static func * (lhs: Vec3, rhs: Double) -> Vec3 {
        Vec3(lhs.x * rhs, lhs.y * rhs, lhs.z * rhs)
    }

    static func cross(_ a: Vec3, _ b: Vec3) -> Vec3 {
        Vec3(
            a.y * b.z - a.z * b.y,
            a.z * b.x - a.x * b.z,
            a.x * b.y - a.y * b.x
        )
    }
}

final class TrackingDebugLog: @unchecked Sendable {
    static let shared = TrackingDebugLog()
    private let lock = NSLock()
    private var lines: [String] = []
    private let maxLines = 2400

    private init() {}

    func reset(context: String) {
        lock.lock()
        lines = [
            "Track3DTool Tracking Log",
            "ui_version: v19",
            "time: \(ISO8601DateFormatter().string(from: Date()))",
            context,
            ""
        ]
        lock.unlock()
    }

    func append(_ line: String) {
        lock.lock()
        lines.append(line)
        if lines.count > maxLines {
            lines.removeFirst(lines.count - maxLines)
            if lines.first?.hasPrefix("Track3DTool Tracking Log") != true {
                lines.insert("Track3DTool Tracking Log", at: 0)
                lines.insert("note: older tracking lines were truncated to keep the log copyable", at: 1)
            }
        }
        lock.unlock()
    }

    func appendFrame(frameIndex: Int, timeSeconds: Double, result: PatchTrackResult, quad: [CGPoint]) {
        let quadText = quad.enumerated().map { idx, p in
            "P\(idx + 1)=(\(String(format: "%.1f", p.x)),\(String(format: "%.1f", p.y)))"
        }.joined(separator: " ")
        append("frame=\(frameIndex) time=\(String(format: "%.3f", timeSeconds)) model=\(result.modelName) conf=\(String(format: "%.3f", result.confidence)) score=\(String(format: "%.3f", result.averageScore)) inliers=\(result.inlierCount) matched=\(result.matchedCount)/\(result.totalPoints) status=\(result.status) quad=\(quadText)")
    }

    func snapshot() -> String {
        lock.lock()
        let text = lines.joined(separator: "\n")
        lock.unlock()
        return text
    }
}
