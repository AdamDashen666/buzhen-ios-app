import Foundation
import CoreGraphics

struct PatchTrackResult {
    let quadOriginalPixels: [CGPoint]
    let confidence: Double
    let inlierCount: Int
    let status: String
    let matchedCount: Int
    let totalPoints: Int
    let modelName: String
    let averageScore: Double
}

final class PatchPlaneTracker {
    private struct TrackPoint {
        let initial: CGPoint
        var current: CGPoint
        var template: [UInt8]
        let texture: Double
        var lostFrames: Int
    }

    private struct MatchCandidate {
        let point: CGPoint
        let score: Double
        let secondScore: Double
        let gap: Double
        let distanceFromPrediction: CGFloat
    }

    private var points: [TrackPoint] = []
    private let initialQuad: [CGPoint]
    private let quality: TrackingQuality
    private let advanced: AdvancedTrackingConfiguration
    private var lastHomography: Homography2D = .identity
    private var lastGoodQuad: [CGPoint]
    private var frameCounter = 0
    private var lockMode = false

    init(initialImage: ImageGray, quadInOriginalPixels: [CGPoint], quality: TrackingQuality, advanced: AdvancedTrackingConfiguration = .capcutPro) {
        self.quality = quality
        self.advanced = advanced
        let ordered = QuadNormalizer.canonical(quadInOriginalPixels)
        let s = initialImage.scaleFromOriginal
        self.initialQuad = ordered.map { CGPoint(x: $0.x * s, y: $0.y * s) }
        self.lastGoodQuad = self.initialQuad
        self.points = Self.makeTrackPoints(image: initialImage, quad: self.initialQuad, quality: quality, advanced: advanced)
        self.lockMode = self.points.count < 4
        TrackingDebugLog.shared.append("tracker_init_v19: points=\(points.count), lockMode=\(lockMode), quality=\(quality.rawValue), preset=\(advanced.preset.rawValue), feature=\(advanced.enableFeatureTracking), opticalFlow=\(advanced.enableOpticalFlow), mask=\(advanced.enablePlaneMotionMask), lowTexture=\(advanced.enableLowTextureCompensation), smooth=\(String(format: "%.2f", advanced.smoothStrength)), metal=\(advanced.enableMetalAcceleration), patchRadius=\(quality.patchRadius), searchRadius=\(quality.searchRadius)")
    }

    func track(nextImage: ImageGray) -> PatchTrackResult {
        frameCounter += 1
        if lockMode || points.count < 4 {
            return result(
                quad: lastGoodQuad,
                scale: nextImage.scaleFromOriginal,
                confidence: 0.14,
                inliers: points.count,
                matched: points.count,
                total: points.count,
                modelName: "locked",
                averageScore: 0,
                status: "专业平面跟踪：低纹理保持上一帧"
            )
        }

        let radius = quality.patchRadius
        let opticalBoost = advanced.enableOpticalFlow ? max(0, advanced.opticalFlowWindow * 4) : 0
        let baseSearch = quality.searchRadius + opticalBoost
        var src: [CGPoint] = []
        var dst: [CGPoint] = []
        var pointIndices: [Int] = []
        var newPoints = points
        var scores: [Double] = []
        var acceptedDisplacements: [CGPoint] = []

        for i in 0..<newPoints.count {
            let predicted = lastHomography.apply(newPoints[i].initial)
            let backupPredicted = newPoints[i].current
            let search = min(baseSearch + 12, baseSearch + newPoints[i].lostFrames * (advanced.enableOpticalFlow ? 5 : 3))
            let first = bestMatch(image: nextImage, template: newPoints[i].template, predicted: predicted, radius: radius, search: search)
            let second = bestMatch(image: nextImage, template: newPoints[i].template, predicted: backupPredicted, radius: radius, search: max(6, baseSearch / 2))

            let candidate: MatchCandidate?
            if let first, let second {
                candidate = first.score >= second.score ? first : second
            } else {
                candidate = first ?? second
            }

            let lowTextureRelax = advanced.enableLowTextureCompensation ? 0.20 : 0.14
            let relaxedThreshold = max(0.24, quality.minNCC - lowTextureRelax)
            if let candidate, isReliableMatch(candidate, point: newPoints[i], threshold: relaxedThreshold) {
                src.append(newPoints[i].initial)
                dst.append(candidate.point)
                pointIndices.append(i)
                scores.append(candidate.score)
                acceptedDisplacements.append(CGPoint(x: candidate.point.x - newPoints[i].initial.x, y: candidate.point.y - newPoints[i].initial.y))
                newPoints[i].current = candidate.point
                newPoints[i].lostFrames = 0
            } else {
                newPoints[i].lostFrames = min(newPoints[i].lostFrames + 1, 30)
            }
        }

        let minUsefulInliers = max(4, min(12, max(4, points.count / 5)))
        let matchedCount = src.count
        let meanScore = scores.isEmpty ? 0 : scores.reduce(0, +) / Double(scores.count)

        let filtered = filterByMedianMotion(src: src, dst: dst, pointIndices: pointIndices, scores: scores)
        let modelSrc = filtered.src
        let modelDst = filtered.dst
        let modelScores = filtered.scores
        let modelPointIndices = filtered.pointIndices

        if modelSrc.count >= 4,
           let robust = HomographyEstimator.robust(from: modelSrc, to: modelDst, threshold: quality.ransacError * (advanced.enablePlaneMotionMask ? 0.72 : 0.82), maxIterations: advanced.ransacIterations) {
            let proposedQuad = initialQuad.map { robust.model.apply($0) }
            let rawScore = averageScore(indices: robust.inliers, scores: modelScores)
            let coverage = min(1.0, Double(robust.inliers.count) / Double(max(minUsefulInliers, min(points.count, 36))))
            let confidence = max(0.0, min(1.0, rawScore * coverage))

            let strongConsensus = robust.inliers.count >= max(18, min(points.count / 3, 42))
            let acceptableConfidence = confidence >= (advanced.enableLowTextureCompensation ? 0.18 : 0.24) || (strongConsensus && confidence >= 0.13)
            if robust.inliers.count >= minUsefulInliers,
               acceptableConfidence,
               isSaneQuad(proposedQuad, image: nextImage) {
                for inlier in robust.inliers where inlier < modelPointIndices.count {
                    let idx = modelPointIndices[inlier]
                    let updated = robust.model.apply(newPoints[idx].initial)
                    newPoints[idx].current = updated
                    newPoints[idx].lostFrames = 0
                    if confidence >= 0.34, let patch = nextImage.patch(center: updated, radius: radius) {
                        newPoints[idx].template = patch
                    }
                }
                let exportedConfidence = max(confidence, strongConsensus ? 0.40 : confidence)
                return accept(
                    proposedQuad: proposedQuad,
                    confidence: exportedConfidence,
                    inliers: robust.inliers.count,
                    matched: matchedCount,
                    total: points.count,
                    averageScore: rawScore,
                    points: newPoints,
                    scale: nextImage.scaleFromOriginal,
                    statusPrefix: advanced.enableOpticalFlow ? "v19 Feature+OpticalFlow Homography" : "v19 Feature Homography"
                )
            }
        }

        if modelSrc.count >= 3, let affine = AffineEstimator.estimate(from: modelSrc, to: modelDst) {
            let proposedQuad = initialQuad.map { affine.apply($0) }
            let rawScore = modelScores.isEmpty ? meanScore : modelScores.reduce(0, +) / Double(modelScores.count)
            let coverage = min(1.0, Double(modelSrc.count) / Double(max(minUsefulInliers, min(points.count, 28))))
            let confidence = min(0.62, rawScore * coverage * 0.82)
            if modelSrc.count >= max(3, minUsefulInliers - 2), confidence >= 0.19, isSaneQuad(proposedQuad, image: nextImage) {
                for i in 0..<newPoints.count where newPoints[i].lostFrames == 0 {
                    if confidence >= 0.33, let patch = nextImage.patch(center: newPoints[i].current, radius: radius) {
                        newPoints[i].template = patch
                    }
                }
                return accept(
                    proposedQuad: proposedQuad,
                    confidence: max(confidence, 0.30),
                    inliers: modelSrc.count,
                    matched: matchedCount,
                    total: points.count,
                    averageScore: rawScore,
                    points: newPoints,
                    scale: nextImage.scaleFromOriginal,
                    statusPrefix: advanced.enableOpticalFlow ? "v19 OpticalFlow Affine" : "v19 Affine"
                )
            }
        }

        // Conservative translation fallback: avoids sudden wrong perspective jumps, but still follows slow camera movement.
        if matchedCount >= 4, let translationQuad = translationFallback(displacements: acceptedDisplacements) {
            let rawScore = meanScore
            let coverage = min(1.0, Double(matchedCount) / Double(max(minUsefulInliers, min(points.count, 26))))
            let confidence = min(0.42, max(0.18, rawScore * coverage * 0.55))
            if confidence >= 0.20, isSaneQuad(translationQuad, image: nextImage) {
                self.points = newPoints
                return accept(
                    proposedQuad: translationQuad,
                    confidence: confidence,
                    inliers: matchedCount,
                    matched: matchedCount,
                    total: points.count,
                    averageScore: rawScore,
                    points: newPoints,
                    scale: nextImage.scaleFromOriginal,
                    statusPrefix: "v19 LowTexture Translation"
                )
            }
        }

        self.points = newPoints
        return result(
            quad: lastGoodQuad,
            scale: nextImage.scaleFromOriginal,
            confidence: 0.18,
            inliers: modelSrc.count,
            matched: matchedCount,
            total: points.count,
            modelName: "hold",
            averageScore: meanScore,
            status: advanced.enableLowTextureCompensation ? "v19 低纹理补偿：置信度低，保持/平滑上一帧" : "v19 平面跟踪：置信度低，保持上一帧"
        )
    }

    private func isReliableMatch(_ candidate: MatchCandidate, point: TrackPoint, threshold: Double) -> Bool {
        guard candidate.score >= threshold else { return false }
        // Repeating game textures often produce many similar NCC matches. A small uniqueness gap rejects those false positives.
        let minGap: Double
        if point.texture >= 8 { minGap = 0.012 }
        else if point.texture >= 3 { minGap = 0.020 }
        else { minGap = 0.030 }
        if candidate.gap >= minGap { return true }
        // Allow close, high-score matches even if the second best is similar.
        if candidate.score >= threshold + 0.12 && candidate.distanceFromPrediction <= CGFloat(max(6, quality.searchRadius / 3)) { return true }
        return false
    }

    private func accept(
        proposedQuad: [CGPoint],
        confidence: Double,
        inliers: Int,
        matched: Int,
        total: Int,
        averageScore: Double,
        points newPoints: [TrackPoint],
        scale: CGFloat,
        statusPrefix: String
    ) -> PatchTrackResult {
        let alpha: CGFloat
        if confidence > 0.78 { alpha = 0.72 }
        else if confidence > 0.58 { alpha = 0.54 }
        else if confidence > 0.38 { alpha = 0.38 }
        else { alpha = 0.24 }

        let tunedAlpha: CGFloat
        if advanced.enableJitterSmoothing {
            let damping = CGFloat(min(max(advanced.smoothStrength, 0.0), 0.88))
            tunedAlpha = max(0.08, min(0.90, alpha * (1.0 - damping * 0.55)))
        } else {
            tunedAlpha = alpha
        }
        let smoothed = blendQuad(from: lastGoodQuad, to: proposedQuad, alpha: tunedAlpha)
        lastGoodQuad = smoothed
        lastHomography = HomographyEstimator.estimate(from: initialQuad, to: smoothed) ?? lastHomography
        self.points = newPoints

        let status: String
        if confidence > 0.70 { status = "\(statusPrefix)：稳定贴合" }
        else if confidence > 0.45 { status = "\(statusPrefix)：平滑贴合" }
        else { status = "\(statusPrefix)：保守贴合" }
        return result(quad: smoothed, scale: scale, confidence: confidence, inliers: inliers, matched: matched, total: total, modelName: statusPrefix, averageScore: averageScore, status: status)
    }

    private func result(quad: [CGPoint], scale: CGFloat, confidence: Double, inliers: Int, matched: Int, total: Int, modelName: String, averageScore: Double, status: String) -> PatchTrackResult {
        let inv = 1 / scale
        let originalQ = QuadNormalizer.canonical(quad.map { CGPoint(x: $0.x * inv, y: $0.y * inv) })
        return PatchTrackResult(quadOriginalPixels: originalQ, confidence: confidence, inlierCount: inliers, status: status, matchedCount: matched, totalPoints: total, modelName: modelName, averageScore: averageScore)
    }

    private static func makeTrackPoints(image: ImageGray, quad: [CGPoint], quality: TrackingQuality, advanced: AdvancedTrackingConfiguration = .capcutPro) -> [TrackPoint] {
        let radius = quality.patchRadius
        var all: [TrackPoint] = []
        var candidates: [TrackPoint] = []

        func add(_ p: CGPoint, threshold: Double) {
            guard pointInsideImage(p, image: image, radius: radius) else { return }
            guard let patch = image.patch(center: p, radius: radius) else { return }
            let energy = textureEnergy(patch)
            let tp = TrackPoint(initial: p, current: p, template: patch, texture: energy, lostFrames: 0)
            all.append(tp)
            if energy >= threshold { candidates.append(tp) }
        }

        // More dense points inside the selected plane. This follows the user-selected wall/screen instead of background/HUD outside it.
        let densityBoost = max(0, advanced.featureGridDensity)
        let gxCount = max(quality.gridX + 4 + densityBoost * 3, 12)
        let gyCount = max(quality.gridY + 4 + densityBoost * 2, 9)
        for gy in 0..<gyCount {
            for gx in 0..<gxCount {
                let u = CGFloat(gx + 1) / CGFloat(gxCount + 1)
                let v = CGFloat(gy + 1) / CGFloat(gyCount + 1)
                add(bilinear(quad, u: u, v: v), threshold: 0.78)
            }
        }

        // Edge points are kept on the border only. No outside offsets, because outside points often lock onto guns/HUD/characters in game videos.
        let edgeSamples = max(10, quality.gridX + 4 + densityBoost * 2)
        for i in 0..<edgeSamples {
            let t = CGFloat(i) / CGFloat(max(1, edgeSamples - 1))
            add(bilinear(quad, u: t, v: 0), threshold: 0.70)
            add(bilinear(quad, u: t, v: 1), threshold: 0.70)
            add(bilinear(quad, u: 0, v: t), threshold: 0.70)
            add(bilinear(quad, u: 1, v: t), threshold: 0.70)
        }

        for p in quad { add(p, threshold: 0.45) }

        if candidates.count < 8 {
            candidates = all.sorted(by: { $0.texture > $1.texture }).filter { $0.texture > 0.18 }
        }
        if candidates.count < 4 {
            candidates = all.sorted(by: { $0.texture > $1.texture })
        }

        var unique: [TrackPoint] = []
        let minDistance = CGFloat(max(3, radius + 1))
        for c in candidates.sorted(by: { $0.texture > $1.texture }) {
            if unique.contains(where: { hypot($0.initial.x - c.initial.x, $0.initial.y - c.initial.y) < minDistance }) { continue }
            unique.append(c)
            let cap = (quality == .ultra ? 150 : 110) + densityBoost * 30
            if unique.count >= cap { break }
        }
        return unique
    }

    private static func pointInsideImage(_ p: CGPoint, image: ImageGray, radius: Int) -> Bool {
        let r = CGFloat(radius + 1)
        return p.x >= r && p.y >= r && p.x < CGFloat(image.width) - r && p.y < CGFloat(image.height) - r
    }

    private func filterByMedianMotion(src: [CGPoint], dst: [CGPoint], pointIndices: [Int], scores: [Double]) -> (src: [CGPoint], dst: [CGPoint], pointIndices: [Int], scores: [Double]) {
        guard src.count == dst.count, src.count >= 5 else { return (src, dst, pointIndices, scores) }
        let dxs = zip(src, dst).map { Double($1.x - $0.x) }.sorted()
        let dys = zip(src, dst).map { Double($1.y - $0.y) }.sorted()
        let mdx = median(sorted: dxs)
        let mdy = median(sorted: dys)
        let maskFactor = advanced.enablePlaneMotionMask ? max(0.50, 1.0 - advanced.hudRejectionStrength * 0.35) : 1.0
        let tolerance = Double(max(Int(Double(quality.searchRadius * 2) * maskFactor), 14))
        var fs: [CGPoint] = []
        var fd: [CGPoint] = []
        var fi: [Int] = []
        var fsc: [Double] = []
        for i in 0..<src.count {
            let dx = Double(dst[i].x - src[i].x)
            let dy = Double(dst[i].y - src[i].y)
            let dev = hypot(dx - mdx, dy - mdy)
            if dev <= tolerance || scores[i] > quality.minNCC + 0.18 {
                fs.append(src[i])
                fd.append(dst[i])
                fi.append(pointIndices[i])
                fsc.append(scores[i])
            }
        }
        if fs.count >= 4 { return (fs, fd, fi, fsc) }
        return (src, dst, pointIndices, scores)
    }

    private func translationFallback(displacements: [CGPoint]) -> [CGPoint]? {
        guard displacements.count >= 4 else { return nil }
        let dxs = displacements.map { Double($0.x) }.sorted()
        let dys = displacements.map { Double($0.y) }.sorted()
        let dx = CGFloat(median(sorted: dxs))
        let dy = CGFloat(median(sorted: dys))
        return initialQuad.map { CGPoint(x: $0.x + dx, y: $0.y + dy) }
    }

    private func median(sorted values: [Double]) -> Double {
        guard !values.isEmpty else { return 0 }
        let mid = values.count / 2
        if values.count % 2 == 0 { return (values[mid - 1] + values[mid]) / 2 }
        return values[mid]
    }

    private func isSaneQuad(_ q: [CGPoint], image: ImageGray) -> Bool {
        guard q.count == 4 else { return false }
        if q.contains(where: { !$0.x.isFinite || !$0.y.isFinite }) { return false }
        let margin = CGFloat(max(image.width, image.height)) * 0.16
        for p in q {
            if p.x < -margin || p.y < -margin || p.x > CGFloat(image.width) + margin || p.y > CGFloat(image.height) + margin { return false }
        }
        let initialArea = abs(polygonArea(initialQuad))
        let proposedArea = abs(polygonArea(q))
        if initialArea > 1 {
            if proposedArea < initialArea * 0.24 || proposedArea > initialArea * 3.10 { return false }
        }
        if abs(polygonArea(q)) < 4 { return false }
        let jumpBase: CGFloat = quality == .ultra ? 0.22 : 0.18
        let jumpLimit = CGFloat(max(image.width, image.height)) * (advanced.enableJitterSmoothing ? max(0.10, jumpBase - CGFloat(advanced.smoothStrength) * 0.06) : jumpBase)
        let maxJump = zip(q, lastGoodQuad).map { pair in hypot(pair.0.x - pair.1.x, pair.0.y - pair.1.y) }.max() ?? 0
        return maxJump <= jumpLimit
    }

    private func isInsideExpandedLastQuad(_ p: CGPoint, image: ImageGray) -> Bool {
        let xs = lastGoodQuad.map(\.x)
        let ys = lastGoodQuad.map(\.y)
        guard let minX0 = xs.min(), let maxX0 = xs.max(), let minY0 = ys.min(), let maxY0 = ys.max() else { return true }
        let planeW = max(12, maxX0 - minX0)
        let planeH = max(12, maxY0 - minY0)
        let margin = max(CGFloat(quality.searchRadius + quality.patchRadius + 6), max(planeW, planeH) * 0.22)
        return p.x >= minX0 - margin && p.x <= maxX0 + margin && p.y >= minY0 - margin && p.y <= maxY0 + margin
            && p.x >= -margin && p.y >= -margin && p.x <= CGFloat(image.width) + margin && p.y <= CGFloat(image.height) + margin
    }

    private func bestMatch(image: ImageGray, template: [UInt8], predicted: CGPoint, radius: Int, search: Int) -> MatchCandidate? {
        var bestScore = -Double.greatestFiniteMagnitude
        var secondScore = -Double.greatestFiniteMagnitude
        var best = predicted
        let centerX = Int(round(predicted.x))
        let centerY = Int(round(predicted.y))
        let step = search > 30 ? 2 : 1

        for dy in stride(from: -search, through: search, by: step) {
            for dx in stride(from: -search, through: search, by: step) {
                let candidate = CGPoint(x: CGFloat(centerX + dx), y: CGFloat(centerY + dy))
                guard isInsideExpandedLastQuad(candidate, image: image) else { continue }
                guard let patch = image.patch(center: candidate, radius: radius) else { continue }
                let score = ncc(template, patch)
                if score > bestScore {
                    secondScore = bestScore
                    bestScore = score
                    best = candidate
                } else if score > secondScore {
                    secondScore = score
                }
            }
        }

        if step > 1 {
            let coarse = best
            for dy in -3...3 {
                for dx in -3...3 {
                    let candidate = CGPoint(x: coarse.x + CGFloat(dx), y: coarse.y + CGFloat(dy))
                    guard isInsideExpandedLastQuad(candidate, image: image) else { continue }
                    guard let patch = image.patch(center: candidate, radius: radius) else { continue }
                    let score = ncc(template, patch)
                    if score > bestScore {
                        secondScore = bestScore
                        bestScore = score
                        best = candidate
                    } else if score > secondScore {
                        secondScore = score
                    }
                }
            }
        }

        guard bestScore.isFinite else { return nil }
        let gap = bestScore - (secondScore.isFinite ? secondScore : -1)
        let distance = hypot(best.x - predicted.x, best.y - predicted.y)
        return MatchCandidate(point: best, score: bestScore, secondScore: secondScore, gap: gap, distanceFromPrediction: distance)
    }

    private func averageScore(indices: [Int], scores: [Double]) -> Double {
        var values: [Double] = []
        for i in indices where i < scores.count { values.append(scores[i]) }
        return values.isEmpty ? 0 : values.reduce(0, +) / Double(values.count)
    }

    private func blendQuad(from old: [CGPoint], to new: [CGPoint], alpha: CGFloat) -> [CGPoint] {
        guard old.count == new.count else { return new }
        return zip(old, new).map { a, b in
            CGPoint(x: a.x + (b.x - a.x) * alpha, y: a.y + (b.y - a.y) * alpha)
        }
    }

    private static func bilinear(_ q: [CGPoint], u: CGFloat, v: CGFloat) -> CGPoint {
        let top = CGPoint(x: q[0].x + (q[1].x - q[0].x) * u, y: q[0].y + (q[1].y - q[0].y) * u)
        let bottom = CGPoint(x: q[3].x + (q[2].x - q[3].x) * u, y: q[3].y + (q[2].y - q[3].y) * u)
        return CGPoint(x: top.x + (bottom.x - top.x) * v, y: top.y + (bottom.y - top.y) * v)
    }

    private static func textureEnergy(_ patch: [UInt8]) -> Double {
        guard !patch.isEmpty else { return 0 }
        let mean = patch.reduce(0.0) { $0 + Double($1) } / Double(patch.count)
        let variance = patch.reduce(0.0) { acc, px in
            let d = Double(px) - mean
            return acc + d * d
        } / Double(patch.count)
        return sqrt(variance)
    }

    private func ncc(_ a: [UInt8], _ b: [UInt8]) -> Double {
        guard a.count == b.count, !a.isEmpty else { return -1 }
        let n = Double(a.count)
        var meanA = 0.0
        var meanB = 0.0
        for i in 0..<a.count {
            meanA += Double(a[i])
            meanB += Double(b[i])
        }
        meanA /= n
        meanB /= n
        var num = 0.0
        var da = 0.0
        var db = 0.0
        for i in 0..<a.count {
            let x = Double(a[i]) - meanA
            let y = Double(b[i]) - meanB
            num += x * y
            da += x * x
            db += y * y
        }
        let denom = sqrt(da * db)
        guard denom > 1e-6 else { return -1 }
        return num / denom
    }

    private func polygonArea(_ q: [CGPoint]) -> CGFloat {
        guard q.count >= 3 else { return 0 }
        var a: CGFloat = 0
        for i in 0..<q.count {
            let j = (i + 1) % q.count
            a += q[i].x * q[j].y - q[j].x * q[i].y
        }
        return a * 0.5
    }
}
