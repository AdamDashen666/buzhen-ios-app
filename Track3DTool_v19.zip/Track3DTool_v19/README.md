# Track3DTool v12

本地 iOS/iPadOS 视频平面 3D 追踪工具。

## v12 更新

- 先生成 720p 代理跟踪预览，App 内可播放。
- 确认预览效果后，再导出原片。
- 导出不再从选中帧裁掉前面视频；完整保留原视频，文字从选中的那一帧开始出现。
- 四个角点可以拖动微调，点位缩小，减少遮挡视野。
- 跟踪增强：更多采样点、更大搜索范围、更多 RANSAC 迭代。
- 720p 预览默认 H.264、无音频，降低 Cannot Complete Action 风险。

## 使用顺序

1. 导入视频。
2. 拖动视频条选择文字开始出现的帧。
3. 按顺序点 4 个角：左上 → 右上 → 右下 → 左下。
4. 拖动小黄点微调四点，拖动文字调整位置。
5. 生成 720p 跟踪预览。
6. 确认后导出原片。

## 风险

- 纯色墙、遮挡、快速转场仍可能漂移。
- HEVC/HDR 仍是实验路径；稳定性优先建议先用 H.264。
- 如果继续失败，需要发崩溃日志或 GitHub workflow 日志继续定位。


## v19
- 剪映专业版式平面跟踪：只追踪所选平面/边缘，避免跟到手、枪、HUD。
- AVPlayer 代理实时预览：拖动时间条直接 seek 画面。
- Homography + Affine 双路径 + 平滑防漂移。


## v19
- Added full copyable tracking logs.
- Added per-frame tracking diagnostics: model, confidence, score, matched/inlier points, status, quad coordinates.
- Improved plane tracking: dense in-plane points only, ambiguity rejection for repeated textures, median-motion outlier filtering, conservative translation fallback.
