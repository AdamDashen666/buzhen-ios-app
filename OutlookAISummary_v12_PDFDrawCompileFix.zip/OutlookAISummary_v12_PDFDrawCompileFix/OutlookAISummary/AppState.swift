import Foundation
import SwiftUI
import UserNotifications
import UIKit

@MainActor
final class AppState: ObservableObject {
    @Published var backendURL: String {
        didSet {
            UserDefaults.standard.set(backendURL, forKey: "backendURL")
            api.baseURL = backendURL.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        }
    }
    @Published var linkedUser: LinkedUser?
    @Published var historySummaries: [LocalSummaryRecord] = []
    @Published var settings = AppSettings()
    @Published var backendHealth: BackendHealthResponse?
    @Published var imapStatus: IMAPTestResponse?
    @Published var connectionStatus = "未检查后端连接"
    @Published var aiTestStatus = "未测试 AI 模型"
    @Published var testSummaryStatus = "未测试 AI 总结"
    @Published var notificationStatus = "未测试通知"
    @Published var isLoading = false
    @Published var statusText = "未连接"
    @Published var lastError: String?
    @Published var pushToken: String?

    let deviceId: String
    let api: APIClient

    private let historyKey = "localSummaryHistoryV11"
    private let textRetentionDays = 60
    private let pdfRetentionDays = 15

    init() {
        let storedBackend = UserDefaults.standard.string(forKey: "backendURL")?.trimmingCharacters(in: .whitespacesAndNewlines)
        let savedBackend = (storedBackend?.isEmpty == false) ? storedBackend! : "https://outlook-ai-backend.onrender.com"
        self.backendURL = savedBackend
        self.api = APIClient(baseURL: savedBackend)
        Self.removeLegacyAISettings()
        if let savedDeviceId = UserDefaults.standard.string(forKey: "deviceId") {
            self.deviceId = savedDeviceId
        } else {
            let newId = UUID().uuidString
            UserDefaults.standard.set(newId, forKey: "deviceId")
            self.deviceId = newId
        }
        loadLocalSummaryHistory()
        cleanupLocalHistoryAndPDFs()
    }

    private static func removeLegacyAISettings() {
        ["aiModel", "aiBaseUrl", "aiApiKey"].forEach { key in
            UserDefaults.standard.removeObject(forKey: key)
        }
    }

    func bootstrap() async {
        await registerDevice()
        await refreshAll()
    }

    var historyGroups: [LocalSummaryDayGroup] {
        let grouped = Dictionary(grouping: historySummaries) { $0.dateTitle }
        return grouped.keys.sorted(by: >).map { key in
            LocalSummaryDayGroup(
                id: key,
                dateTitle: key,
                records: (grouped[key] ?? []).sorted { $0.createdAt > $1.createdAt }
            )
        }
    }

    var backendValidationMessage: String? {
        let raw = backendURL.trimmingCharacters(in: .whitespacesAndNewlines)
        if raw.isEmpty {
            return "先到设置里填写后端地址。真机需要 HTTPS 后端地址，不能直接用 localhost。"
        }
        guard let components = URLComponents(string: raw),
              let scheme = components.scheme?.lowercased(),
              let host = components.host?.lowercased(),
              ["http", "https"].contains(scheme) else {
            return "后端地址格式不正确。示例：https://你的后端域名"
        }

        #if targetEnvironment(simulator)
        return nil
        #else
        if host == "localhost" || host == "127.0.0.1" || host == "::1" {
            return "真机里的 localhost 是 iPad/iPhone 自己，不是后端服务器。请填部署后的 HTTPS 地址，或用 ngrok/Cloudflare Tunnel 暴露本地后端。"
        }
        return nil
        #endif
    }

    func registerDevice() async {
        guard backendValidationMessage == nil else {
            statusText = "请先配置后端地址"
            return
        }
        do {
            _ = try await api.registerDevice(deviceId: deviceId, deviceToken: pushToken)
        } catch {
            lastError = error.localizedDescription
        }
    }

    func refreshAll() async {
        cleanupLocalHistoryAndPDFs()
        await refreshBackendConnection()
        if let message = backendValidationMessage {
            linkedUser = nil
            statusText = "请先配置后端地址"
            lastError = message
            return
        }

        isLoading = true
        defer { isLoading = false }

        // QQ IMAP 模式只以 IMAP 测试结果为邮箱连接状态来源。
        guard imapStatus?.ok == true else {
            linkedUser = nil
            statusText = "QQ IMAP 未连接"
            if backendHealth?.ok == true {
                lastError = imapStatus?.error ?? "QQ IMAP 测试未通过"
            }
            return
        }

        linkedUser = LinkedUser(displayName: "QQ 邮箱", email: imapStatus?.account, settings: settings, lastRunAt: nil)
        statusText = imapStatus?.account ?? "QQ 邮箱已连接"
        lastError = nil
    }

    func refreshBackendConnection() async {
        if let message = backendValidationMessage {
            connectionStatus = "后端地址无效"
            lastError = message
            return
        }

        do {
            let health = try await api.health()
            backendHealth = health

            let imap = try await api.imapTest()
            imapStatus = imap

            if health.ok && imap.ok {
                connectionStatus = "后端正常，QQ 邮箱 IMAP 已连接"
                statusText = imap.account ?? "QQ 邮箱已连接"
                linkedUser = LinkedUser(displayName: "QQ 邮箱", email: imap.account, settings: settings, lastRunAt: nil)
                lastError = nil
            } else if health.ok {
                connectionStatus = "后端正常，但 QQ 邮箱未连接"
                lastError = imap.error ?? "IMAP 测试未通过"
            } else {
                connectionStatus = "后端异常"
                lastError = "后端健康检查失败"
            }
        } catch {
            backendHealth = nil
            imapStatus = nil
            connectionStatus = "无法连接后端"
            lastError = error.localizedDescription
        }
    }

    func testAIModel() async {
        if let message = backendValidationMessage {
            lastError = message
            return
        }
        isLoading = true
        aiTestStatus = "正在测试后端 AI 模型..."
        defer { isLoading = false }

        do {
            let response = try await api.testAIModel(deviceId: deviceId)
            if response.ok {
                aiTestStatus = "AI 模型可用"
                lastError = nil
            } else {
                aiTestStatus = "AI 模型测试失败"
                lastError = response.error ?? "后端返回失败状态"
            }
        } catch {
            aiTestStatus = "AI 模型测试失败"
            lastError = error.localizedDescription
        }
    }

    func saveSettings() async {
        if let message = backendValidationMessage {
            lastError = message
            return
        }
        isLoading = true
        defer { isLoading = false }
        do {
            let response = try await api.updateSettings(deviceId: deviceId, settings: settings)
            settings = response.settings
            lastError = nil
            await refreshAll()
        } catch {
            lastError = error.localizedDescription
        }
    }

    func runNow() async {
        await runTestSummary()
    }

    func runTestSummary() async {
        if let message = backendValidationMessage {
            lastError = message
            return
        }
        isLoading = true
        testSummaryStatus = "正在测试最新 3 封邮件...\n仅测试最新 3 封邮件，不会处理全部历史邮件。"
        defer { isLoading = false }
        do {
            await refreshBackendConnection()
            guard imapStatus?.ok == true else {
                testSummaryStatus = "QQ IMAP 未连接，无法测试总结"
                lastError = imapStatus?.error ?? "QQ IMAP 测试未通过"
                return
            }

            let response = try await api.runTestSummary()
            if response.ok {
                let record = saveSuccessfulSummary(response, fallbackTitle: "QQ 邮箱测试总结")
                linkedUser = LinkedUser(displayName: "QQ 邮箱", email: imapStatus?.account, settings: settings, lastRunAt: nil)
                statusText = imapStatus?.account ?? "QQ 邮箱已连接"

                let testedCount = response.effectiveProcessedCount ?? record.processedCount
                var message = "已测试 \(testedCount) 封邮件"
                let summaryText = record.content.trimmingCharacters(in: .whitespacesAndNewlines)
                if summaryText.isEmpty {
                    message += "\n\n后端未返回总结内容。"
                } else {
                    message += "\n\n" + summaryText
                }
                if response.hasMore == true {
                    message += "\n\n邮件较多，本次只测试了部分邮件。"
                }
                testSummaryStatus = message
            } else {
                testSummaryStatus = "测试总结失败\n" + (response.error ?? response.message ?? "后端未返回成功状态")
            }
            lastError = nil
        } catch {
            let message = userFacingSummaryError(error)
            testSummaryStatus = "测试总结失败\n" + message
            lastError = message
        }
    }

    func runScheduledSummaryNow() async {
        if let message = backendValidationMessage {
            lastError = message
            return
        }
        isLoading = true
        testSummaryStatus = "正在按当前频率窗口执行正式总结..."
        defer { isLoading = false }
        do {
            await refreshBackendConnection()
            guard imapStatus?.ok == true else {
                testSummaryStatus = "QQ IMAP 未连接，无法立即总结"
                lastError = imapStatus?.error ?? "QQ IMAP 测试未通过"
                return
            }

            let response = try await api.runScheduledSummary(frequency: settings.frequency)
            if response.ok {
                let record = saveSuccessfulSummary(response, fallbackTitle: "QQ 邮箱邮件总结")
                linkedUser = LinkedUser(displayName: "QQ 邮箱", email: imapStatus?.account, settings: settings, lastRunAt: nil)
                statusText = imapStatus?.account ?? "QQ 邮箱已连接"

                let processedCount = response.effectiveProcessedCount ?? record.processedCount
                testSummaryStatus = "正式总结完成：处理 \(processedCount) 封邮件"
                let summaryText = record.content.trimmingCharacters(in: .whitespacesAndNewlines)
                if !summaryText.isEmpty {
                    testSummaryStatus += "\n\n" + summaryText
                }
                if response.hasMore == true {
                    testSummaryStatus += "\n\n邮件较多，本次只处理了窗口内部分邮件。"
                }
            } else {
                testSummaryStatus = "正式总结失败\n" + (response.error ?? response.message ?? "后端未返回成功状态")
            }
            lastError = nil
        } catch {
            let message = userFacingSummaryError(error)
            testSummaryStatus = "正式总结失败\n" + message
            lastError = message
        }
    }

    private func userFacingSummaryError(_ error: Error) -> String {
        let nsError = error as NSError
        if nsError.domain == NSURLErrorDomain && nsError.code == NSURLErrorTimedOut {
            return "邮件较多或 AI 响应较慢，请稍后重试。测试模式只会处理最近 3 封。"
        }
        if let formatError = error as? BackendDecodeFormatError {
            return formatError.localizedDescription
        }
        return error.localizedDescription
    }

    func requestNotifications() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .badge, .sound]) { granted, error in
            DispatchQueue.main.async {
                if let error { self.lastError = error.localizedDescription }
                if granted { UIApplication.shared.registerForRemoteNotifications() }
            }
        }
    }

    func sendTestNotification() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .badge, .sound]) { granted, error in
            DispatchQueue.main.async {
                if let error {
                    self.notificationStatus = "测试通知失败"
                    self.lastError = error.localizedDescription
                    return
                }
                guard granted else {
                    self.notificationStatus = "请在系统设置中允许 Mail AI 通知。"
                    self.lastError = "请在系统设置中允许 Mail AI 通知。"
                    return
                }

                let content = UNMutableNotificationContent()
                content.title = "Mail AI 测试通知"
                content.body = "如果你看到这条通知，说明推送通知功能正常。"
                content.sound = .default
                let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 3, repeats: false)
                let request = UNNotificationRequest(identifier: "mail-ai-local-test-\(UUID().uuidString)", content: content, trigger: trigger)
                UNUserNotificationCenter.current().add(request) { addError in
                    DispatchQueue.main.async {
                        if let addError {
                            self.notificationStatus = "测试通知失败"
                            self.lastError = addError.localizedDescription
                        } else {
                            self.notificationStatus = "测试通知已发送，约 3 秒后显示。"
                            self.lastError = nil
                            UIApplication.shared.registerForRemoteNotifications()
                        }
                    }
                }
            }
        }
    }

    func updatePushToken(_ token: String) {
        pushToken = token
        Task { await registerDevice() }
    }

    private func saveSuccessfulSummary(_ response: RunSummaryResponse, fallbackTitle: String) -> LocalSummaryRecord {
        let now = Date()
        let createdAt = parseISODate(response.summary?.createdAt) ?? now
        let rawContent = (response.displaySummaryText ?? response.message ?? "后端未返回总结内容。")
            .trimmingCharacters(in: .whitespacesAndNewlines)
        let processedCount = response.effectiveProcessedCount ?? 0
        let importantCount = response.importantCount ?? 0
        let spamCount = response.spamCount ?? response.summary?.junkUnreadCount ?? 0
        let content = normalizedSummaryContent(
            rawContent,
            startTime: response.startTime,
            endTime: response.endTime,
            processedCount: processedCount,
            importantCount: importantCount,
            spamCount: spamCount
        )
        var record = LocalSummaryRecord(
            id: response.summary?.id ?? UUID().uuidString,
            title: response.summary?.title ?? fallbackTitle,
            content: content,
            createdAt: createdAt,
            startTime: response.startTime,
            endTime: response.endTime,
            processedCount: processedCount,
            importantCount: importantCount,
            spamCount: spamCount,
            pdfFileName: nil,
            backendPDFInfo: response.backendPDFInfo
        )

        if let pdfURL = generatePDF(for: record) {
            record.pdfFileName = pdfURL.lastPathComponent
        }

        historySummaries.removeAll { $0.id == record.id }
        historySummaries.insert(record, at: 0)
        historySummaries.sort { $0.createdAt > $1.createdAt }
        cleanupLocalHistoryAndPDFs(saveAfterCleanup: false)
        saveLocalSummaryHistory()
        return record
    }

    private func normalizedSummaryContent(
        _ raw: String,
        startTime: String?,
        endTime: String?,
        processedCount: Int,
        importantCount: Int,
        spamCount: Int
    ) -> String {
        let trimmed = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        if trimmed.contains("【邮件总结】") { return trimmed }

        var lines: [String] = ["【邮件总结】"]
        if let startTime, let endTime, !startTime.isEmpty, !endTime.isEmpty {
            lines.append("时间范围：\(startTime) - \(endTime)")
        }
        lines.append("处理邮件：\(processedCount) 封")
        lines.append("重要邮件：\(importantCount) 封")
        lines.append("垃圾/低价值邮件：\(spamCount) 封")
        lines.append("")
        lines.append(trimmed.isEmpty ? "后端未返回总结内容。" : trimmed)
        return lines.joined(separator: "\n")
    }

    private func loadLocalSummaryHistory() {
        guard let data = UserDefaults.standard.data(forKey: historyKey),
              let decoded = try? JSONDecoder().decode([LocalSummaryRecord].self, from: data) else {
            historySummaries = []
            return
        }
        historySummaries = decoded.sorted { $0.createdAt > $1.createdAt }
    }

    private func saveLocalSummaryHistory() {
        if let data = try? JSONEncoder().encode(historySummaries) {
            UserDefaults.standard.set(data, forKey: historyKey)
        }
    }

    func pdfURL(for record: LocalSummaryRecord) -> URL? {
        guard let fileName = record.pdfFileName else { return nil }
        let url = pdfDirectoryURL().appendingPathComponent(fileName)
        return FileManager.default.fileExists(atPath: url.path) ? url : nil
    }

    func hasPDF(for record: LocalSummaryRecord) -> Bool {
        pdfURL(for: record) != nil
    }

    func regeneratePDF(for recordId: String) {
        guard let index = historySummaries.firstIndex(where: { $0.id == recordId }) else { return }
        let record = historySummaries[index]
        if let url = generatePDF(for: record) {
            historySummaries[index].pdfFileName = url.lastPathComponent
            saveLocalSummaryHistory()
            lastError = nil
        } else {
            lastError = "重新生成 PDF 失败"
        }
    }

    private func generatePDF(for record: LocalSummaryRecord) -> URL? {
        let directory = pdfDirectoryURL()
        do {
            try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true, attributes: nil)
        } catch {
            lastError = error.localizedDescription
            return nil
        }

        let fileName = record.pdfFileName ?? makePDFFileName(for: record.createdAt, id: record.id)
        let url = directory.appendingPathComponent(fileName)
        let pageRect = CGRect(x: 0, y: 0, width: 595.2, height: 841.8)
        let margin: CGFloat = 48
        let textWidth = pageRect.width - margin * 2
        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.lineSpacing = 4
        paragraphStyle.paragraphSpacing = 6

        let bodyFont = UIFont.systemFont(ofSize: 12)
        let titleFont = UIFont.boldSystemFont(ofSize: 18)
        let attributes: [NSAttributedString.Key: Any] = [
            .font: bodyFont,
            .paragraphStyle: paragraphStyle,
            .foregroundColor: UIColor.label
        ]
        let titleAttributes: [NSAttributedString.Key: Any] = [
            .font: titleFont,
            .paragraphStyle: paragraphStyle,
            .foregroundColor: UIColor.label
        ]

        let renderer = UIGraphicsPDFRenderer(bounds: pageRect)
        do {
            try renderer.writePDF(to: url) { context in
                context.beginPage()
                var y = margin

                func draw(_ text: String, attrs: [NSAttributedString.Key: Any]) {
                    let value = text.isEmpty ? " " : text
                    let attributed = NSAttributedString(string: value, attributes: attrs)
                    let height = ceil(attributed.boundingRect(
                        with: CGSize(width: textWidth, height: .greatestFiniteMagnitude),
                        options: [.usesLineFragmentOrigin, .usesFontLeading],
                        context: nil
                    ).height) + 4
                    if y + height > pageRect.height - margin {
                        context.beginPage()
                        y = margin
                    }
                    attributed.draw(
                        with: CGRect(x: margin, y: y, width: textWidth, height: height),
                        options: [.usesLineFragmentOrigin, .usesFontLeading],
                        context: nil
                    )
                    y += height + 4
                }

                for (index, line) in cleanMarkdownForPlainText(record.content).components(separatedBy: .newlines).enumerated() {
                    draw(line, attrs: index == 0 ? titleAttributes : attributes)
                }
            }
            return url
        } catch {
            lastError = error.localizedDescription
            return nil
        }
    }

    private func pdfDirectoryURL() -> URL {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first
            ?? FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        return base.appendingPathComponent("MailAISummaryPDFs", isDirectory: true)
    }

    private func makePDFFileName(for date: Date, id: String) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd_HH-mm"
        let suffix = String(id.prefix(6))
        return "mail_summary_\(formatter.string(from: date))_\(suffix).pdf"
    }

    private func cleanupLocalHistoryAndPDFs(saveAfterCleanup: Bool = true) {
        let now = Date()
        let textCutoff = now.addingTimeInterval(TimeInterval(-textRetentionDays * 24 * 60 * 60))
        let pdfCutoff = now.addingTimeInterval(TimeInterval(-pdfRetentionDays * 24 * 60 * 60))
        let manager = FileManager.default
        let pdfDirectory = pdfDirectoryURL()

        var changed = false
        let removed = historySummaries.filter { $0.createdAt < textCutoff }
        if !removed.isEmpty {
            changed = true
            for record in removed {
                if let fileName = record.pdfFileName {
                    try? manager.removeItem(at: pdfDirectory.appendingPathComponent(fileName))
                }
            }
            historySummaries.removeAll { $0.createdAt < textCutoff }
        }

        for index in historySummaries.indices {
            guard let fileName = historySummaries[index].pdfFileName else { continue }
            let url = pdfDirectory.appendingPathComponent(fileName)
            if historySummaries[index].createdAt < pdfCutoff || !manager.fileExists(atPath: url.path) {
                try? manager.removeItem(at: url)
                historySummaries[index].pdfFileName = nil
                changed = true
            }
        }

        if let files = try? manager.contentsOfDirectory(at: pdfDirectory, includingPropertiesForKeys: [.creationDateKey], options: []) {
            for file in files where file.pathExtension.lowercased() == "pdf" {
                let values = try? file.resourceValues(forKeys: [.creationDateKey])
                if let created = values?.creationDate, created < pdfCutoff {
                    try? manager.removeItem(at: file)
                }
            }
        }

        historySummaries.sort { $0.createdAt > $1.createdAt }
        if changed && saveAfterCleanup { saveLocalSummaryHistory() }
    }

    private func parseISODate(_ value: String?) -> Date? {
        guard let value else { return nil }
        let iso = ISO8601DateFormatter()
        if let date = iso.date(from: value) { return date }
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSXXXXX"
        return formatter.date(from: value)
    }
}

func cleanMarkdownForPlainText(_ text: String) -> String {
    text
        .replacingOccurrences(of: "**", with: "")
        .replacingOccurrences(of: #"(?m)^\s*#{1,6}\s*"#, with: "", options: .regularExpression)
        .trimmingCharacters(in: .whitespacesAndNewlines)
}
