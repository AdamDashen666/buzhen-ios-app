# Changelog

## 0.2.9 - iPad Splash Unlock Fix
- Fixed a WKWebView/iPad issue where the original Mineradio splash screen could become impossible to enter with touch or mouse after the v0.2.8 drag-selection prevention changes.
- Added direct touchend, pointerup, mouseup, and click splash unlock handlers without changing the original visual splash design.
- Added a fallback that removes the splash overlay if the original dismiss function is not reachable.

## 0.2.8 - Stability and Interaction Audit
- Added deeper iOS text cleanup for local songs so large stage titles also remove UUID prefixes and `- 本地` / `- 本地文件` suffixes.
- Hardened hidden API entry removal so the old bottom-left API button cannot reopen a modal.
- Added document-level file-input detection to make audio-only document picker filtering more reliable.
- Improved touch/camera adaptation by dispatching both pointer and mouse events and reinstalling the adapter when the original WebGL canvas is recreated.
- Added iPad viewport and drag-selection stability patches in the downloaded original web bundle.
- Made the build-time patch script more tolerant of upstream Mineradio whitespace/limit changes.

## 0.2.7 - Audio Terrain Preset
- Added an iOS-only `音域回响` / Audio Terrain visual preset inspired by the 3D audio landscape effect.
- Injected a Three.js terrain point field with audio-reactive height, warm center glow, blue outer sound field, fog/vignette, floating title, auto camera orbit, mouse and touch camera drag, and wheel/pinch zoom.
- Added a preset card into the original visual console when the preset list is available, plus a small `音域` toggle chip.
- Fixed missing iOS runtime helper functions used by the touch/mouse selection guards.
- Improved resume handling after returning from background by remembering playback state and trying to restart Web audio playback when visible again.
- Kept the original Mineradio web frontend as the base; this version only adds an iPad compatibility/effect layer.

## 0.2.6 - iPad Interaction and Playback Fixes
- Removed the visible iOS API configuration modal/button while preserving previously stored API base support.
- Added iOS background audio entitlement and AVAudioSession playback activation to reduce silent playback after returning from background.
- Added global iPad touch adapter for one-finger camera/orbit drag and two-finger zoom.
- Prevented iPad mouse/touch dragging from selecting the whole WebView page.
- Cleaned local-track UI labels so titles do not show UUID prefixes or "- 本地文件".
- Filtered the main document picker to audio formats by default, with separate image/video handling for background inputs.
- Raised the cover-particle resolution ceiling to about 10x the original particle count and exposed a higher max slider range.
- Added iOS visibility stabilization for the "安魂"/skull preset so it is not effectively invisible on iPad.


## 0.2.5 - Local Artwork and Full FX Bridge
- Preserved original imported audio filenames instead of adding UUID prefixes, so local track titles no longer show long temporary IDs.
- Added native AVFoundation metadata reading for local audio artwork; embedded album covers are injected back into the original Mineradio visual pipeline as custom covers.
- Forced original DIY / FX mode on by default for the iOS WebView shell, so the original effect controls are visible instead of staying in simplified mode.
- Rewrote relative `/api/*` image, audio, fetch, and XHR requests to the configured API base, covering cover proxy and audio proxy URLs in addition to QR/search calls.
- Kept the original Mineradio `public/index.html` visual layer untouched; all changes are iOS bridge compatibility fixes.

## 0.2.4 - API Base configuration panel
- Fixed QR login blank/load-failed flow caused by iPad using `127.0.0.1:3000` as the API host.
- Added an in-WebView iOS API configuration panel behind a small `API` button.
- `/api/...` calls now fail with a clear setup prompt when no Mineradio API Base is configured.
- Updated docs to recommend running the original Mineradio `server.js` on a LAN-accessible host.
- Visual layer remains the original Mineradio Web frontend; this change only touches the iOS bridge.

## 0.2.3 - Swift raw string compile fix
- Fixed `ContentView.swift` raw string terminator for the injected Mineradio iOS bridge script.
- Keeps the original Mineradio Web/WKWebView direction unchanged.

## 0.2.2

- 修复 GitHub Actions / Xcode 26.6 编译失败：`WKOpenPanelParameters` 在 iOS 18.4+ 才公开可用。
- 给 WebKit 文件选择代理加 `@available(iOS 18.4, *)`，保持 iOS 17 deployment target 可编译。
- 不改变原版 Mineradio Web 前端移植方向；视觉层仍走原 `public/index.html`。

## 0.2.0

- 彻底停止 SwiftUI 仿版方向。
- 改为 WKWebView 原版前端移植：构建时下载并打包 `XxHuberrr/Mineradio/public`。
- 加入 Electron `window.desktopWindow` 兼容桥，让原版桌面 shell / fullscreen 相关逻辑能走。
- 保留原版 `three.js / gsap / music-tempo / index.html` 视觉链路。
- 加入 iOS 文件选择桥，兼容原版 `<input type="file">` 导入音乐 / 封面。
- `/api/...` 请求桥接到可配置 API Base，默认 `http://127.0.0.1:3000`。

## 0.1.4

- 旧 SwiftUI 仿版，已废弃。
