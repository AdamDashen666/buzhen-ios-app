import AVFoundation
import SwiftUI
import UIKit

@main
struct MineradioiOSApp: App {
    @Environment(\.scenePhase) private var scenePhase

    var body: some Scene {
        WindowGroup {
            MineradioOriginalRootView()
                .ignoresSafeArea()
                .background(Color.black)
                .preferredColorScheme(.dark)
                .persistentSystemOverlays(.hidden)
                .onAppear {
                    UIApplication.shared.isIdleTimerDisabled = true
                    MineradioAudioSession.activate()
                }
                .onChange(of: scenePhase) { phase in
                    if phase == .active || phase == .background {
                        MineradioAudioSession.activate()
                    }
                }
        }
    }
}

struct MineradioOriginalRootView: View {
    var body: some View {
        MineradioWebShellView()
            .ignoresSafeArea()
            .background(Color.black)
            .statusBar(hidden: true)
    }
}


enum MineradioAudioSession {
    static func activate() {
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default, options: [.allowAirPlay, .allowBluetoothHFP])
            try AVAudioSession.sharedInstance().setActive(true)
        } catch {
            #if DEBUG
            print("Mineradio audio session activation failed:", error)
            #endif
        }
    }
}
