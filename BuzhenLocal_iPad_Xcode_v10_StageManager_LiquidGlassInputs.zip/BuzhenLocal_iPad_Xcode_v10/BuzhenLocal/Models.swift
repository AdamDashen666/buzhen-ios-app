import Foundation
import AVFoundation
import Vision

enum OpticalFlowQuality: String, CaseIterable, Identifiable {
    case fast
    case balanced
    case high
    case extreme
    case antiBlur

    var id: String { rawValue }

    var title: String {
        switch self {
        case .fast:
            return "1 快速"
        case .balanced:
            return "2 平衡"
        case .high:
            return "3 高质量"
        case .extreme:
            return "4 极限光流"
        case .antiBlur:
            return "5 抗模糊极限"
        }
    }

    var subtitle: String {
        switch self {
        case .fast:
            return "低精度光流，速度优先"
        case .balanced:
            return "中精度光流，速度/质量折中"
        case .high:
            return "高精度光流，画质优先"
        case .extreme:
            return "最高精度 + 更高码率，最慢"
        case .antiBlur:
            return "最高精度光流 + 降低双帧混合拖影 + 轻锐化，适合高速运动"
        }
    }

    var visionAccuracy: VNGenerateOpticalFlowRequest.ComputationAccuracy {
        switch self {
        case .fast:
            return .low
        case .balanced:
            return .medium
        case .high:
            return .high
        case .extreme, .antiBlur:
            return .veryHigh
        }
    }

    var bitrateMultiplier: Double {
        switch self {
        case .fast:
            return 1.00
        case .balanced:
            return 1.25
        case .high:
            return 1.50
        case .extreme:
            return 1.85
        case .antiBlur:
            return 2.15
        }
    }

    var blendStrength: Float {
        switch self {
        case .fast:
            return 1.00
        case .balanced:
            return 0.92
        case .high:
            return 0.82
        case .extreme:
            return 0.70
        case .antiBlur:
            return 0.48
        }
    }

    var sharpenAmount: Float {
        switch self {
        case .fast:
            return 0.00
        case .balanced:
            return 0.03
        case .high:
            return 0.08
        case .extreme:
            return 0.12
        case .antiBlur:
            return 0.20
        }
    }
}

enum ProcessingMode: String, CaseIterable, Identifiable {
    case full
    case serialSegmented
    case parallelSegmented

    var id: String { rawValue }

    var title: String {
        switch self {
        case .full:
            return "单次完整处理"
        case .serialSegmented:
            return "串行分段处理"
        case .parallelSegmented:
            return "并行分段处理"
        }
    }

    var subtitle: String {
        switch self {
        case .full:
            return "最简单，但长视频更容易爆内存"
        case .serialSegmented:
            return "稳定优先，适合 iPad 长视频"
        case .parallelSegmented:
            return "速度优先，发热/内存压力更高"
        }
    }
}

enum OutputMode: String, CaseIterable, Identifiable {
    case appleHEVC
    case h264Compatible
    case hdrPreserve

    var id: String { rawValue }

    var title: String {
        switch self {
        case .appleHEVC:
            return "Apple HEVC 兼容"
        case .h264Compatible:
            return "H.264 最稳兼容"
        case .hdrPreserve:
            return "HDR 保留模式"
        }
    }

    var fileType: AVFileType {
        switch self {
        case .appleHEVC, .hdrPreserve:
            return .mov
        case .h264Compatible:
            return .mp4
        }
    }

    var fileExtension: String {
        switch self {
        case .appleHEVC, .hdrPreserve:
            return "mov"
        case .h264Compatible:
            return "mp4"
        }
    }

    var codec: AVVideoCodecType {
        switch self {
        case .appleHEVC, .hdrPreserve:
            return .hevc
        case .h264Compatible:
            return .h264
        }
    }

    var wantsHDR: Bool {
        self == .hdrPreserve
    }
}

enum BitrateMode: String, CaseIterable, Identifiable {
    case automatic
    case customMbps

    var id: String { rawValue }

    var title: String {
        switch self {
        case .automatic:
            return "自动推荐"
        case .customMbps:
            return "手动 Mbps"
        }
    }
}

struct ProcessingOptions: Sendable {
    let targetFPS: Double
    let quality: OpticalFlowQuality
    let processingMode: ProcessingMode
    let segmentSeconds: Double
    let maxParallelJobs: Int
    let outputMode: OutputMode
    let bitrateMode: BitrateMode
    let customBitrateMbps: Double
    let keepAudio: Bool
    let keepMetadata: Bool
    let preserveHDRTags: Bool
}

struct VideoFrame {
    let pixelBuffer: CVPixelBuffer
    let pts: CMTime
}

struct SegmentJob: Sendable {
    let index: Int
    let start: Double
    let duration: Double
}
