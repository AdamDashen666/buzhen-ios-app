import Foundation
import AVFoundation
import CoreMedia
import CoreVideo
import VideoToolbox

final class VideoFrameInterpolator {
    typealias ProgressHandler = @Sendable (Double, String) -> Void

    func interpolate(
        inputURL: URL,
        options: ProcessingOptions,
        progress: @escaping ProgressHandler
    ) async throws -> URL {
        switch options.processingMode {
        case .full:
            let output = try makeOutputURL(prefix: "buzhen_full", mode: options.outputMode)
            return try await processFullVideo(
                inputURL: inputURL,
                outputURL: output,
                options: options,
                progressBase: 0,
                progressSpan: 1,
                progress: progress
            )

        case .serialSegmented:
            return try await processSegmented(
                inputURL: inputURL,
                options: options,
                parallel: false,
                progress: progress
            )

        case .parallelSegmented:
            return try await processSegmented(
                inputURL: inputURL,
                options: options,
                parallel: true,
                progress: progress
            )
        }
    }

    private static func effectiveSourceDuration(sourceDuration: Double, options: ProcessingOptions) -> Double {
        let sourceDuration = max(sourceDuration, 0.05)
        let factor = min(max(options.slowMotionFactor, 0.01), 1.0)
        let requestedOutputSeconds = max(0, options.slowMotionOutputSeconds)

        guard factor < 0.999, requestedOutputSeconds > 0 else {
            return sourceDuration
        }

        return min(sourceDuration, max(0.05, requestedOutputSeconds * factor))
    }

    private static func effectiveSourceStart(sourceDuration: Double, options: ProcessingOptions) -> Double {
        let sourceDuration = max(sourceDuration, 0.05)
        let factor = min(max(options.slowMotionFactor, 0.01), 1.0)
        guard factor < 0.999, options.slowMotionOutputSeconds > 0 else {
            return 0
        }
        let requestedStart = max(0, options.slowMotionOutputStartSeconds) * factor
        let effectiveDuration = effectiveSourceDuration(sourceDuration: sourceDuration, options: options)
        return min(max(0, requestedStart), max(0, sourceDuration - effectiveDuration))
    }


    private static func speedFactor(
        atRelativeSourceTime relativeTime: Double,
        nodes: [SpeedCurveNode],
        fallback: Double
    ) -> Double {
        let fallback = min(max(fallback, 0.01), 10.0)
        let nodes = nodes
            .map { SpeedCurveNode(id: $0.id, time: max(0, $0.time), speed: min(max($0.speed, 0.01), 10.0)) }
            .sorted { $0.time < $1.time }

        guard let first = nodes.first else {
            return fallback
        }

        if relativeTime <= first.time {
            return first.speed
        }

        guard let last = nodes.last else {
            return fallback
        }

        if relativeTime >= last.time {
            return last.speed
        }

        for index in 0..<(nodes.count - 1) {
            let a = nodes[index]
            let b = nodes[index + 1]

            if relativeTime >= a.time && relativeTime <= b.time {
                let span = max(b.time - a.time, 0.0001)
                let rawT = min(max((relativeTime - a.time) / span, 0), 1)
                let t = rawT * rawT * (3.0 - 2.0 * rawT)
                // 用 smoothstep + log 插值，避免节点之间变成硬直线。
                let logA = log10(min(max(a.speed, 0.01), 10.0))
                let logB = log10(min(max(b.speed, 0.01), 10.0))
                return pow(10.0, logA + (logB - logA) * t)
            }
        }

        return fallback
    }

    private func processFullVideo(
        inputURL: URL,
        outputURL: URL,
        options: ProcessingOptions,
        progressBase: Double,
        progressSpan: Double,
        progress: @escaping ProgressHandler
    ) async throws -> URL {
        let videoOnly = try makeTempURL(prefix: "buzhen_video_only", ext: options.outputMode.fileExtension)

        let info = try await VideoInspector.inspect(url: inputURL)
        let effectiveDuration = Self.effectiveSourceDuration(sourceDuration: info.duration, options: options)
        let effectiveStart = Self.effectiveSourceStart(sourceDuration: info.duration, options: options)
        let segment = SegmentJob(index: 0, start: effectiveStart, duration: effectiveDuration)
        progress(progressBase, "SEGMENT_SETUP|1|1|full")

        try await processSegmentVideoOnly(
            inputURL: inputURL,
            segment: segment,
            outputURL: videoOnly,
            options: options,
            progressBase: progressBase,
            progressSpan: progressSpan * 0.92,
            progress: progress
        )

        progress(progressBase + progressSpan * 0.94, "STAGE|合并音频/元数据...")

        let muxed = try await muxAudioAndMetadata(
            originalURL: inputURL,
            processedVideoURL: videoOnly,
            outputURL: outputURL,
            options: options
        )

        try? FileManager.default.removeItem(at: videoOnly)
        progress(progressBase + progressSpan, "STAGE|完成")
        return muxed
    }

    private func processSegmented(
        inputURL: URL,
        options: ProcessingOptions,
        parallel: Bool,
        progress: @escaping ProgressHandler
    ) async throws -> URL {
        progress(0.01, "读取视频信息...")

        let info = try await VideoInspector.inspect(url: inputURL)
        let effectiveDuration = Self.effectiveSourceDuration(sourceDuration: info.duration, options: options)
        let effectiveStart = Self.effectiveSourceStart(sourceDuration: info.duration, options: options)
        let segmentSeconds = max(0.25, options.segmentSeconds)
        let count = max(1, Int(ceil(effectiveDuration / segmentSeconds)))
        let tempDir = FileManager.default.temporaryDirectory
            .appendingPathComponent("buzhen_segments_\(UUID().uuidString)", isDirectory: true)

        try FileManager.default.createDirectory(at: tempDir, withIntermediateDirectories: true)

        let outputURL = try makeOutputURL(prefix: "buzhen_segmented", mode: options.outputMode)

        defer {
            try? FileManager.default.removeItem(at: tempDir)
        }

        let jobs: [SegmentJob] = (0..<count).map { index in
            let relativeStart = Double(index) * segmentSeconds
            let start = effectiveStart + relativeStart
            let remaining = max(0.05, effectiveDuration - relativeStart)
            let duration = min(segmentSeconds, remaining)
            return SegmentJob(index: index, start: start, duration: duration)
        }

        let segmentOutputs = jobs.map {
            tempDir
                .appendingPathComponent(String(format: "seg_%04d", $0.index))
                .appendingPathExtension(options.outputMode.fileExtension)
        }

        if parallel {
            let workers = min(max(1, options.maxParallelJobs), count)
            let tracker = SegmentProgressTracker(count: count)
            progress(0.02, "SEGMENT_SETUP|\(count)|\(workers)|parallel")

            try await withThrowingTaskGroup(of: Int.self) { group in
                var nextIndex = 0

                func submitNextJob() {
                    guard nextIndex < jobs.count else { return }
                    let job = jobs[nextIndex]
                    let out = segmentOutputs[job.index]
                    nextIndex += 1

                    group.addTask(priority: options.performanceMode.taskPriority) {
                        let startedSummary = await tracker.start(index: job.index)
                        progress(0.02 + 0.80 * startedSummary.average, "SEGMENT_START|\(job.index)|\(job.start)|\(job.duration)")

                        let processor = VideoFrameInterpolator()
                        do {
                            try await processor.processSegmentVideoOnly(
                                inputURL: inputURL,
                                segment: job,
                                outputURL: out,
                                options: options,
                                progressBase: 0,
                                progressSpan: 0,
                                progress: { localProgress, _ in
                                    Task {
                                        let summary = await tracker.update(index: job.index, local: localProgress)
                                        progress(0.02 + 0.80 * summary.average, "SEGMENT_PROGRESS|\(job.index)|\(localProgress)")
                                    }
                                }
                            )
                        } catch {
                            progress(0.02, "SEGMENT_FAILED|\(job.index)|\(error.localizedDescription)")
                            throw error
                        }

                        return job.index
                    }
                }

                for _ in 0..<workers {
                    submitNextJob()
                }

                while let finishedIndex = try await group.next() {
                    let summary = await tracker.complete(index: finishedIndex)
                    progress(0.02 + 0.80 * summary.average, "SEGMENT_DONE|\(finishedIndex)|\(summary.done)|\(count)")
                    submitNextJob()
                }
            }
        } else {
            progress(0.02, "SEGMENT_SETUP|\(count)|1|serial")

            for job in jobs {
                let base = 0.02 + 0.80 * Double(job.index) / Double(count)
                let span = 0.80 / Double(count)
                progress(base, "SEGMENT_START|\(job.index)|\(job.start)|\(job.duration)")

                try await processSegmentVideoOnly(
                    inputURL: inputURL,
                    segment: job,
                    outputURL: segmentOutputs[job.index],
                    options: options,
                    progressBase: base,
                    progressSpan: span,
                    progress: progress
                )
            }
        }

        progress(0.85, "STAGE|等待分段文件落盘...")
        try await waitForSegmentFiles(segmentOutputs)

        progress(0.86, "STAGE|合并所有视频段...")
        let joinedVideo = tempDir.appendingPathComponent("joined").appendingPathExtension(options.outputMode.fileExtension)
        try await joinSegments(segmentOutputs: segmentOutputs, outputURL: joinedVideo, outputMode: options.outputMode)

        progress(0.94, "STAGE|合并原音频/元数据...")
        let muxed = try await muxAudioAndMetadata(
            originalURL: inputURL,
            processedVideoURL: joinedVideo,
            outputURL: outputURL,
            options: options
        )

        progress(1.0, "STAGE|完成")
        return muxed
    }

    private func processSegmentVideoOnly(
        inputURL: URL,
        segment: SegmentJob,
        outputURL: URL,
        options: ProcessingOptions,
        progressBase: Double,
        progressSpan: Double,
        progress: @escaping ProgressHandler
    ) async throws {
        let asset = AVURLAsset(url: inputURL)
        let videoTracks = try await asset.loadTracks(withMediaType: .video)

        guard let videoTrack = videoTracks.first else {
            throw NSError(domain: "BuzhenLocal", code: 4001, userInfo: [NSLocalizedDescriptionKey: "没有找到视频轨道"])
        }

        let naturalSize = try await videoTrack.load(.naturalSize)
        let transform = try await videoTrack.load(.preferredTransform)

        let width = Int(abs(naturalSize.width))
        let height = Int(abs(naturalSize.height))

        if FileManager.default.fileExists(atPath: outputURL.path) {
            try FileManager.default.removeItem(at: outputURL)
        }

        let assetDuration = try await asset.load(.duration)
        let assetDurationSeconds = max(assetDuration.seconds.isFinite ? assetDuration.seconds : 0, segment.start + segment.duration)
        let nominalFPS = Double((try? await videoTrack.load(.nominalFrameRate)) ?? 0)
        let sourceFrameStep = nominalFPS.isFinite && nominalFPS > 1 ? 1.0 / nominalFPS : 1.0 / 30.0

        // 慢放 + 分段时，分段边界如果刚好切在两帧之间，reader 只读当前段会拿不到边界外的上一帧/下一帧。
        // 0.01x 慢放时，源视频少 1 帧就可能在输出里少 1 秒以上，所以这里给每段前后多读保护帧。
        // 输出仍严格 clamp 在 segment.start...segment.end，不会把保护帧输出成多余片段。
        let boundaryPadding = max(sourceFrameStep * 3.0, 0.08)
        let targetSourceStart = max(0, segment.start)
        let targetSourceEnd = min(assetDurationSeconds, segment.start + segment.duration)
        let paddedReadStart = max(0, targetSourceStart - boundaryPadding)
        let paddedReadEnd = min(assetDurationSeconds, targetSourceEnd + boundaryPadding)
        let paddedReadDuration = max(0.05, paddedReadEnd - paddedReadStart)

        let reader = try AVAssetReader(asset: asset)
        reader.timeRange = CMTimeRange(
            start: CMTime(seconds: paddedReadStart, preferredTimescale: 600),
            duration: CMTime(seconds: paddedReadDuration, preferredTimescale: 600)
        )

        let readerOutput = AVAssetReaderTrackOutput(
            track: videoTrack,
            outputSettings: [
                kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA,
                kCVPixelBufferMetalCompatibilityKey as String: true
            ]
        )
        readerOutput.alwaysCopiesSampleData = false

        guard reader.canAdd(readerOutput) else {
            throw NSError(domain: "BuzhenLocal", code: 4002, userInfo: [NSLocalizedDescriptionKey: "无法创建视频读取器"])
        }
        reader.add(readerOutput)

        let writer = try AVAssetWriter(outputURL: outputURL, fileType: options.outputMode.fileType)
        let writerInput = AVAssetWriterInput(mediaType: .video, outputSettings: makeVideoSettings(width: width, height: height, options: options))
        writerInput.expectsMediaDataInRealTime = false
        writerInput.transform = transform

        let adaptor = AVAssetWriterInputPixelBufferAdaptor(
            assetWriterInput: writerInput,
            sourcePixelBufferAttributes: [
                kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA,
                kCVPixelBufferWidthKey as String: width,
                kCVPixelBufferHeightKey as String: height,
                kCVPixelBufferMetalCompatibilityKey as String: true,
                kCVPixelBufferIOSurfacePropertiesKey as String: [:]
            ]
        )

        guard writer.canAdd(writerInput) else {
            throw NSError(domain: "BuzhenLocal", code: 4003, userInfo: [NSLocalizedDescriptionKey: "无法创建视频写入器"])
        }
        writer.add(writerInput)

        guard reader.startReading() else {
            throw reader.error ?? NSError(domain: "BuzhenLocal", code: 4004, userInfo: [NSLocalizedDescriptionKey: "读取视频失败"])
        }

        guard writer.startWriting() else {
            throw writer.error ?? NSError(domain: "BuzhenLocal", code: 4005, userInfo: [NSLocalizedDescriptionKey: "写入视频失败"])
        }
        writer.startSession(atSourceTime: .zero)

        try await Self.prewarmEncoderIfNeeded(
            segment: segment,
            writer: writer,
            input: writerInput,
            width: width,
            height: height,
            options: options
        )

        let renderer = try MetalFrameRenderer()
        let estimator = VisionFlowEstimator()

        guard let first = copyNextFrame(from: readerOutput) else {
            writerInput.markAsFinished()
            await writer.finishWritingAsync()
            return
        }

        var current = first
        var outputSourceTime = targetSourceStart
        let firstSourceTime = targetSourceStart
        let outputStep = 1.0 / max(1, options.targetFPS)
        let constantSpeedFactor = min(max(options.slowMotionFactor, 0.01), 10.0)
        let hasSpeedCurve = !options.speedCurveNodes.isEmpty
        let curveOriginSourceTime = Self.effectiveSourceStart(sourceDuration: assetDurationSeconds, options: options)
        let minSourceStep = outputStep * 0.01
        let outputTimescale = Self.outputTimescale(for: options.targetFPS)
        var outputFrameIndex = 0
        var lastWrittenSourceTime = targetSourceStart
        let progressEmitInterval = max(8, Int(options.targetFPS / 4.0))

        while let next = copyNextFrame(from: readerOutput) {
            try Task.checkCancellation()

            let currentTime = CMTimeGetSeconds(current.pts)
            let nextTime = CMTimeGetSeconds(next.pts)
            let pairDuration = max(0.0001, nextTime - currentTime)

            let relation = analyzeFrameRelation(current.pixelBuffer, next.pixelBuffer)
            let treatAsDuplicate = options.enableDuplicateFrameDetection && relation.isDuplicate
            let treatAsSceneCut = options.enableSceneChangeDetection && relation.isSceneCut
            let shouldSkipOpticalFlow = treatAsDuplicate || treatAsSceneCut

            let flow: CVPixelBuffer?
            let reverseFlow: CVPixelBuffer?

            if shouldSkipOpticalFlow {
                flow = nil
                reverseFlow = nil
            } else {
                flow = try estimator.estimateFlow(
                    from: current.pixelBuffer,
                    to: next.pixelBuffer,
                    quality: options.quality
                )

                if options.quality.usesBidirectionalConsistency {
                    reverseFlow = try estimator.estimateFlow(
                        from: next.pixelBuffer,
                        to: current.pixelBuffer,
                        quality: options.quality
                    )
                } else {
                    reverseFlow = nil
                }
            }

            while outputSourceTime < nextTime && outputSourceTime < targetSourceEnd {
                try Task.checkCancellation()

                let alpha = min(max((outputSourceTime - currentTime) / pairDuration, 0), 1)
                let buffer: CVPixelBuffer

                if alpha <= 0.0001 || treatAsDuplicate {
                    buffer = current.pixelBuffer
                } else if treatAsSceneCut {
                    buffer = alpha < 0.5 ? current.pixelBuffer : next.pixelBuffer
                } else if let flow, let reverseFlow {
                    buffer = try await renderer.renderBidirectionalOpticalFlowBlend(
                        previous: current.pixelBuffer,
                        next: next.pixelBuffer,
                        forwardFlow: flow,
                        reverseFlow: reverseFlow,
                        alpha: Float(alpha),
                        quality: options.quality,
                        pixelBufferPool: adaptor.pixelBufferPool
                    )
                } else if let flow {
                    buffer = try await renderer.renderOpticalFlowBlend(
                        previous: current.pixelBuffer,
                        next: next.pixelBuffer,
                        flow: flow,
                        alpha: Float(alpha),
                        quality: options.quality,
                        pixelBufferPool: adaptor.pixelBufferPool
                    )
                } else {
                    buffer = current.pixelBuffer
                }

                let presentation = CMTime(
                    seconds: max(0, Double(outputFrameIndex) * outputStep),
                    preferredTimescale: outputTimescale
                )

                try await append(buffer, to: adaptor, input: writerInput, writer: writer, time: presentation)
                lastWrittenSourceTime = outputSourceTime

                outputFrameIndex += 1
                let relativeCurveTime = max(0, outputSourceTime - curveOriginSourceTime)
                let speedFactor = hasSpeedCurve
                    ? Self.speedFactor(atRelativeSourceTime: relativeCurveTime, nodes: options.speedCurveNodes, fallback: constantSpeedFactor)
                    : constantSpeedFactor
                outputSourceTime += outputStep * speedFactor

                if outputFrameIndex % progressEmitInterval == 0 {
                    let local = min(1, max(0, (outputSourceTime - firstSourceTime) / max(targetSourceEnd - targetSourceStart, 0.001)))
                    let emittedProgress = progressSpan > 0 ? progressBase + progressSpan * local : local
                    progress(emittedProgress, "SEGMENT_PROGRESS|\(segment.index)|\(local)")
                }
            }

            current = next

            if outputSourceTime >= targetSourceEnd {
                break
            }
        }

        if outputFrameIndex == 0 || lastWrittenSourceTime < targetSourceEnd - minSourceStep * 0.25 {
            let lastPresentation = CMTime(
                seconds: max(0, Double(outputFrameIndex) * outputStep),
                preferredTimescale: outputTimescale
            )
            try await append(current.pixelBuffer, to: adaptor, input: writerInput, writer: writer, time: lastPresentation)
        }

        writerInput.markAsFinished()
        await writer.finishWritingAsync()

        let completedProgress = progressSpan > 0 ? progressBase + progressSpan : 1
        progress(completedProgress, "SEGMENT_DONE|\(segment.index)|0|0")

        if writer.status != .completed {
            let detail = writer.error?.localizedDescription ?? "AVAssetWriter 未完成，状态：\(writer.status.rawValue)"
            throw NSError(domain: "BuzhenLocal", code: 4007, userInfo: [
                NSLocalizedDescriptionKey: "写入结束失败：\(detail)"
            ])
        }
    }


    private struct FrameRelation {
        let averageLumaDelta: Double
        let isDuplicate: Bool
        let isSceneCut: Bool
        let isHighMotion: Bool
    }

    private func analyzeFrameRelation(_ first: CVPixelBuffer, _ second: CVPixelBuffer) -> FrameRelation {
        let width = min(CVPixelBufferGetWidth(first), CVPixelBufferGetWidth(second))
        let height = min(CVPixelBufferGetHeight(first), CVPixelBufferGetHeight(second))
        guard width > 0, height > 0 else {
            return FrameRelation(averageLumaDelta: 0, isDuplicate: false, isSceneCut: false, isHighMotion: false)
        }

        CVPixelBufferLockBaseAddress(first, .readOnly)
        CVPixelBufferLockBaseAddress(second, .readOnly)
        defer {
            CVPixelBufferUnlockBaseAddress(first, .readOnly)
            CVPixelBufferUnlockBaseAddress(second, .readOnly)
        }

        guard let baseA = CVPixelBufferGetBaseAddress(first),
              let baseB = CVPixelBufferGetBaseAddress(second) else {
            return FrameRelation(averageLumaDelta: 0, isDuplicate: false, isSceneCut: false, isHighMotion: false)
        }

        let rowA = CVPixelBufferGetBytesPerRow(first)
        let rowB = CVPixelBufferGetBytesPerRow(second)
        let stepX = max(8, width / 64)
        let stepY = max(8, height / 64)

        var totalDelta = 0.0
        var count = 0.0

        for y in stride(from: 0, to: height, by: stepY) {
            let pointerA = baseA.advanced(by: y * rowA).assumingMemoryBound(to: UInt8.self)
            let pointerB = baseB.advanced(by: y * rowB).assumingMemoryBound(to: UInt8.self)

            for x in stride(from: 0, to: width, by: stepX) {
                let offset = x * 4

                let bA = Double(pointerA[offset])
                let gA = Double(pointerA[offset + 1])
                let rA = Double(pointerA[offset + 2])

                let bB = Double(pointerB[offset])
                let gB = Double(pointerB[offset + 1])
                let rB = Double(pointerB[offset + 2])

                let lumaA = 0.2126 * rA + 0.7152 * gA + 0.0722 * bA
                let lumaB = 0.2126 * rB + 0.7152 * gB + 0.0722 * bB
                totalDelta += abs(lumaA - lumaB)
                count += 1
            }
        }

        let average = count > 0 ? totalDelta / count : 0
        return FrameRelation(
            averageLumaDelta: average,
            isDuplicate: average < 1.25,
            isSceneCut: average > 42.0,
            isHighMotion: average > 24.0
        )
    }

    private static func shouldRetryWithEncoderSafePlan(_ error: Error) -> Bool {
        let text = error.localizedDescription.lowercased()
        return text.contains("写入") ||
            text.contains("writer") ||
            text.contains("cannot complete") ||
            text.contains("avassetwriter") ||
            text.contains("operation could not be completed")
    }

    private static func prewarmEncoderIfNeeded(
        segment: SegmentJob,
        writer: AVAssetWriter,
        input: AVAssetWriterInput,
        width: Int,
        height: Int,
        options: ProcessingOptions
    ) async throws {
        let megapixels = Double(max(width, 1) * max(height, 1)) / 1_000_000.0
        let highRisk =
            options.outputMode == .hdrPreserve ||
            options.outputMode == .appleHEVC ||
            options.targetFPS >= 120 ||
            options.quality == .supremeAI ||
            megapixels >= 4.0

        let _ = highRisk

        var spins = 0
        while !input.isReadyForMoreMediaData && spins < 160 {
            try Task.checkCancellation()

            if writer.status == .failed || writer.status == .cancelled || writer.status == .completed {
                let detail = writer.error?.localizedDescription ?? "AVAssetWriter 状态异常：\(writer.status.rawValue)"
                throw NSError(domain: "BuzhenLocal", code: 4010, userInfo: [
                    NSLocalizedDescriptionKey: "编码器初始化失败：\(detail)"
                ])
            }

            spins += 1
            try await Task.sleep(nanoseconds: 10_000_000)
        }
    }

    private static func outputTimescale(for fps: Double) -> CMTimeScale {
        let roundedFPS = max(1, Int(fps.rounded()))
        if roundedFPS > 0 && roundedFPS <= 240 {
            return CMTimeScale(max(600, roundedFPS * 1000))
        }

        return 60_000
    }

    private static func encoderStartupStaggerNanoseconds(width: Int, height: Int, options: ProcessingOptions) -> UInt64 {
        0
    }

    private func makeVideoSettings(width: Int, height: Int, options: ProcessingOptions) -> [String: Any] {
        let bitrate = bitrate(width: width, height: height, options: options)

        var compression: [String: Any] = [
            AVVideoAverageBitRateKey: bitrate,
            AVVideoExpectedSourceFrameRateKey: Int(options.targetFPS),
            AVVideoMaxKeyFrameIntervalKey: Int(options.targetFPS),
            AVVideoMaxKeyFrameIntervalDurationKey: 1,
            AVVideoAllowFrameReorderingKey: false
        ]

        if options.outputMode == .hdrPreserve && options.preserveHDRTags {
            compression[AVVideoProfileLevelKey] = kVTProfileLevel_HEVC_Main10_AutoLevel
        }

        var settings: [String: Any] = [
            AVVideoCodecKey: options.outputMode.codec,
            AVVideoWidthKey: width,
            AVVideoHeightKey: height,
            AVVideoCompressionPropertiesKey: compression
        ]

        if options.outputMode == .hdrPreserve && options.preserveHDRTags {
            settings[AVVideoColorPropertiesKey] = [
                AVVideoColorPrimariesKey: AVVideoColorPrimaries_ITU_R_2020,
                AVVideoTransferFunctionKey: AVVideoTransferFunction_SMPTE_ST_2084_PQ,
                AVVideoYCbCrMatrixKey: AVVideoYCbCrMatrix_ITU_R_2020
            ]
        } else {
            settings[AVVideoColorPropertiesKey] = [
                AVVideoColorPrimariesKey: AVVideoColorPrimaries_ITU_R_709_2,
                AVVideoTransferFunctionKey: AVVideoTransferFunction_ITU_R_709_2,
                AVVideoYCbCrMatrixKey: AVVideoYCbCrMatrix_ITU_R_709_2
            ]
        }

        return settings
    }

    private func bitrate(width: Int, height: Int, options: ProcessingOptions) -> Int {
        if options.bitrateMode == .customMbps {
            return max(1, Int(options.customBitrateMbps * 1_000_000))
        }

        let pixelsPerSecond = Double(width * height) * options.targetFPS
        let bppf: Double

        switch options.outputMode {
        case .h264Compatible:
            bppf = 0.13
        case .appleHEVC:
            bppf = 0.15
        case .hdrPreserve:
            bppf = 0.17
        }

        let raw = pixelsPerSecond * bppf * options.quality.bitrateMultiplier
        let floor: Double = options.outputMode == .hdrPreserve ? 70_000_000 : 45_000_000

        let cap: Double
        if options.outputMode == .hdrPreserve && options.targetFPS >= 180 {
            cap = 240_000_000
        } else if options.outputMode == .hdrPreserve {
            cap = 380_000_000
        } else {
            cap = 300_000_000
        }

        return Int(min(max(raw, floor), cap))
    }

    private func copyNextFrame(from output: AVAssetReaderTrackOutput) -> VideoFrame? {
        guard let sampleBuffer = output.copyNextSampleBuffer(),
              let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else {
            return nil
        }

        return VideoFrame(
            pixelBuffer: pixelBuffer,
            pts: CMSampleBufferGetPresentationTimeStamp(sampleBuffer)
        )
    }

    private func append(
        _ pixelBuffer: CVPixelBuffer,
        to adaptor: AVAssetWriterInputPixelBufferAdaptor,
        input: AVAssetWriterInput,
        writer: AVAssetWriter,
        time: CMTime
    ) async throws {
        while !input.isReadyForMoreMediaData {
            try Task.checkCancellation()

            if writer.status == .failed || writer.status == .cancelled || writer.status == .completed {
                let detail = writer.error?.localizedDescription ?? "AVAssetWriter 状态异常：\(writer.status.rawValue)"
                throw NSError(domain: "BuzhenLocal", code: 4006, userInfo: [
                    NSLocalizedDescriptionKey: "写入帧失败：\(detail)"
                ])
            }

            try await Task.sleep(nanoseconds: 1_000_000)
        }

        guard adaptor.append(pixelBuffer, withPresentationTime: time) else {
            let seconds = CMTimeGetSeconds(time)
            let detail = writer.error?.localizedDescription ?? "writerStatus=\(writer.status.rawValue), time=\(String(format: "%.3f", seconds))"
            throw NSError(domain: "BuzhenLocal", code: 4006, userInfo: [
                NSLocalizedDescriptionKey: "写入帧失败：\(detail)"
            ])
        }
    }

    private func waitForSegmentFiles(_ urls: [URL]) async throws {
        let fileManager = FileManager.default

        for attempt in 0..<30 {
            var missing: [String] = []
            var tooSmall: [String] = []

            for url in urls {
                if !fileManager.fileExists(atPath: url.path) {
                    missing.append(url.lastPathComponent)
                    continue
                }

                let size = (try? fileManager.attributesOfItem(atPath: url.path)[.size] as? NSNumber)?.int64Value ?? 0
                if size < 2048 {
                    tooSmall.append(url.lastPathComponent)
                }
            }

            if missing.isEmpty && tooSmall.isEmpty {
                if attempt > 0 {
                    try await Task.sleep(nanoseconds: 180_000_000)
                }
                return
            }

            try await Task.sleep(nanoseconds: 120_000_000)
        }

        throw NSError(domain: "BuzhenLocal", code: 5000, userInfo: [
            NSLocalizedDescriptionKey: "分段文件尚未完全写入，无法开始合并。"
        ])
    }

    private func joinSegments(
        segmentOutputs: [URL],
        outputURL: URL,
        outputMode: OutputMode
    ) async throws {
        let validSegments = try await validatedSegmentURLs(segmentOutputs)

        guard !validSegments.isEmpty else {
            throw NSError(domain: "BuzhenLocal", code: 5001, userInfo: [
                NSLocalizedDescriptionKey: "没有可合并的视频分段。"
            ])
        }

        if validSegments.count > 12 {
            try await joinSegmentsInBatches(
                segmentOutputs: validSegments,
                outputURL: outputURL,
                outputMode: outputMode,
                batchSize: 8
            )
            return
        }

        try await joinSegmentsDirect(segmentOutputs: validSegments, outputURL: outputURL, outputMode: outputMode)
    }

    private func validatedSegmentURLs(_ urls: [URL]) async throws -> [URL] {
        var result: [URL] = []

        for url in urls {
            guard FileManager.default.fileExists(atPath: url.path) else { continue }

            let size = (try? FileManager.default.attributesOfItem(atPath: url.path)[.size] as? NSNumber)?.int64Value ?? 0
            guard size > 2048 else { continue }

            var didLoad = false
            var lastError: Error?

            for _ in 0..<8 {
                do {
                    let asset = AVURLAsset(url: url)
                    let tracks = try await asset.loadTracks(withMediaType: .video)
                    let duration = try await asset.load(.duration)

                    if !tracks.isEmpty && duration.seconds.isFinite && duration.seconds > 0 {
                        didLoad = true
                        break
                    }
                } catch {
                    lastError = error
                }

                try await Task.sleep(nanoseconds: 120_000_000)
            }

            if didLoad {
                result.append(url)
            } else if let lastError {
                throw NSError(domain: "BuzhenLocal", code: 5004, userInfo: [
                    NSLocalizedDescriptionKey: "无法打开分段文件 \(url.lastPathComponent)：\(lastError.localizedDescription)"
                ])
            }
        }

        return result
    }

    private func joinSegmentsInBatches(
        segmentOutputs: [URL],
        outputURL: URL,
        outputMode: OutputMode,
        batchSize: Int
    ) async throws {
        let tempDir = outputURL.deletingLastPathComponent()
        var intermediateURLs: [URL] = []

        for (batchIndex, startIndex) in stride(from: 0, to: segmentOutputs.count, by: max(2, batchSize)).enumerated() {
            let endIndex = min(segmentOutputs.count, startIndex + max(2, batchSize))
            let batch = Array(segmentOutputs[startIndex..<endIndex])
            let batchURL = tempDir
                .appendingPathComponent(String(format: "joined_batch_%03d", batchIndex))
                .appendingPathExtension(outputMode.fileExtension)

            try await joinSegmentsDirect(segmentOutputs: batch, outputURL: batchURL, outputMode: outputMode)
            intermediateURLs.append(batchURL)
            try await Task.sleep(nanoseconds: 150_000_000)
        }

        defer {
            for url in intermediateURLs {
                try? FileManager.default.removeItem(at: url)
            }
        }

        let checkedIntermediate = try await validatedSegmentURLs(intermediateURLs)
        try await joinSegmentsDirect(segmentOutputs: checkedIntermediate, outputURL: outputURL, outputMode: outputMode)
    }

    private func joinSegmentsDirect(
        segmentOutputs: [URL],
        outputURL: URL,
        outputMode: OutputMode
    ) async throws {
        var lastError: Error?

        for attempt in 0..<3 {
            do {
                try await exportJoinedSegments(segmentOutputs: segmentOutputs, outputURL: outputURL, outputMode: outputMode)
                return
            } catch {
                lastError = error
                try? FileManager.default.removeItem(at: outputURL)
                try await Task.sleep(nanoseconds: UInt64(250_000_000 * (attempt + 1)))
            }
        }

        throw lastError ?? NSError(domain: "BuzhenLocal", code: 5003, userInfo: [
            NSLocalizedDescriptionKey: "合并分段失败：未知错误"
        ])
    }

    private func exportJoinedSegments(
        segmentOutputs: [URL],
        outputURL: URL,
        outputMode: OutputMode
    ) async throws {
        if FileManager.default.fileExists(atPath: outputURL.path) {
            try FileManager.default.removeItem(at: outputURL)
        }

        let composition = AVMutableComposition()
        guard let compVideo = composition.addMutableTrack(
            withMediaType: .video,
            preferredTrackID: kCMPersistentTrackID_Invalid
        ) else {
            throw NSError(domain: "BuzhenLocal", code: 5001, userInfo: [NSLocalizedDescriptionKey: "无法创建合并轨道"])
        }

        var cursor = CMTime.zero

        for url in segmentOutputs {
            let asset = AVURLAsset(url: url)
            let tracks = try await asset.loadTracks(withMediaType: .video)
            guard let videoTrack = tracks.first else { continue }
            let duration = try await asset.load(.duration)

            guard duration.seconds.isFinite && duration.seconds > 0 else { continue }

            try compVideo.insertTimeRange(
                CMTimeRange(start: .zero, duration: duration),
                of: videoTrack,
                at: cursor
            )

            cursor = cursor + duration
        }

        guard cursor.seconds.isFinite && cursor.seconds > 0 else {
            throw NSError(domain: "BuzhenLocal", code: 5005, userInfo: [
                NSLocalizedDescriptionKey: "分段时长无效，无法合并。"
            ])
        }

        guard let exporter = AVAssetExportSession(asset: composition, presetName: AVAssetExportPresetPassthrough) else {
            throw NSError(domain: "BuzhenLocal", code: 5002, userInfo: [NSLocalizedDescriptionKey: "无法创建分段合并器"])
        }

        exporter.outputURL = outputURL
        exporter.outputFileType = outputMode.fileType
        exporter.shouldOptimizeForNetworkUse = false

        await exporter.exportAsync()

        if exporter.status != .completed {
            let detail = exporter.error?.localizedDescription ?? "status=\(exporter.status.rawValue)"
            throw NSError(domain: "BuzhenLocal", code: 5003, userInfo: [
                NSLocalizedDescriptionKey: "合并分段失败：\(detail)"
            ])
        }

        let size = (try? FileManager.default.attributesOfItem(atPath: outputURL.path)[.size] as? NSNumber)?.int64Value ?? 0
        guard size > 2048 else {
            throw NSError(domain: "BuzhenLocal", code: 5006, userInfo: [
                NSLocalizedDescriptionKey: "合并输出为空。"
            ])
        }
    }

    private func muxAudioAndMetadata(
        originalURL: URL,
        processedVideoURL: URL,
        outputURL: URL,
        options: ProcessingOptions
    ) async throws -> URL {
        if !options.keepAudio && !options.keepMetadata {
            if FileManager.default.fileExists(atPath: outputURL.path) {
                try FileManager.default.removeItem(at: outputURL)
            }
            try FileManager.default.copyItem(at: processedVideoURL, to: outputURL)
            return outputURL
        }

        if FileManager.default.fileExists(atPath: outputURL.path) {
            try FileManager.default.removeItem(at: outputURL)
        }

        let originalAsset = AVURLAsset(url: originalURL)
        let processedAsset = AVURLAsset(url: processedVideoURL)

        var processedVideoTrack: AVAssetTrack?
        var processedDuration = CMTime.zero

        for _ in 0..<10 {
            do {
                processedVideoTrack = try await processedAsset.loadTracks(withMediaType: .video).first
                processedDuration = try await processedAsset.load(.duration)
                if processedVideoTrack != nil && processedDuration.seconds.isFinite && processedDuration.seconds > 0 {
                    break
                }
            } catch {
                try await Task.sleep(nanoseconds: 150_000_000)
            }

            try await Task.sleep(nanoseconds: 120_000_000)
        }

        guard let processedVideoTrack,
              processedDuration.seconds.isFinite,
              processedDuration.seconds > 0 else {
            try FileManager.default.copyItem(at: processedVideoURL, to: outputURL)
            return outputURL
        }

        let composition = AVMutableComposition()
        guard let videoTrack = composition.addMutableTrack(withMediaType: .video, preferredTrackID: kCMPersistentTrackID_Invalid) else {
            try FileManager.default.copyItem(at: processedVideoURL, to: outputURL)
            return outputURL
        }

        try videoTrack.insertTimeRange(
            CMTimeRange(start: .zero, duration: processedDuration),
            of: processedVideoTrack,
            at: .zero
        )

        if options.keepAudio,
           let sourceAudioTrack = try? await originalAsset.loadTracks(withMediaType: .audio).first,
           let compAudio = composition.addMutableTrack(withMediaType: .audio, preferredTrackID: kCMPersistentTrackID_Invalid) {
            let originalDuration = (try? await originalAsset.load(.duration)) ?? processedDuration
            let audioDuration = CMTimeMinimum(processedDuration, originalDuration)

            try? compAudio.insertTimeRange(
                CMTimeRange(start: .zero, duration: audioDuration),
                of: sourceAudioTrack,
                at: .zero
            )
        }

        let originalMetadata: [AVMetadataItem]
        if options.keepMetadata {
            originalMetadata = (try? await originalAsset.load(.metadata)) ?? []
        } else {
            originalMetadata = []
        }

        guard let exporter = AVAssetExportSession(asset: composition, presetName: AVAssetExportPresetPassthrough) else {
            try FileManager.default.copyItem(at: processedVideoURL, to: outputURL)
            return outputURL
        }

        if options.keepMetadata && !originalMetadata.isEmpty {
            exporter.metadata = originalMetadata
        }

        exporter.outputURL = outputURL
        exporter.outputFileType = options.outputMode.fileType
        exporter.shouldOptimizeForNetworkUse = false

        await exporter.exportAsync()

        if exporter.status == .completed {
            return outputURL
        }

        try? FileManager.default.removeItem(at: outputURL)
        try FileManager.default.copyItem(at: processedVideoURL, to: outputURL)
        return outputURL
    }

    private func makeOutputURL(prefix: String, mode: OutputMode) throws -> URL {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        let url = docs
            .appendingPathComponent("\(prefix)_\(Int(Date().timeIntervalSince1970))")
            .appendingPathExtension(mode.fileExtension)

        if FileManager.default.fileExists(atPath: url.path) {
            try FileManager.default.removeItem(at: url)
        }
        return url
    }

    private func makeTempURL(prefix: String, ext: String) throws -> URL {
        let url = FileManager.default.temporaryDirectory
            .appendingPathComponent("\(prefix)_\(UUID().uuidString)")
            .appendingPathExtension(ext)

        if FileManager.default.fileExists(atPath: url.path) {
            try FileManager.default.removeItem(at: url)
        }
        return url
    }
}

private actor SegmentProgressTracker {
    struct Summary: Sendable {
        let average: Double
        let done: Int
        let active: Int
    }

    private var values: [Double]
    private var doneFlags: [Bool]
    private var activeFlags: [Bool]

    init(count: Int) {
        self.values = Array(repeating: 0, count: max(0, count))
        self.doneFlags = Array(repeating: false, count: max(0, count))
        self.activeFlags = Array(repeating: false, count: max(0, count))
    }

    func start(index: Int) -> Summary {
        guard values.indices.contains(index) else { return summary() }
        activeFlags[index] = true
        values[index] = max(values[index], 0.01)
        return summary()
    }

    func update(index: Int, local: Double) -> Summary {
        guard values.indices.contains(index) else { return summary() }
        activeFlags[index] = true
        values[index] = max(values[index], min(max(local, 0), 1))
        return summary()
    }

    func complete(index: Int) -> Summary {
        guard values.indices.contains(index) else { return summary() }
        values[index] = 1
        doneFlags[index] = true
        activeFlags[index] = false
        return summary()
    }

    private func summary() -> Summary {
        guard !values.isEmpty else {
            return Summary(average: 0, done: 0, active: 0)
        }

        let average = values.reduce(0, +) / Double(values.count)
        let done = doneFlags.filter { $0 }.count
        let active = activeFlags.filter { $0 }.count
        return Summary(average: average, done: done, active: active)
    }
}

