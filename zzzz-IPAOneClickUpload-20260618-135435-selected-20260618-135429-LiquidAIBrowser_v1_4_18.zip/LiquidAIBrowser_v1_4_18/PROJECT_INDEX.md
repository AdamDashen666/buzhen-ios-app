# LiquidAIBrowser v1.4.18 Project Index

- Marketing Version: 1.4.18
- Build: 25
- Package: LiquidAIBrowser_v1_4_18.zip

## Key v1.4.18 changes

- Hardened per-group WebKit isolation with separate non-persistent storage contexts.
- Closing a group now deletes its tabs, tasks, timers, snapshots, PDF reports and WebKit website data.
- Clearing all groups now removes all app-side task artifacts and temporary WebKit storage.
- Added settings copy explaining group isolation and close-group cleanup.

## Important files

- `LiquidAIBrowser/WebViewPool.swift`
  - Browser WebView lifecycle, per-group process/data stores, WebKit data purge, JS bridge, page scanning and screenshots.
- `LiquidAIBrowser/BrowserStore.swift`
  - App state, group/tab/task lifecycle, group data deletion, persistence, timers and reports.
- `LiquidAIBrowser/Panels.swift`
  - Settings UI and privacy/isolation explanation.
- `LiquidAIBrowser/AgentEngine.swift`
  - Agent worker loop, planning, action execution and verification.
- `LiquidAIBrowser/PDFReportExporter.swift`
  - Task report PDF generation.
- `QA_V14_18_GROUP_PRIVACY_ISOLATION_REPORT.md`
  - v1.4.18 focused privacy/group isolation report.

## Previous index/history

# LiquidAIBrowser v1.4.15 Project Index

## Version
- Marketing Version: 1.4.15
- Build: 22

## Main source files
- `LiquidAIBrowserApp.swift`: App entry.
- `ContentView.swift`: Main route, browser layout, settings page, task overview page, toast banner.
- `BrowserStore.swift`: Groups, tabs, tasks, timers, PDF generation, session persistence.
- `BrowserModels.swift`: Data models, task snapshots, plan history, findings.
- `AgentEngine.swift`: Agent loop, planning, decisions, verification, action execution.
- `WebViewPool.swift`: WKWebView pool, JS bridge, DOM reading, actions, screenshots.
- `PDFReportExporter.swift`: PDF report generation.
- `Panels.swift`: New task, task cards, settings, task management panels.
- `AIClient.swift`: OpenAI-compatible API client and JSON extraction.
- `AISettings.swift`: API settings, presets, Keychain.
- `NotificationService.swift`: Local notifications.
- `WindowSizingSupport.swift`: Stage Manager/window sizing support.

## Important reports
- `QA_V14_14_STABILITY_COMPLIANCE_FIX_REPORT.md`: This version's fix report.
- `AI_REVIEW_REQUIREMENTS.md`: Current requirements document.
- `QA_CHECK_REPORT.md`: Prior static check report.
- `QA_FIX_REPORT.md`: Prior fix summary.

## Key v1.4.15 changes
- Independent settings page.
- Auto PDF report after task completion.
- Screenshot file storage under Application Support.
- Enhanced DOM/page state reading.
- Native wait/reload/forward/stopLoading/back.
- Clear failed/stopped task actions.
- No system alert/confirmation dialog for normal operations.
- Background task no longer hijacks current UI.
- Count-up timer fixed.
- Original plan and plan history stored.


## v1.4.15 Stability Hardening

- `QA_V14_15_STABILITY_HARDENING_REPORT.md`: 稳定性专项修复报告。
- BrowserStore: 防抖 session、后台 PDF、截图缓存清理。
- WebViewPool: WebKit 进程恢复、bridge 重注入、about:blank 和截图稳定性。
- AgentEngine: 连续失败判定、JS 动作超时、后台 PDF 触发。

## v1.4.15 Build Diagnostics Patch

- `QA_V14_15_BUILD_AND_STABILITY_REPORT.md`: 构建诊断修复与稳定性检查报告。
- 修复 Xcode 26.3 下 Swift `String.init` ambiguous 与 `excluding` 参数解析问题。
