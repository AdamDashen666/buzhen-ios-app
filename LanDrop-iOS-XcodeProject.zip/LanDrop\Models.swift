import Foundation

enum PeerPlatform: String, Codable {
    case ios
    case windows
}

struct DiscoveredDevice: Identifiable, Equatable {
    let id: String
    let name: String
    let platform: PeerPlatform
    let host: String
    let port: Int
}

struct PairedDevice: Identifiable, Equatable {
    let id: String
    let pairId: String
    let name: String
    let platform: PeerPlatform
    let createdAt: Date
}

struct TransferSnapshot: Identifiable, Equatable {
    enum Direction {
        case send
        case receive
    }

    enum Status {
        case offered
        case transferring
        case complete
        case failed(String)
    }

    let id: String
    let fileName: String
    let direction: Direction
    let status: Status
    let transferredBytes: Int64
    let totalBytes: Int64
    let speedBytesPerSecond: Int64

    var progress: Double {
        guard totalBytes > 0 else { return 0 }
        return min(1, Double(transferredBytes) / Double(totalBytes))
    }
}
