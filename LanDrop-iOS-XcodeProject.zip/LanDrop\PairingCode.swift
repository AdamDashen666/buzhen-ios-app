import Foundation

struct PairingSession: Equatable {
    let code: String
    let expiresAt: Date

    func accepts(_ input: String, now: Date = Date()) -> Bool {
        input == code && now <= expiresAt
    }
}

enum PairingCode {
    static let ttl: TimeInterval = 5 * 60

    static func create(now: Date = Date(), code: String? = nil) -> PairingSession {
        let resolvedCode = code ?? String(format: "%06d", Int.random(in: 0...999_999))
        precondition(resolvedCode.range(of: #"^\d{6}$"#, options: .regularExpression) != nil)
        return PairingSession(code: resolvedCode, expiresAt: now.addingTimeInterval(ttl))
    }
}
