import Foundation

struct TransferStatsWindow {
    let totalBytes: Int64
    let window: TimeInterval
    private var samples: [(date: Date, bytes: Int64)] = []

    init(totalBytes: Int64, window: TimeInterval = 5) {
        self.totalBytes = totalBytes
        self.window = window
    }

    mutating func addSample(date: Date, bytes: Int64) {
        samples.append((date, bytes))
        samples.removeAll { date.timeIntervalSince($0.date) > window }
    }

    func speedBytesPerSecond() -> Int64 {
        guard let first = samples.first, let last = samples.last else { return 0 }
        let elapsed = last.date.timeIntervalSince(first.date)
        guard elapsed > 0 else { return 0 }
        return max(0, Int64(Double(last.bytes - first.bytes) / elapsed))
    }

    func progress(transferredBytes: Int64) -> Double {
        guard totalBytes > 0 else { return 0 }
        return min(1, Double(transferredBytes) / Double(totalBytes))
    }
}
