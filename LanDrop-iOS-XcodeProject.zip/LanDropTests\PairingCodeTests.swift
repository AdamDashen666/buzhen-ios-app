import XCTest
@testable import LanDrop

final class PairingCodeTests: XCTestCase {
    func testCreatesSixDigitCodeExpiringAfterFiveMinutes() {
        let now = Date(timeIntervalSince1970: 1_000)
        let session = PairingCode.create(now: now, code: "493812")

        XCTAssertEqual(session.code, "493812")
        XCTAssertEqual(session.expiresAt, now.addingTimeInterval(300))
    }

    func testAcceptsOnlyExactCodeBeforeExpiration() {
        let now = Date(timeIntervalSince1970: 1_000)
        let session = PairingCode.create(now: now, code: "120045")

        XCTAssertTrue(session.accepts("120045", now: now.addingTimeInterval(1)))
        XCTAssertFalse(session.accepts("120046", now: now.addingTimeInterval(1)))
        XCTAssertFalse(session.accepts("120045", now: now.addingTimeInterval(301)))
    }
}
