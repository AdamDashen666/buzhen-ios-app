import Foundation
import SwiftUI

@MainActor
final class AppModel: ObservableObject {
    @Published var pairingCode: PairingSession?
    @Published var pairedDevices: [PairedDevice] = []
    @Published var discoveredDevices: [DiscoveredDevice] = []
    @Published var transfers: [TransferSnapshot] = []
    @Published var statusText = "保持两台设备在同一 Wi-Fi，打开 LanDrop 即可发现。"

    private let network = LocalNetworkService()

    func start() {
        network.start()
        discoveredDevices = network.discoveredDevices
    }

    func generatePairingCode() {
        pairingCode = PairingCode.create(now: Date())
        statusText = "配对码已生成，5 分钟内有效。"
    }

    func unpair(_ device: PairedDevice) {
        pairedDevices.removeAll { $0.id == device.id }
        statusText = "已解除与 \(device.name) 的配对。"
    }
}
