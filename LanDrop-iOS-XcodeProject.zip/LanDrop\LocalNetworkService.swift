import Foundation
import Network

@MainActor
final class LocalNetworkService: ObservableObject {
    @Published private(set) var discoveredDevices: [DiscoveredDevice] = []

    private var browser: NWBrowser?
    private var listener: NWListener?

    func start() {
        startListener()
        startBrowser()
    }

    private func startListener() {
        do {
            let listener = try NWListener(using: .tcp)
            listener.service = NWListener.Service(
                name: Host.current().localizedName ?? "LanDrop iPhone",
                type: "_landrop._tcp"
            )
            listener.newConnectionHandler = { connection in
                connection.start(queue: .global(qos: .userInitiated))
            }
            listener.start(queue: .global(qos: .userInitiated))
            self.listener = listener
        } catch {
            print("LanDrop listener failed: \(error)")
        }
    }

    private func startBrowser() {
        let browser = NWBrowser(
            for: .bonjour(type: "_landrop._tcp", domain: nil),
            using: .tcp
        )
        browser.browseResultsChangedHandler = { [weak self] results, _ in
            Task { @MainActor in
                self?.discoveredDevices = results.compactMap(Self.device(from:))
            }
        }
        browser.start(queue: .global(qos: .userInitiated))
        self.browser = browser
    }

    private static func device(from result: NWBrowser.Result) -> DiscoveredDevice? {
        guard case let .service(name, _, _, _) = result.endpoint else {
            return nil
        }
        return DiscoveredDevice(
            id: name,
            name: name,
            platform: .windows,
            host: name,
            port: 0
        )
    }
}
