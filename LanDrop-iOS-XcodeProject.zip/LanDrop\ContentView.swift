import SwiftUI

struct ContentView: View {
    @EnvironmentObject private var model: AppModel
    @Namespace private var heroNamespace

    var body: some View {
        ZStack {
            AuroraBackground()
            ScrollView {
                VStack(spacing: 24) {
                    header
                    hero
                    panels
                }
                .padding(22)
            }
        }
        .preferredColorScheme(.dark)
    }

    private var header: some View {
        HStack {
            HStack(spacing: 12) {
                Image(systemName: "arrow.right.circle.fill")
                    .font(.system(size: 34, weight: .bold))
                    .symbolRenderingMode(.palette)
                    .foregroundStyle(.black, .cyan)
                VStack(alignment: .leading, spacing: 2) {
                    Text("LanDrop")
                        .font(.headline)
                    Text("同 Wi-Fi 文件直传")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
            Spacer()
            Label("无服务器", systemImage: "wifi")
                .font(.caption.weight(.semibold))
                .padding(.horizontal, 12)
                .padding(.vertical, 8)
                .glassCard(cornerRadius: 18)
        }
    }

    private var hero: some View {
        VStack(alignment: .leading, spacing: 18) {
            Text("安全配对 · 实时速度 · 流畅传输")
                .font(.caption.weight(.bold))
                .foregroundStyle(.cyan)
            Text(model.pairedDevices.first.map { "已连接 \($0.name)" } ?? "生成 6 位配对码，开始局域网传输")
                .font(.system(size: 38, weight: .bold, design: .rounded))
                .lineLimit(3)
            Text(model.statusText)
                .font(.body)
                .foregroundStyle(.secondary)
            HStack {
                Button {
                    withAnimation(.spring(response: 0.52, dampingFraction: 0.82)) {
                        model.generatePairingCode()
                    }
                } label: {
                    Label("生成配对码", systemImage: "link")
                }
                .buttonStyle(.primaryLanDrop)

                Button {} label: {
                    Label("选择文件", systemImage: "paperclip")
                }
                .buttonStyle(.secondaryLanDrop)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(24)
        .glassCard(cornerRadius: 28)
    }

    private var panels: some View {
        VStack(spacing: 16) {
            PairingPanel(code: model.pairingCode?.code)
            DevicePanel(title: "发现的设备", emptyText: "保持两台设备在同一 Wi-Fi，并打开 LanDrop。") {
                ForEach(model.discoveredDevices) { device in
                    DeviceRow(name: device.name, subtitle: device.platform.rawValue)
                }
            }
            DevicePanel(title: "已配对", emptyText: "配对完成后，设备会显示在这里。") {
                ForEach(model.pairedDevices) { device in
                    DeviceRow(name: device.name, subtitle: device.platform.rawValue)
                }
            }
            TransferStatusPanel(transfers: model.transfers)
        }
    }
}

private struct PairingPanel: View {
    let code: String?

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Label("本机配对码", systemImage: "shield.checkered")
                .font(.headline)
            Text(code ?? "------")
                .font(.system(size: 52, weight: .black, design: .rounded))
                .monospacedDigit()
                .tracking(8)
            Text("让 Windows 输入此号码，或输入对方设备显示的号码。")
                .font(.footnote)
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(22)
        .glassCard(cornerRadius: 24)
    }
}

private struct DevicePanel<Content: View>: View {
    let title: String
    let emptyText: String
    private let content: Content

    init(title: String, emptyText: String, @ViewBuilder content: () -> Content) {
        self.title = title
        self.emptyText = emptyText
        self.content = content()
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(title)
                .font(.headline)
            if Mirror(reflecting: content).children.isEmpty {
                Text(emptyText)
                    .frame(maxWidth: .infinity, minHeight: 74)
                    .foregroundStyle(.secondary)
            } else {
                content
            }
        }
        .padding(18)
        .glassCard(cornerRadius: 22)
    }
}

private struct DeviceRow: View {
    let name: String
    let subtitle: String

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: "iphone.gen3")
                .font(.title3)
                .foregroundStyle(.cyan)
            VStack(alignment: .leading) {
                Text(name).font(.subheadline.weight(.semibold))
                Text(subtitle).font(.caption).foregroundStyle(.secondary)
            }
            Spacer()
        }
        .padding(14)
        .background(.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
    }
}

private struct TransferStatusPanel: View {
    let transfers: [TransferSnapshot]

    var body: some View {
        HStack(spacing: 18) {
            ZStack {
                Circle().stroke(.white.opacity(0.15), lineWidth: 9)
                Circle()
                    .trim(from: 0, to: transfers.first?.progress ?? 0)
                    .stroke(.cyan, style: StrokeStyle(lineWidth: 9, lineCap: .round))
                    .rotationEffect(.degrees(-90))
                Text(transfers.isEmpty ? "Ready" : "\(Int((transfers.first?.progress ?? 0) * 100))%")
                    .font(.caption.weight(.bold))
            }
            .frame(width: 86, height: 86)
            VStack(alignment: .leading, spacing: 6) {
                Text(transfers.first?.fileName ?? "等待传输")
                    .font(.headline)
                Text("传输进度和速度会在这里实时显示。")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
            }
            Spacer()
        }
        .padding(18)
        .glassCard(cornerRadius: 22)
    }
}

private struct AuroraBackground: View {
    var body: some View {
        ZStack {
            LinearGradient(colors: [.black, Color(red: 0.04, green: 0.08, blue: 0.15)], startPoint: .topLeading, endPoint: .bottomTrailing)
            Circle()
                .fill(.cyan.opacity(0.26))
                .frame(width: 260)
                .blur(radius: 44)
                .offset(x: -120, y: -260)
            Circle()
                .fill(.orange.opacity(0.18))
                .frame(width: 300)
                .blur(radius: 54)
                .offset(x: 150, y: 300)
        }
        .ignoresSafeArea()
    }
}

private extension View {
    func glassCard(cornerRadius: CGFloat) -> some View {
        self.background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: cornerRadius, style: .continuous))
            .overlay {
                RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
                    .stroke(.white.opacity(0.16), lineWidth: 1)
            }
            .shadow(color: .black.opacity(0.22), radius: 32, y: 20)
    }
}

private struct PrimaryLanDropButton: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.subheadline.weight(.bold))
            .padding(.horizontal, 16)
            .padding(.vertical, 12)
            .foregroundStyle(.black)
            .background(LinearGradient(colors: [.cyan, Color(red: 0.58, green: 0.72, blue: 1)], startPoint: .leading, endPoint: .trailing), in: Capsule())
            .scaleEffect(configuration.isPressed ? 0.96 : 1)
            .animation(.spring(response: 0.28, dampingFraction: 0.74), value: configuration.isPressed)
    }
}

private struct SecondaryLanDropButton: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.subheadline.weight(.bold))
            .padding(.horizontal, 16)
            .padding(.vertical, 12)
            .foregroundStyle(.white)
            .background(.white.opacity(0.1), in: Capsule())
            .scaleEffect(configuration.isPressed ? 0.96 : 1)
            .animation(.spring(response: 0.28, dampingFraction: 0.74), value: configuration.isPressed)
    }
}

private extension ButtonStyle where Self == PrimaryLanDropButton {
    static var primaryLanDrop: PrimaryLanDropButton { PrimaryLanDropButton() }
}

private extension ButtonStyle where Self == SecondaryLanDropButton {
    static var secondaryLanDrop: SecondaryLanDropButton { SecondaryLanDropButton() }
}
