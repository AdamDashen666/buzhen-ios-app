import XCTest
@testable import LanDrop

final class TransferStatsTests: XCTestCase {
    func testCalculatesSpeedWithinWindow() {
        var stats = TransferStatsWindow(totalBytes: 1_000, window: 5)
        let start = Date(timeIntervalSince1970: 0)

        stats.addSample(date: start, bytes: 0)
        stats.addSample(date: start.addingTimeInterval(2), bytes: 400)

        XCTAssertEqual(stats.speedBytesPerSecond(), 200)
        XCTAssertEqual(stats.progress(transferredBytes: 400), 0.4, accuracy: 0.001)
    }
}
