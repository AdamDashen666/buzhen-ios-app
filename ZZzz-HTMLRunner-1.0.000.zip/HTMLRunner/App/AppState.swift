//
//  AppState.swift
//  HTMLRunner
//
//  Composition root. Owns the long-lived objects, wires the run flow, and keeps
//  the loopback server's lifetime tied to the project that needs it.
//
//  Nothing here contains rendering or file-copy logic; those live in their own
//  modules so this file stays a readable description of how the app fits together.
//

import Foundation
import SwiftUI
import UIKit

@MainActor
final class AppState: ObservableObject {

    // MARK: Long-lived objects

    let log: DiagnosticLogStore
    let settings: AppSettings
    let projects: ProjectStore
    let server: LocalHTTPServer

    /// One coordinator per run. Recreated when the project changes, which is what
    /// keeps the web view (and its decoded-asset caches) alive across reloads.
    @Published private(set) var coordinator: WebViewCoordinator?

    // MARK: UI state

    enum Route: Hashable {
        case projectList
        case run(UUID)
        case diagnostics
    }

    @Published var route: Route = .projectList
    @Published var activeProjectID: UUID?
    @Published var showingLogViewer = false
    @Published var showingImporter = false
    @Published var showingFolderImporter = false
    @Published var banner: Banner?
    /// True while a run is being prepared (server start can take a moment).
    @Published private(set) var isPreparingRun = false

    struct Banner: Identifiable, Equatable {
        enum Kind { case info, success, warning, error }
        let id = UUID()
        var kind: Kind
        var title: String
        var message: String
    }

    private var backgroundObserver: NSObjectProtocol?
    /// Root the currently running server serves, used to detect that a different
    /// project now needs the port.
    private var serverRoot: URL?

    var projectsDirectoryDescription: String {
        projects.projectsRootDirectory.path
    }

    // MARK: Init

    init() {
        let log = DiagnosticLogStore()
        self.log = log
        self.settings = AppSettings(log: log)
        self.projects = ProjectStore(log: log)
        self.server = LocalHTTPServer()

        // Apply the persisted log level. This lives here rather than in
        // `AppSettings.init` because `DiagnosticLogStore` is main-actor isolated and
        // `AppState` is created on the main actor.
        log.minimumLevel = settings.logLevel

        log.info(LogEvent.appLaunch, "应用启动")
        log.info(LogEvent.appVersion, AppInfo.versionDescription, metadata: [
            "bundleID": AppInfo.bundleIdentifier,
            "configuration": AppInfo.buildConfigurationName,
            "target": AppInfo.isSimulatorBuild ? "simulator" : "device",
            "system": AppInfo.systemName,
            "device": AppInfo.deviceModelIdentifier ?? "unknown",
            "physicalMemory": "\(AppInfo.physicalMemoryBytes)"
        ])

        let debugState = ProcessDebugState.current()
        log.info(LogEvent.appLaunch, "进程调试状态（仅描述本 App 进程，不代表 WebContent 进程）", metadata: [
            "isBeingTraced": "\(debugState.isBeingTraced)",
            "flags": String(format: "0x%08X", debugState.processFlags),
            "failure": debugState.failureReason ?? "none"
        ])

        let memory = AppMemoryProbe.sample()
        log.info(LogEvent.appMemorySample, "启动内存采样", metadata: ["values": memory.logSummary])

        if settings.showDiagnosticsOnLaunch {
            route = .diagnostics
        }

        // Backgrounding is when iOS is most likely to reclaim the WebContent process;
        // recording the transition with a memory sample makes that visible afterwards.
        backgroundObserver = NotificationCenter.default.addObserver(
            forName: UIApplication.didEnterBackgroundNotification,
            object: nil,
            queue: .main
        ) { [weak self] _ in
            Task { @MainActor in
                guard let self else { return }
                let sample = AppMemoryProbe.sample()
                self.log.notice(LogEvent.appMemorySample, "进入后台", metadata: [
                    "resident": sample.residentBytes.map(String.init) ?? "unknown",
                    "footprint": sample.physicalFootprintBytes.map(String.init) ?? "unknown"
                ])
            }
        }
    }

    deinit {
        if let backgroundObserver {
            NotificationCenter.default.removeObserver(backgroundObserver)
        }
    }

    // MARK: Server lifetime

    /// Starts the loopback server for a project if the run mode needs it. Never
    /// called for `file://` runs, so the default path opens no sockets at all.
    private func ensureServer(for project: Project, configuration: RunConfiguration) async throws -> URL {
        let root = projects.rootURL(for: project).standardizedFileURL

        if case .running(let port) = server.state, serverRoot == root,
           let url = serverURL(port: port, entry: configuration.entryRelativePath) {
            return url
        }

        serverRoot = root
        try server.start(root: root, log: log)

        // `NWListener` becomes ready asynchronously. `Task.sleep` yields, so the
        // listener's state handler on the main queue can actually run.
        let deadline = Date().addingTimeInterval(3.0)
        while Date() < deadline {
            switch server.state {
            case .running(let port):
                if let url = serverURL(port: port, entry: configuration.entryRelativePath) {
                    return url
                }
            case .stopped:
                if let failure = server.lastError {
                    throw NSError(domain: "HTMLRunner", code: 11, userInfo: [
                        NSLocalizedDescriptionKey: failure
                    ])
                }
            case .starting:
                break
            }
            try? await Task.sleep(nanoseconds: 50_000_000)
        }
        throw NSError(domain: "HTMLRunner", code: 12, userInfo: [
            NSLocalizedDescriptionKey: "本地服务在 3 秒内未就绪"
        ])
    }

    func stopServer(reason: String) {
        guard server.state.isRunning || server.state == .starting else { return }
        server.stop(reason: reason)
        serverRoot = nil
    }

    /// URL for a project served over the loopback server, with each path component
    /// percent-encoded so Chinese names, spaces and `#` all survive.
    func serverURL(port: UInt16, entry: String) -> URL? {
        var components = URLComponents()
        components.scheme = "http"
        components.host = "127.0.0.1"
        components.port = Int(port)
        let encodedPath = "/" + entry
            .split(separator: "/")
            .map { component -> String in
                String(component).addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? String(component)
            }
            .joined(separator: "/")
        components.percentEncodedPath = encodedPath
        return components.url
    }

    // MARK: Run flow

    func open(_ project: Project) async {
        var configuration = settings.makeRunConfiguration(entryRelativePath: project.entryRelativePath)
        log.notice(LogEvent.userOpenProject, "打开项目", metadata: [
            "name": project.name,
            "entry": project.entryRelativePath,
            "files": "\(project.fileCount)",
            "bytes": "\(project.totalBytes)",
            "config": configuration.summaryForLog
        ])

        guard projects.entryExists(for: project) else {
            log.error(LogEvent.projectMissing, "入口文件不存在", metadata: [
                "name": project.name,
                "entry": project.entryRelativePath
            ])
            banner = Banner(kind: .error,
                            title: "找不到入口文件",
                            message: "项目「\(project.name)」中不存在 \(project.entryRelativePath)。请重新导入，或在项目详情里改选入口文件。")
            return
        }

        isPreparingRun = true
        defer { isPreparingRun = false }

        if configuration.mode == .localServer {
            do {
                _ = try await ensureServer(for: project, configuration: configuration)
            } catch {
                log.error(LogEvent.localServerFail, "本地服务不可用，已回退到 file:// 加载", metadata: [
                    "error": error.localizedDescription
                ])
                banner = Banner(
                    kind: .warning,
                    title: "本地服务不可用，已回退到 file://",
                    message: "\(error.localizedDescription)\n已改用 file:// 直接加载。注意：file:// 下 ES Modules 与 fetch 可能受限。"
                )
                configuration.mode = .fileURL
            }
        }

        let coordinator = makeCoordinator()
        self.coordinator = coordinator
        self.activeProjectID = project.id
        self.route = .run(project.id)
        // Apply the Web Inspector preference to the freshly created web view, since
        // `isInspectable` is only consulted while the view exists.
        coordinator.setInspectable(settings.allowWebInspector)
        coordinator.run(project: project, configuration: configuration)
        projects.markOpened(project)
    }

    private func makeCoordinator() -> WebViewCoordinator {
        coordinator?.clear()
        return WebViewCoordinator(
            log: log,
            settings: settings,
            serverStatusProvider: { [weak self] in
                self?.server.state ?? .stopped
            },
            serverURLProvider: { [weak self] project in
                guard let self, case .running(let port) = self.server.state else { return nil }
                return self.serverURL(port: port, entry: project.entryRelativePath)
            },
            resolveLoadURL: { [weak self] project, configuration in
                guard let self else {
                    return (project.entryURL(in: FileManager.default.temporaryDirectory), nil)
                }
                switch configuration.mode {
                case .fileURL:
                    let root = self.projects.rootURL(for: project).standardizedFileURL
                    return (self.projects.entryURL(for: project), root)
                case .localServer:
                    if case .running(let port) = self.server.state,
                       let url = self.serverURL(port: port, entry: configuration.entryRelativePath) {
                        return (url, nil)
                    }
                    // The server was requested but is not up: fall back rather than
                    // showing an empty page, and say so in the log.
                    self.log.warning(LogEvent.localServerFail, "本地服务未运行，本次加载使用 file://")
                    let root = self.projects.rootURL(for: project).standardizedFileURL
                    return (self.projects.entryURL(for: project), root)
                }
            }
        )
    }

    func closeRun() {
        coordinator?.clear()
        coordinator = nil
        activeProjectID = nil
        route = .projectList
        stopServer(reason: "run closed")
    }

    // MARK: Project operations

    func handleImportedProject(_ project: Project, fromFolder: Bool) {
        banner = Banner(
            kind: .success,
            title: "导入完成",
            message: "「\(project.name)」已复制到 App 内（\(project.fileCount) 个文件，\(project.sizeDescription)）。入口文件：\(project.entryRelativePath)"
        )
        log.notice(LogEvent.importFinished, "导入后提示", metadata: [
            "name": project.name,
            "fromFolder": "\(fromFolder)"
        ])
    }

    func handleImportFailure(_ error: Error) {
        let message = (error as? LocalizedError)?.errorDescription ?? error.localizedDescription
        banner = Banner(kind: .error, title: "导入失败", message: message)
    }

    func refreshActiveProject() -> Project? {
        guard let id = activeProjectID else { return nil }
        return projects.project(withID: id)
    }

    // MARK: Diagnostics export

    /// Produces a full report: bundle info, runtime facts, the current log, and the
    /// last probe if one exists. Written to a temporary file the share sheet can use.
    func makeDiagnosticReport() throws -> URL {
        var lines: [String] = []
        lines.append("HTMLRunner 诊断报告")
        lines.append("生成时间: \(DiagnosticLogStore.isoFormatter.string(from: Date()))")
        lines.append("")
        lines.append("== 构建与设备 ==")
        for (key, value) in AppInfo.snapshot() { lines.append("\(key): \(value)") }
        lines.append("物理内存字节数: \(AppInfo.physicalMemoryBytes)")
        lines.append("")

        lines.append("== 进程状态（仅描述本 App 进程）==")
        let debug = ProcessDebugState.current()
        lines.append("是否被调试器附加(P_TRACED): \(debug.isBeingTracedDescription)")
        lines.append("p_flag: \(String(format: "0x%08X", debug.processFlags))")
        lines.append("说明: 该值只描述 App 进程。WKWebView 的页面运行在独立的 WebContent 进程中，其 JIT 状态无法由 App 读取。")
        lines.append("")

        lines.append("== 内存 ==")
        let memory = AppMemoryProbe.sample()
        lines.append("本进程 resident: \(memory.residentDescription)")
        lines.append("本进程 phys_footprint: \(memory.footprintDescription)")
        lines.append("本进程 virtual: \(memory.virtualDescription)")
        lines.append("malloc 使用: \(memory.mallocDescription)")
        lines.append("设备空闲内存(仅参考，不是本 App 的配额): \(memory.deviceFreeDescription)")
        lines.append("说明: 无法获取 WebContent 进程的内存数据；iOS 未提供该接口。")
        lines.append("")

        lines.append("== 本地服务 ==")
        lines.append("状态: \(server.state.description)")
        lines.append("已处理请求数: \(server.requestCount)")
        lines.append("")

        if let project = refreshActiveProject() {
            lines.append("== 当前项目 ==")
            lines.append("名称: \(project.name)")
            lines.append("目录: \(project.directoryName)")
            lines.append("入口: \(project.entryRelativePath)")
            lines.append("文件数: \(project.fileCount)")
            lines.append("体积: \(project.sizeDescription)")
            lines.append("导入方式: \(project.importedFromDescription)")
            lines.append("")
        }

        if let probe = coordinator?.lastProbe {
            lines.append("== 最近一次页面探测 ==")
            lines.append("WebGL2: \(probe.webgl2?.summaryLine ?? "未获取")")
            lines.append("WebGL2 着色器编译/链接: \(probe.webgl2?.shaderTest.map { $0.succeeded ? "成功" : "失败" } ?? "未获取")")
            lines.append("WebGL1: \(probe.webgl1?.summaryLine ?? "未获取")")
            lines.append("WebAssembly 可用: \(probe.webAssemblyAvailable.map { $0 ? "是" : "否" } ?? "未知")")
            lines.append("WebAssembly 模块校验通过: \(probe.webAssemblyModuleValid.map { $0 ? "是" : "否" } ?? "未知")")
            lines.append("new Function 可用: \(probe.newFunctionSupported.map { $0 ? "是" : "否" } ?? "未知")")
            lines.append("numeric ops/s: \(probe.numericOpsPerSecond.map { String(format: "%.0f", $0) } ?? "未获取")")
            lines.append("探测时热状态: \(AppInfo.thermalStateDescription)")
            lines.append("结论限制: \(probe.confidence?.javascriptJitState ?? "cannot-be-determined-from-a-web-page")")
            lines.append("")
        }

        lines.append("== 诊断日志 ==")
        lines.append(log.plainText(level: .debug))

        let text = lines.joined(separator: "\n")
        let url = FileManager.default.temporaryDirectory
            .appendingPathComponent("HTMLRunner-Diagnostic-\(Int(Date().timeIntervalSince1970)).txt")
        try text.write(to: url, atomically: true, encoding: .utf8)
        log.notice(LogEvent.diagnosticExport, "诊断报告已生成", metadata: ["file": url.lastPathComponent])
        return url
    }
}
