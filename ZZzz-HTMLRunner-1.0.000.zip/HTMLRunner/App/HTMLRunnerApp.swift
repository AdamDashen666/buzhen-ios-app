//
//  HTMLRunnerApp.swift
//  HTMLRunner
//
//  App entry point. Deliberately thin: it creates the composition root and hands it
//  to `RootView`. Any logic placed here would be untestable.
//

import SwiftUI

@main
struct HTMLRunnerApp: App {

    @StateObject private var appState = AppState()
    @Environment(\.scenePhase) private var scenePhase

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(appState)
                .environmentObject(appState.log)
                .environmentObject(appState.settings)
                .environmentObject(appState.projects)
                .environmentObject(appState.server)
                // A dark appearance is the right default for a game runner: it removes
                // the white flash between launches and matches what a WebGL page
                // usually expects. It is a UI choice only and is overridable per view.
                .preferredColorScheme(nil)
                .onChange(of: scenePhase) { _, newPhase in
                    switch newPhase {
                    case .background:
                        appState.log.notice(LogEvent.appMemorySample, "场景进入后台")
                    case .active:
                        appState.log.info(LogEvent.appMemorySample, "场景回到前台")
                    default:
                        break
                    }
                }
        }
    }
}
