/*
 * WebProbe.js — HTMLRunner in-page diagnostics, performance and JIT probe.
 *
 * IMPORTANT DESIGN CONTRACT
 * -------------------------
 * This file is *never* injected automatically. It is evaluated on demand from
 * `WebViewCoordinator` via `evaluateJavaScript`. Two invocation styles are
 * supported, and both matter:
 *
 *   1. Loaded as a plain script: it assigns `window.__HTMLRUNNER_PROBE_RUN__`, a
 *      function taking an options object and returning the JSON string. This is
 *      what lets the file be run verbatim in a browser for testing.
 *   2. Wrapped by the app, which evaluates the file once and then calls
 *      `__HTMLRUNNER_PROBE_RUN__(options)` — so the probe body is parsed and
 *      compiled a single time even if it is run repeatedly.
 *
 * The file deliberately does NOT self-invoke with `})(...)` at the end: doing so
 * makes `return (<file>)(options)` fail with "Unexpected token ';'", because an
 * already-invoked expression cannot be called again. That mistake was made once and
 * caught by project-tests/fixtures/11-diagnostic-bridge; the form below is the
 * corrected one.
 *
 * Consequences of the contract:
 *   * The game's own code is never touched, wrapped or monkey-patched.
 *   * Nothing here runs during normal gameplay, so it cannot cost frames.
 *
 * EPISTEMIC RULES (must be preserved by any future edit)
 * -----------------------------------------------------
 *   * This probe can NOT determine whether JavaScriptCore compiled a function
 *     with the JIT. There is no public API for that. Every field that would
 *     require such knowledge is reported as an explicit "unknown"/"indirect"
 *     marker rather than being inferred from a stopwatch.
 *   * Timing numbers are reported as measurements with their conditions, never
 *     as a verdict.
 *   * Capability checks (WebAssembly availability, `new Function` success,
 *     WebGL2 presence) are *facts*, and are reported as facts.
 */
(function (global) {
  "use strict";

  function probe(config) {
    config = config || {};

  var result = {
    probeVersion: "1.0",
    startedAt: new Date().toISOString(),
    userAgent: navigator.userAgent,
    location: String(location.href),
    protocol: location.protocol,
    isSecureContext: typeof global.isSecureContext === "boolean" ? global.isSecureContext : null,
    hardwareConcurrency: navigator.hardwareConcurrency || null,
    deviceMemoryGB: typeof navigator.deviceMemory === "number" ? navigator.deviceMemory : null,
    performanceMemory: null,
    limits: {},
    errors: []
  };

  function record(section, error) {
    result.errors.push({ section: section, message: String(error && error.message ? error.message : error) });
  }

  // ---------------------------------------------------------------- memory -----
  // Chrome/WebKit expose `performance.memory` only in some configurations. When it
  // is missing we say so; we never estimate.
  try {
    var memory = performance && performance.memory;
    result.performanceMemory = memory
      ? {
          usedJSHeapSize: memory.usedJSHeapSize,
          totalJSHeapSize: memory.totalJSHeapSize,
          jsHeapSizeLimit: memory.jsHeapSizeLimit
        }
      : null;
  } catch (error) {
    record("performance.memory", error);
  }

  // ------------------------------------------------- dynamic code evaluation -----
  // Whether `new Function` succeeds is a real, observable capability signal. On
  // WebKit it is not by itself proof that the optimizing JIT is enabled — an
  // interpreter can still evaluate source — so the field is named for what it
  // measures, not for what one might wish it measured.
  try {
    var dynamicFunction = new Function("a", "b", "return a + b;");
    var dynamicFunctionValue = dynamicFunction(19, 23);
    result.limits.newFunctionSupported = true;
    result.limits.newFunctionResult = dynamicFunctionValue;
  } catch (error) {
    result.limits.newFunctionSupported = false;
    record("new Function", error);
  }

  // ------------------------------------------------------------- WebAssembly -----
  // WebAssembly is the strongest *capability* evidence available to a web page on
  // this platform: WebKit implements it with the same executable-memory machinery
  // the JS JIT uses, and it is disabled wherever that machinery is unavailable.
  // It still is not a measurement of the JavaScript JIT itself.
  try {
    result.limits.webAssembly = typeof WebAssembly === "object" && WebAssembly !== null;
    if (result.limits.webAssembly) {
      result.limits.webAssemblyValidate = typeof WebAssembly.validate === "function";
      // 8-byte module: (func (export "f") (result i32) i32.const 42)
      var wasmBytes = new Uint8Array([
        0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00,
        0x01, 0x05, 0x01, 0x60, 0x00, 0x01, 0x7f,
        0x03, 0x02, 0x01, 0x00,
        0x07, 0x05, 0x01, 0x01, 0x66, 0x00, 0x00,
        0x0a, 0x06, 0x01, 0x04, 0x00, 0x41, 0x2a, 0x0b
      ]);
      result.limits.webAssemblyModuleValid = result.limits.webAssemblyValidate
        ? WebAssembly.validate(wasmBytes)
        : null;
      if (result.limits.webAssemblyModuleValid) {
        var compileStart = performance.now();
        var instance = new WebAssembly.Instance(new WebAssembly.Module(wasmBytes), {});
        result.limits.webAssemblyInstantiateMs = performance.now() - compileStart;
        result.limits.webAssemblyCallResult = instance.exports.f();
      }
    }
  } catch (error) {
    result.limits.webAssembly = false;
    record("WebAssembly", error);
  }

  // ------------------------------------------------------------------- WebGL -----
  function describeContext(gl, label, attributes) {
    if (!gl) {
      return { available: false, label: label, attributes: attributes };
    }
    var info = {
      available: true,
      label: label,
      attributes: attributes,
      version: gl.getParameter(gl.VERSION),
      shadingLanguageVersion: gl.getParameter(gl.SHADING_LANGUAGE_VERSION),
      vendor: gl.getParameter(gl.VENDOR),
      renderer: gl.getParameter(gl.RENDERER),
      contextAttributes: gl.getContextAttributes ? gl.getContextAttributes() : null,
      limits: {},
      extensions: [],
      shaderTest: null
    };

    var limitNames = [
      "MAX_TEXTURE_SIZE",
      "MAX_CUBE_MAP_TEXTURE_SIZE",
      "MAX_RENDERBUFFER_SIZE",
      "MAX_TEXTURE_IMAGE_UNITS",
      "MAX_VERTEX_TEXTURE_IMAGE_UNITS",
      "MAX_COMBINED_TEXTURE_IMAGE_UNITS",
      "MAX_VERTEX_ATTRIBS",
      "MAX_VERTEX_UNIFORM_VECTORS",
      "MAX_FRAGMENT_UNIFORM_VECTORS",
      "MAX_VARYING_VECTORS",
      "MAX_3D_TEXTURE_SIZE",
      "MAX_ARRAY_TEXTURE_LAYERS",
      "MAX_SAMPLES",
      "MAX_DRAW_BUFFERS"
    ];
    for (var i = 0; i < limitNames.length; i += 1) {
      var name = limitNames[i];
      if (typeof gl[name] === "number") {
        try {
          info.limits[name] = gl.getParameter(gl[name]);
        } catch (error) {
          info.limits[name] = null;
        }
      }
    }

    try {
      var extensions = gl.getSupportedExtensions() || [];
      info.extensions = extensions;
    } catch (error) {
      record("getSupportedExtensions", error);
    }

    // GLSL compile+link test: this is the closest thing to a real asset-loading
    // smoke test, because it exercises the same driver path a game's shaders take.
    var vertexSource = "attribute vec3 aPosition;\nuniform mat4 uMatrix;\nvoid main() { gl_Position = uMatrix * vec4(aPosition, 1.0); }\n";
    var fragmentSource = "precision mediump float;\nuniform vec4 uColor;\nvoid main() { gl_FragColor = uColor; }\n";
    try {
      var vertexShader = gl.createShader(gl.VERTEX_SHADER);
      gl.shaderSource(vertexShader, vertexSource);
      gl.compileShader(vertexShader);
      var fragmentShader = gl.createShader(gl.FRAGMENT_SHADER);
      gl.shaderSource(fragmentShader, fragmentSource);
      gl.compileShader(fragmentShader);

      var program = gl.createProgram();
      gl.attachShader(program, vertexShader);
      gl.attachShader(program, fragmentShader);
      gl.linkProgram(program);

      info.shaderTest = {
        vertexCompiled: gl.getShaderParameter(vertexShader, gl.COMPILE_STATUS),
        vertexLog: gl.getShaderInfoLog(vertexShader) || "",
        fragmentCompiled: gl.getShaderParameter(fragmentShader, gl.COMPILE_STATUS),
        fragmentLog: gl.getShaderInfoLog(fragmentShader) || "",
        linked: gl.getProgramParameter(program, gl.LINK_STATUS),
        linkLog: gl.getProgramInfoLog(program) || "",
        activeUniforms: gl.getProgramParameter(program, gl.ACTIVE_UNIFORMS)
      };
      gl.deleteProgram(program);
      gl.deleteShader(vertexShader);
      gl.deleteShader(fragmentShader);
    } catch (error) {
      record("glsl.compile", error);
    }

    // Deliberately release the context so repeated probing cannot leak contexts.
    // `WEBGL_lose_context` is the only supported way to do this from script.
    try {
      var lose = gl.getExtension("WEBGL_lose_context");
      if (lose && lose.loseContext) { lose.loseContext(); }
    } catch (error) {
      record("webgl.loseContext", error);
    }

    return info;
  }

  var canvasAttributes = {
    alpha: false,
    antialias: true,
    depth: true,
    stencil: false,
    powerPreference: "high-performance",
    failIfMajorPerformanceCaveat: false,
    preserveDrawingBuffer: false
  };

  try {
    var canvas2 = document.createElement("canvas");
    var gl2 = canvas2.getContext("webgl2", canvasAttributes);
    result.webgl2 = describeContext(gl2, "webgl2", canvasAttributes);
    canvas2.width = 1;
    canvas2.height = 1;
  } catch (error) {
    result.webgl2 = { available: false, label: "webgl2", error: String(error) };
    record("webgl2", error);
  }

  if (!result.webgl2 || !result.webgl2.available || config.testWebGL1) {
    try {
      var canvas1 = document.createElement("canvas");
      var gl1 = canvas1.getContext("webgl", canvasAttributes) || canvas1.getContext("experimental-webgl", canvasAttributes);
      result.webgl1 = describeContext(gl1, "webgl1", canvasAttributes);
      canvas1.width = 1;
      canvas1.height = 1;
    } catch (error) {
      result.webgl1 = { available: false, label: "webgl1", error: String(error) };
      record("webgl1", error);
    }
  }

  // --------------------------------------------------------------- benchmark -----
  // Two workloads with different characteristics, both bounded by iteration count
  // so the probe can never hang a game:
  //
  //   numeric  — tight arithmetic loop; the kind of code an optimizing JIT turns
  //              into machine code. Reported as a measurement only.
  //   alloc    — object/array churn; dominated by the garbage collector.
  //
  // A JIT'd engine is typically orders of magnitude faster on `numeric`, but a
  // single measurement cannot separate "JIT is on" from "this device is fast".
  // The report therefore labels these numbers as INDIRECT EVIDENCE and nothing
  // in the app is allowed to promote them into a JIT verdict.
  function runNumeric(iterations) {
    var accumulator = 0;
    for (var i = 1; i <= iterations; i += 1) {
      accumulator += (i * 3) ^ (i >> 2);
      accumulator = accumulator % 2147483647;
    }
    return accumulator;
  }

  function runAllocation(rounds, size) {
    var sink = 0;
    for (var round = 0; round < rounds; round += 1) {
      var array = new Array(size);
      for (var i = 0; i < size; i += 1) {
        array[i] = { index: i, value: i * 0.5 };
      }
      sink += array[size - 1].index;
    }
    return sink;
  }

  result.benchmark = { iterations: {}, measurements: {}, conditions: {} };
  var iterations = config.iterations || {};
  var numericIterations = iterations.numeric || 6000000;
  var allocationRounds = iterations.allocationRounds || 60;
  var allocationSize = iterations.allocationSize || 2000;

  // Warm-up: lets any tiering that the engine performs happen before measurement.
  // The warm-up time is reported separately so a reader can see how much of the
  // total was warm-up rather than the measured run.
  var warmupStart = performance.now();
  runNumeric(Math.min(numericIterations, 500000));
  var warmupMs = performance.now() - warmupStart;

  var numericStart = performance.now();
  var numericResult = runNumeric(numericIterations);
  var numericMs = performance.now() - numericStart;

  var allocationStart = performance.now();
  var allocationResult = runAllocation(allocationRounds, allocationSize);
  var allocationMs = performance.now() - allocationStart;

  result.benchmark.iterations = {
    numeric: numericIterations,
    allocationRounds: allocationRounds,
    allocationSize: allocationSize
  };
  result.benchmark.measurements = {
    warmupMs: warmupMs,
    numericMs: numericMs,
    numericOpsPerSecond: numericMs > 0 ? (numericIterations / numericMs) * 1000 : null,
    numericSink: numericResult,
    allocationMs: allocationMs,
    allocationSink: allocationResult
  };
  result.benchmark.conditions = {
    visibilityState: document.visibilityState,
    pageWasHidden: document.visibilityState !== "visible",
    thermalState: "unknown-from-page",
    note: "单一测量结果受热降频、后台限速、设备状态影响，不能作为 JIT 是否开启的判据"
  };

  // ------------------------------------- optional large-texture staging test -----
  // Opt-in only: allocating a 4096² RGBA texture costs 64 MB, which is exactly the
  // kind of峰值 this app is trying to avoid by default.
  if (config.testLargeTexture && result.webgl2 && result.webgl2.available) {
    try {
      var probeCanvas = document.createElement("canvas");
      var probeGl = probeCanvas.getContext("webgl2", canvasAttributes);
      var sizes = config.textureSizes || [512, 1024, 2048, 4096];
      var staging = [];
      for (var s = 0; s < sizes.length; s += 1) {
        var size = sizes[s];
        var start = performance.now();
        var texture = probeGl.createTexture();
        probeGl.bindTexture(probeGl.TEXTURE_2D, texture);
        probeGl.texImage2D(probeGl.TEXTURE_2D, 0, probeGl.RGBA, size, size, 0, probeGl.RGBA, probeGl.UNSIGNED_BYTE, null);
        probeGl.texParameteri(probeGl.TEXTURE_2D, probeGl.TEXTURE_MIN_FILTER, probeGl.LINEAR);
        staging.push({
          size: size,
          bytes: size * size * 4,
          allocateMs: performance.now() - start,
          error: probeGl.getError()
        });
        probeGl.deleteTexture(texture);
      }
      probeCanvas.width = 1;
      probeCanvas.height = 1;
      result.textureStaging = staging;
    } catch (error) {
      record("textureStaging", error);
    }
  }

  // ------------------------------------------------------------------ result -----
  result.finishedAt = new Date().toISOString();
  result.elapsedMs = Date.parse(result.finishedAt) - Date.parse(result.startedAt);

  // Explicit, machine-readable statement of what this probe can and cannot say.
  result.confidence = {
    webglCapabilities: "measured",
    webAssemblyAvailability: "measured",
    dynamicCodeEvaluationAvailability: "measured",
    javascriptJitState: "cannot-be-determined-from-a-web-page",
    javascriptPerformance: "indirect-evidence-only"
  };

  var json = JSON.stringify(result);
  try { global.__HTMLRUNNER_PROBE_RESULT = result; } catch (error) { /* ignore */ }
  return json;
  }

  // Publication point. `global` is `window` inside a page and `globalThis`
  // everywhere else, so the same file also loads in Node for testing.
  global.__HTMLRUNNER_PROBE_RUN__ = probe;

  // Loading the file as a plain script also runs the probe once with defaults, so
  // opening WebProbe.js directly in a browser produces a result instead of nothing.
  try {
    global.__HTMLRUNNER_PROBE_RESULT_DEFAULT__ = JSON.parse(probe({}));
  } catch (error) {
    global.__HTMLRUNNER_PROBE_DEFAULT_ERROR__ = String(error && error.stack ? error.stack : error);
  }
})(typeof window !== "undefined" ? window : globalThis);
