/*
 * DiagnosticBridge.js — HTMLRunner page-side error reporter.
 *
 * Injected at `.atDocumentStart` (opt-out in Settings) and ONLY when diagnostics
 * are enabled. It is the only script the app ever puts into a user's page during
 * normal运行, so its contract is deliberately narrow:
 *
 *   PATCHES (to observe, never to change behaviour):
 *     • console.debug / log / info / warn / error  → forwarded, original still called
 *     • window 'error'          → uncaught exceptions
 *     • window 'unhandledrejection' → rejected promises
 *     • window 'error' (capture) → failed <script>/<img>/<link> resource loads
 *
 *   DOES NOT: touch requestAnimationFrame, timers, fetch, XHR, module loading,
 *   WebGL state, the DOM, or any global the page might own. A game must behave
 *   identically with this script present or absent; the only difference is that
 *   errors become visible in the app's diagnostics screen.
 *
 * Messages are delivered through `window.webkit.messageHandlers.<name>.postMessage`
 * when running inside WKWebView. Outside WKWebView (e.g. running these fixtures in
 * a desktop browser during testing) they degrade to a ring buffer on
 * `window.__HTMLRUNNER_BRIDGE_LOG` so tests can still assert on behaviour.
 */
(function () {
  "use strict";

  if (window.__HTMLRUNNER_BRIDGE_INSTALLED__) return;
  window.__HTMLRUNNER_BRIDGE_INSTALLED__ = true;

  // The handler name is substituted by the app before injection; the default keeps
  // the file runnable verbatim in a browser for testing.
  var HANDLER_NAME = "htmlrunnerDiag";
  var MAX_STRING = 2000;
  var MAX_LOG_ENTRIES = 400;

  var nativeHandler = (window.webkit
    && window.webkit.messageHandlers
    && window.webkit.messageHandlers[HANDLER_NAME])
    ? window.webkit.messageHandlers[HANDLER_NAME]
    : null;

  window.__HTMLRUNNER_BRIDGE_LOG = window.__HTMLRUNNER_BRIDGE_LOG || [];

  function truncate(value) {
    if (value === null || value === undefined) return String(value);
    var text;
    if (typeof value === "string") {
      text = value;
    } else if (value instanceof Error) {
      text = value.name + ": " + value.message;
    } else {
      try {
        text = JSON.stringify(value);
      } catch (error) {
        text = Object.prototype.toString.call(value);
      }
    }
    if (typeof text !== "string") text = String(text);
    return text.length > MAX_STRING ? text.slice(0, MAX_STRING) + "…[截断]" : text;
  }

  function post(payload) {
    // Ring buffer for tests / non-WKWebView contexts.
    try {
      window.__HTMLRUNNER_BRIDGE_LOG.push(payload);
      if (window.__HTMLRUNNER_BRIDGE_LOG.length > MAX_LOG_ENTRIES) {
        window.__HTMLRUNNER_BRIDGE_LOG.shift();
      }
    } catch (error) { /* ignore */ }

    if (!nativeHandler || typeof nativeHandler.postMessage !== "function") return;
    try {
      nativeHandler.postMessage(payload);
    } catch (error) {
      // A failure to report must never break the page.
    }
  }

  function stackOf(error) {
    if (error && error.stack) return truncate(error.stack);
    return null;
  }

  // ------------------------------------------------------------------ console ---
  var levels = ["debug", "log", "info", "warn", "error"];
  for (var i = 0; i < levels.length; i += 1) {
    (function (level) {
      var original = console[level];
      if (typeof original !== "function") return;
      console[level] = function () {
        try {
          var parts = [];
          for (var a = 0; a < arguments.length; a += 1) {
            parts.push(truncate(arguments[a]));
          }
          post({ kind: "console", level: level, message: parts.join(" ") });
        } catch (error) { /* never throw from the shim */ }
        return original.apply(console, arguments);
      };
    })(levels[i]);
  }

  // -------------------------------------------------------- uncaught exceptions --
  window.addEventListener("error", function (event) {
    // Resource load failures surface here with a target that is not window.
    if (event && event.target && event.target !== window && event.target.tagName) {
      var tag = String(event.target.tagName).toLowerCase();
      if (tag === "script" || tag === "link" || tag === "img" || tag === "audio" ||
          tag === "video" || tag === "source" || tag === "track") {
        post({
          kind: "resourceError",
          tag: tag,
          url: truncate(event.target.currentSrc || event.target.src || event.target.href || ""),
          message: tag + " 资源加载失败"
        });
        return;
      }
    }

    post({
      kind: "error",
      message: truncate(event && event.message ? event.message : "unknown error"),
      source: event && event.filename ? truncate(event.filename) : null,
      line: event && typeof event.lineno === "number" ? event.lineno : null,
      column: event && typeof event.colno === "number" ? event.colno : null,
      stack: stackOf(event && event.error)
    });
  }, true);

  // ------------------------------------------------------- unhandled rejections --
  window.addEventListener("unhandledrejection", function (event) {
    var reason = event ? event.reason : undefined;
    post({
      kind: "unhandledrejection",
      message: truncate(reason),
      stack: stackOf(reason)
    });
  });

  // -------------------------------------------------------------- WebGL errors ---
  // Cheap, targeted instrumentation: only reports a context creation failure, which
  // is the case that otherwise shows up as an unexplained black screen. It does not
  // wrap WebGLRenderingContext methods (that would slow every draw call).
  try {
    var originalGetContext = HTMLCanvasElement.prototype.getContext;
    HTMLCanvasElement.prototype.getContext = function (type, attributes) {
      var context = originalGetContext.call(this, type, attributes);
      if (!context && (type === "webgl2" || type === "webgl" || type === "experimental-webgl")) {
        post({
          kind: "webglError",
          message: "无法创建 " + String(type) + " 上下文",
          attributes: (function () {
            try { return truncate(attributes || {}); } catch (error) { return null; }
          })()
        });
      }
      return context;
    };
  } catch (error) { /* ignore */ }

  post({
    kind: "ready",
    message: "诊断桥已注入",
    userAgent: truncate(navigator.userAgent),
    location: truncate(String(location.href))
  });
})();
