//
//  WebViewFactory.swift
//  HTMLRunner
//
//  The single place where a WKWebView is created. Nothing else in the app calls
//  `WKWebView(frame:configuration:)`, so there is exactly one configuration to
//  audit.
//
//  Configuration philosophy: start from `WKWebViewConfiguration()` defaults and
//  change as little as possible. Every deviation is listed here with the reason it
//  exists and what it costs. Nothing that weakens a WebKit security mechanism is
//  present, and no "performance" flag is set without a stated justification.
//
//  Deviations from default, and why:
//
//    • `allowsInlineMediaPlayback = true`
//        Games play audio/video without going fullscreen. Cost: none meaningful.
//    • `mediaTypesRequiringUserActionForPlayback` from the user's setting
//        Default is `.audio`; games usually need autoplay, so the default here is
//        "allow" but it is user-visible and revertible.
//    • `preferences.isElementFullscreenEnabled = true` (iOS 15.4+)
//        Lets a canvas call requestFullscreen(); required by some WebGL templates.
//    • user scripts for diagnostics
//        Only the error-reporting bridge, at document start, and the whole thing is
//        switchable off in Settings.
//
//  Explicitly NOT done (and why):
//    • No `setValue(true, forKey: "allowUniversalAccessFromFileURLs")`. It would
//      remove file:// origin isolation and is exactly the kind of "make it work"
//      change that silently breaks the security model.
//    • No `WKPreferences` private keys, no `_setWebGLEnabled:` style SPI.
//    • No `limitsNavigationsToAppBoundDomains`: the page is local content, and app
//      bound domains would restrict what a user's own project may load.
//    • No JS injection that patches timers, rAF or fetch "for speed".
//

import Foundation
import WebKit

// MARK: - Runtime information

enum WebRuntimeInfo {

    /// WebKit's own bundle version, e.g. `8618.2.4`. This is not the Safari version
    /// and it is not the JavaScriptCore version, but it is the only WebKit build
    /// identifier a third-party app can read without private APIs.
    ///
    /// On iOS the system WebKit framework lives in the shared cache, so there may be
    /// no bundle to query. Returning nil in that case is correct — the UI shows
    /// "无法获取" instead of inventing a number.
    static var kitVersion: String? {
        let candidates = [
            "/System/Library/Frameworks/WebKit.framework/Info.plist",
            "/System/Library/PrivateFrameworks/WebKitLegacy.framework/Info.plist",
            "/System/Library/Frameworks/JavaScriptCore.framework/Info.plist"
        ]
        for path in candidates {
            guard let dictionary = NSDictionary(contentsOfFile: path),
                  let version = dictionary["CFBundleVersion"] as? String else { continue }
            return version
        }
        return nil
    }

    /// Same idea, but also reports which file it came from so a report is auditable.
    static var kitVersionSource: String? {
        let candidates = [
            "/System/Library/Frameworks/WebKit.framework/Info.plist",
            "/System/Library/PrivateFrameworks/WebKitLegacy.framework/Info.plist",
            "/System/Library/Frameworks/JavaScriptCore.framework/Info.plist"
        ]
        for path in candidates {
            guard let dictionary = NSDictionary(contentsOfFile: path),
                  dictionary["CFBundleVersion"] is String else { continue }
            return (path as NSString).lastPathComponent
        }
        return nil
    }

    /// Reported by the page itself through `navigator.userAgent`, which is the most
    /// honest description of the engine that will run the game.
    static var currentUserAgent: String {
        WKWebView().value(forKey: "userAgent") as? String ?? "无法获取"
    }
}

// MARK: - Configuration

enum WebViewFactory {

    static let diagnosticsHandlerName = "htmlrunnerDiag"

    struct Built {
        var webView: WKWebView
        var configuration: WKWebViewConfiguration
        var userContentController: WKUserContentController
    }

    /// Creates a web view. `messageHandler` is the object that will receive
    /// `htmlrunnerDiag` messages; pass nil to skip installing the bridge entirely.
    static func makeWebView(configuration runConfiguration: RunConfiguration,
                            messageHandler: WKScriptMessageHandler?,
                            backgroundColor: UIColor = .black,
                            diagnosticsEnabled: Bool = true) -> Built {
        let configuration = WKWebViewConfiguration()

        // --- media -------------------------------------------------------------
        configuration.allowsInlineMediaPlayback = true
        configuration.mediaTypesRequiringUserActionForPlayback = runConfiguration.audioPolicy.mediaTypes
        configuration.allowsPictureInPictureMediaPlayback = false

        // --- content -----------------------------------------------------------
        configuration.defaultWebpagePreferences.allowsContentJavaScript = true
        // Games are the one case where desktop-class content is genuinely useful,
        // but the request must be opt-in from the page: this only *allows* it.
        if #available(iOS 16.4, *) {
            configuration.preferences.isElementFullscreenEnabled = true
        }

        // --- data store --------------------------------------------------------
        // The default (persistent) store is used on purpose: IndexedDB/localStorage
        // state belongs to the user's project and must survive relaunches, and a
        // non-persistent store would silently reset a game's save data.
        configuration.websiteDataStore = .default()

        // --- diagnostics bridge ------------------------------------------------
        let controller = configuration.userContentController
        if diagnosticsEnabled, runConfiguration.consoleBridgeEnabled, let messageHandler {
            controller.add(messageHandler, name: diagnosticsHandlerName)
            if let source = bridgeSource() {
                let script = WKUserScript(source: source,
                                          injectionTime: .atDocumentStart,
                                          forMainFrameOnly: false)
                controller.addUserScript(script)
            }
        }

        let preferences = WKWebpagePreferences()
        preferences.allowsContentJavaScript = true
        configuration.defaultWebpagePreferences = preferences

        let webView = WKWebView(frame: .zero, configuration: configuration)
        webView.isOpaque = false
        webView.backgroundColor = backgroundColor
        webView.scrollView.backgroundColor = backgroundColor
        // A game that draws its own UI must not be rubber-banded or zoomed by the
        // scroll view, but the web view still needs to be scrollable for pages that
        // actually scroll. `contentInsetAdjustmentBehavior = .never` keeps the canvas
        // flush with the screen edges on notched devices.
        webView.scrollView.contentInsetAdjustmentBehavior = .never
        webView.scrollView.bounces = false
        webView.scrollView.bouncesZoom = false
        webView.allowsBackForwardNavigationGestures = false
        if #available(iOS 16.4, *) {
            webView.isInspectable = false
        }
        // Let WebKit's own layout viewport decide sizing from CSS; forcing a viewport
        // would fight the page's `<meta name="viewport">`.
        webView.translatesAutoresizingMaskIntoConstraints = false

        return Built(webView: webView, configuration: configuration, userContentController: controller)
    }

    /// Loads the bridge from the bundle. Falls back to a compiled-in minimal version
    /// so a mis-packaged resource degrades to "errors are still reported" rather
    /// than to silence.
    static func bridgeSource() -> String? {
        if let url = Bundle.main.url(forResource: "DiagnosticBridge", withExtension: "js"),
           let source = try? String(contentsOf: url, encoding: .utf8) {
            return source
        }
        return minimalBridgeSource
    }

    static func probeSource() -> String? {
        guard let url = Bundle.main.url(forResource: "WebProbe", withExtension: "js"),
              let source = try? String(contentsOf: url, encoding: .utf8) else {
            return nil
        }
        return source
    }

    private static let minimalBridgeSource = """
    (function () {
      if (window.__HTMLRUNNER_BRIDGE_INSTALLED__) return;
      window.__HTMLRUNNER_BRIDGE_INSTALLED__ = true;
      function send(payload) {
        try { window.webkit.messageHandlers.htmlrunnerDiag.postMessage(payload); } catch (e) {}
      }
      window.addEventListener('error', function (event) {
        send({ kind: 'error', message: String(event.message || 'unknown') });
      }, true);
      window.addEventListener('unhandledrejection', function (event) {
        send({ kind: 'unhandledrejection', message: String(event.reason) });
      });
      send({ kind: 'ready', message: '诊断桥已注入（内置精简版）' });
    })();
    """
}
