//
//  LocalHTTPServer.swift
//  HTMLRunner
//
//  Optional, minimal HTTP/1.1 server for local HTML projects.
//
//  Security posture (deliberate and documented):
//   * Binds to 127.0.0.1 only — `NWListener` is started with an explicit loopback
//     endpoint, so nothing on the LAN can reach it. There is no "bind all
//     interfaces" option anywhere in this file.
//   * Serves exactly one directory: the imported project root. Every request path
//     is percent-decoded, normalised and then verified to still be inside that
//     root *after* symlink resolution, so `../` traversal and symlink escapes are
//     both rejected.
//   * No directory listing, no request ranges beyond a single byte range, no
//     methods other than GET/HEAD/OPTIONS.
//   * Files are streamed in 256 KiB chunks; a response never buffers a whole file.
//
//  This exists because `file://` gives WebKit an opaque origin: ES module imports
//  and `fetch()` of sibling files are subject to restrictions that plain HTTP does
//  not have. The default run mode is still `file://` — this server is opt-in.
//

import Foundation
import Network
import UIKit

// MARK: - MIME types

enum MIMEType {
    private static let table: [String: String] = [
        "html": "text/html; charset=utf-8",
        "htm": "text/html; charset=utf-8",
        "xhtml": "application/xhtml+xml",
        "js": "text/javascript; charset=utf-8",
        "mjs": "text/javascript; charset=utf-8",
        "cjs": "text/javascript; charset=utf-8",
        "json": "application/json; charset=utf-8",
        "map": "application/json; charset=utf-8",
        "css": "text/css; charset=utf-8",
        "txt": "text/plain; charset=utf-8",
        "md": "text/markdown; charset=utf-8",
        "xml": "application/xml; charset=utf-8",
        "csv": "text/csv; charset=utf-8",
        "svg": "image/svg+xml",
        "png": "image/png",
        "jpg": "image/jpeg",
        "jpeg": "image/jpeg",
        "webp": "image/webp",
        "avif": "image/avif",
        "gif": "image/gif",
        "bmp": "image/bmp",
        "ico": "image/vnd.microsoft.icon",
        "tif": "image/tiff",
        "tiff": "image/tiff",
        "hdr": "image/vnd.radiance",
        "exr": "image/x-exr",
        "ktx": "image/ktx",
        "ktx2": "image/ktx2",
        "basis": "application/octet-stream",
        "dds": "image/vnd-ms.dds",
        "mp3": "audio/mpeg",
        "m4a": "audio/mp4",
        "aac": "audio/aac",
        "wav": "audio/wav",
        "ogg": "audio/ogg",
        "oga": "audio/ogg",
        "opus": "audio/ogg",
        "flac": "audio/flac",
        "weba": "audio/webm",
        "mp4": "video/mp4",
        "m4v": "video/mp4",
        "mov": "video/quicktime",
        "webm": "video/webm",
        "ogv": "video/ogg",
        "ttf": "font/ttf",
        "otf": "font/otf",
        "woff": "font/woff",
        "woff2": "font/woff2",
        "glb": "model/gltf-binary",
        "gltf": "model/gltf+json",
        "obj": "text/plain; charset=utf-8",
        "mtl": "text/plain; charset=utf-8",
        "fbx": "application/octet-stream",
        "dae": "model/vnd.collada+xml",
        "stl": "model/stl",
        "ply": "application/octet-stream",
        "bin": "application/octet-stream",
        "wasm": "application/wasm",
        "data": "application/octet-stream",
        "glsl": "text/plain; charset=utf-8",
        "vert": "text/plain; charset=utf-8",
        "frag": "text/plain; charset=utf-8",
        "wgsl": "text/plain; charset=utf-8",
        "appcache": "text/cache-manifest",
        "webmanifest": "application/manifest+json",
        "pdf": "application/pdf",
        "zip": "application/zip"
    ]

    static func forExtension(_ ext: String) -> String {
        table[ext.lowercased()] ?? "application/octet-stream"
    }

    static func forPath(_ path: String) -> String {
        forExtension((path as NSString).pathExtension)
    }
}

// MARK: - Path resolution

struct ResolvedProjectFile {
    var url: URL
    var size: UInt64
    var modified: Date?
    var mimeType: String
}

enum ProjectPathResolver {

    enum Failure: Error {
        case emptyPath
        case forbiddenCharacters
        case outsideRoot
        case notFound
        case notAFile

        var httpStatus: (code: Int, reason: String) {
            switch self {
            case .emptyPath, .forbiddenCharacters, .outsideRoot:
                return (403, "Forbidden")
            case .notFound, .notAFile:
                return (404, "Not Found")
            }
        }
    }

    /// Resolves an HTTP request path to a file inside `root`.
    ///
    /// - Parameter rawPath: the raw request-target, e.g. `/sub/dir/模 型.glb?v=2`
    static func resolve(rawPath: String, root: URL) throws -> ResolvedProjectFile {
        // Strip query and fragment.
        var path = rawPath
        if let hashIndex = path.firstIndex(of: "#") { path = String(path[path.startIndex..<hashIndex]) }
        if let queryIndex = path.firstIndex(of: "?") { path = String(path[path.startIndex..<queryIndex]) }

        // Percent-decode. `removingPercentEncoding` returns nil for malformed input,
        // which must be rejected rather than guessed at.
        let decoded: String
        if let value = path.removingPercentEncoding {
            decoded = value
        } else {
            throw Failure.forbiddenCharacters
        }

        var relative = decoded
        while relative.hasPrefix("/") { relative.removeFirst() }
        if relative.isEmpty { relative = "index.html" }

        // A NUL byte or backslash in a decoded path is never legitimate here and is
        // a classic filter-bypass trick.
        if relative.unicodeScalars.contains(where: { $0.value == 0 || $0.value == 0x5C }) {
            throw Failure.forbiddenCharacters
        }

        let rootPath = root.standardizedFileURL.resolvingSymlinksInPath().path
        var candidate = root
        for component in relative.split(separator: "/", omittingEmptySubsequences: true) {
            // Never follow `.` or `..` components, even though standardising below
            // would also catch them — rejecting early keeps the intent obvious.
            if component == "." || component == ".." { throw Failure.outsideRoot }
            candidate.appendPathComponent(String(component), isDirectory: false)
        }

        let standardized = candidate.standardizedFileURL.resolvingSymlinksInPath().path
        guard standardized == rootPath || standardized.hasPrefix(rootPath + "/") else {
            throw Failure.outsideRoot
        }

        let fileURL = URL(fileURLWithPath: standardized, isDirectory: false)
        let keys: Set<URLResourceKey> = [.isRegularFileKey, .fileSizeKey, .contentModificationDateKey, .isSymbolicLinkKey]
        guard let values = try? fileURL.resourceValues(forKeys: keys) else {
            throw Failure.notFound
        }
        guard values.isRegularFile == true else { throw Failure.notAFile }

        return ResolvedProjectFile(url: fileURL,
                                   size: UInt64(values.fileSize ?? 0),
                                   modified: values.contentModificationDate,
                                   mimeType: MIMEType.forPath(standardized))
    }
}

// MARK: - HTTP request parsing (pure, unit-testable)

struct HTTPRequestHead {
    var method: String
    var target: String
    var version: String
    var headers: [String: String]   // lower-cased keys
    var bodyLength: Int
    var headerByteCount: Int

    var rangeHeader: String? { headers["range"] }
    var ifNoneMatch: String? { headers["if-none-match"] }
    var ifModifiedSince: String? { headers["if-modified-since"] }
    var wantsKeepAlive: Bool {
        guard let connection = headers["connection"]?.lowercased() else { return version == "HTTP/1.1" }
        return connection.contains("keep-alive")
    }
}

enum HTTPRequestParser {

    enum ParseError: Error {
        case incomplete
        case malformed(String)
        case tooLarge
    }

    static let maximumHeaderBytes = 32 * 1_024
    static let maximumBodyBytes = 8 * 1_024 * 1_024

    /// Parses the request head from `data`. Returns `.incomplete` when more bytes
    /// are required, so the caller can simply append to its buffer and retry.
    static func parseHead(_ data: Data) throws -> HTTPRequestHead {
        guard let terminatorRange = data.range(of: Data("\r\n\r\n".utf8)) else {
            if data.count > maximumHeaderBytes { throw ParseError.tooLarge }
            throw ParseError.incomplete
        }
        let headerData = data.subdata(in: data.startIndex..<terminatorRange.lowerBound)
        guard let headerText = String(data: headerData, encoding: .utf8) else {
            throw ParseError.malformed("请求头不是有效的 UTF-8")
        }

        var lines = headerText.components(separatedBy: "\r\n")
        guard let requestLine = lines.first, !requestLine.isEmpty else {
            throw ParseError.malformed("缺少请求行")
        }
        lines.removeFirst()

        // Request line: METHOD SP request-target SP HTTP-version
        let parts = requestLine.split(separator: " ", omittingEmptySubsequences: true).map(String.init)
        guard parts.count == 3 else { throw ParseError.malformed("请求行格式错误: \(requestLine)") }
        guard parts[2].hasPrefix("HTTP/1.") else { throw ParseError.malformed("不支持的协议版本: \(parts[2])") }

        var headers: [String: String] = [:]
        for line in lines where !line.isEmpty {
            guard let colon = line.firstIndex(of: ":") else { continue }
            let key = String(line[line.startIndex..<colon]).trimmingCharacters(in: .whitespaces).lowercased()
            let value = String(line[line.index(after: colon)...]).trimmingCharacters(in: .whitespaces)
            guard !key.isEmpty else { continue }
            if let existing = headers[key] {
                headers[key] = existing + ", " + value
            } else {
                headers[key] = value
            }
        }

        var bodyLength = 0
        if let rawLength = headers["content-length"], let parsed = Int(rawLength) {
            guard parsed >= 0 else { throw ParseError.malformed("Content-Length 为负") }
            guard parsed <= maximumBodyBytes else { throw ParseError.tooLarge }
            bodyLength = parsed
        }

        return HTTPRequestHead(method: parts[0].uppercased(),
                               target: parts[1],
                               version: parts[2],
                               headers: headers,
                               bodyLength: bodyLength,
                               headerByteCount: headerData.count + 4)
    }
}

/// Single-range parsing for `Range: bytes=…`. Multi-range requests are rejected
/// with 416 rather than silently answered with a wrong body.
enum HTTPRangeParser {
    enum Outcome {
        case full
        case partial(start: UInt64, end: UInt64)
        case unsatisfiable
        case malformed
    }

    static func parse(_ header: String?, fileSize: UInt64) -> Outcome {
        guard let header, !header.isEmpty else { return .full }
        let trimmed = header.trimmingCharacters(in: .whitespaces)
        guard trimmed.lowercased().hasPrefix("bytes=") else { return .malformed }
        let spec = String(trimmed.dropFirst("bytes=".count))
        guard !spec.contains(",") else { return .malformed }
        let bounds = spec.split(separator: "-", maxSplits: 1, omittingEmptySubsequences: false).map(String.init)
        guard bounds.count == 2 else { return .malformed }

        let startText = bounds[0].trimmingCharacters(in: .whitespaces)
        let endText = bounds[1].trimmingCharacters(in: .whitespaces)

        if startText.isEmpty {
            // suffix range: last N bytes
            guard let suffix = UInt64(endText), suffix > 0 else { return .malformed }
            if fileSize == 0 { return .unsatisfiable }
            let length = min(suffix, fileSize)
            return .partial(start: fileSize - length, end: fileSize - 1)
        }

        guard let start = UInt64(startText) else { return .malformed }
        guard start < fileSize else { return .unsatisfiable }

        if endText.isEmpty {
            return .partial(start: start, end: fileSize - 1)
        }
        guard let rawEnd = UInt64(endText), rawEnd >= start else { return .malformed }
        return .partial(start: start, end: min(rawEnd, fileSize - 1))
    }
}

enum HTTPDateFormatter {
    static let rfc1123: DateFormatter = {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.timeZone = TimeZone(identifier: "GMT")
        formatter.dateFormat = "EEE, dd MMM yyyy HH:mm:ss 'GMT'"
        return formatter
    }()
}

// MARK: - Server

@MainActor
final class LocalHTTPServer: ObservableObject {

    enum State: Equatable {
        case stopped
        case starting
        case running(port: UInt16)

        var isRunning: Bool { if case .running = self { return true }; return false }

        var description: String {
            switch self {
            case .stopped: return "已停止"
            case .starting: return "启动中…"
            case .running(let port): return "运行中 http://127.0.0.1:\(port)/"
            }
        }

        var port: UInt16? { if case .running(let port) = self { return port }; return nil }
    }

    @Published private(set) var state: State = .stopped
    @Published private(set) var lastError: String?
    @Published private(set) var requestCount: Int = 0

    private var listener: NWListener?
    private var connections: [ObjectIdentifier: NWConnection] = [:]
    private var root: URL?
    private var log: DiagnosticLogStore?

    /// Maximum simultaneous client connections. A page loading a large model set can
    /// open many connections at once; WebKit itself caps per-host connections, so a
    /// modest ceiling is plenty and prevents unbounded memory growth.
    private let maximumConnections = 24

    // MARK: Lifecycle

    func start(root: URL, log: DiagnosticLogStore, preferredPort: UInt16 = 0) throws {
        stop(reason: "restart")
        self.root = root
        self.log = log
        self.lastError = nil
        state = .starting

        let parameters = NWParameters.tcp
        // Loopback only. This is the security boundary of the whole feature: the
        // listener is pinned to 127.0.0.1 and there is no code path anywhere in this
        // file that binds to a wildcard or LAN address.
        //
        // `port` 0 asks the system for an ephemeral port, which is what the app wants:
        // a fixed port could collide with another app and would also make the service
        // reachable at a predictable address.
        parameters.requiredLocalEndpoint = NWEndpoint.hostPort(
            host: .ipv4(.loopback),
            port: NWEndpoint.Port(rawValue: preferredPort) ?? NWEndpoint.Port(rawValue: 0)!)

        let listener: NWListener
        do {
            listener = try NWListener(using: parameters)
        } catch {
            state = .stopped
            lastError = error.localizedDescription
            log.error(LogEvent.localServerFail, "本地服务创建失败", metadata: ["error": error.localizedDescription])
            throw error
        }
        listener.newConnectionHandler = { [weak self] connection in
            Task { @MainActor in self?.accept(connection) }
        }
        listener.stateUpdateHandler = { [weak self] newState in
            Task { @MainActor in self?.handleListenerState(newState) }
        }
        listener.start(queue: .global(qos: .userInitiated))
        self.listener = listener
        log.info(LogEvent.localServerStart, "正在启动本地服务", metadata: ["root": root.lastPathComponent])
    }

    func stop(reason: String) {
        guard listener != nil || !connections.isEmpty else {
            state = .stopped
            return
        }
        listener?.stateUpdateHandler = nil
        listener?.newConnectionHandler = nil
        listener?.cancel()
        listener = nil
        for (_, connection) in connections { connection.cancel() }
        connections.removeAll()
        root = nil
        state = .stopped
        log?.info(LogEvent.localServerStop, "本地服务已停止", metadata: ["reason": reason])
    }

    private func handleListenerState(_ newState: NWListener.State) {
        switch newState {
        case .ready:
            if let port = listener?.port?.rawValue {
                state = .running(port: port)
                log?.info(LogEvent.localServerReady, "本地服务已就绪", metadata: ["port": "\(port)"])
            } else {
                state = .stopped
                lastError = "监听器就绪但未获得端口"
                log?.error(LogEvent.localServerFail, "监听器就绪但未获得端口")
            }
        case .failed(let error):
            state = .stopped
            lastError = error.localizedDescription
            log?.error(LogEvent.localServerFail, "本地服务监听失败", metadata: ["error": error.localizedDescription])
            stop(reason: "listener failed")
        case .cancelled:
            state = .stopped
        default:
            break
        }
    }

    // MARK: Connections

    private func accept(_ connection: NWConnection) {
        guard connections.count < maximumConnections else {
            connection.cancel()
            log?.warning(LogEvent.localServerDenied, "连接数超过上限，已拒绝", metadata: ["limit": "\(maximumConnections)"])
            return
        }
        let key = ObjectIdentifier(connection)
        connections[key] = connection
        connection.stateUpdateHandler = { [weak self] newState in
            Task { @MainActor in
                switch newState {
                case .ready:
                    self?.receive(on: connection, buffer: Data())
                case .failed, .cancelled:
                    self?.connections.removeValue(forKey: key)
                default:
                    break
                }
            }
        }
        connection.start(queue: .global(qos: .userInitiated))
    }

    private func receive(on connection: NWConnection, buffer: Data) {
        connection.receive(minimumIncompleteLength: 1, maximumLength: 64 * 1_024) { [weak self] data, _, isComplete, error in
            Task { @MainActor in
                guard let self else { return }
                var accumulated = buffer
                if let data, !data.isEmpty { accumulated.append(data) }

                if let error {
                    self.log?.warning(LogEvent.localServerRequest, "连接读取失败", metadata: ["error": error.localizedDescription])
                    connection.cancel()
                    return
                }

                do {
                    let head = try HTTPRequestParser.parseHead(accumulated)
                    // Body is drained but ignored: GET/HEAD are the only real verbs.
                    if head.bodyLength > 0 {
                        let available = accumulated.count - head.headerByteCount
                        if available < head.bodyLength {
                            self.receive(on: connection, buffer: accumulated)
                            return
                        }
                    }
                    self.handle(head: head, on: connection)
                } catch HTTPRequestParser.ParseError.incomplete {
                    if accumulated.count > HTTPRequestParser.maximumHeaderBytes {
                        self.respondSimple(status: (431, "Request Header Fields Too Large"), on: connection)
                    } else if isComplete {
                        connection.cancel()
                    } else {
                        self.receive(on: connection, buffer: accumulated)
                    }
                } catch {
                    self.respondSimple(status: (400, "Bad Request"), on: connection)
                }
            }
        }
    }

    // MARK: Request handling

    private func handle(head: HTTPRequestHead, on connection: NWConnection) {
        requestCount += 1
        guard let root else {
            respondSimple(status: (503, "Service Unavailable"), on: connection)
            return
        }

        switch head.method {
        case "GET", "HEAD":
            break
        case "OPTIONS":
            let response = HTTPResponseBuilder.plain(status: (204, "No Content"),
                                                     extraHeaders: ["Allow": "GET, HEAD, OPTIONS"])
            send(response, body: nil, on: connection)
            return
        default:
            respondSimple(status: (405, "Method Not Allowed"), on: connection, extraHeaders: ["Allow": "GET, HEAD, OPTIONS"])
            return
        }

        let resolved: ResolvedProjectFile
        do {
            resolved = try ProjectPathResolver.resolve(rawPath: head.target, root: root)
        } catch let failure as ProjectPathResolver.Failure {
            let status = failure.httpStatus
            log?.notice(LogEvent.localServerDenied, "请求被拒绝", metadata: [
                "target": head.target,
                "status": "\(status.code)"
            ])
            respondSimple(status: status, on: connection)
            return
        } catch {
            respondSimple(status: (500, "Internal Server Error"), on: connection)
            return
        }

        if requestCount <= 40 || requestCount % 50 == 0 {
            log?.debug(LogEvent.localServerRequest, "服务请求", metadata: [
                "method": head.method,
                "target": head.target,
                "bytes": "\(resolved.size)"
            ])
        }

        // Conditional requests: a game that reloads often benefits a lot from 304s
        // because it avoids re-parsing multi-megabyte JS bundles.
        let etag = HTTPResponseBuilder.etag(size: resolved.size, modified: resolved.modified)
        if let ifNoneMatch = head.ifNoneMatch, ifNoneMatch == etag {
            let response = HTTPResponseBuilder.plain(status: (304, "Not Modified"),
                                                     extraHeaders: ["ETag": etag, "Cache-Control": "no-cache"])
            send(response, body: nil, on: connection)
            return
        }
        if let ifModifiedSince = head.ifModifiedSince,
           let sinceDate = HTTPDateFormatter.rfc1123.date(from: ifModifiedSince),
           let modified = resolved.modified,
           modified <= sinceDate {
            let response = HTTPResponseBuilder.plain(status: (304, "Not Modified"),
                                                     extraHeaders: ["ETag": etag, "Cache-Control": "no-cache"])
            send(response, body: nil, on: connection)
            return
        }

        let rangeOutcome = HTTPRangeParser.parse(head.rangeHeader, fileSize: resolved.size)
        var start: UInt64 = 0
        var end: UInt64 = resolved.size > 0 ? resolved.size - 1 : 0
        var status = (200, "OK")

        switch rangeOutcome {
        case .full:
            break
        case .partial(let rangeStart, let rangeEnd):
            start = rangeStart
            end = rangeEnd
            status = (206, "Partial Content")
        case .unsatisfiable:
            let response = HTTPResponseBuilder.plain(status: (416, "Range Not Satisfiable"),
                                                     extraHeaders: ["Content-Range": "bytes */\(resolved.size)"])
            send(response, body: nil, on: connection)
            return
        case .malformed:
            // Serve the whole entity: RFC 9110 permits ignoring an unsatisfiable
            // Range header, and browsers handle 200-with-full-body gracefully.
            break
        }

        let length = resolved.size == 0 ? 0 : (end - start + 1)
        var headers: [String: String] = [
            "Content-Type": resolved.mimeType,
            "Content-Length": "\(length)",
            "Accept-Ranges": "bytes",
            "ETag": etag,
            "Cache-Control": "no-cache",
            "X-Content-Type-Options": "nosniff"
        ]
        if let modified = resolved.modified {
            headers["Last-Modified"] = HTTPDateFormatter.rfc1123.string(from: modified)
        }
        if case .partial = rangeOutcome {
            headers["Content-Range"] = "bytes \(start)-\(end)/\(resolved.size)"
        }

        let headerData = HTTPResponseBuilder.head(status: status, headers: headers)
        if head.method == "HEAD" || length == 0 {
            send(HTTPResponseBuilder.plain(status: status, extraHeaders: headers), body: nil, on: connection)
            return
        }

        streamFile(at: resolved.url,
                   headerData: headerData,
                   start: start,
                   length: length,
                   on: connection)
    }

    /// Streams a file range using a small, fixed buffer. The file is never loaded
    /// into memory as a whole, which is the entire point for multi-gigabyte assets.
    private func streamFile(at url: URL,
                           headerData: Data,
                           start: UInt64,
                           length: UInt64,
                           on connection: NWConnection) {
        let chunkSize = 256 * 1_024
        connection.send(content: headerData, completion: .contentProcessed { [weak self] error in
            Task { @MainActor in
                guard let self else { return }
                if error != nil {
                    connection.cancel()
                    return
                }
                guard let handle = try? FileHandle(forReadingFrom: url) else {
                    connection.cancel()
                    self.log?.warning(LogEvent.localServerRequest, "无法打开文件", metadata: ["file": url.lastPathComponent])
                    return
                }
                do {
                    try handle.seek(toOffset: start)
                } catch {
                    try? handle.close()
                    connection.cancel()
                    return
                }
                self.sendChunks(handle: handle,
                                remaining: length,
                                chunkSize: chunkSize,
                                on: connection)
            }
        })
    }

    private func sendChunks(handle: FileHandle,
                            remaining: UInt64,
                            chunkSize: Int,
                            on connection: NWConnection) {
        guard remaining > 0 else {
            try? handle.close()
            connection.cancel()
            return
        }
        let toRead = Int(min(UInt64(chunkSize), remaining))
        let chunk = (try? handle.read(upToCount: toRead)) ?? nil

        guard let chunk, !chunk.isEmpty else {
            try? handle.close()
            connection.cancel()
            return
        }

        connection.send(content: chunk, completion: .contentProcessed { [weak self] error in
            Task { @MainActor in
                guard let self else { return }
                if error != nil {
                    try? handle.close()
                    connection.cancel()
                    return
                }
                self.sendChunks(handle: handle,
                                remaining: remaining - UInt64(chunk.count),
                                chunkSize: chunkSize,
                                on: connection)
            }
        })
    }

    private func respondSimple(status: (Int, String),
                              on connection: NWConnection,
                              extraHeaders: [String: String] = [:]) {
        let response = HTTPResponseBuilder.plain(status: status, extraHeaders: extraHeaders)
        send(response, body: nil, on: connection)
    }

    private func send(_ response: Data, body: Data?, on connection: NWConnection) {
        var payload = response
        if let body { payload.append(body) }
        connection.send(content: payload, completion: .contentProcessed { _ in
            connection.cancel()
        })
    }
}

// MARK: - Response building (pure, unit-testable)

enum HTTPResponseBuilder {

    static func head(status: (Int, String), headers: [String: String]) -> Data {
        var lines: [String] = ["HTTP/1.1 \(status.0) \(status.1)"]
        var merged = headers
        merged["Connection"] = "close"
        merged["Server"] = "HTMLRunner-LocalServer"
        for key in merged.keys.sorted() {
            lines.append("\(key): \(merged[key] ?? "")")
        }
        lines.append("")
        lines.append("")
        return Data(lines.joined(separator: "\r\n").utf8)
    }

    static func plain(status: (Int, String), extraHeaders: [String: String] = [:]) -> Data {
        var headers = extraHeaders
        headers["Content-Length"] = headers["Content-Length"] ?? "0"
        return head(status: status, headers: headers)
    }

    /// Weak-but-standard ETag derived from size + mtime. It is only ever used to
    /// decide 304 vs 200 inside this process, so collisions have no security impact.
    static func etag(size: UInt64, modified: Date?) -> String {
        let stamp = modified.map { String(Int($0.timeIntervalSince1970)) } ?? "0"
        return "\"\(String(size, radix: 16))-\(String(stamp, radix: 16))\""
    }
}
