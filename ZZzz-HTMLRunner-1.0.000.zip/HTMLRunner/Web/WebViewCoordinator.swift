//
//  WebViewCoordinator.swift
//  HTMLRunner
//
//  Owns one WKWebView for the lifetime of one project run, implements
//  WKNavigationDelegate + WKUIDelegate, and is the only object that talks to the
//  page. Everything it learns is written to the diagnostic log with a timestamp,
//  which is what makes a white screen diagnosable after the fact.
//
//  Key behaviours, and the reasoning behind each:
//
//   • The web view is created ONCE per run. Reloading re-issues a load on the same
//     instance instead of rebuilding it — rebuilding loses the HTTP cache, the
//     WebGL context and up to a few hundred megabytes of already-decoded assets.
//   • `loadFileURL(_:allowingReadAccessTo:)` is given the *project root*, not the
//     entry file, so relative asset paths resolve. The root is never widened to the
//     device or even to Documents/.
//   • Navigation that would leave the local project is intercepted. By default it
//     is handed to Safari, which keeps the game's WebGL context alive; the policy
//     is user-configurable but never silently ignored.
//   • Every WebKit error that has a `NSError` is logged with its domain and code,
//     because "WebKitErrorDomain 102" (frame load interrupted by policy change)
//     and "101" (cannot show URL) mean completely different things.
//   • Process termination is logged as a first-class event, including the fact
//     that iOS does not tell us WHY it happened.
//

import Foundation
import WebKit
import UIKit
import SwiftUI

@MainActor
final class WebViewCoordinator: NSObject, ObservableObject {

    // MARK: Published state

    enum Phase: Equatable {
        case idle
        case loading
        case loaded
        case failed(String)
        case terminated
    }

    @Published private(set) var phase: Phase = .idle
    @Published private(set) var lastErrorMessage: String?
    @Published private(set) var loadStartedAt: Date?
    @Published private(set) var loadFinishedAt: Date?
    @Published private(set) var loadDuration: TimeInterval?
    @Published private(set) var navigationCount: Int = 0
    @Published private(set) var terminationCount: Int = 0
    @Published private(set) var lastProbe: ProbeResult?
    @Published private(set) var isProbing = false
    @Published private(set) var currentURLString: String = ""
    @Published private(set) var blockCount: Int = 0
    /// Set when the page loaded but the app suspects a failure the page never
    /// reported; drives a non-blocking hint in the toolbar, never a modal.
    @Published private(set) var suspendedWarning: String?

    // MARK: Dependencies

    private let log: DiagnosticLogStore
    private let settings: AppSettings
    private let serverStatusProvider: () -> LocalHTTPServer.State
    private let serverURLProvider: (Project) -> URL?
    private let resolveLoadURL: (Project, RunConfiguration) -> (url: URL, readAccessRoot: URL?)

    private(set) var webView: WKWebView!
    private var project: Project?
    private var configuration: RunConfiguration = .default
    private var healthTimer: Timer?
    private var lastActivity = Date()

    init(log: DiagnosticLogStore,
         settings: AppSettings,
         serverStatusProvider: @escaping () -> LocalHTTPServer.State,
         serverURLProvider: @escaping (Project) -> URL?,
         resolveLoadURL: @escaping (Project, RunConfiguration) -> (url: URL, readAccessRoot: URL?)) {
        self.log = log
        self.settings = settings
        self.serverStatusProvider = serverStatusProvider
        self.serverURLProvider = serverURLProvider
        self.resolveLoadURL = resolveLoadURL
        super.init()
        self.webView = makeWebView()
    }

    private func makeWebView() -> WKWebView {
        let built = WebViewFactory.makeWebView(configuration: configuration,
                                               messageHandler: self,
                                               diagnosticsEnabled: settings.diagnosticsEnabled)
        let webView = built.webView
        webView.navigationDelegate = self
        webView.uiDelegate = self
        log.info(LogEvent.webViewCreated, "已创建 WKWebView", metadata: [
            "inspectable": settings.allowWebInspector ? "on" : "off",
            "bridge": settings.diagnosticsEnabled ? "on" : "off"
        ])
        return webView
    }

    // MARK: Running

    func run(project: Project, configuration: RunConfiguration) {
        self.project = project
        self.configuration = configuration
        self.lastErrorMessage = nil
        self.suspendedWarning = nil
        self.loadFinishedAt = nil
        self.loadDuration = nil

        let resolved = resolveLoadURL(project, configuration)
        if let root = resolved.readAccessRoot {
            log.info(LogEvent.userRun, "开始运行项目", metadata: [
                "project": project.name,
                "entry": project.entryRelativePath,
                "config": configuration.summaryForLog,
                "readAccessRoot": root.lastPathComponent,
                "readAccessIsProjectRoot": "\(root.standardizedFileURL == root.standardizedFileURL)"
            ])
            webView.loadFileURL(resolved.url, allowingReadAccessTo: root)
        } else {
            log.info(LogEvent.userRun, "开始运行项目（本地 HTTP 服务）", metadata: [
                "project": project.name,
                "entry": project.entryRelativePath,
                "config": configuration.summaryForLog,
                "url": resolved.url.absoluteString,
                "server": serverStatusProvider().description
            ])
            webView.load(URLRequest(url: resolved.url))
        }
        startHealthTimer()
    }

    func reload(userInitiated: Bool) {
        guard webView.url != nil || project != nil else { return }
        log.notice(LogEvent.userReload, userInitiated ? "用户主动刷新" : "自动刷新")
        lastActivity = Date()
        suspendedWarning = nil
        if webView.url == nil, let project {
            run(project: project, configuration: configuration)
        } else {
            webView.reload()
        }
    }

    /// After `.webContentProcessDidTerminate` the view is blank. Re-running is the
    /// only public way to recover; the state (scroll position, JS globals) is gone
    /// and cannot be restored, which is stated in the UI rather than hidden.
    func restoreAfterTermination() {
        guard let project else { return }
        log.notice(LogEvent.webContentRestored, "正在恢复页面（页面内状态无法还原）")
        run(project: project, configuration: configuration)
    }

    func stopLoading() {
        webView.stopLoading()
        log.info(LogEvent.userStop, "用户停止了加载")
        setPhase(.idle)
    }

    func clear() {
        healthTimer?.invalidate()
        healthTimer = nil
        webView.stopLoading()
        project = nil
        setPhase(.idle)
    }

    /// Applies the Settings toggle to the live web view. `isInspectable` only has an
    /// effect on a Debug build attached to a Mac; on a sideloaded Release build
    /// Safari Web Inspector cannot attach regardless of this flag, and the UI says so.
    func setInspectable(_ enabled: Bool) {
        if #available(iOS 16.4, *) {
            webView.isInspectable = enabled
            log.info(LogEvent.settingsChanged, "Web Inspector 可附加性已更新", metadata: [
                "isInspectable": "\(enabled)",
                "effectiveFor": AppInfo.isDebugBuild ? "debug build" : "release build (通常无效)"
            ])
        } else {
            log.info(LogEvent.settingsChanged, "当前系统版本不支持 isInspectable（需要 iOS 16.4 及以上）")
        }
    }

    // MARK: Probes

    /// Runs `WebProbe.js` in the page and decodes its JSON result.
    func runProbe(includeLargeTexture: Bool = false,
                  iterations: [String: Int]? = nil,
                  completion: ((Result<ProbeResult, Error>) -> Void)? = nil) {
        guard !isProbing else { return }
        guard let source = WebViewFactory.probeSource() else {
            let error = NSError(domain: "HTMLRunner", code: 2,
                                userInfo: [NSLocalizedDescriptionKey: "WebProbe.js 未打包进 App"])
            log.error(LogEvent.perfProbeFailed, "探测脚本缺失")
            completion?(.failure(error))
            return
        }

        isProbing = true
        let conditions: [String: Any] = [
            "testLargeTexture": includeLargeTexture,
            "iterations": iterations ?? ["numeric": 6_000_000, "allocationRounds": 60, "allocationSize": 2000]
        ]
        let conditionsJSON = (try? JSONSerialization.data(withJSONObject: conditions))
            .flatMap { String(data: $0, encoding: .utf8) } ?? "{}"

        log.info(LogEvent.perfProbeStart, "开始页面性能与能力探测", metadata: [
            "largeTexture": "\(includeLargeTexture)",
            "conditions": conditionsJSON
        ])
        log.info(LogEvent.jitProbeStart, "开始 JIT 相关能力探测（结果仅用于间接判断）")

        // The probe file *publishes* `__HTMLRUNNER_PROBE_RUN__` rather than invoking
        // itself, so it is evaluated once here (defining the function) and then called
        // with the run conditions. The previous form — `return (<file>)(options)` —
        // was a syntax error, because the file already ended in a self-invocation.
        //
        // Note: the probe is synchronous inside the page, so this blocks the WebContent
        // process's main thread for the duration of the benchmark. That is acceptable
        // for an explicitly user-triggered diagnostic, and it is why the iteration
        // counts are bounded.
        let script = """
        (function () {
          try {
            if (typeof window.__HTMLRUNNER_PROBE_RUN__ !== "function") {
              \(source)
            }
            if (typeof window.__HTMLRUNNER_PROBE_RUN__ !== "function") {
              return JSON.stringify({ fatal: "探测脚本未成功加载（__HTMLRUNNER_PROBE_RUN__ 未定义）" });
            }
            return window.__HTMLRUNNER_PROBE_RUN__(\(conditionsJSON));
          } catch (error) {
            return JSON.stringify({ fatal: String(error && error.stack ? error.stack : error) });
          }
        })();
        """

        webView.evaluateJavaScript(script) { [weak self] value, error in
            guard let self else { return }
            self.isProbing = false

            if let error {
                self.log.error(LogEvent.perfProbeFailed, "探测脚本执行失败", metadata: [
                    "error": error.localizedDescription
                ])
                completion?(.failure(error))
                return
            }

            let jsonString: String?
            if let string = value as? String {
                jsonString = string
            } else if let dictionary = value as? [String: Any],
                      let data = try? JSONSerialization.data(withJSONObject: dictionary) {
                jsonString = String(data: data, encoding: .utf8)
            } else {
                jsonString = nil
            }

            guard let jsonString else {
                let error = NSError(domain: "HTMLRunner", code: 3,
                                    userInfo: [NSLocalizedDescriptionKey: "探测没有返回字符串结果"])
                self.log.error(LogEvent.perfProbeFailed, "探测结果为空")
                completion?(.failure(error))
                return
            }

            // The wrapper reports its own failures as `{"fatal": "..."}` so that a
            // syntax error inside the probe cannot be mistaken for a page that simply
            // has no WebGL.
            if let data = jsonString.data(using: .utf8),
               let object = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
               let fatal = object["fatal"] as? String {
                let error = NSError(domain: "HTMLRunner", code: 4,
                                    userInfo: [NSLocalizedDescriptionKey: "探测脚本内部错误：\(fatal)"])
                self.log.error(LogEvent.perfProbeFailed, "探测脚本内部错误", metadata: [
                    "fatal": String(fatal.prefix(1_000))
                ])
                completion?(.failure(error))
                return
            }

            guard let result = try? ProbeResult.decode(fromJSONString: jsonString) else {
                let error = NSError(domain: "HTMLRunner", code: 3,
                                    userInfo: [NSLocalizedDescriptionKey: "探测结果无法解析"])
                self.log.error(LogEvent.perfProbeFailed, "探测结果解析失败", metadata: [
                    "head": String(jsonString.prefix(300))
                ])
                completion?(.failure(error))
                return
            }

            self.lastProbe = result
            self.logProbeSummary(result)
            completion?(.success(result))
        }
    }

    private func logProbeSummary(_ result: ProbeResult) {
        var metadata: [String: String] = [:]
        metadata["webgl2"] = result.webgl2?.available == true ? "available" : "unavailable"
        if let renderer = result.webgl2?.renderer { metadata["renderer"] = renderer }
        metadata["wasm"] = result.webAssemblyAvailable.map { "\($0)" } ?? "unknown"
        metadata["newFunction"] = result.newFunctionSupported.map { "\($0)" } ?? "unknown"
        if let ops = result.numericOpsPerSecond {
            metadata["numericOpsPerSecond"] = String(format: "%.0f", ops)
        }
        if let shaderOK = result.webgl2?.shaderTest?.succeeded {
            metadata["glslCompileLink"] = shaderOK ? "ok" : "failed"
        }
        if let errors = result.errors, !errors.isEmpty {
            metadata["pageErrors"] = "\(errors.count)"
        }
        let thermal = AppInfo.thermalStateDescription
        metadata["thermalStateAtProbe"] = thermal
        metadata["verdict"] = "性能数字为间接证据；JIT 状态无法由网页判定"

        log.info(LogEvent.perfProbeResult, "页面探测完成", metadata: metadata)
        log.info(LogEvent.jitProbeResult, "JIT 相关能力探测完成（WASM/new Function 为能力事实，耗时仅为间接证据）", metadata: metadata)

        if let shader = result.webgl2?.shaderTest, !shader.succeeded {
            log.error(LogEvent.webGLError, "GLSL 编译或链接失败", metadata: [
                "vertexLog": shader.vertexLog ?? "",
                "fragmentLog": shader.fragmentLog ?? "",
                "linkLog": shader.linkLog ?? ""
            ])
        }
    }

    // MARK: Performance overlay

    func setPerformanceOverlay(enabled: Bool) {
        guard webView.url != nil else { return }
        if enabled {
            let source = Self.overlaySource
            webView.evaluateJavaScript(source) { _, error in
                if let error {
                    Task { @MainActor in
                        self.log.warning(LogEvent.perfProbeFailed, "性能悬浮面板注入失败", metadata: [
                            "error": error.localizedDescription
                        ])
                    }
                }
            }
        } else {
            webView.evaluateJavaScript("window.__htmlrunnerOverlay && window.__htmlrunnerOverlay.remove();") { _, _ in }
        }
    }

    /// Minimal FPS + heap readout. Deliberately tiny: it must not become a second
    /// rendering loop that competes with the game.
    private static let overlaySource = """
    (function () {
      if (window.__htmlrunnerOverlay) { return; }
      var box = document.createElement('div');
      box.id = '__htmlrunner_overlay__';
      box.style.cssText = 'position:fixed;top:8px;right:8px;z-index:2147483647;' +
        'font:12px/1.35 ui-monospace,Menlo,monospace;color:#9ef;background:rgba(0,0,0,.62);' +
        'padding:6px 8px;border-radius:8px;pointer-events:auto;white-space:pre;';
      box.textContent = 'FPS …';
      box.title = '点击隐藏';
      document.body.appendChild(box);
      var frames = 0, last = performance.now(), fps = 0;
      function tick(now) {
        frames += 1;
        if (now - last >= 500) {
          fps = Math.round((frames * 1000) / (now - last));
          frames = 0; last = now;
          var heap = (performance.memory && performance.memory.usedJSHeapSize)
            ? (performance.memory.usedJSHeapSize / 1048576).toFixed(1) + ' MB' : '无法获取';
          box.textContent = 'FPS ' + fps + '\\nJS堆 ' + heap + '\\n(点击隐藏)';
        }
        window.__htmlrunnerOverlayFrame = requestAnimationFrame(tick);
      }
      box.addEventListener('click', function () {
        cancelAnimationFrame(window.__htmlrunnerOverlayFrame);
        box.remove();
        window.__htmlrunnerOverlay = null;
      });
      window.__htmlrunnerOverlay = box;
      window.__htmlrunnerOverlayFrame = requestAnimationFrame(tick);
    })();
    """

    // MARK: Health monitoring
    //
    // A white screen after a load that WebKit reported as successful is the single
    // most common failure mode. This timer correlates "loaded" with "the page has
    // produced no diagnostics of any kind for N seconds" and surfaces a hint. It
    // does NOT restart the page, because a silently restarted game is worse than a
    // visible warning.

    private func startHealthTimer() {
        healthTimer?.invalidate()
        lastActivity = Date()
        healthTimer = Timer.scheduledTimer(withTimeInterval: 5, repeats: true) { [weak self] _ in
            Task { @MainActor in self?.evaluateHealth() }
        }
    }

    private func evaluateHealth() {
        guard phase == .loaded || phase == .loading else { return }
        let silence = Date().timeIntervalSince(lastActivity)
        if phase == .loaded, silence > 20, suspendedWarning == nil {
            suspendedWarning = "页面已加载但 \(Int(silence)) 秒内没有任何诊断事件。可能原因：资源路径错误、脚本异常未上报、或是正在长时间编译着色器。可打开日志查看最后阶段。"
            log.warning(LogEvent.loadProgressStage, "页面静默", metadata: ["seconds": "\(Int(silence))"])
        }
    }

    private func noteActivity() {
        lastActivity = Date()
    }

    private func setPhase(_ newPhase: Phase) {
        if phase != newPhase { phase = newPhase }
    }
}

// MARK: - WKNavigationDelegate

extension WebViewCoordinator: WKNavigationDelegate {

    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        noteActivity()
        navigationCount += 1
        loadStartedAt = Date()
        setPhase(.loading)
        log.info(LogEvent.navigationStart, "开始导航", metadata: [
            "url": sanitized(webView.url),
            "count": "\(navigationCount)",
            "server": serverStatusProvider().description
        ])
        log.info(LogEvent.loadStart, "页面加载开始")
    }

    func webView(_ webView: WKWebView, didCommit navigation: WKNavigation!) {
        noteActivity()
        log.info(LogEvent.navigationCommit, "内容开始到达", metadata: [
            "url": sanitized(webView.url),
            "title": webView.title ?? ""
        ])
    }

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        noteActivity()
        currentURLString = sanitized(webView.url)
        loadFinishedAt = Date()
        if let started = loadStartedAt {
            loadDuration = loadFinishedAt?.timeIntervalSince(started)
        }
        setPhase(.loaded)
        healthTimer?.invalidate()
        log.info(LogEvent.navigationFinish, "导航完成", metadata: [
            "url": currentURLString,
            "title": webView.title ?? "",
            "seconds": loadDuration.map { String(format: "%.2f", $0) } ?? "unknown"
        ])
        log.info(LogEvent.loadFinish, "页面加载完成", metadata: [
            "seconds": loadDuration.map { String(format: "%.2f", $0) } ?? "unknown",
            "entry": configuration.entryRelativePath
        ])
        if configuration.performanceOverlayEnabled {
            setPerformanceOverlay(enabled: true)
        }
        // Ask the page what it actually is, without touching it.
        webView.evaluateJavaScript("[location.href, document.readyState, document.title].join(' | ')") { [weak self] value, _ in
            guard let self, let description = value as? String else { return }
            self.log.info(LogEvent.loadProgressStage, "页面自述", metadata: ["state": description])
        }
    }

    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        noteActivity()
        handleFailure(error, stage: "didFail")
    }

    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        noteActivity()
        handleFailure(error, stage: "didFailProvisionalNavigation")
    }

    private func handleFailure(_ error: Error, stage: String) {
        let nsError = error as NSError
        // -999 / WebKitErrorDomain 102 means "cancelled because a new navigation or a
        // policy decision replaced this one". It is not a bug and must not be shown
        // as one, otherwise every external-link click looks like a crash.
        let isCancellation = nsError.code == NSURLErrorCancelled
            || (nsError.domain == "WebKitErrorDomain" && nsError.code == 102)
        if isCancellation {
            log.info(LogEvent.navigationPolicyBlocked, "导航被取消（属于预期行为）", metadata: [
                "stage": stage,
                "domain": nsError.domain,
                "code": "\(nsError.code)"
            ])
            return
        }

        let description = "\(nsError.localizedDescription) [\(nsError.domain) \(nsError.code)]"
        lastErrorMessage = description
        setPhase(.failed(description))
        log.error(LogEvent.navigationFail, "导航失败", metadata: [
            "stage": stage,
            "url": sanitized(webView.url),
            "domain": nsError.domain,
            "code": "\(nsError.code)",
            "error": nsError.localizedDescription,
            "failingURL": (nsError.userInfo[NSURLErrorFailingURLStringErrorKey] as? String) ?? ""
        ])
        log.error(LogEvent.loadFail, "页面加载失败", metadata: ["error": description])
    }

    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
        noteActivity()
        terminationCount += 1
        setPhase(.terminated)
        let memory = AppMemoryProbe.sample()
        // iOS does not report the reason. Memory pressure is the usual suspect, so the
        // app records what it CAN observe and explicitly refuses to name a cause.
        log.error(LogEvent.webContentTerminated, "网页内容进程被系统终止", metadata: [
            "count": "\(terminationCount)",
            "url": sanitized(webView.url),
            "appResident": memory.residentBytes.map(String.init) ?? "unknown",
            "appFootprint": memory.physicalFootprintBytes.map(String.init) ?? "unknown",
            "deviceFree": memory.deviceFreeBytes.map(String.init) ?? "unknown",
            "thermalState": AppInfo.thermalStateDescription,
            "cause": "系统未提供终止原因（不以推测作为结论）",
            "secondsSinceLastEvent": String(format: "%.1f", Date().timeIntervalSince(lastActivity))
        ])
        healthTimer?.invalidate()
    }

    func webView(_ webView: WKWebView, didReceive challenge: URLAuthenticationChallenge, completionHandler: @escaping (URLSession.AuthChallengeDisposition, URLCredential?) -> Void) {
        // The local server needs no authentication; anything else is refused rather
        // than blindly trusted.
        log.notice(LogEvent.navigationPolicyBlocked, "收到认证挑战，已拒绝", metadata: [
            "host": challenge.protectionSpace.host,
            "method": challenge.protectionSpace.authenticationMethod
        ])
        completionHandler(.performDefaultHandling, nil)
    }

    func webView(_ webView: WKWebView,
                 decidePolicyFor navigationAction: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = navigationAction.request.url else {
            decisionHandler(.allow)
            return
        }

        let scheme = url.scheme?.lowercased() ?? ""
        let isMainFrame = navigationAction.targetFrame?.isMainFrame ?? false

        // Local, in-project navigation: always allowed.
        let localSchemes: Set<String> = ["file", "about", "data", "blob"]
        if localSchemes.contains(scheme) {
            decisionHandler(.allow)
            return
        }

        // The optional loopback server: only requests to 127.0.0.1 are "ours".
        if (scheme == "http" || scheme == "https"), isLoopback(url) {
            decisionHandler(.allow)
            return
        }

        // Anything else leaves the project.
        switch configuration.externalLinkPolicy {
        case .allowInWebView:
            log.notice(LogEvent.navigationExternal, "允许外部导航（用户配置）", metadata: ["url": sanitized(url)])
            decisionHandler(.allow)
        case .block:
            blockCount += 1
            log.notice(LogEvent.navigationExternal, "已阻止离开项目的外部导航", metadata: ["url": sanitized(url)])
            decisionHandler(.cancel)
        case .openInSafari:
            blockCount += 1
            log.notice(LogEvent.navigationExternal, "外部链接转交系统浏览器", metadata: ["url": sanitized(url)])
            if isMainFrame || navigationAction.navigationType == .linkActivated {
                UIApplication.shared.open(url, options: [:]) { [weak self] success in
                    Task { @MainActor in
                        self?.log.info(LogEvent.navigationExternal, "系统浏览器打开结果", metadata: [
                            "opened": "\(success)"
                        ])
                    }
                }
            }
            decisionHandler(.cancel)
        }
    }

    private func isLoopback(_ url: URL) -> Bool {
        guard let host = url.host?.lowercased() else { return false }
        return host == "127.0.0.1" || host == "localhost" || host == "::1"
    }

    func webView(_ webView: WKWebView, decidePolicyFor navigationResponse: WKNavigationResponse, decisionHandler: @escaping (WKNavigationResponsePolicy) -> Void) {
        if let response = navigationResponse.response as? HTTPURLResponse,
           response.statusCode >= 400 {
            log.error(LogEvent.resourceError, "导航响应状态码为错误", metadata: [
                "status": "\(response.statusCode)",
                "url": sanitized(response.url)
            ])
        }
        decisionHandler(.allow)
    }

    /// Reduces a URL to something loggable without dumping a user's full directory
    /// layout into every line. The path is kept because it is what makes a 404
    /// diagnosable; the query string is dropped.
    private func sanitized(_ url: URL?) -> String {
        guard let url else { return "" }
        var components = URLComponents(url: url, resolvingAgainstBaseURL: false)
        components?.query = nil
        components?.fragment = nil
        return components?.string ?? url.absoluteString
    }
}

// MARK: - WKUIDelegate

extension WebViewCoordinator: WKUIDelegate {

    /// A game that calls `window.open` or `alert` must not be able to wedge the app.
    func webView(_ webView: WKWebView,
                 createWebViewWith configuration: WKWebViewConfiguration,
                 for navigationAction: WKNavigationAction,
                 windowFeatures: WKWindowFeatures) -> WKWebView? {
        if let url = navigationAction.request.url {
            log.notice(LogEvent.navigationExternal, "页面请求打开新窗口（已按外部链接策略处理）", metadata: [
                "url": sanitized(url)
            ])
            if configuration.preferences.javaScriptCanOpenWindowsAutomatically {
                // Not silently forwarded; logs above and falls through to the policy.
            }
        }
        return nil
    }

    func webView(_ webView: WKWebView,
                 runJavaScriptAlertPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo,
                 completionHandler: @escaping () -> Void) {
        log.info(LogEvent.javaScriptConsole, "页面 alert", metadata: ["message": String(message.prefix(500))])
        presentSimpleAlert(title: "页面提示", message: message, completion: completionHandler)
    }

    func webView(_ webView: WKWebView,
                 runJavaScriptConfirmPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo,
                 completionHandler: @escaping (Bool) -> Void) {
        log.info(LogEvent.javaScriptConsole, "页面 confirm（自动取消以避免阻塞）", metadata: ["message": String(message.prefix(500))])
        // Auto-cancelling is the safe default: a blocking confirm with no user present
        // would freeze the game loop.
        completionHandler(false)
    }

    func webView(_ webView: WKWebView,
                 runJavaScriptTextInputPanelWithPrompt prompt: String,
                 defaultText: String?,
                 initiatedByFrame frame: WKFrameInfo,
                 completionHandler: @escaping (String?) -> Void) {
        log.info(LogEvent.javaScriptConsole, "页面 prompt（返回空值以避免阻塞）", metadata: ["prompt": String(prompt.prefix(500))])
        completionHandler(nil)
    }

    private func presentSimpleAlert(title: String, message: String, completion: @escaping () -> Void) {
        guard let scene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
              let root = scene.keyWindow?.rootViewController else {
            completion()
            return
        }
        let alert = UIAlertController(title: title, message: String(message.prefix(2_000)), preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "好", style: .default) { _ in completion() })
        root.present(alert, animated: true)
    }
}

// MARK: - WKScriptMessageHandler

extension WebViewCoordinator: WKScriptMessageHandler {

    func userContentController(_ userContentController: WKUserContentController,
                              didReceive message: WKScriptMessage) {
        guard message.name == WebViewFactory.diagnosticsHandlerName else { return }
        noteActivity()
        guard let payload = message.body as? [String: Any],
              let kind = payload["kind"] as? String else {
            log.warning(LogEvent.javaScriptConsole, "收到无法解析的诊断消息")
            return
        }

        func string(_ key: String) -> String? {
            if let value = payload[key] as? String { return value }
            if let value = payload[key] { return String(describing: value) }
            return nil
        }

        switch kind {
        case "ready":
            log.info(LogEvent.loadProgressStage, "页面诊断桥已就绪", metadata: [
                "location": string("location") ?? "",
                "userAgent": string("userAgent") ?? ""
            ])

        case "console":
            let level = string("level") ?? "log"
            let text = string("message") ?? ""
            switch level {
            case "error":
                log.error(LogEvent.javaScriptConsole, "console.error: \(text)")
            case "warn":
                log.warning(LogEvent.javaScriptConsole, "console.warn: \(text)")
            default:
                log.debug(LogEvent.javaScriptConsole, "console.\(level): \(text)")
            }

        case "error":
            var metadata: [String: String] = ["message": string("message") ?? ""]
            if let source = string("source") { metadata["source"] = source }
            if let line = string("line") { metadata["line"] = line }
            if let column = string("column") { metadata["column"] = column }
            if let stack = string("stack") { metadata["stack"] = String(stack.prefix(1_500)) }
            log.error(LogEvent.javaScriptError, "未捕获的 JavaScript 异常", metadata: metadata)

        case "unhandledrejection":
            var metadata: [String: String] = ["message": string("message") ?? ""]
            if let stack = string("stack") { metadata["stack"] = String(stack.prefix(1_500)) }
            log.error(LogEvent.javaScriptPromiseRejection, "未处理的 Promise 拒绝", metadata: metadata)

        case "resourceError":
            log.error(LogEvent.resourceError, "资源加载失败", metadata: [
                "tag": string("tag") ?? "",
                "url": string("url") ?? "",
                "message": string("message") ?? ""
            ])

        case "webglError":
            log.error(LogEvent.webGLError, "WebGL 上下文创建失败", metadata: [
                "message": string("message") ?? "",
                "attributes": string("attributes") ?? ""
            ])

        default:
            log.debug(LogEvent.javaScriptConsole, "诊断消息", metadata: ["kind": kind])
        }
    }
}
