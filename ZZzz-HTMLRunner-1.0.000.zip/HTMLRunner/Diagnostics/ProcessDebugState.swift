//
//  ProcessDebugState.swift
//  HTMLRunner
//
//  Answers one narrow, verifiable question: "is a debugger attached to *this*
//  process right now?".
//
//  This is the only JIT-adjacent question an app can answer about itself with a
//  public API, because:
//
//    * `P_TRACED` in `kinfo_proc.kp_proc.p_flag` is set by the kernel whenever a
//      process is being traced (`ptrace(PT_ATTACH)`), which is exactly the state
//      JIT-enabling tools put an app into before flipping its code-signing flags.
//    * There is NO public API that reports whether JavaScriptCore compiled a
//      function with the JIT, and there is no API at all into the WebContent
//      process that runs WKWebView's page. Anything claiming otherwise would be
//      a guess.
//
//  Therefore: the value produced here describes the app process only. The UI and
//  the docs must not present it as proof that the page runs with JIT.
//

import Foundation
import Darwin

struct ProcessDebugState: Equatable {
    /// True when the kernel reports `P_TRACED` for this process.
    var isBeingTraced: Bool
    /// Raw `p_flag` value, kept for the log so a future agent can re-check the bit.
    var processFlags: UInt32
    /// Reason the value could not be read, if any.
    var failureReason: String?

    var isBeingTracedDescription: String {
        if let failureReason {
            return "无法确认（\(failureReason)）"
        }
        return isBeingTraced ? "是（内核报告 P_TRACED）" : "否（内核未报告 P_TRACED）"
    }

    static func current() -> ProcessDebugState {
        var info = kinfo_proc()
        var size = MemoryLayout<kinfo_proc>.stride
        var mib: [Int32] = [CTL_KERN, KERN_PROC, KERN_PROC_PID, getpid()]

        let result = mib.withUnsafeMutableBufferPointer { buffer -> Int32 in
            sysctl(buffer.baseAddress, u_int(buffer.count), &info, &size, nil, 0)
        }

        guard result == 0, size > 0 else {
            let code = errno
            return ProcessDebugState(isBeingTraced: false,
                                     processFlags: 0,
                                     failureReason: "sysctl(KERN_PROC_PID) 失败 errno=\(code)")
        }

        let flags = UInt32(info.kp_proc.p_flag)
        let traced = (flags & UInt32(P_TRACED)) != 0
        return ProcessDebugState(isBeingTraced: traced, processFlags: flags, failureReason: nil)
    }
}
