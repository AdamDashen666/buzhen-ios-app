//
//  AppInfo.swift
//  HTMLRunner
//
//  Static facts about the running build. Everything here is read from the
//  bundle or from the operating system; nothing is hard-coded and nothing is
//  guessed. Where a value is genuinely unavailable, the API returns nil and the
//  caller is expected to render "无法获取" instead of inventing a value.
//

import Foundation
import Darwin

enum AppInfo {

    // MARK: Bundle

    static var bundleIdentifier: String {
        Bundle.main.bundleIdentifier ?? "unknown"
    }

    static var shortVersion: String {
        (Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String) ?? "0.0.0"
    }

    static var buildNumber: String {
        (Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String) ?? "0"
    }

    static var displayName: String {
        (Bundle.main.object(forInfoDictionaryKey: "CFBundleDisplayName") as? String)
            ?? (Bundle.main.object(forInfoDictionaryKey: "CFBundleName") as? String)
            ?? "HTMLRunner"
    }

    static var versionDescription: String {
        "\(displayName) \(shortVersion) (\(buildNumber))"
    }

    /// `embedded.mobileprovision` presence is *not* a reliable signing check on
    /// modern iOS, so it is reported as a raw observation, not as a conclusion.
    static var hasEmbeddedProvisioningProfile: Bool {
        Bundle.main.url(forResource: "embedded", withExtension: "mobileprovision") != nil
    }

    // MARK: Platform

    static var systemName: String { ProcessInfo.processInfo.operatingSystemVersionString }

    static var osVersion: OperatingSystemVersion { ProcessInfo.processInfo.operatingSystemVersion }

    static var osVersionShort: String {
        let version = osVersion
        return "\(version.majorVersion).\(version.minorVersion).\(version.patchVersion)"
    }

    static var platformDescription: String {
        "\(deviceModelIdentifier ?? "unknown-device") / \(systemName)"
    }

    /// Hardware identifier such as `iPad16,3`. Read via `uname`, which reports the
    /// kernel's machine string on iOS (e.g. `iPad16,3` or an `arm64` fallback in
    /// some contexts). Returns nil when the value cannot be obtained.
    static var deviceModelIdentifier: String? {
        var systemInfo = utsname()
        guard uname(&systemInfo) == 0 else { return nil }
        let mirror = Mirror(reflecting: systemInfo.machine)
        let identifier = mirror.children.reduce(into: "") { partial, element in
            guard let value = element.value as? Int8, value != 0 else { return }
            partial.append(Character(UnicodeScalar(UInt8(bitPattern: value))))
        }
        return identifier.isEmpty ? nil : identifier
    }

    static var physicalMemoryBytes: UInt64 { ProcessInfo.processInfo.physicalMemory }

    static var physicalMemoryDescription: String {
        ByteCountFormatter.string(fromByteCount: Int64(physicalMemoryBytes), countStyle: .memory)
    }

    static var processorCount: Int { ProcessInfo.processInfo.processorCount }

    static var activeProcessorCount: Int { ProcessInfo.processInfo.activeProcessorCount }

    /// iPadOS/iOS expose the thermal state publicly. Useful because it is one of
    /// the confounders that make JavaScript benchmarks unreliable over time.
    static var thermalStateDescription: String {
        switch ProcessInfo.processInfo.thermalState {
        case .nominal: return "nominal"
        case .fair: return "fair"
        case .serious: return "serious"
        case .critical: return "critical"
        @unknown default: return "unknown"
        }
    }

    static var lowPowerModeEnabled: Bool { ProcessInfo.processInfo.isLowPowerModeEnabled }

    // MARK: Build environment
    //
    // These values are baked in at compile time by the Xcode build settings
    // (`SWIFT_ACTIVE_COMPILATION_CONDITIONS` / `-D` flags are not used; the
    // standard `#if targetEnvironment` checks are). They describe how *this*
    // binary was compiled, which matters when diagnosing "it behaves differently
    // than the IPA you gave me".

    static var isSimulatorBuild: Bool {
        #if targetEnvironment(simulator)
        return true
        #else
        return false
        #endif
    }

    static var isDebugBuild: Bool {
        #if DEBUG
        return true
        #else
        return false
        #endif
    }

    static var buildConfigurationName: String { isDebugBuild ? "Debug" : "Release" }

    /// Snapshot used by the diagnostics screen and by exported reports.
    static func snapshot() -> [(String, String)] {
        var rows: [(String, String)] = [
            ("App 版本", shortVersion),
            ("构建号", buildNumber),
            ("Bundle ID", bundleIdentifier),
            ("构建配置", buildConfigurationName),
            ("编译目标", isSimulatorBuild ? "Simulator" : "Device (arm64)"),
            ("系统版本", systemName),
            ("设备型号标识", deviceModelIdentifier ?? "无法获取"),
            ("物理内存", physicalMemoryDescription),
            ("CPU 核心数", "\(processorCount) (活动 \(activeProcessorCount))"),
            ("热状态", thermalStateDescription),
            ("低电量模式", lowPowerModeEnabled ? "已开启" : "已关闭"),
            ("embedded.mobileprovision", hasEmbeddedProvisioningProfile ? "存在" : "不存在")
        ]
        if let version = WebRuntimeInfo.kitVersion {
            rows.append(("WebKit 版本(可用时)", version))
        }
        return rows
    }
}
