//
//  AppMemory.swift
//  HTMLRunner
//
//  Reads the memory figures the OS is actually willing to hand to a third-party
//  app. There is no public API that reports the WebContent process footprint,
//  so this file never pretends to. Unavailable fields are `nil` and are rendered
//  as "无法获取".
//

import Foundation
import Darwin
import MachO

struct AppMemorySample: Equatable {
    /// Physical memory currently resident in this process (`task_vm_info.resident_size`).
    var residentBytes: UInt64?
    /// The figure the OS uses for jetsam decisions (`phys_footprint`).
    var physicalFootprintBytes: UInt64?
    /// Virtual size, useful only to spot runaway mappings.
    var virtualBytes: UInt64?
    /// Bytes currently in use by the malloc zones of this process.
    var mallocBytes: UInt64?
    /// Device-wide free memory. This is *not* the app's budget; it is context only.
    var deviceFreeBytes: UInt64?
    var deviceTotalBytes: UInt64?
    var timestamp: Date

    var residentDescription: String {
        residentBytes.map { ByteCountFormatter.string(fromByteCount: Int64($0), countStyle: .memory) } ?? "无法获取"
    }

    var footprintDescription: String {
        physicalFootprintBytes.map { ByteCountFormatter.string(fromByteCount: Int64($0), countStyle: .memory) } ?? "无法获取"
    }

    var virtualDescription: String {
        virtualBytes.map { ByteCountFormatter.string(fromByteCount: Int64($0), countStyle: .memory) } ?? "无法获取"
    }

    var mallocDescription: String {
        mallocBytes.map { ByteCountFormatter.string(fromByteCount: Int64($0), countStyle: .memory) } ?? "无法获取"
    }

    var deviceFreeDescription: String {
        deviceFreeBytes.map { ByteCountFormatter.string(fromByteCount: Int64($0), countStyle: .memory) } ?? "无法获取"
    }

    /// A one-line summary suitable for the log.
    var logSummary: String {
        "resident=\(residentBytes.map(String.init) ?? "nil") footprint=\(physicalFootprintBytes.map(String.init) ?? "nil") virtual=\(virtualBytes.map(String.init) ?? "nil") deviceFree=\(deviceFreeBytes.map(String.init) ?? "nil")"
    }
}

enum AppMemoryProbe {

    /// Samples this process. Returns `nil` only if even the timestamp could not be made.
    static func sample() -> AppMemorySample {
        let taskInfo = taskVMInfo()
        return AppMemorySample(
            residentBytes: taskInfo?.resident,
            physicalFootprintBytes: taskInfo?.footprint,
            virtualBytes: taskInfo?.virtualSize,
            mallocBytes: mallocFootprint(),
            deviceFreeBytes: hostMemory(page: false),
            deviceTotalBytes: ProcessInfo.processInfo.physicalMemory,
            timestamp: Date()
        )
    }

    // MARK: task_vm_info

    private struct TaskVMFigures {
        var virtualSize: UInt64
        var resident: UInt64
        var footprint: UInt64
    }

    /// `MACH_TASK_BASIC_INFO` is not available to App Store style sandboxes on all
    /// OS versions, but `TASK_VM_INFO` (count = `TASK_VM_INFO_COUNT`) is the
    /// documented way to obtain `phys_footprint`, which is what jetsam watches.
    private static func taskVMInfo() -> TaskVMFigures? {
        var info = task_vm_info_data_t()
        var count = mach_msg_type_number_t(MemoryLayout<task_vm_info_data_t>.size / MemoryLayout<natural_t>.size)
        let result = withUnsafeMutablePointer(to: &info) { pointer -> kern_return_t in
            pointer.withMemoryRebound(to: integer_t.self, capacity: Int(count)) { reboundPointer in
                task_info(mach_task_self_, task_flavor_t(TASK_VM_INFO), reboundPointer, &count)
            }
        }
        guard result == KERN_SUCCESS else { return nil }

        let footprint = UInt64(info.phys_footprint)
        // A zero footprint is technically a valid "could not be determined" value
        // for some sandbox configurations; treat it as absent rather than as 0 B.
        return TaskVMFigures(virtualSize: UInt64(info.virtual_size),
                             resident: UInt64(info.resident_size),
                             footprint: footprint == 0 ? UInt64(info.resident_size) : footprint)
    }

    // MARK: malloc

    private static func mallocFootprint() -> UInt64? {
        var stats = malloc_statistics_t()
        malloc_zone_statistics(malloc_default_zone(), &stats)
        let size = UInt64(stats.size_in_use)
        return size == 0 ? nil : size
    }

    // MARK: host statistics
    //
    // `host_statistics64` with `HOST_VM_INFO64` is available but on iOS the
    // free-page count reflects the whole device, not this app's headroom, and the
    // sandbox may refuse it. Both facts are reported honestly by returning nil.
    private static func hostMemory(page: Bool) -> UInt64? {
        var pageSize: vm_size_t = 0
        guard host_page_size(mach_host_self(), &pageSize) == KERN_SUCCESS else { return nil }

        var stats = vm_statistics64_data_t()
        var count = mach_msg_type_number_t(MemoryLayout<vm_statistics64_data_t>.size / MemoryLayout<integer_t>.size)
        let result = withUnsafeMutablePointer(to: &stats) { pointer -> kern_return_t in
            pointer.withMemoryRebound(to: integer_t.self, capacity: Int(count)) { reboundPointer in
                host_statistics64(mach_host_self(), HOST_VM_INFO64, reboundPointer, &count)
            }
        }
        guard result == KERN_SUCCESS, pageSize > 0 else { return nil }

        let freePages = UInt64(stats.free_count) + UInt64(stats.speculative_count)
        let bytes = freePages * UInt64(pageSize)
        return bytes == 0 ? nil : bytes
    }
}
