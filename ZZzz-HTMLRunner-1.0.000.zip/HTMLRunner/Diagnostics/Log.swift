//
//  Log.swift
//  HTMLRunner
//
//  Lightweight, bounded, file-backed diagnostic log.
//
//  Design notes:
//  * This log is deliberately independent from `os.Logger` so that it also works
//    when the log file is the only artefact a user can export from a sideloaded
//    build (no Xcode console attached).
//  * The store is bounded twice: by a line cap and by a byte cap. Oldest entries
//    are dropped first, so the file can never grow without limit.
//  * Only data the system actually provides is recorded. Nothing is invented.
//

import Foundation

// MARK: - Level

enum LogLevel: String, Codable, CaseIterable, Comparable, Identifiable {
    case debug
    case info
    case notice
    case warning
    case error

    var id: String { rawValue }

    var title: String {
        switch self {
        case .debug: return "调试"
        case .info: return "信息"
        case .notice: return "注意"
        case .warning: return "警告"
        case .error: return "错误"
        }
    }

    var symbolName: String {
        switch self {
        case .debug: return "ant"
        case .info: return "info.circle"
        case .notice: return "bell"
        case .warning: return "exclamationmark.triangle"
        case .error: return "xmark.octagon"
        }
    }

    private var rank: Int {
        switch self {
        case .debug: return 0
        case .info: return 1
        case .notice: return 2
        case .warning: return 3
        case .error: return 4
        }
    }

    static func < (lhs: LogLevel, rhs: LogLevel) -> Bool { lhs.rank < rhs.rank }
}

// MARK: - Entry

struct LogEntry: Identifiable, Hashable, Codable {
    let id: UUID
    let date: Date
    let level: LogLevel
    /// Stable, greppable event identifier, e.g. `navigation.start`.
    let event: String
    let message: String
    let metadata: [String: String]

    init(level: LogLevel, event: String, message: String, metadata: [String: String] = [:], date: Date = Date()) {
        self.id = UUID()
        self.date = date
        self.level = level
        self.event = event
        self.message = message
        self.metadata = metadata
    }
}

// MARK: - Event names
//
// Centralised so that every module logs the same identifiers and the exported
// log stays greppable.
enum LogEvent {
    static let appLaunch = "app.launch"
    static let appVersion = "app.version"
    static let appMemorySample = "app.memory.sample"
    static let appMemoryUnavailable = "app.memory.unavailable"

    static let importStarted = "project.import.start"
    static let importProgress = "project.import.progress"
    static let importFinished = "project.import.finish"
    static let importFailed = "project.import.fail"
    static let importCancelled = "project.import.cancel"
    static let importDiskSpace = "project.import.diskspace"

    static let projectDelete = "project.delete"
    static let projectRename = "project.rename"
    static let projectMissing = "project.missing"

    static let navigationStart = "navigation.start"
    static let navigationCommit = "navigation.commit"
    static let navigationFinish = "navigation.finish"
    static let navigationFail = "navigation.fail"
    static let navigationPolicyBlocked = "navigation.policy.blocked"
    static let navigationExternal = "navigation.external"

    static let loadStart = "page.load.start"
    static let loadFinish = "page.load.finish"
    static let loadFail = "page.load.fail"
    static let loadTimeout = "page.load.timeout"
    static let loadProgressStage = "page.load.stage"

    static let webContentTerminated = "webcontent.terminated"
    static let webContentRestored = "webcontent.restored"
    static let webContentUnresponsive = "webcontent.unresponsive"
    static let webContentResponsive = "webcontent.responsive"
    static let webViewCreated = "webview.create"
    static let webViewSnapshotRejected = "webview.snapshot.rejected"

    static let javaScriptError = "js.error"
    static let javaScriptPromiseRejection = "js.unhandledrejection"
    static let javaScriptConsole = "js.console"
    static let javaScriptException = "js.exception"
    static let webGLError = "webgl.error"
    static let resourceError = "resource.error"

    static let userReload = "user.reload"
    static let userStop = "user.stop"
    static let userRun = "user.run"
    static let userOpenProject = "user.openProject"

    static let jitProbeStart = "jit.probe.start"
    static let jitProbeResult = "jit.probe.result"
    static let jitProbeFailed = "jit.probe.fail"
    static let perfProbeResult = "perf.probe.result"
    static let perfProbeFailed = "perf.probe.fail"

    static let localServerStart = "server.start"
    static let localServerReady = "server.ready"
    static let localServerStop = "server.stop"
    static let localServerFail = "server.fail"
    static let localServerRequest = "server.request"
    static let localServerDenied = "server.denied"

    static let settingsChanged = "settings.change"
    static let logCleared = "log.clear"
    static let logExported = "log.export"
    static let diagnosticExport = "diagnostic.export"
}

// MARK: - Store

/// Observable, bounded log store.
///
/// `@MainActor` so that SwiftUI and the WebKit delegates can all mutate it
/// without additional locking; every WebKit callback that logs is already
/// delivered on the main thread.
@MainActor
final class DiagnosticLogStore: ObservableObject {

    /// Maximum number of entries kept in memory and on disk.
    static let maxEntries = 4_000
    /// Maximum size of the on-disk log before it is truncated.
    static let maxFileBytes = 3 * 1_024 * 1_024
    /// Maximum size of a single exported bundle.
    static let exportFileName = "HTMLRunner-Logs.txt"

    @Published private(set) var entries: [LogEntry] = []

    /// Minimum level that is retained in memory.
    var minimumLevel: LogLevel = .debug

    private let fileURL: URL
    private let encoder: JSONEncoder
    private var droppedCount = 0

    init(fileURL: URL? = nil) {
        self.fileURL = fileURL ?? DiagnosticLogStore.defaultFileURL()
        let encoder = JSONEncoder()
        encoder.dateEncodingStrategy = .iso8601
        self.encoder = encoder
    }

    nonisolated static func defaultFileURL() -> URL {
        let base = (try? FileManager.default.url(for: .applicationSupportDirectory,
                                                 in: .userDomainMask,
                                                 appropriateFor: nil,
                                                 create: true))
            ?? URL(fileURLWithPath: NSTemporaryDirectory(), isDirectory: true)
        let directory = base.appendingPathComponent("HTMLRunner", isDirectory: true)
        try? FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        return directory.appendingPathComponent("diagnostics.jsonl", isDirectory: false)
    }

    // MARK: Recording

    @MainActor
    func log(_ level: LogLevel, _ event: String, _ message: String, metadata: [String: String] = [:]) {
        guard level >= minimumLevel else { return }
        let entry = LogEntry(level: level, event: event, message: message, metadata: metadata)
        append(entry)
    }

    func debug(_ event: String, _ message: String, metadata: [String: String] = [:]) {
        log(.debug, event, message, metadata: metadata)
    }

    func info(_ event: String, _ message: String, metadata: [String: String] = [:]) {
        log(.info, event, message, metadata: metadata)
    }

    func notice(_ event: String, _ message: String, metadata: [String: String] = [:]) {
        log(.notice, event, message, metadata: metadata)
    }

    func warning(_ event: String, _ message: String, metadata: [String: String] = [:]) {
        log(.warning, event, message, metadata: metadata)
    }

    func error(_ event: String, _ message: String, metadata: [String: String] = [:]) {
        log(.error, event, message, metadata: metadata)
    }

    private func append(_ entry: LogEntry) {
        entries.append(entry)
        if entries.count > Self.maxEntries {
            let overflow = entries.count - Self.maxEntries
            entries.removeFirst(overflow)
            droppedCount += overflow
        }
        let fileURL = self.fileURL
        let encoder = self.encoder
        Task.detached(priority: .utility) { [fileURL, encoder, entry] in
            DiagnosticLogStore.appendToDisk(entry: entry, fileURL: fileURL, encoder: encoder)
        }
    }

    // MARK: Filtering / export

    func filtered(level: LogLevel, search: String) -> [LogEntry] {
        let needle = search.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        return entries.filter { entry in
            guard entry.level >= level else { return false }
            guard !needle.isEmpty else { return true }
            return entry.message.lowercased().contains(needle)
                || entry.event.lowercased().contains(needle)
                || entry.metadata.values.contains { $0.lowercased().contains(needle) }
        }
    }

    /// Plain-text rendering used for the in-app viewer, the clipboard and export.
    func plainText(level: LogLevel = .debug, search: String = "") -> String {
        var lines: [String] = []
        lines.append("# HTMLRunner 诊断日志")
        lines.append("# 生成时间: \(Self.isoFormatter.string(from: Date()))")
        lines.append("# 版本: \(AppInfo.versionDescription)")
        lines.append("# 平台: \(AppInfo.platformDescription)")
        if droppedCount > 0 {
            lines.append("# 注意: 有 \(droppedCount) 条较早的日志因超出容量上限已被丢弃")
        }
        lines.append("")
        for entry in filtered(level: level, search: search) {
            var line = "\(Self.isoFormatter.string(from: entry.date)) [\(entry.level.rawValue.uppercased())] \(entry.event): \(entry.message)"
            if !entry.metadata.isEmpty {
                let pairs = entry.metadata
                    .sorted { $0.key < $1.key }
                    .map { "\($0.key)=\($0.value)" }
                    .joined(separator: " ")
                line += " {\(pairs)}"
            }
            lines.append(line)
        }
        lines.append("")
        return lines.joined(separator: "\n")
    }

    func clear() {
        entries.removeAll()
        droppedCount = 0
        try? FileManager.default.removeItem(at: fileURL)
        info(LogEvent.logCleared, "日志已由用户清空")
    }

    /// Writes the current log to `url` (an exported copy). Never throws silently.
    func export(to url: URL, level: LogLevel = .debug, search: String = "") throws {
        let text = plainText(level: level, search: search)
        try text.write(to: url, atomically: true, encoding: .utf8)
        info(LogEvent.logExported, "日志已导出", metadata: ["file": url.lastPathComponent])
    }

    var fileURLForDebugging: URL { fileURL }

    var droppedEntryCount: Int { droppedCount }

    // MARK: Disk backing

    nonisolated private static func appendToDisk(entry: LogEntry, fileURL: URL, encoder: JSONEncoder) {
        guard let data = try? encoder.encode(entry) else { return }
        var line = data
        line.append(0x0A)
        let manager = FileManager.default

        if !manager.fileExists(atPath: fileURL.path) {
            try? manager.createDirectory(at: fileURL.deletingLastPathComponent(),
                                         withIntermediateDirectories: true)
            try? line.write(to: fileURL, options: .atomic)
            return
        }

        // Rotate before the file can grow unbounded.
        if let size = try? manager.attributesOfItem(atPath: fileURL.path)[.size] as? Int,
           size > maxFileBytes {
            let rotated = fileURL.appendingPathExtension("1")
            try? manager.removeItem(at: rotated)
            try? manager.moveItem(at: fileURL, to: rotated)
            try? line.write(to: fileURL, options: .atomic)
            return
        }

        guard let handle = try? FileHandle(forWritingTo: fileURL) else { return }
        defer { try? handle.close() }
        _ = try? handle.seekToEnd()
        try? handle.write(contentsOf: line)
    }

    nonisolated static let isoFormatter: ISO8601DateFormatter = {
        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        return formatter
    }()
}
