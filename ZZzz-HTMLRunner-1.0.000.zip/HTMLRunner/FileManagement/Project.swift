//
//  Project.swift
//  HTMLRunner
//
//  A "project" is a directory the user imported into the app sandbox. The record
//  stores only metadata; the files themselves live under
//  `Documents/Projects/<projectDirectoryName>/` and are never duplicated in memory.
//

import Foundation

struct Project: Identifiable, Codable, Hashable {
    let id: UUID
    var name: String
    /// Directory name inside `Documents/Projects`. Generated to be filesystem-safe
    /// while preserving the user's original name in `name`.
    var directoryName: String
    /// Entry file relative to the project root, e.g. `index.html` or `game/main.html`.
    var entryRelativePath: String
    /// How the project was imported. Files are copied in both cases; the origin is
    /// kept only for diagnostics.
    var importedFromFolder: Bool
    var importedAt: Date
    var lastOpenedAt: Date?
    var lastRunSucceeded: Bool?
    /// Best-effort statistics gathered while copying (streamed, never buffered).
    var fileCount: Int
    var totalBytes: Int64
    /// Set when the project was imported as a single HTML file: the directory that
    /// was scanned for sibling assets, relative to the project root.
    var notes: String?

    init(id: UUID = UUID(),
         name: String,
         directoryName: String,
         entryRelativePath: String,
         importedFromFolder: Bool,
         importedAt: Date = Date(),
         lastOpenedAt: Date? = nil,
         lastRunSucceeded: Bool? = nil,
         fileCount: Int = 0,
         totalBytes: Int64 = 0,
         notes: String? = nil) {
        self.id = id
        self.name = name
        self.directoryName = directoryName
        self.entryRelativePath = entryRelativePath
        self.importedFromFolder = importedFromFolder
        self.importedAt = importedAt
        self.lastOpenedAt = lastOpenedAt
        self.lastRunSucceeded = lastRunSucceeded
        self.fileCount = fileCount
        self.totalBytes = totalBytes
        self.notes = notes
    }

    var sizeDescription: String {
        ByteCountFormatter.string(fromByteCount: totalBytes, countStyle: .file)
    }

    var importedFromDescription: String {
        importedFromFolder ? "文件夹导入" : "单个 HTML 文件"
    }
}

extension Project {
    /// Relative path helpers. The entry file always uses POSIX separators so it can
    /// be turned into a URL and into an HTTP path identically.
    var entryPathComponents: [String] {
        entryRelativePath.split(separator: "/").map(String.init)
    }

    func rootURL(in baseDirectory: URL) -> URL {
        baseDirectory.appendingPathComponent(directoryName, isDirectory: true)
    }

    func entryURL(in baseDirectory: URL) -> URL {
        entryPathComponents.reduce(rootURL(in: baseDirectory)) { partial, component in
            partial.appendingPathComponent(component, isDirectory: false)
        }
    }
}

/// Lightweight value used for persistence and for the "recently opened" list.
struct ProjectLibrarySnapshot: Codable {
    var projects: [Project]
    var schemaVersion: Int
}
