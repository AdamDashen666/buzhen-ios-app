//
//  ProjectStore.swift
//  HTMLRunner
//
//  Owns the on-disk project library:
//
//      <Documents>/Projects/<directoryName>/…            imported files
//      <Application Support>/HTMLRunner/library.json     metadata
//
//  Import is *streamed*: entries are enumerated one at a time, each file is copied
//  with a chunked copy loop, and nothing larger than one chunk is ever held in
//  memory. That is what keeps the import of a multi-gigabyte project flat in RSS.
//

import Foundation
import UIKit

// MARK: - Errors

enum ProjectImportError: LocalizedError {
    case cancelledByUser
    case missingSecurityScopedAccess(String)
    case sourceNotReadable(String)
    case notEnoughDiskSpace(required: Int64, available: Int64)
    case duplicateName(String)
    case copyFailed(path: String, underlying: String)
    case noFilesCopied(String)

    var errorDescription: String? {
        switch self {
        case .cancelledByUser:
            return "导入已取消。"
        case .missingSecurityScopedAccess(let path):
            return "无法获得对所选位置的安全作用域访问权限（\(path)）。请重新选择文件或文件夹。"
        case .sourceNotReadable(let path):
            return "无法读取所选位置：\(path)"
        case .notEnoughDiskSpace(let required, let available):
            let need = ByteCountFormatter.string(fromByteCount: required, countStyle: .file)
            let have = ByteCountFormatter.string(fromByteCount: available, countStyle: .file)
            return "磁盘空间不足：需要约 \(need)，当前可用 \(have)。"
        case .duplicateName(let name):
            return "已存在同名项目「\(name)」。请先删除或重命名，或改用其他名称导入。"
        case .copyFailed(let path, let underlying):
            return "复制文件失败：\(path)\n\(underlying)"
        case .noFilesCopied(let path):
            return "所选位置没有可导入的文件：\(path)"
        }
    }
}

// MARK: - Progress

struct ImportProgress {
    var bytesCopied: Int64 = 0
    var bytesTotal: Int64
    /// 0…1. Only meaningful once `bytesTotal` is known.
    var fraction: Double {
        guard bytesTotal > 0 else { return 0 }
        return min(1, Double(bytesCopied) / Double(bytesTotal))
    }
    var filesCopied: Int = 0
    var totalFiles: Int = 0
    /// Current file being copied, relative to the selected root.
    var currentRelativePath: String = ""
}

/// Thrown internally when the user cancels; caught by the importer.
private struct ImportCancellationSignal: Error {}

// MARK: - Store

@MainActor
final class ProjectStore: ObservableObject {

    static let maximumReportedFileCount = 200_000
    static let maximumReportedByteCount: Int64 = 1 << 50   // 1 PiB guard against overflow
    private static let copyChunkSize = 1 << 18             // 256 KiB
    private static let freeSpaceSafetyMargin: Int64 = 256 * 1_024 * 1_024

    @Published private(set) var projects: [Project] = []
    @Published private(set) var isImporting = false
    @Published private(set) var importProgress: ImportProgress?
    @Published private(set) var importStatusText: String = ""

    private var importTask: Task<Void, Never>?
    private var cancellationRequested = false

    private let log: DiagnosticLogStore

    init(log: DiagnosticLogStore) {
        self.log = log
        load()
    }

    // MARK: Locations

    var projectsRootDirectory: URL {
        let documents = (try? FileManager.default.url(for: .documentDirectory,
                                                      in: .userDomainMask,
                                                      appropriateFor: nil,
                                                      create: true))
            ?? URL(fileURLWithPath: NSTemporaryDirectory(), isDirectory: true)
        let root = documents.appendingPathComponent("Projects", isDirectory: true)
        if !FileManager.default.fileExists(atPath: root.path) {
            try? FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
        }
        return root
    }

    private var libraryURL: URL {
        let base = (try? FileManager.default.url(for: .applicationSupportDirectory,
                                                 in: .userDomainMask,
                                                 appropriateFor: nil,
                                                 create: true))
            ?? URL(fileURLWithPath: NSTemporaryDirectory(), isDirectory: true)
        let directory = base.appendingPathComponent("HTMLRunner", isDirectory: true)
        try? FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        return directory.appendingPathComponent("library.json", isDirectory: false)
    }

    // MARK: Persistence

    private func load() {
        guard let data = try? Data(contentsOf: libraryURL) else {
            log.info(LogEvent.appLaunch, "项目库为空，首次运行")
            return
        }
        do {
            let snapshot = try JSONDecoder().decode(ProjectLibrarySnapshot.self, from: data)
            projects = snapshot.projects.sorted { lhs, rhs in
                (lhs.lastOpenedAt ?? lhs.importedAt) > (rhs.lastOpenedAt ?? rhs.importedAt)
            }
            log.info(LogEvent.appLaunch, "已载入项目库", metadata: ["count": "\(projects.count)"])
        } catch {
            log.error(LogEvent.importFailed, "项目库解析失败，已保留原文件并忽略", metadata: ["error": error.localizedDescription])
        }
    }

    private func persist() {
        let snapshot = ProjectLibrarySnapshot(projects: projects, schemaVersion: 1)
        do {
            let encoder = JSONEncoder()
            encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
            let data = try encoder.encode(snapshot)
            try data.write(to: libraryURL, options: .atomic)
        } catch {
            log.error(LogEvent.importFailed, "项目库写入失败", metadata: ["error": error.localizedDescription])
        }
    }

    // MARK: Queries

    func project(withID id: UUID) -> Project? {
        projects.first { $0.id == id }
    }

    func rootURL(for project: Project) -> URL {
        project.rootURL(in: projectsRootDirectory)
    }

    func entryURL(for project: Project) -> URL {
        project.entryURL(in: projectsRootDirectory)
    }

    func entryExists(for project: Project) -> Bool {
        FileManager.default.fileExists(atPath: entryURL(for: project).path)
    }

    func recentlyOpened(limit: Int = 8) -> [Project] {
        projects
            .filter { $0.lastOpenedAt != nil }
            .sorted { ($0.lastOpenedAt ?? .distantPast) > ($1.lastOpenedAt ?? .distantPast) }
            .prefix(limit)
            .map { $0 }
    }

    // MARK: Mutation

    func markOpened(_ project: Project) {
        guard let index = projects.firstIndex(where: { $0.id == project.id }) else { return }
        projects[index].lastOpenedAt = Date()
        persist()
    }

    func recordRunOutcome(_ project: Project, succeeded: Bool) {
        guard let index = projects.firstIndex(where: { $0.id == project.id }) else { return }
        projects[index].lastRunSucceeded = succeeded
        projects[index].lastOpenedAt = Date()
        persist()
    }

    func rename(_ project: Project, to newName: String) throws {
        let trimmed = newName.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }
        guard let index = projects.firstIndex(where: { $0.id == project.id }) else { return }
        let previous = projects[index].name
        projects[index].name = trimmed
        persist()
        log.notice(LogEvent.projectRename, "项目已重命名", metadata: ["from": previous, "to": trimmed])
    }

    /// Deletes the project directory and drops its metadata. The directory removal
    /// happens off the main actor because a multi-gigabyte tree can take a while.
    func delete(_ project: Project) async {
        let root = rootURL(for: project)
        projects.removeAll { $0.id == project.id }
        persist()
        let log = self.log
        await Task.detached(priority: .utility) {
            do {
                if FileManager.default.fileExists(atPath: root.path) {
                    try FileManager.default.removeItem(at: root)
                }
                await MainActor.run {
                    log.notice(LogEvent.projectDelete, "项目已删除", metadata: ["name": project.name])
                }
            } catch {
                await MainActor.run {
                    log.error(LogEvent.projectDelete, "项目删除失败", metadata: [
                        "name": project.name,
                        "error": error.localizedDescription
                    ])
                }
            }
        }.value
    }

    func updateEntryPath(_ project: Project, relativePath: String) {
        guard let index = projects.firstIndex(where: { $0.id == project.id }) else { return }
        projects[index].entryRelativePath = relativePath
        persist()
        log.notice(LogEvent.settingsChanged, "入口文件已更新", metadata: [
            "project": project.name,
            "entry": relativePath
        ])
    }

    // MARK: Import control

    func cancelImport() {
        guard isImporting else { return }
        cancellationRequested = true
        log.notice(LogEvent.importCancelled, "用户请求取消导入")
    }

    /// Imports a directory. Returns the created project on success.
    @discardableResult
    func importFolder(at url: URL, suggestedName: String) async throws -> Project {
        try await runImport { [weak self] in
            guard let self else { throw ProjectImportError.cancelledByUser }
            return try await self.performFolderImport(at: url, suggestedName: suggestedName)
        }
    }

    /// Imports a single HTML file together with the files that sit next to it.
    /// Siblings are copied *selectively* (see `shouldCopySibling`) so that picking
    /// one file from a huge directory does not silently clone the whole directory;
    /// the result is reported in `Project.notes` so the user is never misled.
    @discardableResult
    func importHTMLFile(at url: URL, suggestedName: String) async throws -> Project {
        try await runImport { [weak self] in
            guard let self else { throw ProjectImportError.cancelledByUser }
            return try await self.performFileImport(at: url, suggestedName: suggestedName)
        }
    }

    private func runImport(_ operation: @escaping () async throws -> Project) async throws -> Project {
        guard !isImporting else { throw ProjectImportError.duplicateName("已有导入任务在进行") }
        isImporting = true
        cancellationRequested = false
        importProgress = nil
        importStatusText = "准备中…"
        defer {
            isImporting = false
            importProgress = nil
            importStatusText = ""
        }
        do {
            let project = try await operation()
            return project
        } catch is ImportCancellationSignal {
            throw ProjectImportError.cancelledByUser
        }
    }

    private func checkCancellation() throws {
        if cancellationRequested || Task.isCancelled {
            throw ImportCancellationSignal()
        }
    }

    // MARK: Folder import

    private func performFolderImport(at url: URL, suggestedName: String) async throws -> Project {
        log.info(LogEvent.importStarted, "开始导入文件夹", metadata: ["source": url.lastPathComponent])

        let didAccess = url.startAccessingSecurityScopedResource()
        defer { if didAccess { url.stopAccessingSecurityScopedResource() } }
        if !didAccess {
            // Not fatal for files inside the app's own container, but it is a real
            // signal when the picker returned a file-provider URL.
            log.notice(LogEvent.importStarted, "未能开启 security-scoped 访问，尝试直接读取", metadata: ["path": url.lastPathComponent])
        }

        // Planning (a full tree walk) runs off the main actor; the files themselves
        // are not touched here, only their metadata.
        let plan = try await Task.detached(priority: .userInitiated) { () -> ImportPlan in
            try ProjectStore.planForDirectory(url)
        }.value

        return try await copyPlan(plan, displayName: suggestedName, importedFromFolder: true, notes: nil)
    }

    // MARK: Single file import

    private func performFileImport(at url: URL, suggestedName: String) async throws -> Project {
        log.info(LogEvent.importStarted, "开始导入单个 HTML 文件", metadata: ["source": url.lastPathComponent])

        let didAccess = url.startAccessingSecurityScopedResource()
        defer { if didAccess { url.stopAccessingSecurityScopedResource() } }
        if !didAccess {
            log.notice(LogEvent.importStarted, "未能开启 security-scoped 访问，尝试直接读取", metadata: ["path": url.lastPathComponent])
        }

        let plan = try await Task.detached(priority: .userInitiated) { () -> ImportPlan in
            try ProjectStore.planForSingleFile(url)
        }.value

        let notes = "以单个 HTML 文件导入；同目录下的 \(plan.siblingCount) 个资源文件已一并复制（不含子目录）。"
        return try await copyPlan(plan, displayName: suggestedName, importedFromFolder: false, notes: notes)
    }

    // MARK: Planning

    private struct PlannedFile {
        var source: URL
        /// POSIX-style path relative to the project root.
        var relativePath: String
        var size: Int64
    }

    private struct ImportPlan {
        var files: [PlannedFile] = []
        var totalBytes: Int64 = 0
        var directoryCount: Int = 0
        var siblingCount: Int = 0
        var skippedCount: Int = 0
        var entryRelativePath: String
        /// Root of the source tree (used to compute relative paths already).
        var sourceRoot: URL
    }

    private nonisolated static func planForDirectory(_ url: URL) throws -> ImportPlan {
        let manager = FileManager.default
        var plan = ImportPlan(entryRelativePath: "index.html", sourceRoot: url)

        let keys: [URLResourceKey] = [.isDirectoryKey, .fileSizeKey, .isRegularFileKey, .isSymbolicLinkKey, .nameKey]
        guard let enumerator = manager.enumerator(at: url,
                                                  includingPropertiesForKeys: keys,
                                                  options: [.skipsHiddenFiles],
                                                  errorHandler: { _, _ in true }) else {
            throw ProjectImportError.sourceNotReadable(url.lastPathComponent)
        }

        let rootPath = url.standardizedFileURL.path
        var htmlCandidates: [String] = []

        for case let fileURL as URL in enumerator {
            try Task.checkCancellation()
            let values = try? fileURL.resourceValues(forKeys: Set(keys))
            if values?.isDirectory == true {
                plan.directoryCount += 1
                continue
            }
            guard values?.isRegularFile != false else {
                plan.skippedCount += 1
                continue
            }
            let fullPath = fileURL.standardizedFileURL.path
            guard fullPath.hasPrefix(rootPath) else {
                plan.skippedCount += 1
                continue
            }
            var relative = String(fullPath.dropFirst(rootPath.count))
            while relative.hasPrefix("/") { relative.removeFirst() }
            guard !relative.isEmpty else { continue }

            let size = Int64(values?.fileSize ?? 0)
            if plan.totalBytes < ProjectStore.maximumReportedByteCount {
                plan.totalBytes += size
            }
            if plan.files.count < ProjectStore.maximumReportedFileCount {
                plan.files.append(PlannedFile(source: fileURL, relativePath: relative, size: size))
            } else {
                plan.skippedCount += 1
            }
            if relative.lowercased().hasSuffix(".html") || relative.lowercased().hasSuffix(".htm") {
                htmlCandidates.append(relative)
            }
        }

        if plan.files.isEmpty {
            throw ProjectImportError.noFilesCopied(url.lastPathComponent)
        }

        plan.entryRelativePath = ImportPlanner.chooseEntryPath(from: htmlCandidates)
        return plan
    }

    private nonisolated static func planForSingleFile(_ url: URL) throws -> ImportPlan {
        let manager = FileManager.default
        var plan = ImportPlan(entryRelativePath: url.lastPathComponent, sourceRoot: url.deletingLastPathComponent())

        let fileSize = (try? url.resourceValues(forKeys: [.fileSizeKey]).fileSize).flatMap { Int64($0) } ?? 0
        plan.files.append(PlannedFile(source: url, relativePath: url.lastPathComponent, size: fileSize))
        plan.totalBytes += fileSize

        let parent = url.deletingLastPathComponent()
        let keys: [URLResourceKey] = [.isDirectoryKey, .isRegularFileKey, .fileSizeKey]
        let contents = (try? manager.contentsOfDirectory(at: parent,
                                                        includingPropertiesForKeys: keys,
                                                        options: [.skipsHiddenFiles])) ?? []
        for sibling in contents {
            try Task.checkCancellation()
            guard sibling.standardizedFileURL != url.standardizedFileURL else { continue }
            let values = try? sibling.resourceValues(forKeys: Set(keys))
            guard values?.isRegularFile == true else { continue }
            guard ImportPlanner.shouldCopySibling(extension: sibling.pathExtension) else {
                plan.skippedCount += 1
                continue
            }
            let size = Int64(values?.fileSize ?? 0)
            plan.files.append(PlannedFile(source: sibling, relativePath: sibling.lastPathComponent, size: size))
            plan.totalBytes += size
            plan.siblingCount += 1
        }
        return plan
    }

    // MARK: Copying

    private func copyPlan(_ plan: ImportPlan,
                          displayName: String,
                          importedFromFolder: Bool,
                          notes: String?) async throws -> Project {
        let manager = FileManager.default
        let destinationName = try uniqueDirectoryName(for: displayName)

        // Disk-space pre-flight. `volumeAvailableCapacityForImportantUsage` is the
        // figure that accounts for purgeable space; when it is unavailable we simply
        // skip the check rather than guess.
        let root = projectsRootDirectory
        if let values = try? root.resourceValues(forKeys: [.volumeAvailableCapacityForImportantUsageKey]),
           let available = values.volumeAvailableCapacityForImportantUsage {
            let required = plan.totalBytes + Self.freeSpaceSafetyMargin
            if available < required {
                log.error(LogEvent.importDiskSpace, "磁盘空间不足，导入被拒绝", metadata: [
                    "required": "\(required)",
                    "available": "\(available)"
                ])
                throw ProjectImportError.notEnoughDiskSpace(required: required, available: Int64(available))
            }
        }

        let destinationRoot = root.appendingPathComponent(destinationName, isDirectory: true)
        try manager.createDirectory(at: destinationRoot, withIntermediateDirectories: true)

        var progress = ImportProgress(bytesTotal: plan.totalBytes)
        progress.totalFiles = plan.files.count
        let started = Date()

        log.info(LogEvent.importStarted, "开始复制文件", metadata: [
            "files": "\(plan.files.count)",
            "bytes": "\(plan.totalBytes)",
            "destination": destinationName
        ])

        do {
            var lastReportedBytes: Int64 = 0
            for (index, file) in plan.files.enumerated() {
                try checkCancellation()

                let relativeComponents = file.relativePath.split(separator: "/").map(String.init)
                var target = destinationRoot
                for component in relativeComponents { target.appendPathComponent(component, isDirectory: false) }
                try manager.createDirectory(at: target.deletingLastPathComponent(),
                                            withIntermediateDirectories: true)

                try streamCopy(from: file.source, to: target, expectedSize: file.size) { [weak self] copied in
                    guard let self else { return }
                    progress.bytesCopied += copied
                    // Throttle UI updates: one per 4 MiB or per file, whichever is rarer.
                    if progress.bytesCopied - lastReportedBytes > (4 << 20) {
                        lastReportedBytes = progress.bytesCopied
                        let snapshot = progress
                        Task { @MainActor in self.importProgress = snapshot }
                    }
                }

                progress.filesCopied = index + 1
                progress.currentRelativePath = file.relativePath
                let snapshot = progress
                await MainActor.run {
                    self.importProgress = snapshot
                    self.importStatusText = "已复制 \(snapshot.filesCopied)/\(snapshot.totalFiles) 个文件"
                }
            }

            try checkCancellation()
        } catch {
            // Clean up the partially copied directory so a failed import never
            // leaves a half-project behind that appears usable.
            try? manager.removeItem(at: destinationRoot)
            if error is ImportCancellationSignal {
                log.notice(LogEvent.importCancelled, "导入已取消，已清理未完成的目录", metadata: ["destination": destinationName])
                throw error
            }
            log.error(LogEvent.importFailed, "导入失败", metadata: [
                "destination": destinationName,
                "error": error.localizedDescription
            ])
            throw error
        }

        let elapsed = Date().timeIntervalSince(started)
        let project = Project(name: displayName,
                              directoryName: destinationName,
                              entryRelativePath: plan.entryRelativePath,
                              importedFromFolder: importedFromFolder,
                              fileCount: plan.files.count,
                              totalBytes: plan.totalBytes,
                              notes: notes)

        // Verify the entry file really landed; if not, fall back to the first HTML
        // file found on disk and record that we changed our mind.
        var mutableProject = project
        if !FileManager.default.fileExists(atPath: mutableProject.entryURL(in: root).path),
           let fallback = firstHTMLFile(in: destinationRoot) {
            mutableProject.entryRelativePath = fallback
            log.notice(LogEvent.importFinished, "入口文件不存在，已回退到找到的第一个 HTML", metadata: ["entry": fallback])
        }

        projects.insert(mutableProject, at: 0)
        persist()

        log.info(LogEvent.importFinished, "导入完成", metadata: [
            "name": displayName,
            "files": "\(plan.files.count)",
            "bytes": "\(plan.totalBytes)",
            "directories": "\(plan.directoryCount)",
            "skipped": "\(plan.skippedCount)",
            "seconds": String(format: "%.2f", elapsed),
            "entry": mutableProject.entryRelativePath
        ])
        return mutableProject
    }

    /// Chunked copy. Never allocates a buffer larger than `copyChunkSize`, and
    /// reports progress per chunk so multi-gigabyte files stay responsive.
    private func streamCopy(from source: URL,
                            to destination: URL,
                            expectedSize: Int64,
                            onChunk: @escaping (Int64) -> Void) throws {
        let manager = FileManager.default
        if manager.fileExists(atPath: destination.path) {
            try manager.removeItem(at: destination)
        }
        guard manager.createFile(atPath: destination.path, contents: nil) else {
            throw ProjectImportError.copyFailed(path: destination.lastPathComponent,
                                                underlying: "无法创建目标文件")
        }

        let readHandle: FileHandle
        do {
            readHandle = try FileHandle(forReadingFrom: source)
        } catch {
            throw ProjectImportError.copyFailed(path: source.lastPathComponent,
                                                underlying: error.localizedDescription)
        }
        defer { try? readHandle.close() }

        let writeHandle: FileHandle
        do {
            writeHandle = try FileHandle(forWritingTo: destination)
        } catch {
            throw ProjectImportError.copyFailed(path: destination.lastPathComponent,
                                                underlying: error.localizedDescription)
        }
        defer { try? writeHandle.close() }

        // Pre-allocate when the size is known: fewer extent allocations, no repeated
        // growth of the destination file.
        if expectedSize > 0 {
            try? writeHandle.truncate(atOffset: UInt64(expectedSize))
            try? writeHandle.seek(toOffset: 0)
        }

        while true {
            try checkCancellation()
            let chunk: Data?
            do {
                chunk = try readHandle.read(upToCount: Self.copyChunkSize)
            } catch {
                throw ProjectImportError.copyFailed(path: source.lastPathComponent,
                                                    underlying: error.localizedDescription)
            }
            guard let chunk, !chunk.isEmpty else { break }
            do {
                try writeHandle.write(contentsOf: chunk)
            } catch {
                throw ProjectImportError.copyFailed(path: destination.lastPathComponent,
                                                    underlying: error.localizedDescription)
            }
            onChunk(Int64(chunk.count))
        }

        // Trim the pre-allocation if the file grew or shrank while copying.
        if expectedSize > 0 {
            let end = (try? writeHandle.seekToEnd()) ?? UInt64(expectedSize)
            if end != UInt64(expectedSize) {
                try? writeHandle.truncate(atOffset: end)
            }
        }

        // Preserve the modification date — some bundlers and caching layers read it.
        if let attributes = try? manager.attributesOfItem(atPath: source.path),
           let modified = attributes[.modificationDate] as? Date {
            try? manager.setAttributes([.modificationDate: modified], ofItemAtPath: destination.path)
        }
    }

    // MARK: Helpers

    private func uniqueDirectoryName(for displayName: String) throws -> String {
        let base = ImportPlanner.sanitizeDirectoryName(displayName)
        var candidate = base
        var counter = 2
        let root = projectsRootDirectory
        while projects.contains(where: { $0.directoryName == candidate })
                || FileManager.default.fileExists(atPath: root.appendingPathComponent(candidate).path) {
            candidate = "\(base)-\(counter)"
            counter += 1
            if counter > 9_999 {
                throw ProjectImportError.duplicateName(displayName)
            }
        }
        return candidate
    }

    private func firstHTMLFile(in directory: URL) -> String? {
        let manager = FileManager.default
        guard let enumerator = manager.enumerator(at: directory,
                                                 includingPropertiesForKeys: [.isRegularFileKey],
                                                 options: [.skipsHiddenFiles]) else { return nil }
        let rootPath = directory.standardizedFileURL.path
        for case let fileURL as URL in enumerator {
            let ext = fileURL.pathExtension.lowercased()
            guard ext == "html" || ext == "htm" else { continue }
            let full = fileURL.standardizedFileURL.path
            guard full.hasPrefix(rootPath) else { continue }
            var relative = String(full.dropFirst(rootPath.count))
            while relative.hasPrefix("/") { relative.removeFirst() }
            return relative
        }
        return nil
    }
}

// MARK: - Pure planning helpers (unit-testable without a device)

enum ImportPlanner {

    /// Extensions copied alongside a single picked HTML file. Deliberately narrow:
    /// the point is to make a picked `index.html` usable, not to clone a directory.
    static let siblingExtensions: Set<String> = [
        "js", "mjs", "cjs", "json", "css", "map",
        "wasm", "glsl", "vert", "frag", "vs", "fs", "wgsl",
        "glb", "gltf", "obj", "mtl", "fbx", "dae", "stl", "ply", "bin", "ktx2", "basis", "drc",
        "png", "jpg", "jpeg", "webp", "gif", "bmp", "svg", "ico", "avif", "hdr", "exr", "tga",
        "mp3", "ogg", "oga", "wav", "m4a", "aac", "flac", "opus", "webm", "mp4", "mov", "m4v",
        "ttf", "otf", "woff", "woff2", "eot",
        "xml", "txt", "csv", "tsv", "md", "html", "htm"
    ]

    static func shouldCopySibling(extension ext: String) -> Bool {
        siblingExtensions.contains(ext.lowercased())
    }

    /// Directory names that must never be treated as the entry file.
    static func chooseEntryPath(from htmlCandidates: [String]) -> String {
        guard !htmlCandidates.isEmpty else { return "index.html" }
        let sorted = htmlCandidates.sorted { lhs, rhs in
            let lhsDepth = lhs.split(separator: "/").count
            let rhsDepth = rhs.split(separator: "/").count
            if lhsDepth != rhsDepth { return lhsDepth < rhsDepth }
            return lhs.count < rhs.count
        }
        let preferred = ["index.html", "index.htm", "main.html", "game.html", "start.html"]
        for name in preferred {
            if let match = sorted.first(where: { $0.lowercased() == name }) { return match }
        }
        if let rootIndex = sorted.first(where: { !$0.contains("/") && $0.lowercased().hasPrefix("index") }) {
            return rootIndex
        }
        if let rootLevel = sorted.first(where: { !$0.contains("/") }) { return rootLevel }
        return sorted[0]
    }

    /// Produces a directory name that is safe on APFS *and* inside a URL path:
    /// no separators, no control characters, no leading dot, bounded length.
    /// Unicode (Chinese) names are preserved because APFS normalises them safely.
    static func sanitizeDirectoryName(_ name: String) -> String {
        var result = name.trimmingCharacters(in: .whitespacesAndNewlines)
        let forbidden = CharacterSet(charactersIn: "/\\:*?\"<>|\u{0}")
        result = result.components(separatedBy: forbidden).joined(separator: "-")
        result = result.replacingOccurrences(of: "..", with: "-")
        // Strip every leading "." and "-": a leading dot would create a hidden
        // directory, and a leading dash is an argument-injection hazard for any
        // tool that later receives the path on a command line.
        while let first = result.first, first == "." || first == "-" {
            result.removeFirst()
        }
        if result.count > 96 { result = String(result.prefix(96)) }
        if result.isEmpty { result = "project-\(Int(Date().timeIntervalSince1970))" }
        return result
    }
}
