//
//  DocumentImporters.swift
//  HTMLRunner
//
//  SwiftUI wrappers around `UIDocumentPickerViewController`.
//
//  Two important choices, both of which matter for correctness on iPadOS:
//
//   1. `asCopy: false`. It is tempting to let the picker copy the files for us, but
//      that copy happens before we can stream it, cannot be cancelled, reports no
//      progress, and does not tell us the source layout. Taking a security-scoped
//      URL and copying it ourselves (see `ProjectStore`), chunk by chunk, is what
//      makes multi-gigabyte imports watchable and cancellable.
//
//   2. The folder picker uses `.folder`; the file picker uses `.open` with an
//      explicit type list. Both are asked for the *content* type, never for a
//      general "any file" grab, so a user cannot accidentally hand the app a
//      directory it will then try to interpret as HTML.
//

import SwiftUI
import UniformTypeIdentifiers

// MARK: - HTML file importer

struct HTMLFileImporter: UIViewControllerRepresentable {

    var onPick: ([URL]) -> Void
    var onCancel: () -> Void

    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        // `.html` and `.htm` are the only entry points; the sibling assets are picked
        // up by the importer itself.
        var types: [UTType] = []
        if let html = UTType(filenameExtension: "html") { types.append(html) }
        if let htm = UTType(filenameExtension: "htm") { types.append(htm) }
        if types.isEmpty { types = [.text, .data] }

        let picker = UIDocumentPickerViewController(forOpeningContentTypes: types, asCopy: false)
        picker.allowsMultipleSelection = false
        picker.shouldShowFileExtensions = true
        picker.delegate = context.coordinator
        return picker
    }

    func updateUIViewController(_ uiViewController: UIDocumentPickerViewController, context: Context) {}

    func makeCoordinator() -> FilePickerCoordinator {
        FilePickerCoordinator(onPick: onPick, onCancel: onCancel)
    }

    final class FilePickerCoordinator: NSObject, UIDocumentPickerDelegate {
        private let onPick: ([URL]) -> Void
        private let onCancel: () -> Void

        init(onPick: @escaping ([URL]) -> Void, onCancel: @escaping () -> Void) {
            self.onPick = onPick
            self.onCancel = onCancel
        }

        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            onPick(urls)
        }

        func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
            onCancel()
        }
    }
}

// MARK: - Folder importer

struct FolderImporter: UIViewControllerRepresentable {

    var onPick: ([URL]) -> Void
    var onCancel: () -> Void

    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        let picker = UIDocumentPickerViewController(forOpeningContentTypes: [.folder], asCopy: false)
        picker.allowsMultipleSelection = false
        picker.delegate = context.coordinator
        return picker
    }

    func updateUIViewController(_ uiViewController: UIDocumentPickerViewController, context: Context) {}

    func makeCoordinator() -> FolderPickerCoordinator {
        FolderPickerCoordinator(onPick: onPick, onCancel: onCancel)
    }

    final class FolderPickerCoordinator: NSObject, UIDocumentPickerDelegate {
        private let onPick: ([URL]) -> Void
        private let onCancel: () -> Void

        init(onPick: @escaping ([URL]) -> Void, onCancel: @escaping () -> Void) {
            self.onPick = onPick
            self.onCancel = onCancel
        }

        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            onPick(urls)
        }

        func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
            onCancel()
        }
    }
}

// MARK: - Plain text share sheet (log export, diagnostic report)

struct ShareSheet: UIViewControllerRepresentable {

    var items: [Any]

    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: items, applicationActivities: nil)
    }

    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}
