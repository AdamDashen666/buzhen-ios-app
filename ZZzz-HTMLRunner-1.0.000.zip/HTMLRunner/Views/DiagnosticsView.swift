//
//  DiagnosticsView.swift
//  HTMLRunner
//
//  The screen that answers "what is actually going on?".
//
//  Its most important design constraint is epistemic: it must show, side by side,
//  what the app *measured* and what it *cannot know*. A user who believes a
//  benchmark proves JIT is enabled will chase the wrong problem for weeks, so the
//  "无法直接确认" rows are rendered with the same visual weight as the numbers.
//

import SwiftUI

struct DiagnosticsView: View {

    @EnvironmentObject private var appState: AppState
    @EnvironmentObject private var log: DiagnosticLogStore

    @State private var rows: [DiagnosticRowGroup] = []
    @State private var memorySamples: [AppMemorySample] = []
    @State private var isRunningProbe = false
    @State private var probeError: String?
    @State private var probeWithLargeTexture = false
    @State private var exportURL: URL?
    @State private var showingShare = false
    @State private var memoryTimer: Timer?

    var body: some View {
        List {
            runtimeSection
            jitSection
            probeSection
            memorySection
            serverSection
            exportSection
        }
        .navigationTitle("诊断")
        .toolbar {
            ToolbarItem(placement: .primaryAction) {
                Button {
                    refreshFacts()
                } label: {
                    Label("刷新", systemImage: "arrow.clockwise")
                }
            }
        }
        .onAppear {
            refreshFacts()
            startMemoryTimer()
        }
        .onDisappear {
            memoryTimer?.invalidate()
            memoryTimer = nil
        }
        .sheet(isPresented: $showingShare) {
            if let exportURL {
                ShareSheet(items: [exportURL])
            }
        }
    }

    // MARK: Runtime facts

    private var runtimeSection: some View {
        Section {
            ForEach(rows) { group in
                DisclosureGroup {
                    ForEach(group.rows) { row in
                        VStack(alignment: .leading, spacing: 2) {
                            HStack(alignment: .firstTextBaseline) {
                                Text(row.label)
                                    .foregroundStyle(.secondary)
                                Spacer()
                                Text(row.displayValue)
                                    .multilineTextAlignment(.trailing)
                                    .foregroundStyle(colorFor(row))
                            }
                            if let note = row.note {
                                Text(note)
                                    .font(.caption2)
                                    .foregroundStyle(.tertiary)
                                    .fixedSize(horizontal: false, vertical: true)
                            }
                        }
                    }
                } label: {
                    Label(group.title, systemImage: group.symbol)
                        .font(.headline)
                }
            }
        } header: {
            Text("运行时事实")
        } footer: {
            Text("本节全部来自构建信息与系统 API。「无法获取」表示系统未提供该值，而不是 0。")
        }
    }

    private func colorFor(_ row: DiagnosticRow) -> Color {
        switch row.value {
        case .unknown: return .orange
        case .measured: return .primary
        case .text: return .primary
        }
    }

    // MARK: JIT

    private var jitSection: some View {
        Section {
            let debug = ProcessDebugState.current()
            VStack(alignment: .leading, spacing: 6) {
                Label("本 App 进程是否被调试器附加", systemImage: "ant")
                    .font(.subheadline.weight(.semibold))
                Text(debug.isBeingTracedDescription)
                Text("通过 sysctl(KERN_PROC_PID) 读取内核的 P_TRACED 标志。这是侧载工具（StikDebug / SideStore 类工具）在开启 JIT 时会让进程进入的状态。")
                    .font(.caption2)
                    .foregroundStyle(.secondary)
            }

            VStack(alignment: .leading, spacing: 6) {
                Label("网页（WebContent 进程）是否在使用 JIT", systemImage: "questionmark.circle")
                    .font(.subheadline.weight(.semibold))
                Text("无法直接确认")
                    .foregroundStyle(.orange)
                Text("""
                    WKWebView 的页面运行在系统独立的 WebContent 进程中，App 无法读取其权限、内存或代码生成状态。iOS 也没有任何公开 API 可以查询「JavaScriptCore 是否以 JIT 模式编译了某个函数」。
                    因此本页不会给出 JIT 是否开启的结论。WebAssembly 是否可用、new Function 是否可用，是页面上可以直接观测的「能力事实」，仅供参考，不等于 JIT 已开启。
                    """)
                    .font(.caption2)
                    .foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }

            if let probe = appState.coordinator?.lastProbe {
                factRow("WebAssembly 可用", probe.webAssemblyAvailable.map { $0 ? "是" : "否" } ?? "未知",
                        note: "WebAssembly 与 JS JIT 依赖同一套可执行内存机制，是最接近的能力指标，但仍不等价。")
                factRow("WebAssembly 模块校验通过", probe.webAssemblyModuleValid.map { $0 ? "是" : "否" } ?? "未知")
                factRow("new Function 可用", probe.newFunctionSupported.map { $0 ? "是" : "否" } ?? "未知",
                        note: "动态求值可用只说明引擎允许从字符串生成函数，解释器同样可以做到。")
            } else {
                Text("尚未运行页面探测。运行一个项目后，在运行界面点击「探测」。")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            NavigationLink("阅读 JIT 原理与限制（JIT_NOTES.md 摘要）") {
                JITNotesView()
            }
        } header: {
            Text("JIT 诊断")
        } footer: {
            Text("get-task-allow 与调试器附加只影响 App 进程的可调试性；它不会把权限转移给 WebContent 进程。详见 JIT_NOTES.md。")
        }
    }

    private func factRow(_ label: String, _ value: String, note: String? = nil) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            HStack {
                Text(label).foregroundStyle(.secondary)
                Spacer()
                Text(value)
            }
            if let note {
                Text(note).font(.caption2).foregroundStyle(.tertiary)
            }
        }
    }

    // MARK: Probe

    private var probeSection: some View {
        Section {
            Toggle("同时测试大纹理分配（4096²，约 64 MB 峰值）", isOn: $probeWithLargeTexture)

            Button {
                runProbe()
            } label: {
                HStack {
                    Label("运行性能与能力探测", systemImage: "speedometer")
                    if isRunningProbe {
                        Spacer()
                        ProgressView()
                    }
                }
            }
            .disabled(isRunningProbe || appState.coordinator == nil)

            if appState.coordinator == nil {
                Text("需要先运行一个项目：探测是在真实页面中执行的。")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            if let probeError {
                Text(probeError).foregroundStyle(.red).font(.callout)
            }

            if let probe = appState.coordinator?.lastProbe {
                Group {
                    row("WebGL2", probe.webgl2?.summaryLine ?? "未获取")
                    if let shader = probe.webgl2?.shaderTest {
                        row("GLSL 编译/链接", shader.succeeded ? "成功" : "失败")
                        if !shader.succeeded {
                            if let text = shader.vertexLog, !text.isEmpty { Text("顶点着色器: \(text)").font(.caption2).foregroundStyle(.red) }
                            if let text = shader.fragmentLog, !text.isEmpty { Text("片元着色器: \(text)").font(.caption2).foregroundStyle(.red) }
                            if let text = shader.linkLog, !text.isEmpty { Text("链接: \(text)").font(.caption2).foregroundStyle(.red) }
                        }
                    }
                    row("WebGL2 扩展数量", "\(probe.webgl2?.extensionCount ?? 0)")
                    row("最大纹理尺寸", probe.webgl2?.limits?["MAX_TEXTURE_SIZE"]?.text ?? "无法获取")
                    row("最大 3D 纹理尺寸", probe.webgl2?.limits?["MAX_3D_TEXTURE_SIZE"]?.text ?? "无法获取")
                    row("MSAA 最大采样数", probe.webgl2?.limits?["MAX_SAMPLES"]?.text ?? "无法获取")
                    row("WebGL1", probe.webgl1?.summaryLine ?? "未获取（已有 WebGL2 时默认不测）")
                    row("hardwareConcurrency", probe.hardwareConcurrency.map(String.init) ?? "无法获取")

                    if let measurements = probe.benchmark?.measurements {
                        row("numeric 循环", measurements.numericMs.map { String(format: "%.0f ms", $0) } ?? "无法获取")
                        row("numeric 吞吐", measurements.numericOpsPerSecond.map { String(format: "%.0f ops/s", $0) } ?? "无法获取")
                        row("分配测试", measurements.allocationMs.map { String(format: "%.0f ms", $0) } ?? "无法获取")
                        row("预热耗时", measurements.warmupMs.map { String(format: "%.0f ms", $0) } ?? "无法获取")
                        Text("以上为间接证据：单次测量受热降频、后台限速、设备状态影响，不能作为 JIT 是否开启的判据。测试时热状态：\(AppInfo.thermalStateDescription)。")
                            .font(.caption2)
                            .foregroundStyle(.orange)
                    }

                    if let staging = probe.textureStaging {
                        ForEach(Array(staging.enumerated()), id: \.offset) { _, step in
                            row("纹理 \(step.size ?? 0)²", String(format: "分配 %.1f ms，glError=%d", step.allocateMs ?? 0, step.error ?? -1))
                        }
                    }

                    if let errors = probe.errors, !errors.isEmpty {
                        ForEach(errors, id: \.message) { error in
                            Text("\(error.section): \(error.message)")
                                .font(.caption2)
                                .foregroundStyle(.red)
                        }
                    }
                }
            }
        } header: {
            Text("页面探测")
        } footer: {
            Text("探测脚本只在点击时注入并执行一次，会立即释放创建的 WebGL 上下文，不会常驻页面。")
        }
    }

    private func row(_ label: String, _ value: String) -> some View {
        HStack(alignment: .firstTextBaseline) {
            Text(label).foregroundStyle(.secondary)
            Spacer()
            Text(value).multilineTextAlignment(.trailing)
        }
    }

    // MARK: Memory

    private var memorySection: some View {
        Section {
            if let latest = memorySamples.last {
                row("本进程 resident", latest.residentDescription)
                row("本进程 phys_footprint", latest.footprintDescription)
                row("本进程 virtual", latest.virtualDescription)
                row("malloc 使用", latest.mallocDescription)
                row("设备空闲内存（仅参考）", latest.deviceFreeDescription)
                row("采样时间", latest.timestamp.formatted(date: .omitted, time: .standard))
            } else {
                Text("正在采样…").foregroundStyle(.secondary)
            }

            if memorySamples.count > 1 {
                SparklineView(values: memorySamples.compactMap { $0.physicalFootprintBytes.map(Double.init) })
                    .frame(height: 44)
                Text("phys_footprint 走势（最近 \(memorySamples.count) 次采样）")
                    .font(.caption2)
                    .foregroundStyle(.tertiary)
            }

            Button {
                appState.coordinator?.reload(userInitiated: true)
            } label: {
                Label("重新加载页面（释放页面内资源）", systemImage: "arrow.clockwise")
            }
            .disabled(appState.coordinator == nil)

            Button {
                appState.closeRun()
            } label: {
                Label("关闭运行并停止本地服务", systemImage: "stop.circle")
            }
            .disabled(appState.coordinator == nil)
        } header: {
            Text("内存与运行")
        } footer: {
            Text("""
                只能读取本 App 进程的内存。WebContent 进程的内存、WKWebView 的内部缓存，App 既无法读取也无法主动释放——iOS 未提供这类接口，因此本 App 不提供「一键释放 WebKit 内存」按钮。
                """)
        }
    }

    // MARK: Server

    private var serverSection: some View {
        Section {
            row("状态", appState.server.state.description)
            row("已处理请求", "\(appState.server.requestCount)")
            if let error = appState.server.lastError {
                Text(error).foregroundStyle(.red).font(.callout)
            }
            Button("停止本地服务") {
                appState.stopServer(reason: "user request")
            }
            .disabled(!appState.server.state.isRunning)
        } header: {
            Text("本地 HTTP 服务")
        } footer: {
            Text("仅在启用「本地服务」模式时运行，且只监听 127.0.0.1：局域网内其他设备无法访问。")
        }
    }

    // MARK: Export

    private var exportSection: some View {
        Section {
            Button {
                exportReport()
            } label: {
                Label("生成并分享诊断报告", systemImage: "square.and.arrow.up")
            }
            NavigationLink {
                LogViewerView()
            } label: {
                Label("查看完整日志", systemImage: "text.alignleft")
            }
            row("日志条目", "\(log.entries.count)（上限 \(DiagnosticLogStore.maxEntries)）")
            if log.droppedEntryCount > 0 {
                Text("已有 \(log.droppedEntryCount) 条较早日志因容量上限被丢弃。")
                    .font(.caption2)
                    .foregroundStyle(.orange)
            }
        } header: {
            Text("导出")
        }
    }

    // MARK: Actions

    private func refreshFacts() {
        rows = DiagnosticFacts.groups(appState: appState)
        memorySamples = [AppMemoryProbe.sample()]
    }

    private func startMemoryTimer() {
        memoryTimer?.invalidate()
        memoryTimer = Timer.scheduledTimer(withTimeInterval: 3, repeats: true) { _ in
            Task { @MainActor in
                let sample = AppMemoryProbe.sample()
                memorySamples.append(sample)
                if memorySamples.count > 40 { memorySamples.removeFirst(memorySamples.count - 40) }
            }
        }
    }

    private func runProbe() {
        guard let coordinator = appState.coordinator else {
            probeError = "没有正在运行的页面。先运行一个项目，再执行探测。"
            return
        }
        isRunningProbe = true
        probeError = nil
        log.info(LogEvent.perfProbeStart, "用户触发页面探测", metadata: [
            "largeTexture": "\(probeWithLargeTexture)"
        ])
        coordinator.runProbe(includeLargeTexture: probeWithLargeTexture) { result in
            isRunningProbe = false
            if case .failure(let error) = result {
                probeError = error.localizedDescription
            }
        }
    }

    private func exportReport() {
        do {
            let url = try appState.makeDiagnosticReport()
            exportURL = url
            showingShare = true
        } catch {
            probeError = "报告生成失败：\(error.localizedDescription)"
            log.error(LogEvent.diagnosticExport, "报告生成失败", metadata: ["error": error.localizedDescription])
        }
    }
}

// MARK: - Grouped facts

struct DiagnosticRowGroup: Identifiable {
    let id = UUID()
    var title: String
    var symbol: String
    var rows: [DiagnosticRow]
}

enum DiagnosticFacts {

    @MainActor
    static func groups(appState: AppState) -> [DiagnosticRowGroup] {
        var build: [DiagnosticRow] = []
        for (label, value) in AppInfo.snapshot() {
            build.append(DiagnosticRow(group: "构建", label: label, value: .text(value)))
        }
        build.append(DiagnosticRow(
            group: "构建",
            label: "WebKit 版本来源",
            value: WebRuntimeInfo.kitVersionSource.map { .text($0) }
                ?? .unknown("系统 WebKit 位于共享缓存，未找到 Info.plist")
        ))

        var web: [DiagnosticRow] = []
        if let probe = appState.coordinator?.lastProbe {
            web.append(DiagnosticRow(group: "页面", label: "navigator.userAgent",
                                     value: probe.userAgent.map { .text($0) } ?? .unknown("页面未上报")))
            web.append(DiagnosticRow(group: "页面", label: "页面协议",
                                     value: probe.protocol.map { .text($0) } ?? .unknown("页面未上报")))
            web.append(DiagnosticRow(group: "页面", label: "isSecureContext",
                                     value: probe.isSecureContext.map { .text($0 ? "true" : "false") } ?? .unknown("页面未上报")))
        } else {
            web.append(DiagnosticRow(group: "页面", label: "页面信息",
                                     value: .unknown("尚未运行页面探测")))
        }

        var run: [DiagnosticRow] = []
        if let coordinator = appState.coordinator {
            run.append(DiagnosticRow(group: "运行", label: "阶段",
                                     value: .text(String(describing: coordinator.phase))))
            run.append(DiagnosticRow(group: "运行", label: "当前 URL",
                                     value: coordinator.currentURLString.isEmpty
                                        ? .unknown("尚未开始导航") : .text(coordinator.currentURLString)))
            run.append(DiagnosticRow(group: "运行", label: "导航次数",
                                     value: .text("\(coordinator.navigationCount)")))
            run.append(DiagnosticRow(group: "运行", label: "WebContent 终止次数",
                                     value: .text("\(coordinator.terminationCount)")))
            run.append(DiagnosticRow(group: "运行", label: "最近加载耗时",
                                     value: coordinator.loadDuration.map { .measured(String(format: "%.2f s", $0), note: "单次测量，受缓存与设备状态影响") }
                                        ?? .unknown("尚未完成一次加载")))
            run.append(DiagnosticRow(group: "运行", label: "被拦截的外部导航",
                                     value: .text("\(coordinator.blockCount)")))
        } else {
            run.append(DiagnosticRow(group: "运行", label: "运行状态",
                                     value: .unknown("当前没有运行中的项目")))
        }

        let project: [DiagnosticRow]
        if let active = appState.refreshActiveProject() {
            project = [
                DiagnosticRow(group: "项目", label: "名称", value: .text(active.name)),
                DiagnosticRow(group: "项目", label: "入口文件", value: .text(active.entryRelativePath)),
                DiagnosticRow(group: "项目", label: "文件数", value: .text("\(active.fileCount)")),
                DiagnosticRow(group: "项目", label: "体积", value: .text(active.sizeDescription))
            ]
        } else {
            project = [DiagnosticRow(group: "项目", label: "当前项目", value: .unknown("未打开项目"))]
        }

        return [
            DiagnosticRowGroup(title: "构建与设备", symbol: "hammer", rows: build),
            DiagnosticRowGroup(title: "页面", symbol: "globe", rows: web),
            DiagnosticRowGroup(title: "运行状态", symbol: "play.circle", rows: run),
            DiagnosticRowGroup(title: "项目", symbol: "folder", rows: project)
        ]
    }
}

// MARK: - Sparkline

struct SparklineView: View {

    let values: [Double]

    var body: some View {
        GeometryReader { geometry in
            if values.count > 1, let minimum = values.min(), let maximum = values.max() {
                let span = max(maximum - minimum, 1)
                let stepX = geometry.size.width / CGFloat(values.count - 1)
                Path { path in
                    for (index, value) in values.enumerated() {
                        let x = CGFloat(index) * stepX
                        let normalized = (value - minimum) / span
                        let y = geometry.size.height * (1 - CGFloat(normalized))
                        if index == 0 {
                            path.move(to: CGPoint(x: x, y: y))
                        } else {
                            path.addLine(to: CGPoint(x: x, y: y))
                        }
                    }
                }
                .stroke(Color.accentColor, lineWidth: 1.5)
            } else {
                Rectangle().fill(.quaternary)
            }
        }
    }
}

// MARK: - JIT notes summary (bundled markdown)

/// Renders `JIT_NOTES.md` from the bundle when it is packaged, so the app's
/// explanation and the repository document can never drift apart. When the file is
/// not bundled (it is a developer document), a built-in summary is shown instead.
struct JITNotesView: View {

    private var bundledText: String? {
        guard let url = Bundle.main.url(forResource: "JIT_NOTES", withExtension: "md") else { return nil }
        return try? String(contentsOf: url, encoding: .utf8)
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                if let text = bundledText {
                    Text(text)
                        .font(.system(.footnote, design: .monospaced))
                        .textSelection(.enabled)
                        .frame(maxWidth: .infinity, alignment: .leading)
                } else {
                    fallbackSummary
                }
            }
            .padding(20)
        }
        .navigationTitle("JIT 说明")
    }

    private var fallbackSummary: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("结论摘要").font(.headline)
            bullet("iOS 上网页的 JavaScript 由系统的 WebContent 进程执行；该进程的权限由系统 WebKit 决定，第三方 App 无法授予或修改。")
            bullet("get-task-allow 让 App 进程可被调试器附加，这是侧载工具开启 JIT 的前提，但它只作用于 App 进程本身。")
            bullet("没有任何公开 API 能让网页或 App 判断 JavaScriptCore 是否以 JIT 模式运行。本 App 因此明确标注「无法直接确认」。")
            bullet("WebAssembly 是否可用、new Function 是否可用是可以在页面上直接观测的能力事实，常被用作间接参考。")
            bullet("性能benchmark 只是间接证据：热降频、后台限速、缓存状态都会显著改变结果。")
            bullet("完整说明请阅读仓库中的 JIT_NOTES.md。")
            Text("（此摘要未随 App 打包完整文档，完整内容见仓库 JIT_NOTES.md。）")
                .font(.caption2)
                .foregroundStyle(.tertiary)
        }
    }

    private func bullet(_ text: String) -> some View {
        HStack(alignment: .top, spacing: 8) {
            Text("•")
            Text(text).fixedSize(horizontal: false, vertical: true)
        }
        .font(.callout)
    }
}
