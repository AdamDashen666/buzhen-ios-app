//
//  LogViewerView.swift
//  HTMLRunner
//
//  In-app log viewer with level filtering, text search, copy and export.
//  Backed by `DiagnosticLogStore`, which is bounded in memory and on disk.
//

import SwiftUI

struct LogViewerView: View {

    @EnvironmentObject private var log: DiagnosticLogStore

    @State private var minimumLevel: LogLevel = .debug
    @State private var searchText = ""
    @State private var showingShare = false
    @State private var exportURL: URL?
    @State private var errorMessage: String?
    @State private var autoScroll = true

    private var filtered: [LogEntry] {
        log.filtered(level: minimumLevel, search: searchText)
    }

    var body: some View {
        VStack(spacing: 0) {
            filterBar
            Divider()
            content
        }
        .navigationTitle("诊断日志")
        .toolbar {
            ToolbarItemGroup(placement: .primaryAction) {
                Button {
                    UIPasteboard.general.string = log.plainText(level: minimumLevel, search: searchText)
                } label: {
                    Label("复制", systemImage: "doc.on.doc")
                }
                Button {
                    exportLog()
                } label: {
                    Label("导出", systemImage: "square.and.arrow.up")
                }
                Button(role: .destructive) {
                    log.clear()
                } label: {
                    Label("清空", systemImage: "trash")
                }
            }
        }
        .sheet(isPresented: $showingShare) {
            if let exportURL {
                ShareSheet(items: [exportURL])
            }
        }
        .alert("导出失败", isPresented: Binding(
            get: { errorMessage != nil },
            set: { if !$0 { errorMessage = nil } }
        )) {
            Button("好") { errorMessage = nil }
        } message: {
            Text(errorMessage ?? "")
        }
    }

    private var filterBar: some View {
        VStack(spacing: 8) {
            Picker("级别", selection: $minimumLevel) {
                ForEach(LogLevel.allCases) { level in
                    Text(level.title).tag(level)
                }
            }
            .pickerStyle(.segmented)

            HStack {
                Image(systemName: "magnifyingglass").foregroundStyle(.secondary)
                TextField("搜索事件、消息或元数据", text: $searchText)
                    .textFieldStyle(.plain)
                    .autocorrectionDisabled()
                    .textInputAutocapitalization(.never)
                if !searchText.isEmpty {
                    Button {
                        searchText = ""
                    } label: {
                        Image(systemName: "xmark.circle.fill").foregroundStyle(.secondary)
                    }
                    .buttonStyle(.plain)
                }
            }
            .padding(8)
            .background(.quaternary.opacity(0.4), in: RoundedRectangle(cornerRadius: 8))

            HStack {
                Text("显示 \(filtered.count) / \(log.entries.count) 条")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                Spacer()
                Toggle("自动滚动到最新", isOn: $autoScroll)
                    .toggleStyle(.switch)
                    .font(.caption)
            }
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 10)
    }

    private var content: some View {
        ScrollViewReader { proxy in
            ScrollView {
                LazyVStack(alignment: .leading, spacing: 6) {
                    ForEach(filtered) { entry in
                        LogEntryRow(entry: entry).id(entry.id)
                    }
                }
                .padding(16)
                .frame(maxWidth: .infinity, alignment: .leading)
            }
            .onChange(of: filtered.count) { _, _ in
                guard autoScroll, let last = filtered.last else { return }
                withAnimation(.linear(duration: 0.15)) {
                    proxy.scrollTo(last.id, anchor: .bottom)
                }
            }
        }
    }

    private func exportLog() {
        let name = "HTMLRunner-Logs-\(Int(Date().timeIntervalSince1970)).txt"
        let url = FileManager.default.temporaryDirectory.appendingPathComponent(name)
        do {
            try log.export(to: url, level: minimumLevel, search: searchText)
            exportURL = url
            showingShare = true
        } catch {
            errorMessage = error.localizedDescription
            log.error(LogEvent.logExported, "日志导出失败", metadata: ["error": error.localizedDescription])
        }
    }
}

struct LogEntryRow: View {

    let entry: LogEntry

    var body: some View {
        HStack(alignment: .top, spacing: 8) {
            Image(systemName: entry.level.symbolName)
                .foregroundStyle(color)
                .frame(width: 16)
            VStack(alignment: .leading, spacing: 2) {
                HStack(spacing: 6) {
                    Text(timeText)
                        .font(.caption2.monospacedDigit())
                        .foregroundStyle(.secondary)
                    Text(entry.event)
                        .font(.caption2.monospaced())
                        .foregroundStyle(.tertiary)
                }
                Text(entry.message)
                    .font(.callout)
                    .textSelection(.enabled)
                    .fixedSize(horizontal: false, vertical: true)
                if !entry.metadata.isEmpty {
                    Text(metadataText)
                        .font(.caption2.monospaced())
                        .foregroundStyle(.secondary)
                        .textSelection(.enabled)
                        .fixedSize(horizontal: false, vertical: true)
                }
            }
            Spacer(minLength: 0)
        }
        .padding(8)
        .background(background, in: RoundedRectangle(cornerRadius: 8, style: .continuous))
    }

    private var timeText: String {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm:ss.SSS"
        return formatter.string(from: entry.date)
    }

    private var metadataText: String {
        entry.metadata
            .sorted { $0.key < $1.key }
            .map { "\($0.key)=\($0.value)" }
            .joined(separator: "  ")
    }

    private var color: Color {
        switch entry.level {
        case .debug: return .secondary
        case .info: return .blue
        case .notice: return .teal
        case .warning: return .orange
        case .error: return .red
        }
    }

    private var background: Color {
        switch entry.level {
        case .error: return .red.opacity(0.08)
        case .warning: return .orange.opacity(0.07)
        default: return .clear
        }
    }
}
