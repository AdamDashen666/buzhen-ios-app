//
//  ProjectListView.swift
//  HTMLRunner
//
//  Home screen: recent projects, import actions, and per-project management.
//  Laid out for landscape iPad — a two-column grid of project cards rather than a
//  single narrow list.
//

import SwiftUI

struct ProjectListView: View {

    @EnvironmentObject private var appState: AppState
    @EnvironmentObject private var projects: ProjectStore

    @State private var renamingProject: Project?
    @State private var renameText = ""
    @State private var projectPendingDeletion: Project?
    @State private var showingProjectDetail: Project?
    @State private var runPreparationTask: Task<Void, Never>?

    private let columns = [GridItem(.adaptive(minimum: 320, maximum: 480), spacing: 16)]

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                importBar

                if projects.isImporting {
                    importProgressCard
                }

                let recent = projects.recentlyOpened(limit: 6)
                if !recent.isEmpty {
                    sectionHeader("最近打开", systemImage: "clock.arrow.circlepath")
                    LazyVGrid(columns: columns, spacing: 16) {
                        ForEach(recent) { project in
                            ProjectCard(project: project,
                                        onOpen: { run(project) },
                                        onDetails: { showingProjectDetail = project })
                        }
                    }
                }

                sectionHeader("全部项目（\(projects.projects.count)）", systemImage: "square.stack.3d.up")
                if projects.projects.isEmpty {
                    emptyState
                } else {
                    LazyVGrid(columns: columns, spacing: 16) {
                        ForEach(projects.projects) { project in
                            ProjectCard(project: project,
                                        onOpen: { run(project) },
                                        onDetails: { showingProjectDetail = project })
                                .contextMenu {
                                    Button { run(project) } label: {
                                        Label("运行", systemImage: "play.fill")
                                    }
                                    Button { showingProjectDetail = project } label: {
                                        Label("详情与入口文件", systemImage: "info.circle")
                                    }
                                    Button {
                                        renamingProject = project
                                        renameText = project.name
                                    } label: {
                                        Label("重命名", systemImage: "pencil")
                                    }
                                    Divider()
                                    Button(role: .destructive) {
                                        projectPendingDeletion = project
                                    } label: {
                                        Label("删除", systemImage: "trash")
                                    }
                                }
                        }
                    }
                }

                footer
            }
            .padding(24)
        }
        .navigationTitle("项目")
        .toolbar {
            ToolbarItemGroup(placement: .primaryAction) {
                Button {
                    appState.showingFolderImporter = true
                } label: {
                    Label("导入文件夹", systemImage: "folder.badge.plus")
                }
                Button {
                    appState.showingImporter = true
                } label: {
                    Label("导入 HTML", systemImage: "doc.badge.plus")
                }
            }
        }
        .alert("重命名项目", isPresented: Binding(
            get: { renamingProject != nil },
            set: { if !$0 { renamingProject = nil } }
        )) {
            TextField("名称", text: $renameText)
            Button("取消", role: .cancel) { renamingProject = nil }
            Button("保存") {
                if let project = renamingProject {
                    try? projects.rename(project, to: renameText)
                }
                renamingProject = nil
            }
        } message: {
            Text("只修改显示名称，App 内的目录名保持不变，因此不会破坏相对路径。")
        }
        .confirmationDialog(
            "删除「\(projectPendingDeletion?.name ?? "")」？",
            isPresented: Binding(
                get: { projectPendingDeletion != nil },
                set: { if !$0 { projectPendingDeletion = nil } }
            ),
            titleVisibility: .visible
        ) {
            Button("删除项目和文件", role: .destructive) {
                if let project = projectPendingDeletion {
                    Task { await projects.delete(project) }
                }
                projectPendingDeletion = nil
            }
            Button("取消", role: .cancel) { projectPendingDeletion = nil }
        } message: {
            Text("将同时删除 App 内复制的项目文件（\(projectPendingDeletion?.sizeDescription ?? "")）。原始文件不受影响。")
        }
        .sheet(item: $showingProjectDetail) { project in
            NavigationStack {
                ProjectDetailView(project: project)
                    .toolbar {
                        ToolbarItem(placement: .cancellationAction) {
                            Button("关闭") { showingProjectDetail = nil }
                        }
                    }
            }
        }
    }

    // MARK: Sections

    private var importBar: some View {
        HStack(spacing: 12) {
            Button {
                appState.showingFolderImporter = true
            } label: {
                Label("导入整个项目文件夹", systemImage: "folder.badge.plus")
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 6)
            }
            .buttonStyle(.borderedProminent)

            Button {
                appState.showingImporter = true
            } label: {
                Label("导入单个 HTML 文件", systemImage: "doc.badge.plus")
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 6)
            }
            .buttonStyle(.bordered)
        }
        .controlSize(.large)
    }

    private var importProgressCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text(projects.importStatusText.isEmpty ? "正在导入…" : projects.importStatusText)
                    .font(.headline)
                Spacer()
                Button("取消", role: .destructive) {
                    projects.cancelImport()
                }
            }
            if let progress = projects.importProgress {
                ProgressView(value: progress.fraction) {
                    Text("\(Int(progress.fraction * 100))%")
                        .font(.caption.monospacedDigit())
                }
                HStack {
                    Text(ByteCountFormatter.string(fromByteCount: progress.bytesCopied, countStyle: .file))
                    Text("/")
                    Text(ByteCountFormatter.string(fromByteCount: progress.bytesTotal, countStyle: .file))
                    Spacer()
                    Text("\(progress.filesCopied)/\(progress.totalFiles) 个文件")
                }
                .font(.caption)
                .foregroundStyle(.secondary)
                if !progress.currentRelativePath.isEmpty {
                    Text(progress.currentRelativePath)
                        .font(.caption2)
                        .foregroundStyle(.tertiary)
                        .lineLimit(1)
                        .truncationMode(.middle)
                }
            } else {
                ProgressView()
            }
            Text("文件是分批流式复制的，不会一次性读入内存；导入过程中可随时取消。")
                .font(.caption2)
                .foregroundStyle(.tertiary)
        }
        .padding(16)
        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
    }

    private var emptyState: some View {
        ContentUnavailableView {
            Label("还没有导入项目", systemImage: "tray")
        } description: {
            Text("导入一个包含 index.html 的项目文件夹，或导入单个 HTML 文件。项目会被复制到 App 内部，之后不再依赖临时授权。")
        } actions: {
            Button("导入文件夹") { appState.showingFolderImporter = true }
                .buttonStyle(.borderedProminent)
        }
    }

    private var footer: some View {
        VStack(alignment: .leading, spacing: 8) {
            Divider()
            Text("项目存储位置")
                .font(.headline)
            Text(appState.projectsDirectoryDescription)
                .font(.caption.monospaced())
                .foregroundStyle(.secondary)
                .textSelection(.enabled)
            Text("App 已开启「文件」App 共享，可在 Files → 我的 iPad → HTMLRunner 中直接查看。")
                .font(.caption2)
                .foregroundStyle(.tertiary)
        }
        .padding(.top, 8)
    }

    private func sectionHeader(_ title: String, systemImage: String) -> some View {
        Label(title, systemImage: systemImage)
            .font(.title3.weight(.semibold))
    }

    // MARK: Actions

    private func run(_ project: Project) {
        runPreparationTask?.cancel()
        runPreparationTask = Task {
            await appState.open(project)
        }
    }
}

// MARK: - Project card

struct ProjectCard: View {

    let project: Project
    var onOpen: () -> Void
    var onDetails: () -> Void

    @EnvironmentObject private var store: ProjectStore

    private var entryExists: Bool { store.entryExists(for: project) }

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(alignment: .top) {
                Image(systemName: project.importedFromFolder ? "folder.fill" : "doc.text.fill")
                    .font(.title2)
                    .foregroundStyle(.tint)
                VStack(alignment: .leading, spacing: 2) {
                    Text(project.name)
                        .font(.headline)
                        .lineLimit(2)
                    Text(project.importedFromDescription)
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                }
                Spacer()
                if let succeeded = project.lastRunSucceeded {
                    Image(systemName: succeeded ? "checkmark.circle.fill" : "exclamationmark.circle.fill")
                        .foregroundStyle(succeeded ? .green : .orange)
                        .help(succeeded ? "上次运行加载成功" : "上次运行出现过错误")
                }
            }

            VStack(alignment: .leading, spacing: 4) {
                Label(project.entryRelativePath, systemImage: "arrow.turn.down.right")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
                    .truncationMode(.middle)
                Label("\(project.fileCount) 个文件 · \(project.sizeDescription)", systemImage: "internaldrive")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            if !entryExists {
                Label("入口文件已不存在，需要重新导入", systemImage: "exclamationmark.triangle.fill")
                    .font(.caption)
                    .foregroundStyle(.orange)
            }

            HStack(spacing: 10) {
                Button {
                    onOpen()
                } label: {
                    Label("运行", systemImage: "play.fill")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)
                .disabled(!entryExists)

                Button {
                    onDetails()
                } label: {
                    Image(systemName: "info.circle")
                }
                .buttonStyle(.bordered)
            }
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
    }
}

// MARK: - Project detail

struct ProjectDetailView: View {

    let project: Project

    @EnvironmentObject private var appState: AppState
    @EnvironmentObject private var store: ProjectStore

    /// HTML files discovered in the project, so the user can re-point the entry file
    /// when `index.html` was not the right guess.
    @State private var htmlFiles: [String] = []
    @State private var isScanning = false

    var body: some View {
        List {
            Section("概览") {
                row("名称", project.name)
                row("App 内目录", project.directoryName)
                row("入口文件", project.entryRelativePath)
                row("文件数量", "\(project.fileCount)")
                row("体积", project.sizeDescription)
                row("导入方式", project.importedFromDescription)
                row("导入时间", project.importedAt.formatted(date: .abbreviated, time: .shortened))
                if let lastOpened = project.lastOpenedAt {
                    row("最近打开", lastOpened.formatted(date: .abbreviated, time: .shortened))
                }
                if let notes = project.notes {
                    Text(notes).font(.caption).foregroundStyle(.secondary)
                }
            }

            Section {
                if isScanning {
                    ProgressView("正在扫描 HTML 文件…")
                } else if htmlFiles.isEmpty {
                    Text("未在项目中发现 HTML 文件。")
                        .foregroundStyle(.secondary)
                } else {
                    ForEach(htmlFiles, id: \.self) { file in
                        Button {
                            store.updateEntryPath(project, relativePath: file)
                        } label: {
                            HStack {
                                Text(file)
                                    .lineLimit(1)
                                    .truncationMode(.middle)
                                Spacer()
                                if file == project.entryRelativePath {
                                    Image(systemName: "checkmark")
                                        .foregroundStyle(.tint)
                                }
                            }
                        }
                        .buttonStyle(.plain)
                    }
                }
            } header: {
                Text("选择入口文件")
            } footer: {
                Text("入口文件就是启动时加载的那个 HTML。相对路径资源会以它所在项目根目录为基准解析。")
            }

            Section("路径") {
                Text(store.rootURL(for: project).path)
                    .font(.caption.monospaced())
                    .textSelection(.enabled)
            }
        }
        .navigationTitle(project.name)
        .task {
            isScanning = true
            let root = store.rootURL(for: project)
            htmlFiles = await Task.detached(priority: .userInitiated) {
                ProjectDetailView.scanHTMLFiles(in: root)
            }.value
            isScanning = false
        }
    }

    private func row(_ label: String, _ value: String) -> some View {
        HStack {
            Text(label).foregroundStyle(.secondary)
            Spacer()
            Text(value).multilineTextAlignment(.trailing)
        }
    }

    nonisolated static func scanHTMLFiles(in root: URL) -> [String] {
        let manager = FileManager.default
        guard let enumerator = manager.enumerator(at: root,
                                                 includingPropertiesForKeys: [.isRegularFileKey],
                                                 options: [.skipsHiddenFiles]) else { return [] }
        let rootPath = root.standardizedFileURL.path
        var results: [String] = []
        for case let url as URL in enumerator {
            let ext = url.pathExtension.lowercased()
            guard ext == "html" || ext == "htm" else { continue }
            let full = url.standardizedFileURL.path
            guard full.hasPrefix(rootPath) else { continue }
            var relative = String(full.dropFirst(rootPath.count))
            while relative.hasPrefix("/") { relative.removeFirst() }
            if !relative.isEmpty { results.append(relative) }
            if results.count >= 500 { break }
        }
        return results.sorted()
    }
}
