//
//  RunConfiguration.swift
//  HTMLRunner
//
//  Everything that controls *how* a project is executed. Kept in one place so the
//  settings screen, the run screen and the WebView factory all agree on the
//  meaning of a configuration, and so the log can record the exact conditions a
//  measurement was taken under.
//

import Foundation
import WebKit

enum RunMode: String, Codable, CaseIterable, Identifiable {
    /// `WKWebView.loadFileURL(_:allowingReadAccessTo:)` with the read-access root
    /// set to the imported project directory.
    case fileURL
    /// Optional loopback HTTP server bound to 127.0.0.1 only.
    case localServer

    var id: String { rawValue }

    var title: String {
        switch self {
        case .fileURL: return "file:// 直接加载"
        case .localServer: return "本地 HTTP 服务 (127.0.0.1)"
        }
    }

    var shortTitle: String {
        switch self {
        case .fileURL: return "file://"
        case .localServer: return "本地服务"
        }
    }

    var explanation: String {
        switch self {
        case .fileURL:
            return "使用 WKWebView.loadFileURL，并把读取范围授权到项目根目录。不占用端口，最接近“双击打开 HTML”的行为。受 WebKit 对 file:// 的同源策略限制。"
        case .localServer:
            return "启动仅监听 127.0.0.1 的本地 HTTP 服务，页面通过 http://127.0.0.1:<port>/ 访问。可获得正常的 HTTP 语义（ES Module、fetch、CORS），代价是多一个进程内的服务实现。"
        }
    }
}

/// Mirrors the parts of `WKAudiovisualMediaTypes` that matter for games, without
/// forcing callers to import WebKit just to read a setting.
enum AudioPlaybackPolicy: String, Codable, CaseIterable, Identifiable {
    case allowAll
    case requireUserGesture

    var id: String { rawValue }

    var title: String {
        switch self {
        case .allowAll: return "允许自动播放"
        case .requireUserGesture: return "需要用户手势"
        }
    }

    var mediaTypes: WKAudiovisualMediaTypes {
        switch self {
        case .allowAll: return []
        case .requireUserGesture: return .audio
        }
    }
}

enum ExternalLinkPolicy: String, Codable, CaseIterable, Identifiable {
    case openInSafari
    case block
    case allowInWebView

    var id: String { rawValue }

    var title: String {
        switch self {
        case .openInSafari: return "用 Safari 打开"
        case .block: return "阻止"
        case .allowInWebView: return "在应用内打开"
        }
    }

    var explanation: String {
        switch self {
        case .openInSafari:
            return "http/https 等外部链接交给系统浏览器，游戏页面本身保持稳定。"
        case .block:
            return "完全阻止离开本地项目的导航，最安全，也最严格。"
        case .allowInWebView:
            return "允许在同一个 WKWebView 内导航到外部站点；会离开本地项目，调试时才有必要。"
        }
    }
}

struct RunConfiguration: Codable, Equatable {
    var mode: RunMode = .fileURL
    /// Entry file path relative to the project root, e.g. `index.html`.
    var entryRelativePath: String = "index.html"
    var audioPolicy: AudioPlaybackPolicy = .allowAll
    var externalLinkPolicy: ExternalLinkPolicy = .openInSafari
    /// Injects the *diagnostics only* bridge at document start. It patches nothing
    /// related to rendering, timing or module loading; it only reports errors.
    var consoleBridgeEnabled: Bool = true
    /// Shows the optional in-page performance overlay (opt-in, off by default so
    /// it never covers the game).
    var performanceOverlayEnabled: Bool = false
    /// Keeps the project's own content untouched: this flag exists so the user can
    /// see, in the UI, that injection of the bridge can be turned off entirely.
    var injectDiagnosticsIntoPage: Bool = true
    /// Lowercased extensions of navigations that stay inside the web view.
    var allowedLocalSchemes: [String] = ["file", "about", "data", "blob", "http", "https"]

    var entryURLRelative: String { entryRelativePath }

    static let `default` = RunConfiguration()

    var summaryForLog: String {
        "mode=\(mode.rawValue) entry=\(entryRelativePath) audio=\(audioPolicy.rawValue) external=\(externalLinkPolicy.rawValue) consoleBridge=\(consoleBridgeEnabled) overlay=\(performanceOverlayEnabled) inject=\(injectDiagnosticsIntoPage)"
    }
}

// There is deliberately no `LastRunRecord` type here. An earlier revision declared
// one to persist "the conditions of the previous run", but `Project` already carries
// `lastOpenedAt` / `lastRunSucceeded`, and each run's full configuration is written
// into the diagnostic log — so the type was never referenced. It was removed by
// `tools/check_swift.py`'s unused-type check rather than left as dead code.
