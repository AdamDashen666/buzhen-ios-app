//
//  AppSettings.swift
//  HTMLRunner
//
//  User-visible configuration, persisted in UserDefaults.
//
//  Deliberate separation from `RunConfiguration`: a `RunConfiguration` is captured
//  per run and recorded in the log, so a measurement can always be traced back to
//  the exact conditions it was taken under. `AppSettings` is the mutable source the
//  run configuration is derived from.
//

import Foundation

final class AppSettings: ObservableObject {

    private enum Key {
        static let defaultRunMode = "defaultRunMode"
        static let defaultExternalLinkPolicy = "defaultExternalLinkPolicy"
        static let defaultAudioPolicy = "defaultAudioPolicy"
        static let diagnosticsEnabled = "diagnosticsEnabled"
        static let performanceOverlayEnabled = "performanceOverlayEnabled"
        static let localServerEnabled = "localServerEnabled"
        static let logLevel = "logLevel"
        static let allowWebInspector = "allowWebInspector"
        static let showDiagnosticsOnLaunch = "showDiagnosticsOnLaunch"
    }

    private let defaults: UserDefaults
    private let log: DiagnosticLogStore?

    // MARK: Stored settings

    /// Default page-load strategy for newly opened projects.
    @Published var defaultRunMode: RunMode {
        didSet { persist(defaultRunMode.rawValue, Key.defaultRunMode) }
    }

    @Published var defaultExternalLinkPolicy: ExternalLinkPolicy {
        didSet { persist(defaultExternalLinkPolicy.rawValue, Key.defaultExternalLinkPolicy) }
    }

    @Published var defaultAudioPolicy: AudioPlaybackPolicy {
        didSet { persist(defaultAudioPolicy.rawValue, Key.defaultAudioPolicy) }
    }

    /// Master switch for the diagnostic bridge (console + error capture). Turning it
    /// off means the page runs with zero scripts injected by this app.
    @Published var diagnosticsEnabled: Bool {
        didSet { persist(diagnosticsEnabled, Key.diagnosticsEnabled) }
    }

    @Published var performanceOverlayEnabled: Bool {
        didSet { persist(performanceOverlayEnabled, Key.performanceOverlayEnabled) }
    }

    /// Opt-in loopback server. Off by default: the file:// path needs no port, no
    /// listener and no network stack at all.
    @Published var localServerEnabled: Bool {
        didSet { persist(localServerEnabled, Key.localServerEnabled) }
    }

    @Published var logLevel: LogLevel {
        didSet {
            persist(logLevel.rawValue, Key.logLevel)
            // `self.log` is `@MainActor`-isolated. `logLevel` is only ever mutated from
            // SwiftUI (main thread), so hopping explicitly keeps the compiler happy
            // without weakening the isolation.
            if let log {
                let level = logLevel
                Task { @MainActor in log.minimumLevel = level }
            }
        }
    }

    /// Enables `WKWebView.isInspectable` so a Mac with Safari Web Inspector can
    /// attach to a Debug build. Off by default; it has no effect on Release builds
    /// signed for sideloading, where Web Inspector cannot attach anyway.
    @Published var allowWebInspector: Bool {
        didSet { persist(allowWebInspector, Key.allowWebInspector) }
    }

    @Published var showDiagnosticsOnLaunch: Bool {
        didSet { persist(showDiagnosticsOnLaunch, Key.showDiagnosticsOnLaunch) }
    }

    init(defaults: UserDefaults = .standard, log: DiagnosticLogStore? = nil) {
        self.defaults = defaults
        self.log = log
        let mode = defaults.string(forKey: Key.defaultRunMode).flatMap(RunMode.init(rawValue:)) ?? .fileURL
        let external = defaults.string(forKey: Key.defaultExternalLinkPolicy)
            .flatMap(ExternalLinkPolicy.init(rawValue:)) ?? .openInSafari
        let audio = defaults.string(forKey: Key.defaultAudioPolicy)
            .flatMap(AudioPlaybackPolicy.init(rawValue:)) ?? .allowAll
        let level = defaults.string(forKey: Key.logLevel).flatMap(LogLevel.init(rawValue:)) ?? .debug

        self.defaultRunMode = mode
        self.defaultExternalLinkPolicy = external
        self.defaultAudioPolicy = audio
        self.logLevel = level
        self.diagnosticsEnabled = defaults.object(forKey: Key.diagnosticsEnabled) as? Bool ?? true
        self.performanceOverlayEnabled = defaults.object(forKey: Key.performanceOverlayEnabled) as? Bool ?? false
        self.localServerEnabled = defaults.object(forKey: Key.localServerEnabled) as? Bool ?? false
        self.allowWebInspector = defaults.object(forKey: Key.allowWebInspector) as? Bool ?? false
        self.showDiagnosticsOnLaunch = defaults.object(forKey: Key.showDiagnosticsOnLaunch) as? Bool ?? false

        // NOTE: the log store's `minimumLevel` is deliberately NOT set here.
        // `DiagnosticLogStore` is `@MainActor`-isolated, so touching it from a
        // non-isolated initialiser would be an isolation violation. `AppState.init`
        // (which is main-actor isolated) applies the stored level instead.
    }

    private func persist(_ value: Any, _ key: String) {
        defaults.set(value, forKey: key)
    }

    /// Builds the run configuration used for a new run, recording which settings it
    /// came from so the log is self-explanatory.
    func makeRunConfiguration(entryRelativePath: String) -> RunConfiguration {
        var configuration = RunConfiguration()
        configuration.mode = localServerEnabled ? .localServer : defaultRunMode
        configuration.entryRelativePath = entryRelativePath
        configuration.externalLinkPolicy = defaultExternalLinkPolicy
        configuration.audioPolicy = defaultAudioPolicy
        configuration.consoleBridgeEnabled = diagnosticsEnabled
        configuration.injectDiagnosticsIntoPage = diagnosticsEnabled
        configuration.performanceOverlayEnabled = performanceOverlayEnabled
        return configuration
    }

    /// Row data for the settings screen, so the view has no formatting logic.
    var summaryRows: [(String, String)] {
        [
            ("默认加载方式", localServerEnabled ? "本地 HTTP 服务" : defaultRunMode.title),
            ("外部链接", defaultExternalLinkPolicy.title),
            ("音频播放", defaultAudioPolicy.title),
            ("诊断桥", diagnosticsEnabled ? "已启用" : "已关闭"),
            ("性能悬浮面板", performanceOverlayEnabled ? "已启用" : "已关闭"),
            ("本地服务开关", localServerEnabled ? "已启用" : "已关闭"),
            ("日志级别", logLevel.title),
            ("Web Inspector", allowWebInspector ? "允许（仅 Debug 生效）" : "不允许")
        ]
    }
}
