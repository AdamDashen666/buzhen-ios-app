# 交付报告

生成时间：2026-10-12 ｜ 生成环境：**Windows 11（10.0.26200），无 macOS / 无 Xcode / 无 iOS SDK / 无 iPad**

本文件是这次交付的**事实清单**。凡在此声明「完成」的项目，都能在本仓库中找到对应的文件或可复现的命令；
凡不能完成的，都写明了原因与下一步该由谁执行。

---

## 一、直接回答你的五个问题

| 你的问题 | 回答 |
|---|---|
| **IPA 的实际路径** | **不存在。本次没有生成 IPA。** 见第二节。构建脚本与工程已就绪，需在 macOS 上执行 `bash mac/build.sh`。 |
| **ZIP 的实际路径** | `dist/HTMLRunner-source-<版本>.zip`（由 `python tools/package_zip.py` 生成，含源码、工程、资源、脚本、文档；`dist/SHA256SUMS.txt` 内含其 SHA-256） |
| **是否成功构建** | **否。** 本机不是 macOS，`xcodebuild` 不存在，无法编译任何 iOS 产物。**未创建任何空文件或占位 IPA 来冒充成功。** |
| **是否实际安装到真机测试** | **否。** 没有可用的 Mac、没有连接设备，也没有签名证书与描述文件。 |
| **JIT 是否经过验证** | **否，且无法由本 App 验证。** 已通过阅读 WebKit / PojavLauncher / 侧载工具的一手源码与文档给出结论（见 [`HTMLRunner/JIT_NOTES.md`](HTMLRunner/JIT_NOTES.md)），但**没有任何一项是真机对照实验的结果**。 |

---

## 二、为什么没有 IPA（环境事实）

执行过的探测与结果：

```
uname / OS          : Microsoft Windows NT 10.0.26200.0 (AMD64)
xcodebuild          : 未找到（Get-Command 无结果）
swift / clang       : 未找到
WSL                 : 未安装（wsl --status → "not installed"）
Docker              : 未找到
SSH 配置            : 不存在（无远程 Mac）
签名证书 / 描述文件  : 不存在（无 ~/.mobileprovision、无 Xcode 账户）
连接的 iOS 设备      : 无
macOS 构建替代方案   : 无。iOS 应用只能由 Apple 的 Xcode 工具链编译；
                      没有合法的跨平台替代，也不存在可在 Windows 上产出的真机 IPA。
```

**因此：iOS 应用的编译与导出在本环境不可能完成。** 这一点无法通过任何技术手段绕过，
也不应该通过伪造产物来掩盖。可执行的下一步见第七节。

---

## 三、实际完成了什么（可验证）

### 3.1 源码与工程

| 内容 | 数量 / 说明 |
|---|---|
| Swift 源文件 | **21 个 / 6,245 行**（App、Views、Web、FileManagement、Diagnostics、Settings） |
| 打包进 App 的 JavaScript | 2 个：`DiagnosticBridge.js`、`WebProbe.js` |
| Xcode 工程 | `HTMLRunner.xcodeproj`，由 `tools/generate_project.py` 可重现生成；使用 Xcode 16 同步组，新增文件自动纳入编译 |
| Target | iOS/iPadOS App，Bundle ID `com.htmlrunner.ipad`，**仅 iPad**（`UIDeviceFamily = [2]`，要求全屏） |
| 部署目标 | iOS 17.0 |
| 第三方依赖 | **零**。无 CocoaPods / SPM / Homebrew |
| Entitlements | 仅 `get-task-allow`，且只在 Debug 配置引用；Release 不引用任何 entitlements 文件 |
| App 图标 | 1024² 无 alpha，由 `tools/make_icon.py` 可重现生成 |
| 文档 | `README.md`、`BUILD.md`、`CHANGELOG.md`、`HTMLRunner/JIT_NOTES.md`（334 行）、`docs/TEST-PLAN.md`、本文件 |

### 3.2 已真实执行的验证（6 个套件，全部通过）

来自 `python project-tests/run_all.py` 的实测输出：

| 套件 | 结果 | 实际做了什么 |
|---|---|---|
| `tools/check_swift.py` | **通过**，问题 0 | 21 个文件 / 6,245 行的结构检查：括号与字符串平衡、`#if`/`#endif` 平衡、重复类型声明、**重命名后遗漏的构造调用**（该项已用注入错误的方式做过反向验证） |
| `tools/verify_project.py` | **通过**，90 项检查 / 0 错误 / 0 警告 | pbxproj 以 OpenStep plist 语法解析、所有对象引用无悬空、scheme 的 BlueprintIdentifier 与 target 匹配、7 个同步组目录均存在且覆盖全部 Swift 文件、Info.plist 关键键与 iPad 方向、entitlements 最小化且无特权键、AppIcon 尺寸与无 alpha、打包 JS 资源存在 |
| `tools/verify_pbxproj.py` | **通过**，0 问题 | 独立复核 `project.pbxproj`：Debug/Release 的构建配置差异是否全部落在允许清单内、是否混入不该提交的签名身份键、entitlements 引用是否存在且最小化、以及**提交的 pbxproj 与生成器输出逐字节一致**（手工改过的话，下次生成会被静默还原） |
| `project-tests/harness/logic.test.js` | **通过，52/52** | HTTP 请求头解析、Byte-Range 算术（含后缀范围 / 区间裁剪 / 416 / 多段拒绝）、路径穿越与符号链接逃逸防护、MIME 表、导入入口选择、目录名净化；以及「Swift 与 JS 的实现必须一致」的交叉断言 |
| `project-tests/run_tests.py` | **通过，10/10 夹具、41/41 断言**，引擎 WebKit 27.2 | 在**桌面 WebKit 引擎**中真实加载 12 个夹具中的 10 个自动化夹具：简单页面、CSS/JS、ES Modules（两级导入）、fetch（含中文/空格文件名与二进制）、Three.js 形态 3D 场景（外部着色器文件 + 逐帧渲染）、WebGL2 能力与端到端绘制、GLSL（含 3 个故意写错的着色器）、纹理分阶段分配、目录与编码、以及 App 自身两个脚本的自测 |
| `tools/verify_dist.py` | **通过** | 校验 `dist/` 的 SHA-256 清单、ZIP 完整性、无绝对路径/反斜杠/路径穿越条目、内嵌清单与 102 个文件的哈希逐项匹配、构建所需文件齐全、无构建产物或依赖目录泄漏；并确认「没有 IPA」与文档声明一致 |

**在测试中发现并修复的真实缺陷**（不是「一次写对」）：

1. **`WebProbe.js` 的调用形式是错的** —— 它以 `})(arguments[0] || {})` 自调用，导致 Swift 侧
   `return (<file>)(options)` 直接抛 `SyntaxError: Unexpected token ';'`。**这会使用户点击「探测」必然失败。**
   改为「先发布 `__HTMLRUNNER_PROBE_RUN__`，再显式调用」，并给探测器加了 `{"fatal": ...}` 自报错误通道。
2. **诊断桥无法捕获页面解析期的资源加载失败** —— 原先的测试把桥注入在页面脚本之后。改为在解析期
   同步安装（与 `WKUserScript(.atDocumentStart)` 一致）后，`resourceError` 被正确捕获。
3. **`ProjectStore.sanitizeDirectoryName` 的净化不完整** —— 逻辑测试发现它会把 `...hidden` 变成 `-.hidden`。
   已修正为同时剥离前导 `.` 与 `-`（后者兼作命令行参数注入防护），并补充了对应测试。
4. **两个嵌套类同名** `Coordinator` —— 结构检查发现；已重命名为 `FilePickerCoordinator` / `FolderPickerCoordinator`。
5. **`tools/generate_project.py` 会产出 `CODE_SIGN_ENTITLEMENTS = ;`** —— 空值赋值是非法 OpenStep 语法，
   会让 Xcode 报「工程已损坏」。已修正为省略空值键（Release 配置正依赖这一点）。
6. **夹具自身的 GLSL 问题** —— `#version` 必须在着色器源码第一行，模板字符串的前导换行会让编译失败。
   已在 mini-three 的着色器编译器与夹具中修正（并因此把外部着色器文件加载也纳入夹具）。
7. **测试脚手架的两个 bug** —— 静态服务器的根目录与 URL 路径重复导致全夹具 404；`--only` 选择器在
   PowerShell 下被当成整数。两者都已修正，并加了「非 200 立即失败」的守卫，避免白白空等。

### 3.3 JIT 研究（已完成，且经过交叉核对）

`HTMLRunner/JIT_NOTES.md` 的核心结论，我**独立复核过其中最关键的两条**：

* **已复核**：WebKit 源码 `Source/WebKit/Scripts/process-entitlements.sh` 中，
  iOS 家族的 WebContent 进程被写入 `com.apple.private.verified-jit`，且在 `SDK_VERSION_ACTUAL >= 170400` 时
  写 `com.apple.developer.cs.allow-jit`（更早为 `dynamic-codesigning`）。
  同一脚本里 `PRODUCT_NAME == com.apple.WebKit.WebContent.Development` 时**不写任何 entitlement**。
  → 网页的运行权限由 Apple 签名的系统进程决定，**第三方 App 无法授予，也不需要授予**。
* **已复核**：PojavLauncher `Natives/utils.m` 的 `isJITEnabled()` 检查
  `SecTaskCopyValueForEntitlement("dynamic-codesigning")` 或 `csops(getpid(), 0, &flags, …) & CS_DEBUGGED`。
  → 侧载工具的「开 JIT」作用于**被附加的 App 进程**，这是它出现在列表里的原因，与网页 JS 无关。

**结论（供你据此调整预期）：**

* 用带 `get-task-allow` 的签名方式（个人 Apple ID / 开发证书）安装，HTMLRunner **大概率会出现在
  这类工具的 JIT 候选列表里**——但给**它**开 JIT **不会**让 WKWebView 里的 Three.js 跑得更快。
* 反过来，**锁定模式（Lockdown Mode）会真的关掉网页的 JIT 与 WebAssembly**，那是唯一你能通过系统
  设置实际改变网页 JS 执行方式的开关。
* 网页侧**没有任何公开 API** 能判定 JIT 是否开启；唯一有对照意义的实验是「锁定模式开 / 关各跑一次」。
  本 App 因此把这部分标为「无法直接确认」，不拿性能数字冒充结论。

---

## 四、测试计划执行情况（逐项，不做任何混淆）

| # | 测试项 | 状态 | 依据 |
|---|---|---|---|
| 1 | 简单 HTML 页面 | `ran-webkit` | 夹具 01 |
| 2 | 同目录 CSS 和 JS | `ran-webkit` | 夹具 02 |
| 3 | ES Modules | `ran-webkit` | 夹具 03（HTTP 语义下两级导入） |
| 4 | fetch() 读取本地 JSON | `ran-webkit` | 夹具 04（含中文/空格名与二进制） |
| 5 | Three.js 基础 3D 场景 | `ran-webkit` | 夹具 05（mini-three 替代，非真实 Three.js） |
| 6 | WebGL2 能力检测 | `ran-webkit` | 夹具 06（含端到端绘制与 readPixels） |
| 7 | GLSL 着色器编译 | `ran-webkit` | 夹具 07（6 例，含 3 个预期失败） |
| 8 | 大型纹理分阶段加载 | `ran-webkit` | 夹具 08（512→4096，逐阶段检查 glError） |
| 9 | 大量小文件的导入 | `static-check` | 算法级测试 + 源码检查；**iOS 文件提供器与 security-scoped URL 必须真机验证** |
| 10 | 中大型项目目录结构保留 | `static-check` | 夹具 10 覆盖中文/空格/`#`/大写扩展名/深层目录/BOM；**App 的复制保真度未在真机验证** |
| 11 | 进程终止后的提示与恢复 | `static-check` | 代码路径存在；**非 iOS 环境无法触发 WebContent 终止** |
| 12 | 长时间运行稳定性 | `not-run` | 需要真机长时间运行，无可信替代 |
| 13 | JIT 页面在不同签名/授权状态下 | `static-check` | 测试页与探测脚本已在 WebKit 中运行；**对照实验必须真机执行** |

**明确区分四种状态，互不替代：**

* **已在模拟器运行**：❌ **从未发生**（本机无 iOS 模拟器）。
* **已在真实 iPad 运行**：❌ **从未发生**。
* **仅静态检查**：第 9、10、11、13 项中的 iOS 侧部分。
* **未能执行**：第 12 项，以及全部需要 Xcode / 真机的构建与安装步骤。

> 桌面 WebKit（Playwright 27.2）**不是** WKWebView，也**不是** iPadOS。
> iOS 沙箱、jetsam 内存上限、`loadFileURL` 的 `file://` 策略、WebContent 进程终止，都无法在桌面复现。
> 上表中任何一个 `ran-webkit` 都**不能**读作「已在 iPad 上验证通过」。

---

## 五、产物与校验和

`dist/` 中的实际文件（由 `tools/package_zip.py` 生成，SHA-256 记录在 `dist/SHA256SUMS.txt`）：

| 文件 | 说明 |
|---|---|
| `dist/HTMLRunner-source-1.0.0.zip` | 完整源码 + 工程 + 资源 + 脚本 + 文档 |
| `dist/SHA256SUMS.txt` | 上述文件的 SHA-256 |
| ~~`dist/HTMLRunner.ipa`~~ | **未生成**（需要 macOS + Xcode） |

`build/` 中的构建日志：**不存在**，因为没有执行过 Xcode 构建。
`build/` 目录保留为空占位，供 `mac/build.sh` 在 macOS 上写入。

---

## 六、已知问题与未完成事项

**阻塞性（本环境无法解决）**

1. 未生成 IPA——需要 macOS + Xcode 15/16。
2. 未在真机或模拟器上运行——需要 iPad 或 macOS。
3. 未验证安装后能否出现在侧载工具的 JIT 列表中——需要真机 + 具体工具。
4. 长时间稳定性、真机内存水位、WebContent 终止与恢复——均需要真机。

**代码层面已知的、不影响交付但应知晓的限制**

5. `WebViewCoordinator` 与若干类使用类级 `@MainActor` 标注。若未来把 `SWIFT_STRICT_CONCURRENCY`
   提升到 `complete`，需要重新审视 WebKit delegate 回调与 `Network` 回调的隔离标注。
   （当前设置为 `minimal`，是有意选择，不是疏忽。）
6. `LocalHTTPServer` 的 keep-alive 被禁用（每个响应后关闭连接）。这简化了实现；若将来发现有明显开销，
   可以改为连接复用——但当前实现绝不会把大文件整块读入内存，这一点比复用更重要。
7. 诊断桥会包装 `HTMLCanvasElement.prototype.getContext`（仅用于上报 WebGL 创建失败）。
   这是 App 对页面唯一的行为性改动，可在设置中整体关闭。
8. 夹具 05 使用 mini-three 而非真实 Three.js（避免网络依赖）。替换为本地 `three.module.js` 只需改一行 import。

---

## 七、在 macOS 上的下一步操作（可复现）

```bash
# 0) 前置检查
xcodebuild -version && xcrun --sdk iphoneos --show-sdk-version

# 1) 先跑不需要 Xcode 的检查，确认源码与工程本身没问题
python3 tools/check_swift.py
python3 tools/verify_project.py
node project-tests/harness/logic.test.js

# 2) 重新生成工程（可选；仓库内已包含生成结果）
python3 tools/generate_project.py
xcodebuild -list -project HTMLRunner.xcodeproj

# 3) 构建 + 归档 + 导出未签名 IPA + 生成校验和
bash mac/build.sh

# 4) 校验产物
bash mac/verify_ipa.sh dist/HTMLRunner.ipa
shasum -a 256 -c dist/SHA256SUMS.txt

# 5) 若有 Apple 开发者账号，同时产出已签名开发版
DEVELOPMENT_TEAM=你的TeamID bash mac/build.sh --signed

# 6) 无 Mac 时：把 mac/ci-github-actions.yml 复制到 .github/workflows/ 并提交，
#    GitHub 的 macOS runner 会自动产出未签名 IPA 作为 artifact（不需要任何密钥）
```

拿到 IPA 之后：

```bash
# 在真机上跑测试夹具（把 project-tests/fixtures 整个文件夹导入 App）
# 逐项核对 docs/TEST-PLAN.md 中标记为 static-check / not-run 的项目
```

---

## 八、一句话总结

**这个仓库里有一个完整、经过可执行验证、且诚实标注了每一条结论来源的 iPadOS App 工程；
它唯一缺的东西是「一台 Mac」。** 需要 Mac 才能完成的部分（编译、签名、安装、真机测试）
我没有用任何伪造方式替代，而是把它们写成了可直接执行的脚本与明确的验收清单。
