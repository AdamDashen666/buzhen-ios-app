# Changelog

本文件记录有意义的变更。格式参考 [Keep a Changelog](https://keepachangelog.com/zh-CN/1.1.0/)，版本号遵循语义化版本。

**约定：** 只有真正完成并验证过的内容才会写入本文件。
「计划中」的内容会明确标为「未实现」，不会伪装成已完成。

---

## [1.0.0] — 2026-10-12

首个完整版本。目标：让本地大型 HTML / WebGL 项目在 iPad 上**可加载、可诊断、可控内存峰值**。

### 新增 — 项目导入与文件管理

* 项目库：`Documents/Projects/<目录名>/`，元数据保存在 `Application Support/HTMLRunner/library.json`。
* 两种导入入口：`UIDocumentPickerViewController`（文件夹 / 单个 HTML 文件），均使用 `asCopy: false` 以便自行控制复制过程。
* **流式分批复制**：按 256 KiB 分块读写，单文件可上报进度、可取消；不会把大文件读入 `Data`。
* 磁盘空间预检（`volumeAvailableCapacityForImportantUsage`，包含可清除空间），不足时拒绝导入并给出具体数字。
* 失败或取消时清理未完成的目录，不留半个项目。
* 导入计划：优先选择根目录 `index.html`，否则选择最浅层的 HTML；单个文件导入时按**白名单扩展名**复制同目录资源，并在项目详情里说明「不含子目录」。
* 项目重命名（只改显示名，不动目录名，因此不破坏相对路径）、删除（连同文件）、最近打开、入口文件改选。
* 目录名净化：移除分隔符、控制字符、前导 `.` 与 `-`（后者兼作命令行参数注入防护），长度上限 96。

### 新增 — WebKit 运行环境

* `WebViewFactory`：全 App 唯一的 `WKWebView` 创建点，每处非默认配置都在注释里写明理由与代价。
* `WebViewCoordinator`：`WKNavigationDelegate` / `WKUIDelegate` / `WKScriptMessageHandler`。
* 加载方式：`loadFileURL(_:allowingReadAccessTo:)`，读取范围授权到**项目根目录**而非入口文件。
* 可选**本地 HTTP 服务**（`Network.framework`）：只绑定 `127.0.0.1`、随机端口；支持 `GET`/`HEAD`/`OPTIONS`、`ETag`/304、单段 `Range`/206/416、正确的 MIME 表；拒绝 `..`、`.`、反斜杠、NUL 字节与符号链接逃逸；按 256 KiB 分块流式发送，绝不整文件读入内存。
* 导航策略：`file://`/`about:`/`data:`/`blob:` 与回环地址放行；外部链接按设置转交 Safari、阻止或允许。
* 失败分类：区分 `NSURLErrorCancelled` 与 `WebKitErrorDomain 102`（预期取消）和真正的加载失败，并记录 domain/code/failingURL。
* 页面进程终止：记录发生次数、当时的 App 内存采样、热状态、距上次事件的秒数，并**明确写出系统未提供终止原因**；提供带「状态会丢失」提示的重新加载入口。
* 页面静默探测：加载成功但长时间没有任何诊断事件时给出非阻断提示（不自动重启页面）。
* 防阻塞：`confirm`/`prompt` 自动返回安全值，避免游戏循环被卡死。

### 新增 — 诊断

* 有界日志：内存 4000 条 + 磁盘 3 MiB 双上限，超出丢弃最早记录并统计丢弃数；JSONL 落盘，支持级别过滤、全文搜索、复制、导出。
* 记录的事件类型全部带稳定标识符与时间戳，覆盖导航、加载、JavaScript 异常、Promise 拒绝、资源加载失败、WebGL 上下文创建失败、进程终止、用户刷新、导入、JIT 探测、本地服务、设置变更。
* `AppInfo`：版本、构建配置、设备型号标识（`uname`）、物理内存、核心数、热状态、低电量模式、WebKit 版本（能读到时）。
* `AppMemory`：`task_vm_info` 的 `resident_size` / `phys_footprint` / `virtual_size`、malloc 使用量、设备空闲内存。**读不到的字段返回 nil 并显示「无法获取」，绝不用 0 冒充。**
* `ProcessDebugState`：`sysctl(KERN_PROC_PID)` 读取 `P_TRACED`，并明确标注该值**只描述 App 进程**。
* 诊断报告导出：构建信息 + 设备信息 + 进程状态 + 内存 + 本地服务 + 当前项目 + 最近探测 + 完整日志，可分享。

### 新增 — 性能与能力探测

* `DiagnosticBridge.js`：文档开始时注入的**只读**错误上报桥（console 包装、未捕获异常、Promise 拒绝、资源加载失败、WebGL 上下文创建失败）。不触碰 rAF、定时器、fetch、模块加载与渲染，且可在设置里整体关闭。
* `WebProbe.js`：按需注入的能力与性能探测——WebGL2 版本/厂商/渲染器与完整限制表、扩展清单、GLSL 300 es 编译+链接+端到端绘制、WebAssembly 可用性与实例化、`new Function` 可用性、数值/分配/字符串基准、可选的大纹理分阶段分配。
* 探测结果带有机器可读的置信度声明：`javascriptJitState = "cannot-be-determined-from-a-web-page"`、`javascriptPerformance = "indirect-evidence-only"`。
* 探测只在用户点击时执行，创建的 WebGL 上下文立即释放。

### 新增 — 界面（iPad 优先）

* `NavigationSplitView` 三栏式布局：项目 / 诊断 / 设置，横屏下项目列表常驻侧边栏，不是拉伸的 iPhone 界面。
* 运行界面默认沉浸式全屏（忽略安全区、隐藏状态栏与系统浮层），点按呼出浮层工具栏；浮层不参与布局，因此不改变画布尺寸。
* 诊断页：运行时事实分组、JIT 诊断（含「无法直接确认」的显式呈现）、探测结果、内存走势图、本地服务状态、导出。
* 设置页：每项都说明作用与代价；包含 WebKit 缓存占用测量与清理（明确提示会删除 localStorage/IndexedDB 存档）。

### 新增 — 构建与打包（未执行）

* `mac/build.sh`：预检 → 构建 → 归档 → **arm64/非模拟器硬校验** → 导出 IPA（失败则手动打包）→ 结构校验 → 生成 SHA-256。
* `mac/build.sh --signed`：按开发证书 + 描述文件产出已签名开发版。
* `mac/verify_ipa.sh`：独立的 IPA 校验工具。
* `mac/ExportOptions-unsigned.plist` / `ExportOptions-development.plist`。
* `mac/ci-github-actions.yml`：GitHub Actions 模板（macOS runner，无需任何密钥）。
* `tools/generate_project.py`：可重现地生成 `HTMLRunner.xcodeproj`（Xcode 16 同步组，无 `DEVELOPMENT_TEAM`）。
* `tools/make_icon.py`：可重现地生成 1024² App 图标。

### 新增 — 测试

* `project-tests/fixtures/`：12 个夹具（简单页面、CSS/JS、ES Modules、fetch、Three.js 形态 3D 场景、WebGL2 能力、GLSL 编译、纹理分阶段加载、JIT 基准页、目录与编码、诊断桥自测）。
* `project-tests/run_tests.py` + `harness/`：在 **Playwright WebKit** 引擎中真实加载夹具并断言。
* `project-tests/harness/logic.test.js`：52 项纯逻辑测试，覆盖 HTTP 请求解析、Range 算术、路径穿越防护、导入计划、目录名净化，以及「JS 与 Swift 契约一致」的交叉检查。
* `tools/check_swift.py`：Swift 结构检查（括号/字符串/编译指令平衡、重复声明、**重命名后遗漏的构造调用**、**声明后从未被引用的类型**）。
* `tools/verify_project.py`：90 项工程与资源检查（pbxproj 图完整性、同步组覆盖、Info.plist 关键键、entitlements 最小化、AppIcon 尺寸与无 alpha）。
* `tools/verify_pbxproj.py`：复核构建配置一致性（Debug/Release 差异是否都在允许清单内）、确认未提交任何签名身份键、以及**提交的 pbxproj 与生成器输出逐字节一致**（防止手工修改在下次生成时被静默还原）。
* `tools/verify_dist.py`：交付物自检——SHA-256 清单、ZIP 完整性与条目安全（无绝对路径/反斜杠/路径穿越）、内嵌清单逐项哈希匹配、构建必需文件齐全、无构建产物泄漏。
* `tools/sync_doc_counts.py`：让文档里引用的文件数与行数保持与实际代码一致（`--check` 可用作门禁）。
* `project-tests/run_all.py`：一次跑完全部可用检查（6 个套件）并生成 `test-output/TEST-REPORT.json`，其中每个测试计划项都被标注为 `ran-webkit` / `ran-node` / `static-check` / `not-run-sim` / `not-run-device` / `not-run`。

**测试中发现并修复的缺陷（记录在后，避免被误读为「一次写对」）**

1. `WebProbe.js` 以 `})(arguments[0] || {})` 自调用，使 Swift 侧的 `return (<file>)(options)` 必然抛
   `SyntaxError`——用户点「探测」一定会失败。已改为「先发布 `__HTMLRUNNER_PROBE_RUN__` 再显式调用」，
   并给探测器加了 `{"fatal": …}` 自报错误通道。
2. 诊断桥无法捕获解析期的资源加载失败（测试把它注在页面脚本之后）。改在解析期同步安装后修复。
3. `ImportPlanner.sanitizeDirectoryName` 会把 `...hidden` 变成 `-.hidden`；已改为同时剥离前导 `.` 与 `-`。
4. 两个嵌套类同名 `Coordinator`；已重命名为 `FilePickerCoordinator` / `FolderPickerCoordinator`。
5. `tools/generate_project.py` 会产出非法的 `CODE_SIGN_ENTITLEMENTS = ;`（Xcode 会报工程损坏）；已改为省略空值键。
6. 夹具中的 `#version` 不在着色器首行（模板字符串前导换行）；已在 mini-three 与夹具中修正。
7. 测试脚手架两处 bug：静态服务器根目录与 URL 路径重复导致全夹具 404；`--only` 选择器在 PowerShell 下被当作整数。
8. 未使用的死类型 `LastRunRecord`（由新增的未引用类型检查发现，已删除）。
9. `tools/verify_pbxproj.py` 自身的假阳性：OpenStep 解析器会剥掉引号，`TARGETED_DEVICE_FAMILY = "2"` 读作 `2`。

### 安全相关

* 未启用 `allowUniversalAccessFromFileURLs` 等削弱 `file://` 同源隔离的配置。
* 未使用任何 WebKit 私有 API 或 SPI。
* `entitlements` 只含 `get-task-allow`，且仅 Debug 配置引用；Release 不引用任何 entitlements 文件。
* 未添加 `com.apple.security.cs.allow-jit` / `dynamic-codesigning` 等无法由 App 自授、只会导致安装失败的特权键。
* 本地服务仅监听回环地址，不开放局域网，不暴露项目根目录以外的任何路径。
* 日志不记录文件内容，只记录路径、大小与错误信息。

---

## 未实现 / 已知限制

以下内容**没有**实现，列在这里以免被误认为已完成：

* **未生成 IPA。** 开发环境是 Windows，没有 macOS 与 Xcode。见 [`DELIVERY-REPORT.md`](DELIVERY-REPORT.md)。
* **未在 iPad 真机或 iOS 模拟器上运行过。** 全部 iOS 侧结论均为静态检查。
* **未验证网页内容进程终止后的恢复流程。** 代码路径存在，但无法在非 iOS 环境触发该事件。
* **未进行长时间稳定性测试**（测试计划第 12 项）。
* **未对不同签名 / 授权状态下的 JIT 行为做对照实验**（测试计划第 13 项），也无法做到——网页侧没有判定 JIT 的 API。
* **未使用真实的 Three.js。** 夹具用 API 形态一致的 mini-three 替代，以避免网络依赖；替换方式见夹具内注释。
* **[ ] 若需要**：项目内搜索、缩略图生成、WebGL 帧率历史记录、崩溃报告上传——均未实现。
