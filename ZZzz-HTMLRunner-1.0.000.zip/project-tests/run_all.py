#!/usr/bin/env python3
"""Run every available check and write the definitive status report.

The point of this script is to prevent the single most damaging failure mode for a
deliverable like this one: blurring together "verified on a real iPad", "verified in
a desktop WebKit engine", "verified by static analysis" and "not verified at all".

Every test-plan item therefore has an explicit status drawn from this closed set:

    ran-webkit       executed in the Playwright WebKit engine on this machine
    ran-node         executed by the Node.js logic suite
    static-check     verified by source/project inspection only, never executed
    not-run-sim      would require the iOS Simulator (no macOS/Xcode available)
    not-run-device   would require a physical iPad
    not-run          not executed, and no substitute exists

Nothing here may promote an item's status. A green run of this script does NOT
mean the app was tested on an iPad, and the report says so in its own text.

Run:  python project-tests/run_all.py [--skip-webkit]
Exit: 0 when every *executable* check passed, 1 otherwise.
"""
from __future__ import annotations

import argparse
import datetime
import json
import pathlib
import platform
import re
import subprocess
import sys
import time

ROOT = pathlib.Path(__file__).resolve().parent.parent
OUTPUT = ROOT / "test-output"

STATUS_ORDER = [
    "ran-webkit",
    "ran-node",
    "static-check",
    "not-run-sim",
    "not-run-device",
    "not-run",
]

# The user's test plan (section 10), with the status each item can honestly claim
# on a Windows machine with no Xcode. `substitute` records what WAS actually done
# in place of the unavailable execution.
TEST_PLAN: list[dict] = [
    {
        "item": 1,
        "title": "简单 HTML 页面",
        "status": "ran-webkit",
        "evidence": "fixture 01-simple",
        "note": "在桌面 WebKit 引擎中加载并通过断言。真机未测。",
    },
    {
        "item": 2,
        "title": "引用同目录 CSS 和 JS 的 HTML",
        "status": "ran-webkit",
        "evidence": "fixture 02-css-js",
        "note": "样式表生效、外部脚本执行、子目录图片加载均已断言。",
    },
    {
        "item": 3,
        "title": "使用 ES Modules 的 HTML",
        "status": "ran-webkit",
        "evidence": "fixture 03-es-modules",
        "note": "在 HTTP 传输下两级相对导入成功。file:// 下的行为无法在此环境验证——那正是本地服务功能存在的理由。",
    },
    {
        "item": 4,
        "title": "使用 fetch() 读取本地 JSON 的 HTML",
        "status": "ran-webkit",
        "evidence": "fixture 04-fetch",
        "note": "含中文与空格文件名、二进制 arrayBuffer、404 预期失败。",
    },
    {
        "item": 5,
        "title": "使用 Three.js 创建基础 3D 场景",
        "status": "ran-webkit",
        "evidence": "fixture 05-threejs",
        "note": "以 API 形态一致的 mini-three 替代（无网络依赖），覆盖 WebGL2 上下文、外部着色器文件、VBO/VAO、投影矩阵与逐帧渲染。未使用真实 Three.js。",
    },
    {
        "item": 6,
        "title": "WebGL2 能力检测",
        "status": "ran-webkit",
        "evidence": "fixture 06-webgl2-capabilities",
        "note": "列出真实限制与扩展，并完成一次端到端绘制与 readPixels。",
    },
    {
        "item": 7,
        "title": "GLSL 着色器编译",
        "status": "ran-webkit",
        "evidence": "fixture 07-glsl",
        "note": "6 个用例，含 3 个故意写错的着色器，确认编译器拒绝并返回日志。",
    },
    {
        "item": 8,
        "title": "大型纹理的分阶段加载",
        "status": "ran-webkit",
        "evidence": "fixture 08-texture-staging",
        "note": "512→4096 分阶段创建/释放，逐步检查 glError。真机的显存与 jetsam 行为无法在此复现。",
    },
    {
        "item": 9,
        "title": "大量小文件的导入",
        "status": "static-check",
        "evidence": "tools/verify_project.py + project-tests/harness/logic.test.js",
        "note": "导入路径的分批复制、进度上报、取消与清理逻辑经静态检查与算法级测试；iOS 文件提供器与 security-scoped URL 的真实行为必须在真机验证。",
    },
    {
        "item": 10,
        "title": "中大型项目的目录结构保留",
        "status": "static-check",
        "evidence": "fixture 10-structure-and-encoding + logic.test.js 路径解析测试",
        "note": "夹具覆盖中文目录、空格、# 编码、大写扩展名、深层目录、零字节文件与 BOM；WebKit 侧已验证这些路径在 HTTP 语义下可解析。App 的复制保真度需真机验证。",
    },
    {
        "item": 11,
        "title": "页面进程终止后的错误提示与恢复",
        "status": "static-check",
        "evidence": "HTMLRunner/Web/WebViewCoordinator.swift (webViewWebContentProcessDidTerminate)",
        "note": "无法在非 iOS 环境触发 WebContent 终止。代码路径存在并写入日志，UI 提供重新加载入口，但未在真机验证过终止与恢复。",
    },
    {
        "item": 12,
        "title": "长时间运行时的稳定性",
        "status": "not-run",
        "evidence": "-",
        "note": "需要在真机上长时间运行并观察内存与热状态。本环境无法执行，也没有可信替代方案。",
    },
    {
        "item": 13,
        "title": "JIT 测试页面在不同签名和授权状态下的表现",
        "status": "static-check",
        "evidence": "fixture 09-jit-benchmark + HTMLRunner/Resources/Web/WebProbe.js + JIT_NOTES.md",
        "note": "测试页与探测脚本已实现并在 WebKit 中运行；不同签名状态下的对照实验必须在真机上做（且需要可改变签名状态的工具）。JIT 状态本身无法由网页判定，详见 JIT_NOTES.md。",
    },
]


def run(command: list[str], cwd: pathlib.Path | None = None, timeout: int = 1800) -> tuple[int, str]:
    started = time.time()
    try:
        completed = subprocess.run(command, cwd=cwd or ROOT, capture_output=True,
                                   text=True, encoding="utf-8", errors="replace", timeout=timeout)
        output = (completed.stdout or "") + (completed.stderr or "")
        return completed.returncode, output
    except subprocess.TimeoutExpired as error:
        return 124, f"[timeout after {time.time() - started:.0f}s]\n{error}"
    except FileNotFoundError as error:
        return 127, f"[command not found: {error}]"


def main() -> int:
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except (AttributeError, ValueError):
            pass

    parser = argparse.ArgumentParser(description="运行全部可用检查并生成状态报告")
    parser.add_argument("--skip-webkit", action="store_true", help="跳过浏览器夹具（在无浏览器的机器上使用）")
    args = parser.parse_args()

    OUTPUT.mkdir(exist_ok=True)
    suites: list[dict] = []

    def record(name: str, command: list[str], exit_code: int, output: str, log_name: str) -> None:
        (OUTPUT / log_name).write_text(output, encoding="utf-8")
        suites.append({
            "name": name,
            "command": " ".join(command),
            "exitCode": exit_code,
            "passed": exit_code == 0,
            "log": f"test-output/{log_name}",
        })

    print("[all] 1/6 Swift 结构检查 …")
    code, output = run([sys.executable, "tools/check_swift.py"])
    record("swift-structure", [sys.executable, "tools/check_swift.py"], code, output, "check-swift.log")
    print(f"      exit={code}")

    print("[all] 2/6 Xcode 工程结构校验 …")
    code, output = run([sys.executable, "tools/verify_project.py"])
    record("xcode-project", [sys.executable, "tools/verify_project.py"], code, output, "verify-project.log")
    print(f"      exit={code}")

    print("[all] 3/6 pbxproj 配置一致性校验 …")
    code, output = run([sys.executable, "tools/verify_pbxproj.py"])
    record("pbxproj-consistency", [sys.executable, "tools/verify_pbxproj.py"], code, output, "verify-pbxproj.log")
    print(f"      exit={code}")

    print("[all] 4/6 Node 纯逻辑测试 …")
    code, output = run(["node", "project-tests/harness/logic.test.js"])
    record("logic", ["node", "project-tests/harness/logic.test.js"], code, output, "logic-tests.log")
    # The summary line is the machine-readable part.
    match = re.search(r"结果: (\d+)/(\d+) 通过", output)
    if match:
        suites[-1]["assertions"] = {"passed": int(match.group(1)), "total": int(match.group(2))}
    print(f"      exit={code}")

    if args.skip_webkit:
        print("[all] 5/6 浏览器夹具：已跳过（--skip-webkit）")
        suites.append({
            "name": "webit-fixtures",
            "command": "python project-tests/run_tests.py",
            "exitCode": None,
            "passed": None,
            "skipped": True,
            "log": None,
        })
    else:
        print("[all] 5/6 桌面 WebKit 夹具 …")
        code, output = run([sys.executable, "project-tests/run_tests.py"])
        record("webit-fixtures", [sys.executable, "project-tests/run_tests.py"], code, output, "webit-tests.log")
        fixture_report = OUTPUT / "webit-test-report.json"
        if fixture_report.exists():
            report = json.loads(fixture_report.read_text(encoding="utf-8"))
            suites[-1]["browser"] = report.get("browserName")
            suites[-1]["browserVersion"] = report.get("browserVersion")
            suites[-1]["fixtures"] = [
                {"id": fixture["id"], "passed": fixture["passed"],
                 "httpStatus": fixture.get("httpStatus"),
                 "checks": len(fixture["checks"]),
                 "checksPassed": sum(1 for check in fixture["checks"] if check["passed"])}
                for fixture in report.get("fixtures", [])
            ]
        print(f"      exit={code}")

    # ------------------------------------------------------------------ report --
    print("[all] 6/6 交付物（dist/）校验 …")
    if (ROOT / "dist" / "SHA256SUMS.txt").exists():
        code, output = run([sys.executable, "tools/verify_dist.py"])
        record("dist-artifacts", [sys.executable, "tools/verify_dist.py"], code, output, "verify-dist.log")
        print(f"      exit={code}")
    else:
        # Not a failure: the ZIP is produced by a separate step, and a reader running
        # only the checks should not be blocked by it.
        print("      dist/ 尚未打包，跳过（先运行 python tools/package_zip.py）")
        suites.append({
            "name": "dist-artifacts",
            "command": "python tools/verify_dist.py",
            "exitCode": None,
            "passed": None,
            "skipped": True,
            "log": None,
        })

    report = {
        "generatedAt": datetime.datetime.now().astimezone().isoformat(),
        "host": {
            "platform": platform.platform(),
            "python": platform.python_version(),
            "machine": platform.machine(),
            "note": "本报告的宿主是 Windows。没有 macOS、没有 Xcode、没有 iOS SDK、没有 iPad。",
        },
        "headline": {
            "ipaBuilt": False,
            "ipaReason": "本机不是 macOS，没有 Xcode 与 iOS SDK，无法编译或导出 IPA。详见 BUILD.md 与 DELIVERY-REPORT.md。",
            "testedOnIPad": False,
            "testedOnSimulator": False,
            "jitVerified": False,
            "jitReason": "没有任何公开 API 能判定 WKWebView 的 WebContent 进程是否使用 JIT；本环境也无法进行锁定模式对照实验。详见 JIT_NOTES.md。",
        },
        "suites": suites,
        "testPlan": TEST_PLAN,
        "statusLegend": {
            "ran-webkit": "在桌面 WebKit 引擎中真实执行",
            "ran-node": "由 Node 逻辑测试真实执行",
            "static-check": "仅静态/算法级验证，未在目标环境执行",
            "not-run-sim": "需要 iOS 模拟器（本机不可用）",
            "not-run-device": "需要真机 iPad",
            "not-run": "未执行，且无可信替代",
        },
        "disclaimer": [
            "桌面 WebKit 不是 WKWebView，也不是 iPadOS。",
            "iOS 沙箱、jetsam 内存上限、loadFileURL 的 file:// 策略、WebContent 进程终止都无法在桌面复现。",
            "本报告中的任何一项都不能读作「已在 iPad 上验证通过」。",
        ],
    }

    report_path = OUTPUT / "TEST-REPORT.json"
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    print("\n[all] 测试计划状态（按原始编号）")
    for item in TEST_PLAN:
        marker = "✔" if item["status"].startswith("ran-") else "·"
        print(f"  {marker} {item['item']:>2}. {item['title']} → {item['status']}")

    print(f"\n[all] 报告: {report_path.relative_to(ROOT)}")
    failed = [suite for suite in suites if suite["passed"] is False]
    if failed:
        print(f"[all] 失败的套件: {', '.join(suite['name'] for suite in failed)}")
        return 1
    print("[all] 全部可执行的检查通过")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
