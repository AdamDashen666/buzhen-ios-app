#!/usr/bin/env python3
"""Run the HTML fixtures in a real WebKit engine and report what actually happened.

WHAT THIS PROVES, AND WHAT IT DOES NOT
--------------------------------------
Playwright's WebKit build shares the engine lineage of the WebKit that backs
WKWebView on iPadOS, so it is a far better proxy than Chromium for questions like
"does this ES module graph resolve", "does this GLSL compile", "does fetch() of a
sibling file work over HTTP". It is NOT an iPad and it is NOT WKWebView:

  * it does not reproduce WebKit's iOS sandbox, jetsam limits or memory budget;
  * it does not reproduce the WKURLSchemeHandler / loadFileURL file:// policy;
  * it cannot observe a WebContent process termination the way iOS does.

So a pass here means "the fixture and the engine agree", not "this works on the
iPad". Every line of the generated report says which of the two it is.

Usage
-----
    python project-tests/run_tests.py                  # all automated fixtures
    python project-tests/run_tests.py --only 03,06     # a subset
    python project-tests/run_tests.py --browser chromium
    python project-tests/run_tests.py --keep-open      # leave the server up for manual poking

Exit code 0 = every automated fixture passed, 1 otherwise, 2 = harness unavailable.
"""
from __future__ import annotations

import argparse
import json
import os
import pathlib
import shutil
import subprocess
import sys
import time

ROOT = pathlib.Path(__file__).resolve().parent.parent
FIXTURES = ROOT / "project-tests" / "fixtures"
OUTPUT_DIR = ROOT / "test-output"
HARNESS_DIR = ROOT / "project-tests" / "harness"
PLAYWRIGHT_DIRS = [
    pathlib.Path(os.environ.get("LOCALAPPDATA", "")) / "ms-playwright",
    pathlib.Path.home() / "Library" / "Caches" / "ms-playwright",
    pathlib.Path.home() / ".cache" / "ms-playwright",
]

# Assertions are declared here so the report can show what was expected even when a
# page fails to load at all.
CHECKS = {
    "01-simple": [
        {
            "label": "页面渲染出标题",
            "script": "document.querySelector('h1') && document.querySelector('h1').textContent.includes('最简单')",
        },
        {
            "label": "内联脚本已执行",
            "script": "!!document.getElementById('ok') && document.getElementById('ok').textContent.includes('脚本已执行')",
        },
    ],
    "02-css-js": [
        {"label": "外部 JS 已加载", "script": "window.FIXTURE_LOADER_LOADED === true"},
        {
            "label": "外部 CSS 生效",
            "script": "getComputedStyle(document.getElementById('title')).color === 'rgb(0, 102, 204)'",
        },
        {
            "label": "子目录图片加载成功",
            "script": "(function(){var i=document.querySelector('img');return !!(i && i.complete && i.naturalWidth > 0);})()",
        },
    ],
    "03-es-modules": [
        {"label": "模块脚本执行完成", "script": "!!window.__FIXTURE_03__ && window.__FIXTURE_03__.moduleExecuted === true"},
        {
            "label": "两级相对路径导入都成功",
            "script": "!!window.__FIXTURE_03__ && (window.__FIXTURE_03__.imports || []).length === 2",
        },
        {"label": "模块导出计算结果正确", "script": "!!window.__FIXTURE_03__ && window.__FIXTURE_03__.addResult === 5"},
    ],
    "04-fetch": [
        {"label": "fetch 全部用例执行完毕", "script": "!!window.__FIXTURE_04__ && window.__FIXTURE_04__.done === true"},
        {
            "label": "成功用例数 ≥ 4（含中文与空格文件名）",
            "script": "!!window.__FIXTURE_04__ && (window.__FIXTURE_04__.cases || []).filter(function(c){return c.ok;}).length >= 4",
        },
        {
            "label": "不存在的文件按预期失败",
            "script": "!!window.__FIXTURE_04__ && (window.__FIXTURE_04__.cases || []).some(function(c){return c.label.indexOf('不存在') >= 0 && !c.ok;})",
        },
    ],
    "05-threejs": [
        {
            "label": "场景初始化无异常",
            "script": "!!window.__FIXTURE_05__ && window.__FIXTURE_05__.error === null",
        },
        {"label": "使用 WebGL2 上下文", "script": "!!window.__FIXTURE_05__ && window.__FIXTURE_05__.webgl2 === true"},
        {
            "label": "渲染循环持续出帧（≥ 20 帧）",
            "script": "!!window.__FIXTURE_05__ && window.__FIXTURE_05__.frames >= 20",
        },
        {
            "label": "能取到渲染器标识",
            "script": "!!window.__FIXTURE_05__ && typeof window.__FIXTURE_05__.renderer === 'string' && window.__FIXTURE_05__.renderer.length > 0",
        },
        {
            "label": "外部着色器文件（shaders/*.vert/.frag）通过 fetch 加载",
            "script": "!!window.__FIXTURE_05__ && window.__FIXTURE_05__.externalShaderLoaded === true",
        },
    ],
    "06-webgl2-capabilities": [
        {"label": "WebGL2 上下文可用", "script": "!!window.__FIXTURE_06__ && window.__FIXTURE_06__.webgl2 === true"},
        {
            "label": "GLSL 300 es 编译并链接成功",
            "script": "!!window.__FIXTURE_06__ && !!window.__FIXTURE_06__.shaderTest && window.__FIXTURE_06__.shaderTest.linked === true",
        },
        {"label": "绘制一帧无 glError", "script": "!!window.__FIXTURE_06__ && window.__FIXTURE_06__.drawError === 0"},
        {
            "label": "readPixels 返回 4 字节",
            "script": "!!window.__FIXTURE_06__ && Array.isArray(window.__FIXTURE_06__.centerPixel) && window.__FIXTURE_06__.centerPixel.length === 4",
        },
    ],
    "07-glsl": [
        {
            "label": "全部 6 个用例的期望结果都成立",
            "script": "!!window.__FIXTURE_07__ && window.__FIXTURE_07__.cases.length === 6 && window.__FIXTURE_07__.cases.every(function(c){return c.passed;})",
        },
        {
            "label": "故意写错的着色器确实被拒绝",
            "script": "!!window.__FIXTURE_07__ && window.__FIXTURE_07__.cases.filter(function(c){return !c.expectSuccess;}).every(function(c){return c.compiled === false || c.linked === false;})",
        },
        {
            "label": "错误用例带回了编译器日志",
            "script": "!!window.__FIXTURE_07__ && window.__FIXTURE_07__.cases.filter(function(c){return !c.expectSuccess;}).every(function(c){return typeof c.log === 'string' && c.log.trim().length > 0;})",
        },
    ],
    "08-texture-staging": [
        {"label": "WebGL2 可用", "script": "!!window.__FIXTURE_08__ && window.__FIXTURE_08__.webgl2 === true"},
        {
            "label": "至少完成 3 个纹理阶段",
            "script": "!!window.__FIXTURE_08__ && window.__FIXTURE_08__.stages.length >= 3",
        },
        {
            "label": "所有阶段 glError 为 0",
            "script": "!!window.__FIXTURE_08__ && window.__FIXTURE_08__.stages.every(function(s){return s.error === 0;})",
        },
        {"label": "测试正常结束（未中断）", "script": "!!window.__FIXTURE_08__ && window.__FIXTURE_08__.finished === true"},
    ],
    "10-structure-and-encoding": [
        {
            "label": "全部路径/编码检查通过",
            "script": "!!window.__FIXTURE_10__ && window.__FIXTURE_10__.checks.length > 0 && window.__FIXTURE_10__.checks.every(function(c){return c.ok;})",
        },
        {
            "label": "中文目录图片加载成功",
            "script": "!!window.__FIXTURE_10__ && window.__FIXTURE_10__.checks.some(function(c){return c.label.indexOf('中文目录名') >= 0 && c.ok;})",
        },
        {
            "label": "含 # 的文件名（%23）加载成功",
            "script": "!!window.__FIXTURE_10__ && window.__FIXTURE_10__.checks.some(function(c){return c.label.indexOf('#') >= 0 && c.ok;})",
        },
        {
            "label": "含空格的文件名（%20）加载成功",
            "script": "!!window.__FIXTURE_10__ && window.__FIXTURE_10__.checks.some(function(c){return c.label.indexOf('空格') >= 0 && c.ok;})",
        },
    ],
    "11-diagnostic-bridge": [
        {"label": "诊断桥已注入并置位安装标记", "script": "!!window.__FIXTURE_11__ && window.__FIXTURE_11__.bridgeLoaded === true"},
        {
            "label": "捕获 console.log / warn / error",
            "script": "!!window.__FIXTURE_11__ && ['log','warn','error'].every(function(level){return window.__FIXTURE_11__.bridgeMessages.some(function(m){return m.kind === 'console' && m.level === level;});})",
        },
        {
            "label": "捕获未捕获异常",
            "script": "!!window.__FIXTURE_11__ && window.__FIXTURE_11__.bridgeMessages.some(function(m){return m.kind === 'error';})",
        },
        {
            "label": "捕获未处理的 Promise 拒绝",
            "script": "!!window.__FIXTURE_11__ && window.__FIXTURE_11__.bridgeMessages.some(function(m){return m.kind === 'unhandledrejection';})",
        },
        {
            "label": "捕获资源加载失败（img）",
            "script": "!!window.__FIXTURE_11__ && window.__FIXTURE_11__.bridgeMessages.some(function(m){return m.kind === 'resourceError';})",
        },
        {
            "label": "原 console 仍然被调用（是包装不是替换）",
            "script": "!!window.__FIXTURE_11__ && window.__FIXTURE_11__.originalConsoleStillCalled.log === true && window.__FIXTURE_11__.originalConsoleStillCalled.error === true",
        },
        {
            "label": "WebProbe.js 返回结构化 JSON（含 WebGL2 与基准数据）",
            "script": "!!window.__FIXTURE_11__ && !!window.__FIXTURE_11__.probe && !!window.__FIXTURE_11__.probe.webgl2 && !!window.__FIXTURE_11__.probe.benchmark",
        },
        {
            "label": "探测结果明确标注 JIT 状态不可判定",
            "script": "!!window.__FIXTURE_11__ && window.__FIXTURE_11__.probeJitVerdict === 'cannot-be-determined-from-a-web-page'",
        },
        {
            "label": "探测结果把性能标注为 indirect-evidence-only",
            "script": "!!window.__FIXTURE_11__ && !!window.__FIXTURE_11__.probe && window.__FIXTURE_11__.probe.confidence.javascriptPerformance === 'indirect-evidence-only'",
        },
        {
            "label": "WebProbe.js 的 GLSL 编译链接在真实引擎中成功",
            "script": "!!window.__FIXTURE_11__ && !!window.__FIXTURE_11__.probe && !!window.__FIXTURE_11__.probe.webgl2.shaderTest && window.__FIXTURE_11__.probe.webgl2.shaderTest.linked === true",
        },
    ],
}


# Values a fixture exposes purely to explain a failure. Printed in the report so a
# red test says why it is red instead of only "false".
DIAGNOSTICS = {
    "11-diagnostic-bridge": {
        "probeError": "window.__FIXTURE_11__ && window.__FIXTURE_11__.probeError",
        "bridgeError": "window.__FIXTURE_11__ && window.__FIXTURE_11__.bridgeError",
        "bridgeMessageKinds": "window.__FIXTURE_11__ ? Array.from(new Set(window.__FIXTURE_11__.bridgeMessages.map(function(m){return m.kind;}))) : null",
        "probeNull": "window.__FIXTURE_11__ ? window.__FIXTURE_11__.probe === null : null",
    },
    "05-threejs": {
        "error": "window.__FIXTURE_05__ && window.__FIXTURE_05__.error",
        "frames": "window.__FIXTURE_05__ && window.__FIXTURE_05__.frames",
    },
    "08-texture-staging": {
        "error": "window.__FIXTURE_08__ && window.__FIXTURE_08__.error",
        "stageCount": "window.__FIXTURE_08__ ? window.__FIXTURE_08__.stages.length : null",
    },
}


def find_browser(browser_name: str) -> pathlib.Path | None:
    """Locate a Playwright browser executable without downloading anything."""
    prefix = {"webkit": "webkit", "chromium": "chromium", "firefox": "firefox"}[browser_name]
    candidates: list[pathlib.Path] = []
    for directory in PLAYWRIGHT_DIRS:
        if not directory.is_dir():
            continue
        for child in sorted(directory.iterdir(), reverse=True):
            if not child.name.startswith(prefix):
                continue
            for name in ("Playwright.exe", "chrome-win/chrome.exe", "firefox/firefox.exe",
                         "pw_run.sh", "MiniBrowser", "minibrowser"):
                path = child / name
                if path.exists():
                    candidates.append(path)
    return candidates[0] if candidates else None


def node_available() -> bool:
    return shutil.which("node") is not None


def ensure_harness_dependencies() -> bool:
    """Installs playwright-core locally if the harness has no node_modules yet."""
    if (HARNESS_DIR / "node_modules" / "playwright-core").is_dir():
        return True
    package_json = HARNESS_DIR / "package.json"
    package_json.parent.mkdir(parents=True, exist_ok=True)
    if not package_json.exists():
        package_json.write_text(
            json.dumps({"name": "htmlrunner-harness", "private": True, "type": "commonjs",
                        "dependencies": {"playwright-core": "^1.64.0"}}, indent=2) + "\n",
            encoding="utf-8")
    print("[harness] 正在安装 playwright-core（仅驱动本地已存在的浏览器，不下载浏览器）…")
    env = dict(os.environ, PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD="1")
    result = subprocess.run(["npm", "install", "--no-audit", "--no-fund"],
                            cwd=HARNESS_DIR, env=env, capture_output=True, text=True, shell=True)
    if result.returncode != 0:
        print(result.stdout[-2000:])
        print(result.stderr[-2000:], file=sys.stderr)
        return False
    return (HARNESS_DIR / "node_modules" / "playwright-core").is_dir()


def main() -> int:
    # Windows consoles frequently default to a legacy code page (e.g. GBK) that
    # cannot encode the symbols this report uses. Reconfiguring stdout to UTF-8 with
    # a replacement policy keeps the report readable instead of aborting the run.
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except (AttributeError, ValueError):
            pass

    parser = argparse.ArgumentParser(description="在真实 WebKit 引擎中运行 HTML 测试夹具")
    parser.add_argument("--only", default="", help="只运行这些编号，例如 03,06")
    parser.add_argument("--browser", default="webkit", choices=["webkit", "chromium", "firefox"])
    parser.add_argument("--keep-open", action="store_true", help="测试结束后保持服务器运行，便于手动访问")
    parser.add_argument("--timeout", type=int, default=45, help="每个夹具的等待上限（秒）")
    args = parser.parse_args()

    OUTPUT_DIR.mkdir(exist_ok=True)

    if not node_available():
        print("[harness] 未找到 node，无法驱动浏览器。", file=sys.stderr)
        return 2
    if not ensure_harness_dependencies():
        print("[harness] playwright-core 不可用。", file=sys.stderr)
        return 2

    executable = find_browser(args.browser)
    if executable is None and args.browser != "chromium":
        executable = find_browser("chromium")

    index = json.loads((FIXTURES / "index.json").read_text(encoding="utf-8"))
    selected = [case for case in index["fixtures"] if case.get("automated")]
    if args.only:
        # Accepts `--only 03,06` (leading number) or `--only 03-es-modules` (full id).
        # Comparison normalises the numeric prefix, because shells differ on whether
        # `01` arrives as the string "01" or the integer 1.
        def numeric_prefix(value: str) -> str:
            head = value.split("-")[0]
            return str(int(head)) if head.isdigit() else head

        wanted = [item.strip() for item in args.only.split(",") if item.strip()]
        selected = [
            case for case in selected
            if any(case["id"] == item or numeric_prefix(case["id"]) == numeric_prefix(item)
                   for item in wanted)
        ]
        if not selected:
            print(f"[harness] --only {args.only} 没有匹配任何自动化夹具。", file=sys.stderr)
            return 2

    payload = {
        "fixtures": [
            {
                "id": case["id"],
                "title": case["title"],
                "dir": str(FIXTURES / case["id"]),
                # The URL keeps the `<id>/index.html` shape, so the document root the
                # server exposes must be the fixtures directory itself.
                "serveRoot": str(FIXTURES),
                # Extra mounts: the diagnostic-bridge self-test loads the *shipped*
                # WebProbe.js / DiagnosticBridge.js from the real app resources, so it
                # can never pass against a stale copy.
                "mounts": [{"prefix": "/__app__/", "dir": str(ROOT / "HTMLRunner" / "Resources")}],
                "checks": CHECKS.get(case["id"], []),
                "diagnostics": DIAGNOSTICS.get(case["id"], {}),
                "requiresLocalServer": case.get("requiresLocalServer", False),
            }
            for case in selected
        ],
        "executablePath": str(executable) if executable else None,
        "browserName": args.browser,
        "timeoutMs": args.timeout * 1000,
        "outputPath": str(OUTPUT_DIR / "webit-test-report.json"),
    }

    payload_path = OUTPUT_DIR / "harness-input.json"
    payload_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")

    env = dict(os.environ)
    env["PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD"] = "1"
    env["NODE_PATH"] = str(HARNESS_DIR / "node_modules")

    started = time.time()
    completed = subprocess.run(
        ["node", str(ROOT / "project-tests" / "harness" / "run-webkit-tests.js"), str(payload_path)],
        cwd=ROOT, env=env, capture_output=True, text=True, encoding="utf-8", errors="replace")
    elapsed = time.time() - started

    print(completed.stdout)
    if completed.stderr.strip():
        print(completed.stderr, file=sys.stderr)

    report_path = OUTPUT_DIR / "webit-test-report.json"
    if not report_path.exists():
        print("[harness] 未生成报告，说明 harness 自身失败。", file=sys.stderr)
        return 2

    report = json.loads(report_path.read_text(encoding="utf-8"))
    report["harnessElapsedSeconds"] = round(elapsed, 2)
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")

    passed = sum(1 for fixture in report["fixtures"] if fixture["passed"])
    total = len(report["fixtures"])
    print(f"[harness] 夹具通过 {passed}/{total}（引擎: {report['browserName']}，用时 {elapsed:.1f}s）")
    print(f"[harness] 报告: {report_path.relative_to(ROOT)}")

    if args.keep_open:
        print("[harness] --keep-open 已指定，但服务器随 harness 退出而关闭；如需手动调试请直接运行 node 脚本。")

    return 0 if passed == total else 1


if __name__ == "__main__":
    raise SystemExit(main())
