/*
 * run-webkit-tests.js — the browser-driving half of the test harness.
 *
 * Reads a JSON job description (paths + assertions), serves each fixture over a
 * loopback HTTP server, loads it in a real browser engine, evaluates the assertions
 * inside the page and writes a JSON report.
 *
 * It is launched by `project-tests/run_tests.py`; running it directly is supported
 * for debugging:
 *
 *     node project-tests/harness/run-webkit-tests.js test-output/harness-input.json
 *
 * No network access is required and no browser is downloaded: the script drives a
 * browser that is already installed on the machine, and fails loudly if there is
 * none rather than silently skipping the tests.
 */

'use strict';

const fs = require('fs');
const path = require('path');

const payloadPath = process.argv[2];
if (!payloadPath) {
  console.error('usage: node run-webkit-tests.js <payload.json>');
  process.exit(2);
}

const payload = JSON.parse(fs.readFileSync(payloadPath, 'utf8'));
const { startStaticServer } = require(path.join(__dirname, '..', 'lib', 'static-server.js'));

function loadPlaywright() {
  const candidates = [
    path.join(__dirname, '..', '..', 'tools', 'harness', 'node_modules', 'playwright-core'),
    'playwright-core',
    'playwright'
  ];
  for (const candidate of candidates) {
    try {
      return require(candidate);
    } catch (error) {
      /* try the next candidate */
    }
  }
  return null;
}

async function evaluateCheck(page, check) {
  try {
    const value = await page.evaluate(check.script);
    return { label: check.label, passed: value === true, actual: value };
  } catch (error) {
    return { label: check.label, passed: false, actual: null, error: String(error && error.message ? error.message : error) };
  }
}

async function runFixture(browser, fixture, timeoutMs) {
  const result = {
    id: fixture.id,
    title: fixture.title,
    url: null,
    loaded: false,
    passed: false,
    checks: [],
    consoleMessages: [],
    pageErrors: [],
    requestFailures: [],
    durationMs: 0,
    error: null
  };

  const started = Date.now();
  // The server root is the whole fixtures directory so the URL keeps its
  // `<fixture-id>/index.html` shape. Serving the fixture directory itself would
  // double the id in the resolved path and 404 every request.
  const server = await startStaticServer(
    fixture.serveRoot || path.dirname(fixture.dir),
    0,
    fixture.mounts || []);
  let context = null;

  try {
    context = await browser.newContext({
      viewport: { width: 1180, height: 820 },
      deviceScaleFactor: 2,
      hasTouch: true,
      isMobile: false
    });
    const page = await context.newPage();

    page.on('console', (message) => {
      result.consoleMessages.push({ type: message.type(), text: message.text().slice(0, 500) });
    });
    page.on('pageerror', (error) => {
      result.pageErrors.push(String(error && error.message ? error.message : error).slice(0, 500));
    });
    page.on('requestfailed', (request) => {
      const failure = request.failure();
      result.requestFailures.push({
        url: request.url().replace(server.url, '/'),
        error: failure ? failure.errorText : 'unknown'
      });
    });

    result.url = `${server.url}${fixture.id}/index.html`;
    const response = await page.goto(result.url, { waitUntil: 'load', timeout: timeoutMs });
    result.httpStatus = response ? response.status() : null;
    result.loaded = result.httpStatus === 200;

    // A fixture that did not return 200 cannot be evaluated meaningfully. Failing
    // fast here avoids spending the whole settle budget on an empty document — the
    // first version of this harness wasted 45s per fixture on a path bug.
    if (!result.loaded) {
      result.error = `夹具页面返回 HTTP ${result.httpStatus}，未执行任何断言`;
      for (const check of fixture.checks) {
        result.checks.push({ label: check.label, passed: false, actual: null, error: result.error });
      }
      return result;
    }

    // Fixtures run multi-stage asynchronous work (module graphs, texture staging,
    // fetch sweeps). Poll until the observable markers stop changing. The cap only
    // has to exceed one marker change (~400 ms) plus a stall; it is NOT a timeout for
    // the fixture's own work, because a fixture with no marker at all would otherwise
    // burn the whole budget for nothing.
    const settleDeadline = Date.now() + Math.min(timeoutMs, 6000);
    let previousSignature = '';
    let stableCount = 0;
    while (Date.now() < settleDeadline) {
      const signature = await page.evaluate(() => {
        const markers = ['__FIXTURE_03__', '__FIXTURE_04__', '__FIXTURE_05__', '__FIXTURE_08__', '__FIXTURE_10__'];
        const parts = [];
        for (const marker of markers) {
          const value = window[marker];
          if (value === undefined) continue;
          if (typeof value.frames === 'number') parts.push(`${marker}:frames=${value.frames}`);
          else if (Array.isArray(value.checks)) parts.push(`${marker}:checks=${value.checks.length}`);
          else if (Array.isArray(value.cases)) parts.push(`${marker}:cases=${value.cases.length}`);
          else if (Array.isArray(value.stages)) parts.push(`${marker}:stages=${value.stages.length}`);
          else parts.push(`${marker}:${JSON.stringify(value).length}`);
        }
        return parts.join('|');
      }).catch(() => '');

      if (signature && signature === previousSignature) {
        stableCount += 1;
        if (stableCount >= 2) break;
      } else {
        stableCount = 0;
      }
      previousSignature = signature;
      await page.waitForTimeout(400);
    }

    for (const check of fixture.checks) {
      result.checks.push(await evaluateCheck(page, check));
    }

    // Optional fixture diagnostics: values a fixture exposes to explain a failure.
    // Without this, a broken probe shows up only as "false" with no reason.
    if (fixture.diagnostics) {
      result.diagnostics = {};
      for (const [key, script] of Object.entries(fixture.diagnostics)) {
        result.diagnostics[key] = await page.evaluate(script).catch((error) => `evaluate failed: ${error.message}`);
      }
    }

    // Give the frame counter a final moment so the "≥ 20 frames" check is meaningful.
    await page.waitForTimeout(300);
    for (const check of fixture.checks) {
      if (result.checks.find((item) => item.label === check.label)?.passed === false
          && /帧/.test(check.label)) {
        const retry = await evaluateCheck(page, check);
        const index = result.checks.findIndex((item) => item.label === check.label);
        result.checks[index] = retry;
      }
    }

    result.passed = result.checks.length > 0 && result.checks.every((check) => check.passed);
  } catch (error) {
    result.error = String(error && error.message ? error.message : error);
  } finally {
    if (context) await context.close().catch(() => {});
    if (!payload.keepOpen) await server.close().catch(() => {});
    result.durationMs = Date.now() - started;
  }

  return result;
}

async function main() {
  const playwright = loadPlaywright();
  const report = {
    generatedAt: new Date().toISOString(),
    browserName: payload.browserName,
    browserVersion: null,
    executablePath: payload.executablePath,
    harness: 'project-tests/harness/run-webkit-tests.js',
    disclaimer: [
      '本报告由 Playwright 驱动的桌面 WebKit 引擎生成，不是 WKWebView，也不是 iPad 真机。',
      '它验证的是「夹具与 WebKit 引擎是否一致」，不能替代真机验证。',
      'iOS 沙箱、jetsam 内存上限、loadFileURL 的 file:// 策略、WebContent 进程终止都无法在此复现。'
    ],
    fixtures: []
  };

  if (!playwright) {
    report.fatal = 'playwright-core 未安装';
    fs.writeFileSync(payload.outputPath, JSON.stringify(report, null, 2));
    console.error('[harness] playwright-core 未找到。');
    process.exit(2);
  }

  const launchOptions = { headless: true };
  if (payload.executablePath) launchOptions.executablePath = payload.executablePath;

  let browser;
  try {
    browser = await playwright[payload.browserName || 'webkit'].launch(launchOptions);
  } catch (error) {
    report.fatal = `浏览器启动失败: ${error.message}`;
    fs.writeFileSync(payload.outputPath, JSON.stringify(report, null, 2));
    console.error(`[harness] 浏览器启动失败: ${error.message}`);
    process.exit(2);
  }

  report.browserVersion = browser.version();

  for (const fixture of payload.fixtures) {
    process.stdout.write(`[harness] ${fixture.id} … `);
    const result = await runFixture(browser, fixture, payload.timeoutMs || 45000);
    report.fixtures.push(result);
    const failed = result.checks.filter((check) => !check.passed);
    console.log(result.passed
      ? `通过（${result.durationMs}ms）`
      : `失败：${result.error || failed.map((check) => check.label).join('; ')}`);
    for (const check of failed) {
      console.log(`           ✘ ${check.label} → ${JSON.stringify(check.actual)}${check.error ? ' ' + check.error : ''}`);
    }
    if (result.pageErrors.length) {
      console.log(`           pageerror: ${result.pageErrors[0]}`);
    }
  }

  await browser.close();
  fs.writeFileSync(payload.outputPath, JSON.stringify(report, null, 2));
  const failedCount = report.fixtures.filter((fixture) => !fixture.passed).length;
  process.exit(failedCount === 0 ? 0 : 1);
}

main().catch((error) => {
  console.error('[harness] 未捕获错误:', error);
  process.exit(2);
});
