#version 300 es
// 该文件同时被 04-fetch（文本读取）与 07-glsl（编译）测试使用。
precision highp float;

in vec3 aPosition;
uniform mat4 uModelViewProjection;

void main() {
  gl_Position = uModelViewProjection * vec4(aPosition, 1.0);
}
