// 二级模块：验证「模块再导入模块」的相对路径解析。
import { VERSION, multiply } from './math.js';

export class Scene {
  constructor(name) {
    this.name = name;
    this.objects = [];
  }

  add(object) {
    this.objects.push(object);
    return this;
  }

  describe() {
    return `${this.name}（模块版本 ${VERSION}，对象 ${this.objects.length} 个，3×4=${multiply(3, 4)}）`;
  }
}

export default Scene;
