// 一个普通的 ES module，被 index.html 与 scene.js 分别导入。
export const VERSION = '1.2.3';

export function add(a, b) {
  return a + b;
}

export function multiply(a, b) {
  return a * b;
}

export default { VERSION, add, multiply };
