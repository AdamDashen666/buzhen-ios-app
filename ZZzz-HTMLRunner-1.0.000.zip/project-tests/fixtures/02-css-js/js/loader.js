// 外部脚本：只要它被加载，全局标记就会变成 true。
window.FIXTURE_LOADER_LOADED = true;
