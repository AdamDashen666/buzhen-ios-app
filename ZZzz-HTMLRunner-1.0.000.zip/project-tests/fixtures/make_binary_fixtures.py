#!/usr/bin/env python3
"""Regenerate every fixture file that cannot survive a ZIP round-trip.

Two categories live here:

1. Binary fixtures (a 256 KiB blob) — regenerated so they need not be committed as
   opaque data.
2. **Non-ASCII named fixtures** — Chinese directory and file names used by the
   `04-fetch` and `10-structure-and-encoding` cases.

Why non-ASCII names are generated rather than shipped in the source ZIP
-----------------------------------------------------------------------
The source ZIP is handed to a third-party CI workflow that extracts it with
macOS's `/usr/bin/unzip` (Info-ZIP). Info-ZIP ignores the ZIP general-purpose
"UTF-8 filename" flag (bit 11) unless built with `UNICODE_SUPPORT`, so a name like
`中文 文件名.json` is decoded as latin-1 and collapses to `+` characters. The
extraction then fails with exit code 50 and aborts the build before `xcodebuild`
even runs. That failure was observed for real (GitHub run #140).

Python's `zipfile` writes those names correctly, so the archive was never wrong —
but the consumer cannot read it. Every deliverable ZIP is therefore ASCII-only, and
these fixtures are recreated locally by this script. `tools/package_zip.py`
enforces the ASCII rule and refuses to ship a name that would break the consumer.

Run:  python project-tests/fixtures/make_binary_fixtures.py
"""
from __future__ import annotations

import pathlib

FIXTURES = pathlib.Path(__file__).resolve().parent

# The PNG body used by the encoding fixture (1x1 opaque).
PNG_BYTES = bytes.fromhex(
    "89504e470d0a1a0a0000000d4948445200000001000000010806000000"
    "1f15c4890000000d4944415478da63f8cf00000301010018dd8db00000000049454e44ae426082"
)

# path -> UTF-8 text content. Paths intentionally contain Chinese characters and
# spaces so the import path/encoding behaviour is exercised.
NON_ASCII_TEXT_FILES = {
    "04-fetch/data/中文 文件名.json": (
        "{\n"
        '  "描述": "这个文件的文件名包含中文与一个空格，用于验证 URL 百分号编码是否正确。",\n'
        '  "编码测试": "UTF-8 中文内容 ✓",\n'
        '  "路径": "data/中文 文件名.json"\n'
        "}\n"
    ),
    "10-structure-and-encoding/资源/说明.txt": (
        "中文目录名与中文文件名。\n"
        "这一行是 UTF-8 中文内容，用来确认编码没有被破坏。\n"
    ),
    "10-structure-and-encoding/a/b/c/d/e/深层文件.txt": (
        "这个文件位于 a/b/c/d/e/，用于验证深层层级被完整保留。\n"
    ),
    "10-structure-and-encoding/资源/纹理/贴图#1.png.bak": (
        "扩展名为 .bak，避免被当成真实图片；重点是文件名里的 # 需要被编码为 %23。\n"
    ),
    "10-structure-and-encoding/资源/音频/背景 音乐 01.mp3.bak": (
        "文件名含空格；同样以 .bak 结尾，不假装它是真实音频。\n"
    ),
}

NON_ASCII_BINARY_FILES = {
    "10-structure-and-encoding/资源/纹理/砖墙-漫反射.png": PNG_BYTES,
}


def main() -> int:
    # ---- 1. binary blob for the fetch() tests ---------------------------------
    size = 256 * 1024
    payload = bytes(((index * 31 + 7) & 0xFF) for index in range(size))
    binary_path = FIXTURES / "04-fetch" / "data" / "binary.bin"
    binary_path.parent.mkdir(parents=True, exist_ok=True)
    binary_path.write_bytes(payload)
    print(f"[fixtures] {binary_path.relative_to(FIXTURES.parent.parent)} ({len(payload)} bytes)")

    # ---- 2. non-ASCII named fixtures -----------------------------------------
    created = 0
    for relative, content in NON_ASCII_TEXT_FILES.items():
        path = FIXTURES / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8", newline="\n")
        created += 1
    for relative, blob in NON_ASCII_BINARY_FILES.items():
        path = FIXTURES / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(blob)
        created += 1
    print(f"[fixtures] 重建了 {created} 个非 ASCII 命名的夹具文件"
          "（刻意不放进交付 ZIP：macOS 的 Info-ZIP unzip 会破坏这些文件名）")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

