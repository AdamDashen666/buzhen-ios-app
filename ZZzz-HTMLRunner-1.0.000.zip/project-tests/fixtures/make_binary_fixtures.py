#!/usr/bin/env python3
"""Create the binary fixtures that cannot be committed as readable text.

Run:  python project-tests/fixtures/make_binary_fixtures.py
"""
from __future__ import annotations

import pathlib

FIXTURES = pathlib.Path(__file__).resolve().parent


def main() -> int:
    # 256 KiB of deterministic pseudo-random bytes for the fetch() tests. The content
    # is irrelevant; what matters is that it is unambiguously binary and large enough
    # that a broken streaming path would be visible.
    size = 256 * 1024
    payload = bytes(((index * 31 + 7) & 0xFF) for index in range(size))
    binary_path = FIXTURES / "04-fetch" / "data" / "binary.bin"
    binary_path.parent.mkdir(parents=True, exist_ok=True)
    binary_path.write_bytes(payload)
    print(f"[fixtures] wrote {binary_path.relative_to(FIXTURES.parent.parent)} ({len(payload)} bytes)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
