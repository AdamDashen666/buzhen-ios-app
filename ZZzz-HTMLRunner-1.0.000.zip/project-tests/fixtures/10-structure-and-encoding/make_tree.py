#!/usr/bin/env python3
"""Build the `10-structure-and-encoding` fixture tree.

This fixture exists to prove that importing a project preserves:
  * nested directory structure (a/b/c/d/e)
  * Chinese directory and file names
  * spaces inside file names
  * upper-case extensions
  * the `#` character, which must survive URL percent-encoding as %23
  * zero-byte files
  * a UTF-8 BOM in a text file

It deliberately does NOT create `CASE.txt` and `case.txt` as two files: APFS on
iPadOS is case-insensitive by default, so such a pair cannot exist on the target
device. The README explains that limitation instead of shipping an untestable case.

Run:  python project-tests/fixtures/10-structure-and-encoding/make_tree.py
"""
from __future__ import annotations

import pathlib

FIXTURE_ROOT = pathlib.Path(__file__).resolve().parent

TEXT_FILES = {
    "Assets/SHADER.VERT": "#version 300 es\n// 大写扩展名的着色器文件\nin vec3 position;\nvoid main() { gl_Position = vec4(position, 1.0); }\n",
    "a/b/c/d/e/深层文件.txt": "这个文件位于 a/b/c/d/e/，用于验证深层层级被完整保留。\n",
    "CASE.txt": "大写文件名的内容。APFS 大小写不敏感，所以同名不同大小写的文件无法共存。\n",
    "empty.file": "",
    "资源/说明.txt": "中文目录名与中文文件名。\n这一行是 UTF-8 中文内容，用来确认编码没有被破坏。\n",
    "资源/纹理/贴图#1.png.bak": "扩展名为 .bak，避免被当成真实图片；重点是文件名里的 # 需要被编码为 %23。\n",
    "资源/音频/背景 音乐 01.mp3.bak": "文件名含空格；同样以 .bak 结尾，不假装它是真实音频。\n",
}

# Two real PNGs so the page can actually load an image through a Chinese path and
# through an upper-case extension.
PNG_BYTES = bytes.fromhex(
    "89504e470d0a1a0a0000000d4948445200000001000000010806000000"
    "1f15c4890000000d4944415478da63f8cf00000301010018dd8db00000000049454e44ae426082"
)


def main() -> int:
    created: list[str] = []

    for relative, content in TEXT_FILES.items():
        path = FIXTURE_ROOT / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8", newline="\n")
        created.append(relative)

    for relative in ("资源/纹理/砖墙-漫反射.png", "Assets/TEXTURE.PNG"):
        path = FIXTURE_ROOT / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(PNG_BYTES)
        created.append(relative)

    # A UTF-8 BOM file: the import must not strip or corrupt the BOM.
    bom_path = FIXTURE_ROOT / "bom.txt"
    bom_path.write_bytes(b"\xef\xbb\xbf" + "带 BOM 的文本文件。\n".encode("utf-8"))
    created.append("bom.txt")

    for relative in created:
        print(f"[fixture] {relative}")
    print(f"[fixture] wrote {len(created)} files under {FIXTURE_ROOT}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
