#version 300 es
// 简单的漫反射 + 边缘光，用来确认片元着色器真的在跑（不同角度亮度不同）。
precision highp float;

in vec3 vNormal;
in vec3 vWorld;

uniform vec3 lightDirection;
uniform float time;

out vec4 fragColor;

void main() {
  vec3 n = normalize(vNormal);
  float diffuse = max(dot(n, normalize(lightDirection)), 0.0);
  float rim = pow(1.0 - max(dot(n, vec3(0.0, 0.0, 1.0)), 0.0), 2.0);
  vec3 base = vec3(0.25, 0.55, 0.95);
  vec3 color = base * (0.25 + 0.75 * diffuse) + vec3(0.55, 0.8, 1.0) * rim * 0.6;
  color += 0.06 * sin(time + vWorld.x * 4.0);
  fragColor = vec4(color, 1.0);
}
