#version 300 es
// 逐顶点变换 + 法线/世界坐标传递。由 index.html 通过 fetch 读取，
// 用于同时验证「外部着色器文件相对路径加载」与「GLSL 300 es 编译链接」。
in vec3 position;
in vec3 normal;

uniform mat4 modelViewProjection;
uniform mat4 model;

out vec3 vNormal;
out vec3 vWorld;

void main() {
  vNormal = mat3(model) * normal;
  vWorld = vec3(model * vec4(position, 1.0));
  gl_Position = modelViewProjection * vec4(position, 1.0);
}
