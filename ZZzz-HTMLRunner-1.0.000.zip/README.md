# HTMLRunner

一个为 **iPad** 设计的高性能 HTML / WebGL 游戏运行器。用 Swift + SwiftUI + 系统 WebKit（WKWebView）实现，
把本地 HTML 项目导入到 App 内部，然后以接近原生的方式全屏运行，并提供面向「白屏 / 崩溃 / 卡顿」的诊断能力。

> **交付状态请先看 [`DELIVERY-REPORT.md`](DELIVERY-REPORT.md)。**
> 当前环境是 Windows，没有 Xcode 与 iOS SDK，**因此本次没有生成 IPA**。
> 源码、工程、测试与构建脚本已完成并经过可执行的验证；IPA 需要在 macOS 上按 [`BUILD.md`](BUILD.md) 生成。
> 任何声称「已构建 / 已在真机测试 / JIT 已验证」的说法都必须能在该报告里找到依据——目前这三项都是**否**。

---

## 这个 App 解决什么问题

你的现状是：a-Shell 起本地服务器 → Safari 打开 → 白屏、自动刷新、进程退出，而且看不出原因。

HTMLRunner 不试图「让网页跑得更快」，它试图让**失败变得可见、让加载变得可控**：

| 问题 | 本项目的做法 |
|---|---|
| 白屏但不知道原因 | 记录导航开始/提交/完成/失败、WebKit 错误域与错误码、页面自述的 `readyState`；未捕获异常、Promise 拒绝、资源加载失败、WebGL 上下文创建失败都会带时间戳进日志 |
| 相对路径资源加载不了 | 导入时**流式复制整个项目目录**到 App 沙箱（保留目录结构与文件名），运行时用 `loadFileURL(_:allowingReadAccessTo: 项目根目录)`，而不是只授权入口文件 |
| `file://` 下 ES Modules / `fetch` 被同源策略拦截 | 提供**可选**的只监听 `127.0.0.1` 的本地 HTTP 服务，用正常的 HTTP 语义加载项目 |
| 网页进程被杀、状态丢失 | 捕获 `webContentProcessDidTerminate`，记录当时的 App 内存采样、热状态与距上次事件的时间，并提供明确的「重新加载（状态会丢失）」入口——不假装能恢复 |
| 想调优却只能瞎猜 | 「探测」按钮在真实页面里跑一次能力与性能测量：WebGL2 限制、扩展、GLSL 编译链接、纹理分阶段分配、numeric 吞吐；并把「能力事实」和「间接证据」分开呈现 |
| 想给 App 开 JIT 以求提速 | 明确告诉你：这件事对 WKWebView 里的网页 JS **没有作用**，原理与证据见 [`JIT_NOTES.md`](HTMLRunner/JIT_NOTES.md) |

### 三条贯穿全局的诚实原则

1. **不把「测出来的数字」说成「确定的结论」。** 性能基准受热降频、后台限速、缓存状态影响，页面上也没有任何公开 API 能查询 JavaScriptCore 是否以 JIT 模式运行。UI 里凡是无法确定的项，都显示「无法直接确认」，而不是显示 0 或猜测值。
2. **不为了「能跑」而关闭系统安全机制。** 没有 `allowUniversalAccessFromFileURLs`，没有私有 WebKit SPI，没有伪造的 entitlement，日志里也不会编造系统没有提供的数据。
3. **不假装拥有不存在的能力。** 没有「一键释放 WebKit 内存」按钮（iOS 不提供该接口），不承诺网页进程不被系统回收，也不声称比 Safari 拥有更大的内存配额。

---

## 安装（在 iPad 上）

本仓库不包含预编译的 IPA（原因见交付报告）。有两条路径：

### A. 自己构建（需要一个 macOS + Xcode）

```bash
bash mac/build.sh              # 产出未签名的 dist/HTMLRunner.ipa
bash mac/build.sh --signed     # 需要 DEVELOPMENT_TEAM，产出已签名开发版
```

细节、排错与导出选项见 [`BUILD.md`](BUILD.md)。

### B. 用第三方签名工具安装

拿到 `dist/HTMLRunner.ipa` 后，用你惯用的侧载工具（NB 助手等）签名并安装。

关于这类工具要说明三点，避免误解：

* 未签名的 IPA **不能**直接安装，必须经过签名工具重签，这是预期流程。
* 重签会改写 `_CodeSignature` 与 `embedded.mobileprovision`，最终的能力由**实际签名方式与系统**决定，不由本仓库决定。
* 若签名方式带 `get-task-allow`（个人 Apple ID / 开发证书），App 通常会出现在这类工具的「JIT 待开启」列表里——但这只表示 **App 进程**可被附加调试器，**不会**给 WKWebView 的网页内容进程任何额外权限。完整原理见 [`HTMLRunner/JIT_NOTES.md`](HTMLRunner/JIT_NOTES.md)。

---

## 使用方法

### 1. 导入项目

首页有两个入口：

* **导入整个项目文件夹**（推荐）——完整复制目录结构与文件名。
* **导入单个 HTML 文件**——连同同目录下的资源文件一起复制（不含子目录），并在项目详情里说明这一点。

导入是**分批流式复制**的：可以看进度、随时取消；失败或取消时会清理未完成的目录，不会留下半个「看起来能用」的项目。
项目会被复制到 App 沙箱的 `Documents/Projects/<项目名>/`，之后不再依赖文件选择器的临时授权。

App 开启了「文件」App 共享，因此也可以在 **Files → 我的 iPad → HTMLRunner** 中直接查看或投放项目。

### 2. 运行

点项目的「运行」。默认以 `file://` 加载（不占端口、不启服务）；若在设置里打开「本地 HTTP 服务」，则改用 `http://127.0.0.1:<随机端口>/`。

运行界面是**沉浸式全屏**：点屏幕任意位置呼出轻量工具栏，工具栏是浮层而不是布局的一部分，因此显示/隐藏不会改变画布尺寸、不会触发页面重新布局。

工具栏：返回项目列表 · 刷新 · 停止 · 重新打开 · 探测 · 日志 · 诊断 · 设置 · 隐藏。

### 3. 遇到白屏时按这个顺序排查

1. **看日志**（工具栏 →「日志」）。重点看 `navigation.fail` 的 `domain`/`code`：`WebKitErrorDomain 102` 是「被策略取消」，属预期；其它错误码才是真问题。
2. **看入口文件**是否选对（项目详情 →「选择入口文件」）。导入时 App 会优先选 `index.html`，其次是最浅层的 HTML；如果你项目的入口叫别的名字，在这里改。
3. **看是否有 ES Modules / `fetch` 相关报错**。`file://` 下这类请求会因同源策略被拒——这是 WebKit 的既定行为，不是本 App 的缺陷。打开「设置 → 本地服务」，重新运行即可。
4. **点「探测」**。如果 `webgl2` 不可用或 GLSL 编译失败，问题在页面/驱动层，与加载路径无关。
5. **诊断页**里可以看 App 进程内存走势、WebContent 终止次数、本地服务状态，并导出完整报告。

### 4. 设置项

| 设置 | 作用 | 代价 / 注意 |
|---|---|---|
| 默认加载方式 | `file://` 或本地 HTTP 服务 | 本地服务多一个进程内服务实现；`file://` 受同源限制 |
| 外部链接策略 | 用 Safari 打开 / 阻止 / 应用内打开 | 默认转交 Safari，避免离开项目后丢失 WebGL 上下文 |
| 音频播放策略 | 允许自动播放 / 需要用户手势 | 游戏通常在加载时就播音频，故默认允许 |
| 诊断桥 | 注入只负责上报错误的脚本 | 关闭后页面内**零**注入；桥不改写渲染、计时器、模块加载 |
| 性能悬浮面板 | 页面右上角小面板（FPS / JS 堆） | 默认关闭，点击面板即可隐藏 |
| 日志级别 | 调试 / 信息 / 注意 / 警告 / 错误 | 日志有上限（4000 条 + 3 MiB），超出后丢弃最早的记录 |
| Web Inspector | 设置 `isInspectable` | **只对 Debug 构建 + 连接的 Mac 有效**；侧载的 Release 版本无法附加 |

---

## 项目结构

```
HTMLRunner.xcodeproj/           Xcode 工程（由 tools/generate_project.py 生成，可重现）
HTMLRunner/                     App 源码与资源（Xcode 16 同步组，新增文件自动纳入编译）
├── App/                        入口与组合根
│   ├── HTMLRunnerApp.swift
│   └── AppState.swift          对象装配、运行流程、诊断报告生成
├── Views/                      SwiftUI 界面
│   ├── RootView.swift          NavigationSplitView，iPad 横屏优先
│   ├── ProjectListView.swift   项目列表 / 导入 / 重命名 / 删除 / 入口文件选择
│   ├── RunView.swift           沉浸式运行界面与可呼出工具栏
│   ├── DiagnosticsView.swift   运行时事实 / JIT 诊断 / 探测 / 内存 / 导出
│   ├── LogViewerView.swift     日志过滤、搜索、复制、导出
│   └── SettingsView.swift      设置、缓存清理、版本信息
├── Web/                        WebKit 层
│   ├── WebViewFactory.swift    唯一的 WKWebView 创建点（每处非默认配置都有理由）
│   ├── WebViewCoordinator.swift 导航/UI delegate、失败分类、终止处理、探测调用
│   ├── LocalHTTPServer.swift   可选的 127.0.0.1 服务（含路径安全与 Range 支持）
│   └── ProbeResult.swift       探测结果的可选字段建模（「无法获取」≠ 0）
├── FileManagement/
│   ├── Project.swift           项目模型
│   ├── ProjectStore.swift      流式导入、分批复制、进度、取消、库持久化
│   └── DocumentImporters.swift 文件/文件夹选择器（asCopy: false）
├── Diagnostics/
│   ├── Log.swift               有界日志（内存 + 磁盘双上限）
│   ├── AppInfo.swift           构建与设备事实（读不到就返回 nil）
│   ├── AppMemory.swift         task_vm_info / 主机内存采样
│   └── ProcessDebugState.swift P_TRACED 检测（只描述 App 进程）
├── Settings/
│   ├── RunConfiguration.swift  单次运行的配置（会被完整记入日志）
│   └── AppSettings.swift       持久化设置
├── Resources/
│   ├── Info.plist  Entitlements/  Assets.xcassets/
│   └── Web/                    ★ 会打包进 App 的两个脚本
│       ├── DiagnosticBridge.js 页面侧错误上报（可关闭）
│       └── WebProbe.js         性能与能力探测（按需注入）
└── JIT_NOTES.md                ★ 会打包进 App，供「诊断 → JIT 说明」直接阅读

mac/                            macOS 上的构建与打包（本机无法执行）
├── build.sh  verify_ipa.sh  ExportOptions-*.plist  README.md  ci-github-actions.yml

tools/                          可在任何平台运行的校验与生成工具
├── generate_project.py         生成 Xcode 工程（不含 DEVELOPMENT_TEAM）
├── verify_project.py           独立校验工程结构与资源（90 项检查）
├── verify_pbxproj.py           复核 pbxproj：配置一致性、无提交签名信息、与生成器输出一致
├── verify_dist.py              校验 dist/ 的 ZIP、清单与 SHA-256（交付物自检）
├── check_swift.py              Swift 结构检查（括号/指令/字符串/重复与未用声明）
├── make_icon.py                生成 1024² App 图标
├── sync_doc_counts.py          让文档里的文件数/行数与实际代码保持一致
├── summarize_report.py         打印 TEST-REPORT.json 的摘要
└── patch_annotations.py        一次性源码注解调整（已应用，保留作记录）

project-tests/                  测试
├── run_all.py                  跑全部检查并生成 TEST-REPORT.json
├── run_tests.py                在桌面 WebKit 中运行 HTML 夹具
├── harness/                    Node 侧驱动与纯逻辑测试
├── lib/static-server.js        测试用静态服务器（对照 Swift 服务实现）
└── fixtures/                   01–11 号测试夹具 + index.json
```

**唯一事实来源**：Xcode 工程由脚本生成；图标由脚本生成；测试夹具清单在 `project-tests/fixtures/index.json`；
测试计划状态在 `test-output/TEST-REPORT.json`（由 `project-tests/run_all.py` 重新生成）。

---

## 在非 macOS 上能运行哪些验证

```bash
python tools/check_swift.py            # Swift 结构检查
python tools/verify_project.py         # Xcode 工程结构与资源校验（90 项）
python tools/verify_pbxproj.py         # 工程配置一致性（含「未被手工改过」）
node   project-tests/harness/logic.test.js   # 52 项纯逻辑测试
python project-tests/run_tests.py      # 在桌面 WebKit 中跑 12 个 HTML 夹具

python project-tests/run_all.py        # 上面全部，并生成 TEST-REPORT.json
python tools/package_zip.py            # 打包 dist/（ZIP + 清单 + SHA-256）
python tools/verify_dist.py            # 校验刚打好的交付物
```

这些检查**不能替代**在 macOS 上构建与在 iPad 上运行。它们能发现的是：工程图错误、资源缺失、
括号/字符串结构错误、重命名后遗漏的调用点、导入与 HTTP 解析的算法错误、以及夹具与 WebKit 引擎的行为差异。
详见 [`docs/TEST-PLAN.md`](docs/TEST-PLAN.md)。

---

## 边界与已知限制

* **iOS 不向第三方 App 提供 WebContent 进程的内存数据**，也无法主动释放 WebKit 的内存。App 只能读取自己的进程内存。
* **无法保证网页进程不被回收。** iOS 按系统策略决定，App 能做的是记录事件、给出诊断、提供重新加载。
* **诊断桥会改写 `console.*` 与 `HTMLCanvasElement.prototype.getContext`**（仅包装，用于上报错误与 WebGL 创建失败）。这两处是唯一对页面的改动，且可在设置里整体关闭。
* **`file://` 下 ES Modules 与 `fetch` 通常不可用**，这是 WebKit 的同源策略，不是缺陷。需要时请用本地服务模式。
* **APFS 默认大小写不敏感**，因此 `Texture.png` 与 `texture.png` 无法在 iPad 上共存；导入时 App 会记入日志。
* **本地服务只监听回环地址**，局域网其他设备无法访问；它只暴露当前项目的根目录，并拒绝 `../` 与符号链接逃逸。

## 许可与来源

代码为本项目原创。关于 JIT 的结论引用了 WebKit、PojavLauncher、SideStore / StikDebug 的公开源码与文档，
每个结论在 [`JIT_NOTES.md`](HTMLRunner/JIT_NOTES.md) 中都附有 URL 与原文引用，并区分「已验证 / 推断 / 无法直接确认」。
