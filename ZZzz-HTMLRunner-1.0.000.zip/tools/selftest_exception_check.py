#!/usr/bin/env python3
"""Negative test: prove `tools/verify_pbxproj.py` detects the "Multiple commands
produce" bug class it was written for.

The bug is caused by a file living inside a synchronized group while also being
managed by a build setting (`INFOPLIST_FILE` / `CODE_SIGN_ENTITLEMENTS`), with no
`membershipExceptions` entry. This script removes the exclusion, regenerates the
project, asserts the verifier fails with the expected message, then restores
everything.

Run:  python tools/selftest_exception_check.py
"""
from __future__ import annotations

import pathlib
import shutil
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
GENERATOR = ROOT / "tools" / "generate_project.py"
BACKUP = ROOT / "tools" / ".generate_project.py.bak"

EXCLUSION_BLOCK = '''    "Resources": [
        "Info.plist",
        "Entitlements/HTMLRunner.entitlements",
    ],'''


def run(command: list[str]) -> subprocess.CompletedProcess:
    return subprocess.run(command, cwd=ROOT, capture_output=True, text=True,
                          encoding="utf-8", errors="replace")


def main() -> int:
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except (AttributeError, ValueError):
            pass

    original = GENERATOR.read_text(encoding="utf-8")
    if EXCLUSION_BLOCK not in original:
        print("[selftest] 找不到预期的排除代码块，生成器可能已被改动", file=sys.stderr)
        return 2

    shutil.copy2(GENERATOR, BACKUP)
    try:
        broken = original.replace(EXCLUSION_BLOCK, '    "Resources": [],')
        GENERATOR.write_text(broken, encoding="utf-8", newline="\n")
        run([sys.executable, "tools/generate_project.py"])

        result = run([sys.executable, "tools/verify_pbxproj.py"])
        output = result.stdout + result.stderr
        caught = "Multiple commands produce" in output and result.returncode != 0
        print(f"[selftest] 去掉排除后 verify_pbxproj exit={result.returncode} "
              f"检测到问题={caught}")
        if not caught:
            print("[selftest] 失败：检查没有发现这个缺陷", file=sys.stderr)
            print(output[-1500:], file=sys.stderr)
            return 1
        for line in output.splitlines():
            if "Multiple commands produce" in line:
                print(f"[selftest]   {line.strip()[:160]}")
    finally:
        shutil.copy2(BACKUP, GENERATOR)
        BACKUP.unlink()
        run([sys.executable, "tools/generate_project.py"])

    restored = run([sys.executable, "tools/verify_pbxproj.py"])
    print(f"[selftest] 恢复后 verify_pbxproj exit={restored.returncode}")
    if restored.returncode != 0:
        print("[selftest] 失败：恢复后校验仍未通过", file=sys.stderr)
        return 1
    print("[selftest] 通过：缺陷可被检测，且已正确恢复")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
