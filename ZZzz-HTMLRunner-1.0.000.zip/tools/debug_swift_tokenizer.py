#!/usr/bin/env python3
"""Debug helper: show exactly where the Swift tokenizer loses its place.

Not part of the delivery pipeline; kept because diagnosing a lexer by reading
mojibake console output on a non-UTF-8 Windows console wasted real time.

Run:  python tools/debug_swift_tokenizer.py HTMLRunner/Diagnostics/AppMemory.swift
"""
from __future__ import annotations

import pathlib
import sys

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import check_swift as cs  # noqa: E402

ROOT = pathlib.Path(__file__).resolve().parent.parent


def main() -> int:
    target = sys.argv[1] if len(sys.argv) > 1 else "HTMLRunner/Diagnostics/AppMemory.swift"
    path = ROOT / target
    text = path.read_text(encoding="utf-8")

    problems: list[cs.Problem] = []
    tokens = cs.tokenize(path, text, problems)

    lines = text.split("\n")
    report: list[str] = []
    report.append(f"file: {target}")
    report.append(f"lines: {len(lines)}  tokens: {len(tokens)}  tokenizer problems: {len(problems)}")
    for problem in problems[:10]:
        report.append(f"  tokenizer: line {problem.line}: {problem.message}")

    # Bracket walk, recording the first mismatch with surrounding source.
    stack: list[tuple[str, int]] = []
    for kind, value, line in tokens:
        if kind != "bracket":
            continue
        if value in cs.OPENERS:
            stack.append((value, line))
            continue
        if not stack:
            report.append(f"  stray closer '{value}' at line {line}")
            break
        opener, opener_line = stack.pop()
        if cs.MATCHING[opener] != value:
            report.append(f"  MISMATCH: '{opener}' opened at line {opener_line} closed by '{value}' at line {line}")
            for offset in range(max(0, opener_line - 3), min(len(lines), line + 2)):
                report.append(f"    {offset + 1:4}| {lines[offset]}")
            break
    else:
        if stack:
            report.append(f"  unclosed openers remaining: {stack[:5]}")
        else:
            report.append("  brackets balanced")

    output = pathlib.Path("test-output") / "swift-tokenizer-debug.txt"
    output.parent.mkdir(exist_ok=True)
    output.write_text("\n".join(report) + "\n", encoding="utf-8")
    print(f"wrote {output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
