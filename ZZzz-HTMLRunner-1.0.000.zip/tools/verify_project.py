#!/usr/bin/env python3
"""Independently verify the generated Xcode project.

This is the closest thing to "it would build" that a non-macOS environment can
produce. It is NOT a compiler and does not claim to be: it validates the project
*graph* and the *plumbing* that most often breaks a build, so that the first
`xcodebuild` on a Mac fails for real reasons rather than typos.

Checks performed
----------------
 1. `project.pbxproj` parses as an OpenStep plist (the same grammar Xcode uses).
 2. Every object id referenced exists; no dangling references.
 3. Every `isa` value is a known Xcode object type.
 4. The scheme XML is well-formed and its `BlueprintIdentifier` matches the target.
 5. `rootObject` resolves to the PBXProject.
 6. Each synchronized group's directory exists on disk and contains at least the
    files we expect, so nothing is silently left out of the target.
 7. Every `.swift` file under the app source folders is inside a synchronized
    group (i.e. it will actually be compiled).
 8. `Info.plist` and the entitlements plist parse, and the keys an iPad app needs
    are present and plausible.
 9. The asset catalog contains an AppIcon set with a 1024x1024 PNG that exists,
    is square, and is opaque (iOS rejects icons with alpha).
10. The JavaScript resources the Swift code loads by name are present.
11. No Swift file declares the same top-level type twice (a common copy-paste
    failure that a compiler catches but a reviewer often misses).
12. Path separators, file encodings and CRLF usage are consistent (CRLF in a
    pbxproj or a .js resource is a real, easy-to-miss portability problem).

Exit code 0 means "no problems found", 1 means at least one error.
Warnings never affect the exit code unless `--strict` is passed.

Run:  python tools/verify_project.py [--strict]
"""
from __future__ import annotations

import argparse
import pathlib
import plistlib
import re
import sys
import xml.etree.ElementTree as ET

ROOT = pathlib.Path(__file__).resolve().parent.parent
PROJECT_NAME = "HTMLRunner"

KNOWN_ISA = {
    "PBXBuildFile",
    "PBXFileReference",
    "PBXFileSystemSynchronizedRootGroup",
    "PBXFileSystemSynchronizedBuildFileExceptionSet",
    "PBXFrameworksBuildPhase",
    "PBXGroup",
    "PBXNativeTarget",
    "PBXProject",
    "PBXResourcesBuildPhase",
    "PBXSourcesBuildPhase",
    "XCBuildConfiguration",
    "XCConfigurationList",
}

# Folders that must be part of the app target (synchronized groups in the pbxproj).
EXPECTED_SYNC_GROUPS = ["App", "Views", "Web", "FileManagement", "Diagnostics", "Settings", "Resources"]

# Resources loaded at runtime by name from the bundle.
EXPECTED_BUNDLED_JS = ["DiagnosticBridge.js", "WebProbe.js"]

OBJECT_DECL_RE = re.compile(r"^\t\t([0-9A-F]{24})\b(?: /\* (.*?) \*/)? = \{", re.MULTILINE)


class Report:
    def __init__(self) -> None:
        self.errors: list[str] = []
        self.warnings: list[str] = []
        self.notes: list[str] = []
        self.checks = 0

    def check(self, condition: bool, message: str) -> bool:
        self.checks += 1
        if not condition:
            self.errors.append(message)
        return condition

    def warn_if(self, condition: bool, message: str) -> None:
        if not condition:
            self.warnings.append(message)

    def note(self, message: str) -> None:
        self.notes.append(message)


def parse_openstep_plist(text: str) -> dict:
    """Parse an OpenStep/NeXTSTEP plist into nested dicts.

    `plistlib` only understands XML and binary plists, so this is a small, strict
    reader for the subset Xcode emits. Being strict matters: a lenient reader that
    guesses would hide exactly the syntax errors this tool exists to find.
    """
    index = 0
    length = len(text)

    def skip_ws() -> None:
        nonlocal index
        while index < length:
            char = text[index]
            if char in " \t\r\n":
                index += 1
            elif text.startswith("/*", index):
                end = text.find("*/", index + 2)
                index = length if end == -1 else end + 2
            elif text.startswith("//", index):
                end = text.find("\n", index)
                index = length if end == -1 else end + 1
            else:
                return

    def parse_string() -> str:
        nonlocal index
        if text[index] == '"':
            index += 1
            out: list[str] = []
            while index < length:
                char = text[index]
                if char == "\\":
                    out.append(text[index + 1])
                    index += 2
                    continue
                if char == '"':
                    index += 1
                    return "".join(out)
                out.append(char)
                index += 1
            raise ValueError("unterminated string")
        start = index
        while index < length and (text[index].isalnum() or text[index] in "_$./-<>"):
            index += 1
        if start == index:
            raise ValueError(f"unexpected character {text[index]!r} at {index}")
        return text[start:index]

    def parse_value():
        skip_ws()
        if index >= length:
            raise ValueError("unexpected end of input")
        char = text[index]
        if char == "{":
            return parse_dict()
        if char == "(":
            return parse_array()
        return parse_string()

    def parse_dict() -> dict:
        nonlocal index
        index += 1  # consume '{'
        result: dict = {}
        while True:
            skip_ws()
            if index >= length:
                raise ValueError("unterminated dict")
            if text[index] == "}":
                index += 1
                return result
            key = parse_string()
            skip_ws()
            if index >= length or text[index] != "=":
                raise ValueError(f"expected '=' after key {key!r} at {index}")
            index += 1
            result[key] = parse_value()
            skip_ws()
            if index < length and text[index] == ";":
                index += 1

    def parse_array() -> list:
        nonlocal index
        index += 1  # consume '('
        result: list = []
        while True:
            skip_ws()
            if index >= length:
                raise ValueError("unterminated array")
            if text[index] == ")":
                index += 1
                return result
            result.append(parse_value())
            skip_ws()
            if index < length and text[index] == ",":
                index += 1

    value = parse_value()
    skip_ws()
    if index != length:
        raise ValueError(f"trailing content after root object at {index}")
    return value


def collect_ids(node, ids: set[str]) -> None:
    if isinstance(node, dict):
        for key, value in node.items():
            if re.fullmatch(r"[0-9A-F]{24}", key):
                ids.add(key)
            collect_ids(value, ids)
    elif isinstance(node, list):
        for item in node:
            collect_ids(item, ids)


def collect_refs(node, refs: set[str]) -> None:
    if isinstance(node, dict):
        for value in node.values():
            collect_refs(value, refs)
    elif isinstance(node, list):
        for item in node:
            collect_refs(item, refs)
    elif isinstance(node, str):
        if re.fullmatch(r"[0-9A-F]{24}", node):
            refs.add(node)


def main() -> int:
    parser = argparse.ArgumentParser(description="Verify the HTMLRunner Xcode project")
    parser.add_argument("--strict", action="store_true", help="treat warnings as failures")
    parser.add_argument("--quiet", action="store_true", help="only print problems")
    args = parser.parse_args()

    report = Report()

    # ---------------------------------------------------------------- pbxproj --
    pbx_path = ROOT / f"{PROJECT_NAME}.xcodeproj" / "project.pbxproj"
    if not report.check(pbx_path.exists(), f"缺少 {pbx_path.relative_to(ROOT)}（先运行 tools/generate_project.py）"):
        return finish(report, args)

    raw_bytes = pbx_path.read_bytes()
    report.check(b"\r\n" not in raw_bytes, "project.pbxproj 含 CRLF 换行，Xcode 期望 LF")
    text = raw_bytes.decode("utf-8")
    report.check(text.startswith("// !$*UTF8*$!"), "project.pbxproj 缺少 UTF-8 头注释")

    try:
        root = parse_openstep_plist(text)
        report.check(True, "")
        report.checks -= 1
    except ValueError as error:
        report.check(False, f"project.pbxproj 解析失败: {error}")
        return finish(report, args)

    objects = root.get("objects")
    report.check(isinstance(objects, dict) and bool(objects), "project.pbxproj 缺少 objects 字典")
    if not isinstance(objects, dict):
        return finish(report, args)

    # Object ids declared in the objects dict must match the ids used in the file.
    declared_ids = set(objects.keys())
    inline_ids = set(OBJECT_DECL_RE.findall(text))
    inline_ids = {value[0] for value in inline_ids}
    report.check(declared_ids == inline_ids,
                 f"objects 字典与文件中声明的对象 id 不一致: 差集={sorted(declared_ids ^ inline_ids)[:5]}")
    report.check(len(declared_ids) == len(objects), "存在重复的对象 id")

    known = {value for value in declared_ids if re.fullmatch(r"[0-9A-F]{24}", value)}
    refs: set[str] = set()
    collect_refs(objects, refs)
    dangling = refs - known
    report.check(not dangling, f"存在悬空引用（引用了不存在的对象）: {sorted(dangling)[:5]}")

    isas: dict[str, int] = {}
    for object_id, body in objects.items():
        if not isinstance(body, dict):
            report.check(False, f"对象 {object_id} 不是字典")
            continue
        isa = body.get("isa")
        if not isinstance(isa, str):
            report.check(False, f"对象 {object_id} 缺少 isa")
            continue
        isas[isa] = isas.get(isa, 0) + 1
        report.check(isa in KNOWN_ISA, f"对象 {object_id} 的 isa 未知: {isa}")

    report.check("PBXProject" in isas, "缺少 PBXProject 对象")
    report.check("PBXNativeTarget" in isas, "缺少 PBXNativeTarget 对象")
    report.note(f"对象统计: {', '.join(f'{k}×{v}' for k, v in sorted(isas.items()))}")

    root_object = root.get("rootObject")
    report.check(isinstance(root_object, str) and root_object in objects, "rootObject 未指向有效对象")
    if isinstance(root_object, str) and root_object in objects:
        report.check(objects[root_object].get("isa") == "PBXProject", "rootObject 指向的不是 PBXProject")

    # ------------------------------------------------------ synchronized groups --
    sync_groups = [body for body in objects.values()
                   if isinstance(body, dict) and body.get("isa") == "PBXFileSystemSynchronizedRootGroup"]
    sync_paths = {body.get("path") for body in sync_groups}
    for folder in EXPECTED_SYNC_GROUPS:
        report.check(folder in sync_paths, f"缺少同步组 {folder}（该目录下的文件不会被编译/打包）")
        directory = ROOT / PROJECT_NAME / folder
        report.check(directory.is_dir(), f"同步组目录不存在: {PROJECT_NAME}/{folder}")

    target = next((body for body in objects.values()
                   if isinstance(body, dict) and body.get("isa") == "PBXNativeTarget"), None)
    report.check(target is not None, "找不到 native target")
    if target:
        report.check(target.get("productType") == "com.apple.product-type.application",
                     "target 的 productType 不是 iOS 应用")
        phases = target.get("buildPhases") or []
        report.check(isinstance(phases, list) and len(phases) == 3,
                     f"target 的 buildPhases 数量异常: {len(phases) if isinstance(phases, list) else 'n/a'}")
        group_refs = target.get("fileSystemSynchronizedGroups") or []
        report.check(len(group_refs) == len(EXPECTED_SYNC_GROUPS),
                     f"target 引用的同步组数量为 {len(group_refs)}，期望 {len(EXPECTED_SYNC_GROUPS)}")

    # ----------------------------------------------------------- swift coverage --
    app_root = ROOT / PROJECT_NAME
    swift_files: list[pathlib.Path] = []
    for folder in EXPECTED_SYNC_GROUPS:
        swift_files.extend(sorted((app_root / folder).rglob("*.swift")))
    report.check(bool(swift_files), "在 App target 目录下没有找到任何 .swift 文件")
    report.note(f"Swift 源文件 {len(swift_files)} 个，均位于同步组内，会被编译")

    # Non-ASCII / CRLF / BOM hygiene, and a duplicate-declaration guard.
    declarations: dict[str, list[str]] = {}
    for path in swift_files:
        data = path.read_bytes()
        relative = path.relative_to(ROOT).as_posix()
        report.warn_if(b"\r\n" not in data, f"{relative} 使用 CRLF 换行（Swift 可编译，但会污染 diff）")
        report.warn_if(not data.startswith(b"\xef\xbb\xbf"), f"{relative} 含 UTF-8 BOM")
        content = data.decode("utf-8")
        for match in re.finditer(r"^(?:final |public |private |internal |@MainActor\s+)*(?:class|struct|enum|protocol|actor)\s+([A-Za-z_][A-Za-z0-9_]*)", content, re.MULTILINE):
            declarations.setdefault(match.group(1), []).append(relative)
    duplicates = {name: files for name, files in declarations.items() if len(files) > 1}
    report.check(not duplicates, f"重复的类型声明（会导致编译失败）: {duplicates}")

    # ------------------------------------------------------------- scheme match --
    scheme_path = ROOT / f"{PROJECT_NAME}.xcodeproj" / "xcshareddata" / "xcschemes" / f"{PROJECT_NAME}.xcscheme"
    if report.check(scheme_path.exists(), f"缺少共享 scheme: {scheme_path.relative_to(ROOT)}"):
        try:
            tree = ET.parse(scheme_path)
            identifiers = [element.get("BlueprintIdentifier") for element in tree.iter("BuildableReference")]
            report.check(all(value in known for value in identifiers),
                         f"scheme 的 BlueprintIdentifier 与 target 不匹配: {identifiers}")
            names = {element.get("BlueprintName") for element in tree.iter("BuildableReference")}
            report.check(names == {PROJECT_NAME}, f"scheme BlueprintName 异常: {names}")
        except ET.ParseError as error:
            report.check(False, f"scheme XML 解析失败: {error}")

    # ---------------------------------------------------------------- plist files --
    info_path = app_root / "Resources" / "Info.plist"
    if report.check(info_path.exists(), "缺少 Info.plist"):
        try:
            info = plistlib.loads(info_path.read_bytes())
            for key in ("CFBundleIdentifier", "CFBundleShortVersionString", "CFBundleVersion",
                        "CFBundleExecutable", "UIDeviceFamily", "UISupportedInterfaceOrientations~ipad"):
                report.check(key in info, f"Info.plist 缺少必需键: {key}")
            report.check(info.get("UIDeviceFamily") == [2], f"UIDeviceFamily 应为 [2]（仅 iPad），实际 {info.get('UIDeviceFamily')}")
            families = info.get("UISupportedInterfaceOrientations~ipad") or []
            report.check("UIInterfaceOrientationLandscapeLeft" in families
                         and "UIInterfaceOrientationLandscapeRight" in families,
                         "Info.plist 未声明横屏方向")
            report.check(info.get("UIRequiresFullScreen") is True,
                         "UIRequiresFullScreen 未开启：分屏下 WebGL 画布尺寸不可控")
            report.check("NSAppTransportSecurity" not in info,
                         "Info.plist 出现 NSAppTransportSecurity：本地回环服务不需要放宽 ATS")
        except Exception as error:  # noqa: BLE001 - report and continue
            report.check(False, f"Info.plist 解析失败: {error}")

    entitlements_path = app_root / "Resources" / "Entitlements" / f"{PROJECT_NAME}.entitlements"
    if report.check(entitlements_path.exists(), "缺少 entitlements 文件"):
        try:
            entitlements = plistlib.loads(entitlements_path.read_bytes())
            report.check(set(entitlements.keys()) == {"get-task-allow"},
                         f"entitlements 只应包含 get-task-allow，实际: {sorted(entitlements.keys())}")
            report.check(entitlements.get("get-task-allow") is True, "get-task-allow 不为 true")
            for forbidden in ("com.apple.security.cs.allow-jit", "dynamic-codesigning",
                              "com.apple.private.cs.debugger", "task_for_pid-allow"):
                report.check(forbidden not in entitlements,
                             f"entitlements 含未经验证的特权键 {forbidden}（会导致安装失败或被拒）")
        except Exception as error:  # noqa: BLE001
            report.check(False, f"entitlements 解析失败: {error}")

    # ------------------------------------------------------------- asset catalog --
    catalog = app_root / "Resources" / "Assets.xcassets"
    appicon_contents = catalog / "AppIcon.appiconset" / "Contents.json"
    if report.check(appicon_contents.exists(), "缺少 AppIcon.appiconset/Contents.json"):
        import json
        try:
            contents = json.loads(appicon_contents.read_text(encoding="utf-8"))
            images = contents.get("images") or []
            report.check(bool(images), "AppIcon Contents.json 没有 image 条目")
            for entry in images:
                filename = entry.get("filename")
                if not filename:
                    continue
                icon = catalog / "AppIcon.appiconset" / filename
                if not report.check(icon.exists(), f"AppIcon 引用的文件不存在: {filename}"):
                    continue
                try:
                    from PIL import Image
                    with Image.open(icon) as image:
                        report.check(image.size == (1024, 1024),
                                     f"AppIcon 尺寸应为 1024x1024，实际 {image.size}")
                        report.check(image.mode in ("RGB", "P"),
                                     f"AppIcon 必须不含 alpha 通道（iOS 会拒绝），实际模式 {image.mode}")
                except ImportError:
                    report.warn_if(False, "未安装 Pillow，跳过了 AppIcon 图像校验")
        except Exception as error:  # noqa: BLE001
            report.check(False, f"AppIcon Contents.json 解析失败: {error}")

    # ------------------------------------------------------------- web resources --
    web_dir = app_root / "Resources" / "Web"
    for name in EXPECTED_BUNDLED_JS:
        path = web_dir / name
        if report.check(path.exists(), f"缺少打包资源 {name}（Swift 通过 Bundle 按名称加载它）"):
            data = path.read_bytes()
            report.check(b"\r\n" not in data, f"{name} 含 CRLF 换行")
            report.check(len(data) > 200, f"{name} 内容过短，可能是占位文件")
            report.check(b"htmlrunnerDiag" in data or name == "WebProbe.js",
                         f"{name} 未引用 WKScriptMessageHandler 名称 htmlrunnerDiag")

    # Handler name must be identical on both sides of the bridge.
    factory = app_root / "Web" / "WebViewFactory.swift"
    if factory.exists():
        report.check('diagnosticsHandlerName = "htmlrunnerDiag"' in factory.read_text(encoding="utf-8"),
                     "WebViewFactory 中的 handler 名称与 DiagnosticBridge.js 不一致")

    return finish(report, args)


def finish(report: Report, args: argparse.Namespace) -> int:
    if not args.quiet:
        for note in report.notes:
            print(f"[verify] {note}")
    for warning in report.warnings:
        print(f"[verify][warn] {warning}")
    for error in report.errors:
        print(f"[verify][ERROR] {error}")

    print(f"[verify] 检查项 {report.checks} 个，错误 {len(report.errors)} 个，警告 {len(report.warnings)} 个")
    if report.errors:
        print("[verify] 结果: 失败")
        return 1
    if args.strict and report.warnings:
        print("[verify] 结果: 失败（strict 模式把警告视为错误）")
        return 1
    print("[verify] 结果: 通过（注意：这不是编译，只验证工程结构与资源）")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
