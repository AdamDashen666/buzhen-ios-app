#!/usr/bin/env python3
"""Package the deliverable: source ZIP + SHA-256 checksums + a file manifest.

Design rules learned the hard way:

  * Never package a build artefact by accident. `build/`, `DerivedData/`,
    `.xcarchive/`, `.ipa` and `node_modules/` are excluded — shipping a stale or
    partial build tree is worse than shipping none.
  * Never package an empty file and call it a deliverable. Every file is checked to
    be non-empty, and a `.ipa` is *only* included if a real one exists (this
    repository has none: it cannot be built without macOS/Xcode).
  * The manifest records size + SHA-256 for every entry, so a consumer can verify
    what they received without trusting this script's word for it.
  * The ZIP is written with forward-slash entry names and no `__MACOSX`-style
    metadata, so it extracts identically on macOS, Windows and Linux.

Run:  python tools/package_zip.py [--no-zip]
"""
from __future__ import annotations

import argparse
import hashlib
import json
import pathlib
import sys
import zipfile

ROOT = pathlib.Path(__file__).resolve().parent.parent
DIST = ROOT / "dist"
VERSION = "1.0.0"

# Files that are part of the source deliverable. Any directory listed here is
# walked recursively.
INCLUDE_DIRS = [
    "HTMLRunner",
    "HTMLRunner.xcodeproj",
    "mac",
    "tools",
    "project-tests",
    "docs",
]
INCLUDE_FILES = [
    "README.md",
    "BUILD.md",
    "CHANGELOG.md",
    "DELIVERY-REPORT.md",
    "agent.md",
    ".gitignore",
]

# Anything matching these is never packaged, wherever it appears.
EXCLUDE_PARTS = {
    "node_modules", ".git", "build", "DerivedData", ".xcarchive", "__pycache__",
    ".pytest_cache", ".venv", "venv", "dist",
}
EXCLUDE_SUFFIXES = {".pyc", ".pyo", ".bak", ".orig", ".log", ".tmp"}
EXCLUDE_NAMES = {".DS_Store", "Thumbs.db", "harness-input.json"}

# Test output that is genuinely useful to the reader is added explicitly, even
# though the directory as a whole is excluded.
EXTRA_FILES = [
    "test-output/TEST-REPORT.json",
]


def sha256(path: pathlib.Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def should_include(path: pathlib.Path, allow_non_ascii: bool = False) -> bool:
    relative = path.relative_to(ROOT)
    if any(part in EXCLUDE_PARTS for part in relative.parts):
        return False
    if path.name in EXCLUDE_NAMES:
        return False
    if path.suffix.lower() in EXCLUDE_SUFFIXES:
        return False
    if not path.is_file():
        return False
    # Non-ASCII archive member names break the CI consumer: macOS's Info-ZIP `unzip`
    # ignores the UTF-8 filename flag and fails the whole extraction with exit 50.
    # Those fixture files are regenerated locally instead (see
    # project-tests/fixtures/make_binary_fixtures.py).
    if not allow_non_ascii:
        try:
            relative.as_posix().encode("ascii")
        except UnicodeEncodeError:
            return False
    # Empty files are legitimate in one case only: the encoding fixture deliberately
    # contains a zero-byte file to prove that zero-byte files survive import.
    if path.stat().st_size == 0 and path.name != "empty.file":
        return False
    return True


def collect(allow_non_ascii: bool = False) -> tuple[list[pathlib.Path], list[str]]:
    files: list[pathlib.Path] = []
    skipped_non_ascii: list[str] = []
    for directory in INCLUDE_DIRS:
        base = ROOT / directory
        if not base.is_dir():
            print(f"[package][warn] 目录不存在，已跳过: {directory}", file=sys.stderr)
            continue
        for path in sorted(base.rglob("*")):
            if should_include(path, allow_non_ascii):
                files.append(path)
            elif path.is_file() and any(ord(ch) > 127 for ch in path.relative_to(ROOT).as_posix()):
                skipped_non_ascii.append(path.relative_to(ROOT).as_posix())
    for name in INCLUDE_FILES:
        path = ROOT / name
        if path.is_file() and should_include(path, allow_non_ascii):
            files.append(path)
        else:
            print(f"[package][warn] 缺少文件（不是致命错误）: {name}", file=sys.stderr)
    for name in EXTRA_FILES:
        path = ROOT / name
        if path.is_file() and path.stat().st_size > 0:
            files.append(path)
    return sorted(set(files)), sorted(skipped_non_ascii)


# Files with non-ASCII names that must never end up in a deliverable ZIP, listed so
# the exclusion is verified rather than assumed.
KNOWN_NON_ASCII_FIXTURES = {
    "project-tests/fixtures/04-fetch/data/中文 文件名.json",
    "project-tests/fixtures/10-structure-and-encoding/资源/说明.txt",
    "project-tests/fixtures/10-structure-and-encoding/资源/纹理/砖墙-漫反射.png",
    "project-tests/fixtures/10-structure-and-encoding/资源/纹理/贴图#1.png.bak",
    "project-tests/fixtures/10-structure-and-encoding/资源/音频/背景 音乐 01.mp3.bak",
    "project-tests/fixtures/10-structure-and-encoding/a/b/c/d/e/深层文件.txt",
}


def main() -> int:
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except (AttributeError, ValueError):
            pass

    parser = argparse.ArgumentParser(description="打包交付物")
    parser.add_argument("--no-zip", action="store_true", help="只生成清单与校验和")
    parser.add_argument("--include-non-ascii", action="store_true",
                        help="保留非 ASCII 文件名（仅在本地使用时；会让 macOS 的 unzip 解压失败）")
    args = parser.parse_args()

    DIST.mkdir(exist_ok=True)
    files, skipped_non_ascii = collect(args.include_non_ascii)
    if skipped_non_ascii:
        print(f"[package] 已排除 {len(skipped_non_ascii)} 个非 ASCII 文件名条目"
              "（macOS 的 Info-ZIP unzip 会因此解压失败，如 GitHub run #140）:")
        for name in skipped_non_ascii:
            print(f"[package]   - {name}")
    # Verify the rule rather than trusting the filter: any non-ASCII name that slips
    # through would break the CI consumer, and that failure mode is silent locally.
    leaked = [path.relative_to(ROOT).as_posix() for path in files
              if any(ord(ch) > 127 for ch in path.relative_to(ROOT).as_posix())]
    if leaked:
        print(f"[package][ERROR] 归档仍包含非 ASCII 文件名: {leaked[:5]}", file=sys.stderr)
        return 4
    if not args.include_non_ascii and KNOWN_NON_ASCII_FIXTURES - set(skipped_non_ascii):
        missing = sorted(KNOWN_NON_ASCII_FIXTURES - set(skipped_non_ascii))
        print(f"[package][warn] 预期的非 ASCII 夹具未出现在本地工作区: {missing}", file=sys.stderr)

    # A real IPA may or may not exist depending on whether a macOS toolchain (or a
    # GitHub macOS runner) produced one. The manifest states which case it is, and
    # `tools/verify_dist.py` cross-checks that claim against the filesystem — an
    # empty or absent IPA must never be reported as a successful build.
    ipa_path = DIST / "HTMLRunner.ipa"
    has_ipa = ipa_path.is_file() and ipa_path.stat().st_size > 0
    build_run = DIST / "GITHUB-BUILD-RUN.json"
    build_info = None
    if has_ipa and build_run.exists():
        try:
            build_info = json.loads(build_run.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            build_info = None

    # ------------------------------------------------------------------ manifest --
    manifest = {
        "name": "HTMLRunner",
        "version": VERSION,
        "description": "iPadOS HTML/WebGL 游戏运行器（SwiftUI + WKWebView）",
        "generatedAt": __import__("datetime").datetime.now().astimezone().isoformat(),
        "buildableHere": False,
        "buildableHereReason": "本机是 Windows，没有 macOS 与 Xcode，无法在本地编译 iOS 应用。",
        "containsIPA": has_ipa,
        "containsIPAReason": (
            f"dist/HTMLRunner.ipa 由 GitHub Actions 的 macOS runner 构建（run "
            f"{build_info.get('runNumber') if build_info else '?'}）；"
            "未签名，供侧载工具重签。"
            if has_ipa else
            "未生成 IPA：本地无 macOS/Xcode。可用 tools/build_via_github.py 在 GitHub 的 "
            "macOS runner 上构建，或按 BUILD.md 在 Mac 上执行 mac/build.sh。"
        ),
        "ipa": ({
            "path": "dist/HTMLRunner.ipa",
            "bytes": ipa_path.stat().st_size,
            "sha256": sha256(ipa_path),
            "signed": False,
            "builtBy": "GitHub Actions macOS runner",
            "runUrl": build_info.get("runUrl") if build_info else None,
            "sourceZip": build_info.get("sourceZip") if build_info else None,
        } if has_ipa else None),
        "entryCount": len(files),
        "totalBytes": sum(path.stat().st_size for path in files),
        "files": [
            {
                "path": path.relative_to(ROOT).as_posix(),
                "bytes": path.stat().st_size,
                "sha256": sha256(path),
            }
            for path in files
        ],
    }
    manifest_path = DIST / "HTMLRunner-FILE-MANIFEST.json"
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"[package] 清单: {manifest_path.relative_to(ROOT)}（{len(files)} 个文件，"
          f"{manifest['totalBytes'] / 1024 / 1024:.2f} MiB）")
    print(f"[package] containsIPA={has_ipa}" + (f" ({ipa_path.stat().st_size} 字节)" if has_ipa else ""))

    # ----------------------------------------------------------------------- zip --
    zip_path = DIST / f"HTMLRunner-source-{VERSION}.zip"
    if not args.no_zip:
        if zip_path.exists():
            zip_path.unlink()
        with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
            for path in files:
                archive.write(path, arcname=path.relative_to(ROOT).as_posix())
            # The file list is also stored inside the archive so a reader can verify
            # the contents without the sidecar file.
            archive.writestr("HTMLRunner-FILE-MANIFEST.json",
                             manifest_path.read_text(encoding="utf-8"))
        size = zip_path.stat().st_size
        print(f"[package] ZIP : {zip_path.relative_to(ROOT)}（{size / 1024 / 1024:.2f} MiB）")

    # ---------------------------------------------------------------- checksums --
    sums_path = DIST / "SHA256SUMS.txt"
    lines: list[str] = []
    lines.append("# HTMLRunner 交付物 SHA-256")
    lines.append(f"# 生成时间: {manifest['generatedAt']}")
    lines.append("# 校验方式: shasum -a 256 -c dist/SHA256SUMS.txt   （在仓库根目录执行）")
    lines.append("#")
    lines.append("# 说明: 本仓库没有 IPA —— 未生成 dist/HTMLRunner.ipa，因为没有 macOS 与 Xcode。")
    lines.append("#       不存在被注释掉的占位条目，也不存在空文件冒充产物。")
    lines.append("")
    for artifact in sorted(DIST.glob("*.zip")) + sorted(DIST.glob("*.ipa")) + [manifest_path]:
        if not artifact.is_file() or artifact.stat().st_size == 0:
            continue
        lines.append(f"{sha256(artifact)}  {artifact.relative_to(ROOT).as_posix()}")
    sums_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"[package] 校验和: {sums_path.relative_to(ROOT)}")
    for line in lines:
        if line and not line.startswith("#"):
            print(f"          {line}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
