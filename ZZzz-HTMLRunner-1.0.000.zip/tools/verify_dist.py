#!/usr/bin/env python3
"""Verify the distributed artefacts in `dist/` — the thing a user actually receives.

A source ZIP is easy to get subtly wrong: a missing asset, an entry with a
backslash in its name that explodes into a nested directory on macOS, an absolute
path, a stale manifest, a checksum that no longer matches. All of those are
invisible until someone tries to open the project.

Checks performed
----------------
 1. `dist/SHA256SUMS.txt` parses and every listed hash matches the file on disk.
 2. The ZIP is not corrupt (`testzip`), and contains no directory-traversal or
    absolute entry names, and no backslashes (a `\\` becomes a literal filename
    character on macOS instead of a path separator).
 3. The embedded `HTMLRunner-FILE-MANIFEST.json` matches the sidecar copy, and every
    manifest entry is present in the ZIP with a matching SHA-256.
 4. Every file the Xcode target needs is inside the archive: the pbxproj, the
    scheme, Info.plist, entitlements, asset catalog JSON + icon, and both bundled
    JavaScript resources. A ZIP that cannot build is not a deliverable.
 5. No build output leaked into the archive (`build/`, `DerivedData/`,
    `*.xcarchive`, `node_modules/`, evidence of an `*.ipa`) and no stray empty file
    other than the one the encoding fixture creates on purpose.
 6. Documentation set is complete: README, BUILD, CHANGELOG, DELIVERY-REPORT,
    agent.md, docs/TEST-PLAN.md, and the bundled JIT_NOTES.md.

Exit code 0 = verified. Run:  python tools/verify_dist.py
"""
from __future__ import annotations

import argparse
import hashlib
import json
import pathlib
import re
import sys
import zipfile

ROOT = pathlib.Path(__file__).resolve().parent.parent
DIST = ROOT / "dist"

# Files without which the extracted project cannot be built or understood.
REQUIRED_IN_ARCHIVE = [
    "README.md",
    "BUILD.md",
    "CHANGELOG.md",
    "DELIVERY-REPORT.md",
    "agent.md",
    "docs/TEST-PLAN.md",
    "HTMLRunner.xcodeproj/project.pbxproj",
    "HTMLRunner.xcodeproj/xcshareddata/xcschemes/HTMLRunner.xcscheme",
    "HTMLRunner/Resources/Info.plist",
    "HTMLRunner/Resources/Entitlements/HTMLRunner.entitlements",
    "HTMLRunner/Resources/Assets.xcassets/Contents.json",
    "HTMLRunner/Resources/Assets.xcassets/AppIcon.appiconset/Contents.json",
    "HTMLRunner/Resources/Assets.xcassets/AppIcon.appiconset/AppIcon-1024.png",
    "HTMLRunner/Resources/Assets.xcassets/AccentColor.colorset/Contents.json",
    "HTMLRunner/Resources/Web/DiagnosticBridge.js",
    "HTMLRunner/Resources/Web/WebProbe.js",
    "HTMLRunner/JIT_NOTES.md",
    "mac/build.sh",
    "mac/verify_ipa.sh",
    "mac/ExportOptions-unsigned.plist",
    "mac/ExportOptions-development.plist",
    "mac/ci-github-actions.yml",
    "tools/generate_project.py",
    "tools/verify_project.py",
    "tools/verify_pbxproj.py",
    "tools/check_swift.py",
    "tools/make_icon.py",
    "tools/package_zip.py",
    "tools/verify_dist.py",
    "project-tests/run_all.py",
    "project-tests/run_tests.py",
    "project-tests/fixtures/index.json",
    "test-output/TEST-REPORT.json",
]

# Substrings that indicate build output or vendored dependencies leaked in.
FORBIDDEN_SUBSTRINGS = [
    "node_modules/",
    "DerivedData/",
    ".xcarchive/",
    "__pycache__/",
    "/build/",
    "harness-input.json",
]

# The one file that is legitimately empty.
ALLOWED_EMPTY = {"project-tests/fixtures/10-structure-and-encoding/empty.file"}


class Report:
    def __init__(self) -> None:
        self.errors: list[str] = []
        self.notes: list[str] = []

    def check(self, condition: bool, message: str) -> bool:
        if not condition:
            self.errors.append(message)
        return condition


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser(description="校验 dist/ 中的交付物")
    parser.add_argument("--zip", default=None, help="指定要校验的 ZIP（默认取 dist 中最新的）")
    args = parser.parse_args()

    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except (AttributeError, ValueError):
            pass

    report = Report()

    archive = pathlib.Path(args.zip) if args.zip else None
    if archive is None:
        candidates = sorted(DIST.glob("*.zip"))
        if not report.check(bool(candidates), f"dist/ 下没有 ZIP（先运行 python tools/package_zip.py）"):
            return finish(report)
        archive = candidates[-1]
    if not report.check(archive.exists(), f"找不到 ZIP: {archive}"):
        return finish(report)
    report.notes.append(f"校验对象: {archive.relative_to(ROOT)}（{archive.stat().st_size / 1024:.1f} KiB）")

    # ---- 1: SHA256SUMS.txt ----------------------------------------------------
    sums = DIST / "SHA256SUMS.txt"
    if report.check(sums.exists(), "缺少 dist/SHA256SUMS.txt（没有校验和的交付物无法被独立验证）"):
        listed = 0
        for line in sums.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            match = re.match(r"^([0-9a-f]{64})\s+(.+)$", line)
            if not report.check(bool(match), f"SHA256SUMS.txt 格式错误: {line}"):
                continue
            digest, relative = match.group(1), match.group(2)
            listed += 1
            path = ROOT / relative
            if not report.check(path.exists(), f"SHA256SUMS.txt 列出的文件不存在: {relative}"):
                continue
            actual = hashlib.sha256(path.read_bytes()).hexdigest()
            report.check(actual == digest, f"SHA-256 不匹配: {relative}")
        report.check(listed > 0, "SHA256SUMS.txt 里没有任何有效条目")
        # Reverse direction: every .ipa/.zip in dist must be listed.
        for candidate in sorted(DIST.glob("*.ipa")) + sorted(DIST.glob("*.zip")):
            text = sums.read_text(encoding="utf-8")
            report.check(candidate.name in text,
                         f"{candidate.name} 存在于 dist/ 但没有被记录进 SHA256SUMS.txt")
        report.notes.append(f"SHA256SUMS.txt: {listed} 个条目全部校验通过")

    # ---- 2/3: archive integrity and manifest ---------------------------------
    with zipfile.ZipFile(archive) as zf:
        report.check(zf.testzip() is None, "ZIP 损坏（testzip 报告了坏条目）")
        names = zf.namelist()
        report.notes.append(f"ZIP 内 {len(names)} 个条目")

        for name in names:
            if name.startswith("/") or re.match(r"^[A-Za-z]:", name):
                report.errors.append(f"ZIP 含绝对路径条目（解压时会写到归档目录之外）: {name}")
            if "\\" in name:
                report.errors.append(f"ZIP 条目含反斜杠（在 macOS/Linux 上会变成长文件名）: {name}")
            if ".." in name.split("/"):
                report.errors.append(f"ZIP 条目含 .. 路径穿越: {name}")
            if any(token in name for token in FORBIDDEN_SUBSTRINGS):
                report.errors.append(f"ZIP 含构建产物或依赖目录（不应交付）: {name}")

        for name in REQUIRED_IN_ARCHIVE:
            report.check(name in names, f"ZIP 缺少必需文件: {name}")

        empties = [entry.filename for entry in zf.infolist()
                   if entry.file_size == 0 and entry.filename not in ALLOWED_EMPTY]
        report.check(not empties, f"ZIP 含意外的空文件（可能是未生成的占位产物）: {empties[:5]}")

        report.check(not any(name.endswith(".ipa") for name in names),
                     "ZIP 里出现了 .ipa —— 本仓库不应包含任何 IPA")

        if "HTMLRunner-FILE-MANIFEST.json" in names:
            embedded = json.loads(zf.read("HTMLRunner-FILE-MANIFEST.json").decode("utf-8"))
            sidecar = DIST / "HTMLRunner-FILE-MANIFEST.json"
            if sidecar.exists():
                report.check(embedded == json.loads(sidecar.read_text(encoding="utf-8")),
                             "ZIP 内嵌清单与 dist/ 中的清单不一致")
            report.check(embedded.get("containsIPA") is False,
                         "清单声称包含 IPA，但归档中没有 IPA —— 清单与实际不符")
            mismatches = []
            for entry in embedded.get("files", []):
                path = entry.get("path", "")
                if path not in names:
                    mismatches.append(f"{path}（缺失）")
                    continue
                if sha256_bytes(zf.read(path)) != entry.get("sha256"):
                    mismatches.append(f"{path}（哈希不符）")
            report.check(not mismatches,
                         f"清单校验失败: {mismatches[:5]}")
            report.check(len(embedded.get("files", [])) == embedded.get("entryCount"),
                         "清单的 entryCount 与 files 数量不一致")
            report.notes.append(f"清单逐项校验: {len(embedded.get('files', []))} 个文件，"
                               f"哈希全部匹配")

    # ---- 4: honesty about the IPA --------------------------------------------
    ipa = DIST / "HTMLRunner.ipa"
    if not ipa.exists():
        report.notes.append("dist/HTMLRunner.ipa 不存在 —— 与 DELIVERY-REPORT.md 的声明一致"
                            "（本环境无 macOS/Xcode，未生成 IPA）")
    else:
        report.notes.append(f"发现 dist/HTMLRunner.ipa（{ipa.stat().st_size} 字节）")

    return finish(report)


def finish(report: Report) -> int:
    for note in report.notes:
        print(f"[dist] {note}")
    for error in report.errors:
        print(f"[dist][ERROR] {error}")
    if report.errors:
        print(f"[dist] 结果: 失败（{len(report.errors)} 个问题）")
        return 1
    print("[dist] 结果: 通过（校验和、归档结构、清单、必需文件、无构建产物泄漏）")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
