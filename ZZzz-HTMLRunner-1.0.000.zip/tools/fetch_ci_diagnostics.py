#!/usr/bin/env python3
"""Download and summarize a GitHub Actions run's artifacts and failed-step logs.

Used when a CI build fails: the diagnostics artifact contains the full xcodebuild
log plus the project tree, which is what makes a remote failure debuggable.

Usage
-----
    export HTMLRUNNER_GH_TOKEN=...
    python tools/fetch_ci_diagnostics.py --run-id 38226868451
    python tools/fetch_ci_diagnostics.py --run-id 38226868451 --extract
"""
from __future__ import annotations

import argparse
import io
import json
import os
import pathlib
import sys
import urllib.error
import urllib.parse
import urllib.request
import zipfile

ROOT = pathlib.Path(__file__).resolve().parent.parent
OUT = ROOT / "test-output" / "ci"
API = "https://api.github.com"


def reconfigure() -> None:
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except (AttributeError, ValueError):
            pass


def api(token: str, path: str, raw: bool = False):
    url = path if path.startswith("http") else API + path
    request = urllib.request.Request(url)
    request.add_header("Authorization", f"Bearer {token}")
    request.add_header("Accept", "application/vnd.github+json")
    request.add_header("X-GitHub-Api-Version", "2022-11-28")
    try:
        with urllib.request.urlopen(request, timeout=300) as response:
            data = response.read()
    except urllib.error.HTTPError as error:
        raise RuntimeError(f"HTTP {error.code} {path}: {error.read().decode('utf-8', 'replace')[:300]}") from None
    return data if raw else (json.loads(data.decode()) if data else {})


def download_artifact(token: str, url: str) -> bytes:
    """Downloads an artifact zip, following GitHub's redirect to blob storage.

    `GET /actions/artifacts/{id}/zip` answers 302 to a signed Azure Blob URL. The
    Authorization header must NOT be forwarded to that host — Azure rejects the
    request with `InvalidAuthenticationInfo` when it sees a GitHub bearer token.
    urllib follows redirects but keeps the headers, so the redirect is handled
    manually here.
    """
    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, req, fp, code, msg, headers, newurl):  # noqa: D102
            return None

    opener = urllib.request.build_opener(NoRedirect)
    request = urllib.request.Request(url)
    request.add_header("Authorization", f"Bearer {token}")
    request.add_header("Accept", "application/vnd.github+json")
    request.add_header("X-GitHub-Api-Version", "2022-11-28")
    try:
        with opener.open(request, timeout=300) as response:
            return response.read()
    except urllib.error.HTTPError as error:
        if error.code not in (301, 302, 303, 307, 308):
            raise RuntimeError(f"HTTP {error.code} downloading artifact: "
                               f"{error.read().decode('utf-8', 'replace')[:300]}") from None
        location = error.headers.get("Location")
    if not location:
        raise RuntimeError("artifact redirect had no Location header")
    # Fetch the signed URL WITHOUT the GitHub credentials.
    with urllib.request.urlopen(urllib.request.Request(location), timeout=600) as response:
        return response.read()


def main() -> int:
    reconfigure()
    parser = argparse.ArgumentParser(description="下载 GitHub Actions 运行的 artifacts 与日志")
    parser.add_argument("--owner", default="AdamDashen666")
    parser.add_argument("--repo", default="buzhen-ios-app")
    parser.add_argument("--run-id", type=int, required=True)
    parser.add_argument("--extract", action="store_true", help="解压到 test-output/ci/<artifact>/")
    parser.add_argument("--show", default="xcodebuild-errors.txt",
                        help="解压后打印这个文件的尾部（默认 xcodebuild-errors.txt）")
    parser.add_argument("--tail", type=int, default=120)
    args = parser.parse_args()

    token = os.environ.get("HTMLRUNNER_GH_TOKEN", "").strip()
    if not token:
        print("missing HTMLRUNNER_GH_TOKEN", file=sys.stderr)
        return 2

    run = api(token, f"/repos/{args.owner}/{args.repo}/actions/runs/{args.run_id}")
    print(f"run #{run['run_number']}  status={run['status']} conclusion={run['conclusion']}")
    print(f"url: {run['html_url']}")
    print(f"head_sha: {run.get('head_sha')}")

    jobs = api(token, f"/repos/{args.owner}/{args.repo}/actions/runs/{args.run_id}/jobs")["jobs"]
    for job in jobs:
        print(f"\njob: {job['name']} -> {job.get('conclusion')}")
        for step in job.get("steps", []):
            flag = "OK " if step.get("conclusion") == "success" else "!! "
            print(f"  {flag}{step['name']}: {step.get('conclusion')}")

    artifacts = api(token, f"/repos/{args.owner}/{args.repo}/actions/runs/{args.run_id}/artifacts")["artifacts"]
    print(f"\n{len(artifacts)} artifact(s):")
    OUT.mkdir(parents=True, exist_ok=True)
    for artifact in artifacts:
        print(f"  {artifact['name']}  {artifact['size_in_bytes']} bytes  expired={artifact['expired']}")
        if artifact["expired"]:
            continue
        blob = download_artifact(token, f"{API}/repos/{args.owner}/{args.repo}/actions/artifacts/{artifact['id']}/zip")
        safe = "".join(ch if ch.isalnum() or ch in "-_." else "_" for ch in artifact["name"])
        target = OUT / f"{safe}.zip"
        target.write_bytes(blob)
        print(f"    saved {target.relative_to(ROOT)} ({len(blob)} bytes)")
        if args.extract:
            directory = OUT / safe
            directory.mkdir(parents=True, exist_ok=True)
            with zipfile.ZipFile(io.BytesIO(blob)) as archive:
                archive.extractall(directory)
            print(f"    extracted to {directory.relative_to(ROOT)}")

            wanted = directory / args.show
            if not wanted.exists():
                matches = sorted(directory.rglob(pathlib.Path(args.show).name))
                wanted = matches[0] if matches else None
            if wanted and wanted.exists():
                text = wanted.read_text(encoding="utf-8", errors="replace").splitlines()
                print(f"\n---- {wanted.relative_to(ROOT)} (last {args.tail} lines) ----")
                for line in text[-args.tail:]:
                    print(line)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
