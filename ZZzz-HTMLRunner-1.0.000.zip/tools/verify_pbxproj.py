#!/usr/bin/env python3
"""Second opinion on `HTMLRunner.xcodeproj/project.pbxproj`.

`tools/verify_project.py` answers "is the project graph self-consistent, and does
every referenced file exist?". This script answers the *complementary* questions —
the ones that catch a bad edit to the generator rather than a dangling reference:

  1. Debug and Release build configurations define the **same** settings, except
     for a small, explicitly allowed set. This is the check that catches the bug
     this project actually had: `Release` silently losing `CODE_SIGN_ENTITLEMENTS`
     (which is intended) versus `Release` silently losing a Swift flag (which is not).
  2. Project-level settings that must not drift: `SWIFT_VERSION`, `SDKROOT`,
     `IPHONEOS_DEPLOYMENT_TARGET`, `TARGETED_DEVICE_FAMILY`.
  3. No `CODE_SIGN_STYLE`/team identifiers committed, and no privileged
     entitlements referenced anywhere.
  4. The committed pbxproj is **exactly** what the generator would produce — i.e. it
     was not hand-edited after generation. A divergence means the next person to run
     the generator will silently revert someone's fix.
  5. Object ids are deterministic across regenerations (so diffs stay reviewable).

Exit code 0 = no findings. Run:  python tools/verify_pbxproj.py
"""
from __future__ import annotations

import argparse
import pathlib
import subprocess
import sys

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import check_swift as cs  # reuse the OpenStep plist reader  # noqa: E402
from verify_project import parse_openstep_plist  # type: ignore[import-not-found]  # noqa: E402

ROOT = pathlib.Path(__file__).resolve().parent.parent
PBX = ROOT / "HTMLRunner.xcodeproj" / "project.pbxproj"

# Settings that legitimately differ between Debug and Release.
ALLOWED_CONFIG_DIFFERENCES = {
    "DEBUG_INFORMATION_FORMAT",
    "ENABLE_NS_ASSERTIONS",
    "ENABLE_TESTABILITY",
    "GCC_DYNAMIC_NO_PIC",
    "GCC_OPTIMIZATION_LEVEL",
    "GCC_PREPROCESSOR_DEFINITIONS",
    "MTL_ENABLE_DEBUG_INFO",
    "ONLY_ACTIVE_ARCH",
    "SWIFT_ACTIVE_COMPILATION_CONDITIONS",
    "SWIFT_COMPILATION_MODE",
    "SWIFT_OPTIMIZATION_LEVEL",
    "CODE_SIGN_ENTITLEMENTS",       # Debug only: get-task-allow
    "SWIFT_STRICT_CONCURRENCY",     # may legitimately be raised in one config first
}

# Values that must be identical in both configurations and at both levels.
#
# NOTE ON QUOTING: the OpenStep reader strips the quotes Xcode writes around a
# value, so `TARGETED_DEVICE_FAMILY = "2";` arrives here as the bare string `2`.
# Comparing against `'"2"'` would therefore report a false failure — which it did
# on the first run of this script. The values below are the *parsed* forms.
PINNED = {
    "SWIFT_VERSION": "5.0",
    "SDKROOT": "iphoneos",
    "IPHONEOS_DEPLOYMENT_TARGET": "17.0",
    "TARGETED_DEVICE_FAMILY": "2",
}

# Keys that must never appear in a committed project.
FORBIDDEN_KEYS = {
    "DEVELOPMENT_TEAM",
    "PROVISIONING_PROFILE_SPECIFIER",
    "PROVISIONING_PROFILE",
    "CODE_SIGN_IDENTITY",
}


class Report:
    def __init__(self) -> None:
        self.errors: list[str] = []
        self.notes: list[str] = []

    def check(self, condition: bool, message: str) -> bool:
        if not condition:
            self.errors.append(message)
        return condition


def configs(objects: dict) -> dict[str, dict]:
    """Maps configuration name -> buildSettings, for XCBuildConfiguration objects."""
    result: dict[str, dict] = {}
    for body in objects.values():
        if isinstance(body, dict) and body.get("isa") == "XCBuildConfiguration":
            name = body.get("name")
            settings = body.get("buildSettings")
            if isinstance(name, str) and isinstance(settings, dict):
                result[name] = settings
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description="校验 project.pbxproj 的配置一致性")
    parser.add_argument("--skip-regeneration", action="store_true")
    args = parser.parse_args()

    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except (AttributeError, ValueError):
            pass

    report = Report()
    if not report.check(PBX.exists(), f"缺少 {PBX.relative_to(ROOT)}"):
        return finish(report)

    original = PBX.read_text(encoding="utf-8")
    root = parse_openstep_plist(original)
    objects = root.get("objects", {})

    # There are two levels of configuration (project and target) with the same names,
    # so compare them per level by grouping on the configuration list that owns them.
    lists: dict[str, list[str]] = {}
    for body in objects.values():
        if isinstance(body, dict) and body.get("isa") == "XCConfigurationList":
            names = []
            for reference in body.get("buildConfigurations", []):
                target = objects.get(reference if isinstance(reference, str) else "")
                if isinstance(target, dict) and isinstance(target.get("name"), str):
                    names.append(target["name"])
            lists[str(body.get("buildConfigurations"))] = names

    by_name = configs(objects)
    report.check("Debug" in by_name, "找不到 Debug 构建配置")
    report.check("Release" in by_name, "找不到 Release 构建配置")

    # ---- 1/2: per-level comparison -------------------------------------------
    for body in objects.values():
        if not (isinstance(body, dict) and body.get("isa") == "XCConfigurationList"):
            continue
        references = [ref for ref in body.get("buildConfigurations", []) if isinstance(ref, str)]
        entries: dict[str, dict] = {}
        for reference in references:
            target = objects.get(reference)
            if isinstance(target, dict) and isinstance(target.get("name"), str):
                entries[target["name"]] = target.get("buildSettings", {}) or {}
        if "Debug" not in entries or "Release" not in entries:
            continue
        debug, release = entries["Debug"], entries["Release"]
        differing = {
            key for key in set(debug) | set(release)
            if debug.get(key) != release.get(key)
        }
        unexpected = sorted(differing - ALLOWED_CONFIG_DIFFERENCES)
        report.check(not unexpected,
                     f"Debug/Release 出现未预期的配置差异（可能在某一配置里丢了设置）: {unexpected}")
        if differing:
            report.notes.append(
                f"某一层级的 Debug/Release 差异（均为允许项）: {sorted(differing)}")

        for key, expected in PINNED.items():
            for name, settings in entries.items():
                if key in settings:
                    report.check(settings[key] == expected,
                                 f"{name} 的 {key} 应为 {expected}，实际 {settings[key]}")

        for key in FORBIDDEN_KEYS:
            for name, settings in entries.items():
                report.check(key not in settings,
                             f"{name} 配置里出现了不应提交的键 {key}（应由 mac/build.sh 在构建时注入）")

    # ---- 3: entitlements references -------------------------------------------
    for body in objects.values():
        if isinstance(body, dict) and body.get("isa") == "XCBuildConfiguration":
            settings = body.get("buildSettings", {}) or {}
            entitlements = settings.get("CODE_SIGN_ENTITLEMENTS")
            if entitlements:
                path = ROOT / entitlements
                report.check(path.exists(),
                             f"配置 {body.get('name')} 引用了不存在的 entitlements 文件: {entitlements}")
                if path.exists():
                    import plistlib
                    keys = set(plistlib.loads(path.read_bytes()).keys())
                    report.check(keys == {"get-task-allow"},
                                 f"{entitlements} 只应包含 get-task-allow，实际: {sorted(keys)}")

    # ---- 3b: files that must NOT also be bundle resources ----------------------
    # A file referenced by INFOPLIST_FILE or CODE_SIGN_ENTITLEMENTS is processed by a
    # dedicated build phase. If the same file also sits inside a synchronized group
    # without an exception, Xcode tries to copy it as a resource too and the build
    # fails with "Multiple commands produce '.../Info.plist'". That is a real failure
    # this project hit on a macOS CI runner (run #141), so it is checked here.
    managed_by_build_setting: set[str] = set()
    for body in objects.values():
        if isinstance(body, dict) and body.get("isa") == "XCBuildConfiguration":
            settings = body.get("buildSettings", {}) or {}
            for key in ("INFOPLIST_FILE", "CODE_SIGN_ENTITLEMENTS"):
                value = settings.get(key)
                if isinstance(value, str) and value:
                    managed_by_build_setting.add(value)

    # Walk each synchronized group's exception set and confirm the managed files are
    # listed there so they are excluded from resource membership.
    sync_dirs = {
        body.get("path"): body
        for body in objects.values()
        if isinstance(body, dict) and body.get("isa") == "PBXFileSystemSynchronizedRootGroup"
    }
    excluded_paths: set[str] = set()
    for body in objects.values():
        if not (isinstance(body, dict)
                and body.get("isa") == "PBXFileSystemSynchronizedBuildFileExceptionSet"):
            continue
        for relative in body.get("membershipExceptions", []) or []:
            excluded_paths.add(relative)

    for managed in sorted(managed_by_build_setting):
        managed_path = pathlib.Path(managed)
        for group_path, _ in sync_dirs.items():
            if not isinstance(group_path, str):
                continue
            prefix = f"HTMLRunner/{group_path}/"
            if not managed.startswith(prefix):
                continue
            relative_inside_group = managed[len(prefix):]
            report.check(
                relative_inside_group in excluded_paths,
                f"'{managed}' 由构建设置管理，同时又在同步组 '{group_path}' 内，"
                f"但没有列进 membershipExceptions —— Xcode 会同时复制它并生成它，"
                f"导致 'Multiple commands produce' 构建失败。请在 "
                f"tools/generate_project.py 的 SYNCHRONIZED_EXCEPTIONS 中加入 "
                f"'{relative_inside_group}'。")
    if managed_by_build_setting:
        report.notes.append(
            f"由构建设置管理的文件已从资源同步中排除: {sorted(excluded_paths)}")

    # ---- 4: the committed file must equal generator output --------------------
    if not args.skip_regeneration:
        generator = ROOT / "tools" / "generate_project.py"
        if generator.exists():
            before = original
            result = subprocess.run([sys.executable, str(generator)],
                                    cwd=ROOT, capture_output=True, text=True,
                                    encoding="utf-8", errors="replace")
            after = PBX.read_text(encoding="utf-8")
            report.check(result.returncode == 0,
                         f"tools/generate_project.py 执行失败: {result.stderr.strip()[:400]}")
            if before != after:
                report.errors.append(
                    "project.pbxproj 与生成器输出不一致：它被手工改过。"
                    "请把改动合并进 tools/generate_project.py 并重新生成——"
                    "否则下次运行生成器会静默还原你的修改。")
            else:
                report.notes.append("project.pbxproj 与生成器输出完全一致（未被手工修改）")

    return finish(report)


def finish(report: Report) -> int:
    for note in report.notes:
        print(f"[pbxproj] {note}")
    for error in report.errors:
        print(f"[pbxproj][ERROR] {error}")
    if report.errors:
        print(f"[pbxproj] 结果: 失败（{len(report.errors)} 个问题）")
        return 1
    print("[pbxproj] 结果: 通过（配置一致性、无提交签名信息、与生成器输出一致）")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
