#!/usr/bin/env python3
"""Summarise test-output/TEST-REPORT.json for the delivery report.

Kept as a script because the numbers in DELIVERY-REPORT.md must be copied from a
real run rather than typed by hand.

Run:  python tools/summarize_report.py
"""
from __future__ import annotations

import json
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
REPORT = ROOT / "test-output" / "TEST-REPORT.json"


def main() -> int:
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except (AttributeError, ValueError):
            pass

    if not REPORT.exists():
        print("run `python project-tests/run_all.py` first", file=sys.stderr)
        return 2

    report = json.loads(REPORT.read_text(encoding="utf-8"))
    print(f"generatedAt : {report['generatedAt']}")
    print(f"host        : {report['host']['platform']} / python {report['host']['python']}")
    print()
    for suite in report["suites"]:
        detail = ""
        if suite.get("assertions"):
            detail = f" assertions={suite['assertions']['passed']}/{suite['assertions']['total']}"
        if suite.get("fixtures"):
            passed = sum(1 for fixture in suite["fixtures"] if fixture["passed"])
            checks = sum(fixture["checksPassed"] for fixture in suite["fixtures"])
            total_checks = sum(fixture["checks"] for fixture in suite["fixtures"])
            detail = f" fixtures={passed}/{len(suite['fixtures'])} checks={checks}/{total_checks}"
        if suite.get("browser"):
            detail += f" engine={suite['browser']} {suite.get('browserVersion', '')}"
        if suite.get("skipped"):
            detail = " SKIPPED"
        print(f"  {suite['name']:<18} exit={suite['exitCode']} passed={suite['passed']}{detail}")

    print()
    counts: dict[str, int] = {}
    for item in report["testPlan"]:
        counts[item["status"]] = counts.get(item["status"], 0) + 1
    for status, count in sorted(counts.items()):
        print(f"  {status:<16} {count}")
    print()
    print(f"ipaBuilt      : {report['headline']['ipaBuilt']}")
    print(f"testedOnIPad  : {report['headline']['testedOnIPad']}")
    print(f"jitVerified   : {report['headline']['jitVerified']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
