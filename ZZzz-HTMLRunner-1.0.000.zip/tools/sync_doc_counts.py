#!/usr/bin/env python3
"""Keep the numbers quoted in the documentation equal to the numbers in the tree.

Hand-written counts drift the moment a file is added. This script rewrites the
specific claims that are cheap to get wrong (Swift file/line counts, fixture
counts) so a reader is never misled by a stale figure.

Run:  python tools/sync_doc_counts.py [--check]
"""
from __future__ import annotations

import pathlib
import re
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
DOCS = ["README.md", "BUILD.md", "CHANGELOG.md", "DELIVERY-REPORT.md", "docs/TEST-PLAN.md", "agent.md"]


def measure() -> dict[str, str]:
    swift = sorted((ROOT / "HTMLRunner").rglob("*.swift"))
    lines = sum(path.read_text(encoding="utf-8").count("\n") for path in swift)
    fixtures = [path for path in (ROOT / "project-tests" / "fixtures").iterdir() if path.is_dir()]
    return {
        "swift_files": str(len(swift)),
        "swift_lines": f"{lines:,}",
        "fixtures": str(len(fixtures)),
    }


def rewrite(text: str, numbers: dict[str, str]) -> tuple[str, list[str]]:
    changes: list[str] = []

    # Swift line counts: any 4-digit thousands-separated number used near "行"/"lines".
    def replace_lines(match: re.Match) -> str:
        value = match.group(1).replace(",", "")
        if not value.isdigit() or not (5_000 <= int(value) <= 9_999):
            return match.group(0)
        if match.group(1) != numbers["swift_lines"]:
            changes.append(f"swift lines {match.group(1)} -> {numbers['swift_lines']}")
        return f"{numbers['swift_lines']}{match.group(2)}"

    text = re.sub(r"(\d{1,2},\d{3})(\s*行)", replace_lines, text)
    text = re.sub(r"(\d{1,2},\d{3})(\s*lines)", replace_lines, text)

    # Fixture counts.
    def replace_fixtures(match: re.Match) -> str:
        if match.group(1) != numbers["fixtures"]:
            changes.append(f"fixtures {match.group(1)} -> {numbers['fixtures']}")
        return f"{numbers['fixtures']} 个夹具"

    text = re.sub(r"(\d{1,2}) 个夹具", replace_fixtures, text)
    return text, changes


def main() -> int:
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except (AttributeError, ValueError):
            pass

    check_only = "--check" in sys.argv
    numbers = measure()
    print(f"[docs] 实测: swift={numbers['swift_files']} 个文件 / {numbers['swift_lines']} 行, "
          f"fixtures={numbers['fixtures']} 个")

    problems = 0
    for name in DOCS:
        path = ROOT / name
        if not path.exists():
            continue
        text = path.read_text(encoding="utf-8")
        updated, changes = rewrite(text, numbers)
        if changes:
            if check_only:
                problems += 1
                print(f"[docs][ERROR] {name} 数字过期: {', '.join(sorted(set(changes)))}")
            else:
                path.write_text(updated, encoding="utf-8", newline="\n")
                print(f"[docs] {name}: {', '.join(sorted(set(changes)))}")
        # Swift file count is stated explicitly in a few places.
        stale = re.findall(r"(\d{1,2}) 个 Swift 文件", updated)
        for value in stale:
            if value != numbers["swift_files"]:
                if check_only:
                    problems += 1
                    print(f"[docs][ERROR] {name} 的 Swift 文件数 {value} != {numbers['swift_files']}")
                else:
                    updated = updated.replace(f"{value} 个 Swift 文件", f"{numbers['swift_files']} 个 Swift 文件")
                    path.write_text(updated, encoding="utf-8", newline="\n")
                    print(f"[docs] {name}: Swift 文件数 {value} -> {numbers['swift_files']}")

    if check_only and problems:
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
