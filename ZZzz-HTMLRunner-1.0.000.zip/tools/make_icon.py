#!/usr/bin/env python3
"""Generate the single 1024x1024 app icon required by modern Xcode asset catalogs.

Modern Xcode accepts one `1024x1024` "universal / ios" entry in
`AppIcon.appiconset` and derives every device size from it, so this script only has
to produce that one file — and it can be regenerated deterministically instead of
being an opaque binary in the repository.

Run:  python tools/make_icon.py
"""
from __future__ import annotations

import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
OUTPUT = ROOT / "HTMLRunner" / "Resources" / "Assets.xcassets" / "AppIcon.appiconset" / "AppIcon-1024.png"

SIZE = 1024
# Icon geometry. iPadOS masks the corners itself, so the artwork is a full square
# with no rounded corners and no transparency.
BACKGROUND_TOP = (18, 22, 34)
BACKGROUND_BOTTOM = (34, 52, 92)
ACCENT = (52, 122, 242)
ACCENT_LIGHT = (110, 190, 255)
TEXT = (240, 246, 255)


def hex_to_rgb(value: str) -> tuple[int, int, int]:
    value = value.lstrip("#")
    return tuple(int(value[i:i + 2], 16) for i in (0, 2, 4))  # type: ignore[return-value]


def main() -> int:
    try:
        from PIL import Image, ImageDraw
    except ImportError:
        print("[icon] Pillow is required: python -m pip install Pillow", file=sys.stderr)
        return 2

    image = Image.new("RGB", (SIZE, SIZE), BACKGROUND_TOP)
    draw = ImageDraw.Draw(image)

    # Vertical gradient background.
    for y in range(SIZE):
        ratio = y / (SIZE - 1)
        color = tuple(
            int(BACKGROUND_TOP[channel] + (BACKGROUND_BOTTOM[channel] - BACKGROUND_TOP[channel]) * ratio)
            for channel in range(3)
        )
        draw.line([(0, y), (SIZE, y)], fill=color)

    # Speed lines: short strokes that read as motion without touching the glyph.
    # Each one stops well clear of the brackets; overlapping strokes turned the
    # artwork into a single tangled mark once scaled down to a springboard icon.
    for x0, x1, y in ((150, 300, 300), (724, 874, 700), (150, 250, 700)):
        draw.rounded_rectangle([x0, y, x1, y + 30], radius=15, fill=ACCENT)

    # Angle brackets, drawn as thick polylines so no font file is required.
    left_bracket = [(430, 300), (250, 512), (430, 724)]
    right_bracket = [(594, 300), (774, 512), (594, 724)]
    for points, color, width in ((left_bracket, ACCENT_LIGHT, 46), (right_bracket, ACCENT_LIGHT, 46)):
        draw.line(points, fill=color, width=width, joint="curve")
        for x, y in (points[0], points[-1]):
            draw.ellipse([x - width // 2, y - width // 2, x + width // 2, y + width // 2], fill=color)

    # Forward slash through the middle of the brackets.
    draw.line([(560, 268), (464, 756)], fill=TEXT, width=40)

    image.save(OUTPUT, format="PNG", optimize=True)
    print(f"[icon] wrote {OUTPUT.relative_to(ROOT)} ({OUTPUT.stat().st_size} bytes)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
