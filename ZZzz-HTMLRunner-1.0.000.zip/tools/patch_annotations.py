#!/usr/bin/env python3
"""One-off source annotation pass for HTMLRunner.

Keeps the SwiftUI-facing stores explicitly MainActor-isolated (so `@Published`
access is always legal) and removes a non-Sendable capture from the log writer.

Run:  python tools/patch_annotations.py
"""
from __future__ import annotations

import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent

REPLACEMENTS = {
    "HTMLRunner/Diagnostics/Log.swift": [
        # Explicit isolation for a store that SwiftUI observes.
        ("final class DiagnosticLogStore: ObservableObject {",
         "@MainActor\nfinal class DiagnosticLogStore: ObservableObject {"),
        # Was: `func log(...)` with a one-off @MainActor bolted on by an earlier pass.
        ("    @MainActor\n    func log(_ level: LogLevel,",
         "    func log(_ level: LogLevel,"),
        # The detached writer must not capture `self` (a non-Sendable reference).
        ("""        Task.detached(priority: .utility) { [fileURL, encoder, entry] in
            DiagnosticLogStore.appendToDisk(entry: entry, fileURL: fileURL, encoder: encoder)
        }""",
         """        let fileURL = self.fileURL
        let encoder = self.encoder
        Task.detached(priority: .utility) { [fileURL, encoder, entry] in
            DiagnosticLogStore.appendToDisk(entry: entry, fileURL: fileURL, encoder: encoder)
        }"""),
    ],
    "HTMLRunner/FileManagement/ProjectStore.swift": [
        ("final class ProjectStore: ObservableObject {",
         "@MainActor\nfinal class ProjectStore: ObservableObject {"),
    ],
    "HTMLRunner/Web/LocalHTTPServer.swift": [
        ("final class LocalHTTPServer: ObservableObject {",
         "@MainActor\nfinal class LocalHTTPServer: ObservableObject {"),
    ],
    "HTMLRunner/Web/WebViewCoordinator.swift": [
        ("final class WebViewCoordinator: NSObject, ObservableObject {",
         "@MainActor\nfinal class WebViewCoordinator: NSObject, ObservableObject {"),
    ],
}


def main() -> int:
    changed = []
    for relative, pairs in REPLACEMENTS.items():
        path = ROOT / relative
        if not path.exists():
            print(f"[patch] MISSING {relative}", file=sys.stderr)
            return 2
        text = path.read_text(encoding="utf-8")
        for old, new in pairs:
            if old not in text:
                print(f"[patch] pattern not found in {relative}: {old.splitlines()[0]!r}", file=sys.stderr)
                return 3
            if new in text and old != new:
                # Already applied (idempotent re-run).
                continue
            text = text.replace(old, new, 1)
        path.write_text(text, encoding="utf-8", newline="\n")
        changed.append(relative)
    for relative in changed:
        print(f"[patch] updated {relative}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
