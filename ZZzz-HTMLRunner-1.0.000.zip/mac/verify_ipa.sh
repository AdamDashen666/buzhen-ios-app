#!/usr/bin/env bash
#
# mac/verify_ipa.sh
#
# Standalone verification tool for an iOS .ipa produced by mac/build.sh (or by
# any other means). It answers one question: "is this file actually a valid,
# installable, arm64 device IPA?" - without Xcode, without a device and without
# trusting the build that produced it.
#
# USAGE
#   bash mac/verify_ipa.sh dist/HTMLRunner.ipa
#   bash mac/verify_ipa.sh -h
#
# EXIT STATUS
#   0  no hard failure (warnings may still have been printed)
#   1  at least one hard failure
#   2  usage error (missing/unreadable argument)
#
# WHAT IS CHECKED (hard failure = exit 1)
#   * the file exists, is non-empty and is a readable zip (`unzip -t`)
#   * the archive contains Payload/<App>.app, its Info.plist and its executable
#   * Info.plist parses (`plutil -lint`)
#   * CFBundleIdentifier / CFBundleShortVersionString / CFBundleVersion exist
#   * UIDeviceFamily contains 2 (iPad)
#   * CFBundleSupportedPlatforms says iPhoneOS, not iPhoneSimulator
#   * the executable is a Mach-O arm64 binary with no Intel slice, and is not a
#     simulator build (vtool platform check)
#   * Assets.car (or at least a loose icon) is present
#   * an embedded provisioning profile, when present, has not expired
#
# WHAT IS ONLY A WARNING
#   * no _CodeSignature and no embedded.mobileprovision: this is exactly what an
#     unsigned IPA for a re-signing tool (NB助手) looks like. Not an error.
#   * missing PkgInfo
#   * missing SwiftSupport/ or Symbols/
#   * a signed IPA whose signature cannot be verified on this Mac
#
# Implementation notes: runs on macOS' stock bash 3.2 (no associative arrays, no
# namerefs, no unguarded expansion of empty arrays under `set -u`), uses no
# sudo, needs no network, and writes nothing outside its own temporary
# directory (which is kept for inspection when something fails). `unzip -Z1`
# output is always redirected to a file before being grepped, because under
# `set -o pipefail` a `grep -q` that exits on its first match can kill the
# producer with SIGPIPE and turn a successful match into a failing pipeline.

set -euo pipefail

# ---------------------------------------------------------------------------
# Output helpers and failure accounting
# ---------------------------------------------------------------------------
FAILURES=0
WARNINGS=0

log()  { printf '[verify] %s\n' "$*"; }
ok()   { printf '[verify][ok] %s\n' "$*"; }
info() { printf '[verify]   %s\n' "$*"; }
warn() { WARNINGS=$((WARNINGS + 1)); printf '[verify][warn] %s\n' "$*" >&2; }
err()  { printf '[error] %s\n' "$*" >&2; }
die()  { err "$*"; exit 1; }
fail() { FAILURES=$((FAILURES + 1)); printf '[verify][FAIL] %s\n' "$*" >&2; }
show() { printf '[verify]   %-28s : %s\n' "$1" "${2:-<missing>}"; }

usage() {
  cat <<'USAGE'
mac/verify_ipa.sh - verify an iOS .ipa without Xcode or a device.

Usage:
  bash mac/verify_ipa.sh <path/to/app.ipa>
  bash mac/verify_ipa.sh -h | --help

Checks: zip integrity, Payload/<App>.app structure, Info.plist parse and key
fields (bundle id, versions, MinimumOSVersion, UIDeviceFamily, supported
platforms), arm64 Mach-O executable (rejecting Intel and simulator builds),
Assets.car/PkgInfo, and the integrity/expiry of an embedded provisioning
profile when one is present.

Exit codes: 0 = no hard failure, 1 = hard failure, 2 = usage error.
An unsigned IPA (no _CodeSignature, no embedded.mobileprovision) is valid for
re-signing tools such as NB助手 and is reported as a warning, not a failure.
USAGE
}

# ---------------------------------------------------------------------------
# 1. Arguments
# ---------------------------------------------------------------------------
IPA_INPUT=""

while [ "$#" -gt 0 ]; do
  case "$1" in
    -h|--help) usage; exit 0 ;;
    -*) err "unknown option: $1"; usage >&2; exit 2 ;;
    *)
      if [ -n "${IPA_INPUT}" ]; then
        err "only one .ipa path may be given (got '${IPA_INPUT}' and '$1')."
        usage >&2
        exit 2
      fi
      IPA_INPUT="$1"
      ;;
  esac
  shift
done

if [ -z "${IPA_INPUT}" ]; then
  err "no .ipa path given."
  usage >&2
  exit 2
fi

if [ ! -e "${IPA_INPUT}" ]; then
  die "file not found: ${IPA_INPUT}"
fi
if [ ! -f "${IPA_INPUT}" ]; then
  die "not a regular file: ${IPA_INPUT}"
fi
if [ ! -s "${IPA_INPUT}" ]; then
  die "file is empty: ${IPA_INPUT} - refusing to report on a zero byte IPA."
fi

case "${IPA_INPUT}" in
  *.ipa) : ;;
  *) warn "'${IPA_INPUT}' does not end in .ipa; verifying it anyway." ;;
esac

for tool in unzip plutil shasum lipo file mktemp wc tr sed grep sort tail cat cut date; do
  if ! command -v "${tool}" >/dev/null 2>&1; then
    die "required tool '${tool}' not found on PATH (it ships with macOS)."
  fi
done

IPA_DIR="$(cd "$(dirname "${IPA_INPUT}")" && pwd)"
IPA_ABS="${IPA_DIR}/$(basename "${IPA_INPUT}")"
IPA_BYTES="$(wc -c < "${IPA_ABS}" | tr -d '[:space:]')"
IPA_HASH="$(shasum -a 256 "${IPA_ABS}" | cut -d' ' -f1)"

# ---------------------------------------------------------------------------
# 2. Scratch space. Kept for inspection when something failed, removed when the
#    IPA is fine. Only this directory is ever deleted.
# ---------------------------------------------------------------------------
WORK="$(mktemp -d "${TMPDIR:-/tmp}/htmlrunner-verify.XXXXXX")"
ENTRIES="${WORK}/entries.txt"

cleanup() {
  local status=$?
  if [ "${FAILURES}" -gt 0 ] || [ "${status}" -ne 0 ]; then
    printf '[verify] scratch directory kept for inspection: %s\n' "${WORK}" >&2
  else
    rm -rf "${WORK}"
  fi
  return 0
}
trap cleanup EXIT

if [ ! -x /usr/libexec/PlistBuddy ]; then
  warn "/usr/libexec/PlistBuddy is missing; array values such as UIDeviceFamily cannot be read."
fi

printf '\n[verify] ==== %s ====\n' "$(basename "${IPA_ABS}")"
log "path   : ${IPA_ABS}"
log "size   : ${IPA_BYTES} bytes"
log "sha256 : ${IPA_HASH}"

# ---------------------------------------------------------------------------
# 3. Generic helpers (all file based: see the pipefail note in the header)
# ---------------------------------------------------------------------------
count_matching() {
  # count_matching <file> <extended regex> - prints a count, never fails.
  grep -cE "$2" "$1" 2>/dev/null || true
}

count_nonempty_lines() {
  # count_nonempty_lines <file> - prints a count, never fails.
  grep -c '[^[:space:]]' "$1" 2>/dev/null || true
}

plist_get() {
  # plist_get <key path> <plist file> - prints the value, never fails.
  # Key paths use PlistBuddy syntax, e.g. CFBundleIdentifier or UIDeviceFamily:0.
  # PlistBuddy is the primary reader (it handles binary plists and array
  # indices); the plutil fallback only covers plain string keys.
  local key="$1" plist="$2" value=""
  if [ -x /usr/libexec/PlistBuddy ]; then
    value="$(/usr/libexec/PlistBuddy -c "Print :${key}" "${plist}" 2>/dev/null || true)"
  fi
  if [ -z "${value}" ] && command -v plutil >/dev/null 2>&1; then
    value="$(plutil -extract "${key}" raw -o - "${plist}" 2>/dev/null || true)"
  fi
  printf '%s' "${value}"
  return 0
}

plist_field() {
  # plist_field <key> <plist file> - value on stdout, flattened to one line.
  plist_get "$1" "$2" | tr -d '\n'
}

plist_array() {
  # plist_array <key> [plist file] - one array element per line on stdout.
  # Defaults to the app's Info.plist; pass the profile plist to read other files.
  local key="$1" plist="${2:-${INFO_PLIST}}" index=0 value=""
  while [ "${index}" -lt 64 ]; do
    value="$(plist_get "${key}:${index}" "${plist}")"
    [ -n "${value}" ] || break
    printf '%s\n' "${value}"
    index=$((index + 1))
  done
  return 0
}

# ---------------------------------------------------------------------------
# 4. Zip integrity
# ---------------------------------------------------------------------------
printf '\n[verify] ==== zip integrity ====\n'
if ! unzip -t "${IPA_ABS}" > "${WORK}/unzip-test.log" 2>&1; then
  fail "unzip -t reports a corrupt or unreadable archive."
  tail -n 20 "${WORK}/unzip-test.log" >&2 || true
else
  ok "unzip -t: archive is intact"
  tail -n 2 "${WORK}/unzip-test.log" | while IFS= read -r line; do info "${line}"; done
fi

if ! unzip -Z1 "${IPA_ABS}" > "${ENTRIES}" 2>"${WORK}/unzip-list.err"; then
  fail "cannot list the archive contents (unzip -Z1 failed)."
  tail -n 5 "${WORK}/unzip-list.err" >&2 || true
fi
ENTRY_COUNT="$(wc -l < "${ENTRIES}" | tr -d '[:space:]')"
log "entries: ${ENTRY_COUNT}"

if [ "${ENTRY_COUNT}" = "0" ]; then
  fail "the archive is empty."
  printf '\n[verify] ==== summary ====\n'
  err "${FAILURES} hard failure(s), ${WARNINGS} warning(s) - cannot continue without archive contents."
  exit 1
fi

# ---------------------------------------------------------------------------
# 5. Payload structure
# ---------------------------------------------------------------------------
printf '\n[verify] ==== payload structure ====\n'

PAYLOAD_ENTRIES="$(count_matching "${ENTRIES}" '^Payload/')"
log "Payload entries: ${PAYLOAD_ENTRIES}"
if [ "${PAYLOAD_ENTRIES}" = "0" ]; then
  fail "no Payload/ directory in the archive - this is not an iOS .ipa."
fi

sed -n 's|^Payload/\([^/]*\.app\)/.*|\1|p' "${ENTRIES}" | sort -u > "${WORK}/app-bundles.txt"
APP_BUNDLE_COUNT="$(count_nonempty_lines "${WORK}/app-bundles.txt")"
log "app bundles under Payload/: ${APP_BUNDLE_COUNT}"

if [ "${APP_BUNDLE_COUNT}" = "0" ]; then
  fail "no Payload/<App>.app bundle found."
  printf '\n[verify] ==== summary ====\n'
  err "${FAILURES} hard failure(s), ${WARNINGS} warning(s)."
  exit 1
fi
if [ "${APP_BUNDLE_COUNT}" != "1" ]; then
  warn "more than one .app bundle under Payload/; verifying the first one only."
  while IFS= read -r extra; do info "extra bundle: ${extra}"; done < "${WORK}/app-bundles.txt"
fi
APP_NAME="$(sed -n '1p' "${WORK}/app-bundles.txt")"
APP_REL="Payload/${APP_NAME}"
log "verifying bundle: ${APP_REL} (an iOS .ipa carries exactly one .app)"

for required in "Info.plist" "${APP_NAME%.app}" "PkgInfo" "Assets.car" "embedded.mobileprovision" "_CodeSignature/CodeResources"; do
  if grep -qx "${APP_REL}/${required}" "${ENTRIES}"; then
    info "present: ${APP_REL}/${required}"
  else
    info "absent : ${APP_REL}/${required}"
  fi
done

if ! grep -qx "${APP_REL}/Info.plist" "${ENTRIES}"; then
  fail "missing ${APP_REL}/Info.plist - the bundle cannot be installed."
fi

# ---------------------------------------------------------------------------
# 6. Extract the bundle so the binary and the plists can be inspected
# ---------------------------------------------------------------------------
printf '\n[verify] ==== extracting ====\n'
if ! unzip -q -o "${IPA_ABS}" -d "${WORK}/extract" > "${WORK}/unzip-extract.log" 2>&1; then
  fail "extraction failed."
  tail -n 20 "${WORK}/unzip-extract.log" >&2 || true
  printf '\n[verify] ==== summary ====\n'
  err "${FAILURES} hard failure(s), ${WARNINGS} warning(s)."
  exit 1
fi
APP_DIR="${WORK}/extract/${APP_REL}"
if [ ! -d "${APP_DIR}" ]; then
  fail "extracted bundle directory not found: ${APP_REL}"
  printf '\n[verify] ==== summary ====\n'
  err "${FAILURES} hard failure(s), ${WARNINGS} warning(s)."
  exit 1
fi
ok "extracted ${APP_NAME}"

# ---------------------------------------------------------------------------
# 7. Info.plist
# ---------------------------------------------------------------------------
printf '\n[verify] ==== Info.plist ====\n'
INFO_PLIST="${APP_DIR}/Info.plist"

if [ ! -f "${INFO_PLIST}" ]; then
  fail "Info.plist is not present in the extracted bundle."
  printf '\n[verify] ==== summary ====\n'
  err "${FAILURES} hard failure(s), ${WARNINGS} warning(s)."
  exit 1
fi

if plutil -lint "${INFO_PLIST}" > "${WORK}/plutil-lint.log" 2>&1; then
  ok "plutil -lint: $(cat "${WORK}/plutil-lint.log")"
else
  fail "plutil -lint rejects Info.plist:"
  cat "${WORK}/plutil-lint.log" >&2 || true
fi

BUNDLE_ID="$(plist_field CFBundleIdentifier "${INFO_PLIST}")"
BUNDLE_NAME="$(plist_field CFBundleName "${INFO_PLIST}")"
BUNDLE_DISPLAY_NAME="$(plist_field CFBundleDisplayName "${INFO_PLIST}")"
SHORT_VERSION="$(plist_field CFBundleShortVersionString "${INFO_PLIST}")"
BUNDLE_VERSION="$(plist_field CFBundleVersion "${INFO_PLIST}")"
MIN_OS="$(plist_field MinimumOSVersion "${INFO_PLIST}")"
EXECUTABLE_NAME="$(plist_field CFBundleExecutable "${INFO_PLIST}")"
PLATFORM_NAME="$(plist_field DTPlatformName "${INFO_PLIST}")"
PLATFORM_VERSION="$(plist_field DTPlatformVersion "${INFO_PLIST}")"
SDK_BUILD="$(plist_field DTSDKBuild "${INFO_PLIST}")"

show "CFBundleIdentifier" "${BUNDLE_ID}"
show "CFBundleName" "${BUNDLE_NAME}"
show "CFBundleDisplayName" "${BUNDLE_DISPLAY_NAME}"
show "CFBundleShortVersionString" "${SHORT_VERSION}"
show "CFBundleVersion" "${BUNDLE_VERSION}"
show "MinimumOSVersion" "${MIN_OS}"
show "CFBundleExecutable" "${EXECUTABLE_NAME}"
show "DTPlatformName" "${PLATFORM_NAME}"
show "DTPlatformVersion" "${PLATFORM_VERSION}"
show "DTSDKBuild" "${SDK_BUILD}"

if [ -z "${BUNDLE_ID}" ]; then
  fail "CFBundleIdentifier is missing from Info.plist."
else
  ok "CFBundleIdentifier: ${BUNDLE_ID}"
fi
if [ -z "${SHORT_VERSION}" ]; then
  fail "CFBundleShortVersionString is missing from Info.plist."
fi
if [ -z "${BUNDLE_VERSION}" ]; then
  fail "CFBundleVersion is missing from Info.plist (iOS refuses to install without it)."
fi
if [ -z "${EXECUTABLE_NAME}" ]; then
  EXECUTABLE_NAME="${APP_NAME%.app}"
  fail "CFBundleExecutable is missing from Info.plist (falling back to '${EXECUTABLE_NAME}' for the binary check)."
fi

# ---------------------------------------------------------------------------
# 8. Device family and supported platform
# ---------------------------------------------------------------------------
printf '\n[verify] ==== device family / platform ====\n'

plist_array UIDeviceFamily > "${WORK}/device-family.txt"
if [ ! -s "${WORK}/device-family.txt" ]; then
  fail "UIDeviceFamily is missing from Info.plist (cannot tell whether iPads are supported)."
else
  HAS_IPAD=0
  while IFS= read -r family; do
    case "${family}" in
      1) info "UIDeviceFamily: 1 (iPhone / iPod touch)" ;;
      2) info "UIDeviceFamily: 2 (iPad)"; HAS_IPAD=1 ;;
      *) info "UIDeviceFamily: ${family} (unknown value)" ;;
    esac
  done < "${WORK}/device-family.txt"
  if [ "${HAS_IPAD}" -eq 1 ]; then
    ok "UIDeviceFamily includes 2 (iPad): the app can run on an iPad."
  else
    fail "UIDeviceFamily does not include 2 (iPad) - the app would not install on an iPad."
  fi
fi

plist_array CFBundleSupportedPlatforms > "${WORK}/supported-platforms.txt"
if [ ! -s "${WORK}/supported-platforms.txt" ]; then
  warn "CFBundleSupportedPlatforms is missing from Info.plist (older Xcode omitted it)."
else
  HAS_DEVICE_PLATFORM=0
  HAS_SIMULATOR_PLATFORM=0
  while IFS= read -r platform; do
    info "CFBundleSupportedPlatforms: ${platform}"
    case "${platform}" in
      iPhoneOS) HAS_DEVICE_PLATFORM=1 ;;
      iPhoneSimulator) HAS_SIMULATOR_PLATFORM=1 ;;
    esac
  done < "${WORK}/supported-platforms.txt"
  if [ "${HAS_SIMULATOR_PLATFORM}" -eq 1 ] && [ "${HAS_DEVICE_PLATFORM}" -eq 0 ]; then
    fail "CFBundleSupportedPlatforms lists only iPhoneSimulator: this is a SIMULATOR build, not an installable device IPA."
  elif [ "${HAS_DEVICE_PLATFORM}" -eq 0 ]; then
    fail "CFBundleSupportedPlatforms does not list iPhoneOS."
  else
    ok "CFBundleSupportedPlatforms lists iPhoneOS (device build)."
  fi
fi

if [ -n "${MIN_OS}" ]; then
  MIN_MAJOR="${MIN_OS%%.*}"
  case "${MIN_MAJOR}" in
    ''|*[!0-9]*) warn "cannot parse MinimumOSVersion '${MIN_OS}'." ;;
    *)
      if [ "${MIN_OS}" != "17.0" ]; then
        warn "MinimumOSVersion is ${MIN_OS}, while the project pins IPHONEOS_DEPLOYMENT_TARGET=17.0."
      else
        ok "MinimumOSVersion ${MIN_OS} matches the project's iOS 17.0 deployment target."
      fi
      ;;
  esac
fi

# ---------------------------------------------------------------------------
# 9. Mach-O executable
# ---------------------------------------------------------------------------
printf '\n[verify] ==== executable ====\n'
EXEC_PATH="${APP_DIR}/${EXECUTABLE_NAME}"

if [ ! -f "${EXEC_PATH}" ]; then
  fail "executable not found: ${APP_REL}/${EXECUTABLE_NAME}"
else
  EXEC_BYTES="$(wc -c < "${EXEC_PATH}" | tr -d '[:space:]')"
  log "binary: ${APP_REL}/${EXECUTABLE_NAME} (${EXEC_BYTES} bytes)"
  if [ "${EXEC_BYTES}" = "0" ]; then
    fail "the executable is zero bytes."
  fi

  FILE_OUTPUT="$(file "${EXEC_PATH}" 2>&1 || true)"
  LIPO_OUTPUT="$(lipo -info "${EXEC_PATH}" 2>&1 || true)"
  info "file      : ${FILE_OUTPUT}"
  info "lipo -info: ${LIPO_OUTPUT}"

  case "${FILE_OUTPUT}" in
    *Mach-O*) ok "the executable is a Mach-O binary." ;;
    *) fail "'file' does not report a Mach-O binary: ${FILE_OUTPUT}" ;;
  esac

  case "${FILE_OUTPUT} ${LIPO_OUTPUT}" in
    *arm64*) ok "the executable contains an arm64 slice." ;;
    *) fail "the executable has no arm64 slice: ${LIPO_OUTPUT} - iOS devices need arm64." ;;
  esac

  case "${FILE_OUTPUT} ${LIPO_OUTPUT}" in
    *x86_64*|*i386*)
      fail "the executable contains an Intel slice (x86_64/i386): ${LIPO_OUTPUT} - this is a simulator or Mac build."
      ;;
    *) ok "no Intel (x86_64/i386) slice - the IPA is not an Intel/simulator build." ;;
  esac

  if command -v vtool >/dev/null 2>&1; then
    VTOOL_OUTPUT="$(vtool -show-build "${EXEC_PATH}" 2>&1 || true)"
    case "${VTOOL_OUTPUT}" in
      *IOSSIMULATOR*)
        fail "vtool reports platform IOSSIMULATOR - a simulator build cannot be installed on a device."
        ;;
      *"platform IOS"*)
        ok "vtool confirms build platform: IOS (device)."
        printf '%s\n' "${VTOOL_OUTPUT}" | while IFS= read -r line; do info "vtool: ${line}"; done
        ;;
      *) warn "vtool did not report a build platform; inspect the binary manually." ;;
    esac
  else
    warn "vtool not available; the simulator/device distinction relies on file/lipo output only."
  fi
fi

# ---------------------------------------------------------------------------
# 10. Code signature and provisioning profile
# ---------------------------------------------------------------------------
printf '\n[verify] ==== signature and provisioning ====\n'
SIGNED=0
SIGNED_REASON=""
if [ -d "${APP_DIR}/_CodeSignature" ]; then
  SIGNED=1
  SIGNED_REASON="_CodeSignature/ directory present"
elif [ -f "${APP_DIR}/embedded.mobileprovision" ]; then
  SIGNED=1
  SIGNED_REASON="embedded.mobileprovision present"
fi

if [ "${SIGNED}" -eq 1 ]; then
  log "signature: SIGNED (${SIGNED_REASON})"
  if [ -f "${APP_DIR}/_CodeSignature/CodeResources" ]; then
    ok "_CodeSignature/CodeResources is present."
  else
    warn "_CodeSignature exists but CodeResources is missing - the signature looks incomplete."
  fi
  if command -v codesign >/dev/null 2>&1; then
    codesign -dv --verbose=4 "${APP_DIR}" > "${WORK}/codesign.log" 2>&1 || true
    if [ -s "${WORK}/codesign.log" ]; then
      info "codesign -dv:"
      grep -E 'Identifier|TeamIdentifier|Authority|Signature|Sealed|Format|Timestamp' "${WORK}/codesign.log" 2>/dev/null \
        | while IFS= read -r line; do info "  ${line}"; done || true
    fi
    if codesign --verify "${APP_DIR}" > "${WORK}/codesign-verify.log" 2>&1; then
      ok "codesign --verify: the signature is intact and trusted on this Mac."
    else
      warn "codesign --verify did not succeed on this Mac (see ${WORK}/codesign-verify.log)."
      info "This is normal when the signing certificate is not in this Mac's keychain;"
      info "a re-signing tool replaces the signature anyway."
    fi
  else
    warn "codesign not available; cannot inspect the signature."
  fi
else
  warn "signature: UNSIGNED (no _CodeSignature, no embedded.mobileprovision) - not a failure."
  info "This is EXPECTED for an IPA packaged for a re-signing tool such as NB助手."
  info "iOS will not install it as it is: sign it with your own certificate and profile first."
fi

PROFILE="${APP_DIR}/embedded.mobileprovision"
if [ -f "${PROFILE}" ]; then
  if ! command -v security >/dev/null 2>&1; then
    warn "security(1) not available; cannot decode the embedded provisioning profile."
  elif ! security cms -D -i "${PROFILE}" > "${WORK}/profile.plist" 2> "${WORK}/profile.err"; then
    warn "the embedded provisioning profile could not be decoded (see ${WORK}/profile.err)."
  elif ! plutil -lint "${WORK}/profile.plist" > /dev/null 2>&1; then
    warn "the decoded provisioning profile is not a valid plist."
  else
    ok "decoded the embedded provisioning profile."
    for key in Name UUID TeamName AppIDName; do
      value="$(plist_field "${key}" "${WORK}/profile.plist")"
      if [ -n "${value}" ]; then
        info "${key}: ${value}"
      fi
    done
    TEAM_ID="$(plist_field TeamIdentifier:0 "${WORK}/profile.plist")"
    if [ -n "${TEAM_ID}" ]; then
      info "TeamIdentifier: ${TEAM_ID}"
    fi
    PROFILE_APP_ID="$(plist_field Entitlements:application-identifier "${WORK}/profile.plist")"
    if [ -n "${PROFILE_APP_ID}" ]; then
      info "application-identifier: ${PROFILE_APP_ID}"
    fi

    plist_array ProvisionedDevices "${WORK}/profile.plist" > "${WORK}/devices.txt"
    DEVICE_COUNT="$(count_nonempty_lines "${WORK}/devices.txt")"
    info "ProvisionedDevices: ${DEVICE_COUNT}"
    if [ "${DEVICE_COUNT}" = "0" ]; then
      info "the profile lists no devices (normal for App Store or enterprise profiles)."
    fi

    if [ -n "${BUNDLE_ID}" ] && [ -n "${PROFILE_APP_ID}" ]; then
      case "${PROFILE_APP_ID}" in
        *".${BUNDLE_ID}") ok "the profile covers ${BUNDLE_ID}." ;;
        *) warn "the profile's application-identifier (${PROFILE_APP_ID}) does not match the app's bundle id (${BUNDLE_ID})." ;;
      esac
    fi

    EXPIRATION="$(plutil -extract ExpirationDate raw -o - "${WORK}/profile.plist" 2>/dev/null || true)"
    if [ -z "${EXPIRATION}" ]; then
      EXPIRATION="$(plist_field ExpirationDate "${WORK}/profile.plist")"
    fi
    if [ -z "${EXPIRATION}" ]; then
      warn "the profile has no readable ExpirationDate; check it manually."
    else
      info "ExpirationDate: ${EXPIRATION}"
      EXPIRATION_EPOCH="$(date -j -f "%Y-%m-%dT%H:%M:%SZ" "${EXPIRATION}" "+%s" 2>/dev/null || true)"
      if [ -z "${EXPIRATION_EPOCH}" ]; then
        EXPIRATION_EPOCH="$(date -j -f "%Y-%m-%d %H:%M:%S %z" "${EXPIRATION}" "+%s" 2>/dev/null || true)"
      fi
      if [ -z "${EXPIRATION_EPOCH}" ]; then
        warn "could not parse the profile expiry date automatically; compare it with today's date by hand."
      elif [ "${EXPIRATION_EPOCH}" -lt "$(date "+%s")" ]; then
        fail "the embedded provisioning profile has EXPIRED (${EXPIRATION}). Re-sign with a fresh profile; a re-signing tool such as NB助手 replaces it automatically."
      else
        ok "the embedded profile is still valid (${EXPIRATION})."
      fi
    fi
  fi
else
  info "no embedded.mobileprovision (expected for an unsigned IPA)."
fi

# ---------------------------------------------------------------------------
# 11. Assets and optional extras
# ---------------------------------------------------------------------------
printf '\n[verify] ==== assets and extras ====\n'
if [ -f "${APP_DIR}/Assets.car" ]; then
  ok "Assets.car present ($(wc -c < "${APP_DIR}/Assets.car" | tr -d '[:space:]') bytes)."
else
  ICON_COUNT="$(count_matching "${ENTRIES}" "^${APP_REL}/[^/]*[Ii]con[^/]*\.(png|jpg)\$")"
  if [ "${ICON_COUNT}" != "0" ]; then
    warn "Assets.car is missing but ${ICON_COUNT} loose icon file(s) were found; check the app icon on device."
  else
    fail "neither Assets.car nor an icon file is present in the bundle - the app has no icon."
  fi
fi

if [ -f "${APP_DIR}/PkgInfo" ]; then
  ok "PkgInfo present."
else
  warn "PkgInfo is missing (unusual, but harmless for re-signing tools)."
fi

if [ -d "${APP_DIR}/Frameworks" ]; then
  FRAMEWORK_COUNT="$(count_matching "${ENTRIES}" "^${APP_REL}/Frameworks/[^/]+\\.(framework|dylib)\$")"
  info "embedded frameworks/dylibs: ${FRAMEWORK_COUNT}"
  if [ "${FRAMEWORK_COUNT}" != "0" ] && [ "${SIGNED}" -eq 0 ]; then
    info "an unsigned bundle may embed frameworks: the re-signing tool signs all nested code."
  fi
fi

for extra in SwiftSupport Symbols; do
  EXTRA_COUNT="$(count_matching "${ENTRIES}" "^${extra}/")"
  if [ "${EXTRA_COUNT}" = "0" ]; then
    info "no ${extra}/ directory (only App Store IPAs carry it; not needed here)."
  else
    info "${extra}/ contains ${EXTRA_COUNT} entries."
  fi
done

# ---------------------------------------------------------------------------
# 12. Summary
# ---------------------------------------------------------------------------
printf '\n[verify] ==== summary ====\n'
log "file               : ${IPA_ABS}"
log "size               : ${IPA_BYTES} bytes"
log "sha256             : ${IPA_HASH}"
log "bundle identifier  : ${BUNDLE_ID:-<missing>}"
log "version            : ${SHORT_VERSION:-<missing>} (build ${BUNDLE_VERSION:-<missing>})"
log "minimum iOS        : ${MIN_OS:-<missing>}"
log "executable         : ${EXECUTABLE_NAME:-<missing>}"
if [ "${SIGNED}" -eq 1 ]; then
  log "signature          : SIGNED (${SIGNED_REASON})"
  log "installability     : depends on the signing certificate and profile listed above"
else
  log "signature          : UNSIGNED (no _CodeSignature, no embedded.mobileprovision)"
  log "installability     : must be signed by a re-signing tool (NB助手) or Xcode before installing"
fi
log "hard failures      : ${FAILURES}"
log "warnings           : ${WARNINGS}"

if [ "${FAILURES}" -gt 0 ]; then
  err "verification FAILED with ${FAILURES} hard failure(s)."
  exit 1
fi

if [ "${WARNINGS}" -gt 0 ]; then
  log "verification passed with ${WARNINGS} warning(s) - review them above."
else
  log "verification passed with no warnings."
fi
exit 0
