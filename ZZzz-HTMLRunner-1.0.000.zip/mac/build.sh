#!/usr/bin/env bash
#
# mac/build.sh
#
# Reproducible build -> archive -> IPA packaging pipeline for the HTMLRunner
# iOS/iPadOS app (project HTMLRunner/HTMLRunner.xcodeproj, scheme HTMLRunner).
#
# WHAT IT PRODUCES (relative to the repository root)
#   dist/HTMLRunner.ipa         primary artifact, UNSIGNED by default. This is the
#                               file to hand to a re-signing / sideloading tool
#                               such as NB助手: no development certificate is
#                               locked into it.
#   dist/HTMLRunner-signed.ipa  development-signed IPA, produced only with --signed
#                               (requires a certificate + provisioning profile).
#   dist/SHA256SUMS.txt         shasum -a 256 lines for every .ipa in dist/,
#                               written with repository-relative paths so the
#                               file stays portable.
#   dist/Payload/               staging copy used by the manual packaging path
#                               (safe to delete; recreated on every run).
#   build/*.log                 complete xcodebuild / zipping / verification logs.
#
# USAGE
#   bash mac/build.sh                 # unsigned IPA  (default)
#   bash mac/build.sh --signed        # development-signed IPA
#   bash mac/build.sh --clean         # wipe build/DerivedData first
#   bash mac/build.sh --dry-run       # print the command plan and exit (no execution)
#   bash mac/build.sh --help
#
# ENVIRONMENT OVERRIDES (all optional, all default to the project's own values)
#   BUNDLE_IDENTIFIER=<id>            override PRODUCT_BUNDLE_IDENTIFIER
#                                     (PRODUCT_BUNDLE_IDENTIFIER is accepted too)
#   IOS_DEPLOYMENT_TARGET=<ver>       override IPHONEOS_DEPLOYMENT_TARGET (17.0)
#   DEVELOPMENT_TEAM=<TEAMID>         required by --signed; optional otherwise
#   PROVISIONING_PROFILE_SPECIFIER=<name|UUID>   only meaningful with --signed
#   CODE_SIGN_IDENTITY=<name>         default "Apple Development"
#   CODE_SIGN_STYLE=<Manual|Automatic> default: Manual when a profile specifier is
#                                     given, otherwise Automatic (signed mode only)
#   ALLOW_PROVISIONING_UPDATES=1      add -allowProvisioningUpdates (signed mode only)
#   DEVELOPER_DIR=<path>              honoured by xcodebuild/xcrun themselves
#
# DESIGN NOTES
#   * POSIX-ish bash that also runs on macOS' stock /bin/bash 3.2 (no associative
#     arrays, no ${var,,}, no namerefs, and no expansion of possibly-empty arrays
#     under `set -u` except inside an explicit length guard).
#   * No sudo, no network access, no third-party dependencies.
#   * Every xcodebuild invocation is tee'd into build/ AND the real exit status of
#     xcodebuild (PIPESTATUS[0]) is what decides success - tee must never be able to
#     mask a failed build.
#   * Nothing is ever fabricated: if the build fails, the script exits non-zero and
#     no IPA is written.

set -euo pipefail

# ---------------------------------------------------------------------------
# 1. Locations. Everything runs from the repository root so that the documented
#    relative layout (build/..., dist/...) holds and no path contains surprises.
# ---------------------------------------------------------------------------
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"
cd "${REPO_ROOT}"

PROJECT_PATH="HTMLRunner/HTMLRunner.xcodeproj"
SCHEME_NAME="HTMLRunner"

BUILD_DIR="build"
DIST_DIR="dist"
DERIVED_DATA_PATH="build/DerivedData"
ARCHIVE_PATH="build/HTMLRunner.xcarchive"
ARCHIVED_APP_PATH="build/HTMLRunner.xcarchive/Products/Applications/HTMLRunner.app"

LOG_LIST="build/xcodebuild-list.log"
LOG_BUILD="build/xcodebuild-build.log"
LOG_ARCHIVE="build/xcodebuild-archive.log"
LOG_EXPORT="build/xcodebuild-export.log"
LOG_ZIP="build/zip.log"
LOG_VERIFY="build/verify_ipa.log"

EXPORT_DIR_UNSIGNED="build/export-unsigned"
EXPORT_DIR_SIGNED="build/export-signed"
EXPORT_OPTIONS_GENERATED="build/ExportOptions.plist"

EXPORT_OPTIONS_UNSIGNED_TEMPLATE="mac/ExportOptions-unsigned.plist"
EXPORT_OPTIONS_DEVELOPMENT_TEMPLATE="mac/ExportOptions-development.plist"

IPA_UNSIGNED="dist/HTMLRunner.ipa"
IPA_SIGNED="dist/HTMLRunner-signed.ipa"
SUMS_FILE="dist/SHA256SUMS.txt"
PAYLOAD_DIR="dist/Payload"
PAYLOAD_APP="dist/Payload/HTMLRunner.app"

IPA_LIST_FILE="build/.ipa-entries.txt"
IPA_PROBE_FILE="build/.ipa-signature-probe.txt"
SCHEME_PROBE_FILE="build/.schemes-section.txt"

VERIFY_SCRIPT="mac/verify_ipa.sh"

DEFAULT_BUNDLE_ID="com.htmlrunner.ipad"
DEFAULT_DEPLOYMENT_TARGET="17.0"
DEFAULT_CODE_SIGN_IDENTITY="Apple Development"
# `xcodebuild -exportArchive` method names: Xcode 14/15/16 accept the legacy
# `development` alias, Xcode 15+ renamed it to `debugging`. Both are tried below
# so the script works on either generation of Xcode.
EXPORT_METHOD_PRIMARY="development"
EXPORT_METHOD_FALLBACK="debugging"

# ---------------------------------------------------------------------------
# 2. Options and environment
# ---------------------------------------------------------------------------
MODE="unsigned"
DO_CLEAN=0
DRY_RUN=0

PRODUCT_BUNDLE_IDENTIFIER_ENV="${BUNDLE_IDENTIFIER:-${PRODUCT_BUNDLE_IDENTIFIER:-}}"
BUNDLE_ID_EFFECTIVE="${PRODUCT_BUNDLE_IDENTIFIER_ENV:-${DEFAULT_BUNDLE_ID}}"
DEPLOYMENT_TARGET="${IOS_DEPLOYMENT_TARGET:-${DEFAULT_DEPLOYMENT_TARGET}}"
DEVELOPMENT_TEAM="${DEVELOPMENT_TEAM:-}"
PROVISIONING_PROFILE_SPECIFIER="${PROVISIONING_PROFILE_SPECIFIER:-}"
CODE_SIGN_IDENTITY="${CODE_SIGN_IDENTITY:-${DEFAULT_CODE_SIGN_IDENTITY}}"
CODE_SIGN_STYLE="${CODE_SIGN_STYLE:-}"
ALLOW_PROVISIONING_UPDATES="${ALLOW_PROVISIONING_UPDATES:-0}"

# Extra build settings appended to every xcodebuild invocation.
# Non-empty by construction (the deployment target is always pinned), so
# `"${EXTRA_SETTINGS[@]}"` is safe even under `set -u` on bash 3.2.
EXTRA_SETTINGS=()
EXTRA_SETTINGS+=("IPHONEOS_DEPLOYMENT_TARGET=${DEPLOYMENT_TARGET}")
if [ -n "${PRODUCT_BUNDLE_IDENTIFIER_ENV}" ]; then
  EXTRA_SETTINGS+=("PRODUCT_BUNDLE_IDENTIFIER=${PRODUCT_BUNDLE_IDENTIFIER_ENV}")
fi
# Settings used for the "no signing identity available" retry of the archive step.
# CODE_SIGN_ENTITLEMENTS is cleared on purpose: the shipped entitlements file only
# carries get-task-allow for debug builds, and in this path nothing is signed, so
# no entitlement blob can be embedded anyway. Re-signing tools supply their own.
SIGN_DISABLED_SETTINGS=(
  "CODE_SIGNING_ALLOWED=NO"
  "CODE_SIGNING_REQUIRED=NO"
  "CODE_SIGN_IDENTITY="
  "CODE_SIGN_ENTITLEMENTS="
)
# Per phase build settings/flags (build vs. archive vs. the signing-disabled
# retry). Empty is the normal value; xcodebuild_logged expands it safely.
PHASE_ARGS=()
# Signing settings for --signed, filled in once the mode is known.
SIGN_APPLIED_SETTINGS=()

# ---------------------------------------------------------------------------
# 3. Output helpers: every line is prefixed so logs can be grepped for
#    `[build]`, `[build][warn]` or `[error]`.
# ---------------------------------------------------------------------------
log()  { printf '[build] %s\n' "$*"; }
note() { printf '[build]   %s\n' "$*"; }
warn() { printf '[build][warn] %s\n' "$*" >&2; }
err()  { printf '[error] %s\n' "$*" >&2; }
die()  { err "$*"; exit 1; }

usage() {
  cat <<'USAGE'
mac/build.sh - build, archive and package the HTMLRunner iOS app.

Usage:
  bash mac/build.sh [--signed] [--clean] [--dry-run] [--help]

Modes:
  (default)     dist/HTMLRunner.ipa        UNSIGNED, for re-signing tools (NB助手)
  --signed      dist/HTMLRunner-signed.ipa development-signed (team + profile required)

Options:
  --clean       remove build/DerivedData first (full rebuild)
  --dry-run     print the command plan for the selected mode, execute nothing
  -h, --help    this text

Environment:
  BUNDLE_IDENTIFIER, PRODUCT_BUNDLE_IDENTIFIER, IOS_DEPLOYMENT_TARGET,
  DEVELOPMENT_TEAM, PROVISIONING_PROFILE_SPECIFIER, CODE_SIGN_IDENTITY,
  CODE_SIGN_STYLE, ALLOW_PROVISIONING_UPDATES, DEVELOPER_DIR

Artifacts: dist/HTMLRunner.ipa (or dist/HTMLRunner-signed.ipa) + dist/SHA256SUMS.txt
Logs:      build/xcodebuild-*.log, build/verify_ipa.log
USAGE
}

while [ "$#" -gt 0 ]; do
  case "$1" in
    --signed)  MODE="signed" ;;
    --clean)   DO_CLEAN=1 ;;
    --dry-run) DRY_RUN=1 ;;
    -h|--help) usage; exit 0 ;;
    *) err "unknown argument: $1"; usage >&2; exit 2 ;;
  esac
  shift
done

if [ "$MODE" = "signed" ] && [ "${DRY_RUN}" -eq 0 ] && [ -z "${DEVELOPMENT_TEAM}" ]; then
  err "--signed requires a development team."
  note "Re-run as: DEVELOPMENT_TEAM=ABCDE12345 PROVISIONING_PROFILE_SPECIFIER='iOS Team Provisioning Profile: *' bash mac/build.sh --signed"
  exit 2
fi

# ---------------------------------------------------------------------------
# 4. Argument helpers (logging / dry-run formatting only)
# ---------------------------------------------------------------------------
shell_quote() {
  # Quote one argument so the printed form can be pasted back into a shell.
  local s="$1"
  case "$s" in
    '') printf "''" ;;
    *[!A-Za-z0-9_@%+=:,./-]*)
      # shellcheck disable=SC2016
      printf "'%s'" "$(printf '%s' "$s" | sed "s/'/'\\\\''/g")"
      ;;
    *) printf '%s' "$s" ;;
  esac
}

quote_args() {
  local out="" a
  for a in "$@"; do
    out="${out} $(shell_quote "$a")"
  done
  printf '%s' "${out# }"
}

# run_logged <logfile> <command> [args...]
#   Runs the command with stdout+stderr captured both on the terminal and in
#   <logfile>, then returns the COMMAND's exit status.
#   `set +e` is required: without it the pipeline would be evaluated under
#   errexit before PIPESTATUS could be read. PIPESTATUS[0] is read immediately
#   after the pipeline, before any other command can overwrite it, which is what
#   keeps `| tee` from masking a failing xcodebuild.
#   (The DRY_RUN guard below is unreachable in normal use because print_plan()
#   exits earlier; it stays as a safety net so that no future caller can execute
#   anything during a dry run.)
run_logged() {
  local logfile="$1"
  shift
  local status=0
  printf '[build] $ %s\n' "$(quote_args "$@")" | tee -a "${logfile}"
  if [ "${DRY_RUN}" -eq 1 ]; then
    printf '[build]   (dry run: not executed)\n'
    return 0
  fi
  set +e
  "$@" 2>&1 | tee -a "${logfile}"
  status=${PIPESTATUS[0]}
  set -e
  return "${status}"
}

# xcodebuild_logged <logfile> <xcodebuild args...>
#   Appends the shared EXTRA_SETTINGS (pinned deployment target, optional bundle
#   id) plus whatever the current phase put into PHASE_ARGS (signing settings).
#   `${ARR[@]+"${ARR[@]}"}` is the only expansion form that is safe for a
#   possibly-empty array under `set -u` on macOS' stock bash 3.2.
xcodebuild_logged() {
  local logfile="$1"
  shift
  run_logged "${logfile}" xcodebuild "$@" \
    ${PHASE_ARGS[@]+"${PHASE_ARGS[@]}"} \
    ${EXTRA_SETTINGS[@]+"${EXTRA_SETTINGS[@]}"}
}

log_has_failure_marker() {
  # Belt and braces: xcodebuild sometimes writes its verdict without a non-zero
  # exit status. Treat an explicit failure banner as a failure too.
  [ -f "$1" ] || return 1
  grep -qE '\*\* (BUILD|ARCHIVE|EXPORT) FAILED \*\*' "$1"
}

looks_like_signing_failure() {
  [ -f "$1" ] || return 1
  grep -qE 'No signing certificate|No profiles for|requires a development team|Provisioning profile|Code Sign error|code signing is required|No certificate matching|conflicting provisioning settings' "$1"
}

show_log_tail() {
  local logfile="$1"
  if [ -f "${logfile}" ]; then
    err "last 40 lines of ${logfile}:"
    tail -n 40 "${logfile}" >&2 || true
  fi
}

# ---------------------------------------------------------------------------
# 5. --dry-run: print the exact command plan for the selected mode and stop
#    before anything (including the macOS preflight) is executed. Keep in sync
#    with the implementation below.
# ---------------------------------------------------------------------------
print_plan() {
  local out_ipa="$IPA_UNSIGNED" export_dir="$EXPORT_DIR_UNSIGNED" options="$EXPORT_OPTIONS_UNSIGNED_TEMPLATE"
  if [ "$MODE" = "signed" ]; then
    out_ipa="$IPA_SIGNED"
    export_dir="$EXPORT_DIR_SIGNED"
    options="$EXPORT_OPTIONS_DEVELOPMENT_TEMPLATE"
  fi

  log "dry run: mode=${MODE}, nothing will be executed"
  plan_step=0
  plan_step=$((plan_step + 1)); log "${plan_step}. preflight"
  note "uname -s ; xcode-select -p ; xcodebuild -version ; swift --version"
  note "xcrun --sdk iphoneos --show-sdk-version"
  note "xcodebuild -list -project ${PROJECT_PATH}"
  plan_step=$((plan_step + 1)); log "${plan_step}. build"
  note "xcodebuild -project ${PROJECT_PATH} -scheme ${SCHEME_NAME} -sdk iphoneos -configuration Release -destination generic/platform=iOS -derivedDataPath ${DERIVED_DATA_PATH} build | tee ${LOG_BUILD}"
  plan_step=$((plan_step + 1)); log "${plan_step}. archive"
  note "xcodebuild -project ${PROJECT_PATH} -scheme ${SCHEME_NAME} -sdk iphoneos -configuration Release -destination generic/platform=iOS -derivedDataPath ${DERIVED_DATA_PATH} -archivePath ${ARCHIVE_PATH} archive | tee ${LOG_ARCHIVE}"
  if [ "$MODE" = "unsigned" ]; then
    note "(retry with $(quote_args "${SIGN_DISABLED_SETTINGS[@]}") if the first attempt only fails on signing)"
  else
    note "(with DEVELOPMENT_TEAM=${DEVELOPMENT_TEAM:-<unset - required for a real --signed run>} and the code signing overrides)"
  fi
  plan_step=$((plan_step + 1)); log "${plan_step}. validate the archived binary"
  note "file ${ARCHIVED_APP_PATH}/${SCHEME_NAME} ; lipo -info ${ARCHIVED_APP_PATH}/${SCHEME_NAME}"
  note "vtool -show-build ${ARCHIVED_APP_PATH}/${SCHEME_NAME}   # reject IOSSIMULATOR"
  plan_step=$((plan_step + 1)); log "${plan_step}. export the IPA"
  note "cp ${options} ${EXPORT_OPTIONS_GENERATED} ; plutil -lint ${EXPORT_OPTIONS_GENERATED}"
  note "xcodebuild -exportArchive -archivePath ${ARCHIVE_PATH} -exportPath ${export_dir} -exportOptionsPlist ${EXPORT_OPTIONS_GENERATED}"
  note "(method ${EXPORT_METHOD_PRIMARY}, falling back to ${EXPORT_METHOD_FALLBACK} on newer Xcode)"
  if [ "$MODE" = "unsigned" ]; then
    plan_step=$((plan_step + 1)); log "${plan_step}. manual packaging fallback (run when the export is unavailable or signed)"
    note "mkdir -p ${PAYLOAD_DIR}"
    note "ditto ${ARCHIVED_APP_PATH} ${PAYLOAD_APP}"
    note "rm -rf ${PAYLOAD_APP}/_CodeSignature"
    note "rm -f ${PAYLOAD_APP}/embedded.mobileprovision"
    note "( cd ${DIST_DIR} && zip -qry -X $(basename "${out_ipa}") Payload )"
  fi
  plan_step=$((plan_step + 1)); log "${plan_step}. validate + verify + hash"
  note "unzip -Z1 ${out_ipa} | grep Payload/HTMLRunner.app/{HTMLRunner,Info.plist,Assets.car}"
  note "bash ${VERIFY_SCRIPT} ${out_ipa}"
  note "shasum -a 256 ${out_ipa} >> ${SUMS_FILE}"
  log "dry run complete: nothing was built, nothing was written."
}

if [ "${DRY_RUN}" -eq 1 ]; then
  print_plan
  exit 0
fi

# ---------------------------------------------------------------------------
# 6. Preflight
# ---------------------------------------------------------------------------
printf '\n[build] ==== preflight ====\n'

if [ "$(uname -s)" != "Darwin" ]; then
  err "this script must run on macOS (uname -s reports '$(uname -s)')."
  err "It drives Apple's xcodebuild, which only exists on macOS with Xcode installed."
  err "Run these steps on a Mac (see mac/README.md), or use mac/ci-github-actions.yml on a macOS CI runner."
  exit 1
fi

if ! command -v xcodebuild >/dev/null 2>&1; then
  err "xcodebuild not found on PATH."
  err "Install Xcode from the App Store, then select it (Xcode > Settings > Locations > Command Line Tools)."
  exit 1
fi

for tool in xcrun lipo file plutil shasum zip unzip tee; do
  if ! command -v "${tool}" >/dev/null 2>&1; then
    err "required tool '${tool}' not found on PATH."
    err "It ships with macOS/Xcode; check that /usr/bin is on PATH and the command line tools are installed (xcode-select -p)."
    exit 1
  fi
done

XCODE_SELECT_PATH="$(xcode-select -p 2>/dev/null || true)"
log "xcode-select -p                        : ${XCODE_SELECT_PATH:-<not set>}"
case "${XCODE_SELECT_PATH}" in
  */CommandLineTools) warn "xcode-select points at the standalone Command Line Tools; a full Xcode is required to build for iOS." ;;
esac

XCODE_VERSION_RAW="$(xcodebuild -version 2>&1 || true)"
if [ -z "${XCODE_VERSION_RAW}" ]; then
  die "xcodebuild -version produced no output - the Xcode installation looks broken."
fi
log "xcodebuild -version:"
printf '%s\n' "${XCODE_VERSION_RAW}" | while IFS= read -r line; do note "${line}"; done

XCODE_MAJOR="$(printf '%s\n' "${XCODE_VERSION_RAW}" | sed -n 's/^Xcode[[:space:]][[:space:]]*\([0-9][0-9]*\).*/\1/p')"
XCODE_MAJOR="${XCODE_MAJOR%%$'\n'*}"
case "${XCODE_MAJOR}" in ''|*[!0-9]*) XCODE_MAJOR="" ;; esac
if [ -n "${XCODE_MAJOR}" ]; then
  log "Xcode major version                    : ${XCODE_MAJOR}"
else
  warn "could not parse the Xcode major version from '${XCODE_VERSION_RAW%%$'\n'*}'."
fi

if command -v swift >/dev/null 2>&1; then
  log "swift --version:"
  swift --version 2>&1 | while IFS= read -r line; do note "${line}"; done
else
  warn "swift not found on PATH (it normally ships with Xcode); continuing anyway."
fi

SDK_VERSION="$(xcrun --sdk iphoneos --show-sdk-version 2>/dev/null || true)"
SDK_PATH="$(xcrun --sdk iphoneos --show-sdk-path 2>/dev/null || true)"
if [ -z "${SDK_VERSION}" ]; then
  err "no iOS device SDK found (xcrun --sdk iphoneos --show-sdk-version failed)."
  err "Fixes: select a full Xcode (Xcode > Settings > Locations), or install the iOS platform"
  err "       (Xcode > Settings > Components / 'xcodebuild -downloadPlatform iOS')."
  exit 1
fi
log "iPhoneOS SDK version                   : ${SDK_VERSION}"
log "iPhoneOS SDK path                      : ${SDK_PATH}"
log "IPHONEOS_DEPLOYMENT_TARGET (pinned)    : ${DEPLOYMENT_TARGET}"
log "PRODUCT_BUNDLE_IDENTIFIER (expected)   : ${BUNDLE_ID_EFFECTIVE}${PRODUCT_BUNDLE_IDENTIFIER_ENV:+ (from environment)}"

SDK_MAJOR="${SDK_VERSION%%.*}"
DEPLOY_MAJOR="${DEPLOYMENT_TARGET%%.*}"
case "${SDK_MAJOR}" in ''|*[!0-9]*) SDK_MAJOR="" ;; esac
case "${DEPLOY_MAJOR}" in ''|*[!0-9]*) DEPLOY_MAJOR="" ;; esac

if [ -n "${SDK_MAJOR}" ] && [ -n "${DEPLOY_MAJOR}" ]; then
  if [ "${SDK_MAJOR}" -lt "${DEPLOY_MAJOR}" ]; then
    err "installed iOS SDK ${SDK_VERSION} is OLDER than the deployment target ${DEPLOYMENT_TARGET}."
    err "The deployment target can never be higher than the SDK version, so the build cannot succeed."
    err "Install the matching Xcode (iOS ${DEPLOY_MAJOR} needs Xcode ${DEPLOY_MAJOR} or newer), or lower the target explicitly:"
    err "  IOS_DEPLOYMENT_TARGET=${SDK_VERSION} bash mac/build.sh"
    err "(lowering it can break code that uses newer iOS APIs - prefer updating Xcode.)"
    exit 1
  fi
  if [ "${SDK_MAJOR}" -gt "${DEPLOY_MAJOR}" ]; then
    log "SDK is newer than the deployment target (${SDK_VERSION} > ${DEPLOYMENT_TARGET}) - expected and supported;"
    note "such builds are the normal case when a Mac runs a newer Xcode than the app's minimum iOS."
  else
    log "SDK matches the deployment target major version."
  fi
fi

if [ ! -d "${PROJECT_PATH}" ]; then
  err "project not found: ${PROJECT_PATH}"
  err "Run the script from the repository root layout documented in mac/README.md (repo/mac/build.sh + repo/HTMLRunner/HTMLRunner.xcodeproj)."
  exit 1
fi

mkdir -p "${BUILD_DIR}" "${DIST_DIR}"
: > "${LOG_LIST}"
: > "${LOG_BUILD}"
: > "${LOG_ARCHIVE}"
: > "${LOG_EXPORT}"
: > "${LOG_ZIP}"

printf '\n[build] ==== project listing ====\n'
if ! run_logged "${LOG_LIST}" xcodebuild -list -project "${PROJECT_PATH}"; then
  err "xcodebuild -list failed for ${PROJECT_PATH}."
  show_log_tail "${LOG_LIST}"
  exit 1
fi

SCHEMES_SECTION="$(sed -n '/^[[:space:]]*Schemes:/,$p' "${LOG_LIST}" || true)"
printf '%s\n' "${SCHEMES_SECTION}" > "${SCHEME_PROBE_FILE}"
# Grep a *file* here (not a pipe): under `set -o pipefail` a producer feeding a
# `grep -q` that exits on its first match can die from SIGPIPE and wrongly
# report failure for the whole pipeline.
if grep -qE "^[[:space:]]*${SCHEME_NAME}[[:space:]]*\$" "${SCHEME_PROBE_FILE}"; then
  log "scheme '${SCHEME_NAME}' found in the project."
else
  warn "scheme '${SCHEME_NAME}' was not found in the Schemes section of 'xcodebuild -list'."
  warn "The archive step will fail with a 'does not contain a scheme' error until the scheme exists"
  warn "and is shared (Xcode: Product > Scheme > Manage Schemes > Shared)."
fi

printf '\n[build] ==== signing configuration ====\n'
if [ "${MODE}" = "signed" ]; then
  if [ -z "${CODE_SIGN_STYLE}" ]; then
    if [ -n "${PROVISIONING_PROFILE_SPECIFIER}" ]; then
      CODE_SIGN_STYLE="Manual"
    else
      CODE_SIGN_STYLE="Automatic"
    fi
  fi
  # Applied to BOTH the build and the archive step: without a team on the build
  # step, a project whose signing is not configured yet fails before the archive
  # is ever reached.
  SIGN_APPLIED_SETTINGS=(
    "DEVELOPMENT_TEAM=${DEVELOPMENT_TEAM}"
    "CODE_SIGN_STYLE=${CODE_SIGN_STYLE}"
    "CODE_SIGN_IDENTITY=${CODE_SIGN_IDENTITY}"
  )
  if [ -n "${PROVISIONING_PROFILE_SPECIFIER}" ]; then
    SIGN_APPLIED_SETTINGS+=("PROVISIONING_PROFILE_SPECIFIER=${PROVISIONING_PROFILE_SPECIFIER}")
  fi
  if [ "${ALLOW_PROVISIONING_UPDATES}" = "1" ]; then
    SIGN_APPLIED_SETTINGS+=(-allowProvisioningUpdates)
  fi
  log "mode                : signed development IPA (${IPA_SIGNED})"
  log "DEVELOPMENT_TEAM    : ${DEVELOPMENT_TEAM}"
  log "CODE_SIGN_IDENTITY  : ${CODE_SIGN_IDENTITY}"
  log "CODE_SIGN_STYLE     : ${CODE_SIGN_STYLE}"
  log "PROFILE SPECIFIER   : ${PROVISIONING_PROFILE_SPECIFIER:-<not set - the matching profile must already exist on this Mac>}"
else
  SIGN_APPLIED_SETTINGS=()
  log "mode                : unsigned IPA (${IPA_UNSIGNED}) for re-signing tools"
  log "signing             : attempted first with the project's own settings, then retried"
  note "with code signing disabled (CODE_SIGNING_ALLOWED=NO) so that no identity is required."
  if [ -n "${DEVELOPMENT_TEAM}" ]; then
    note "DEVELOPMENT_TEAM is set and will also be offered to -exportArchive."
  fi
fi
if [ -f "HTMLRunner/Resources/Entitlements/HTMLRunner.entitlements" ]; then
  log "entitlements file   : HTMLRunner/Resources/Entitlements/HTMLRunner.entitlements (get-task-allow for debug builds only)"
  note "the unsigned path clears CODE_SIGN_ENTITLEMENTS for the Release archive; re-signing tools apply their own."
else
  warn "HTMLRunner/Resources/Entitlements/HTMLRunner.entitlements not found; the project's entitlements setting will be left untouched."
fi
if [ "${ALLOW_PROVISIONING_UPDATES}" = "1" ]; then
  warn "ALLOW_PROVISIONING_UPDATES=1 - xcodebuild may contact Apple's servers to manage profiles."
fi

# ---------------------------------------------------------------------------
# 7. Idempotency: drop only what this run is about to regenerate.
# ---------------------------------------------------------------------------
printf '\n[build] ==== preparing output directories ====\n'
rm -rf "${PAYLOAD_DIR}"
if [ "${MODE}" = "signed" ]; then
  rm -f "${IPA_SIGNED}"
else
  rm -f "${IPA_UNSIGNED}"
fi
# Drop the checksum file too: it is only rewritten after a fully successful run,
# so a stale copy must never be able to describe artifacts this run removed.
rm -f "${SUMS_FILE}"
rm -rf "${ARCHIVE_PATH}"
if [ "${DO_CLEAN}" -eq 1 ]; then
  log "removing ${DERIVED_DATA_PATH} (--clean)"
  rm -rf "${DERIVED_DATA_PATH}"
fi
mkdir -p "${DIST_DIR}" "${BUILD_DIR}"
log "clean: removed ${PAYLOAD_DIR}, ${ARCHIVE_PATH}$( [ "${MODE}" = "signed" ] && printf ' and %s' "${IPA_SIGNED}" || printf ' and %s' "${IPA_UNSIGNED}" )"

# ---------------------------------------------------------------------------
# 8. Build (compile + link), logged to build/xcodebuild-build.log
# ---------------------------------------------------------------------------
printf '\n[build] ==== build ====\n'
if [ "${MODE}" = "signed" ]; then
  PHASE_ARGS=("${SIGN_APPLIED_SETTINGS[@]}")
  log "build step signing settings: $(quote_args "${SIGN_APPLIED_SETTINGS[@]}")"
else
  PHASE_ARGS=()
fi
if ! xcodebuild_logged "${LOG_BUILD}" \
      -project "${PROJECT_PATH}" \
      -scheme "${SCHEME_NAME}" \
      -sdk iphoneos \
      -configuration Release \
      -destination 'generic/platform=iOS' \
      -derivedDataPath "${DERIVED_DATA_PATH}" \
      build; then
  err "xcodebuild build FAILED - no IPA will be produced."
  if [ "${MODE}" = "signed" ]; then
    err "In signed mode this often means DEVELOPMENT_TEAM/certificate/profile do not match the project."
  fi
  show_log_tail "${LOG_BUILD}"
  exit 1
fi
if log_has_failure_marker "${LOG_BUILD}"; then
  err "xcodebuild reported a failure banner in ${LOG_BUILD} despite a zero exit status."
  show_log_tail "${LOG_BUILD}"
  exit 1
fi
log "build succeeded (log: ${LOG_BUILD})"

# ---------------------------------------------------------------------------
# 9. Archive (packages the .app for export), logged to build/xcodebuild-archive.log
# ---------------------------------------------------------------------------
printf '\n[build] ==== archive ====\n'
ARCHIVE_ARGS=(
  -project "${PROJECT_PATH}"
  -scheme "${SCHEME_NAME}"
  -sdk iphoneos
  -configuration Release
  -destination 'generic/platform=iOS'
  -derivedDataPath "${DERIVED_DATA_PATH}"
  -archivePath "${ARCHIVE_PATH}"
  archive
)

if [ "${MODE}" = "signed" ]; then
  PHASE_ARGS=("${SIGN_APPLIED_SETTINGS[@]}")
  log "archive with: $(quote_args "${SIGN_APPLIED_SETTINGS[@]}")"
  if ! xcodebuild_logged "${LOG_ARCHIVE}" "${ARCHIVE_ARGS[@]}"; then
    err "xcodebuild archive FAILED in signed mode - no signed IPA will be produced."
    show_log_tail "${LOG_ARCHIVE}"
    exit 1
  fi
  if log_has_failure_marker "${LOG_ARCHIVE}"; then
    err "xcodebuild reported a failure banner in ${LOG_ARCHIVE} despite a zero exit status."
    show_log_tail "${LOG_ARCHIVE}"
    exit 1
  fi
else
  log "archive attempt 1/2 with the project's own code signing settings"
  PHASE_ARGS=()
  if xcodebuild_logged "${LOG_ARCHIVE}" "${ARCHIVE_ARGS[@]}"; then
    ARCHIVE_OK=1
  else
    ARCHIVE_OK=0
  fi
  if [ "${ARCHIVE_OK}" -eq 1 ] && log_has_failure_marker "${LOG_ARCHIVE}"; then
    ARCHIVE_OK=0
  fi

  if [ "${ARCHIVE_OK}" -eq 0 ]; then
    if looks_like_signing_failure "${LOG_ARCHIVE}"; then
      warn "archive attempt 1 failed on code signing (no usable identity/profile on this Mac)."
      log "archive attempt 2/2 with code signing disabled: $(quote_args "${SIGN_DISABLED_SETTINGS[@]}")"
      printf '[build] --- retry with code signing disabled ---\n' >> "${LOG_ARCHIVE}"
      rm -rf "${ARCHIVE_PATH}"
      PHASE_ARGS=("${SIGN_DISABLED_SETTINGS[@]}")
      if ! xcodebuild_logged "${LOG_ARCHIVE}" "${ARCHIVE_ARGS[@]}"; then
        err "xcodebuild archive FAILED even with code signing disabled."
        show_log_tail "${LOG_ARCHIVE}"
        exit 1
      fi
      if log_has_failure_marker "${LOG_ARCHIVE}"; then
        err "xcodebuild reported a failure banner in ${LOG_ARCHIVE} despite a zero exit status."
        show_log_tail "${LOG_ARCHIVE}"
        exit 1
      fi
      log "unsigned archive produced (no certificate was involved)."
    else
      err "xcodebuild archive FAILED (and the failure does not look signing related)."
      show_log_tail "${LOG_ARCHIVE}"
      exit 1
    fi
  else
    log "archive attempt 1 succeeded (the project's own signing settings were usable)."
  fi
fi

if [ ! -d "${ARCHIVED_APP_PATH}" ]; then
  err "expected app bundle not found after the archive: ${ARCHIVED_APP_PATH}"
  err "Contents of ${ARCHIVE_PATH}/Products/Applications (if any):"
  if [ -d "${ARCHIVE_PATH}/Products/Applications" ]; then
    find "${ARCHIVE_PATH}/Products/Applications" -maxdepth 1 -mindepth 1 >&2 || true
  fi
  exit 1
fi
log "archived app bundle: ${ARCHIVED_APP_PATH}"

# ---------------------------------------------------------------------------
# 10. Validate the archived binary before it can ever reach an IPA.
#     lipo/file catch Intel or fat-binary mistakes; vtool and
#     CFBundleSupportedPlatforms catch the far more dangerous case of an
#     arm64 SIMULATOR binary (which lipo alone would happily accept).
# ---------------------------------------------------------------------------
printf '\n[build] ==== binary validation ====\n'

APP_INFO_PLIST="${ARCHIVED_APP_PATH}/Info.plist"
[ -f "${APP_INFO_PLIST}" ] || die "archived app has no Info.plist: ${APP_INFO_PLIST}"

plist_read() {
  # plist_read <key> <plist> - never fails, prints nothing when the key is absent.
  local key="$1" plist="$2" value=""
  if [ -x /usr/libexec/PlistBuddy ]; then
    value="$(/usr/libexec/PlistBuddy -c "Print :${key}" "${plist}" 2>/dev/null || true)"
  fi
  if [ -z "${value}" ]; then
    value="$(plutil -extract "${key}" raw -o - "${plist}" 2>/dev/null || true)"
  fi
  printf '%s' "${value}"
  return 0
}

EXECUTABLE_NAME="$(plist_read CFBundleExecutable "${APP_INFO_PLIST}")"
EXECUTABLE_NAME="${EXECUTABLE_NAME%%$'\n'*}"
if [ -z "${EXECUTABLE_NAME}" ]; then
  warn "CFBundleExecutable missing from the archived Info.plist; assuming '${SCHEME_NAME}'."
  EXECUTABLE_NAME="${SCHEME_NAME}"
fi
BUILT_BINARY="${ARCHIVED_APP_PATH}/${EXECUTABLE_NAME}"
[ -f "${BUILT_BINARY}" ] || die "executable not found in the archived app: ${BUILT_BINARY}"
log "executable: ${BUILT_BINARY}"

BUILT_BUNDLE_ID="$(plist_read CFBundleIdentifier "${APP_INFO_PLIST}")"
BUILT_BUNDLE_ID="${BUILT_BUNDLE_ID%%$'\n'*}"
log "CFBundleIdentifier: ${BUILT_BUNDLE_ID:-<missing>}"
if [ -n "${PRODUCT_BUNDLE_IDENTIFIER_ENV}" ] && [ "${BUILT_BUNDLE_ID}" != "${PRODUCT_BUNDLE_IDENTIFIER_ENV}" ]; then
  die "bundle identifier mismatch: expected '${PRODUCT_BUNDLE_IDENTIFIER_ENV}' (from the environment) but the built app reports '${BUILT_BUNDLE_ID}'."
fi
if [ "${BUILT_BUNDLE_ID}" != "${DEFAULT_BUNDLE_ID}" ]; then
  warn "built bundle identifier is '${BUILT_BUNDLE_ID}' (project default is '${DEFAULT_BUNDLE_ID}')."
fi

SUPPORTED_PLATFORMS_0="$(plist_read CFBundleSupportedPlatforms:0 "${APP_INFO_PLIST}")"
SUPPORTED_PLATFORMS_0="${SUPPORTED_PLATFORMS_0%%$'\n'*}"
log "CFBundleSupportedPlatforms[0]: ${SUPPORTED_PLATFORMS_0:-<missing>}"
if [ "${SUPPORTED_PLATFORMS_0}" = "iPhoneSimulator" ]; then
  die "the archived app targets the iOS SIMULATOR (CFBundleSupportedPlatforms=iPhoneSimulator). Refusing to package a simulator build as an IPA."
fi
if [ -n "${SUPPORTED_PLATFORMS_0}" ] && [ "${SUPPORTED_PLATFORMS_0}" != "iPhoneOS" ]; then
  warn "unexpected CFBundleSupportedPlatforms[0]='${SUPPORTED_PLATFORMS_0}' (expected 'iPhoneOS')."
fi

FILE_OUTPUT="$(file "${BUILT_BINARY}" 2>&1 || true)"
LIPO_OUTPUT="$(lipo -info "${BUILT_BINARY}" 2>&1 || true)"
log "file      : ${FILE_OUTPUT}"
log "lipo -info: ${LIPO_OUTPUT}"

case "${FILE_OUTPUT}" in
  *Mach-O*) : ;;
  *) die "'file' does not report a Mach-O binary for ${BUILT_BINARY}: ${FILE_OUTPUT}" ;;
esac

BINARY_DESCRIPTION="${LIPO_OUTPUT} ${FILE_OUTPUT}"

case "${FILE_OUTPUT}" in
  *Mach-O*) : ;;
  *) die "'file' does not report a Mach-O binary for ${BUILT_BINARY}: ${FILE_OUTPUT}" ;;
esac

# `case` rather than `printf ... | grep -q`: with pipefail a grep that exits on
# its first match can kill the producer with SIGPIPE and turn a match into a
# non-zero pipeline status.
case "${BINARY_DESCRIPTION}" in
  *x86_64*|*i386*)
    die "the built binary contains an Intel slice (x86_64/i386): ${LIPO_OUTPUT}. This is a simulator/Mac build - refusing to package it as a device IPA."
    ;;
esac
case "${BINARY_DESCRIPTION}" in
  *arm64*) : ;;
  *) die "the built binary has no arm64 slice: ${LIPO_OUTPUT}. A device IPA must contain arm64." ;;
esac

if command -v vtool >/dev/null 2>&1; then
  VTOOL_OUTPUT="$(vtool -show-build "${BUILT_BINARY}" 2>&1 || true)"
  case "${VTOOL_OUTPUT}" in
    *IOSSIMULATOR*)
      die "the binary declares platform IOSSIMULATOR - this is a simulator build, not a device build. Refusing to package it as an IPA."
      ;;
    *"platform IOS"*)
      log "vtool confirms build platform: IOS (device)"
      ;;
    *)
      warn "vtool -show-build did not report 'platform IOS'; review ${BUILT_BINARY} manually."
      ;;
  esac
else
  warn "vtool not available; relying on lipo/file and CFBundleSupportedPlatforms to reject simulator builds."
fi

log "binary validation passed (arm64 device build)."

# ---------------------------------------------------------------------------
# 11. Export the IPA.
#     Order of preference:
#       a) xcodebuild -exportArchive with the generated ExportOptions.plist
#          (method development / debugging, signingStyle manual, no team);
#       b) the documented manual packaging path: copy the archived .app into
#          dist/Payload, strip _CodeSignature + embedded.mobileprovision, zip it.
#     An unsigned archive can never satisfy -exportArchive, and an export that
#     comes back signed is rejected for the default (unsigned) deliverable, so
#     (b) is the guaranteed path for re-signing tools.
# ---------------------------------------------------------------------------
printf '\n[build] ==== export ====\n'

ipa_looks_signed() {
  # $1 = ipa ; true when the payload carries a code signature or a profile.
  # The zip listing goes to a file first so that no pipeline can be broken by
  # SIGPIPE under `set -o pipefail`.
  [ -f "$1" ] || return 1
  unzip -Z1 "$1" > "${IPA_PROBE_FILE}" 2>/dev/null || return 1
  grep -qE '^Payload/[^/]+\.app/(_CodeSignature/CodeResources|embedded\.mobileprovision)$' "${IPA_PROBE_FILE}"
}

package_unsigned_ipa_from_app() {
  # package_unsigned_ipa_from_app <source .app> <destination .ipa>
  local src_app="$1" dest_ipa="$2" zip_name=""
  zip_name="$(basename "${dest_ipa}")"
  log "manual packaging: ${src_app} -> ${dest_ipa}"
  rm -rf "${PAYLOAD_DIR}"
  mkdir -p "${PAYLOAD_DIR}"
  if command -v ditto >/dev/null 2>&1; then
    ditto "${src_app}" "${PAYLOAD_APP}"
  else
    cp -R "${src_app}" "${PAYLOAD_APP}"
  fi
  log "stripping code signature so the IPA is genuinely unsigned:"
  note "rm -rf ${PAYLOAD_APP}/_CodeSignature"
  note "rm -f  ${PAYLOAD_APP}/embedded.mobileprovision"
  rm -rf "${PAYLOAD_APP}/_CodeSignature"
  rm -f "${PAYLOAD_APP}/embedded.mobileprovision"
  rm -f "${dest_ipa}"
  printf '[build] $ ( cd %s && zip -qry -X %s Payload )\n' "${DIST_DIR}" "${zip_name}" | tee -a "${LOG_ZIP}"
  # -y keeps symlinks as symlinks (required inside iOS bundles) and -X avoids
  # __MACOSX/AppleDouble entries that some re-signing tools reject.
  ( cd "${DIST_DIR}" && zip -qry -X "${zip_name}" Payload ) >>"${LOG_ZIP}" 2>&1
  [ -f "${dest_ipa}" ] || die "zip did not produce ${dest_ipa}"
  log "packaged ${dest_ipa}"
}

PACKAGING_PATH=""
EXPORT_METHOD_USED=""

if [ "${MODE}" = "signed" ]; then
  EXPORT_OPTIONS_TEMPLATE="${EXPORT_OPTIONS_DEVELOPMENT_TEMPLATE}"
  EXPORT_DIR="${EXPORT_DIR_SIGNED}"
  OUT_IPA="${IPA_SIGNED}"
else
  EXPORT_OPTIONS_TEMPLATE="${EXPORT_OPTIONS_UNSIGNED_TEMPLATE}"
  EXPORT_DIR="${EXPORT_DIR_UNSIGNED}"
  OUT_IPA="${IPA_UNSIGNED}"
fi

[ -f "${EXPORT_OPTIONS_TEMPLATE}" ] || die "export options template not found: ${EXPORT_OPTIONS_TEMPLATE}"
cp "${EXPORT_OPTIONS_TEMPLATE}" "${EXPORT_OPTIONS_GENERATED}"
if ! plutil -lint "${EXPORT_OPTIONS_GENERATED}" >>"${LOG_EXPORT}" 2>&1; then
  err "the generated export options plist is not valid: ${EXPORT_OPTIONS_GENERATED}"
  show_log_tail "${LOG_EXPORT}"
  exit 1
fi
log "export options: ${EXPORT_OPTIONS_TEMPLATE} -> ${EXPORT_OPTIONS_GENERATED}"

PLIST_BUDDY="/usr/libexec/PlistBuddy"
if [ ! -x "${PLIST_BUDDY}" ]; then
  die "${PLIST_BUDDY} not found; it is part of macOS and is required to patch the export options."
fi
plist_set() {
  # plist_set <key path> <value> - replaces the value or adds the key.
  local keypath="$1" value="$2"
  if ! "${PLIST_BUDDY}" -c "Set :${keypath} ${value}" "${EXPORT_OPTIONS_GENERATED}" >>"${LOG_EXPORT}" 2>&1; then
    "${PLIST_BUDDY}" -c "Add :${keypath} string ${value}" "${EXPORT_OPTIONS_GENERATED}" >>"${LOG_EXPORT}" 2>&1 \
      || die "could not set ${keypath} in ${EXPORT_OPTIONS_GENERATED} (see ${LOG_EXPORT})"
  fi
}
plist_add_dict() {
  local keypath="$1"
  "${PLIST_BUDDY}" -c "Add :${keypath} dict" "${EXPORT_OPTIONS_GENERATED}" >>"${LOG_EXPORT}" 2>&1 || true
}

if [ -n "${DEVELOPMENT_TEAM}" ]; then
  plist_set "teamID" "${DEVELOPMENT_TEAM}"
  log "export options: teamID=${DEVELOPMENT_TEAM}"
fi

if [ "${MODE}" = "signed" ]; then
  plist_set "signingCertificate" "${CODE_SIGN_IDENTITY}"
  if [ -n "${PROVISIONING_PROFILE_SPECIFIER}" ]; then
    plist_add_dict "provisioningProfiles"
    plist_set "provisioningProfiles:${BUNDLE_ID_EFFECTIVE}" "${PROVISIONING_PROFILE_SPECIFIER}"
    log "export options: provisioningProfiles[${BUNDLE_ID_EFFECTIVE}]=${PROVISIONING_PROFILE_SPECIFIER}"
  else
    # Without an explicit profile, xcodebuild may still resolve one automatically;
    # the export is attempted either way and any failure is reported verbatim.
    warn "no PROVISIONING_PROFILE_SPECIFIER set; -exportArchive may fail to find a profile for ${BUNDLE_ID_EFFECTIVE}."
  fi
fi

EXPORT_ATTEMPT=0
EXPORT_SUCCEEDED=0
for candidate_method in "${EXPORT_METHOD_PRIMARY}" "${EXPORT_METHOD_FALLBACK}"; do
  EXPORT_ATTEMPT=$((EXPORT_ATTEMPT + 1))
  if ! "${PLIST_BUDDY}" -c "Set :method ${candidate_method}" "${EXPORT_OPTIONS_GENERATED}" >>"${LOG_EXPORT}" 2>&1; then
    "${PLIST_BUDDY}" -c "Add :method string ${candidate_method}" "${EXPORT_OPTIONS_GENERATED}" >>"${LOG_EXPORT}" 2>&1 \
      || die "could not set the export method in ${EXPORT_OPTIONS_GENERATED}"
  fi
  printf '[build] --- -exportArchive attempt %d with method=%s ---\n' "${EXPORT_ATTEMPT}" "${candidate_method}" >>"${LOG_EXPORT}"
  log "-exportArchive attempt ${EXPORT_ATTEMPT} with method=${candidate_method}"
  rm -rf "${EXPORT_DIR}"
  mkdir -p "${EXPORT_DIR}"
  if xcodebuild_logged "${LOG_EXPORT}" \
        -exportArchive \
        -archivePath "${ARCHIVE_PATH}" \
        -exportPath "${EXPORT_DIR}" \
        -exportOptionsPlist "${EXPORT_OPTIONS_GENERATED}"; then
    if log_has_failure_marker "${LOG_EXPORT}"; then
      warn "method=${candidate_method} exited 0 but logged a failure banner."
    else
      EXPORT_SUCCEEDED=1
      EXPORT_METHOD_USED="${candidate_method}"
      break
    fi
  fi
  warn "method=${candidate_method} did not produce an IPA (see ${LOG_EXPORT})."
done

EXPORTED_IPA=""
for candidate_ipa in "${EXPORT_DIR}"/*.ipa; do
  [ -f "${candidate_ipa}" ] || continue
  if [ -z "${EXPORTED_IPA}" ]; then
    EXPORTED_IPA="${candidate_ipa}"
  else
    warn "more than one IPA was exported; using ${EXPORTED_IPA} and ignoring ${candidate_ipa}."
  fi
done

if [ "${EXPORT_SUCCEEDED}" -eq 1 ] && [ -n "${EXPORTED_IPA}" ]; then
  log "-exportArchive succeeded (method=${EXPORT_METHOD_USED}) -> ${EXPORTED_IPA}"
  if [ "${MODE}" = "signed" ]; then
    cp "${EXPORTED_IPA}" "${OUT_IPA}"
    if ! ipa_looks_signed "${OUT_IPA}"; then
      rm -f "${OUT_IPA}"
      err "the exported IPA contains no _CodeSignature/embedded.mobileprovision, so it is not actually signed."
      err "Check that DEVELOPMENT_TEAM/PROVISIONING_PROFILE_SPECIFIER point at a valid certificate and profile."
      exit 1
    fi
    PACKAGING_PATH="xcodebuild -exportArchive (signed, method=${EXPORT_METHOD_USED})"
    log "signed IPA written: ${OUT_IPA}"
  else
    if ipa_looks_signed "${EXPORTED_IPA}"; then
      warn "the exported IPA is code signed (it contains _CodeSignature and/or embedded.mobileprovision)."
      log "the primary artifact must be unsigned, so it is rebuilt from the archive instead;"
      note "the signed export is kept at ${EXPORTED_IPA} for reference."
      package_unsigned_ipa_from_app "${ARCHIVED_APP_PATH}" "${OUT_IPA}"
      PACKAGING_PATH="manual Payload zip (exported IPA was signed)"
    else
      cp "${EXPORTED_IPA}" "${OUT_IPA}"
      PACKAGING_PATH="xcodebuild -exportArchive (unsigned, method=${EXPORT_METHOD_USED})"
      log "unsigned IPA written from -exportArchive: ${OUT_IPA}"
    fi
  fi
else
  if [ "${MODE}" = "signed" ]; then
    err "-exportArchive could not produce a signed IPA."
    err "Common causes: wrong DEVELOPMENT_TEAM, missing/expired certificate, profile that does not match"
    err "${BUNDLE_ID_EFFECTIVE}, or a profile that is not installed in the login keychain."
    show_log_tail "${LOG_EXPORT}"
    exit 1
  fi
  warn "-exportArchive could not produce an IPA - this is expected when no signing identity exists."
  note "reason (from ${LOG_EXPORT}):"
  grep -E 'error:|No signing certificate|No profiles for|requires a development team' "${LOG_EXPORT}" 2>/dev/null | tail -n 5 >&2 || true
  log "falling back to the documented manual packaging path (archive -> Payload -> zip)."
  package_unsigned_ipa_from_app "${ARCHIVED_APP_PATH}" "${OUT_IPA}"
  PACKAGING_PATH="manual Payload zip (exportArchive unavailable without a signing identity)"
fi

# ---------------------------------------------------------------------------
# 12. Structure validation of the packaged IPA.
# ---------------------------------------------------------------------------
printf '\n[build] ==== IPA structure validation ====\n'
[ -f "${OUT_IPA}" ] || die "expected IPA is missing: ${OUT_IPA}"

if ! unzip -Z1 "${OUT_IPA}" > "${IPA_LIST_FILE}" 2>/dev/null; then
  rm -f "${OUT_IPA}"
  die "the packaged file is not a readable zip archive: ${OUT_IPA} (removed)."
fi

IPA_STRUCTURE_OK=1
for required_entry in "Payload/${SCHEME_NAME}.app/${EXECUTABLE_NAME}" "Payload/${SCHEME_NAME}.app/Info.plist"; do
  if grep -qx "${required_entry}" "${IPA_LIST_FILE}"; then
    log "found ${required_entry}"
  else
    err "missing from the IPA: ${required_entry}"
    IPA_STRUCTURE_OK=0
  fi
done

if grep -qE "^Payload/[^/]+\.app/Assets\.car\$" "${IPA_LIST_FILE}"; then
  log "found Payload/${SCHEME_NAME}.app/Assets.car"
elif grep -qE "^Payload/[^/]+\.app/[^/]*[Ii]con[^/]*\.(png|jpg)\$" "${IPA_LIST_FILE}"; then
  warn "no Assets.car in the IPA; falling back to a loose icon file (acceptable, but check the app icon)."
else
  err "neither Assets.car nor an icon file is present under Payload/*.app in the IPA."
  IPA_STRUCTURE_OK=0
fi

if grep -qx "Payload/${SCHEME_NAME}.app/PkgInfo" "${IPA_LIST_FILE}"; then
  log "found Payload/${SCHEME_NAME}.app/PkgInfo"
else
  warn "Payload/${SCHEME_NAME}.app/PkgInfo is absent (unusual but not fatal for re-signing tools)."
fi

if grep -qx "Payload/${SCHEME_NAME}.app/embedded.mobileprovision" "${IPA_LIST_FILE}"; then
  warn "the IPA still embeds a provisioning profile; re-signing tools normally replace it."
fi

if [ "${IPA_STRUCTURE_OK}" -ne 1 ]; then
  rm -f "${OUT_IPA}"
  err "IPA structure validation FAILED; the broken artifact was removed and nothing is published."
  err "zip listing written to ${IPA_LIST_FILE}"
  exit 1
fi
log "IPA structure looks correct."

# ---------------------------------------------------------------------------
# 13. Independent verification (mac/verify_ipa.sh) when it is available.
# ---------------------------------------------------------------------------
printf '\n[build] ==== independent verification ====\n'
if [ -f "${VERIFY_SCRIPT}" ]; then
  if ! run_logged "${LOG_VERIFY}" bash "${VERIFY_SCRIPT}" "${OUT_IPA}"; then
    rm -f "${OUT_IPA}"
    err "${VERIFY_SCRIPT} reported problems with ${OUT_IPA}; the artifact was removed."
    exit 1
  fi
  log "verification passed (full output: ${LOG_VERIFY})"
else
  warn "${VERIFY_SCRIPT} not found - skipping the independent verification step."
fi

# ---------------------------------------------------------------------------
# 14. Checksums. Paths are repository-relative, so SHA256SUMS.txt stays portable
#     and can be read from any directory (e.g. `shasum -a 256 -c dist/SHA256SUMS.txt`
#     executed at the repository root).
# ---------------------------------------------------------------------------
printf '\n[build] ==== checksums ====\n'
: > "${SUMS_FILE}"
HASHED_COUNT=0
for candidate_ipa in "${DIST_DIR}"/*.ipa; do
  [ -f "${candidate_ipa}" ] || continue
  shasum -a 256 "${candidate_ipa}" >> "${SUMS_FILE}"
  HASHED_COUNT=$((HASHED_COUNT + 1))
done
if [ "${HASHED_COUNT}" -eq 0 ]; then
  rm -f "${SUMS_FILE}"
  die "no .ipa was found in ${DIST_DIR}/ - refusing to write an empty ${SUMS_FILE}."
fi
log "${SUMS_FILE} covers ${HASHED_COUNT} artifact(s):"
while IFS= read -r sums_line; do note "${sums_line}"; done < "${SUMS_FILE}"

# ---------------------------------------------------------------------------
# 15. Summary
# ---------------------------------------------------------------------------
printf '\n[build] ==== summary ====\n'
log "mode                 : ${MODE}"
log "packaging path       : ${PACKAGING_PATH}"
if [ -n "${EXPORT_METHOD_USED}" ]; then
  log "export method used   : ${EXPORT_METHOD_USED}"
fi
log "Xcode                : ${XCODE_VERSION_RAW%%$'\n'*}"
log "iPhoneOS SDK         : ${SDK_VERSION}"
log "deployment target    : ${DEPLOYMENT_TARGET}"
log "bundle identifier    : ${BUILT_BUNDLE_ID}"

for candidate_ipa in "${DIST_DIR}"/*.ipa; do
  [ -f "${candidate_ipa}" ] || continue
  IPA_BYTES="$(wc -c < "${candidate_ipa}" | tr -d '[:space:]')"
  IPA_HUMAN="$(du -h "${candidate_ipa}" | cut -f1)"
  IPA_HASH="$(shasum -a 256 "${candidate_ipa}" | cut -d' ' -f1)"
  if ipa_looks_signed "${candidate_ipa}"; then
    IPA_SIGNATURE_STATE="SIGNED (development signature + embedded profile present)"
  else
    IPA_SIGNATURE_STATE="UNSIGNED (no _CodeSignature, no embedded.mobileprovision)"
  fi
  printf '[build] artifact           : %s\n' "${candidate_ipa}"
  printf '[build]   size             : %s (%s bytes)\n' "${IPA_HUMAN}" "${IPA_BYTES}"
  printf '[build]   sha256           : %s\n' "${IPA_HASH}"
  printf '[build]   signature        : %s\n' "${IPA_SIGNATURE_STATE}"
done

if [ "${MODE}" = "signed" ]; then
  log "${IPA_SIGNED} is a SIGNED development IPA: it is tied to DEVELOPMENT_TEAM=${DEVELOPMENT_TEAM}"
  note "and to the provisioning profile used at export time. Install it with Xcode or Apple Configurator 2."
else
  log "${OUT_IPA} is UNSIGNED - no development certificate is locked in, which is what"
  note "a re-signing / sideloading tool such as NB助手 expects. It must be signed with your own"
  note "certificate and provisioning profile before iOS will install it."
fi
log "logs                 : ${LOG_LIST}, ${LOG_BUILD}, ${LOG_ARCHIVE}, ${LOG_EXPORT}, ${LOG_ZIP}, ${LOG_VERIFY}"
log "checksums            : ${SUMS_FILE}  (verify with: shasum -a 256 -c ${SUMS_FILE})"
log "done."
