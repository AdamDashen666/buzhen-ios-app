# HTMLRunner iOS build scripts

Turns `HTMLRunner/HTMLRunner.xcodeproj` (scheme `HTMLRunner`) into an IPA on a Mac.
Zero third-party dependencies, no network access, no `sudo`.

| File | Purpose |
| --- | --- |
| `mac/build.sh` | preflight, build, archive, package, verify and hash the IPA |
| `mac/verify_ipa.sh` | standalone checker for any `.ipa` (no Xcode, no device needed) |
| `mac/ExportOptions-unsigned.plist` | export options for the unsigned primary artifact |
| `mac/ExportOptions-development.plist` | export options for the signed development artifact |
| `mac/ci-github-actions.yml` | GitHub Actions workflow (copy to `.github/workflows/`) |

## Prerequisites

* macOS 13 or newer (macOS 14/15 recommended) with a full **Xcode 15 or newer** installed.
  The deployment target is iOS 17.0, so an older Xcode cannot build the project; `build.sh`
  detects that and stops with an explanation.
* Xcode selected (Xcode > Settings > Locations > Command Line Tools, or `xcode-select -p`
  must print a path inside `Xcode.app`, not `CommandLineTools`).
* Nothing else: `unzip`, `zip`, `shasum`, `plutil`, `PlistBuddy`, `lipo`, `file` and
  `vtool` all ship with macOS or Xcode. No Homebrew packages are required.

## Commands

```bash
bash mac/build.sh                 # unsigned dist/HTMLRunner.ipa + dist/SHA256SUMS.txt
bash mac/build.sh --clean         # same, after wiping build/DerivedData (full rebuild)
bash mac/build.sh --dry-run       # print every command it would run, execute nothing
bash mac/build.sh -h              # usage and every environment override

bash mac/verify_ipa.sh dist/HTMLRunner.ipa        # independent verification, exit 1 on failure
shasum -a 256 -c dist/SHA256SUMS.txt              # re-check the checksums (run at the repo root)
```

Signed development IPA (needs a certificate and a profile in your keychain):

```bash
DEVELOPMENT_TEAM=ABCDE12345 \
PROVISIONING_PROFILE_SPECIFIER="iOS Team Provisioning Profile: com.htmlrunner.ipad" \
bash mac/build.sh --signed       # -> dist/HTMLRunner-signed.ipa
```

## What `build.sh` does

1. **Preflight** - checks that it runs on macOS, prints `xcode-select -p`,
   `xcodebuild -version`, `swift --version` and the `iphoneos` SDK version, compares the SDK
   against the iOS 17.0 deployment target (and fails early if the SDK is older), then runs
   `xcodebuild -list` and checks that the `HTMLRunner` scheme exists.
2. **Build** - `xcodebuild -project HTMLRunner/HTMLRunner.xcodeproj -scheme HTMLRunner
   -sdk iphoneos -configuration Release -destination 'generic/platform=iOS'
   -derivedDataPath build/DerivedData build`, tee'd to `build/xcodebuild-build.log`. The exit
   status of `xcodebuild` (not of `tee`) decides success, so a failed build can never be masked.
3. **Archive** - the same settings plus `-archivePath build/HTMLRunner.xcarchive archive`
   (`build/xcodebuild-archive.log`). If that fails only on code signing, it retries once with
   `CODE_SIGNING_ALLOWED=NO`, which needs no certificate at all.
4. **Binary validation** - `file` and `lipo -info` on the archived executable must report an
   arm64 Mach-O with no x86_64/i386 slice, `vtool` must not report `IOSSIMULATOR`, and
   `CFBundleSupportedPlatforms` must be `iPhoneOS`. A simulator build can never become an IPA.
5. **Export** - tries `xcodebuild -exportArchive` first (trying `method = development`, then
   `debugging` on newer Xcode). If no signing identity exists this legitimately fails, and the
   script falls back to the manual packaging path: copy the archived `.app` into
   `dist/Payload/HTMLRunner.app`, remove `_CodeSignature` and `embedded.mobileprovision`, then
   `zip -qry -X` it into `dist/HTMLRunner.ipa`. The log always states which path was used and why.
6. **Validation** - the IPA must contain `Payload/HTMLRunner.app/HTMLRunner`, its `Info.plist`
   and `Assets.car` (or an icon), otherwise the artifact is deleted and the script exits 1.
   It then runs `mac/verify_ipa.sh` and writes `dist/SHA256SUMS.txt` (repository-relative paths).
   Nothing is ever fabricated: a failed build exits non-zero and writes no IPA.

## Getting the unsigned IPA for a re-signing tool (NB助手)

The default output `dist/HTMLRunner.ipa` is **unsigned** on purpose: it carries no development
certificate, so a re-signing tool can sign it with your own Apple ID. Upload that file to the
tool; the signed development variant is not needed for this workflow. `dist/Payload/` is only a
staging copy of the packaged bundle and can be deleted.

## Installing

* **Sideload tool (NB助手 or similar)** - give it the unsigned `dist/HTMLRunner.ipa`; it signs
  and installs it over USB/Wi-Fi. This is the supported path for the unsigned artifact.
* **Apple Configurator 2** - connect the iPad, then drag a *signed* IPA (`dist/HTMLRunner-signed.ipa`)
  onto the device window. An unsigned IPA is rejected here.
* **Xcode** - Window > Devices and Simulators, select the device, click `+` under
  "Installed Apps" and choose the signed IPA.
* Trust the developer profile on the iPad (Settings > General > VPN & Device Management) after
  the first install.

## CI

Copy `mac/ci-github-actions.yml` to `.github/workflows/build-ipa.yml`, commit and push. It runs
`build.sh`, then `verify_ipa.sh`, then uploads `dist/` as a build artifact, on a macOS runner and
with no secrets. Optionally set the repository *variable* `XCODE_APP` (for example
`/Applications/Xcode_16.4.app`) to pin a specific Xcode; the workflow selects it through
`DEVELOPER_DIR`, which needs no `sudo`.

## Troubleshooting

| Symptom | Cause and fix |
| --- | --- |
| `xcodebuild: error: SDK "iphoneos" cannot be located` | Command Line Tools are selected instead of Xcode, or the iOS platform is not installed. Pick Xcode in Xcode > Settings > Locations, or install the iOS component in Xcode > Settings > Components. `build.sh` reports this in its preflight. |
| `The iOS deployment target 'IPHONEOS_DEPLOYMENT_TARGET' is set to 17.0, but the range of supported deployment target versions is 12.0 to 16.x` | Xcode is too old for iOS 17. Install Xcode 15+ (or pass `IOS_DEPLOYMENT_TARGET=16.0`, which can break iOS 17 APIs). `build.sh` fails early with this explanation. |
| `warning: ... deployment target ... is set to 17.0, but the range ... is 12.0 to 18.x` | SDK newer than the deployment target: completely normal and safe. `build.sh` prints it as an informational note, not an error. |
| `No signing certificate "Apple Development" found` | Expected without a certificate. `build.sh` detects the signing-only failure, rebuilds with code signing disabled and packages the unsigned IPA anyway. For the signed variant, install a certificate (Xcode > Settings > Accounts). |
| `Signing for "HTMLRunner" requires a development team` | `--signed` without `DEVELOPMENT_TEAM`. Pass your 10-character team ID; the script refuses to run signed mode without it. |
| `exportArchive: No profiles for 'com.htmlrunner.ipad' were found` | Normal for the unsigned path; `-exportArchive` cannot export an unsigned archive. The manual `Payload` zip path is used instead and is logged as such. |
| `Provisioning profile "..." doesn't match the entitlements` / does not include the application-identifier | The profile belongs to another bundle ID or team. Pass the correct `PROVISIONING_PROFILE_SPECIFIER`, check `PRODUCT_BUNDLE_IDENTIFIER`, or re-download the profile. |
| `unknown method` or a deprecation warning about `development` | Xcode 15+ renamed the export method to `debugging`. `build.sh` retries automatically; when calling `xcodebuild -exportArchive` by hand, edit `method` in the `ExportOptions` plist. |
| `dyld: Library not loaded: @rpath/...` at launch | A framework was not embedded, or the re-signing tool did not sign every nested binary. Verify with `mac/verify_ipa.sh` (it lists embedded frameworks) and re-sign the whole bundle. |
| `*** The project ... does not contain a scheme named "HTMLRunner"` | The scheme is not shared. Xcode: Product > Scheme > Manage Schemes > check "Shared". |
| `the built binary contains an Intel slice` / `platform IOSSIMULATOR` | A simulator build reached the packaging step. `build.sh` refuses to package it; build with `-sdk iphoneos -destination 'generic/platform=iOS'` as the script does. |
| `verify_ipa.sh` reports `UIDeviceFamily` without 2 | The app is iPhone-only. Set the target's device family to "iPhone and iPad" (or `TARGETED_DEVICE_FAMILY = 1,2`). |

Environment overrides (all optional): `BUNDLE_IDENTIFIER` / `PRODUCT_BUNDLE_IDENTIFIER`,
`IOS_DEPLOYMENT_TARGET`, `DEVELOPMENT_TEAM`, `PROVISIONING_PROFILE_SPECIFIER`,
`CODE_SIGN_IDENTITY`, `CODE_SIGN_STYLE`, `ALLOW_PROVISIONING_UPDATES=1`, `DEVELOPER_DIR`.
Logs land in `build/xcodebuild-*.log` and `build/verify_ipa.log`.
