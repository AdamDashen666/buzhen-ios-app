# 测试计划与执行状态

本文件是你给出的测试计划（第十节）的**逐项执行说明**，并明确标注每一项的真实状态与依据。

状态取值只有这几种，**互不替代**：

| 状态 | 含义 |
|---|---|
| `ran-webkit` | 在**桌面 WebKit 引擎**（Playwright 27.2）中真实执行并通过 |
| `ran-node` | 由 Node.js 逻辑测试真实执行 |
| `static-check` | 仅通过源码阅读 / 工程校验 / 算法级测试确认；**未在 iOS 环境执行** |
| `not-run-sim` | 需要 iOS 模拟器（本机无 macOS / Xcode） |
| `not-run-device` | 需要真机 iPad |
| `not-run` | 未执行，且无可信替代方案 |

机器可读版本在 `test-output/TEST-REPORT.json`（由 `python project-tests/run_all.py` 生成）。
**本文件与那份 JSON 保持一致；若有冲突，以 JSON 为准（它是执行结果，本文件是说明）。**

---

## 一、当前环境的执行边界

```
宿主          Windows 11 (10.0.26200) / AMD64
macOS         ✗    Xcode ✗    iOS SDK ✗    iOS 模拟器 ✗
iPad          ✗    签名证书 ✗  描述文件 ✗
可用的浏览器引擎  Playwright WebKit 27.2（已在本机缓存）
```

因此：

* **可以在本机做的**：算法与协议层测试（Node）、夹具在真实 WebKit 引擎中的行为验证、工程结构与源码的机械校验。
* **必须由 macOS 做的**：编译、归档、导出 IPA、`xcodebuild` 的任何一步。
* **必须由真机做的**：安装、启动、导入大项目、真机内存水位、WebContent 终止、JIT 相关对照实验、长时间稳定性。

---

## 二、逐项状态

### 1. 简单 HTML 页面 — `ran-webkit`

* 夹具：`project-tests/fixtures/01-simple/index.html`
* 断言：标题渲染、内联脚本执行并写入时间戳。
* 意义：这是**最小前提**。若它在真机上也失败，问题一定在导入或加载环节，与 WebGL / 内存 / ES Modules 无关。
* 真机未测。

### 2. 引用同目录 CSS 和 JS 的 HTML — `ran-webkit`

* 夹具：`project-tests/fixtures/02-css-js/`
* 断言：外部 JS 已执行（`window.FIXTURE_LOADER_LOADED === true`）、外部 CSS 生效（计算样式为 `rgb(0, 102, 204)`）、子目录 1×1 PNG 加载成功。
* 覆盖：`<link>`、`<script src>`、`<img src>` 三种子资源请求。

### 3. 使用 ES Modules 的 HTML — `ran-webkit`

* 夹具：`project-tests/fixtures/03-es-modules/`（`index.html` → `modules/scene.js` → `modules/math.js`）
* 断言：模块执行完成、两级相对导入都成功、导出函数计算结果正确。
* **重要边界**：以上是在 **HTTP 语义**下验证的。`file://` 下 ES Module 通常会被 WebKit 的同源策略拦截——
  这不是缺陷，而正是本地 HTTP 服务功能存在的理由。**`file://` 下的真实行为必须在真机上验证。**

### 4. 使用 fetch() 读取本地 JSON 的 HTML — `ran-webkit`

* 夹具：`project-tests/fixtures/04-fetch/`
* 用例：`data/config.json`、**`data/中文 文件名.json`**（中文 + 空格）、`shaders/basic.vert`（文本）、
  `data/binary.bin`（256 KiB `arrayBuffer`）、以及一个**不存在的文件**（预期失败）。
* 断言：成功用例 ≥ 4、失败用例确实失败、`done === true`。
* 同样地，`file://` 下 `fetch` 抛 `TypeError` 属预期；请用本地服务模式复测。

### 5. 使用 Three.js 创建基础 3D 场景 — `ran-webkit`

* 夹具：`project-tests/fixtures/05-threejs/`
* 覆盖：WebGL2 上下文创建、**外部着色器文件通过 fetch 加载**（`shaders/box.vert` / `box.frag`）、
  GLSL 300 es 编译与链接、VBO/VAO 与索引绘制、透视投影矩阵、逐帧 `requestAnimationFrame` 渲染循环、uniform 更新、渲染器标识读取。
* **未使用真实 Three.js**：无网络环境无法拉取 CDN，仓库内也不适合放 700 KB 的第三方 bundle。
  夹具使用 API 形态一致的 `vendor/mini-three.js`。若要换成真实的：把 `three.module.js` 放进 `vendor/`，
  改 `index.html` 里的 import 一行即可，使用方式完全相同。

### 6. WebGL2 能力检测 — `ran-webkit`

* 夹具：`project-tests/fixtures/06-webgl2-capabilities/`
* 输出：`VERSION` / `SHADING_LANGUAGE_VERSION` / `VENDOR` / `RENDERER`（含 `WEBGL_debug_renderer_info` 可用时的
  `UNMASKED_*`）、16 项限制值、扩展清单（重点检查 ASTC/ETC/S3TC/KTX2/float 纹理等）、
  GLSL 300 es 编译与链接、**实际绘制一帧并检查 `glGetError()`**、`readPixels` 往返。
* 这些数字直接决定「多大的纹理、多少采样、多少 uniform 才不会静默失败」。

### 7. GLSL 着色器编译 — `ran-webkit`

* 夹具：`project-tests/fixtures/07-glsl/`，6 个用例：
  1. 最基本的 300 es 着色器（期望成功）
  2. 循环 + 纹理采样（游戏常见写法，期望成功）
  3. 故意语法错误（期望失败）
  4. 类型不匹配 `vec3` 赋给 `vec4`（期望失败）
  5. 调用未声明函数（期望失败）
  6. 高精度数学 + `fract(sin(...))` 噪声（期望成功）
* 断言的重点是**编译器是否按预期拒绝错误的着色器并给出可读日志**——若错误的着色器被静默接受，说明环境有问题。

### 8. 大型纹理的分阶段加载 — `ran-webkit`

* 夹具：`project-tests/fixtures/08-texture-staging/`
* 流程：512 → 1024 → 2048 → 4096 逐阶段 `texImage2D` → 绑定到 FBO 并实际清屏绘制 → `getError()` →
  立即 `deleteTexture` → 让出一帧。
* 断言：至少完成 3 个阶段、每阶段 `glError === 0`、测试正常结束。
* **4096² RGBA 单张就是 64 MiB。** 这正是「不要一次性把所有纹理读进内存」的现实代价。
* 若真机上此步导致页面进程被终止，App 会记录 `webcontent.terminated` 事件——那是有用的信号，不是 App 的 bug。

### 9. 大量小文件的导入 — `static-check`

* 覆盖方式：`project-tests/harness/logic.test.js` 验证导入计划算法（入口选择、同目录资源白名单、目录名净化），
  `tools/verify_project.py` 验证 `ProjectStore` 的流式复制实现所依赖的结构，源码检查确认分批读取路径。
* **必须真机验证的部分**：iOS 文件提供器（iCloud Drive / 本地 / 第三方 provider）返回的
  security-scoped URL 行为、大批量文件的复制耗时与进度更新、取消后的清理、磁盘空间不足时的错误分支。
* 建议的真机用例：导入一个 ≥ 5000 个小文件的项目，中途取消一次，再完整导入一次，对照文件数与体积。

### 10. 中大型项目的目录结构保留 — `static-check`

* 夹具：`project-tests/fixtures/10-structure-and-encoding/`（由 `make_tree.py` 生成）
* 覆盖：中文目录与文件名、文件名中的空格、需要百分号编码的 `#`（`贴图#1.png` → `%23`）、
  大写扩展名（`Assets/TEXTURE.PNG`、`SHADER.VERT`）、5 层深目录、零字节文件、带 BOM 的文本。
* 已在 WebKit 中验证：这些路径在 HTTP 语义下**可以**被正确解析与加载（夹具 10 的断言全部通过）。
* **必须真机验证的部分**：App 复制这些文件名到 APFS 时是否忠实保留。
* **已记录的真实限制**：APFS 在 iPad 上默认大小写不敏感，因此 `Texture.png` 与 `texture.png` **无法共存**。
  夹具**故意不**制造这种无法在目标设备上存在的用例，而是在 README 中说明这一限制。

### 11. 页面进程终止后的错误提示与恢复 — `static-check`

* 实现位置：`HTMLRunner/Web/WebViewCoordinator.swift` 的 `webViewWebContentProcessDidTerminate(_:)`
  与 `RunView` 的状态卡片。
* 记录内容：终止次数、当时的 App 进程 resident / phys_footprint、设备空闲内存、热状态、
  距上次诊断事件的秒数，以及**明确声明「系统未提供终止原因」**（不把内存压力写成结论）。
* UI：明确的「网页进程被系统终止」卡片 + 「重新加载（状态会丢失）」按钮，并说明页面内部进度无法恢复。
* **未能执行的原因**：非 iOS 环境无法触发 WebContent 进程终止。真机上可通过长时间运行大场景或
  人为制造内存压力来触发。

### 12. 长时间运行时的稳定性 — `not-run`

* **未执行，且无可信替代。** 需要真机连续运行数小时，同时观察 App 内存走势（诊断页每 3 秒采样）、
  热状态变化、WebContent 终止次数与 FPS 稳定性。
* 真机建议：运行夹具 05（持续渲染）或你的真实项目，每 15 分钟记录一次诊断页数据，观察 `phys_footprint` 是否持续上升。

### 13. JIT 测试页面在不同签名和授权状态下的表现 — `static-check`

* 已实现并在 WebKit 中运行：
  * 夹具 `09-jit-benchmark`：能力事实（WebAssembly 存在性/校验/实例化、`new Function`、WebGL2）+ 性能测量
    （数值循环、对象分配、字符串操作、WebAssembly 调用）+ 完整测试条件（UA、协议、可见性、核数、
    `performance.memory`、运行时长）+ 原始 JSON。
  * App 内探测脚本 `HTMLRunner/Resources/Web/WebProbe.js`：同一套测量的可注入版本，输出带
    `confidence.javascriptJitState = "cannot-be-determined-from-a-web-page"`。
  * 诊断页的「JIT 诊断」区：显示 App 进程的 `P_TRACED` 状态，并明确写出**网页进程的 JIT 状态无法确认**。
* **未能执行的原因**：需要真机 + 能够改变签名/授权状态的工具，且需要「锁定模式开/关」两组对照。
* **唯一有对照意义的实验**（请在真机上做）：
  1. 关闭锁定模式，运行夹具 09，记录能力事实与性能数字；
  2. 打开 **设置 → 隐私与安全性 → 锁定模式**，重启设备，重复测量；
  3. 对比 `WebAssembly` 是否仍然存在。锁定模式会显式设置 `useWasm() = false` 并关闭 JSC 的 JIT，
     因此**这一组差异是唯一能真实反映 JIT 状态的实验**。
* 原理、证据与引用见 [`../HTMLRunner/JIT_NOTES.md`](../HTMLRunner/JIT_NOTES.md)。
* **重要**：性能数字**不是** JIT 证据。热降频、后台限速、缓存状态都能造成数倍差异。

---

## 三、如何在本机复现全部已执行的检查

```bash
# 全部一次跑完，并生成 test-output/TEST-REPORT.json
python project-tests/run_all.py

# 或分别执行
python tools/check_swift.py                     # Swift 结构检查
python tools/verify_project.py                  # Xcode 工程与资源校验（90 项）
node   project-tests/harness/logic.test.js      # 纯逻辑测试（52 项）
python project-tests/run_tests.py               # 桌面 WebKit 夹具（10 个自动化夹具）
python project-tests/run_tests.py --only "05,06" --browser chromium   # 用另一引擎交叉验证

# 重新生成测试夹具中的二进制与目录树
python project-tests/fixtures/make_binary_fixtures.py
python project-tests/fixtures/10-structure-and-encoding/make_tree.py
```

浏览器定位与依赖安装是自动的：脚本会寻找本机已缓存的 Playwright 浏览器，
**不会下载浏览器**（`PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD=1`）；找不到任何浏览器时会以退出码 2 明确失败，
而不是静默跳过测试。

---

## 四、真机验收清单（拿到 IPA 后按顺序做）

- [ ] 安装并启动，确认诊断页显示正确的 App 版本、`arm64 / Device` 编译目标与设备型号标识
- [ ] 导入 `project-tests/fixtures` 整个文件夹，核对文件数与体积
- [ ] 依次运行夹具 01 → 02 → 06 → 07 → 08，记录哪些通过
- [ ] 切换到「本地服务」模式，再运行夹具 03 → 04 → 10，确认 `file://` 下的失败在 HTTP 下消失
- [ ] 运行夹具 05，观察 FPS 与热状态变化（诊断页每 3 秒采样）
- [ ] 导入一个数 GB 的真实项目，观察导入进度、内存水位与是否有卡顿；中途取消一次
- [ ] 运行真实项目，逐项记录 `docs/TEST-PLAN.md` 第 9、10、11 项中标记为「必须真机验证」的行为
- [ ] 长时间运行（≥ 1 小时），记录 `phys_footprint` 走势与 `webcontent.terminated` 次数
- [ ] 执行第 13 项的锁定模式对照实验
- [ ] 在侧载工具里确认 App 是否出现在 JIT 列表中，并记录工具名称与版本（**这是工具侧的事实，不是 App 的能力**）
- [ ] 导出诊断报告，附在验收记录里

---

## 五、结论口径

* 本机共执行 **4 个套件**：Swift 结构检查（0 问题）、工程与资源校验（90 项，0 错误）、
  逻辑测试（52/52）、WebKit 夹具（10/10 夹具、41/41 断言）。
* 测试计划 13 项中：**8 项 `ran-webkit`**、**4 项 `static-check`**、**1 项 `not-run`**。
* **模拟器运行：从未发生。真机运行：从未发生。IPA 构建：从未发生。**
