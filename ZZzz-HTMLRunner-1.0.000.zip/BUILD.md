# BUILD.md — 构建与打包

**本文件描述的是在 macOS 上如何构建。当前开发环境是 Windows，没有 Xcode，因此本仓库中不存在已生成的 IPA。**
实际执行结果与阻塞原因见 [`DELIVERY-REPORT.md`](DELIVERY-REPORT.md)。

---

## 0. 先决条件

| 项目 | 要求 | 检查命令 |
|---|---|---|
| 操作系统 | macOS（本工程用 Xcode 16 系列验证配置） | `sw_vers` |
| Xcode | 15.0 或更高；建议 16.x | `xcodebuild -version` |
| 命令行工具 | 指向 Xcode，而不是 CommandLineTools | `xcode-select -p` → 应输出 `.../Xcode.app/Contents/Developer` |
| iOS SDK | 17.0 或更高 | `xcrun --sdk iphoneos --show-sdk-version` |
| 第三方依赖 | **无**。不使用 CocoaPods / SPM 包 / Homebrew 工具 | — |

如果 `xcode-select -p` 指向 `/Library/Developer/CommandLineTools`，先修正：

```bash
sudo xcode-select -s /Applications/Xcode.app/Contents/Developer
```

> 部署目标设为 **iOS 17.0**。若你的 Xcode 较旧（SDK < 17），`mac/build.sh` 会直接报错并说明原因，
> 而不是产出一个半成品。

---

## 1. 一条命令构建未签名 IPA（推荐给二次签名工具）

```bash
bash mac/build.sh
```

产出：

```
dist/HTMLRunner.ipa          未签名，供 NB 助手等工具重签
dist/SHA256SUMS.txt          dist/*.ipa 的 SHA-256
build/xcodebuild-build.log   完整构建日志
build/xcodebuild-archive.log 归档日志
build/HTMLRunner.xcarchive   归档产物
```

脚本按顺序执行：

1. **预检**：`xcodebuild -list`、Xcode/SDK 版本、`xcode-select` 指向。
2. **构建**：`-sdk iphoneos -configuration Release -destination 'generic/platform=iOS' -derivedDataPath build/DerivedData`。
3. **归档**：`-archivePath build/HTMLRunner.xcarchive archive`。
4. **二进制校验**：必须是 **arm64 Mach-O**，且不是 `IOSSIMULATOR` 平台 —— 这是防止把模拟器产物伪装成真机 IPA 的硬性闸门。
5. **导出 IPA**：先尝试 `xcodebuild -exportArchive`；若因缺少签名身份失败，或导出结果竟然是已签名的，则走**手动打包**：
   `ditto` 出 `dist/Payload/HTMLRunner.app` → 删除 `_CodeSignature` 与 `embedded.mobileprovision` → `zip -qry -X` 打成 IPA。
   用了哪条路径、为什么，日志里都会写明。
6. **结构与内容校验**：IPA 内必须存在 `Payload/HTMLRunner.app/<CFBundleExecutable>`、`Info.plist`、`Assets.car`；
   否则删除产物并以非零状态退出。
7. **生成校验和**：`dist/SHA256SUMS.txt`（路径相对仓库根，便于搬运）。

先看看它会做什么而不实际执行：

```bash
bash mac/build.sh --dry-run
```

---

## 2. 构建已签名的开发版 IPA

需要你的 **Team ID** 与（可选）**provisioning profile 名称**：

```bash
DEVELOPMENT_TEAM=ABCDE12345 bash mac/build.sh --signed

# 或者显式指定描述文件与证书
DEVELOPMENT_TEAM=ABCDE12345 \
PROVISIONING_PROFILE_SPECIFIER="HTMLRunner Dev" \
CODE_SIGN_IDENTITY="Apple Development" \
bash mac/build.sh --signed
```

产出 `dist/HTMLRunner-signed.ipa`。脚本会验证导出结果**确实**是已签名的，否则不会发布该文件。

### 未签名版与签名版的区别

| | `dist/HTMLRunner.ipa`（默认） | `dist/HTMLRunner-signed.ipa`（`--signed`） |
|---|---|---|
| 签名 | 无（`_CodeSignature` 与 `embedded.mobileprovision` 已移除） | 用你的开发证书与描述文件签名 |
| 能否直接装 | **不能**，必须经签名工具重签 | 可以（用 Xcode / Apple Configurator / 匹配的侧载工具） |
| 适用场景 | 交给 NB 助手等工具二次签名 | 已在 Apple 开发者账号里登记过设备 UDID 的自用安装 |
| 调试能力 | 由签名工具决定 | Debug 配置带 `get-task-allow`，可被调试器附加 |
| Bundle ID | 固定 `com.htmlrunner.ipad` | 需与描述文件匹配（可用 `BUNDLE_IDENTIFIER=...` 覆盖） |

> **未签名 ≠ 能装。** 未签名的 IPA 交给签名工具是正确的交付形态，不是「忘了签名」。

---

## 3. 校验已有的 IPA

```bash
bash mac/verify_ipa.sh dist/HTMLRunner.ipa
```

检查内容：zip 完整性、`Payload` 内容清单、Mach-O 是否为 arm64、`Info.plist` 可解析、
`CFBundleIdentifier` / 版本号 / `MinimumOSVersion` / `UIDeviceFamily`（必须含 2 = iPad）/
`CFBundleSupportedPlatforms` / `Assets.car` / `PkgInfo`；
若存在 `embedded.mobileprovision` 还会打印 Team 与过期时间（已过期视为硬失败，因为重签会替换它）。

未签名 IPA 缺少 `_CodeSignature` 与描述文件是**警告**而非失败——那是默认交付形态。

---

## 4. 在 GitHub Actions 上构建（无需任何密钥）

本机不是 macOS 时，这是最省事的合法路径：

```bash
mkdir -p .github/workflows
cp mac/ci-github-actions.yml .github/workflows/build-ipa.yml
git add .github/workflows/build-ipa.yml && git commit -m "ci: build unsigned IPA"
```

工作流在 `macos-15` runner 上执行 `mac/build.sh` → `mac/verify_ipa.sh` → 上传 `dist/` 为构建产物（artifact）。
不需要证书、不需要 secrets。可选：在仓库 **Variables** 里设置 `XCODE_APP` 固定 Xcode 版本
（用 `DEVELOPER_DIR` 选择，避免 `sudo xcode-select`）。

> 在 CI 上产出的 IPA 同样是**未签名**的，下载后仍需经签名工具处理。GitHub 的 artifact 下载需要先解压，注意别把 `.zip` 当成 `.ipa`。

---

## 5. 安装到 iPad

1. 用签名工具（NB 助手等）打开 `dist/HTMLRunner.ipa`，签名并安装。
2. 或在已配对的情况下用 Apple Configurator 2 / Xcode 的 Devices 窗口安装**已签名**的那一份。
3. 首次启动若被系统拦截，按工具提示在 **设置 → 通用 → VPN 与设备管理** 中信任开发者。

安装后关于 JIT 的预期，请读 [`JIT_NOTES.md`](HTMLRunner/JIT_NOTES.md) —— 简短版：**给本 App 开 JIT 不会改变 WKWebView 里网页 JS 的执行方式。**

---

## 6. 排错

| 症状 | 原因 | 处理 |
|---|---|---|
| `xcodebuild: error: The project ... does not contain a scheme named "HTMLRunner"` | scheme 未共享，或工程被移动 | 确认 `HTMLRunner.xcodeproj/xcshareddata/xcschemes/HTMLRunner.xcscheme` 存在；或运行 `python tools/generate_project.py` 重新生成 |
| `Signing for "HTMLRunner" requires a development team` | 未指定团队 | 用未签名路径（默认）即可，脚本会在签名失败后自动重试 `CODE_SIGNING_ALLOWED=NO` |
| `No profiles for 'com.htmlrunner.ipad' were found` | 描述文件与 Bundle ID 不匹配 | `BUNDLE_IDENTIFIER=com.your.name bash mac/build.sh --signed` |
| `The iOS deployment target 'IPHONEOS_DEPLOYMENT_TARGET' is set to 17.0, but the range of supported deployment target versions is ...` | Xcode 比工程新很多 | 这是**提示**，通常可继续；如需消除，用 `IPHONEOS_DEPLOYMENT_TARGET=18.0` 覆盖 |
| SDK 版本低于 17.0 | Xcode 过旧 | 升级 Xcode；脚本会明确报错而不是产出坏产物 |
| 归档成功但没有 IPA | 无签名身份，且 `-exportArchive` 失败 | 脚本会自动走手动打包路径；若仍失败，看 `build/` 下日志中的 "export" 段落 |
| `Payload/HTMLRunner.app/HTMLRunner` 是 x86_64 | 误用了模拟器 SDK | 脚本已硬性拒绝；检查是否手动加了 `-sdk iphonesimulator` |
| 装到 iPad 后启动即闪退 | 描述文件过期 / Bundle ID 不匹配 / 签名不完整 | `bash mac/verify_ipa.sh`，再用 Console.app 看崩溃日志 |
| 真机上白屏 | **不是**构建问题，是加载问题 | 打开 App 内「日志」，按 README 第 3 节的五步排查 |

---

## 7. 手工执行（不使用脚本时）

```bash
python tools/generate_project.py     # 需要时重新生成工程（不含 DEVELOPMENT_TEAM）

xcodebuild -list -project HTMLRunner.xcodeproj

xcodebuild -project HTMLRunner.xcodeproj -scheme HTMLRunner -sdk iphoneos \
  -configuration Release -destination 'generic/platform=iOS' \
  -derivedDataPath build/DerivedData build

xcodebuild -project HTMLRunner.xcodeproj -scheme HTMLRunner \
  -configuration Release -destination 'generic/platform=iOS' \
  -archivePath build/HTMLRunner.xcarchive archive

cp mac/ExportOptions-unsigned.plist build/ExportOptions.plist
xcodebuild -exportArchive -archivePath build/HTMLRunner.xcarchive \
  -exportPath build/export-unsigned -exportOptionsPlist build/ExportOptions.plist

bash mac/verify_ipa.sh build/export-unsigned/HTMLRunner.ipa
```

---

## 8. 构建产出清单

| 路径 | 是否必需 | 说明 |
|---|---|---|
| `dist/HTMLRunner.ipa` | ✅ | 未签名 IPA（供二次签名） |
| `dist/SHA256SUMS.txt` | ✅ | `dist/*.ipa` 的 SHA-256 |
| `build/xcodebuild-build.log` | ✅ | 完整构建日志 |
| `build/xcodebuild-archive.log` | ✅ | 归档日志 |
| `build/HTMLRunner.xcarchive` | 建议保留 | 归档产物，便于重新导出 |
| `dist/HTMLRunner-signed.ipa` | 仅 `--signed` | 已签名开发版 |

**若某个产物不存在，说明对应的步骤没有成功执行。** 本仓库不会用空文件冒充产物。
