import Foundation

enum WorkflowEngineError: Error, LocalizedError {
    case emptyPrompt
    case noStartNode
    case cancelled
    case safetyLimitReached
    case apiTimeout(String)

    var errorDescription: String? {
        switch self {
        case .emptyPrompt: return "开始模块提示词为空。"
        case .noStartNode: return "工作流缺少开始模块。"
        case .cancelled: return "运行已被停止。"
        case .safetyLimitReached: return "返工循环次数过多，已自动停止以避免卡死。可检查检查者的不合格连线。"
        case .apiTimeout(let message): return message
        }
    }
}

final class WorkflowEngine {
    func run(runID: UUID = UUID(), project: WorkflowProject, apiConfigs: [APIProviderConfig], settings: AppSettings, aiClient: AIClient, onUpdate: @escaping (RunRecord) -> Void) async throws -> RunRecord {
        guard !project.userPrompt.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { throw WorkflowEngineError.emptyPrompt }
        guard let start = project.nodes.first(where: { $0.kind == .start }) else { throw WorkflowEngineError.noStartNode }

        var record = RunRecord(projectID: project.id, projectTitle: project.title)
        record.id = runID
        var contextByNode: [UUID: String] = [:]
        var queue: [UUID] = [start.id]
        var visitCounts: [UUID: Int] = [:]
        var returnCounts: [UUID: Int] = [:]
        var waitCounts: [UUID: Int] = [:]
        var executed = 0
        let safetyLimit = max(project.nodes.count * 20, 80)

        appendLog(&record, .info, nil, "开始运行工作流：\(project.title)")
        record.currentStage = "准备执行队列"
        record.diagnosticMessage = "如果长时间不动，请查看当前模块和最后一条日志。"
        onUpdate(record)

        while let nodeID = queue.first {
            try Task.checkCancellation()
            queue.removeFirst()
            guard let node = project.nodes.first(where: { $0.id == nodeID }) else { continue }

            let missingInputs = missingRequiredInputTitles(for: node, project: project, contextByNode: contextByNode)
            if node.kind != .start && !missingInputs.isEmpty {
                waitCounts[nodeID, default: 0] += 1
                if waitCounts[nodeID, default: 0] <= max(project.nodes.count + 2, 6) {
                    record.currentNodeTitle = node.title
                    record.currentStage = "等待上游：\(node.title)"
                    appendLog(&record, .info, node.title, "等待上游 AI 输出：\(missingInputs.joined(separator: "、"))。下游模块会拿到上游结果后再调用模型。")
                    onUpdate(record)
                    queue.append(nodeID)
                    try await Task.sleep(nanoseconds: 120_000_000)
                    continue
                } else {
                    appendLog(&record, .warning, node.title, "等待上游过久，改用已完成的上游结果继续。缺少：\(missingInputs.joined(separator: "、"))。")
                }
            }

            if executed > safetyLimit {
                appendLog(&record, .error, node.title, "检测到可能的无限返工循环，已停止。")
                record.status = .failed
                record.endedAt = Date()
                record.currentStage = "循环保护停止"
                record.diagnosticMessage = WorkflowEngineError.safetyLimitReached.localizedDescription
                onUpdate(record)
                throw WorkflowEngineError.safetyLimitReached
            }

            visitCounts[nodeID, default: 0] += 1
            executed += 1
            record.currentNodeTitle = node.title
            record.currentStage = "正在执行：\(node.title)"
            record.progress = min(0.95, max(record.progress, (Double(executed) - 0.35) / Double(max(project.nodes.count, 1))))
            record.diagnosticMessage = "阶段：准备输入；已执行 \(executed) 个模块步骤。"

            let inputContext = inputContextFor(node: node, project: project, contextByNode: contextByNode)
            var nodeRecord = NodeRunRecord(nodeID: node.id, nodeTitle: node.title, kind: node.kind, status: .running)
            nodeRecord.inputPreview = String(inputContext.prefix(1600))
            nodeRecord.returnCount = returnCounts[node.id] ?? 0
            record.nodeRecords.append(nodeRecord)
            appendLog(&record, .info, node.title, "开始执行模块。输入长度约 \(TokenEstimator.roughCount(inputContext)) Token。")
            onUpdate(record)

            do {
                record.currentStage = "调用/处理：\(node.title)"
                record.diagnosticMessage = "如果这里卡住，通常是 API 请求超时、网络失败或模型没有返回。超时会写入错误日志。"
                onUpdate(record)

                appendLog(&record, .info, node.title, "已进入调用阶段；最长等待约 \(max(node.timeoutSeconds + 10, 20)) 秒。")
                onUpdate(record)

                let response = try await withTimeout(seconds: max(node.timeoutSeconds + 10, 20)) {
                    try await self.execute(node: node, project: project, context: inputContext, apiConfigs: apiConfigs, settings: settings, aiClient: aiClient)
                }
                try Task.checkCancellation()

                let decision = reviewerDecision(node: node, output: response.text)
                let output = (node.kind.isReviewer && decision.passed == true) ? "{\"passed\":true,\"feedback\":\"\"}" : response.text
                contextByNode[node.id] = output
                record.output = latestCombinedOutput(project: project, contextByNode: contextByNode)
                record.tokenUsage = record.tokenUsage + response.tokenUsage

                if let index = record.nodeRecords.lastIndex(where: { $0.nodeID == node.id && $0.status == .running }) {
                    record.nodeRecords[index].status = .passed
                    record.nodeRecords[index].endedAt = Date()
                    record.nodeRecords[index].output = output
                    record.nodeRecords[index].tokenUsage = response.tokenUsage
                    record.nodeRecords[index].providerName = apiConfigs.first(where: { $0.id == node.providerID })?.name
                    record.nodeRecords[index].modelID = node.modelID
                }
                appendLog(&record, .success, node.title, "模块完成，Token：\(response.tokenUsage.total)")

                let passed = node.kind.isReviewer ? (decision.passed ?? false) : true
                if node.kind.isReviewer {
                    if passed {
                        appendLog(&record, .success, node.title, "检查通过：已清空修改建议，继续走通过出口。")
                    } else {
                        let feedback = decision.feedback?.trimmingCharacters(in: .whitespacesAndNewlines)
                        appendLog(&record, .warning, node.title, "检查未通过：走不合格出口。\(feedback?.isEmpty == false ? " 返工意见：\(feedback!)" : "")")
                    }
                }

                let nextEdges = nextEdges(from: node, passed: passed, project: project)
                if nextEdges.isEmpty && node.kind != .output {
                    appendLog(&record, .warning, node.title, "该模块没有后续连线，流程在这里结束。")
                }
                for edge in nextEdges {
                    if edge.condition == .failed {
                        returnCounts[edge.to, default: 0] += 1
                    }
                    queue.append(edge.to)
                }
            } catch is CancellationError {
                if let index = record.nodeRecords.lastIndex(where: { $0.nodeID == node.id && $0.status == .running }) {
                    record.nodeRecords[index].status = .failed
                    record.nodeRecords[index].endedAt = Date()
                    record.nodeRecords[index].errorMessage = "用户停止运行"
                }
                appendLog(&record, .warning, node.title, "运行被用户停止。")
                record.status = .cancelled
                record.endedAt = Date()
                record.currentStage = "已停止"
                record.diagnosticMessage = "用户点击停止运行。"
                onUpdate(record)
                throw CancellationError()
            } catch {
                if let index = record.nodeRecords.lastIndex(where: { $0.nodeID == node.id && $0.status == .running }) {
                    record.nodeRecords[index].status = .failed
                    record.nodeRecords[index].endedAt = Date()
                    record.nodeRecords[index].errorMessage = error.localizedDescription
                }
                appendLog(&record, .error, node.title, error.localizedDescription)
                record.status = .failed
                record.endedAt = Date()
                record.currentStage = "失败：\(node.title)"
                record.diagnosticMessage = error.localizedDescription
                onUpdate(record)
                throw error
            }

            record.progress = min(0.98, Double(executed) / Double(max(project.nodes.count, 1)))
            onUpdate(record)
        }

        record.status = .completed
        record.endedAt = Date()
        record.progress = 1
        record.currentNodeTitle = nil
        record.currentStage = "运行完成"
        record.diagnosticMessage = "全部可达模块已执行完成。"
        record.output = latestCombinedOutput(project: project, contextByNode: contextByNode)
        appendLog(&record, .success, nil, "工作流运行完成")
        return record
    }

    private func execute(node: WorkflowNode, project: WorkflowProject, context: String, apiConfigs: [APIProviderConfig], settings: AppSettings, aiClient: AIClient) async throws -> AITextResponse {
        switch node.kind {
        case .start:
            let imageNote = project.resources.contains(where: { $0.kind == .image }) ? "\n已检测到图片资源；图片内容将交给图片理解模块处理。" : ""
            let text = "已接收需求。\n\n\(project.userPrompt)\(imageNote)"
            return AITextResponse(text: text, tokenUsage: TokenUsage(input: TokenEstimator.roughCount(project.userPrompt), output: TokenEstimator.roughCount(text)))
        case .logger:
            let text = "日志记录模块已记录当前上下文、模块输出、Token 与状态。"
            return AITextResponse(text: text, tokenUsage: TokenUsage(input: 0, output: TokenEstimator.roughCount(text)))
        case .filePackager:
            let text = "文件打包者已生成真实 ZIP 导出清单。运行完成后可在运行监控或输出历史中点击“导出 ZIP”，ZIP 内包含最终输出、Markdown 日志、JSON 运行记录和各节点独立输出。"
            return AITextResponse(text: text, tokenUsage: TokenUsage(input: TokenEstimator.roughCount(context), output: TokenEstimator.roughCount(text)))
        case .versionSnapshot:
            let text = "版本快照模块已保存工作流结构、提示词、模型配置和当前输出。"
            return AITextResponse(text: text, tokenUsage: TokenUsage(input: 0, output: TokenEstimator.roughCount(text)))
        case .output:
            let text = "# 最终输出\n\n\(context)"
            return AITextResponse(text: text, tokenUsage: TokenUsage(input: TokenEstimator.roughCount(context), output: TokenEstimator.roughCount(text)))
        default:
            guard let providerID = node.providerID, let config = apiConfigs.first(where: { $0.id == providerID }), let model = node.modelID, !model.isEmpty else {
                let simulated = localFallbackOutput(for: node, context: context)
                return AITextResponse(text: simulated, tokenUsage: TokenUsage(input: TokenEstimator.roughCount(context), output: TokenEstimator.roughCount(simulated)))
            }
            let apiKey = try KeychainService.read(account: config.keychainAccount)
            let system = systemPrompt(for: node)
            let outputRule = node.kind.isReviewer
                ? "输出要求：只能输出 JSON。通过时 {\"passed\":true,\"feedback\":\"\"}；不通过时 {\"passed\":false,\"feedback\":\"具体返工意见\"}。不要泄露 API Key。"
                : "输出要求：结构化、可执行、指出不确定内容和风险。不要泄露 API Key。"
            let user = """
            当前模块输入（包含用户原始需求 + 上游 AI 模块真实输出）：
            \(context)

            当前模块职责：
            \(node.kind == .custom ? node.prompt : node.kind.defaultPrompt)

            交流要求：必须明确参考上游模块输出继续工作；如果上游给了修改意见、识别结果、代码或方案，要把它作为本模块输入的一部分处理，不要从零开始。

            \(outputRule)
            """

            if node.kind == .imageUnderstanding, let image = project.resources.first(where: { $0.kind == .image })?.base64Preview {
                return try await aiClient.completeVision(baseURL: config.baseURL, apiKey: apiKey, model: model, prompt: user, imageBase64: image, maxTokens: node.maxTokens, temperature: node.temperature, timeoutSeconds: node.timeoutSeconds)
            } else {
                let messages = [AIMessage(role: "system", content: system), AIMessage(role: "user", content: user)]
                return try await aiClient.completeText(baseURL: config.baseURL, apiKey: apiKey, model: model, messages: messages, maxTokens: node.maxTokens, temperature: node.temperature, timeoutSeconds: node.timeoutSeconds)
            }
        }
    }

    private func systemPrompt(for node: WorkflowNode) -> String {
        switch node.kind {
        case .codeReviewer:
            return "你是严格的代码检查者。必须只输出 JSON：{\"passed\": true, \"feedback\": \"\"} 或 {\"passed\": false, \"feedback\": \"必须返工的问题\"}。通过时 feedback 必须为空，不要给修改建议。"
        case .qualityReviewer:
            return "你是质量评估者。必须只输出 JSON：{\"passed\": true, \"feedback\": \"\"} 或 {\"passed\": false, \"feedback\": \"返工意见\"}。通过时 feedback 必须为空。"
        case .visualReviewer:
            return "你是视觉检查者。必须只输出 JSON：{\"passed\": true, \"feedback\": \"\"} 或 {\"passed\": false, \"feedback\": \"UI/排版/适配问题\"}。通过时 feedback 必须为空。"
        case .imageUnderstanding:
            return "你是图片理解模块。输出图片摘要、关键文字、可操作信息、不确定内容。"
        case .multiModelVote:
            return "你是裁判模型。比较多个答案，选择更可靠结果，并解释理由。"
        default:
            return "你是 AI Workflow Studio 的 \(node.kind.title)。你必须读取上游模块传来的内容，并在此基础上继续处理，形成真实多 AI 协作链。"
        }
    }

    private func localFallbackOutput(for node: WorkflowNode, context: String) -> String {
        switch node.kind {
        case .planner:
            return "未配置模型，使用本地占位计划：1. 拆解需求；2. 执行核心任务；3. 检查质量；4. 导出结果。"
        case .codeReviewer, .qualityReviewer, .visualReviewer:
            return "{\"passed\":false,\"feedback\":\"未配置检查者模型，无法确认质量。请配置检查者模型后重新运行，或手动调整连线。\"}"
        case .imageUnderstanding:
            return "未配置图片理解模型，无法识别图片。请在设置中添加支持图片输入的模型。"
        default:
            return "未配置模型，\(node.kind.title) 已跳过真实 AI 调用，仅生成占位输出。"
        }
    }

    private func inputContextFor(node: WorkflowNode, project: WorkflowProject, contextByNode: [UUID: String]) -> String {
        if node.kind == .start { return "# 用户原始需求\n\(project.userPrompt)" }
        let incoming = project.edges.filter { $0.to == node.id }
        let upstream = incoming.compactMap { edge -> String? in
            guard let source = project.nodes.first(where: { $0.id == edge.from }), let output = contextByNode[source.id] else { return nil }
            return """
            ## 来自上游 AI：\(source.title)
            连线条件：\(edge.condition.title)
            上游输出：
            \(output)
            """
        }
        if upstream.isEmpty {
            return """
            # 用户原始需求
            \(project.userPrompt)

            # 上游 AI 交流上下文
            暂无上游输出；此模块会直接基于用户需求工作。
            """
        }
        return """
        # 用户原始需求
        \(project.userPrompt)

        # 上游 AI 交流上下文
        \(upstream.joined(separator: "\n\n"))

        # 执行要求
        当前模块必须基于以上上游输出继续处理，不要忽略上游结果。
        """
    }

    private func missingRequiredInputTitles(for node: WorkflowNode, project: WorkflowProject, contextByNode: [UUID: String]) -> [String] {
        let incoming = project.edges.filter { $0.to == node.id }
        return incoming.compactMap { edge in
            guard let source = project.nodes.first(where: { $0.id == edge.from }) else { return nil }
            if edge.condition == .failed || edge.condition == .scoreLow {
                return nil
            }
            return contextByNode[source.id] == nil ? source.title : nil
        }
    }

    private func nextEdges(from node: WorkflowNode, passed: Bool, project: WorkflowProject) -> [WorkflowEdge] {
        let outgoing = project.edges.filter { $0.from == node.id }
        if node.kind.isReviewer {
            let preferred = outgoing.filter { passed ? $0.condition == .passed : $0.condition == .failed }
            if !preferred.isEmpty { return preferred }
            return outgoing.filter { $0.condition == .always }
        }
        return outgoing.filter { $0.condition == .always || $0.condition == .passed || $0.condition == .scoreHigh }
    }

    private struct ReviewerDecision: Decodable {
        var passed: Bool
        var feedback: String?
    }

    private func reviewerDecision(node: WorkflowNode, output: String) -> (passed: Bool?, feedback: String?) {
        guard node.kind.isReviewer else { return (true, nil) }
        if let jsonText = extractJSONObject(from: output),
           let data = jsonText.data(using: .utf8),
           let decoded = try? JSONDecoder().decode(ReviewerDecision.self, from: data) {
            return (decoded.passed, decoded.feedback)
        }
        let lower = output.lowercased()
        if lower.contains("\"passed\":false") || lower.contains("passed: false") || lower.contains("不通过") || lower.contains("不合格") || lower.contains("failed") {
            return (false, output)
        }
        if lower.contains("\"passed\":true") || lower.contains("passed: true") || lower.contains("通过") || lower.contains("合格") {
            return (true, nil)
        }
        return (false, "检查者没有返回严格 JSON，按不合格处理，避免误放行。原始输出：\(output)")
    }

    private func extractJSONObject(from text: String) -> String? {
        guard let start = text.firstIndex(of: "{"), let end = text.lastIndex(of: "}"), start <= end else { return nil }
        return String(text[start...end])
    }

    private func withTimeout<T>(seconds: Int, operation: @escaping () async throws -> T) async throws -> T {
        try await withThrowingTaskGroup(of: T.self) { group in
            group.addTask { try await operation() }
            group.addTask {
                try await Task.sleep(nanoseconds: UInt64(max(seconds, 1)) * 1_000_000_000)
                throw WorkflowEngineError.apiTimeout("API 或模块处理超过 \(seconds) 秒没有返回，已自动停止。请检查网络、Base URL、模型名或把模块超时时间调大。")
            }
            guard let result = try await group.next() else { throw WorkflowEngineError.cancelled }
            group.cancelAll()
            return result
        }
    }

    private func latestCombinedOutput(project: WorkflowProject, contextByNode: [UUID: String]) -> String {
        project.nodes.compactMap { node in
            guard let output = contextByNode[node.id] else { return nil }
            return "## \(node.title)\n\(output)"
        }.joined(separator: "\n\n")
    }

    private func appendLog(_ record: inout RunRecord, _ level: LogLevel, _ nodeTitle: String?, _ message: String) {
        record.logs.append(RunLogEntry(level: level, nodeTitle: nodeTitle, message: message))
        record.lastLogAt = Date()
        record.diagnosticMessage = message
    }
}
