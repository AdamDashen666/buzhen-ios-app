# AI Workflow Studio v2.1

SwiftUI iOS / iPadOS Xcode Project 骨架。

## v2.1 更新

- 修复拖拽模块时出现鬼影、来回跳动、左右拖动乱跳的问题。
- 拖动模块时锁定当前节点位置，禁止 `project.nodes` 的旧坐标在同一帧覆盖本地拖拽坐标。
- 模块拖动改为高优先级手势，减少和 ScrollView 横向滚动抢手势的问题。
- 拖动过程中关闭隐式动画，避免 Liquid Glass 卡片位置回弹。
- 强化多 AI 模块之间的真实交流：下游模块会拿到上游模块输出作为输入上下文。
- 多输入模块会等待主要上游模块完成后再运行，避免只拿到部分结果就调用 AI。
- 模型提示词明确要求读取上游 AI 的结果、修改意见、识别信息或代码后再继续处理。

## 注意

需要在 Xcode 中设置 Team / Bundle ID 后运行。API 默认按 OpenAI-compatible `/v1/models` 与 `/v1/chat/completions` 设计。
