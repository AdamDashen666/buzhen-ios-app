import SwiftUI

struct HomeView: View {
    @EnvironmentObject private var store: AppStore

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    hero
                    projectGuide
                    recentProjects
                }
                .padding()
            }
            .studioBackground()
            .navigationTitle("AI Workflow Studio")
        }
    }

    private var hero: some View {
        VStack(alignment: .leading, spacing: 14) {
            Label("可视化多 AI 工作流", systemImage: "sparkles")
                .font(.title.bold())
            Text("首页只负责项目管理。提示词、上传图片、AI 自动选择模块和运行按钮都在“工作流”的开始模块里。")
                .foregroundStyle(.secondary)
            HStack(spacing: 10) {
                InfoPill(icon: "rectangle.3.group", text: "模块化")
                InfoPill(icon: "cable.connector", text: "手动连线")
                InfoPill(icon: "archivebox", text: "真实 ZIP")
                InfoPill(icon: "list.clipboard", text: "日志导出")
            }
            .lineLimit(1)
            Button {
                store.createProject(title: "AI 工作流项目")
            } label: {
                Label("新建空白项目", systemImage: "plus.circle.fill")
                    .font(.headline)
            }
            .buttonStyle(.borderedProminent)
        }
        .liquidGlass()
    }

    private var projectGuide: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("页面说明")
                .font(.headline)
            GuideRow(icon: "house", title: "首页", text: "只看项目、新建项目、选择最近项目。")
            GuideRow(icon: "point.3.connected.trianglepath.dotted", title: "工作流", text: "写需求、上传图片、添加模块、拖端口连线、缩放画布、运行。")
            GuideRow(icon: "gearshape", title: "设置", text: "添加 API、刷新模型、选择 Token 总限制方式、查看错误日志。")
        }
        .liquidGlass()
    }

    private var recentProjects: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("最近项目")
                .font(.headline)
            if store.projects.isEmpty {
                ContentUnavailableView("暂无项目", systemImage: "folder.badge.plus", description: Text("点击上方“新建空白项目”开始。"))
            } else {
                ForEach(store.projects) { project in
                    Button {
                        store.selectedProjectID = project.id
                    } label: {
                        HStack(alignment: .center, spacing: 12) {
                            Image(systemName: "square.stack.3d.up")
                                .font(.title2)
                                .frame(width: 34)
                            VStack(alignment: .leading, spacing: 4) {
                                Text(project.title).font(.headline)
                                Text("节点：\(project.nodes.count) · 连线：\(project.edges.count) · 更新：\(project.updatedAt.formatted(date: .abbreviated, time: .shortened))")
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                                Text("用途：点击选择这个项目，再进入“工作流”编辑。")
                                    .font(.caption2)
                                    .foregroundStyle(.secondary)
                            }
                            Spacer()
                            if store.selectedProjectID == project.id {
                                Image(systemName: "checkmark.circle.fill")
                                    .foregroundStyle(.cyan)
                            }
                        }
                    }
                    .buttonStyle(.plain)
                    .padding()
                    .background(.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous).stroke(.white.opacity(0.12)))
                }
            }
        }
        .liquidGlass()
    }
}

private struct GuideRow: View {
    var icon: String
    var title: String
    var text: String

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: icon)
                .frame(width: 26)
                .foregroundStyle(.cyan)
            VStack(alignment: .leading, spacing: 2) {
                Text(title).font(.subheadline.bold())
                Text(text).font(.caption).foregroundStyle(.secondary)
            }
        }
    }
}
