import SwiftUI

struct OutputHistoryView: View {
    @EnvironmentObject private var store: AppStore
    @State private var selectedRun: RunRecord?

    var body: some View {
        NavigationStack {
            List {
                Section("当前工作流运行输出") {
                    if store.selectedProjectRunRecords.isEmpty {
                        ContentUnavailableView("暂无输出", systemImage: "tray", description: Text("这里只显示当前工作流自己的输出，切换工作流不会串记录。"))
                    }
                    ForEach(store.selectedProjectRunRecords) { run in
                        Button { selectedRun = run } label: {
                            VStack(alignment: .leading, spacing: 6) {
                                Text(run.projectTitle).font(.headline)
                                Text("\(run.displayDate) · \(run.status.title) · Token \(run.tokenUsage.total)")
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                                Text(run.currentStage)
                                    .font(.caption2)
                                    .foregroundStyle(.secondary)
                            }
                        }
                    }
                }
                Section("当前工作流版本历史") {
                    if store.selectedProjectSnapshots.isEmpty {
                        Text("暂无版本快照。")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    ForEach(store.selectedProjectSnapshots) { snapshot in
                        VStack(alignment: .leading) {
                            Text(snapshot.title).font(.headline)
                            Text("\(snapshot.createdAt.formatted(date: .abbreviated, time: .shortened)) · \(snapshot.note)")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                    }
                }
            }
            .scrollContentBackground(.hidden)
            .studioBackground()
            .navigationTitle("输出历史")
            .sheet(item: $selectedRun) { run in
                NavigationStack {
                    ScrollView {
                        VStack(alignment: .leading, spacing: 18) {
                            Text("最终输出")
                                .font(.title2.bold())
                            Text(run.output.isEmpty ? "暂无最终输出" : run.output)
                                .font(.system(.body, design: .monospaced))
                                .textSelection(.enabled)
                                .frame(maxWidth: .infinity, alignment: .leading)

                            Divider().padding(.vertical, 6)
                            Text("模块输入 / 输出")
                                .font(.title2.bold())
                            ForEach(run.nodeRecords) { node in
                                VStack(alignment: .leading, spacing: 8) {
                                    Label(node.nodeTitle, systemImage: node.kind.icon)
                                        .font(.headline)
                                    DisclosureGroup("输入") {
                                        Text(node.inputPreview.isEmpty ? "无输入记录" : node.inputPreview)
                                            .font(.system(.caption, design: .monospaced))
                                            .textSelection(.enabled)
                                            .frame(maxWidth: .infinity, alignment: .leading)
                                    }
                                    DisclosureGroup("输出") {
                                        Text(node.output.isEmpty ? (node.errorMessage ?? "无输出") : node.output)
                                            .font(.system(.caption, design: .monospaced))
                                            .textSelection(.enabled)
                                            .frame(maxWidth: .infinity, alignment: .leading)
                                    }
                                }
                                .padding()
                                .background(.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                            }
                        }
                        .padding()
                    }
                    .studioBackground()
                    .navigationTitle("输出详情")
                    .toolbar {
                        ShareLink("分享日志", item: LogExportService.markdown(for: run))
                        ShareLink("分享 ZIP", item: ZipArchiveService.shareableRunArchive(for: run))
                    }
                }
            }
        }
    }
}
