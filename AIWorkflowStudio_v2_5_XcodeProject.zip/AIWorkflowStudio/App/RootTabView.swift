import SwiftUI

struct RootTabView: View {
    @EnvironmentObject private var store: AppStore

    var body: some View {
        TabView {
            HomeView()
                .tabItem { Label("首页", systemImage: "sparkles.rectangle.stack") }
            WorkflowEditorView()
                .tabItem { Label("工作流", systemImage: "point.3.connected.trianglepath.dotted") }
            RunMonitorView()
                .tabItem { Label("运行记录", systemImage: "waveform.path.ecg.rectangle") }
            OutputHistoryView()
                .tabItem { Label("输出", systemImage: "tray.full") }
            SettingsView()
                .tabItem { Label("设置", systemImage: "gearshape") }
        }
        .tint(.cyan)
        .preferredColorScheme(store.settings.forceDarkMode ? .dark : nil)
    }
}
