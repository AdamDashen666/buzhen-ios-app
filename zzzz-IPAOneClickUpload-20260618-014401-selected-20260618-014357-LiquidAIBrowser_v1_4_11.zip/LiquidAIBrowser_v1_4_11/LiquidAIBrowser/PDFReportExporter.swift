import Foundation
import UIKit

struct PDFReportExporter {
    static func export(task: AgentTask, tab: BrowserTab?, detailedLog: String) throws -> URL {
        let pageRect = CGRect(x: 0, y: 0, width: 595.2, height: 841.8)
        let renderer = UIGraphicsPDFRenderer(bounds: pageRect)
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("LiquidAIBrowser_Report_\(task.id.uuidString.prefix(8)).pdf")
        let margin: CGFloat = 34
        let width = pageRect.width - margin * 2
        let titleFont = UIFont.systemFont(ofSize: 24, weight: .heavy)
        let hFont = UIFont.systemFont(ofSize: 15, weight: .bold)
        let bodyFont = UIFont.systemFont(ofSize: 11.5, weight: .regular)
        let strongBodyFont = UIFont.systemFont(ofSize: 11.5, weight: .semibold)
        let captionFont = UIFont.systemFont(ofSize: 9.5, weight: .medium)
        let monoFont = UIFont.monospacedSystemFont(ofSize: 8.5, weight: .medium)
        let paragraph = NSMutableParagraphStyle(); paragraph.lineSpacing = 4.5; paragraph.paragraphSpacing = 8
        let smallParagraph = NSMutableParagraphStyle(); smallParagraph.lineSpacing = 3.5; smallParagraph.paragraphSpacing = 4
        let textColor = UIColor.black
        let mutedColor = UIColor.darkGray
        let accent = UIColor(red: 0.05, green: 0.19, blue: 0.36, alpha: 1)
        let compactSnapshots = selectReportSnapshots(from: task.stepSnapshots, limit: 10)

        try renderer.writePDF(to: url) { context in
            func newPage() -> CGFloat {
                context.beginPage()
                UIColor.white.setFill()
                UIBezierPath(rect: pageRect).fill()
                return margin
            }
            func ensure(_ y: inout CGFloat, _ height: CGFloat) {
                if y + height > pageRect.height - margin { y = newPage() }
            }
            func drawText(_ text: String, font: UIFont, color: UIColor = textColor, y: inout CGFloat, maxWidth: CGFloat = width, style: NSParagraphStyle? = nil) {
                let attrs: [NSAttributedString.Key: Any] = [.font: font, .foregroundColor: color, .paragraphStyle: style ?? paragraph]
                let rect = NSString(string: text).boundingRect(with: CGSize(width: maxWidth, height: .greatestFiniteMagnitude), options: [.usesLineFragmentOrigin, .usesFontLeading], attributes: attrs, context: nil)
                ensure(&y, ceil(rect.height) + 9)
                NSString(string: text).draw(with: CGRect(x: margin, y: y, width: maxWidth, height: ceil(rect.height) + 6), options: [.usesLineFragmentOrigin, .usesFontLeading], attributes: attrs, context: nil)
                y += ceil(rect.height) + 11
            }
            func drawDivider(y: inout CGFloat) {
                ensure(&y, 12)
                accent.withAlphaComponent(0.55).setStroke()
                let path = UIBezierPath()
                path.move(to: CGPoint(x: margin, y: y))
                path.addLine(to: CGPoint(x: margin + width, y: y))
                path.lineWidth = 1.1
                path.stroke()
                y += 17
            }
            func drawMetricCards(y: inout CGFloat) {
                let duration = Int((task.finishedAt ?? Date()).timeIntervalSince(task.startedAt ?? task.createdAt))
                let values = [
                    ("进度", "\(Int(task.progress * 100))%"),
                    ("动作", "\(task.totalActionCount)"),
                    ("失败/重试", "\(task.failureCount)"),
                    ("运行时间", "\(duration)s")
                ]
                let cardW = (width - 18) / 4
                ensure(&y, 62)
                for (i, item) in values.enumerated() {
                    let x = margin + CGFloat(i) * (cardW + 6)
                    let rect = CGRect(x: x, y: y, width: cardW, height: 54)
                    UIColor(white: 0.95, alpha: 1).setFill()
                    UIBezierPath(roundedRect: rect, cornerRadius: 10).fill()
                    accent.withAlphaComponent(0.35).setStroke()
                    UIBezierPath(roundedRect: rect, cornerRadius: 10).stroke()
                    (item.0 as NSString).draw(in: CGRect(x: x + 8, y: y + 8, width: cardW - 16, height: 15), withAttributes: [.font: captionFont, .foregroundColor: mutedColor])
                    (item.1 as NSString).draw(in: CGRect(x: x + 8, y: y + 26, width: cardW - 16, height: 22), withAttributes: [.font: UIFont.systemFont(ofSize: 15, weight: .heavy), .foregroundColor: accent])
                }
                y += 68
            }
            func drawImage(_ image: UIImage, title: String, subtitle: String?, y: inout CGFloat) {
                drawText(title, font: hFont, color: accent, y: &y)
                if let subtitle, !subtitle.isEmpty { drawText(subtitle, font: captionFont, color: mutedColor, y: &y, style: smallParagraph) }
                let originalW = max(image.size.width, 1)
                let originalH = max(image.size.height, 1)
                let maxH: CGFloat = 165
                var drawW = width
                var drawH = drawW * originalH / originalW
                if drawH > maxH { drawH = maxH; drawW = drawH * originalW / originalH }
                ensure(&y, drawH + 18)
                let rect = CGRect(x: margin + (width - drawW) / 2, y: y, width: drawW, height: drawH)
                UIColor(white: 0.94, alpha: 1).setFill()
                UIBezierPath(roundedRect: rect.insetBy(dx: -4, dy: -4), cornerRadius: 9).fill()
                image.draw(in: rect)
                y += drawH + 18
            }

            var y = newPage()
            drawText("Liquid AI Browser 任务报告", font: titleFont, color: accent, y: &y)
            drawText("状态：\(task.status.title)    生成时间：\(Date().formatted(date: .abbreviated, time: .standard))", font: strongBodyFont, color: mutedColor, y: &y)
            drawMetricCards(y: &y)
            if let tab { drawText("当前网页：\(tab.displayTitle)\nURL：\(tab.urlString)", font: bodyFont, y: &y) }
            drawDivider(y: &y)

            drawText("用户要求", font: hFont, color: accent, y: &y)
            drawText(task.goal, font: bodyFont, y: &y)
            drawText("AI 计划 / 最终目标分析", font: hFont, color: accent, y: &y)
            drawText(task.goalAnalysis.isEmpty ? "未记录。" : task.goalAnalysis, font: bodyFont, y: &y)

            if !task.findings.isEmpty {
                drawText("已记录结论 / 事实记忆", font: hFont, color: accent, y: &y)
                let findingsText = task.findings.sorted { $0.updatedAt < $1.updatedAt }.map { $0.compactLine }.joined(separator: "\n")
                drawText(findingsText, font: bodyFont, y: &y)
            }

            drawText("需要实现的目标与完成检查", font: hFont, color: accent, y: &y)
            let checklistText = task.checklist.enumerated().map { index, item in
                "\(item.isDone ? "✓" : "○") \(index + 1). \(item.title)\n   \(item.detail)\(item.note.isEmpty ? "" : "\n   检查备注：\(item.note)")"
            }.joined(separator: "\n")
            drawText(checklistText.isEmpty ? "没有生成清单。" : checklistText, font: bodyFont, y: &y)

            if let image = tab?.thumbnailImage { drawImage(image, title: "当前网页缩略图", subtitle: nil, y: &y) }
            if !compactSnapshots.isEmpty {
                drawDivider(y: &y)
                drawText("关键步骤截图记录（最多 10 张，720p 等比例压缩）", font: hFont, color: accent, y: &y)
                for (idx, shot) in compactSnapshots.enumerated() {
                    if let image = shot.image {
                        let step = shot.stepIndex.map { "Step \($0 + 1)" } ?? "Snapshot \(idx + 1)"
                        let subtitle = "\(step) · +\(String(format: "%.1f", shot.elapsedSeconds))s · \(shot.actionType ?? "snapshot") · URL: \(shot.urlString)\n\(shot.note)"
                        drawImage(image, title: "\(idx + 1). \(shot.title)", subtitle: subtitle, y: &y)
                    }
                }
            }

            drawDivider(y: &y)
            drawText("结尾总结", font: hFont, color: accent, y: &y)
            drawText(task.report.isEmpty ? "任务尚未生成总结报告。" : task.report, font: bodyFont, y: &y)
            drawText("详细运行日志（PDF 内最多 120 行，完整日志仍可在任务卡复制）", font: hFont, color: accent, y: &y)
            let logLines = detailedLog.split(separator: "\n", omittingEmptySubsequences: false)
            let displayLines = logLines.count > 120 ? Array(logLines.suffix(120)) : Array(logLines)
            if logLines.count > 120 {
                drawText("已省略前 \(logLines.count - 120) 行，避免 PDF 过大。", font: captionFont, color: mutedColor, y: &y, style: smallParagraph)
            }
            for line in displayLines {
                drawText(String(line), font: monoFont, color: textColor, y: &y, style: smallParagraph)
            }
        }
        return url
    }

    private static func selectReportSnapshots(from snapshots: [TaskStepSnapshot], limit: Int) -> [TaskStepSnapshot] {
        guard snapshots.count > limit else { return snapshots }
        var selected: [TaskStepSnapshot] = []
        func appendUnique(_ shot: TaskStepSnapshot?) {
            guard let shot, !selected.contains(where: { $0.id == shot.id }) else { return }
            selected.append(shot)
        }
        appendUnique(snapshots.first)
        for keyword in ["plan", "read", "click", "input", "typeText", "teamsSendMessage", "verify"] {
            appendUnique(snapshots.first(where: { ($0.actionType ?? "").localizedCaseInsensitiveContains(keyword) }))
        }
        appendUnique(snapshots.last)
        if selected.count < limit {
            let remaining = snapshots.filter { shot in !selected.contains(where: { $0.id == shot.id }) }
            let slots = max(1, limit - selected.count)
            let stride = max(1, remaining.count / slots)
            for (index, shot) in remaining.enumerated() where index % stride == 0 {
                appendUnique(shot)
                if selected.count >= limit { break }
            }
        }
        return Array(selected.prefix(limit)).sorted { $0.elapsedSeconds < $1.elapsedSeconds }
    }
}
