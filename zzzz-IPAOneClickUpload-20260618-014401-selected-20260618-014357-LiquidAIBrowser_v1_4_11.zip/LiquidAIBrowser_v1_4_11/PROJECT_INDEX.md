# PROJECT_INDEX - LiquidAIBrowser v1.4.11

## Build

- Version: `1.4.11`
- Build: `18`

## Main files

- `LiquidAIBrowser/BrowserModels.swift`：分组、页面、任务、日志、截图、计时器、Agent action/decision/finding 数据模型。
- `LiquidAIBrowser/BrowserStore.swift`：全局状态、分组/页面/任务管理、计时器、会话持久化。
- `LiquidAIBrowser/WebViewPool.swift`：WKWebView 池、网页兼容、DOM 扫描、坐标/键盘/Teams 动作。
- `LiquidAIBrowser/AgentEngine.swift`：AI 任务规划、执行、重规划、最终验收、事实记忆。
- `LiquidAIBrowser/PDFReportExporter.swift`：任务 PDF 报告，720p 等比例关键截图，最多 10 张，日志最多 120 行。

## v1.4.11 fixes

- Structured findings memory for multi-site tasks.
- Multi-page final verification.
- Fixed duplicate step snapshot cache.
- Fixed PDF compact snapshot selection.
- Reduced timer worker restart noise.
