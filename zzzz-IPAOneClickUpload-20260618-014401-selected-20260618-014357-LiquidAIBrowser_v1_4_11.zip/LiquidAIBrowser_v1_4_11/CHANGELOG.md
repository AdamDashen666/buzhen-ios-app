# CHANGELOG

## v1.4.11

- 新增 AgentFinding 结构化事实记忆，避免多网站任务中重复测试或忘记已完成平台。
- Agent 决策 schema 新增 findings 字段，用于记录 works / requires_login / failed / unknown 等结论。
- 最终验收读取所有参与页面状态，并结合 findings 检查，不再只看当前活动页。
- 计时器动作后 worker 不再退出，减少“任务 worker 已启动”重复日志。
- 修复 captureStepSnapshot 重复 appendStepSnapshot 导致截图缓存翻倍。
- 修复 PDF exporter 使用 task.stepSnapshots 全量输出的问题，现在真正使用 compactSnapshots。
- PDF 详细日志最多输出 120 行，完整日志保留在任务卡复制。
- 版本更新到 1.4.11 / build 18。

# CHANGELOG

## v1.4.10

- 将步骤截图缓存统一压缩为 720p 级别 JPEG，降低 PDF 与任务缓存体积。
- PDF 报告默认只放最多 10 张关键截图，避免动辄十几页。
- 图片绘制保持等比例，不裁切、不压扁、不拉伸。
- 版本更新到 1.4.10 / build 17。


## v1.4.9

- 修复 Teams 发消息任务卡住：不再把“能读取网页/DOM 文本出现”误判为输入框已获得真实焦点。
- 新增 activeElement/focus 验证：点击输入框后必须确认目标输入框或其内部元素拥有焦点。
- Teams 页面 `typeText` 不再因 DOM 出现文本就返回成功；未确认富文本编辑器接收时会返回失败并要求重规划。
- 强化 `teamsSendMessage`：聚焦、写入、验证、发送后继续检查聊天记录。
- 最大循环次数默认改为不限制（0 = 不限制）。
- 强化每步后动态重规划：可重写当前步骤、后续步骤，必要时从头重新规划。
- AI 每轮可看到当前分组所有页面的 tabID、标题、URL 和当前/后台状态。
- 任务列表范围修复：分组任务列表只看当前分组；左侧“全部任务”进入全局任务总览页。
- 版本更新到 1.4.9 / build 16。


## v1.4.8

- 修补 Microsoft Teams / Microsoft 登录流兼容策略：Teams/Microsoft 域名使用桌面 Edge 风格 User-Agent，并保持 App 内 WKWebView 原生加载。
- 网页 alert / confirm / prompt 不再弹窗；confirm 默认同意，prompt 使用默认文本或空字符串。
- 新增自动 Cookie/隐私同意脚本，常见“同意 / Accept / Agree / Continue”会自动点击。
- 任务管理新增单个任务“清除”。
- 新增“一键清除已完成任务”和“一键清除已结束任务”。
- 已完成 / 已停止任务默认折叠，只显示摘要；运行中 / 排队 / 等待用户任务默认展开。
- 版本更新到 1.4.8 / build 15。

## v1.4.8

- 外部 App scheme 改为静默拦截，不再弹出遮挡网页的提示框。
- Agent `navigate` 统一走原生 `WKWebView.load`，不再允许 JS 直接 `location.href` 触发外部 App。
- 浏览器兼容性增强：桌面内容模式、桌面 Safari User-Agent、JS 新窗口、媒体播放和 WebView 调试支持。
- 任务卡新增“重试”和“按原计划重试”。
- 重试任务可复用原任务参与页面，也可以进入分组队列。
- 版本更新到 1.4.8 / build 15。


## v1.4.6

- 隐藏系统状态栏，避免时间/电量/VPN 信息压在浏览器顶部挡视野。
- 参考 iPad DaVinci Resolve 的沉浸式界面：顶部浏览器工具栏默认自动隐藏。
- 鼠标/触控板移动到窗口顶部，或轻点顶部热区时，顶部工具栏自动滑出。
- 顶部工具栏离开鼠标后自动收起，释放网页可视区域。
- 顶部工具栏仍保留返回、前进、刷新/停止、地址栏、任务、任务管理、设置等功能。
- 浏览器画布改为从窗口顶部开始铺满，减少固定 UI 对网页内容的遮挡。
- 版本号更新到 1.4.6 / build 13。

## v1.4.5

- 修复 MainActor 编译错误。
- 保留 v1.4.4 的 AI 询问用户、通知、计时器、每步截图缓存、PDF 报告增强和 App 图标。
