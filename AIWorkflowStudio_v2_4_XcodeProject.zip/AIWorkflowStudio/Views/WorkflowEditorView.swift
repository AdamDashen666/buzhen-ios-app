import SwiftUI
import UIKit

private struct ConnectionDraft: Equatable {
    var nodeID: UUID
    var condition: EdgeCondition
}

private struct ViewportFrameKey: PreferenceKey {
    static var defaultValue: CGRect = .zero
    static func reduce(value: inout CGRect, nextValue: () -> CGRect) { value = nextValue() }
}

struct WorkflowEditorView: View {
    @EnvironmentObject private var store: AppStore
    @State private var showingLibrary = false
    @State private var editingNode: WorkflowNode?
    @State private var selectedNodeIDs: Set<UUID> = []
    @State private var copiedNodes: [WorkflowNode] = []
    @State private var connectFrom: ConnectionDraft?
    @State private var dragPoint: CGPoint?
    @State private var zoom: CGFloat = 1.0
    @State private var lastZoom: CGFloat = 1.0
    @State private var nodePositions: [UUID: CGPoint] = [:]
    @State private var dragStartPositions: [UUID: CGPoint] = [:]
    @State private var activeDragNodeIDs: Set<UUID> = []
    @State private var selectedEdgeID: UUID?
    @State private var edgeAwaitingDeleteID: UUID?
    @State private var moduleMenuNode: WorkflowNode?
    @State private var showingSelectionMenu = false
    @State private var addModuleSpawnPoint: CGPoint?
    @State private var viewportSize: CGSize = .zero
    @State private var contentFrame: CGRect = .zero
    @State private var isCommandPressed = false

    private let minimumCanvasSize = CGSize(width: 5200, height: 4200)
    private let minZoom: CGFloat = 0.40
    private let maxZoom: CGFloat = 1.80

    var body: some View {
        NavigationStack {
            Group {
                if let project = store.selectedProject {
                    GeometryReader { proxy in
                        if proxy.size.width > 720 {
                            canvas(project: project, viewport: proxy.size)
                        } else {
                            listEditor(project: project)
                        }
                    }
                } else {
                    ContentUnavailableView("没有项目", systemImage: "folder.badge.plus", description: Text("先在首页新建一个工作流。"))
                }
            }
            .studioBackground()
            .navigationTitle(store.selectedProject?.title ?? "工作流")
            .toolbar { editorToolbar }
            .sheet(isPresented: $showingLibrary) { ModuleLibrarySheet(spawnPoint: addModuleSpawnPoint) }
            .sheet(item: $editingNode) { node in
                if let project = store.selectedProject {
                    NodeDetailView(projectID: project.id, node: node)
                }
            }
            .overlay { autoBuildOverlay }
            .alert(item: $store.appAlert) { alert in
                Alert(title: Text(alert.title), message: Text(alert.message), dismissButton: .default(Text("知道了")))
            }
            .confirmationDialog("多选操作", isPresented: $showingSelectionMenu, titleVisibility: .visible) {
                selectionMenuActions
            } message: {
                Text("已选中 \(selectedNodeIDs.count) 个模块")
            }
        }
    }

    @ViewBuilder
    private var selectionMenuActions: some View {
        if let project = store.selectedProject {
            Button("复制选中模块") {
                copySelection(project: project)
                showingSelectionMenu = false
            }
            Button("粘贴到原模块附近") {
                pasteSelection(project: project)
                showingSelectionMenu = false
            }
            Button("删除选中模块", role: .destructive) {
                deleteSelection(project: project)
                showingSelectionMenu = false
            }
        }
        Button("取消", role: .cancel) {
            showingSelectionMenu = false
        }
    }

    @ToolbarContentBuilder
    private var editorToolbar: some ToolbarContent {
        ToolbarItemGroup(placement: .topBarTrailing) {
            Button("添加模块") {
                addModuleSpawnPoint = visibleCenterPoint()
                showingLibrary = true
            }
            Button("AI 自动选择") { store.startAutoBuildSelectedProject() }
            Button("一键应用默认模型") { store.applyDefaultModelsToSelectedProject() }
            Button { store.startSelectedProjectRun() } label: { Label("运行", systemImage: "play.fill") }
            Button(role: .destructive) { store.stopActiveRun() } label: { Label("停止", systemImage: "stop.fill") }
        }
    }

    @ViewBuilder
    private func moduleMenuOverlay(project: WorkflowProject) -> some View {
        if let node = moduleMenuNode, selectedNodeIDs.count == 1, selectedNodeIDs.contains(node.id) {
            let position = localPosition(for: node)
            VStack(spacing: 8) {
                Button { editingNode = node; moduleMenuNode = nil } label: {
                    Label("打开详情", systemImage: "slider.horizontal.3")
                }
                Button { copiedNodes = [node]; moduleMenuNode = nil } label: {
                    Label("复制", systemImage: "doc.on.doc")
                }
                if canDeleteNode(node) {
                    Button(role: .destructive) { deleteMenuNode(node) } label: {
                        Label("删除", systemImage: "trash")
                    }
                }
            }
            .font(.caption.weight(.semibold))
            .buttonStyle(.borderedProminent)
            .controlSize(.small)
            .padding(10)
            .background(.black.opacity(0.72), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous).stroke(.white.opacity(0.22), lineWidth: 1))
            .shadow(color: .black.opacity(0.35), radius: 16, x: 0, y: 8)
            .position(x: position.x, y: max(70, position.y - 120))
            .zIndex(60)
        }
    }

    private func canvas(project: WorkflowProject, viewport: CGSize) -> some View {
        let visibleRect = currentVisibleRect(viewport: viewport)
        let runningIDs = Set(store.selectedProjectActiveRun?.currentNodeIDs ?? [])
        let visibleNodes = project.nodes.filter { node in
            visibleRect.insetBy(dx: -600, dy: -500).contains(localPosition(for: node)) || activeDragNodeIDs.contains(node.id)
        }
        let canvasSize = dynamicCanvasSize(for: project, viewport: viewport)

        return ScrollView([.horizontal, .vertical], showsIndicators: false) {
            ZStack(alignment: .topLeading) {
                GeometryReader { geo in
                    Color.clear.preference(key: ViewportFrameKey.self, value: geo.frame(in: .named("workflowScroll")))
                }
                .frame(width: 0, height: 0)

                Rectangle()
                    .fill(Color.clear)
                    .frame(width: canvasSize.width, height: canvasSize.height)
                    .contentShape(Rectangle())
                    .onTapGesture { clearSelection() }

                edgeLayer(project: project, visibleRect: visibleRect, canvasSize: canvasSize)

                ForEach(visibleNodes) { node in
                    nodeCard(node: node, project: project, runningIDs: runningIDs)
                }

                moduleMenuOverlay(project: project)
            }
            .frame(width: canvasSize.width, height: canvasSize.height, alignment: .topLeading)
            .coordinateSpace(name: "workflowCanvas")
            .scaleEffect(zoom, anchor: .topLeading)
            .frame(width: canvasSize.width * zoom, height: canvasSize.height * zoom, alignment: .topLeading)
            .contentShape(Rectangle())
            .gesture(zoomGesture)
            .background(keyCommandLayer(project: project))
            .onAppear {
                viewportSize = viewport
                syncNodePositions(project)
            }
            .onChange(of: project.nodes) { _, _ in
                guard activeDragNodeIDs.isEmpty else { return }
                syncNodePositions(project)
            }
            .onPreferenceChange(ViewportFrameKey.self) { frame in
                contentFrame = frame
                viewportSize = viewport
            }
            .transaction { transaction in transaction.animation = nil }
        }
        .scrollDisabled(!activeDragNodeIDs.isEmpty || connectFrom != nil)
        .coordinateSpace(name: "workflowScroll")
        .overlay(alignment: .topLeading) { leftControls(project: project).padding(12) }
        .overlay(alignment: .topTrailing) { rightControls(project: project).padding(12) }
        .overlay(alignment: .bottomLeading) { hintBar.padding(12) }
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
    }

    private func nodeCard(node: WorkflowNode, project: WorkflowProject, runningIDs: Set<UUID>) -> some View {
        let position = localPosition(for: node)
        let selected = selectedNodeIDs.contains(node.id)
        return NodeCard(
            node: node,
            selected: selected,
            running: runningIDs.contains(node.id),
            isDragging: activeDragNodeIDs.contains(node.id),
            isConnecting: connectFrom?.nodeID == node.id,
            multiSelectedCount: selectedNodeIDs.count,
            onSelect: { handleNodeTap(node) },
            onInputTap: { finishTapConnection(to: node, project: project) },
            onOutputTap: { condition in startPortConnection(from: node, condition: condition) },
            onOutputDragChanged: { condition, value in updatePortDrag(from: node, condition: condition, value: value) },
            onOutputDragEnded: { condition, value in finishPortDrag(from: node, condition: condition, value: value, project: project) },
            onCardDragChanged: { value in updateNodeDrag(node: node, value: value, project: project) },
            onCardDragEnded: { value in finishNodeDrag(node: node, value: value, project: project) }
        )
        .position(x: position.x, y: position.y)
        .zIndex(activeDragNodeIDs.contains(node.id) ? 20 : (selected ? 10 : (runningIDs.contains(node.id) ? 9 : 0)))
        .animation(nil, value: nodePositions[node.id])
    }

    private func keyCommandLayer(project: WorkflowProject) -> some View {
        KeyCommandReader(
            onDelete: { deleteSelection(project: project) },
            onCopy: { copySelection(project: project) },
            onPaste: { pasteSelection(project: project) },
            onUndo: { undo(project: project) },
            onRedo: { redo(project: project) },
            onCommandStateChange: { isDown in isCommandPressed = isDown }
        )
    }

    private var hintBar: some View {
        Text("空白取消选择 · 按住 ⌘ 点击多选 · 拖模块主体移动 · 只从小接口连线 · ⌘Z 回溯")
            .font(.caption2)
            .foregroundStyle(.white.opacity(0.72))
            .padding(.horizontal, 12)
            .padding(.vertical, 8)
            .background(.black.opacity(0.28), in: Capsule())
    }

    private var autoBuildOverlay: some View {
        Group {
            if store.isAutoBuilding {
                VStack(spacing: 12) {
                    ProgressView(value: store.autoBuildProgress)
                    Text(store.autoBuildMessage).font(.headline)
                    Text("正在把全部可用模块说明发给默认文本模型，并生成节点与连线")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                .padding(24)
                .frame(width: 390)
                .liquidGlass(cornerRadius: 26, glow: true)
            }
        }
    }

    private func leftControls(project: WorkflowProject) -> some View {
        HStack(spacing: 8) {
            Button { undo(project: project) } label: { Label("回溯", systemImage: "arrow.uturn.backward") }
                .disabled(!store.canUndoSelectedProject)
            Button { redo(project: project) } label: { Label("取消回溯", systemImage: "arrow.uturn.forward") }
                .disabled(!store.canRedoSelectedProject)
            Button(role: .destructive) { reset(project: project) } label: { Label("重置", systemImage: "arrow.counterclockwise") }
            Button(role: .destructive) { clearEdges(project: project) } label: { Label("清空连线", systemImage: "link.badge.minus") }
        }
        .buttonStyle(.borderedProminent)
        .controlSize(.small)
    }

    private func rightControls(project: WorkflowProject) -> some View {
        HStack(spacing: 8) {
            Text("缩放 \(Int(zoom * 100))%")
                .font(.caption.weight(.semibold))
                .padding(.horizontal, 10)
                .padding(.vertical, 7)
                .background(.black.opacity(0.28), in: Capsule())
            Button("1:1") { zoom = 1.0; lastZoom = 1.0 }
            Button("整理") { arrange(project: project) }
            Button("一键默认模型") { store.applyDefaultModels(to: project.id) }
        }
        .buttonStyle(.bordered)
        .controlSize(.small)
    }

    private func reset(project: WorkflowProject) {
        store.resetWorkflow(projectID: project.id)
        selectedNodeIDs = []
        selectedEdgeID = nil
        edgeAwaitingDeleteID = nil
        moduleMenuNode = nil
    }

    private func clearEdges(project: WorkflowProject) {
        store.removeAllEdges(projectID: project.id)
        selectedEdgeID = nil
        edgeAwaitingDeleteID = nil
        moduleMenuNode = nil
    }

    private func arrange(project: WorkflowProject) {
        store.arrangeWorkflow(projectID: project.id, around: visibleCenterPoint())
        selectedNodeIDs = []
        selectedEdgeID = nil
        edgeAwaitingDeleteID = nil
        moduleMenuNode = nil
    }

    private func undo(project: WorkflowProject) {
        store.undoSelectedProject()
        selectedNodeIDs = []
        selectedEdgeID = nil
        edgeAwaitingDeleteID = nil
        activeDragNodeIDs = []
        moduleMenuNode = nil
    }

    private func redo(project: WorkflowProject) {
        store.redoSelectedProject()
        selectedNodeIDs = []
        selectedEdgeID = nil
        edgeAwaitingDeleteID = nil
        activeDragNodeIDs = []
        moduleMenuNode = nil
    }

    private func edgeLayer(project: WorkflowProject, visibleRect: CGRect, canvasSize: CGSize) -> some View {
        ZStack(alignment: .topLeading) {
            ForEach(project.edges.filter { edgeVisible($0, in: project, visibleRect: visibleRect) }) { edge in
                edgeView(edge: edge, project: project)
            }

            if let connectFrom,
               let source = project.nodes.first(where: { $0.id == connectFrom.nodeID }),
               let dragPoint {
                EdgeCurveShape(start: portPoint(for: source, condition: connectFrom.condition), end: dragPoint)
                    .stroke(edgeColor(connectFrom.condition).opacity(0.92), lineWidth: 3)
            }
        }
        .frame(width: canvasSize.width, height: canvasSize.height)
    }

    private func edgeView(edge: WorkflowEdge, project: WorkflowProject) -> some View {
        ZStack(alignment: .topLeading) {
            if let points = edgePoints(edge, in: project) {
                let selected = selectedEdgeID == edge.id
                EdgeCurveShape(start: points.start, end: points.end)
                    .stroke(edgeColor(edge).opacity(selected ? 0.95 : 0.68), lineWidth: selected ? 4 : 2.2)
                EdgeCurveShape(start: points.start, end: points.end)
                    .stroke(Color.white.opacity(0.001), lineWidth: 34)
                    .contentShape(EdgeCurveShape(start: points.start, end: points.end))
                    .onTapGesture { handleEdgeTap(edge) }
                if edge.condition != .always {
                    Text(edge.condition.title)
                        .font(.caption2.bold())
                        .foregroundStyle(edgeColor(edge))
                        .position(midpoint(points.start, points.end))
                }
                if edgeAwaitingDeleteID == edge.id {
                    Button(role: .destructive) { deleteEdge(edge, project: project) } label: {
                        Label("删除连线", systemImage: "trash").font(.caption.bold())
                    }
                    .buttonStyle(.borderedProminent)
                    .controlSize(.small)
                    .position(CGPoint(x: midpoint(points.start, points.end).x, y: midpoint(points.start, points.end).y - 34))
                }
            }
        }
    }

    private func handleEdgeTap(_ edge: WorkflowEdge) {
        if selectedEdgeID == edge.id { edgeAwaitingDeleteID = edge.id } else {
            selectedEdgeID = edge.id
            selectedNodeIDs = []
            edgeAwaitingDeleteID = nil
        }
    }

    private func deleteEdge(_ edge: WorkflowEdge, project: WorkflowProject) {
        store.removeEdge(projectID: project.id, edgeID: edge.id)
        selectedEdgeID = nil
        edgeAwaitingDeleteID = nil
    }

    private func currentVisibleRect(viewport: CGSize) -> CGRect {
        guard contentFrame != .zero else { return CGRect(x: 0, y: 0, width: 1800, height: 1200) }
        return CGRect(
            x: max(0, -contentFrame.minX / max(zoom, 0.1)),
            y: max(0, -contentFrame.minY / max(zoom, 0.1)),
            width: viewport.width / max(zoom, 0.1),
            height: viewport.height / max(zoom, 0.1)
        ).insetBy(dx: -900, dy: -700)
    }

    private func visibleCenterPoint() -> CGPoint {
        let fallback = viewportSize == .zero ? CGSize(width: 1200, height: 800) : viewportSize
        let rect = currentVisibleRect(viewport: fallback)
        return unclampedPoint(x: rect.midX, y: rect.midY)
    }

    private func dynamicCanvasSize(for project: WorkflowProject, viewport: CGSize) -> CGSize {
        let visible = currentVisibleRect(viewport: viewport)
        let maxX = max(project.nodes.map { CGFloat($0.x) }.max() ?? 0, visible.maxX)
        let maxY = max(project.nodes.map { CGFloat($0.y) }.max() ?? 0, visible.maxY)
        return CGSize(
            width: max(minimumCanvasSize.width, maxX + viewport.width / max(zoom, 0.1) + 1800),
            height: max(minimumCanvasSize.height, maxY + viewport.height / max(zoom, 0.1) + 1600)
        )
    }

    private func edgeVisible(_ edge: WorkflowEdge, in project: WorkflowProject, visibleRect: CGRect) -> Bool {
        guard let points = edgePoints(edge, in: project) else { return false }
        let expanded = visibleRect.insetBy(dx: -700, dy: -700)
        return expanded.contains(points.start) || expanded.contains(points.end)
    }

    private func edgePoints(_ edge: WorkflowEdge, in project: WorkflowProject) -> (start: CGPoint, end: CGPoint)? {
        guard let from = project.nodes.first(where: { $0.id == edge.from }),
              let to = project.nodes.first(where: { $0.id == edge.to }) else { return nil }
        return (portPoint(for: from, condition: edge.condition), inputPortPoint(for: to))
    }

    private func portPoint(for node: WorkflowNode, condition: EdgeCondition) -> CGPoint {
        let p = localPosition(for: node)
        if node.kind.isReviewer && condition == .failed { return CGPoint(x: p.x + 124, y: p.y + 46) }
        return CGPoint(x: p.x + 124, y: p.y - (node.kind.isReviewer ? 26 : 0))
    }

    private func inputPortPoint(for node: WorkflowNode) -> CGPoint {
        let p = localPosition(for: node)
        return CGPoint(x: p.x - 124, y: p.y)
    }

    private func edgeColor(_ edge: WorkflowEdge) -> Color { edgeColor(edge.condition) }
    private func edgeColor(_ condition: EdgeCondition) -> Color {
        switch condition {
        case .failed, .scoreLow: return .red
        case .passed, .scoreHigh: return .mint
        case .always: return .cyan
        }
    }

    private func localPosition(for node: WorkflowNode) -> CGPoint {
        nodePositions[node.id] ?? CGPoint(x: CGFloat(node.x), y: CGFloat(node.y))
    }

    private func syncNodePositions(_ project: WorkflowProject) {
        var next = nodePositions
        let ids = Set(project.nodes.map(\.id))
        next = next.filter { ids.contains($0.key) }
        for node in project.nodes where !activeDragNodeIDs.contains(node.id) {
            next[node.id] = CGPoint(x: CGFloat(node.x), y: CGFloat(node.y))
        }
        withAnimation(nil) { nodePositions = next }
    }

    private func unclampedPoint(x: CGFloat, y: CGFloat) -> CGPoint {
        CGPoint(x: max(x, 120), y: max(y, 100))
    }

    private var zoomGesture: some Gesture {
        MagnificationGesture()
            .onChanged { value in
                guard activeDragNodeIDs.isEmpty && connectFrom == nil else { return }
                let softened = 1 + (value - 1) * 0.10
                zoom = min(max(lastZoom * softened, minZoom), maxZoom)
            }
            .onEnded { _ in lastZoom = zoom }
    }

    private func startPortConnection(from node: WorkflowNode, condition: EdgeCondition) {
        connectFrom = ConnectionDraft(nodeID: node.id, condition: condition)
        dragPoint = portPoint(for: node, condition: condition)
    }

    private func updatePortDrag(from node: WorkflowNode, condition: EdgeCondition, value: DragGesture.Value) {
        connectFrom = ConnectionDraft(nodeID: node.id, condition: condition)
        let start = portPoint(for: node, condition: condition)
        dragPoint = CGPoint(
            x: start.x + value.translation.width / max(zoom, 0.1),
            y: start.y + value.translation.height / max(zoom, 0.1)
        )
    }

    private func finishPortDrag(from node: WorkflowNode, condition: EdgeCondition, value: DragGesture.Value, project: WorkflowProject) {
        let start = portPoint(for: node, condition: condition)
        let endPoint = CGPoint(
            x: start.x + value.translation.width / max(zoom, 0.1),
            y: start.y + value.translation.height / max(zoom, 0.1)
        )
        if let target = targetNode(at: endPoint, in: project, excluding: node.id) {
            store.connect(projectID: project.id, from: node.id, to: target.id, condition: condition)
        }
        connectFrom = nil
        dragPoint = nil
    }

    private func finishTapConnection(to node: WorkflowNode, project: WorkflowProject) {
        if let connectFrom, connectFrom.nodeID != node.id {
            store.connect(projectID: project.id, from: connectFrom.nodeID, to: node.id, condition: connectFrom.condition)
        }
        connectFrom = nil
        dragPoint = nil
    }

    private func dragDelta(_ value: DragGesture.Value) -> CGPoint {
        CGPoint(
            x: value.translation.width / max(zoom, 0.1),
            y: value.translation.height / max(zoom, 0.1)
        )
    }

    private func rawDragDistance(_ value: DragGesture.Value) -> CGFloat {
        hypot(value.translation.width, value.translation.height)
    }

    private func updateNodeDrag(node: WorkflowNode, value: DragGesture.Value, project: WorkflowProject) {
        guard rawDragDistance(value) > 2.5 else { return }
        if activeDragNodeIDs.isEmpty {
            moduleMenuNode = nil
            if !selectedNodeIDs.contains(node.id) { selectedNodeIDs = [node.id] }
            let group = selectedNodeIDs.isEmpty ? Set([node.id]) : selectedNodeIDs
            activeDragNodeIDs = group
            dragStartPositions = Dictionary(uniqueKeysWithValues: group.compactMap { id in
                guard let current = project.nodes.first(where: { $0.id == id }) else { return nil }
                return (id, localPosition(for: current))
            })
        }
        let delta = dragDelta(value)
        var nextPositions = nodePositions
        for id in activeDragNodeIDs {
            guard let start = dragStartPositions[id] else { continue }
            nextPositions[id] = unclampedPoint(x: start.x + delta.x, y: start.y + delta.y)
        }
        var transaction = Transaction()
        transaction.disablesAnimations = true
        transaction.animation = nil
        withTransaction(transaction) { nodePositions = nextPositions }
    }

    private func finishNodeDrag(node: WorkflowNode, value: DragGesture.Value, project: WorkflowProject) {
        guard rawDragDistance(value) > 2.5 else {
            dragStartPositions = [:]
            activeDragNodeIDs = []
            return
        }
        let delta = dragDelta(value)
        var finalPositions: [UUID: CGPoint] = [:]
        for id in activeDragNodeIDs {
            guard let start = dragStartPositions[id] else { continue }
            finalPositions[id] = unclampedPoint(x: start.x + delta.x, y: start.y + delta.y)
        }
        if finalPositions.isEmpty {
            let start = localPosition(for: node)
            finalPositions[node.id] = unclampedPoint(x: start.x + delta.x, y: start.y + delta.y)
        }
        var transaction = Transaction()
        transaction.disablesAnimations = true
        transaction.animation = nil
        withTransaction(transaction) {
            for (id, point) in finalPositions { nodePositions[id] = point }
        }
        store.moveNodes(projectID: project.id, positions: finalPositions, persist: true)
        dragStartPositions = [:]
        activeDragNodeIDs = []
    }

    private func targetNode(at point: CGPoint, in project: WorkflowProject, excluding sourceID: UUID) -> WorkflowNode? {
        project.nodes
            .filter { $0.id != sourceID }
            .min { lhs, rhs in distance(point, inputPortPoint(for: lhs)) < distance(point, inputPortPoint(for: rhs)) }
            .flatMap { candidate in
                let target = inputPortPoint(for: candidate)
                return distance(point, target) < 120 ? candidate : nil
            }
    }

    private func clearSelection() {
        guard activeDragNodeIDs.isEmpty && connectFrom == nil else { return }
        selectedNodeIDs = []
        selectedEdgeID = nil
        edgeAwaitingDeleteID = nil
        moduleMenuNode = nil
        showingSelectionMenu = false
    }

    private func handleNodeTap(_ node: WorkflowNode) {
        guard activeDragNodeIDs.isEmpty && connectFrom == nil else { return }
        selectedEdgeID = nil
        edgeAwaitingDeleteID = nil
        if isCommandPressed {
            moduleMenuNode = nil
            if selectedNodeIDs.contains(node.id) {
                selectedNodeIDs.remove(node.id)
            } else {
                selectedNodeIDs.insert(node.id)
            }
            return
        }
        if selectedNodeIDs.count == 1 && selectedNodeIDs.contains(node.id) {
            moduleMenuNode = node
        } else {
            selectedNodeIDs = [node.id]
            moduleMenuNode = nil
        }
    }

    private func canDeleteNode(_ node: WorkflowNode) -> Bool {
        node.kind != .start && node.kind != .output && store.selectedProject != nil
    }

    private func deleteMenuNode(_ node: WorkflowNode) {
        guard let project = store.selectedProject else { return }
        store.removeNode(projectID: project.id, nodeID: node.id)
        selectedNodeIDs.remove(node.id)
        moduleMenuNode = nil
    }

    private func deleteSelection(project: WorkflowProject) {
        if let edgeID = selectedEdgeID {
            store.removeEdge(projectID: project.id, edgeID: edgeID)
            selectedEdgeID = nil
            edgeAwaitingDeleteID = nil
            return
        }
        store.removeNodes(projectID: project.id, nodeIDs: selectedNodeIDs)
        selectedNodeIDs = []
        moduleMenuNode = nil
    }

    private func copySelection(project: WorkflowProject) {
        copiedNodes = project.nodes.filter { selectedNodeIDs.contains($0.id) && $0.kind != .start && $0.kind != .output }
    }

    private func pasteSelection(project: WorkflowProject) {
        guard !copiedNodes.isEmpty else { return }
        selectedNodeIDs = store.pasteNodes(copiedNodes, to: project.id, near: nil)
    }

    private func midpoint(_ a: CGPoint, _ b: CGPoint) -> CGPoint {
        CGPoint(x: (a.x + b.x) / 2, y: (a.y + b.y) / 2)
    }

    private func distance(_ a: CGPoint, _ b: CGPoint) -> CGFloat {
        hypot(a.x - b.x, a.y - b.y)
    }

    private func listEditor(project: WorkflowProject) -> some View {
        List {
            Section("快速操作") {
                Button { store.applyDefaultModels(to: project.id) } label: { Label("一键应用全局默认模型", systemImage: "bolt.badge.checkmark") }
                Button { store.startSelectedProjectRun() } label: { Label("运行工作流", systemImage: "play.fill") }
                Button(role: .destructive) { store.stopActiveRun() } label: { Label("停止运行", systemImage: "stop.fill") }
                Button { store.undoSelectedProject() } label: { Label("回溯", systemImage: "arrow.uturn.backward") }
                Button { store.redoSelectedProject() } label: { Label("取消回溯", systemImage: "arrow.uturn.forward") }
                Button { store.arrangeWorkflow(projectID: project.id, around: CGPoint(x: 360, y: 240)) } label: { Label("整理布局", systemImage: "square.grid.2x2") }
                Button(role: .destructive) { store.resetWorkflow(projectID: project.id) } label: { Label("重置：清除所有模块", systemImage: "arrow.counterclockwise") }
                Button(role: .destructive) { store.removeAllEdges(projectID: project.id) } label: { Label("清空全部连线", systemImage: "link.badge.minus") }
            }
            Section("节点") {
                ForEach(project.nodes) { node in
                    Button { handleNodeTap(node) } label: {
                        VStack(alignment: .leading, spacing: 4) {
                            Label(node.title, systemImage: node.kind.icon)
                            Text(node.kind.summary).font(.caption).foregroundStyle(.secondary)
                        }
                    }
                }
                .onDelete { offsets in
                    let ids = Set(offsets.map { project.nodes[$0].id })
                    store.removeNodes(projectID: project.id, nodeIDs: ids)
                }
            }
            Section("连线") {
                if project.edges.isEmpty {
                    Text("暂无连线。iPad 横屏下从模块小接口拖动可以连线。")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                ForEach(project.edges) { edge in
                    HStack {
                        Text("\(project.nodes.first(where: { $0.id == edge.from })?.title ?? "?") → \(project.nodes.first(where: { $0.id == edge.to })?.title ?? "?")")
                        Text(edge.condition.title).font(.caption).foregroundStyle(.secondary)
                        Spacer()
                        Button(role: .destructive) { store.removeEdge(projectID: project.id, edgeID: edge.id) } label: { Image(systemName: "trash") }
                    }
                }
            }
        }
        .scrollContentBackground(.hidden)
    }
}

struct EdgeCurveShape: Shape {
    var start: CGPoint
    var end: CGPoint

    func path(in rect: CGRect) -> Path {
        var path = Path()
        path.move(to: start)
        let dx = max(abs(end.x - start.x) * 0.45, 80)
        path.addCurve(
            to: end,
            control1: CGPoint(x: start.x + dx, y: start.y),
            control2: CGPoint(x: end.x - dx, y: end.y)
        )
        return path
    }
}

struct NodeCard: View {
    var node: WorkflowNode
    var selected: Bool
    var running: Bool
    var isDragging: Bool
    var isConnecting: Bool
    var multiSelectedCount: Int
    var onSelect: () -> Void
    var onInputTap: () -> Void
    var onOutputTap: (EdgeCondition) -> Void
    var onOutputDragChanged: (EdgeCondition, DragGesture.Value) -> Void
    var onOutputDragEnded: (EdgeCondition, DragGesture.Value) -> Void
    var onCardDragChanged: (DragGesture.Value) -> Void
    var onCardDragEnded: (DragGesture.Value) -> Void

    var body: some View {
        let base = HStack(spacing: 10) {
            inputPort
            content
            outputPorts
        }
        .padding()
        .overlay(border)
        .transaction { transaction in transaction.animation = nil }

        if isDragging {
            base
                .background(
                    RoundedRectangle(cornerRadius: 22, style: .continuous)
                        .fill(Color.black.opacity(0.72))
                )
                .overlay(
                    RoundedRectangle(cornerRadius: 22, style: .continuous)
                        .stroke(Color.mint.opacity(0.90), lineWidth: 2)
                )
                .shadow(color: .black.opacity(0.18), radius: 6, x: 0, y: 4)
                .animation(nil, value: isDragging)
        } else {
            base
                .background(
                    ZStack {
                        RoundedRectangle(cornerRadius: 22, style: .continuous)
                            .fill(.ultraThinMaterial)
                        RoundedRectangle(cornerRadius: 22, style: .continuous)
                            .fill(
                                LinearGradient(
                                    colors: [Color.white.opacity(0.13), Color.cyan.opacity(0.07), Color.black.opacity(0.20)],
                                    startPoint: .topLeading,
                                    endPoint: .bottomTrailing
                                )
                            )
                    }
                )
                .overlay(
                    RoundedRectangle(cornerRadius: 22, style: .continuous)
                        .stroke(.white.opacity(0.26), lineWidth: 1)
                )
                .shadow(color: .black.opacity(0.25), radius: 18, x: 0, y: 10)
                .shadow(color: .cyan.opacity((isConnecting || selected || running) ? 0.16 : 0), radius: 24, x: 0, y: 8)
        }
    }

    private var inputPort: some View {
        port(title: "输入", systemImage: "arrow.down.circle.fill", color: .cyan)
            .onTapGesture(perform: onInputTap)
    }

    private var content: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Image(systemName: node.kind.icon)
                Text(node.title).font(.headline)
            }
            Text(node.kind.summary)
                .font(.caption)
                .foregroundStyle(.secondary)
                .lineLimit(2)
            HStack {
                Text(running ? "运行中" : node.status.title)
                    .font(.caption2.bold())
                    .padding(.horizontal, 8)
                    .padding(.vertical, 4)
                    .background((running ? Color.orange : Color.cyan).opacity(0.20), in: Capsule())
                Text(selected ? (multiSelectedCount > 1 ? "多选中" : "已选中，再点菜单") : "拖模块移动")
                    .font(.caption2)
                    .foregroundStyle(.secondary)
            }
        }
        .frame(width: 184, alignment: .leading)
        .contentShape(RoundedRectangle(cornerRadius: 18))
        .onTapGesture(perform: onSelect)
        .highPriorityGesture(
            DragGesture(minimumDistance: 0)
                .onChanged(onCardDragChanged)
                .onEnded(onCardDragEnded)
        )
    }

    private var outputPorts: some View {
        VStack(spacing: 8) {
            outputPort(title: node.kind.isReviewer ? "通过" : "输出", condition: node.kind.isReviewer ? .passed : .always, color: .mint)
            if node.kind.isReviewer {
                outputPort(title: "不合格", condition: .failed, color: .red)
            }
        }
    }

    private var border: some View {
        RoundedRectangle(cornerRadius: 22, style: .continuous)
            .stroke(borderColor, lineWidth: selected || running ? 2.5 : 0)
    }

    private var borderColor: Color {
        if running { return .orange.opacity(0.95) }
        if selected { return .mint.opacity(0.90) }
        return .clear
    }

    private func outputPort(title: String, condition: EdgeCondition, color: Color) -> some View {
        port(title: title, systemImage: condition == .failed ? "xmark.circle.fill" : "arrow.up.circle.fill", color: color)
            .onTapGesture { onOutputTap(condition) }
            .gesture(
                DragGesture(minimumDistance: 0)
                    .onChanged { onOutputDragChanged(condition, $0) }
                    .onEnded { onOutputDragEnded(condition, $0) }
            )
    }

    private func port(title: String, systemImage: String, color: Color) -> some View {
        VStack(spacing: 3) {
            Image(systemName: systemImage)
                .font(.title3)
                .foregroundStyle(color)
                .padding(8)
                .background(.black.opacity(0.24), in: Circle())
                .overlay(Circle().stroke(color.opacity(0.65), lineWidth: 1.5))
            Text(title)
                .font(.caption2)
                .foregroundStyle(.secondary)
        }
        .contentShape(Rectangle())
    }
}

struct KeyCommandReader: UIViewRepresentable {
    var onDelete: () -> Void
    var onCopy: () -> Void
    var onPaste: () -> Void
    var onUndo: () -> Void
    var onRedo: () -> Void
    var onCommandStateChange: (Bool) -> Void = { _ in }

    func makeUIView(context: Context) -> KeyCatcherView {
        let view = KeyCatcherView()
        update(view)
        DispatchQueue.main.async { view.becomeFirstResponder() }
        return view
    }

    func updateUIView(_ uiView: KeyCatcherView, context: Context) {
        update(uiView)
        DispatchQueue.main.async { uiView.becomeFirstResponder() }
    }

    private func update(_ view: KeyCatcherView) {
        view.onDelete = onDelete
        view.onCopy = onCopy
        view.onPaste = onPaste
        view.onUndo = onUndo
        view.onRedo = onRedo
        view.onCommandStateChange = onCommandStateChange
    }
}

final class KeyCatcherView: UIView {
    var onDelete: (() -> Void)?
    var onCopy: (() -> Void)?
    var onPaste: (() -> Void)?
    var onUndo: (() -> Void)?
    var onRedo: (() -> Void)?
    var onCommandStateChange: ((Bool) -> Void)?

    override var canBecomeFirstResponder: Bool { true }

    override func pressesBegan(_ presses: Set<UIPress>, with event: UIPressesEvent?) {
        if event?.modifierFlags.contains(.command) == true { onCommandStateChange?(true) }
        super.pressesBegan(presses, with: event)
    }

    override func pressesEnded(_ presses: Set<UIPress>, with event: UIPressesEvent?) {
        if event?.modifierFlags.contains(.command) != true { onCommandStateChange?(false) }
        super.pressesEnded(presses, with: event)
    }

    override func pressesCancelled(_ presses: Set<UIPress>, with event: UIPressesEvent?) {
        onCommandStateChange?(false)
        super.pressesCancelled(presses, with: event)
    }

    override var keyCommands: [UIKeyCommand]? {
        [
            UIKeyCommand(input: UIKeyCommand.inputDelete, modifierFlags: [], action: #selector(deletePressed)),
            UIKeyCommand(input: "c", modifierFlags: .command, action: #selector(copyPressed)),
            UIKeyCommand(input: "v", modifierFlags: .command, action: #selector(pastePressed)),
            UIKeyCommand(input: "z", modifierFlags: .command, action: #selector(undoPressed)),
            UIKeyCommand(input: "z", modifierFlags: [.command, .shift], action: #selector(redoPressed)),
            UIKeyCommand(input: "y", modifierFlags: .command, action: #selector(redoPressed))
        ]
    }

    @objc private func deletePressed() { onDelete?() }
    @objc private func copyPressed() { onCopy?() }
    @objc private func pastePressed() { onPaste?() }
    @objc private func undoPressed() { onUndo?() }
    @objc private func redoPressed() { onRedo?() }
}
