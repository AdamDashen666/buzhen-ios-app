import SwiftUI
import UIKit

@main
struct BuzhenLocalApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
                .background(StageManagerWindowConfigurator())
        }
    }
}

/// Keeps the app usable in iPad Stage Manager / Split View / floating windows.
/// It does not force one physical iPad size; it only prevents the window from being resized
/// so small that the Liquid Glass controls collapse. Full-screen still works normally.
private struct StageManagerWindowConfigurator: UIViewControllerRepresentable {
    func makeUIViewController(context: Context) -> Controller {
        Controller()
    }

    func updateUIViewController(_ uiViewController: Controller, context: Context) {
        uiViewController.applyWindowRestrictions()
    }

    final class Controller: UIViewController {
        override func viewDidAppear(_ animated: Bool) {
            super.viewDidAppear(animated)
            applyWindowRestrictions()
        }

        override func viewDidLayoutSubviews() {
            super.viewDidLayoutSubviews()
            applyWindowRestrictions()
        }

        func applyWindowRestrictions() {
            guard UIDevice.current.userInterfaceIdiom == .pad,
                  let scene = view.window?.windowScene else { return }

            scene.sizeRestrictions?.minimumSize = CGSize(width: 680, height: 520)
        }
    }
}
