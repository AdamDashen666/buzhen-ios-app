import Foundation

// 完整模块系统：覆盖计划者、工作者、检查者、代码检查者、图片理解、多模型投票、日志、版本快照、输出等。
enum WorkflowNodeKind: String, Codable, CaseIterable, Identifiable {
    case start
    case autoGraph
    case planner
    case dispatcher
    case worker
    case optimizer
    case custom
    case codeWorker
    case codeReviewer
    case autoFixer
    case imageUnderstanding
    case imageGenerator
    case multiModelVote
    case qualityReviewer
    case visualReviewer
    case aggregator
    case formatter
    case filePackager
    case humanApproval
    case logger
    case versionSnapshot
    case output

    var id: String { rawValue }

    var title: String {
        switch self {
        case .start: return "开始模块"
        case .autoGraph: return "AI 自动选择模块"
        case .planner: return "计划者"
        case .dispatcher: return "任务分配者"
        case .worker: return "通用工作者"
        case .optimizer: return "意见提出者 / 优化者"
        case .custom: return "自定义模块"
        case .codeWorker: return "代码工作者"
        case .codeReviewer: return "代码检查者"
        case .autoFixer: return "自动修复者（旧版保留）"
        case .imageUnderstanding: return "图片理解 / 识别"
        case .imageGenerator: return "图片生成者"
        case .multiModelVote: return "多模型投票"
        case .qualityReviewer: return "检查者 / 质量评估"
        case .visualReviewer: return "视觉检查者"
        case .aggregator: return "汇总者"
        case .formatter: return "格式转换者"
        case .filePackager: return "文件打包者"
        case .humanApproval: return "人工确认"
        case .logger: return "日志记录"
        case .versionSnapshot: return "版本快照"
        case .output: return "输出模块"
        }
    }

    var icon: String {
        switch self {
        case .start: return "play.circle"
        case .autoGraph: return "wand.and.stars"
        case .planner: return "list.bullet.clipboard"
        case .dispatcher: return "arrow.triangle.branch"
        case .worker: return "person.text.rectangle"
        case .optimizer: return "lightbulb.max"
        case .custom: return "slider.horizontal.3"
        case .codeWorker: return "chevron.left.forwardslash.chevron.right"
        case .codeReviewer: return "checkmark.seal"
        case .autoFixer: return "wrench.and.screwdriver"
        case .imageUnderstanding: return "photo.on.rectangle.angled"
        case .imageGenerator: return "paintbrush.pointed"
        case .multiModelVote: return "person.3.sequence"
        case .qualityReviewer: return "star.leadinghalf.filled"
        case .visualReviewer: return "eye"
        case .aggregator: return "square.stack.3d.up"
        case .formatter: return "doc.richtext"
        case .filePackager: return "archivebox"
        case .humanApproval: return "hand.raised"
        case .logger: return "list.clipboard"
        case .versionSnapshot: return "clock.arrow.circlepath"
        case .output: return "tray.and.arrow.down"
        }
    }

    var summary: String {
        switch self {
        case .start: return "整个工作流的入口，用来写需求、上传图片和文件。"
        case .autoGraph: return "根据需求自动推荐模块，并自动生成推荐连线。"
        case .planner: return "把大目标拆成步骤、风险点和交付物。"
        case .dispatcher: return "读取自己真实连到哪些工作者，再把任务分配给这些下游模块，适合并行处理。"
        case .worker: return "处理普通写作、总结、整理和分析。"
        case .optimizer: return "阅读上游阶段结果，提出问题、风险、可改进点和下一轮修改方向。"
        case .custom: return "用户自定义角色、提示词、输入输出规则的模块。"
        case .codeWorker: return "生成代码、文件结构和项目说明。"
        case .codeReviewer: return "专门检查代码语法、依赖、架构、安全和可运行性。"
        case .autoFixer: return "旧版保留模块。新版建议直接用检查者的不合格出口打回原工作者。"
        case .imageUnderstanding: return "识别图片、截图、作业题、图表、UI 和代码截图。"
        case .imageGenerator: return "生成图片提示词、图标方案、UI 草图或素材说明。"
        case .multiModelVote: return "让多个模型回答同一问题，再用投票/裁判选择结果。"
        case .qualityReviewer: return "检查最终质量，给分，不合格时打回。"
        case .visualReviewer: return "检查 UI、排版、颜色、可读性和移动端适配。"
        case .aggregator: return "合并多个模块输出，去重并统一风格。"
        case .formatter: return "把上游内容转换成指定格式或具体文件内容，例如 snake.py、README.md、index.html。"
        case .filePackager: return "读取格式转换者/工作者输出的文件块，整理目录结构并准备真实 ZIP。"
        case .humanApproval: return "在关键步骤暂停，等用户确认后再继续。"
        case .logger: return "记录输入、输出、模型、Token、错误和耗时。"
        case .versionSnapshot: return "保存当前工作流结构、提示词、模型配置和输出。"
        case .output: return "最终展示和导出入口，只接收上游结果，不再重新整理或转换。"
        }
    }

    var inputDescription: String {
        switch self {
        case .start: return "输入：用户提示词、要求、图片和文件。"
        case .autoGraph: return "输入：开始模块的需求文本、上传资源、用户勾选的自动选择开关。"
        case .planner: return "输入：用户需求、图片理解结果、已有上下文。"
        case .dispatcher: return "输入：计划者输出、项目目标，以及当前画布中实际连接到它的下游工作者列表。"
        case .worker: return "输入：计划者/分配者给出的具体任务和上游资料；也可以接收优化者的修改意见。"
        case .optimizer: return "输入：任意上游模块的当前结果、用户目标、已有输出或草稿。"
        case .custom: return "输入：用户在模块提示词中指定的上游内容、文件、图片或文本。"
        case .codeWorker: return "输入：代码需求、技术栈、文件结构要求、上游方案。"
        case .codeReviewer: return "输入：代码工作者生成的代码、文件结构和运行说明。"
        case .autoFixer: return "输入：旧版自动修复流程的检查意见。"
        case .imageUnderstanding: return "输入：开始模块或项目资源里的图片、截图、图表。"
        case .imageGenerator: return "输入：图片需求、风格、尺寸、参考说明。"
        case .multiModelVote: return "输入：同一问题或多个候选答案。"
        case .qualityReviewer: return "输入：工作者、汇总者或输出模块的结果。"
        case .visualReviewer: return "输入：UI 方案、截图、设计稿或前端代码。"
        case .aggregator: return "输入：多个上游模块的结果。"
        case .formatter: return "输入：汇总者、工作者或检查通过后的内容，以及目标文件格式要求。"
        case .filePackager: return "输入：格式转换者输出的文件块、代码文件、README 和目录结构。"
        case .humanApproval: return "输入：需要用户确认的阶段结果。"
        case .logger: return "输入：所有模块运行状态、上下文、错误和 Token 数据。"
        case .versionSnapshot: return "输入：当前项目结构、模块设置、输出结果。"
        case .output: return "输入：文件打包者、格式转换者或汇总者的最终结果。"
        }
    }

    var outputDescription: String {
        switch self {
        case .start: return "输出：标准化需求、资源列表和初始上下文。"
        case .autoGraph: return "输出：建议模块列表和推荐连线。"
        case .planner: return "输出：步骤计划、模块建议、风险和验收标准。"
        case .dispatcher: return "输出：按真实连接的工作者 ID / 标题拆分的子任务、输入要求、期望输出和验收标准。"
        case .worker: return "输出：文本、分析、总结或初稿；接到优化意见后可输出改进版。"
        case .optimizer: return "输出：修改意见、遗漏点、风险提示、优化优先级，可连回工作者继续改进。"
        case .custom: return "输出：由用户自定义提示词决定，可作为后续模块输入。"
        case .codeWorker: return "输出：代码文件、项目结构和运行说明。"
        case .codeReviewer: return "输出：通过/不通过、问题清单、严重程度、修复建议。"
        case .autoFixer: return "输出：旧版修复结果。新版通常不用它。"
        case .imageUnderstanding: return "输出：图片摘要、OCR 文字、关键对象、可操作信息、不确定内容。"
        case .imageGenerator: return "输出：图片生成结果说明、提示词或素材方案。"
        case .multiModelVote: return "输出：获胜答案、投票结果、裁判理由和分歧点。"
        case .qualityReviewer: return "输出：评分、是否通过、返工意见。"
        case .visualReviewer: return "输出：视觉问题、可读性建议、移动端适配建议。"
        case .aggregator: return "输出：合并后的统一版本。"
        case .formatter: return "输出：指定格式的文件块，例如 ```file path=\"snake.py\" ... ```。"
        case .filePackager: return "输出：可打包文件清单；ZIP 导出会把识别到的 .py/.md/.html 等文件放入 generated/。"
        case .humanApproval: return "输出：用户确认结果：继续、修改、终止。"
        case .logger: return "输出：Markdown / JSON / CSV / TXT 日志。"
        case .versionSnapshot: return "输出：可回滚的版本快照。"
        case .output: return "输出：原样展示上游最终结果，并提供导出入口；不是整理者。"
        }
    }

    var defaultPrompt: String {
        switch self {
        case .start: return "接收用户目标、文件、图片和参数。"
        case .autoGraph: return "根据用户目标推荐应添加的模块，并生成默认连线。"
        case .planner: return "拆解目标，列出阶段、风险、所需模块和交付物。"
        case .dispatcher: return "读取实际连接的下游工作者列表，再给每个工作者分配子任务、输入资料、期望输出和验收标准。"
        case .worker: return "执行普通写作、总结、整理、分析任务；如果输入包含优化者意见，请优先根据意见产出改进版。"
        case .optimizer: return "审阅当前上游结果，指出需要修改的地方、缺失内容、风险、优先级和可执行改进建议。不要直接重写全文，主要输出修改意见。"
        case .custom: return "按用户自定义模块提示词执行任务。"
        case .codeWorker: return "生成代码、项目结构、文件内容和运行说明。"
        case .codeReviewer: return "检查语法、依赖、架构、安全、可运行性和 iOS 适配风险，输出通过/不通过与修复建议。"
        case .autoFixer: return "根据代码检查者意见修复代码，并说明修复点。"
        case .imageUnderstanding: return "识别图片内容，输出图片摘要、关键文字、可操作信息和不确定内容。"
        case .imageGenerator: return "根据需求生成图片提示词、图标或 UI 草图方案。"
        case .multiModelVote: return "汇总多个模型回答，用多数票、评分制或裁判模型选择结果。"
        case .qualityReviewer: return "从准确性、完整性、格式、风险四项评分；低于阈值时打回返工。"
        case .visualReviewer: return "检查 UI、排版、颜色、可读性和移动端适配。"
        case .aggregator: return "合并多个模块输出，去重，统一风格。"
        case .formatter: return "把内容转换为具体文件格式。若用户要 Python 文件，输出 snake.py / main.py 这类文件块。"
        case .filePackager: return "读取上游文件块，整理目录结构和 ZIP 打包清单；不要重新改写业务内容。"
        case .humanApproval: return "暂停流程，等待用户确认后继续。"
        case .logger: return "记录模块输入、输出、模型、Token、错误、耗时和返工记录。"
        case .versionSnapshot: return "保存工作流结构、提示词、模型配置和输出快照。"
        case .output: return "最终展示/导出上游结果。不要重新整理、改写、格式转换或打包。"
        }
    }

    var isReviewer: Bool {
        self == .codeReviewer || self == .qualityReviewer || self == .visualReviewer
    }

    var requiresVisionModel: Bool {
        self == .imageUnderstanding || self == .visualReviewer
    }

    var requiresImageGenerationModel: Bool {
        self == .imageGenerator
    }

    var isCodeRelated: Bool {
        self == .codeWorker || self == .codeReviewer || self == .autoFixer
    }

    var isAssignableWorker: Bool {
        switch self {
        case .worker, .codeWorker, .imageUnderstanding, .imageGenerator, .optimizer, .custom, .formatter, .filePackager, .aggregator, .multiModelVote:
            return true
        default:
            return false
        }
    }
}
