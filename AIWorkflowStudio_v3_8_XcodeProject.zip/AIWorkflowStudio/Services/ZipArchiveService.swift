import Foundation

enum ZipArchiveService {
    struct Entry {
        var path: String
        var data: Data
    }

    enum ArchiveError: Error, LocalizedError {
        case entryNameTooLong(String)
        case entryTooLarge(String)
        case archiveTooLarge

        var errorDescription: String? {
            switch self {
            case .entryNameTooLong(let name): return "ZIP 条目名称过长：\(name)"
            case .entryTooLarge(let name): return "ZIP 条目过大，当前轻量打包器暂不支持 Zip64：\(name)"
            case .archiveTooLarge: return "ZIP 文件过大，当前轻量打包器暂不支持 Zip64"
            }
        }
    }

    static func shareableRunArchive(for run: RunRecord) -> URL {
        do {
            return try exportRunArchive(run)
        } catch {
            return exportFallbackReport(run: run, error: error)
        }
    }

    @discardableResult
    static func exportRunArchive(_ run: RunRecord) throws -> URL {
        let exportRoot = FileManager.default.temporaryDirectory
            .appendingPathComponent("AIWorkflowStudio-Exports", isDirectory: true)
        try FileManager.default.createDirectory(at: exportRoot, withIntermediateDirectories: true)

        let fileName = "\(safeFileName(run.projectTitle))-\(run.id.uuidString.prefix(8)).zip"
        let destination = exportRoot.appendingPathComponent(fileName)

        var entries: [Entry] = []
        entries.append(Entry(path: "README.md", data: readme(for: run).utf8Data))
        entries.append(Entry(path: "output/final-output.md", data: (run.output.isEmpty ? LogExportService.markdown(for: run) : run.output).utf8Data))
        entries.append(Entry(path: "logs/run-log.md", data: LogExportService.markdown(for: run).utf8Data))
        entries.append(Entry(path: "logs/events.json", data: try LogExportService.jsonData(for: run)))

        for (index, node) in run.nodeRecords.enumerated() {
            let number = String(format: "%02d", index + 1)
            let name = safeFileName(node.nodeTitle)
            let body = nodeMarkdown(node)
            entries.append(Entry(path: "nodes/\(number)-\(name).md", data: body.utf8Data))
        }

        entries.append(contentsOf: generatedFileEntries(from: run))

        try write(entries: entries, to: destination)
        return destination
    }

    static func write(entries: [Entry], to destination: URL) throws {
        var archive = Data()
        var centralDirectory = Data()
        var centralRecords: [(entry: Entry, crc: UInt32, offset: UInt32)] = []

        for entry in entries {
            let cleanPath = normalizedPath(entry.path)
            let nameData = cleanPath.utf8Data
            guard nameData.count <= Int(UInt16.max) else { throw ArchiveError.entryNameTooLong(cleanPath) }
            guard entry.data.count <= Int(UInt32.max) else { throw ArchiveError.entryTooLarge(cleanPath) }
            guard archive.count <= Int(UInt32.max) else { throw ArchiveError.archiveTooLarge }

            let crc = CRC32.checksum(entry.data)
            let offset = UInt32(archive.count)
            appendLocalHeader(to: &archive, nameData: nameData, crc: crc, size: UInt32(entry.data.count))
            archive.append(entry.data)
            centralRecords.append((Entry(path: cleanPath, data: entry.data), crc, offset))
        }

        let centralStart = UInt32(archive.count)
        for record in centralRecords {
            let nameData = record.entry.path.utf8Data
            appendCentralDirectoryHeader(
                to: &centralDirectory,
                nameData: nameData,
                crc: record.crc,
                size: UInt32(record.entry.data.count),
                localHeaderOffset: record.offset
            )
        }
        guard centralDirectory.count <= Int(UInt32.max), archive.count + centralDirectory.count <= Int(UInt32.max) else {
            throw ArchiveError.archiveTooLarge
        }
        archive.append(centralDirectory)
        appendEndOfCentralDirectory(
            to: &archive,
            entryCount: UInt16(min(centralRecords.count, Int(UInt16.max))),
            centralDirectorySize: UInt32(centralDirectory.count),
            centralDirectoryOffset: centralStart
        )

        if FileManager.default.fileExists(atPath: destination.path) {
            try FileManager.default.removeItem(at: destination)
        }
        try archive.write(to: destination, options: .atomic)
    }

    private static func appendLocalHeader(to data: inout Data, nameData: Data, crc: UInt32, size: UInt32) {
        data.appendUInt32LE(0x04034b50)
        data.appendUInt16LE(20)       // version needed
        data.appendUInt16LE(0)        // flags
        data.appendUInt16LE(0)        // compression method: stored / no compression
        data.appendUInt16LE(0)        // mod time
        data.appendUInt16LE(33)       // mod date: 1980-01-01
        data.appendUInt32LE(crc)
        data.appendUInt32LE(size)
        data.appendUInt32LE(size)
        data.appendUInt16LE(UInt16(nameData.count))
        data.appendUInt16LE(0)        // extra length
        data.append(nameData)
    }

    private static func appendCentralDirectoryHeader(to data: inout Data, nameData: Data, crc: UInt32, size: UInt32, localHeaderOffset: UInt32) {
        data.appendUInt32LE(0x02014b50)
        data.appendUInt16LE(20)       // version made by
        data.appendUInt16LE(20)       // version needed
        data.appendUInt16LE(0)        // flags
        data.appendUInt16LE(0)        // compression method
        data.appendUInt16LE(0)        // mod time
        data.appendUInt16LE(33)       // mod date: 1980-01-01
        data.appendUInt32LE(crc)
        data.appendUInt32LE(size)
        data.appendUInt32LE(size)
        data.appendUInt16LE(UInt16(nameData.count))
        data.appendUInt16LE(0)        // extra length
        data.appendUInt16LE(0)        // comment length
        data.appendUInt16LE(0)        // disk start
        data.appendUInt16LE(0)        // internal attributes
        data.appendUInt32LE(0)        // external attributes
        data.appendUInt32LE(localHeaderOffset)
        data.append(nameData)
    }

    private static func appendEndOfCentralDirectory(to data: inout Data, entryCount: UInt16, centralDirectorySize: UInt32, centralDirectoryOffset: UInt32) {
        data.appendUInt32LE(0x06054b50)
        data.appendUInt16LE(0)        // disk number
        data.appendUInt16LE(0)        // central dir disk
        data.appendUInt16LE(entryCount)
        data.appendUInt16LE(entryCount)
        data.appendUInt32LE(centralDirectorySize)
        data.appendUInt32LE(centralDirectoryOffset)
        data.appendUInt16LE(0)        // comment length
    }

    private static func readme(for run: RunRecord) -> String {
        """
        # \(run.projectTitle)

        这是 AI Workflow Studio 导出的真实 ZIP 项目包。

        - 状态：\(run.status.title)
        - 开始：\(run.startedAt.formatted(date: .abbreviated, time: .standard))
        - Token：\(run.tokenUsage.total)
        - 节点数：\(run.nodeRecords.count)

        ## 目录
        - `output/final-output.md`：最终输出
        - `logs/run-log.md`：Markdown 运行日志
        - `logs/events.json`：完整 JSON 运行记录
        - `nodes/`：每个模块的独立输出
        - `generated/`：从格式转换者/文件打包者/代码工作者输出中识别出的真实文件，例如 `.py`、`.md`、`.html`
        """
    }

    private static func nodeMarkdown(_ node: NodeRunRecord) -> String {
        """
        # \(node.nodeTitle)

        - 类型：\(node.kind.title)
        - 状态：\(node.status.title)
        - 模型：\(node.modelID ?? "未配置")
        - Provider：\(node.providerName ?? "未配置")
        - Token：\(node.tokenUsage.total)

        ## 输入预览

        ```text
        \(node.inputPreview)
        ```

        ## 输出

        ```text
        \(node.output)
        ```

        ## 错误

        \(node.errorMessage ?? "无")
        """
    }

    static func detectGeneratedFilePaths(in text: String) -> [String] {
        extractedFileEntries(from: text, preferredDefaultName: nil).map(\.path)
    }

    private static func generatedFileEntries(from run: RunRecord) -> [Entry] {
        var entries: [Entry] = []
        let sourceNodes = run.nodeRecords.filter { node in
            node.kind == .formatter || node.kind == .filePackager || node.kind == .codeWorker || node.kind == .aggregator
        }

        for node in sourceNodes {
            let fallback = fallbackFileName(for: node)
            entries.append(contentsOf: extractedFileEntries(from: node.output, preferredDefaultName: fallback))
        }

        if entries.isEmpty {
            entries.append(contentsOf: extractedFileEntries(from: run.output, preferredDefaultName: nil))
        }

        var seen = Set<String>()
        var result: [Entry] = []
        for entry in entries {
            let clean = normalizedPath(entry.path)
            guard !clean.isEmpty else { continue }
            let generatedPath = clean.hasPrefix("generated/") ? clean : "generated/\(clean)"
            if seen.insert(generatedPath).inserted {
                result.append(Entry(path: generatedPath, data: entry.data))
            }
        }
        return result
    }

    private static func extractedFileEntries(from text: String, preferredDefaultName: String?) -> [Entry] {
        let lines = text.components(separatedBy: .newlines)
        var entries: [Entry] = []
        var pendingPathHint: String?
        var insideFence = false
        var fencePath: String?
        var fenceLanguage: String?
        var buffer: [String] = []

        for line in lines {
            let trimmed = line.trimmingCharacters(in: .whitespacesAndNewlines)
            if trimmed.hasPrefix("```") {
                if insideFence {
                    let body = buffer.joined(separator: "\n").trimmingCharacters(in: .whitespacesAndNewlines)
                    if !body.isEmpty {
                        let path = fencePath ?? pendingPathHint ?? preferredDefaultName ?? fallbackFileName(forLanguage: fenceLanguage)
                        if let path, isSupportedGeneratedFile(path) {
                            entries.append(Entry(path: path, data: body.utf8Data))
                        }
                    }
                    insideFence = false
                    fencePath = nil
                    fenceLanguage = nil
                    buffer.removeAll()
                    pendingPathHint = nil
                } else {
                    insideFence = true
                    fencePath = pathHint(from: trimmed)
                    fenceLanguage = languageHint(fromFenceOpening: trimmed)
                    buffer.removeAll()
                }
                continue
            }

            if insideFence {
                buffer.append(line)
            } else if let hint = pathHint(from: line) {
                pendingPathHint = hint
            }
        }
        return entries
    }

    private static func pathHint(from line: String) -> String? {
        let cleaned = line
            .replacingOccurrences(of: "`", with: " ")
            .replacingOccurrences(of: "\"", with: " ")
            .replacingOccurrences(of: "'", with: " ")
            .replacingOccurrences(of: "=", with: " ")
            .replacingOccurrences(of: ":", with: " ")
            .replacingOccurrences(of: "，", with: " ")
            .replacingOccurrences(of: "：", with: " ")
        let parts = cleaned.split { ch in
            ch == " " || ch == "\t" || ch == "(" || ch == ")" || ch == "[" || ch == "]" || ch == "<" || ch == ">"
        }
        for part in parts {
            let candidate = String(part).trimmingCharacters(in: CharacterSet(charactersIn: "#*-•"))
            if isSupportedGeneratedFile(candidate) {
                return normalizedPath(candidate)
            }
        }
        return nil
    }

    private static func languageHint(fromFenceOpening opening: String) -> String? {
        let value = opening.replacingOccurrences(of: "```", with: "")
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .lowercased()
        return value.isEmpty ? nil : value
    }

    private static func fallbackFileName(for node: NodeRunRecord) -> String? {
        switch node.kind {
        case .codeWorker, .formatter:
            return "main.py"
        default:
            return nil
        }
    }

    private static func fallbackFileName(forLanguage language: String?) -> String? {
        let value = language?.lowercased() ?? ""
        if value.contains("python") || value == "py" { return "main.py" }
        if value.contains("swift") { return "Sources/App.swift" }
        if value.contains("javascript") || value == "js" { return "index.js" }
        if value.contains("typescript") || value == "ts" { return "index.ts" }
        if value.contains("html") { return "index.html" }
        if value.contains("css") { return "style.css" }
        if value.contains("markdown") || value == "md" { return "README.md" }
        if value.contains("json") { return "data.json" }
        return nil
    }

    private static func isSupportedGeneratedFile(_ path: String) -> Bool {
        let lower = normalizedPath(path).lowercased()
        guard !lower.isEmpty, !lower.contains(".."), lower.count < 180 else { return false }
        let supported = [".py", ".swift", ".js", ".ts", ".html", ".css", ".json", ".md", ".txt", ".plist", ".yml", ".yaml"]
        return supported.contains { lower.hasSuffix($0) }
    }

    private static func exportFallbackReport(run: RunRecord, error: Error) -> URL {
        let exportRoot = FileManager.default.temporaryDirectory
            .appendingPathComponent("AIWorkflowStudio-Exports", isDirectory: true)
        try? FileManager.default.createDirectory(at: exportRoot, withIntermediateDirectories: true)
        let url = exportRoot.appendingPathComponent("zip-export-failed-\(run.id.uuidString.prefix(8)).txt")
        let text = "ZIP 导出失败：\(error.localizedDescription)\n\n" + LogExportService.markdown(for: run)
        try? text.write(to: url, atomically: true, encoding: .utf8)
        return url
    }

    private static func safeFileName(_ value: String) -> String {
        let allowed = CharacterSet.alphanumerics.union(CharacterSet(charactersIn: "-_ ."))
        let scalars = value.unicodeScalars.map { allowed.contains($0) ? Character($0) : "-" }
        let cleaned = String(scalars).trimmingCharacters(in: .whitespacesAndNewlines)
        return cleaned.isEmpty ? "AIWorkflowStudio" : String(cleaned.prefix(80))
    }

    private static func normalizedPath(_ path: String) -> String {
        path.replacingOccurrences(of: "\\", with: "/")
            .split(separator: "/")
            .filter { !$0.isEmpty && $0 != "." && $0 != ".." }
            .joined(separator: "/")
    }
}

private enum CRC32 {
    private static let table: [UInt32] = (0..<256).map { value in
        var crc = UInt32(value)
        for _ in 0..<8 {
            if crc & 1 == 1 {
                crc = 0xedb88320 ^ (crc >> 1)
            } else {
                crc >>= 1
            }
        }
        return crc
    }

    static func checksum(_ data: Data) -> UInt32 {
        var crc: UInt32 = 0xffffffff
        for byte in data {
            crc = table[Int((crc ^ UInt32(byte)) & 0xff)] ^ (crc >> 8)
        }
        return crc ^ 0xffffffff
    }
}

private extension String {
    var utf8Data: Data { Data(utf8) }
}

private extension Data {
    mutating func appendUInt16LE(_ value: UInt16) {
        append(UInt8(value & 0xff))
        append(UInt8((value >> 8) & 0xff))
    }

    mutating func appendUInt32LE(_ value: UInt32) {
        append(UInt8(value & 0xff))
        append(UInt8((value >> 8) & 0xff))
        append(UInt8((value >> 16) & 0xff))
        append(UInt8((value >> 24) & 0xff))
    }
}
