import Foundation

enum WorkflowEngineError: Error, LocalizedError {
    case emptyPrompt
    case noStartNode
    case cancelled
    case safetyLimitReached
    case apiTimeout(String)
    case missingModelConfiguration(String)

    var errorDescription: String? {
        switch self {
        case .emptyPrompt: return "开始模块提示词为空。"
        case .noStartNode: return "工作流缺少开始模块。"
        case .cancelled: return "运行已被停止。"
        case .safetyLimitReached: return "返工循环次数过多，已自动停止以避免卡死。可检查检查者的不合格连线。"
        case .apiTimeout(let message): return message
        case .missingModelConfiguration(let message): return message
        }
    }
}

final class WorkflowEngine {
    private struct ParallelNodeResult {
        var node: WorkflowNode
        var inputContext: String
        var response: AITextResponse?
        var error: Error?
    }

    func run(runID: UUID = UUID(), project: WorkflowProject, apiConfigs: [APIProviderConfig], settings: AppSettings, aiClient: AIClient, onUpdate: @escaping (RunRecord) -> Void) async throws -> RunRecord {
        guard !project.userPrompt.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { throw WorkflowEngineError.emptyPrompt }
        guard let start = project.nodes.first(where: { $0.kind == .start }) else { throw WorkflowEngineError.noStartNode }

        var record = RunRecord(projectID: project.id, projectTitle: project.title)
        record.id = runID
        var contextByNode: [UUID: String] = [:]
        // 节点可能被检查者打回重复执行。旧输出不能被下游当成“最新完成结果”使用，
        // 否则会出现：某个检查者还在运行，但日志/汇总/输出等后续模块已经开始。
        // dirtyNodeIDs 表示该节点及其下游输出已过期，必须等重新执行完成后才能作为依赖。
        var dirtyNodeIDs = Set<UUID>()
        var runningNodeIDs = Set<UUID>()
        var queue: [UUID] = [start.id]
        var visitCounts: [UUID: Int] = [:]
        var returnCounts: [UUID: Int] = [:]
        var waitCounts: [UUID: Int] = [:]
        var executed = 0
        let safetyLimit = max(project.nodes.count * 30, 120)

        func markDirtyCascade(from rootID: UUID) {
            var stack = [rootID]
            var seen = Set<UUID>()
            while let id = stack.popLast() {
                guard seen.insert(id).inserted else { continue }
                dirtyNodeIDs.insert(id)
                let downstream = project.edges.filter { $0.from == id }.map(\.to)
                stack.append(contentsOf: downstream)
            }
        }

        appendLog(&record, .info, nil, "开始运行工作流：\(project.title)")
        record.currentNodeIDs = [start.id]
        record.currentStage = "准备并行调度"
        record.diagnosticMessage = "同一批满足上游条件的模块会并行运行；汇入模块会等待所有必要上游完成。"
        onUpdate(record)

        if let configurationError = missingModelConfigurationMessage(project: project, apiConfigs: apiConfigs, settings: settings) {
            appendLog(&record, .error, nil, configurationError)
            record.status = .failed
            record.endedAt = Date()
            record.currentNodeIDs = []
            record.currentStage = "模型配置缺失"
            record.diagnosticMessage = configurationError
            onUpdate(record)
            throw WorkflowEngineError.missingModelConfiguration(configurationError)
        }

        while !queue.isEmpty {
            try Task.checkCancellation()

            let candidates = queue
            queue.removeAll()

            var readyNodes: [WorkflowNode] = []
            var stillWaiting: [UUID] = []
            var seenThisWave = Set<UUID>()

            for nodeID in candidates {
                guard !seenThisWave.contains(nodeID), let node = project.nodes.first(where: { $0.id == nodeID }) else { continue }
                seenThisWave.insert(nodeID)

                let missingInputs = missingRequiredInputTitles(
                    for: node,
                    project: project,
                    contextByNode: contextByNode,
                    dirtyNodeIDs: dirtyNodeIDs,
                    runningNodeIDs: runningNodeIDs
                )
                if node.kind != .start && !missingInputs.isEmpty {
                    waitCounts[nodeID, default: 0] += 1
                    stillWaiting.append(nodeID)
                    record.currentNodeTitle = node.title
                    record.currentNodeIDs = [node.id]
                    record.currentStage = "等待上游：\(node.title)"
                    if waitCounts[nodeID, default: 0] == 1 || waitCounts[nodeID, default: 0] % 6 == 0 {
                        appendLog(&record, .info, node.title, "等待最新上游结果：\(missingInputs.joined(separator: "、"))。不会再使用旧输出提前启动。")
                    }
                    onUpdate(record)
                    continue
                }

                readyNodes.append(node)
            }

            if readyNodes.isEmpty {
                queue = stillWaiting
                if queue.isEmpty { break }
                try await Task.sleep(nanoseconds: 120_000_000)
                continue
            }

            if executed > safetyLimit {
                appendLog(&record, .error, nil, "检测到可能的无限返工循环，已停止。")
                record.status = .failed
                record.endedAt = Date()
                record.currentStage = "循环保护停止"
                record.diagnosticMessage = WorkflowEngineError.safetyLimitReached.localizedDescription
                onUpdate(record)
                throw WorkflowEngineError.safetyLimitReached
            }

            let batchTitles = readyNodes.map(\.title).joined(separator: "、")
            record.currentNodeIDs = readyNodes.map(\.id)
            record.currentNodeTitle = readyNodes.count == 1 ? readyNodes[0].title : "\(readyNodes.count) 个模块并行运行"
            record.currentStage = readyNodes.count == 1 ? "正在执行：\(readyNodes[0].title)" : "并行执行：\(batchTitles)"
            record.diagnosticMessage = readyNodes.count == 1 ? "当前模块正在运行。" : "已同时启动 \(readyNodes.count) 个可并行模块。"
            appendLog(&record, .info, nil, readyNodes.count == 1 ? "启动模块：\(batchTitles)" : "并行启动模块：\(batchTitles)")
            runningNodeIDs.formUnion(readyNodes.map(\.id))

            var inputContexts: [UUID: String] = [:]
            for node in readyNodes {
                visitCounts[node.id, default: 0] += 1
                executed += 1
                let inputContext = inputContextFor(node: node, project: project, contextByNode: contextByNode)
                inputContexts[node.id] = inputContext
                var nodeRecord = NodeRunRecord(nodeID: node.id, nodeTitle: node.title, kind: node.kind, status: .running)
                nodeRecord.inputPreview = String(inputContext.prefix(1600))
                nodeRecord.returnCount = returnCounts[node.id] ?? 0
                record.nodeRecords.append(nodeRecord)
                appendLog(&record, .info, node.title, "开始执行模块。输入长度约 \(TokenEstimator.roughCount(inputContext)) Token。")
                if node.kind == .dispatcher {
                    let targetCount = dispatchTargets(for: node, project: project).count
                    appendLog(&record, targetCount == 0 ? .warning : .info, node.title, targetCount == 0 ? "任务分配者没有检测到已连接工作者，请先从输出接口连接到工作者。" : "任务分配者已读取 \(targetCount) 个已连接下游工作者，并会按这些连接关系分配任务。")
                }
            }
            record.progress = min(0.95, max(record.progress, (Double(executed) - 0.35) / Double(max(project.nodes.count, 1))))
            onUpdate(record)

            let results: [ParallelNodeResult] = await withTaskGroup(of: ParallelNodeResult.self) { group in
                for node in readyNodes {
                    let inputContext = inputContexts[node.id] ?? ""
                    let effectiveTimeout = node.kind == .codeWorker ? max(node.timeoutSeconds, 180) : max(node.timeoutSeconds + 10, 20)
                    group.addTask {
                        do {
                            try Task.checkCancellation()
                            let response = try await self.withTimeout(seconds: effectiveTimeout) {
                                try await self.execute(node: node, project: project, context: inputContext, apiConfigs: apiConfigs, settings: settings, aiClient: aiClient)
                            }
                            try Task.checkCancellation()
                            return ParallelNodeResult(node: node, inputContext: inputContext, response: response, error: nil)
                        } catch {
                            return ParallelNodeResult(node: node, inputContext: inputContext, response: nil, error: error)
                        }
                    }
                }

                var values: [ParallelNodeResult] = []
                for await value in group {
                    values.append(value)
                }
                return values
            }

            var fatalError: Error?
            for result in results {
                let node = result.node
                runningNodeIDs.remove(node.id)

                if let error = result.error {
                    if let index = record.nodeRecords.lastIndex(where: { $0.nodeID == node.id && $0.status == .running }) {
                        record.nodeRecords[index].status = .failed
                        record.nodeRecords[index].endedAt = Date()
                        record.nodeRecords[index].errorMessage = error.localizedDescription
                    }
                    if error is CancellationError {
                        appendLog(&record, .warning, node.title, "运行被用户停止。")
                        record.status = .cancelled
                        record.endedAt = Date()
                        record.currentStage = "已停止"
                        record.diagnosticMessage = "用户点击停止运行。"
                        fatalError = error
                    } else {
                        appendLog(&record, .error, node.title, error.localizedDescription)
                        record.status = .failed
                        record.endedAt = Date()
                        record.currentStage = "失败：\(node.title)"
                        record.diagnosticMessage = error.localizedDescription
                        fatalError = error
                    }
                    continue
                }

                guard let response = result.response else { continue }
                let decision = reviewerDecision(node: node, output: response.text)
                let output = (node.kind.isReviewer && decision.passed == true) ? "{\"passed\":true,\"feedback\":\"\"}" : response.text
                contextByNode[node.id] = output
                dirtyNodeIDs.remove(node.id)
                record.output = latestCombinedOutput(project: project, contextByNode: contextByNode)
                record.tokenUsage = record.tokenUsage + response.tokenUsage

                if let index = record.nodeRecords.lastIndex(where: { $0.nodeID == node.id && $0.status == .running }) {
                    let reviewerPassed = node.kind.isReviewer ? (decision.passed ?? false) : true
                    record.nodeRecords[index].status = reviewerPassed ? .passed : .returned
                    record.nodeRecords[index].endedAt = Date()
                    record.nodeRecords[index].output = output
                    record.nodeRecords[index].tokenUsage = response.tokenUsage
                    let effectiveProvider = effectiveProviderID(for: node, settings: settings)
                    record.nodeRecords[index].providerName = effectiveProvider.flatMap { id in apiConfigs.first(where: { $0.id == id })?.name }
                    record.nodeRecords[index].modelID = effectiveModelID(for: node, settings: settings)
                }

                let passed = node.kind.isReviewer ? (decision.passed ?? false) : true
                appendLog(&record, passed ? .success : .warning, node.title, passed ? "模块完成，Token：\(response.tokenUsage.total)" : "模块完成但检查未通过，Token：\(response.tokenUsage.total)")
                if node.kind.isReviewer {
                    if passed {
                        appendLog(&record, .success, node.title, "检查通过：已清空修改建议，继续走通过出口。")
                    } else {
                        let feedback = decision.feedback?.trimmingCharacters(in: .whitespacesAndNewlines)
                        appendLog(&record, .warning, node.title, "检查未通过：走不合格出口。\(feedback?.isEmpty == false ? " 返工意见：\(feedback!)" : "")")
                    }
                }

                let next = nextEdges(from: node, passed: passed, project: project)
                if next.isEmpty && node.kind != .output {
                    appendLog(&record, .warning, node.title, "该模块没有后续连线，流程在这里结束。")
                }
                for edge in next {
                    if edge.condition == .failed {
                        returnCounts[edge.to, default: 0] += 1
                        let count = returnCounts[edge.to, default: 0]
                        let maxBlockingReturns = 3
                        if count > maxBlockingReturns {
                            appendLog(&record, .error, node.title, "检查者已连续打回同一模块 \(maxBlockingReturns) 次，仍判定存在阻塞问题。已停止返工循环，避免无限运行；请手动查看检查意见或放宽检查标准。")
                            record.status = .failed
                            record.endedAt = Date()
                            record.currentStage = "返工循环保护停止"
                            record.diagnosticMessage = WorkflowEngineError.safetyLimitReached.localizedDescription
                            fatalError = WorkflowEngineError.safetyLimitReached
                            break
                        }
                    }
                    markDirtyCascade(from: edge.to)
                    queue.append(edge.to)
                }
            }

            if let fatalError {
                onUpdate(record)
                if fatalError is CancellationError { throw CancellationError() }
                throw fatalError
            }

            queue = stillWaiting + queue
            record.progress = min(0.98, Double(executed) / Double(max(project.nodes.count, 1)))
            onUpdate(record)
        }

        record.status = .completed
        record.endedAt = Date()
        record.progress = 1
        record.currentNodeTitle = nil
        record.currentNodeIDs = []
        record.currentStage = "运行完成"
        record.diagnosticMessage = "全部可达模块已执行完成。并行分支已按依赖关系合并。"
        record.output = latestCombinedOutput(project: project, contextByNode: contextByNode)
        appendLog(&record, .success, nil, "工作流运行完成")
        return record
    }

    private func execute(node: WorkflowNode, project: WorkflowProject, context: String, apiConfigs: [APIProviderConfig], settings: AppSettings, aiClient: AIClient) async throws -> AITextResponse {
        switch node.kind {
        case .start:
            let imageNote = project.resources.contains(where: { $0.kind == .image }) ? "\n已检测到图片资源；图片内容将交给图片理解模块处理。" : ""
            let text = "已接收需求。\n\n\(project.userPrompt)\(imageNote)"
            return AITextResponse(text: text, tokenUsage: TokenUsage(input: TokenEstimator.roughCount(project.userPrompt), output: TokenEstimator.roughCount(text)))
        case .logger:
            let text = "日志记录模块已记录当前上下文、模块输出、Token 与状态。"
            return AITextResponse(text: text, tokenUsage: TokenUsage(input: 0, output: TokenEstimator.roughCount(text)))
        case .filePackager:
            let text = packageSummary(from: context)
            return AITextResponse(text: text, tokenUsage: TokenUsage(input: TokenEstimator.roughCount(context), output: TokenEstimator.roughCount(text)))
        case .versionSnapshot:
            let text = "版本快照模块已保存工作流结构、提示词、模型配置和当前输出。"
            return AITextResponse(text: text, tokenUsage: TokenUsage(input: 0, output: TokenEstimator.roughCount(text)))
        case .output:
            let text = context.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? "输出模块没有收到上游内容。请把文件打包者、格式转换者或汇总者连接到输出模块的输入口。" : context
            return AITextResponse(text: text, tokenUsage: TokenUsage(input: TokenEstimator.roughCount(context), output: TokenEstimator.roughCount(text)))
        default:
            guard let providerID = effectiveProviderID(for: node, settings: settings),
                  let config = apiConfigs.first(where: { $0.id == providerID }),
                  let model = effectiveModelID(for: node, settings: settings),
                  !model.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
                throw WorkflowEngineError.missingModelConfiguration("\(node.title) 未配置可用模型。请先在设置页配置全局默认模型，或在模块详情里单独选择模型，然后在工作流页点击“一键应用默认模型”。")
            }
            let apiKey = try KeychainService.read(account: config.keychainAccount)
            let system = systemPrompt(for: node)
            let outputRule: String
            if node.kind.isReviewer {
                outputRule = "输出要求：只能输出 JSON。只有发现阻塞/严重问题才允许不通过。通过时 {\"passed\":true,\"severity\":\"pass\",\"feedback\":\"\",\"blockingIssues\":[]}；不通过时 {\"passed\":false,\"severity\":\"blocking\",\"feedback\":\"必须返工的阻塞问题\",\"blockingIssues\":[\"具体阻塞问题\"]}。普通优化建议、风格偏好、可选重构必须通过，不要为了找问题而找问题。不要泄露 API Key。"
            } else if node.kind == .dispatcher {
                outputRule = "输出要求：必须按已连接工作者逐个分配任务。优先输出 JSON：{\"assignments\":[{\"targetNodeID\":\"节点ID\",\"targetTitle\":\"工作者标题\",\"task\":\"具体任务\",\"inputsNeeded\":\"需要读取的上游资料\",\"expectedOutput\":\"期望输出\",\"acceptanceCriteria\":\"验收标准\"}],\"parallelPlan\":\"哪些任务可以并行\"}。必须使用下面给出的真实 targetNodeID，不要编造不存在的模块。"
            } else if node.kind == .formatter {
                outputRule = "输出要求：你是格式转换者，只负责把上游内容转换成用户需要的最终文件格式，不要再做质量检查。若用户要求 Python/代码文件，必须输出文件块，格式为 ```file path=\"snake.py\" 或 ```file path=\"main.py\"，代码内容放在代码块内；可同时输出 README.md。不要只给说明而不给文件内容。不要泄露 API Key。"
            } else {
                outputRule = "输出要求：结构化、可执行、指出不确定内容和风险。不要泄露 API Key。"
            }
            let dispatchGuide = node.kind == .dispatcher ? """

            # 已连接工作者 / 可分配目标
            你必须只向下面这些真实连接的下游模块分配任务：
            \(connectedDispatchTargetSummary(for: node, project: project))

            分配要求：
            - 读取上面的连接关系，而不是按想象添加工作者。
            - 每个 assignment 必须对应一个真实连接的 targetNodeID。
            - 如果多个工作者从任务分配者并行连出，要把可并行任务拆开，后续运行引擎会同时启动它们。
            - 如果某个连接目标不是工作者，也要说明为什么需要给它什么输入。
            """ : ""
            let workerGuide = node.kind.isAssignableWorker ? """

            # 本模块身份
            当前模块 ID：\(node.id.uuidString)
            当前模块标题：\(node.title)
            当前模块类型：\(node.kind.title)
            如果上游包含任务分配者输出，请只执行分配给本模块 ID 或本模块标题的任务；如果没有明确匹配，则执行与本模块类型最相关的部分。
            """ : ""
            let user = """
            当前模块输入（包含用户原始需求 + 上游 AI 模块真实输出）：
            \(context)
            \(dispatchGuide)
            \(workerGuide)

            当前模块职责：
            \(node.kind == .custom ? node.prompt : node.kind.defaultPrompt)

            交流要求：必须明确参考上游模块输出继续工作；如果上游给了修改意见、识别结果、代码、方案或任务分配表，要把它作为本模块输入的一部分处理，不要从零开始。

            \(outputRule)
            """

            if node.kind == .imageUnderstanding, let image = project.resources.first(where: { $0.kind == .image })?.base64Preview {
                return try await aiClient.completeVision(baseURL: config.baseURL, apiKey: apiKey, model: model, prompt: user, imageBase64: image, maxTokens: node.maxTokens, temperature: node.temperature, timeoutSeconds: node.kind == .codeWorker ? max(node.timeoutSeconds, 180) : node.timeoutSeconds)
            } else {
                let messages = [AIMessage(role: "system", content: system), AIMessage(role: "user", content: user)]
                return try await aiClient.completeText(baseURL: config.baseURL, apiKey: apiKey, model: model, messages: messages, maxTokens: node.maxTokens, temperature: node.temperature, timeoutSeconds: node.kind == .codeWorker ? max(node.timeoutSeconds, 180) : node.timeoutSeconds)
            }
        }
    }

    private func packageSummary(from context: String) -> String {
        let files = ZipArchiveService.detectGeneratedFilePaths(in: context)
        if files.isEmpty {
            return """
            # 文件打包者

            暂未在上游内容中识别到明确文件块。

            请让“格式转换者”输出这种格式：

            ```file path="snake.py"
            # Python 代码
            ```

            当前上游内容会仍然作为最终输出进入输出模块，导出 ZIP 时也会保留运行日志和节点输出。
            """
        }
        let list = files.map { "- `\($0)`" }.joined(separator: "\n")
        return """
        # 文件打包者

        已识别到以下可导出文件，运行完成后导出 ZIP 时会自动放入 `generated/` 目录：

        \(list)

        ## 打包规则
        - 文件内容来自上游格式转换者 / 代码工作者输出的文件块。
        - 输出模块只负责展示和导出，不会重新整理这些文件。
        - ZIP 内仍会包含运行日志、JSON 记录和每个模块输出。
        """
    }

    private func missingModelConfigurationMessage(project: WorkflowProject, apiConfigs: [APIProviderConfig], settings: AppSettings) -> String? {
        let reachableIDs = reachableNodeIDs(fromStartIn: project)
        let missing = project.nodes
            .filter { reachableIDs.contains($0.id) && requiresAIModel($0.kind) }
            .filter { node in
                guard let providerID = effectiveProviderID(for: node, settings: settings),
                      apiConfigs.contains(where: { $0.id == providerID }),
                      let modelID = effectiveModelID(for: node, settings: settings),
                      !modelID.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
                    return true
                }
                return false
            }

        guard !missing.isEmpty else { return nil }
        let names = missing.map { "• \($0.title)（\($0.kind.title)）" }.joined(separator: "\n")
        return "以下可达 AI 模块没有可用模型，已阻止运行，避免出现假完成/占位输出：\n\(names)\n\n请到设置页配置全局默认模型，或在模块详情中单独选择模型，然后点击工作流页“一键应用默认模型”。"
    }

    private func reachableNodeIDs(fromStartIn project: WorkflowProject) -> Set<UUID> {
        guard let start = project.nodes.first(where: { $0.kind == .start }) else { return [] }
        var visited = Set<UUID>()
        var queue: [UUID] = [start.id]
        while let id = queue.first {
            queue.removeFirst()
            guard !visited.contains(id) else { continue }
            visited.insert(id)
            let next = project.edges.filter { $0.from == id }.map(\.to)
            queue.append(contentsOf: next)
        }
        return visited
    }

    private func requiresAIModel(_ kind: WorkflowNodeKind) -> Bool {
        switch kind {
        case .start, .output, .logger, .filePackager, .versionSnapshot:
            return false
        default:
            return true
        }
    }

    private func effectiveProviderID(for node: WorkflowNode, settings: AppSettings) -> UUID? {
        if let providerID = node.providerID { return providerID }
        switch node.kind {
        case .codeWorker:
            return settings.defaultCodeProviderID ?? settings.defaultTextProviderID
        case .codeReviewer, .qualityReviewer:
            return settings.defaultReviewerProviderID ?? settings.defaultTextProviderID
        case .visualReviewer, .imageUnderstanding:
            return settings.defaultVisionProviderID ?? settings.defaultReviewerProviderID ?? settings.defaultTextProviderID
        case .imageGenerator:
            return settings.defaultImageProviderID ?? settings.defaultTextProviderID
        default:
            return settings.defaultTextProviderID
        }
    }

    private func effectiveModelID(for node: WorkflowNode, settings: AppSettings) -> String? {
        if let modelID = node.modelID, !modelID.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { return modelID }
        switch node.kind {
        case .codeWorker:
            return settings.defaultCodeModelID ?? settings.defaultTextModelID
        case .codeReviewer, .qualityReviewer:
            return settings.defaultReviewerModelID ?? settings.defaultTextModelID
        case .visualReviewer, .imageUnderstanding:
            return settings.defaultVisionModelID ?? settings.defaultReviewerModelID ?? settings.defaultTextModelID
        case .imageGenerator:
            return settings.defaultImageModelID ?? settings.defaultTextModelID
        default:
            return settings.defaultTextModelID
        }
    }

    private func systemPrompt(for node: WorkflowNode) -> String {
        switch node.kind {
        case .codeReviewer:
            return "你是代码检查者。你不是意见收集器，只能检查会导致代码不可用的阻塞问题。必须通过：普通优化、风格建议、命名偏好、可选重构、轻微体验问题。只有编译失败、缺少关键文件/入口、依赖明显错误、API Key 泄露、严重安全风险、核心需求未实现这类阻塞问题才不通过。必须只输出 JSON：{\"passed\":true,\"severity\":\"pass\",\"feedback\":\"\",\"blockingIssues\":[]} 或 {\"passed\":false,\"severity\":\"blocking\",\"feedback\":\"必须返工的阻塞问题\",\"blockingIssues\":[\"具体阻塞问题\"]}。通过时 feedback 必须为空，不要给修改建议。"
        case .qualityReviewer:
            return "你是质量评估者。你只能因为阻塞质量问题打回，例如严重偏离用户要求、缺少核心内容、明显事实/逻辑错误、输出格式完全错误。普通改进建议必须通过。必须只输出 JSON：{\"passed\":true,\"severity\":\"pass\",\"feedback\":\"\",\"blockingIssues\":[]} 或 {\"passed\":false,\"severity\":\"blocking\",\"feedback\":\"必须返工的问题\",\"blockingIssues\":[\"具体阻塞问题\"]}。通过时 feedback 必须为空。"
        case .visualReviewer:
            return "你是视觉检查者。只有严重影响使用的视觉/UI问题才不通过，例如文字看不清、关键按钮不可见、布局遮挡、尺寸严重不适配。普通美化建议必须通过。必须只输出 JSON：{\"passed\":true,\"severity\":\"pass\",\"feedback\":\"\",\"blockingIssues\":[]} 或 {\"passed\":false,\"severity\":\"blocking\",\"feedback\":\"必须返工的严重视觉问题\",\"blockingIssues\":[\"具体阻塞问题\"]}。通过时 feedback 必须为空。"
        case .codeWorker:
            return "你是代码工作者。必须读取上游计划和检查者 review_notes；如果有上一轮代码输出，必须基于上一轮完整修改，不要只复述建议。输出可直接使用的完整代码/文件结构/运行说明。"
        case .imageUnderstanding:
            return "你是图片理解模块。输出图片摘要、关键文字、可操作信息、不确定内容。"
        case .multiModelVote:
            return "你是裁判模型。比较多个答案，选择更可靠结果，并解释理由。"
        default:
            return "你是 AI Workflow Studio 的 \(node.kind.title)。你必须读取上游模块传来的内容，并在此基础上继续处理，形成真实多 AI 协作链。"
        }
    }

    private func localFallbackOutput(for node: WorkflowNode, context: String, project: WorkflowProject) -> String {
        switch node.kind {
        case .planner:
            return "未配置模型，使用本地占位计划：1. 拆解需求；2. 执行核心任务；3. 检查质量；4. 导出结果。"
        case .dispatcher:
            return localDispatcherFallback(for: node, project: project)
        case .codeReviewer, .qualityReviewer, .visualReviewer:
            return "{\"passed\":false,\"feedback\":\"未配置检查者模型，无法确认质量。请配置检查者模型后重新运行，或手动调整连线。\"}"
        case .imageUnderstanding:
            return "未配置图片理解模型，无法识别图片。请在设置中添加支持图片输入的模型。"
        default:
            return "未配置模型，\(node.kind.title) 已跳过真实 AI 调用，仅生成占位输出。"
        }
    }

    private func localDispatcherFallback(for node: WorkflowNode, project: WorkflowProject) -> String {
        let targets = dispatchTargets(for: node, project: project)
        guard !targets.isEmpty else {
            return "任务分配者没有检测到已连接的下游工作者。请从任务分配者输出接口连接到通用工作者、代码工作者、图片生成者等模块后再运行。"
        }
        let assignments = targets.map { target in
            """
            {
              \"targetNodeID\": \"\(target.id.uuidString)\",
              \"targetTitle\": \"\(target.title)\",
              \"task\": \"根据用户需求和上游计划，完成适合 \(target.kind.title) 的子任务。\",
              \"inputsNeeded\": \"用户原始需求、计划者输出、相关上游资料。\",
              \"expectedOutput\": \"\(target.kind.outputDescription)\",
              \"acceptanceCriteria\": \"输出必须可被后续模块直接使用，并说明不确定内容。\"
            }
            """
        }.joined(separator: ",\n")
        return """
        {
          \"assignments\": [
        \(assignments)
          ],
          \"parallelPlan\": \"以上已连接工作者可以按依赖关系并行执行；多个下游同时连接时会同时启动。\"
        }
        """
    }

    private func inputContextFor(node: WorkflowNode, project: WorkflowProject, contextByNode: [UUID: String]) -> String {
        if node.kind == .start { return "# 用户原始需求\n\(project.userPrompt)" }
        let incoming = project.edges.filter { $0.to == node.id }
        let dispatcherConnectionContext: String = node.kind == .dispatcher ? """

        # 任务分配者实际连接的下游模块
        下面是当前画布上从“任务分配者”直接连出去的真实模块。任务分配必须基于这个列表：
        \(connectedDispatchTargetSummary(for: node, project: project))
        """ : ""
        let upstream = incoming.compactMap { edge -> String? in
            guard let source = project.nodes.first(where: { $0.id == edge.from }), let output = contextByNode[source.id] else { return nil }
            return """
            ## 来自上游 AI：\(source.title)
            连线条件：\(edge.condition.title)
            上游输出：
            \(output)
            """
        }
        let previousOwnOutput = contextByNode[node.id].map { previous in
            """

            # 本模块上一轮输出
            \(previous)
            """
        } ?? ""

        let reviewerFeedback = incoming.compactMap { edge -> String? in
            guard edge.condition == .failed || edge.condition == .scoreLow,
                  let source = project.nodes.first(where: { $0.id == edge.from }),
                  source.kind.isReviewer,
                  let output = contextByNode[source.id] else { return nil }
            return "来自检查者 \(source.title) 的不合格返工意见：\n\(output)"
        }.joined(separator: "\n\n")

        if upstream.isEmpty {
            return """
            # 用户原始需求
            \(project.userPrompt)

            # 上游 AI 交流上下文
            暂无上游输出；此模块会直接基于用户需求工作。
            \(dispatcherConnectionContext)
            \(previousOwnOutput)
            """
        }
        return """
        # 用户原始需求
        \(project.userPrompt)

        # 上游 AI 交流上下文
        \(upstream.joined(separator: "\n\n"))
        \(dispatcherConnectionContext)
        \(previousOwnOutput)

        # 返工意见 / review_notes
        \(reviewerFeedback.isEmpty ? "无" : reviewerFeedback)

        # 执行要求
        当前模块必须基于以上上游输出继续处理，不要忽略上游结果。
        如果本次是检查者打回，请对照 review_notes 和本模块上一轮输出，直接产出修复后的完整版本。
        """
    }

    private func missingRequiredInputTitles(
        for node: WorkflowNode,
        project: WorkflowProject,
        contextByNode: [UUID: String],
        dirtyNodeIDs: Set<UUID>,
        runningNodeIDs: Set<UUID>
    ) -> [String] {
        let incoming = project.edges.filter { $0.to == node.id }
        return incoming.compactMap { edge in
            guard let source = project.nodes.first(where: { $0.id == edge.from }) else { return nil }

            // 不合格/低分返工线是返工意见入口，不要求它提前完成；
            // 否则 worker 会因为等待检查者而无法执行返工。
            if edge.condition == .failed || edge.condition == .scoreLow {
                return nil
            }

            if runningNodeIDs.contains(source.id) {
                return "\(source.title)（正在运行）"
            }
            if dirtyNodeIDs.contains(source.id) {
                return "\(source.title)（等待最新输出）"
            }

            guard let sourceOutput = contextByNode[source.id] else {
                return source.title
            }

            // 通过线只在检查者真的通过后才算必要输入。
            // 如果检查者已经不通过，则它的 passed 线不应卡住别的合法分支。
            if edge.condition == .passed || edge.condition == .scoreHigh {
                if source.kind.isReviewer {
                    let decision = reviewerDecision(node: source, output: sourceOutput)
                    return decision.passed == true ? nil : nil
                }
                return nil
            }

            return nil
        }
    }

    private func nextEdges(from node: WorkflowNode, passed: Bool, project: WorkflowProject) -> [WorkflowEdge] {
        let outgoing = project.edges.filter { $0.from == node.id }
        if node.kind.isReviewer {
            let preferred = outgoing.filter { passed ? $0.condition == .passed : $0.condition == .failed }
            if !preferred.isEmpty { return preferred }
            return outgoing.filter { $0.condition == .always }
        }
        return outgoing.filter { $0.condition == .always || $0.condition == .passed || $0.condition == .scoreHigh }
    }

    private func dispatchTargets(for dispatcher: WorkflowNode, project: WorkflowProject) -> [WorkflowNode] {
        let directTargetIDs = project.edges
            .filter { $0.from == dispatcher.id && ($0.condition == .always || $0.condition == .passed || $0.condition == .scoreHigh) }
            .map(\.to)
        return directTargetIDs.compactMap { targetID in
            project.nodes.first { $0.id == targetID }
        }
    }

    private func connectedDispatchTargetSummary(for dispatcher: WorkflowNode, project: WorkflowProject) -> String {
        let targets = dispatchTargets(for: dispatcher, project: project)
        guard !targets.isEmpty else {
            return "未检测到从任务分配者输出接口连接出去的工作者。请先连线，否则无法知道要把任务分给谁。"
        }
        return targets.map { target in
            let apiText: String
            if let modelID = target.modelID, !modelID.isEmpty {
                apiText = "模型：\(modelID)"
            } else {
                apiText = "模型：未设置，将使用本地占位或提示配置默认模型"
            }
            return """
            - targetNodeID: \(target.id.uuidString)
              标题：\(target.title)
              类型：\(target.kind.title)
              能力说明：\(target.kind.summary)
              输入能力：\(target.kind.inputDescription)
              期望输出：\(target.kind.outputDescription)
              \(apiText)
            """
        }.joined(separator: "\n")
    }

    private struct ReviewerDecision: Decodable {
        var passed: Bool?
        var severity: String?
        var feedback: String?
        var blockingIssues: [String]?
    }

    private func reviewerDecision(node: WorkflowNode, output: String) -> (passed: Bool?, feedback: String?) {
        guard node.kind.isReviewer else { return (true, nil) }
        if let jsonText = extractJSONObject(from: output),
           let data = jsonText.data(using: .utf8),
           let decoded = try? JSONDecoder().decode(ReviewerDecision.self, from: data) {
            let feedback = decoded.feedback?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
            let blockingIssues = decoded.blockingIssues?.map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }.filter { !$0.isEmpty } ?? []
            if decoded.passed == true { return (true, nil) }
            if isBlockingSeverity(decoded.severity) || !blockingIssues.isEmpty || isBlockingFeedback(feedback, for: node.kind) {
                let merged = (blockingIssues + (feedback.isEmpty ? [] : [feedback])).joined(separator: "\n")
                return (false, merged.isEmpty ? output : merged)
            }
            return (true, nil)
        }
        let lower = output.lowercased()
        if lower.contains("\"passed\":true") || lower.contains("passed: true") || lower.contains("通过") || lower.contains("合格") {
            return (true, nil)
        }
        if lower.contains("\"passed\":false") || lower.contains("passed: false") || lower.contains("不通过") || lower.contains("不合格") || lower.contains("failed") {
            return isBlockingFeedback(output, for: node.kind) ? (false, output) : (true, nil)
        }
        return (true, nil)
    }

    private func isBlockingSeverity(_ severity: String?) -> Bool {
        let text = (severity ?? "").lowercased()
        return text.contains("blocking") || text.contains("critical") || text.contains("fatal") || text.contains("blocker") || text.contains("严重") || text.contains("阻塞")
    }

    private func isBlockingFeedback(_ feedback: String, for kind: WorkflowNodeKind) -> Bool {
        let lower = feedback.lowercased()
        let sharedKeywords = [
            "blocking", "critical", "fatal", "cannot", "can't", "unable", "missing required", "not implemented",
            "阻塞", "严重", "无法", "不能", "缺少核心", "未实现核心", "完全错误", "必须返工"
        ]
        let codeKeywords = [
            "compile", "build failed", "syntax error", "type error", "cannot find", "no such module", "crash",
            "api key", "secret", "security", "xcode build", "编译", "构建失败", "语法错误", "类型错误", "找不到", "闪退", "泄露", "安全风险"
        ]
        let visualKeywords = [
            "unreadable", "invisible", "overlap", "blocked", "clipped", "看不清", "不可见", "遮挡", "重叠", "被裁切"
        ]
        var keywords = sharedKeywords
        if kind == .codeReviewer { keywords += codeKeywords }
        if kind == .visualReviewer { keywords += visualKeywords }
        return keywords.contains { lower.contains($0) }
    }

    private func extractJSONObject(from text: String) -> String? {
        guard let start = text.firstIndex(of: "{"), let end = text.lastIndex(of: "}"), start <= end else { return nil }
        return String(text[start...end])
    }

    private func withTimeout<T>(seconds: Int, operation: @escaping () async throws -> T) async throws -> T {
        try await withThrowingTaskGroup(of: T.self) { group in
            group.addTask { try await operation() }
            group.addTask {
                try await Task.sleep(nanoseconds: UInt64(max(seconds, 1)) * 1_000_000_000)
                throw WorkflowEngineError.apiTimeout("API 或模块处理超过 \(seconds) 秒没有返回，已自动停止。请检查网络、Base URL、模型名或把模块超时时间调大。")
            }
            guard let result = try await group.next() else { throw WorkflowEngineError.cancelled }
            group.cancelAll()
            return result
        }
    }

    private func latestCombinedOutput(project: WorkflowProject, contextByNode: [UUID: String]) -> String {
        project.nodes.compactMap { node in
            guard let output = contextByNode[node.id] else { return nil }
            return "## \(node.title)\n\(output)"
        }.joined(separator: "\n\n")
    }

    private func appendLog(_ record: inout RunRecord, _ level: LogLevel, _ nodeTitle: String?, _ message: String) {
        record.logs.append(RunLogEntry(level: level, nodeTitle: nodeTitle, message: message))
        record.lastLogAt = Date()
        record.diagnosticMessage = message
    }
}
