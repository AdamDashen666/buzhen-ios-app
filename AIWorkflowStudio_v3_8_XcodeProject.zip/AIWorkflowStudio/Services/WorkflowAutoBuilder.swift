import Foundation

enum WorkflowAutoBuilder {
    static func aiPlannerPrompt(for project: WorkflowProject) -> String {
        """
        根据下面的用户需求，设计 AI Workflow Studio 工作流。

        你必须先理解任务，再从可用模块中选择需要的模块，并给出推荐连线。App 会根据你的模块列表和规则生成节点与连线。

        只输出 JSON，格式：
        {"modules":["planner","worker","qualityReviewer","aggregator","formatter","filePackager","output"],"notes":"为什么这样搭建"}

        全部可用模块清单：
        - planner：计划者。输入用户需求，输出步骤计划、风险和验收标准。
        - dispatcher：任务分配者。运行时会读取自己实际连接到的下游工作者，再按这些真实连接分配任务。
        - worker：通用工作者。输入计划/意见，输出写作、总结、分析或改进版。
        - optimizer：意见提出者 / 优化者。输入当前结果，输出问题、遗漏、风险、优化优先级和修改建议。
        - custom：自定义模块。只有用户自己需要特殊提示词时使用。
        - codeWorker：代码工作者。输入代码需求或返工意见，输出代码、文件结构、运行说明。
        - codeReviewer：代码检查者。输入代码工作者输出，输出严格 JSON，通过或不合格反馈。
        - imageUnderstanding：图片理解。输入图片/截图/OCR/图表，输出结构化识别结果。
        - imageGenerator：图片生成者。输入图片需求，输出图片提示词或素材方案。
        - multiModelVote：多模型投票。输入候选答案，输出更可靠方案。
        - qualityReviewer：质量评估。输入普通工作者输出，输出通过或不合格反馈。
        - visualReviewer：视觉检查。输入 UI/设计/截图，输出视觉问题或通过。
        - aggregator：汇总者。输入多个上游结果，输出统一版本。
        - formatter：格式转换者。输入内容，输出 Markdown/JSON/TXT/HTML/代码文件；例如把代码转换成 snake.py 文件块。
        - filePackager：文件打包者。输入文件块/目录结构，输出可导出的 ZIP 打包清单。
        - humanApproval：人工确认。需要用户确认时使用。
        - logger：日志记录。记录模块输入输出和错误。
        - versionSnapshot：版本快照。保存可回滚版本。
        - output：输出模块。只作为最终展示/导出入口，不负责整理、转换或打包。

        规则：
        - 必须保留 start 和 output，但 JSON 里可以不写 start。
        - 代码/App/网页/Xcode 任务必须包含 codeWorker 和 codeReviewer。
        - 图片/截图/OCR/图表任务必须包含 imageUnderstanding。
        - 检查者不合格时会通过“不合格出口”打回工作者，不需要 autoFixer。
        - 普通写作总结至少包含 planner、worker、qualityReviewer、aggregator、formatter、output。
        - 如果用户要求“提意见、优化、改进、找问题、修改建议”，加入 optimizer，它可以接上游结果，再连回 worker/codeWorker 继续改进。
        - 代码/项目文件任务建议包含 formatter 和 filePackager，再连接到 output；输出模块不要承担整理功能。
        - 复杂任务可以加入 dispatcher、optimizer、multiModelVote、logger、versionSnapshot、filePackager。
        - 如果使用 dispatcher，必须把 dispatcher 连到要并行执行的工作者；运行时 dispatcher 会读取这些连接到的工作者列表来分配任务。

        用户需求：
        \(project.userPrompt)
        """
    }

    static func parseKinds(from text: String) -> [WorkflowNodeKind]? {
        let lower = text.lowercased()
        let mapping: [(String, WorkflowNodeKind)] = [
            ("imageunderstanding", .imageUnderstanding), ("image_understanding", .imageUnderstanding), ("图片理解", .imageUnderstanding),
            ("planner", .planner), ("计划", .planner),
            ("dispatcher", .dispatcher), ("任务分配", .dispatcher),
            ("codeworker", .codeWorker), ("code_worker", .codeWorker), ("代码工作", .codeWorker),
            ("codereviewer", .codeReviewer), ("code_reviewer", .codeReviewer), ("代码检查", .codeReviewer),
            ("worker", .worker), ("通用工作", .worker),
            ("optimizer", .optimizer), ("optimiser", .optimizer), ("优化", .optimizer), ("意见", .optimizer), ("改进建议", .optimizer),
            ("imagegenerator", .imageGenerator), ("image_generator", .imageGenerator), ("图片生成", .imageGenerator),
            ("visualreviewer", .visualReviewer), ("visual_reviewer", .visualReviewer), ("视觉检查", .visualReviewer),
            ("multimodelvote", .multiModelVote), ("multi_model_vote", .multiModelVote), ("多模型", .multiModelVote),
            ("qualityreviewer", .qualityReviewer), ("quality_reviewer", .qualityReviewer), ("质量", .qualityReviewer),
            ("aggregator", .aggregator), ("汇总", .aggregator),
            ("formatter", .formatter), ("格式", .formatter),
            ("filepackager", .filePackager), ("file_packager", .filePackager), ("打包", .filePackager),
            ("humanapproval", .humanApproval), ("human_approval", .humanApproval), ("人工", .humanApproval),
            ("logger", .logger), ("日志", .logger),
            ("versionsnapshot", .versionSnapshot), ("version_snapshot", .versionSnapshot), ("版本", .versionSnapshot),
            ("output", .output), ("输出", .output),
            ("custom", .custom), ("自定义", .custom)
        ]
        var result: [WorkflowNodeKind] = []
        for (token, kind) in mapping where lower.contains(token.lowercased()) {
            if !result.contains(kind) { result.append(kind) }
        }
        result.removeAll { $0 == .autoFixer || $0 == .autoGraph || $0 == .start }
        return result.isEmpty ? nil : result
    }

    static func build(from project: WorkflowProject, preferredKinds: [WorkflowNodeKind]? = nil) -> WorkflowProject {
        var newProject = project
        let lower = project.userPrompt.lowercased()
        let hasImage = !project.resources.filter { $0.kind == .image }.isEmpty || lower.contains("图片") || lower.contains("截图") || lower.contains("image") || lower.contains("ocr") || lower.contains("图表")
        let isCode = lower.contains("代码") || lower.contains("app") || lower.contains("xcode") || lower.contains("swift") || lower.contains("python") || lower.contains("javascript") || lower.contains("网页") || lower.contains("项目")
        let wantsImageGeneration = lower.contains("生成图片") || lower.contains("图标") || lower.contains("插图") || lower.contains("image generation")
        let complex = lower.count > 120 || lower.contains("复杂") || lower.contains("多模型") || lower.contains("投票") || lower.contains("工作流")
        let wantsOptimization = lower.contains("优化") || lower.contains("改进") || lower.contains("意见") || lower.contains("建议") || lower.contains("找问题") || lower.contains("修改")

        var kinds: [WorkflowNodeKind]
        if let preferredKinds, !preferredKinds.isEmpty {
            kinds = [.start] + preferredKinds
            if !kinds.contains(.output) { kinds.append(.output) }
        } else {
            kinds = [.start]
            if hasImage { kinds.append(.imageUnderstanding) }
            kinds.append(.planner)
            if complex { kinds.append(.dispatcher) }
            if isCode {
                kinds += [.codeWorker, .codeReviewer]
            } else {
                kinds += [.worker, .qualityReviewer]
            }
            if wantsImageGeneration { kinds += [.imageGenerator, .visualReviewer] }
            if wantsOptimization { kinds.append(.optimizer) }
            if complex { kinds += [.multiModelVote] }
            kinds += [.aggregator, .formatter]
            if isCode || lower.contains("文件") || lower.contains("zip") || lower.contains("打包") { kinds.append(.filePackager) }
            kinds += [.logger, .versionSnapshot, .output]
        }

        if hasImage && !kinds.contains(.imageUnderstanding) { kinds.insert(.imageUnderstanding, after: .start) }
        if isCode {
            if !kinds.contains(.codeWorker) { kinds.insert(.codeWorker, before: .output) }
            if !kinds.contains(.codeReviewer) { kinds.insert(.codeReviewer, before: .output) }
            if !kinds.contains(.formatter) { kinds.insert(.formatter, before: .output) }
            if !kinds.contains(.filePackager) { kinds.insert(.filePackager, before: .output) }
        }
        if wantsOptimization && !kinds.contains(.optimizer) { kinds.insert(.optimizer, before: .aggregator) }
        kinds.removeAll { $0 == .autoFixer || $0 == .autoGraph }

        var seen = Set<WorkflowNodeKind>()
        kinds = kinds.filter { seen.insert($0).inserted }
        if !kinds.contains(.start) { kinds.insert(.start, at: 0) }
        if !kinds.contains(.output) { kinds.append(.output) }

        var nodesByKind: [WorkflowNodeKind: WorkflowNode] = [:]
        var nodes: [WorkflowNode] = []
        for (index, kind) in kinds.enumerated() {
            var node = WorkflowNode(kind: kind, title: kind.title, x: 180 + Double(index % 4) * 280, y: 190 + Double(index / 4) * 210)
            node.prompt = kind == .custom ? "" : kind.defaultPrompt
            node.maxReturnCount = 0
            node.retryLimit = 0
            node.temperature = kind.isReviewer ? 0.1 : 0.3
            if kind == .codeWorker { node.timeoutSeconds = 180 }
            nodes.append(node)
            nodesByKind[kind] = node
        }

        func edge(_ from: WorkflowNodeKind, _ to: WorkflowNodeKind, _ condition: EdgeCondition = .always) -> WorkflowEdge? {
            guard let source = nodesByKind[from], let target = nodesByKind[to] else { return nil }
            return WorkflowEdge(from: source.id, to: target.id, condition: condition)
        }

        var edges: [WorkflowEdge] = []
        if hasImage, nodesByKind[.imageUnderstanding] != nil {
            if let e = edge(.start, .imageUnderstanding) { edges.append(e) }
            if let e = edge(.imageUnderstanding, .planner) { edges.append(e) }
        } else if let e = edge(.start, .planner) {
            edges.append(e)
        } else if let firstAfterStart = nodes.dropFirst().first, let start = nodesByKind[.start] {
            edges.append(WorkflowEdge(from: start.id, to: firstAfterStart.id, condition: .always))
        }

        if nodesByKind[.dispatcher] != nil {
            if let e = edge(.planner, .dispatcher) { edges.append(e) }
            if isCode, let e = edge(.dispatcher, .codeWorker) { edges.append(e) }
            if !isCode, let e = edge(.dispatcher, .worker) { edges.append(e) }
            if wantsImageGeneration, let e = edge(.dispatcher, .imageGenerator) { edges.append(e) }
        } else {
            if isCode, let e = edge(.planner, .codeWorker) { edges.append(e) }
            if !isCode, let e = edge(.planner, .worker) { edges.append(e) }
            if wantsImageGeneration, let e = edge(.planner, .imageGenerator) { edges.append(e) }
        }

        if isCode {
            if let e = edge(.codeWorker, .codeReviewer) { edges.append(e) }
            if let e = edge(.codeReviewer, .codeWorker, .failed) { edges.append(e) }
            if nodesByKind[.optimizer] != nil {
                if let e = edge(.codeReviewer, .optimizer, .passed) { edges.append(e) }
                if let e = edge(.optimizer, .aggregator) { edges.append(e) }
            } else if let e = edge(.codeReviewer, .aggregator, .passed) {
                edges.append(e)
            }
        } else {
            if let e = edge(.worker, .qualityReviewer) { edges.append(e) }
            if let e = edge(.qualityReviewer, .worker, .failed) { edges.append(e) }
            if nodesByKind[.optimizer] != nil {
                if let e = edge(.qualityReviewer, .optimizer, .passed) { edges.append(e) }
                if let e = edge(.optimizer, .aggregator) { edges.append(e) }
            } else if let e = edge(.qualityReviewer, .aggregator, .passed) {
                edges.append(e)
            }
        }

        if wantsImageGeneration {
            if let e = edge(.imageGenerator, .visualReviewer) { edges.append(e) }
            if let e = edge(.visualReviewer, .imageGenerator, .failed) { edges.append(e) }
            if let e = edge(.visualReviewer, .aggregator, .passed) { edges.append(e) }
        }

        if let e = edge(.aggregator, .multiModelVote) { edges.append(e) }
        if nodesByKind[.multiModelVote] != nil {
            if let e = edge(.multiModelVote, .formatter) { edges.append(e) }
            if let e = edge(.multiModelVote, .logger) { edges.append(e) }
        }
        if let e = edge(.aggregator, .formatter) { edges.append(e) }

        // 最终产物链路：汇总/投票 → 格式转换者 → 文件打包者 → 输出模块。
        // 输出模块只做展示/导出终点，不再做整理或格式转换。
        if nodesByKind[.filePackager] != nil {
            if let e = edge(.formatter, .filePackager) { edges.append(e) }
            if let e = edge(.filePackager, .output) { edges.append(e) }
        } else {
            if let e = edge(.formatter, .output) { edges.append(e) }
        }

        if let e = edge(.formatter, .logger) { edges.append(e) }
        if let e = edge(.filePackager, .logger) { edges.append(e) }
        if let e = edge(.aggregator, .logger) { edges.append(e) }
        if let e = edge(.logger, .versionSnapshot) { edges.append(e) }
        if let e = edge(.versionSnapshot, .output) { edges.append(e) }
        if nodesByKind[.formatter] == nil && nodesByKind[.filePackager] == nil, let e = edge(.aggregator, .output) { edges.append(e) }

        newProject.nodes = nodes
        newProject.edges = deduplicated(edges)
        newProject.autoSelectModules = false
        newProject.updatedAt = Date()
        return newProject
    }

    private static func deduplicated(_ edges: [WorkflowEdge]) -> [WorkflowEdge] {
        var seen = Set<String>()
        return edges.filter { edge in
            let key = "\(edge.from.uuidString)-\(edge.to.uuidString)-\(edge.condition.rawValue)"
            return seen.insert(key).inserted
        }
    }
}

private extension Array where Element == WorkflowNodeKind {
    mutating func insert(_ newElement: WorkflowNodeKind, after marker: WorkflowNodeKind) {
        if let index = firstIndex(of: marker) { insert(newElement, at: self.index(after: index)) } else { append(newElement) }
    }

    mutating func insert(_ newElement: WorkflowNodeKind, before marker: WorkflowNodeKind) {
        if let index = firstIndex(of: marker) { insert(newElement, at: index) } else { append(newElement) }
    }
}
