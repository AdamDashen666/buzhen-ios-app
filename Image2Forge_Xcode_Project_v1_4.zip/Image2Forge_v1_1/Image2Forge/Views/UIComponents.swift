import SwiftUI
import UIKit

struct PageScaffold<Content: View>: View {
    let content: Content
    var maxReadableWidth: CGFloat = 860

    init(maxReadableWidth: CGFloat = 860, @ViewBuilder content: () -> Content) {
        self.maxReadableWidth = maxReadableWidth
        self.content = content()
    }

    var body: some View {
        GeometryReader { proxy in
            let width = proxy.size.width
            let horizontalPadding = width < 390 ? 14.0 : (width > 900 ? 28.0 : 18.0)
            let targetWidth = min(width - horizontalPadding * 2, maxReadableWidth)

            ZStack {
                AppBackdrop()
                    .ignoresSafeArea()

                ScrollView {
                    glassContainer {
                        VStack(spacing: width < 390 ? 14 : 18) {
                            content
                        }
                        .frame(maxWidth: targetWidth)
                        .padding(.horizontal, horizontalPadding)
                        .padding(.top, 14)
                        .padding(.bottom, 28)
                    }
                }
                .scrollIndicators(.hidden)
            }
        }
    }

    @ViewBuilder
    private func glassContainer<Inner: View>(@ViewBuilder content: () -> Inner) -> some View {
        if #available(iOS 26.0, *) {
            GlassEffectContainer(spacing: 18) {
                content()
            }
        } else {
            content()
        }
    }
}

struct AppBackdrop: View {
    @State private var drift = false

    var body: some View {
        ZStack {
            LinearGradient(
                colors: [
                    Color(.systemBackground),
                    Color.accentColor.opacity(0.08),
                    Color(.systemBackground)
                ],
                startPoint: drift ? .topLeading : .bottomTrailing,
                endPoint: drift ? .bottomTrailing : .topLeading
            )

            Circle()
                .fill(Color.blue.opacity(0.16))
                .frame(width: 360, height: 360)
                .blur(radius: 58)
                .offset(x: drift ? -110 : -30, y: drift ? -260 : -190)

            Circle()
                .fill(Color.purple.opacity(0.12))
                .frame(width: 320, height: 320)
                .blur(radius: 68)
                .offset(x: drift ? 120 : 40, y: drift ? 260 : 210)
        }
        .onAppear {
            withAnimation(.spring(response: 5.2, dampingFraction: 0.74).repeatForever(autoreverses: true)) {
                drift.toggle()
            }
        }
    }
}

struct CardView<Content: View>: View {
    let content: Content

    init(@ViewBuilder content: () -> Content) {
        self.content = content()
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            content
        }
        .padding(adaptivePadding)
        .frame(maxWidth: .infinity, alignment: .leading)
        .liquidGlassSurface(cornerRadius: 28, interactive: false)
        .transition(.asymmetric(
            insertion: .scale(scale: 0.985).combined(with: .opacity).combined(with: .move(edge: .top)),
            removal: .opacity.combined(with: .scale(scale: 0.98))
        ))
    }

    private var adaptivePadding: CGFloat {
        UIDevice.current.userInterfaceIdiom == .pad ? 22 : 18
    }
}

struct Badge: View {
    let text: String
    let systemImage: String

    var body: some View {
        Label(text, systemImage: systemImage)
            .font(.caption.weight(.semibold))
            .lineLimit(1)
            .padding(.horizontal, 11)
            .padding(.vertical, 7)
            .liquidGlassCapsule(tint: Color.accentColor.opacity(0.14), interactive: false)
            .foregroundStyle(Color.accentColor)
            .contentTransition(.numericText())
            .animation(.spring(response: 0.42, dampingFraction: 0.72), value: text)
    }
}

struct PillLabel: View {
    let title: String
    let systemImage: String

    var body: some View {
        Label(title, systemImage: systemImage)
            .font(.footnote.weight(.semibold))
            .padding(.horizontal, 12)
            .padding(.vertical, 8)
            .liquidGlassCapsule(tint: .primary.opacity(0.05), interactive: false)
    }
}

struct ResponsiveButtonStack<Content: View>: View {
    let content: Content

    init(@ViewBuilder content: () -> Content) {
        self.content = content()
    }

    var body: some View {
        ViewThatFits(in: .horizontal) {
            HStack(spacing: 10) { content }
            VStack(spacing: 10) { content }
        }
    }
}

struct LiquidGlassButtonStyle: ButtonStyle {
    var prominent = false

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.headline.weight(.semibold))
            .padding(.horizontal, 16)
            .padding(.vertical, 13)
            .frame(maxWidth: .infinity)
            .foregroundStyle(prominent ? .white : .primary)
            .background(prominent ? Color.accentColor.opacity(configuration.isPressed ? 0.82 : 0.92) : Color.primary.opacity(0.045), in: Capsule())
            .liquidGlassCapsule(tint: prominent ? Color.accentColor.opacity(0.18) : Color.primary.opacity(0.04), interactive: true)
            .scaleEffect(configuration.isPressed ? 0.965 : 1.0)
            .blur(radius: configuration.isPressed ? 0.15 : 0)
            .animation(.spring(response: 0.24, dampingFraction: 0.62, blendDuration: 0.18), value: configuration.isPressed)
    }
}

extension View {
    @ViewBuilder
    func liquidGlassSurface(cornerRadius: CGFloat, interactive: Bool) -> some View {
        let shape = RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
        if #available(iOS 26.0, *) {
            self
                .background(Color.white.opacity(0.035), in: shape)
                .glassEffect(interactive ? .regular.interactive() : .regular, in: shape)
                .overlay(shape.stroke(.white.opacity(0.15), lineWidth: 0.8))
                .shadow(color: .black.opacity(0.08), radius: 22, x: 0, y: 12)
        } else {
            self
                .background(.regularMaterial, in: shape)
                .overlay(shape.stroke(.primary.opacity(0.06), lineWidth: 1))
                .shadow(color: .black.opacity(0.06), radius: 18, x: 0, y: 10)
        }
    }

    @ViewBuilder
    func liquidGlassCapsule(tint: Color, interactive: Bool) -> some View {
        let shape = Capsule()
        if #available(iOS 26.0, *) {
            self
                .background(tint, in: shape)
                .glassEffect(interactive ? .regular.interactive() : .regular, in: shape)
                .overlay(shape.stroke(.white.opacity(0.14), lineWidth: 0.8))
        } else {
            self
                .background(.thinMaterial, in: shape)
                .overlay(shape.stroke(.primary.opacity(0.06), lineWidth: 1))
        }
    }
}

struct ResultCard: View {
    let record: GeneratedImageRecord
    @State private var saveMessage: String?

    var body: some View {
        CardView {
            VStack(alignment: .leading, spacing: 14) {
                HStack {
                    Label("生成结果", systemImage: "checkmark.seal.fill")
                        .font(.headline)
                    Spacer()
                    ShareLink(item: record.fileURL) {
                        Label("分享 / 保存", systemImage: "square.and.arrow.up")
                    }
                }

                if let uiImage = UIImage(contentsOfFile: record.fileURL.path) {
                    Image(uiImage: uiImage)
                        .resizable()
                        .scaledToFit()
                        .frame(maxWidth: .infinity)
                        .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
                        .shadow(color: .black.opacity(0.1), radius: 18, x: 0, y: 10)

                    ResponsiveButtonStack {
                        Button {
                            UIImageWriteToSavedPhotosAlbum(uiImage, nil, nil, nil)
                            saveMessage = "已请求保存到相册"
                        } label: {
                            Label("保存到相册", systemImage: "square.and.arrow.down")
                        }
                        .buttonStyle(LiquidGlassButtonStyle())

                        ShareLink(item: record.fileURL) {
                            Label("导出文件", systemImage: "doc")
                        }
                        .buttonStyle(LiquidGlassButtonStyle(prominent: true))
                    }
                }

                Text("模型：\(record.model) · 尺寸：\(record.size) · \(record.pixelSummary)")
                    .font(.footnote)
                    .foregroundStyle(.secondary)

                if let revised = record.revisedPrompt, !revised.isEmpty {
                    DisclosureGroup("Revised prompt") {
                        Text(revised)
                            .font(.footnote)
                            .textSelection(.enabled)
                    }
                }

                if let saveMessage {
                    Text(saveMessage)
                        .font(.footnote.weight(.medium))
                        .foregroundStyle(.green)
                        .transition(.opacity.combined(with: .move(edge: .top)))
                }
            }
            .animation(.spring(response: 0.36, dampingFraction: 0.7), value: saveMessage)
        }
    }
}
