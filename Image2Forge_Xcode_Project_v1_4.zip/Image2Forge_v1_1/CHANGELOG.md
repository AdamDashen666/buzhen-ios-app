# Changelog

## v1.1 - Build Fix

- 修复 `Image2Forge.xcodeproj/project.pbxproj` 里错误的双大括号，解决 Xcode 报 “project is damaged / parse error”。
- 新增共享 Scheme：`Image2Forge.xcscheme`，解决自动构建时 “No shared scheme found”。
- 给 `AppSettings.swift`、`HistoryStore.swift` 补充 `import Combine`，避免 `ObservableObject` / `@Published` 相关编译失败。
- 保留 v1.0 的 APIYI 默认 Base URL、模型刷新、4K 分辨率、文生图与参考图上传功能。

## v1.0

- 默认 Base URL: `https://api.apiyi.com/v1`
- 默认模型: `gpt-image-2-vip`
- 支持刷新模型 `/models`
- 支持文生图 `/images/generations`
- 支持图片编辑 `/images/edits`
- 支持 1K / 2K / 4K 尺寸预设与自定义尺寸
- 支持相册 / 文件上传参考图
- 支持历史记录、分享、保存到相册


## v1.2
- 新增本地任务队列。
- 开始生成后立即创建任务，不再阻塞后续任务创建。
- 新增任务列表与估算进度条。
- 默认最多同时并行 3 个，超出的自动排队。
- 完成后可保存到相册，或通过 ShareLink 下载 / 分享文件。


## v1.3
- 修复上传图片时 4K/自定义尺寸容易被第三方接口降成 1MP 的体验问题。
- 对 gpt-image-2-vip / gpt-image-2-all 自动不发送 quality 参数，因为 APIYI 文档明确写这两个模型不支持 quality。
- 对 gpt-image-2-vip / gpt-image-2-all 自动不发送 n 参数，避免不必要计费和兼容问题。
- 上传参考图不再转 PNG，改为压缩 JPEG，并尽量控制在 1.5MB 左右，提高图生图/多图融合的成功率。
- 增加实际输出像素检测：历史记录和任务列表显示真实像素与 MP。
- 增加“严格导出所选尺寸”：如果 API 原生返回低分辨率，App 会本地补齐导出为所选尺寸，并在任务状态/详情中注明。
- 修复 b64_json 带 data:image/png;base64, 前缀时解码失败的问题。

## v1.4
- 重新适配 iOS 27 风格 UI：液态玻璃卡片、胶囊按钮、玻璃化任务行。
- 大量使用 Liquid Glass / GlassEffectContainer 风格接口，并保留旧系统 Material fallback。
- 生成页、设置页、历史页改成响应式宽度布局，适配小屏 iPhone、大屏 iPhone、iPad。
- 按钮、任务插入、模型选择、状态变化加入非线性 spring 动画。
- 去掉设置页和历史页原来的 Form/List 生硬样式，改成统一视觉语言。
