import Foundation
import AVFoundation
import Vision

enum OpticalFlowQuality: String, CaseIterable, Identifiable {
    case fast
    case extreme
    case supremeAI

    var id: String { rawValue }

    var title: String {
        switch self {
        case .fast:
            return "1 快速"
        case .extreme:
            return "2 极限光流"
        case .supremeAI:
            return "3 终极AI混合"
        }
    }

    var subtitle: String {
        switch self {
        case .fast:
            return "低精度光流，速度优先"
        case .extreme:
            return "原光流 4：最高精度 + 更高码率，画质优先"
        case .supremeAI:
            return "原光流 7：双向 veryHigh + 更强一致性抑制 + 更低混合拖影 + 更强锐化，最慢，适合最终导出"
        }
    }

    var visionAccuracy: VNGenerateOpticalFlowRequest.ComputationAccuracy {
        switch self {
        case .fast:
            return .low
        case .extreme, .supremeAI:
            return .veryHigh
        }
    }

    var bitrateMultiplier: Double {
        switch self {
        case .fast:
            return 1.00
        case .extreme:
            return 1.85
        case .supremeAI:
            return 2.85
        }
    }

    var blendStrength: Float {
        switch self {
        case .fast:
            return 1.00
        case .extreme:
            return 0.70
        case .supremeAI:
            return 0.34
        }
    }

    var sharpenAmount: Float {
        switch self {
        case .fast:
            return 0.00
        case .extreme:
            return 0.12
        case .supremeAI:
            return 0.30
        }
    }

    var consistencyStrength: Float {
        switch self {
        case .supremeAI:
            return 1.00
        case .extreme:
            return 0.25
        case .fast:
            return 0.00
        }
    }

    var usesBidirectionalConsistency: Bool {
        self == .supremeAI
    }
}
enum ProcessingMode: String, CaseIterable, Identifiable {
    case full
    case serialSegmented
    case parallelSegmented

    var id: String { rawValue }

    var title: String {
        switch self {
        case .full:
            return "单次完整处理"
        case .serialSegmented:
            return "串行分段处理"
        case .parallelSegmented:
            return "并行分段处理"
        }
    }

    var subtitle: String {
        switch self {
        case .full:
            return "最简单，但长视频更容易爆内存"
        case .serialSegmented:
            return "稳定优先，适合 iPad 长视频"
        case .parallelSegmented:
            return "速度优先，发热/内存压力更高"
        }
    }
}

enum OutputMode: String, CaseIterable, Identifiable {
    case appleHEVC
    case h264Compatible
    case hdrPreserve

    var id: String { rawValue }

    var title: String {
        switch self {
        case .appleHEVC:
            return "Apple HEVC 兼容"
        case .h264Compatible:
            return "H.264 最稳兼容"
        case .hdrPreserve:
            return "HDR 保留模式"
        }
    }

    var fileType: AVFileType {
        switch self {
        case .appleHEVC, .hdrPreserve:
            return .mov
        case .h264Compatible:
            return .mp4
        }
    }

    var fileExtension: String {
        switch self {
        case .appleHEVC, .hdrPreserve:
            return "mov"
        case .h264Compatible:
            return "mp4"
        }
    }

    var codec: AVVideoCodecType {
        switch self {
        case .appleHEVC, .hdrPreserve:
            return .hevc
        case .h264Compatible:
            return .h264
        }
    }

    var wantsHDR: Bool {
        self == .hdrPreserve
    }
}

enum BitrateMode: String, CaseIterable, Identifiable {
    case automatic
    case customMbps

    var id: String { rawValue }

    var title: String {
        switch self {
        case .automatic:
            return "自动推荐"
        case .customMbps:
            return "手动 Mbps"
        }
    }
}

struct ProcessingOptions: Sendable {
    let targetFPS: Double
    let quality: OpticalFlowQuality
    let processingMode: ProcessingMode
    let segmentSeconds: Double
    let maxParallelJobs: Int
    let outputMode: OutputMode
    let bitrateMode: BitrateMode
    let customBitrateMbps: Double
    let keepAudio: Bool
    let keepMetadata: Bool
    let preserveHDRTags: Bool
}

struct VideoFrame {
    let pixelBuffer: CVPixelBuffer
    let pts: CMTime
}

struct SegmentJob: Sendable {
    let index: Int
    let start: Double
    let duration: Double
}
