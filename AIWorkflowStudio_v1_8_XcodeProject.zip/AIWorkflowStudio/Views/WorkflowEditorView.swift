import SwiftUI
import UIKit

private struct ConnectionDraft: Equatable {
    var nodeID: UUID
    var condition: EdgeCondition
}

private struct ViewportFrameKey: PreferenceKey {
    static var defaultValue: CGRect = .zero
    static func reduce(value: inout CGRect, nextValue: () -> CGRect) { value = nextValue() }
}

struct WorkflowEditorView: View {
    @EnvironmentObject private var store: AppStore
    @State private var showingLibrary = false
    @State private var editingNode: WorkflowNode?
    @State private var selectedNodeID: UUID?
    @State private var copiedNode: WorkflowNode?
    @State private var connectFrom: ConnectionDraft?
    @State private var dragPoint: CGPoint?
    @State private var zoom: CGFloat = 1.0
    @State private var lastZoom: CGFloat = 1.0
    @State private var nodePositions: [UUID: CGPoint] = [:]
    @State private var dragStartPositions: [UUID: CGPoint] = [:]
    @State private var selectedEdgeID: UUID?
    @State private var edgeAwaitingDeleteID: UUID?
    @State private var moduleMenuNode: WorkflowNode?
    @State private var addModuleSpawnPoint: CGPoint?
    @State private var viewportSize: CGSize = .zero
    @State private var contentFrame: CGRect = .zero

    private let minimumCanvasSize = CGSize(width: 4200, height: 3200)
    private let minZoom: CGFloat = 0.40
    private let maxZoom: CGFloat = 1.80

    var body: some View {
        NavigationStack {
            Group {
                if let project = store.selectedProject {
                    GeometryReader { proxy in
                        if proxy.size.width > 720 {
                            canvas(project: project, viewport: proxy.size)
                        } else {
                            listEditor(project: project)
                        }
                    }
                } else {
                    ContentUnavailableView("没有项目", systemImage: "folder.badge.plus", description: Text("先在首页新建一个工作流。"))
                }
            }
            .studioBackground()
            .navigationTitle(store.selectedProject?.title ?? "工作流")
            .toolbar {
                ToolbarItemGroup(placement: .topBarTrailing) {
                    Button("添加模块") {
                        addModuleSpawnPoint = visibleCenterPoint()
                        showingLibrary = true
                    }
                    Button("AI 自动选择") { store.startAutoBuildSelectedProject() }
                    Button("一键应用默认模型") { store.applyDefaultModelsToSelectedProject() }
                    Button { store.startSelectedProjectRun() } label: { Label("运行", systemImage: "play.fill") }
                    Button(role: .destructive) { store.stopActiveRun() } label: { Label("停止", systemImage: "stop.fill") }
                }
            }
            .sheet(isPresented: $showingLibrary) { ModuleLibrarySheet(spawnPoint: addModuleSpawnPoint) }
            .sheet(item: $editingNode) { node in
                if let project = store.selectedProject {
                    NodeDetailView(projectID: project.id, node: node)
                }
            }
            .overlay { autoBuildOverlay }
            .alert(item: $store.appAlert) { alert in
                Alert(title: Text(alert.title), message: Text(alert.message), dismissButton: .default(Text("知道了")))
            }
            .confirmationDialog("模块操作", item: $moduleMenuNode, titleVisibility: .visible) { node in
                Button("打开模块详情") { editingNode = node }
                Button("复制模块") { copiedNode = node }
                if node.kind != .start && node.kind != .output, let project = store.selectedProject {
                    Button("删除模块", role: .destructive) { store.removeNode(projectID: project.id, nodeID: node.id) }
                }
                Button("取消", role: .cancel) { }
            } message: { node in
                Text("已选中：\(node.title)")
            }
        }
    }

    private func canvas(project: WorkflowProject, viewport: CGSize) -> some View {
        let visibleRect = currentVisibleRect(viewport: viewport)
        let visibleNodes = project.nodes.filter { visibleRect.contains(localPosition(for: $0)) }
        let canvasSize = dynamicCanvasSize(for: project, viewport: viewport)

        return ScrollView([.horizontal, .vertical], showsIndicators: false) {
            ZStack(alignment: .topLeading) {
                GeometryReader { geo in
                    Color.clear.preference(key: ViewportFrameKey.self, value: geo.frame(in: .named("workflowScroll")))
                }
                .frame(width: 0, height: 0)

                edgeLayer(project: project, visibleRect: visibleRect, canvasSize: canvasSize)

                ForEach(visibleNodes) { node in
                    let position = localPosition(for: node)
                    NodeCard(
                        node: node,
                        selected: selectedNodeID == node.id,
                        isConnecting: connectFrom?.nodeID == node.id,
                        onSelect: { handleNodeTap(node) },
                        onInputTap: {
                            if let connectFrom, connectFrom.nodeID != node.id {
                                store.connect(projectID: project.id, from: connectFrom.nodeID, to: node.id, condition: connectFrom.condition)
                                self.connectFrom = nil
                                self.dragPoint = nil
                            }
                        },
                        onOutputTap: { condition in
                            connectFrom = ConnectionDraft(nodeID: node.id, condition: condition)
                            dragPoint = portPoint(for: node, condition: condition)
                        },
                        onOutputDragChanged: { condition, value in
                            connectFrom = ConnectionDraft(nodeID: node.id, condition: condition)
                            let start = portPoint(for: node, condition: condition)
                            dragPoint = CGPoint(
                                x: start.x + value.translation.width / max(zoom, 0.1),
                                y: start.y + value.translation.height / max(zoom, 0.1)
                            )
                        },
                        onOutputDragEnded: { condition, value in
                            let start = portPoint(for: node, condition: condition)
                            let endPoint = CGPoint(
                                x: start.x + value.translation.width / max(zoom, 0.1),
                                y: start.y + value.translation.height / max(zoom, 0.1)
                            )
                            if let target = targetNode(at: endPoint, in: project, excluding: node.id) {
                                store.connect(projectID: project.id, from: node.id, to: target.id, condition: condition)
                            }
                            connectFrom = nil
                            dragPoint = nil
                        },
                        onCardDragChanged: { value in
                            let start = dragStartPositions[node.id] ?? localPosition(for: node)
                            if dragStartPositions[node.id] == nil { dragStartPositions[node.id] = start }
                            let next = unclampedPoint(
                                x: start.x + value.translation.width / max(zoom, 0.1),
                                y: start.y + value.translation.height / max(zoom, 0.1)
                            )
                            nodePositions[node.id] = next
                        },
                        onCardDragEnded: { value in
                            defer { dragStartPositions[node.id] = nil }
                            let start = dragStartPositions[node.id] ?? localPosition(for: node)
                            let next = unclampedPoint(
                                x: start.x + value.translation.width / max(zoom, 0.1),
                                y: start.y + value.translation.height / max(zoom, 0.1)
                            )
                            nodePositions[node.id] = next
                            store.moveNode(projectID: project.id, nodeID: node.id, x: Double(next.x), y: Double(next.y), persist: true)
                        }
                    )
                    .position(x: position.x, y: position.y)
                }
            }
            .frame(width: canvasSize.width, height: canvasSize.height, alignment: .topLeading)
            .scaleEffect(zoom, anchor: .topLeading)
            .frame(width: canvasSize.width * zoom, height: canvasSize.height * zoom, alignment: .topLeading)
            .contentShape(Rectangle())
            .gesture(zoomGesture)
            .background(KeyCommandReader(
                onDelete: { deleteSelection(project: project) },
                onCopy: { copySelection(project: project) },
                onPaste: { pasteSelection(project: project) }
            ))
            .onAppear {
                viewportSize = viewport
                syncNodePositions(project)
            }
            .onChange(of: project.nodes) { _, _ in syncNodePositions(project) }
            .onPreferenceChange(ViewportFrameKey.self) { frame in
                contentFrame = frame
                viewportSize = viewport
            }
        }
        .coordinateSpace(name: "workflowScroll")
        .overlay(alignment: .topLeading) { cleanLeftControls(project: project).padding(12) }
        .overlay(alignment: .topTrailing) { cleanRightControls(project: project).padding(12) }
        .overlay(alignment: .bottomLeading) {
            Text("拖模块主体移动 · 从输出口拖到输入口连线 · 检查者有“不合格”返工出口 · ⌘C/⌘V 复制粘贴")
                .font(.caption2)
                .foregroundStyle(.white.opacity(0.72))
                .padding(.horizontal, 12)
                .padding(.vertical, 8)
                .background(.black.opacity(0.26), in: Capsule())
                .padding(12)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
    }

    private var autoBuildOverlay: some View {
        Group {
            if store.isAutoBuilding {
                VStack(spacing: 12) {
                    ProgressView(value: store.autoBuildProgress)
                    Text(store.autoBuildMessage)
                        .font(.headline)
                    Text("正在根据开始模块提示词生成模块和连线")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                .padding(24)
                .frame(width: 360)
                .liquidGlass(cornerRadius: 26, glow: true)
            }
        }
    }

    private func currentVisibleRect(viewport: CGSize) -> CGRect {
        guard contentFrame != .zero else { return CGRect(x: 0, y: 0, width: 1800, height: 1200) }
        return CGRect(
            x: max(0, -contentFrame.minX / max(zoom, 0.1)),
            y: max(0, -contentFrame.minY / max(zoom, 0.1)),
            width: viewport.width / max(zoom, 0.1),
            height: viewport.height / max(zoom, 0.1)
        ).insetBy(dx: -900, dy: -700)
    }

    private func visibleCenterPoint() -> CGPoint {
        let rect = currentVisibleRect(viewport: viewportSize == .zero ? CGSize(width: 1200, height: 800) : viewportSize)
        return unclampedPoint(x: rect.midX, y: rect.midY)
    }

    private func dynamicCanvasSize(for project: WorkflowProject, viewport: CGSize) -> CGSize {
        let maxX = project.nodes.map { CGFloat($0.x) }.max() ?? 0
        let maxY = project.nodes.map { CGFloat($0.y) }.max() ?? 0
        return CGSize(
            width: max(minimumCanvasSize.width, maxX + viewport.width / max(zoom, 0.1) + 1600),
            height: max(minimumCanvasSize.height, maxY + viewport.height / max(zoom, 0.1) + 1400)
        )
    }

    private func edgeLayer(project: WorkflowProject, visibleRect: CGRect, canvasSize: CGSize) -> some View {
        ZStack(alignment: .topLeading) {
            ForEach(project.edges.filter { edgeVisible($0, in: project, visibleRect: visibleRect) }) { edge in
                if let points = edgePoints(edge, in: project) {
                    let selected = selectedEdgeID == edge.id
                    EdgeCurveShape(start: points.start, end: points.end)
                        .stroke(edgeColor(edge).opacity(selected ? 0.95 : 0.68), lineWidth: selected ? 4 : 2.2)
                    EdgeCurveShape(start: points.start, end: points.end)
                        .stroke(Color.white.opacity(0.001), lineWidth: 34)
                        .contentShape(EdgeCurveShape(start: points.start, end: points.end))
                        .onTapGesture {
                            if selectedEdgeID == edge.id { edgeAwaitingDeleteID = edge.id } else {
                                selectedEdgeID = edge.id
                                selectedNodeID = nil
                                edgeAwaitingDeleteID = nil
                            }
                        }
                    Text(edge.condition == .failed ? "不合格" : edge.condition == .passed ? "通过" : "")
                        .font(.caption2.bold())
                        .foregroundStyle(edgeColor(edge))
                        .position(midpoint(points.start, points.end))
                    if edgeAwaitingDeleteID == edge.id {
                        Button(role: .destructive) {
                            store.removeEdge(projectID: project.id, edgeID: edge.id)
                            selectedEdgeID = nil
                            edgeAwaitingDeleteID = nil
                        } label: {
                            Label("删除连线", systemImage: "trash")
                                .font(.caption.bold())
                        }
                        .buttonStyle(.borderedProminent)
                        .controlSize(.small)
                        .position(CGPoint(x: midpoint(points.start, points.end).x, y: midpoint(points.start, points.end).y - 34))
                    }
                }
            }

            if let connectFrom,
               let source = project.nodes.first(where: { $0.id == connectFrom.nodeID }),
               let dragPoint {
                EdgeCurveShape(start: portPoint(for: source, condition: connectFrom.condition), end: dragPoint)
                    .stroke(edgeColor(connectFrom.condition).opacity(0.92), lineWidth: 3)
            }
        }
        .frame(width: canvasSize.width, height: canvasSize.height)
    }

    private func edgeVisible(_ edge: WorkflowEdge, in project: WorkflowProject, visibleRect: CGRect) -> Bool {
        guard let points = edgePoints(edge, in: project) else { return false }
        return visibleRect.insetBy(dx: -400, dy: -400).contains(points.start) || visibleRect.insetBy(dx: -400, dy: -400).contains(points.end)
    }

    private func edgePoints(_ edge: WorkflowEdge, in project: WorkflowProject) -> (start: CGPoint, end: CGPoint)? {
        guard let from = project.nodes.first(where: { $0.id == edge.from }),
              let to = project.nodes.first(where: { $0.id == edge.to }) else { return nil }
        return (portPoint(for: from, condition: edge.condition), inputPortPoint(for: to))
    }

    private func portPoint(for node: WorkflowNode, condition: EdgeCondition) -> CGPoint {
        let p = localPosition(for: node)
        if node.kind.isReviewer && condition == .failed { return CGPoint(x: p.x + 124, y: p.y + 46) }
        return CGPoint(x: p.x + 124, y: p.y - (node.kind.isReviewer ? 26 : 0))
    }

    private func inputPortPoint(for node: WorkflowNode) -> CGPoint {
        let p = localPosition(for: node)
        return CGPoint(x: p.x - 124, y: p.y)
    }

    private func edgeColor(_ edge: WorkflowEdge) -> Color { edgeColor(edge.condition) }
    private func edgeColor(_ condition: EdgeCondition) -> Color {
        switch condition {
        case .failed, .scoreLow: return .red
        case .passed, .scoreHigh: return .mint
        case .always: return .cyan
        }
    }

    private func localPosition(for node: WorkflowNode) -> CGPoint {
        nodePositions[node.id] ?? CGPoint(x: CGFloat(node.x), y: CGFloat(node.y))
    }

    private func syncNodePositions(_ project: WorkflowProject) {
        var next = nodePositions
        let ids = Set(project.nodes.map(\.id))
        next = next.filter { ids.contains($0.key) }
        for node in project.nodes where next[node.id] == nil {
            next[node.id] = CGPoint(x: CGFloat(node.x), y: CGFloat(node.y))
        }
        nodePositions = next
    }

    private func unclampedPoint(x: CGFloat, y: CGFloat) -> CGPoint {
        CGPoint(x: max(x, 120), y: max(y, 100))
    }

    private var zoomGesture: some Gesture {
        MagnificationGesture()
            .onChanged { value in
                let softened = 1 + (value - 1) * 0.12
                zoom = min(max(lastZoom * softened, minZoom), maxZoom)
            }
            .onEnded { _ in lastZoom = zoom }
    }

    private func cleanLeftControls(project: WorkflowProject) -> some View {
        HStack(spacing: 8) {
            Button(role: .destructive) {
                store.resetWorkflow(projectID: project.id)
                selectedEdgeID = nil
                selectedNodeID = nil
                edgeAwaitingDeleteID = nil
            } label: { Label("重置", systemImage: "arrow.counterclockwise") }
            Button(role: .destructive) {
                store.removeAllEdges(projectID: project.id)
                selectedEdgeID = nil
                edgeAwaitingDeleteID = nil
            } label: { Label("清空连线", systemImage: "link.badge.minus") }
        }
        .buttonStyle(.borderedProminent)
        .controlSize(.small)
    }

    private func cleanRightControls(project: WorkflowProject) -> some View {
        HStack(spacing: 8) {
            Text("缩放 \(Int(zoom * 100))%")
                .font(.caption.weight(.semibold))
                .padding(.horizontal, 10)
                .padding(.vertical, 7)
                .background(.black.opacity(0.28), in: Capsule())
            Button("1:1") { zoom = 1.0; lastZoom = 1.0 }
            Button("一键默认模型") { store.applyDefaultModels(to: project.id) }
        }
        .buttonStyle(.bordered)
        .controlSize(.small)
    }

    private func targetNode(at point: CGPoint, in project: WorkflowProject, excluding sourceID: UUID) -> WorkflowNode? {
        project.nodes
            .filter { $0.id != sourceID }
            .min { lhs, rhs in distance(point, inputPortPoint(for: lhs)) < distance(point, inputPortPoint(for: rhs)) }
            .flatMap { candidate in
                let target = inputPortPoint(for: candidate)
                return distance(point, target) < 110 ? candidate : nil
            }
    }

    private func handleNodeTap(_ node: WorkflowNode) {
        selectedEdgeID = nil
        edgeAwaitingDeleteID = nil
        if selectedNodeID == node.id { editingNode = node } else { selectedNodeID = node.id }
    }

    private func deleteSelection(project: WorkflowProject) {
        if let edgeID = selectedEdgeID {
            store.removeEdge(projectID: project.id, edgeID: edgeID)
            selectedEdgeID = nil
            edgeAwaitingDeleteID = nil
        }
    }

    private func copySelection(project: WorkflowProject) {
        guard let id = selectedNodeID,
              let node = project.nodes.first(where: { $0.id == id }),
              node.kind != .start,
              node.kind != .output else { return }
        copiedNode = node
    }

    private func pasteSelection(project: WorkflowProject) {
        guard let copiedNode else { return }
        selectedNodeID = store.pasteNode(copiedNode, to: project.id, near: visibleCenterPoint())
    }

    private func midpoint(_ a: CGPoint, _ b: CGPoint) -> CGPoint {
        CGPoint(x: (a.x + b.x) / 2, y: (a.y + b.y) / 2)
    }

    private func distance(_ a: CGPoint, _ b: CGPoint) -> CGFloat {
        hypot(a.x - b.x, a.y - b.y)
    }

    private func listEditor(project: WorkflowProject) -> some View {
        List {
            Section("快速操作") {
                Button { store.applyDefaultModels(to: project.id) } label: { Label("一键应用全局默认模型", systemImage: "bolt.badge.checkmark") }
                Button { store.startSelectedProjectRun() } label: { Label("运行工作流", systemImage: "play.fill") }
                Button(role: .destructive) { store.stopActiveRun() } label: { Label("停止运行", systemImage: "stop.fill") }
                Button(role: .destructive) { store.resetWorkflow(projectID: project.id) } label: { Label("重置：清除所有模块", systemImage: "arrow.counterclockwise") }
                Button(role: .destructive) { store.removeAllEdges(projectID: project.id) } label: { Label("清空全部连线", systemImage: "link.badge.minus") }
            }
            Section("节点") {
                ForEach(project.nodes) { node in
                    Button { handleNodeTap(node) } label: {
                        VStack(alignment: .leading, spacing: 4) {
                            Label(node.title, systemImage: node.kind.icon)
                            Text(node.kind.summary).font(.caption).foregroundStyle(.secondary)
                        }
                    }
                }
                .onDelete { offsets in
                    for index in offsets { store.removeNode(projectID: project.id, nodeID: project.nodes[index].id) }
                }
            }
            Section("连线") {
                if project.edges.isEmpty {
                    Text("暂无连线。iPhone 小屏建议用 iPad 横屏画布拖端口连线。")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                ForEach(project.edges) { edge in
                    HStack {
                        Text("\(project.nodes.first(where: { $0.id == edge.from })?.title ?? "?") → \(project.nodes.first(where: { $0.id == edge.to })?.title ?? "?")")
                        Text(edge.condition.title).font(.caption).foregroundStyle(.secondary)
                        Spacer()
                        Button(role: .destructive) { store.removeEdge(projectID: project.id, edgeID: edge.id) } label: { Image(systemName: "trash") }
                    }
                }
            }
        }
        .scrollContentBackground(.hidden)
    }
}

struct EdgeCurveShape: Shape {
    var start: CGPoint
    var end: CGPoint

    func path(in rect: CGRect) -> Path {
        var path = Path()
        path.move(to: start)
        let dx = max(abs(end.x - start.x) * 0.45, 80)
        path.addCurve(
            to: end,
            control1: CGPoint(x: start.x + dx, y: start.y),
            control2: CGPoint(x: end.x - dx, y: end.y)
        )
        return path
    }
}

struct NodeCard: View {
    var node: WorkflowNode
    var selected: Bool
    var isConnecting: Bool
    var onSelect: () -> Void
    var onInputTap: () -> Void
    var onOutputTap: (EdgeCondition) -> Void
    var onOutputDragChanged: (EdgeCondition, DragGesture.Value) -> Void
    var onOutputDragEnded: (EdgeCondition, DragGesture.Value) -> Void
    var onCardDragChanged: (DragGesture.Value) -> Void
    var onCardDragEnded: (DragGesture.Value) -> Void

    var body: some View {
        HStack(spacing: 10) {
            port(title: "输入", systemImage: "arrow.down.circle.fill", color: .cyan)
                .onTapGesture(perform: onInputTap)
            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    Image(systemName: node.kind.icon)
                    Text(node.title).font(.headline)
                }
                Text(node.kind.summary)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .lineLimit(2)
                HStack {
                    Text(node.status.title)
                        .font(.caption2.bold())
                        .padding(.horizontal, 8)
                        .padding(.vertical, 4)
                        .background(.cyan.opacity(0.20), in: Capsule())
                    Text(selected ? "已选中，再点菜单" : "拖动模块移动")
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                }
            }
            .frame(width: 184, alignment: .leading)
            .contentShape(RoundedRectangle(cornerRadius: 18))
            .onTapGesture(perform: onSelect)
            .gesture(
                DragGesture(minimumDistance: 6)
                    .onChanged(onCardDragChanged)
                    .onEnded(onCardDragEnded)
            )

            VStack(spacing: 8) {
                outputPort(title: node.kind.isReviewer ? "通过" : "输出", condition: node.kind.isReviewer ? .passed : .always, color: .mint)
                if node.kind.isReviewer {
                    outputPort(title: "不合格", condition: .failed, color: .red)
                }
            }
        }
        .liquidGlass(cornerRadius: 22, glow: isConnecting || selected)
        .overlay(
            RoundedRectangle(cornerRadius: 22, style: .continuous)
                .stroke(selected ? Color.mint.opacity(0.90) : Color.clear, lineWidth: 2)
        )
        .scaleEffect(isConnecting ? 1.035 : 1)
    }

    private func outputPort(title: String, condition: EdgeCondition, color: Color) -> some View {
        port(title: title, systemImage: condition == .failed ? "xmark.circle.fill" : "arrow.up.circle.fill", color: color)
            .onTapGesture { onOutputTap(condition) }
            .gesture(
                DragGesture(minimumDistance: 0)
                    .onChanged { onOutputDragChanged(condition, $0) }
                    .onEnded { onOutputDragEnded(condition, $0) }
            )
    }

    private func port(title: String, systemImage: String, color: Color) -> some View {
        VStack(spacing: 3) {
            Image(systemName: systemImage)
                .font(.title3)
                .foregroundStyle(color)
                .padding(8)
                .background(.black.opacity(0.24), in: Circle())
                .overlay(Circle().stroke(color.opacity(0.65), lineWidth: 1.5))
            Text(title)
                .font(.caption2)
                .foregroundStyle(.secondary)
        }
        .contentShape(Rectangle())
    }
}

struct KeyCommandReader: UIViewRepresentable {
    var onDelete: () -> Void
    var onCopy: () -> Void
    var onPaste: () -> Void

    func makeUIView(context: Context) -> KeyCatcherView {
        let view = KeyCatcherView()
        view.onDelete = onDelete
        view.onCopy = onCopy
        view.onPaste = onPaste
        DispatchQueue.main.async { view.becomeFirstResponder() }
        return view
    }

    func updateUIView(_ uiView: KeyCatcherView, context: Context) {
        uiView.onDelete = onDelete
        uiView.onCopy = onCopy
        uiView.onPaste = onPaste
        DispatchQueue.main.async { uiView.becomeFirstResponder() }
    }
}

final class KeyCatcherView: UIView {
    var onDelete: (() -> Void)?
    var onCopy: (() -> Void)?
    var onPaste: (() -> Void)?
    override var canBecomeFirstResponder: Bool { true }
    override var keyCommands: [UIKeyCommand]? {
        [
            UIKeyCommand(input: UIKeyCommand.inputDelete, modifierFlags: [], action: #selector(deletePressed)),
            UIKeyCommand(input: "c", modifierFlags: .command, action: #selector(copyPressed)),
            UIKeyCommand(input: "v", modifierFlags: .command, action: #selector(pastePressed))
        ]
    }
    @objc private func deletePressed() { onDelete?() }
    @objc private func copyPressed() { onCopy?() }
    @objc private func pastePressed() { onPaste?() }
}
