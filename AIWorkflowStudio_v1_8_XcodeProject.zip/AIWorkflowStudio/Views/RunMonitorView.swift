import SwiftUI

struct RunMonitorView: View {
    @EnvironmentObject private var store: AppStore

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    if let run = activeRun {
                        runHeader(run)
                        nodeTimeline(run)
                        logs(run)
                    } else {
                        ContentUnavailableView("当前工作流暂无运行记录", systemImage: "play.slash", description: Text("切换工作流后这里只显示当前工作流自己的记录。"))
                    }
                }
                .padding()
            }
            .studioBackground()
            .navigationTitle("运行监控")
            .toolbar {
                Button("运行当前项目") { store.startSelectedProjectRun() }
                Button(role: .destructive) { store.stopActiveRun() } label: { Label("停止", systemImage: "stop.fill") }
            }
        }
    }

    private var activeRun: RunRecord? {
        store.selectedProjectActiveRun
    }

    private func runHeader(_ run: RunRecord) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(run.projectTitle).font(.title2.bold())
            FlowingStatusBar(progress: run.progress)
            HStack {
                Label(run.status.title, systemImage: "circle.fill")
                Spacer()
                Text("Token \(run.tokenUsage.total)")
            }
            .font(.caption)
            .foregroundStyle(.secondary)

            VStack(alignment: .leading, spacing: 6) {
                Text("当前阶段：\(run.currentStage)")
                    .font(.headline)
                if let current = run.currentNodeTitle {
                    Text("当前模块：\(current)")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                Text(run.diagnosticMessage.isEmpty ? "暂无诊断信息。" : run.diagnosticMessage)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .textSelection(.enabled)
                Text("最后日志：\(run.lastLogAt.formatted(date: .omitted, time: .standard))")
                    .font(.caption2)
                    .foregroundStyle(.secondary)
            }
            .padding()
            .background(.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
        }
        .liquidGlass()
    }

    private func nodeTimeline(_ run: RunRecord) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("模块状态").font(.headline)
            if run.nodeRecords.isEmpty {
                Text("运行已创建，但还没有模块开始执行。通常是刚启动、提示词为空被拦截，或等待 API 响应。")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            ForEach(run.nodeRecords) { node in
                VStack(alignment: .leading, spacing: 8) {
                    HStack(alignment: .top) {
                        Image(systemName: node.kind.icon)
                        VStack(alignment: .leading) {
                            Text(node.nodeTitle).font(.headline)
                            Text("\(node.status.title) · Token \(node.tokenUsage.total) · \(node.modelID ?? "本地/未配置")")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                            if let error = node.errorMessage { Text(error).font(.caption).foregroundStyle(.red).textSelection(.enabled) }
                        }
                        Spacer()
                    }
                    DisclosureGroup("查看这个模块的输入") {
                        Text(node.inputPreview.isEmpty ? "无输入记录" : node.inputPreview)
                            .font(.system(.caption, design: .monospaced))
                            .textSelection(.enabled)
                            .frame(maxWidth: .infinity, alignment: .leading)
                    }
                }
                .padding()
                .background(.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
            }
        }
        .liquidGlass()
    }

    private func logs(_ run: RunRecord) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text("运行日志").font(.headline)
                Spacer()
                ShareLink("导出 Markdown", item: LogExportService.markdown(for: run))
                ShareLink("导出 ZIP", item: ZipArchiveService.shareableRunArchive(for: run))
            }
            if run.logs.isEmpty {
                Text("暂无日志。如果进度条不动，这里会显示最后卡住的模块和诊断信息。")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            ForEach(run.logs) { log in
                Text("\(log.level.symbol) \(log.nodeTitle.map { "[\($0)] " } ?? "")\(log.message)")
                    .font(.caption)
                    .textSelection(.enabled)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
        }
        .liquidGlass()
    }
}
