import Foundation

enum WorkflowAutoBuilder {
    static func aiPlannerPrompt(for project: WorkflowProject) -> String {
        """
        根据下面的用户需求，选择 AI Workflow Studio 应该创建的模块。

        只输出 JSON，格式：
        {"modules":["planner","worker","qualityReviewer","aggregator","output"]}

        可选模块：
        planner, dispatcher, worker, custom, codeWorker, codeReviewer, imageUnderstanding, imageGenerator, multiModelVote, qualityReviewer, visualReviewer, aggregator, formatter, filePackager, humanApproval, logger, versionSnapshot, output

        规则：
        - 必须保留 start 和 output，但 JSON 里可以不写 start。
        - 代码/App/网页/Xcode 任务必须包含 codeWorker 和 codeReviewer。
        - 图片/截图/OCR/图表任务必须包含 imageUnderstanding。
        - 检查者不合格时会通过“不合格出口”打回工作者，不需要 autoFixer。
        - 普通写作总结至少包含 planner、worker、qualityReviewer、aggregator、output。
        - 复杂任务可以加入 dispatcher、multiModelVote、logger、versionSnapshot、filePackager。

        用户需求：
        \(project.userPrompt)
        """
    }

    static func parseKinds(from text: String) -> [WorkflowNodeKind]? {
        let lower = text.lowercased()
        let mapping: [(String, WorkflowNodeKind)] = [
            ("imageunderstanding", .imageUnderstanding), ("image_understanding", .imageUnderstanding), ("图片理解", .imageUnderstanding),
            ("planner", .planner), ("计划", .planner),
            ("dispatcher", .dispatcher), ("任务分配", .dispatcher),
            ("codeworker", .codeWorker), ("code_worker", .codeWorker), ("代码工作", .codeWorker),
            ("codereviewer", .codeReviewer), ("code_reviewer", .codeReviewer), ("代码检查", .codeReviewer),
            ("worker", .worker), ("通用工作", .worker),
            ("imagegenerator", .imageGenerator), ("image_generator", .imageGenerator), ("图片生成", .imageGenerator),
            ("visualreviewer", .visualReviewer), ("visual_reviewer", .visualReviewer), ("视觉检查", .visualReviewer),
            ("multimodelvote", .multiModelVote), ("multi_model_vote", .multiModelVote), ("多模型", .multiModelVote),
            ("qualityreviewer", .qualityReviewer), ("quality_reviewer", .qualityReviewer), ("质量", .qualityReviewer),
            ("aggregator", .aggregator), ("汇总", .aggregator),
            ("formatter", .formatter), ("格式", .formatter),
            ("filepackager", .filePackager), ("file_packager", .filePackager), ("打包", .filePackager),
            ("humanapproval", .humanApproval), ("human_approval", .humanApproval), ("人工", .humanApproval),
            ("logger", .logger), ("日志", .logger),
            ("versionsnapshot", .versionSnapshot), ("version_snapshot", .versionSnapshot), ("版本", .versionSnapshot),
            ("output", .output), ("输出", .output),
            ("custom", .custom), ("自定义", .custom)
        ]
        var result: [WorkflowNodeKind] = []
        for (token, kind) in mapping where lower.contains(token.lowercased()) {
            if !result.contains(kind) { result.append(kind) }
        }
        result.removeAll { $0 == .autoFixer || $0 == .autoGraph || $0 == .start }
        return result.isEmpty ? nil : result
    }

    static func build(from project: WorkflowProject, preferredKinds: [WorkflowNodeKind]? = nil) -> WorkflowProject {
        var newProject = project
        let lower = project.userPrompt.lowercased()
        let hasImage = !project.resources.filter { $0.kind == .image }.isEmpty || lower.contains("图片") || lower.contains("截图") || lower.contains("image") || lower.contains("ocr") || lower.contains("图表")
        let isCode = lower.contains("代码") || lower.contains("app") || lower.contains("xcode") || lower.contains("swift") || lower.contains("python") || lower.contains("javascript") || lower.contains("网页") || lower.contains("项目")
        let wantsImageGeneration = lower.contains("生成图片") || lower.contains("图标") || lower.contains("插图") || lower.contains("image generation")
        let complex = lower.count > 120 || lower.contains("复杂") || lower.contains("多模型") || lower.contains("投票") || lower.contains("工作流")

        var kinds: [WorkflowNodeKind]
        if let preferredKinds, !preferredKinds.isEmpty {
            kinds = [.start] + preferredKinds
            if !kinds.contains(.output) { kinds.append(.output) }
        } else {
            kinds = [.start]
            if hasImage { kinds.append(.imageUnderstanding) }
            kinds.append(.planner)
            if complex { kinds.append(.dispatcher) }
            if isCode {
                kinds += [.codeWorker, .codeReviewer]
            } else {
                kinds += [.worker, .qualityReviewer]
            }
            if wantsImageGeneration { kinds += [.imageGenerator, .visualReviewer] }
            if complex { kinds += [.multiModelVote] }
            kinds += [.aggregator, .logger, .versionSnapshot, .output]
        }

        if hasImage && !kinds.contains(.imageUnderstanding) { kinds.insert(.imageUnderstanding, after: .start) }
        if isCode {
            if !kinds.contains(.codeWorker) { kinds.insert(.codeWorker, before: .output) }
            if !kinds.contains(.codeReviewer) { kinds.insert(.codeReviewer, before: .output) }
        }
        kinds.removeAll { $0 == .autoFixer || $0 == .autoGraph }

        var seen = Set<WorkflowNodeKind>()
        kinds = kinds.filter { seen.insert($0).inserted }
        if !kinds.contains(.start) { kinds.insert(.start, at: 0) }
        if !kinds.contains(.output) { kinds.append(.output) }

        var nodesByKind: [WorkflowNodeKind: WorkflowNode] = [:]
        var nodes: [WorkflowNode] = []
        for (index, kind) in kinds.enumerated() {
            var node = WorkflowNode(kind: kind, title: kind.title, x: 180 + Double(index % 4) * 280, y: 190 + Double(index / 4) * 210)
            node.prompt = kind == .custom ? "" : kind.defaultPrompt
            node.maxReturnCount = 0
            node.retryLimit = 0
            node.temperature = kind.isReviewer ? 0.1 : 0.3
            nodes.append(node)
            nodesByKind[kind] = node
        }

        func edge(_ from: WorkflowNodeKind, _ to: WorkflowNodeKind, _ condition: EdgeCondition = .always) -> WorkflowEdge? {
            guard let source = nodesByKind[from], let target = nodesByKind[to] else { return nil }
            return WorkflowEdge(from: source.id, to: target.id, condition: condition)
        }

        var edges: [WorkflowEdge] = []
        if hasImage, nodesByKind[.imageUnderstanding] != nil {
            if let e = edge(.start, .imageUnderstanding) { edges.append(e) }
            if let e = edge(.imageUnderstanding, .planner) { edges.append(e) }
        } else if let e = edge(.start, .planner) {
            edges.append(e)
        } else if let firstAfterStart = nodes.dropFirst().first, let start = nodesByKind[.start] {
            edges.append(WorkflowEdge(from: start.id, to: firstAfterStart.id, condition: .always))
        }

        if nodesByKind[.dispatcher] != nil {
            if let e = edge(.planner, .dispatcher) { edges.append(e) }
            if isCode, let e = edge(.dispatcher, .codeWorker) { edges.append(e) }
            if !isCode, let e = edge(.dispatcher, .worker) { edges.append(e) }
            if wantsImageGeneration, let e = edge(.dispatcher, .imageGenerator) { edges.append(e) }
        } else {
            if isCode, let e = edge(.planner, .codeWorker) { edges.append(e) }
            if !isCode, let e = edge(.planner, .worker) { edges.append(e) }
            if wantsImageGeneration, let e = edge(.planner, .imageGenerator) { edges.append(e) }
        }

        if isCode {
            if let e = edge(.codeWorker, .codeReviewer) { edges.append(e) }
            if let e = edge(.codeReviewer, .codeWorker, .failed) { edges.append(e) }
            if let e = edge(.codeReviewer, .aggregator, .passed) { edges.append(e) }
        } else {
            if let e = edge(.worker, .qualityReviewer) { edges.append(e) }
            if let e = edge(.qualityReviewer, .worker, .failed) { edges.append(e) }
            if let e = edge(.qualityReviewer, .aggregator, .passed) { edges.append(e) }
        }

        if wantsImageGeneration {
            if let e = edge(.imageGenerator, .visualReviewer) { edges.append(e) }
            if let e = edge(.visualReviewer, .imageGenerator, .failed) { edges.append(e) }
            if let e = edge(.visualReviewer, .aggregator, .passed) { edges.append(e) }
        }

        if let e = edge(.aggregator, .multiModelVote) { edges.append(e) }
        if nodesByKind[.multiModelVote] != nil {
            if let e = edge(.multiModelVote, .formatter) { edges.append(e) }
            if let e = edge(.multiModelVote, .logger) { edges.append(e) }
        }
        if let e = edge(.aggregator, .formatter) { edges.append(e) }
        if let e = edge(.formatter, .filePackager) { edges.append(e) }
        if let e = edge(.filePackager, .logger) { edges.append(e) }
        if let e = edge(.aggregator, .logger) { edges.append(e) }
        if let e = edge(.logger, .versionSnapshot) { edges.append(e) }
        if let e = edge(.versionSnapshot, .output) { edges.append(e) }
        if nodesByKind[.versionSnapshot] == nil, let e = edge(.logger, .output) { edges.append(e) }
        if nodesByKind[.logger] == nil, let e = edge(.aggregator, .output) { edges.append(e) }

        newProject.nodes = nodes
        newProject.edges = deduplicated(edges)
        newProject.autoSelectModules = false
        newProject.updatedAt = Date()
        return newProject
    }

    private static func deduplicated(_ edges: [WorkflowEdge]) -> [WorkflowEdge] {
        var seen = Set<String>()
        return edges.filter { edge in
            let key = "\(edge.from.uuidString)-\(edge.to.uuidString)-\(edge.condition.rawValue)"
            return seen.insert(key).inserted
        }
    }
}

private extension Array where Element == WorkflowNodeKind {
    mutating func insert(_ newElement: WorkflowNodeKind, after marker: WorkflowNodeKind) {
        if let index = firstIndex(of: marker) { insert(newElement, at: self.index(after: index)) } else { append(newElement) }
    }

    mutating func insert(_ newElement: WorkflowNodeKind, before marker: WorkflowNodeKind) {
        if let index = firstIndex(of: marker) { insert(newElement, at: index) } else { append(newElement) }
    }
}
