# LiquidAIBrowser v1.3.1 Project Index

## Main deliverable
- `LiquidAIBrowser.xcodeproj` — Xcode project.
- `LiquidAIBrowser/` — SwiftUI + WKWebView source.

## Important source files
- `LiquidAIBrowserApp.swift` — app entry.
- `BrowserStore.swift` — tabs, tasks, settings, WebViewPool, AgentEngine state.
- `BrowserModels.swift` — task, log, action, setting models.
- `WebViewPool.swift` — WKWebView pool, JS bridge, DOM scan, coordinate/gesture actions, screenshots.
- `AgentEngine.swift` — Agent planning/execution loop, confirmation, reports.
- `AIClient.swift` — OpenAI-compatible chat/models calls.
- `AISettings.swift` — API settings + Keychain.
- `Panels.swift` — tasks/settings UI.
- `PDFReportExporter.swift` — PDF report export.
- `LiquidGlassSupport.swift` — Liquid Glass/fallback helpers.

## QA / review documents
- `README.md` — build/use guide.
- `CHANGELOG.md` — version history.
- `QA_CHECK_REPORT.md` — project QA report.
- `QA_FIX_REPORT.md` — prior fixes.
- `QA_V13_FIX_REPORT.md` — v1.3 feature/fix report.
- `QA_V13_1_BUILD_FIX_REPORT.md` — build diagnostics fixes.
- `AI_REVIEW_REQUIREMENTS.md` — requirements and acceptance checklist.

## Current status
v1.3.1 fixes compile errors reported by `Build-Diagnostics-20-1.zip`. Requires another Xcode/IPA builder run for final confirmation.
