import SwiftUI
import UIKit

struct ContentView: View {
    @StateObject private var manager = DownloadManager()
    @State private var showShareSheet = false
    @State private var showReportSheet = false

    var body: some View {
        NavigationStack {
            Form {
                Section("下载链接") {
                    TextField("https://example.com/file.zip", text: $manager.urlText, axis: .vertical)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .keyboardType(.URL)
                        .lineLimit(2...4)

                    Stepper(value: $manager.connectionCount, in: 1...32) {
                        HStack {
                            Text("并发连接数")
                            Spacer()
                            Text("\(manager.connectionCount)")
                                .foregroundStyle(.secondary)
                        }
                    }

                    Picker("快速预设", selection: $manager.connectionCount) {
                        Text("保守 4").tag(4)
                        Text("推荐 8").tag(8)
                        Text("高速 16").tag(16)
                        Text("极限 32").tag(32)
                    }
                    .pickerStyle(.segmented)
                }

                Section("实时下载状态") {
                    VStack(alignment: .leading, spacing: 12) {
                        HStack(alignment: .firstTextBaseline) {
                            Text(manager.statusText)
                                .font(.headline)
                            Spacer()
                            Text(manager.progressText)
                                .font(.headline)
                                .monospacedDigit()
                        }

                        ProgressView(value: manager.progress)

                        HStack {
                            Text(manager.sizeText)
                            Spacer()
                            Text(manager.speedText)
                        }
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                    }
                    .padding(.vertical, 4)

                    LabeledContent("当前速度", value: manager.speedText.isEmpty ? "—" : manager.speedText.replacingOccurrences(of: "当前 ", with: ""))
                    LabeledContent("平均速度", value: manager.averageSpeedText.replacingOccurrences(of: "平均 ", with: ""))
                    LabeledContent("峰值速度", value: manager.peakSpeedText.replacingOccurrences(of: "峰值 ", with: ""))
                    LabeledContent("已用时间", value: manager.elapsedText)
                    LabeledContent("预计剩余", value: manager.etaText)
                    LabeledContent("连接状态", value: manager.connectionSummaryText)
                    LabeledContent("Range 支持", value: manager.supportsRanges ? "支持" : "未确认 / 不支持")
                }

                if !manager.segments.isEmpty {
                    Section("分段进度") {
                        ForEach(manager.segments) { segment in
                            VStack(alignment: .leading, spacing: 6) {
                                HStack {
                                    Text("分段 \(segment.index + 1)")
                                    Spacer()
                                    Text("\(Int(segment.progress * 100))%")
                                        .monospacedDigit()
                                        .foregroundStyle(.secondary)
                                }
                                ProgressView(value: segment.progress)
                                HStack {
                                    Text("\(ByteFormatter.string(from: segment.downloadedBytes)) / \(ByteFormatter.string(from: segment.totalBytes))")
                                    Spacer()
                                    Text("平均 \(ByteFormatter.string(from: Int64(segment.speedBytesPerSecond)))/s")
                                }
                                .font(.caption)
                                .foregroundStyle(.secondary)
                            }
                            .padding(.vertical, 4)
                        }
                    }
                }

                Section("操作") {
                    Button {
                        manager.startDownload()
                    } label: {
                        Label("开始多线程下载", systemImage: "arrow.down.circle.fill")
                    }
                    .disabled(manager.isDownloading)

                    Button(role: .destructive) {
                        manager.cancelDownload()
                    } label: {
                        Label("取消下载", systemImage: "xmark.circle")
                    }
                    .disabled(!manager.isDownloading)

                    if manager.completedFile != nil {
                        Button {
                            showReportSheet = true
                        } label: {
                            Label("查看下载报告", systemImage: "doc.text.magnifyingglass")
                        }

                        Button {
                            showShareSheet = true
                        } label: {
                            Label("保存 / 分享文件和报告", systemImage: "square.and.arrow.up")
                        }
                    }
                }

                if !manager.reportText.isEmpty {
                    Section("下载完成报告预览") {
                        Text(manager.reportText)
                            .font(.footnote.monospaced())
                            .textSelection(.enabled)
                    }
                }

                Section("说明") {
                    Text("支持 Range 的服务器会自动分段并发下载；不支持 Range 或无法获取大小时，会自动退回普通单连接下载，并继续显示实时速度和已下载大小。")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
            }
            .navigationTitle("多线程下载器")
            .sheet(isPresented: $showShareSheet) {
                ActivityView(activityItems: manager.shareItems)
            }
            .sheet(isPresented: $showReportSheet) {
                NavigationStack {
                    ScrollView {
                        Text(manager.reportText.isEmpty ? "暂无报告" : manager.reportText)
                            .font(.body.monospaced())
                            .textSelection(.enabled)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding()
                    }
                    .navigationTitle("下载报告")
                    .toolbar {
                        ToolbarItem(placement: .navigationBarTrailing) {
                            Button("完成") {
                                showReportSheet = false
                            }
                        }
                    }
                }
            }
        }
    }
}

struct ActivityView: UIViewControllerRepresentable {
    let activityItems: [Any]

    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: activityItems, applicationActivities: nil)
    }

    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) { }
}
