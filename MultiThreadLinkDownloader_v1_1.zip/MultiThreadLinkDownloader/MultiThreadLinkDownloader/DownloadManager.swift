import Foundation
import SwiftUI

struct CompletedDownload: Identifiable {
    let id = UUID()
    let url: URL
    let reportURL: URL?
}

struct DownloadReport: Identifiable, Sendable {
    let id = UUID()
    let sourceURL: URL
    let fileName: String
    let fileURL: URL
    let fileSize: Int64
    let startedAt: Date
    let endedAt: Date
    let durationSeconds: TimeInterval
    let averageSpeedBytesPerSecond: Double
    let peakSpeedBytesPerSecond: Double
    let requestedConnections: Int
    let actualConnections: Int
    let supportsRanges: Bool
    let usedMultiThreading: Bool
    let segmentCount: Int

    init(result: DownloadResult) {
        self.sourceURL = result.sourceURL
        self.fileName = result.fileName
        self.fileURL = result.fileURL
        self.fileSize = result.fileSize
        self.startedAt = result.startedAt
        self.endedAt = result.endedAt
        self.durationSeconds = result.durationSeconds
        self.averageSpeedBytesPerSecond = result.averageSpeedBytesPerSecond
        self.peakSpeedBytesPerSecond = result.peakSpeedBytesPerSecond
        self.requestedConnections = result.requestedConnections
        self.actualConnections = result.actualConnections
        self.supportsRanges = result.supportsRanges
        self.usedMultiThreading = result.usedMultiThreading
        self.segmentCount = result.segmentCount
    }

    var text: String {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.timeStyle = .medium

        return """
        下载完成报告

        文件名：\(fileName)
        来源链接：\(sourceURL.absoluteString)
        保存位置：\(fileURL.path)

        文件大小：\(ByteFormatter.string(from: fileSize))
        开始时间：\(formatter.string(from: startedAt))
        完成时间：\(formatter.string(from: endedAt))
        总耗时：\(TimeFormatter.string(from: durationSeconds))

        请求并发连接：\(requestedConnections)
        实际连接/分段：\(actualConnections)
        服务器支持 Range：\(supportsRanges ? "是" : "否")
        是否使用多线程：\(usedMultiThreading ? "是" : "否")
        分段数量：\(segmentCount)

        平均速度：\(ByteFormatter.string(from: Int64(averageSpeedBytesPerSecond)))/s
        峰值速度：\(ByteFormatter.string(from: Int64(peakSpeedBytesPerSecond)))/s
        """
    }
}

@MainActor
final class DownloadManager: ObservableObject {
    @Published var urlText = ""
    @Published var connectionCount = 8
    @Published var isDownloading = false
    @Published var statusText = "等待输入链接"
    @Published var progress: Double = 0
    @Published var downloadedBytes: Int64 = 0
    @Published var totalBytes: Int64 = 0
    @Published var currentSpeedBytesPerSecond: Double = 0
    @Published var averageSpeedBytesPerSecond: Double = 0
    @Published var peakSpeedBytesPerSecond: Double = 0
    @Published var elapsedSeconds: TimeInterval = 0
    @Published var estimatedRemainingSeconds: TimeInterval?
    @Published var requestedConnections = 0
    @Published var actualConnections = 0
    @Published var supportsRanges = false
    @Published var isMultiThreaded = false
    @Published var segments: [SegmentProgress] = []
    @Published var completedFile: CompletedDownload?
    @Published var latestReport: DownloadReport?
    @Published var reportText = ""

    private var task: Task<Void, Never>?

    var progressText: String {
        guard totalBytes > 0 else { return downloadedBytes > 0 ? "已下载 \(ByteFormatter.string(from: downloadedBytes))" : "0%" }
        return String(format: "%.1f%%", progress * 100)
    }

    var sizeText: String {
        if totalBytes <= 0 {
            return ByteFormatter.string(from: downloadedBytes)
        }
        return "\(ByteFormatter.string(from: downloadedBytes)) / \(ByteFormatter.string(from: totalBytes))"
    }

    var speedText: String {
        guard isDownloading else { return latestReport == nil ? "" : "完成" }
        return "当前 \(ByteFormatter.string(from: Int64(currentSpeedBytesPerSecond)))/s"
    }

    var averageSpeedText: String {
        "平均 \(ByteFormatter.string(from: Int64(averageSpeedBytesPerSecond)))/s"
    }

    var peakSpeedText: String {
        "峰值 \(ByteFormatter.string(from: Int64(peakSpeedBytesPerSecond)))/s"
    }

    var elapsedText: String {
        TimeFormatter.string(from: elapsedSeconds)
    }

    var etaText: String {
        guard let estimatedRemainingSeconds else { return "未知" }
        return TimeFormatter.string(from: estimatedRemainingSeconds)
    }

    var connectionSummaryText: String {
        if actualConnections <= 0 { return "请求 \(connectionCount) 个连接" }
        return "请求 \(requestedConnections)｜实际 \(actualConnections)｜\(isMultiThreaded ? "多线程" : "单连接")"
    }

    var shareItems: [Any] {
        guard let completedFile else { return [] }
        if let reportURL = completedFile.reportURL {
            return [completedFile.url, reportURL]
        }
        return [completedFile.url]
    }

    func startDownload() {
        let trimmed = urlText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard let url = URL(string: trimmed), ["http", "https"].contains(url.scheme?.lowercased()) else {
            statusText = "链接格式不正确"
            return
        }

        task?.cancel()
        completedFile = nil
        latestReport = nil
        reportText = ""
        isDownloading = true
        statusText = "准备下载"
        progress = 0
        downloadedBytes = 0
        totalBytes = 0
        currentSpeedBytesPerSecond = 0
        averageSpeedBytesPerSecond = 0
        peakSpeedBytesPerSecond = 0
        elapsedSeconds = 0
        estimatedRemainingSeconds = nil
        requestedConnections = max(1, min(connectionCount, 32))
        actualConnections = 0
        supportsRanges = false
        isMultiThreaded = false
        segments = []

        let safeConnections = max(1, min(connectionCount, 32))

        task = Task.detached(priority: .userInitiated) { [safeConnections] in
            do {
                let outputDirectory = try FileManager.default.url(
                    for: .documentDirectory,
                    in: .userDomainMask,
                    appropriateFor: nil,
                    create: true
                )

                let config = DownloadConfig(
                    url: url,
                    connections: safeConnections,
                    sliceBytes: 4 * 1024 * 1024,
                    outputDirectory: outputDirectory
                )

                let result = try await ThreadedRangeDownloader.download(config: config) { update in
                    await MainActor.run {
                        self.apply(update)
                    }
                }

                let report = DownloadReport(result: result)
                let reportURL = try Self.writeReport(report, nextTo: result.fileURL)

                await MainActor.run {
                    self.isDownloading = false
                    self.statusText = "下载完成"
                    self.progress = 1
                    self.downloadedBytes = result.fileSize
                    self.totalBytes = max(self.totalBytes, result.fileSize)
                    self.averageSpeedBytesPerSecond = result.averageSpeedBytesPerSecond
                    self.peakSpeedBytesPerSecond = result.peakSpeedBytesPerSecond
                    self.elapsedSeconds = result.durationSeconds
                    self.estimatedRemainingSeconds = 0
                    self.requestedConnections = result.requestedConnections
                    self.actualConnections = result.actualConnections
                    self.supportsRanges = result.supportsRanges
                    self.isMultiThreaded = result.usedMultiThreading
                    self.completedFile = CompletedDownload(url: result.fileURL, reportURL: reportURL)
                    self.latestReport = report
                    self.reportText = report.text
                }
            } catch is CancellationError {
                await MainActor.run {
                    self.isDownloading = false
                    self.statusText = "已取消"
                }
            } catch {
                await MainActor.run {
                    self.isDownloading = false
                    self.statusText = "失败：\(error.localizedDescription)"
                }
            }
        }
    }

    func cancelDownload() {
        task?.cancel()
        task = nil
        isDownloading = false
        statusText = "正在取消"
    }

    private func apply(_ update: DownloadUpdate) {
        statusText = update.phase
        downloadedBytes = update.downloadedBytes
        totalBytes = update.totalBytes
        currentSpeedBytesPerSecond = update.currentSpeedBytesPerSecond
        averageSpeedBytesPerSecond = update.averageSpeedBytesPerSecond
        peakSpeedBytesPerSecond = update.peakSpeedBytesPerSecond
        elapsedSeconds = update.elapsedSeconds
        estimatedRemainingSeconds = update.estimatedRemainingSeconds
        requestedConnections = update.requestedConnections
        actualConnections = update.actualConnections
        supportsRanges = update.supportsRanges
        isMultiThreaded = update.isMultiThreaded
        segments = update.segments
        progress = update.totalBytes > 0 ? min(1, max(0, Double(update.downloadedBytes) / Double(update.totalBytes))) : 0
    }

    private nonisolated static func writeReport(_ report: DownloadReport, nextTo fileURL: URL) throws -> URL {
        let reportName = "\((report.fileName as NSString).deletingPathExtension)-download-report.txt"
        let reportURL = fileURL.deletingLastPathComponent().appendingPathComponent(reportName)
        try report.text.write(to: reportURL, atomically: true, encoding: .utf8)
        return reportURL
    }
}

enum ByteFormatter {
    static func string(from bytes: Int64) -> String {
        let units = ["B", "KB", "MB", "GB", "TB"]
        var value = Double(max(bytes, 0))
        var index = 0
        while value >= 1024, index < units.count - 1 {
            value /= 1024
            index += 1
        }
        if index == 0 { return "\(Int(value)) B" }
        return String(format: "%.2f %@", value, units[index])
    }
}

enum TimeFormatter {
    static func string(from seconds: TimeInterval) -> String {
        guard seconds.isFinite, seconds >= 0 else { return "未知" }
        let total = Int(seconds.rounded())
        let hours = total / 3600
        let minutes = (total % 3600) / 60
        let secs = total % 60
        if hours > 0 {
            return String(format: "%d:%02d:%02d", hours, minutes, secs)
        }
        return String(format: "%d:%02d", minutes, secs)
    }
}
