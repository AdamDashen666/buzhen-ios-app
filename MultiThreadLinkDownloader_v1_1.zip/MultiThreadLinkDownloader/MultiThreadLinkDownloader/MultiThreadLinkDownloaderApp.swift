import SwiftUI

@main
struct MultiThreadLinkDownloaderApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
