import Foundation

enum WorkflowEngineError: Error, LocalizedError {
    case emptyPrompt
    case noStartNode
    case cancelled
    case safetyLimitReached
    case dependencyDeadlock(String)
    case apiTimeout(String)
    case missingModelConfiguration(String)

    var errorDescription: String? {
        switch self {
        case .emptyPrompt: return "开始模块提示词为空。"
        case .noStartNode: return "工作流缺少开始模块。"
        case .cancelled: return "运行已被停止。"
        case .safetyLimitReached: return "已达到用户设置的最大返工次数。"
        case .dependencyDeadlock(let message): return message
        case .apiTimeout(let message): return message
        case .missingModelConfiguration(let message): return message
        }
    }
}

final class WorkflowEngine {
    private struct ParallelNodeResult {
        var node: WorkflowNode
        var inputContext: String
        var response: AITextResponse?
        var error: Error?
    }

    func run(runID: UUID = UUID(), project: WorkflowProject, apiConfigs: [APIProviderConfig], settings: AppSettings, aiClient: AIClient, onUpdate: @escaping @MainActor (RunRecord) -> Void) async throws -> RunRecord {
        guard !project.userPrompt.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { throw WorkflowEngineError.emptyPrompt }
        guard let start = project.nodes.first(where: { $0.kind == .start }) else { throw WorkflowEngineError.noStartNode }

        var record = RunRecord(projectID: project.id, projectTitle: project.title)
        record.id = runID
        var contextByNode: [UUID: String] = [:]
        // 节点可能被检查者打回重复执行。旧输出不能被下游当成“最新完成结果”使用，
        // 否则会出现：某个检查者还在运行，但日志/汇总/输出等后续模块已经开始。
        // dirtyNodeIDs 表示该节点及其下游输出已过期，必须等重新执行完成后才能作为依赖。
        var dirtyNodeIDs = Set<UUID>()
        // v7.6: 记录“本轮真实触发过”的连线。多上游节点不能只看上游是否有旧输出，
        // 必须等每一条输入边都由对应上游完成后触发，才能开始运行。
        var activatedEdgeIDs = Set<UUID>()
        var runningNodeIDs = Set<UUID>()
        var queue: [UUID] = [start.id]
        var visitCounts: [UUID: Int] = [:]
        var returnCounts: [UUID: Int] = [:]
        var waitCounts: [UUID: Int] = [:]
        var waitStartDates: [UUID: Date] = [:]
        var executed = 0
        let safetyLimit = max(project.nodes.count * 30, 120)

        func configuredReturnLimit(for nodeID: UUID) -> Int {
            guard let node = project.nodes.first(where: { $0.id == nodeID }) else { return 0 }
            // 0 表示无限返工；只有用户在模块/设置里显式设置了 > 0，才允许自动停止。
            let limits = [node.maxReturnCount, node.retryLimit].filter { $0 > 0 }
            return limits.min() ?? 0
        }

        func markDirtyCascade(from rootID: UUID) {
            var stack = [rootID]
            var seen = Set<UUID>()
            while let id = stack.popLast() {
                guard seen.insert(id).inserted else { continue }
                dirtyNodeIDs.insert(id)

                // 只沿“前进线”扩散 dirty。失败/低分返工线是回路；如果也跟着扩散，
                // worker 刚准备给 reviewer 新输出，reviewer 的返工线又会把 worker 标成 dirty，
                // 最终造成两个并行代码检查者一直等待/来回跳。
                let forwardDownstream = project.edges
                    .filter { $0.from == id && $0.condition != .failed && $0.condition != .scoreLow }
                    .map(\.to)
                stack.append(contentsOf: forwardDownstream)
            }

            // v7.6：dirty 节点相关连线必须一起失效。
            // 否则汇总者可能看到某条 passed 边以前触发过，就在其它并行上游还没重跑完时提前开始。
            let invalidatedNodeIDs = seen
            let invalidatedEdgeIDs = project.edges
                // 只失效 dirty 节点自己的输出边；不要失效指向 dirty 节点的输入边。
                // 多上游汇总节点需要累计每一条输入边的触发状态，否则一个上游完成会把其它已完成上游清掉。
                .filter { invalidatedNodeIDs.contains($0.from) }
                .map(\.id)
            activatedEdgeIDs.subtract(invalidatedEdgeIDs)
        }

        func appendQueue(_ id: UUID, into targetQueue: inout [UUID]) {
            if !targetQueue.contains(id) { targetQueue.append(id) }
        }

        func deduplicated(_ ids: [UUID]) -> [UUID] {
            var seen = Set<UUID>()
            return ids.filter { seen.insert($0).inserted }
        }

        func syncDependencyState(waitingIDs: [UUID] = []) {
            record.currentNodeIDs = Array(runningNodeIDs)
            let waiting = deduplicated(waitingIDs.filter { !runningNodeIDs.contains($0) })
            record.waitingNodeIDs = waiting.isEmpty ? nil : waiting
            // dirty 节点表示“旧输出已失效，必须等上游返工完成后重新执行”。
            // UI 里不再显示成“待返工”紫色状态，而是作为等待上游/预备重跑处理，
            // 防止下游在上游还没完成时看起来像已经开始返工。
            let stale = Array(dirtyNodeIDs.subtracting(runningNodeIDs))
            record.staleNodeIDs = stale.isEmpty ? nil : stale
        }

        appendLog(&record, .info, nil, "开始运行工作流：\(project.title)")
        record.currentNodeIDs = [start.id]
        record.waitingNodeIDs = nil
        record.staleNodeIDs = nil
        record.currentStage = "准备并行调度"
        record.diagnosticMessage = "同一批满足上游条件的模块会并行运行；失败/不合格返工线不会作为首次启动依赖，只在检查者失败后触发返工。"
        await onUpdate(record)

        if let configurationError = missingModelConfigurationMessage(project: project, apiConfigs: apiConfigs, settings: settings) {
            appendLog(&record, .error, nil, configurationError)
            record.status = .failed
            record.endedAt = Date()
            record.currentNodeIDs = []
            record.currentStage = "模型配置缺失"
            record.diagnosticMessage = configurationError
            await onUpdate(record)
            throw WorkflowEngineError.missingModelConfiguration(configurationError)
        }

        while !queue.isEmpty {
            try Task.checkCancellation()

            let candidates = queue
            queue.removeAll()

            var readyNodes: [WorkflowNode] = []
            var stillWaiting: [UUID] = []
            var seenThisWave = Set<UUID>()

            for nodeID in candidates {
                guard !seenThisWave.contains(nodeID), let node = project.nodes.first(where: { $0.id == nodeID }) else { continue }
                seenThisWave.insert(nodeID)

                if node.kind != .start,
                   let blockedReason = blockedConditionalInputReason(for: node, project: project, contextByNode: contextByNode, dirtyNodeIDs: dirtyNodeIDs, runningNodeIDs: runningNodeIDs, pendingNodeIDs: Set(candidates).subtracting([nodeID])) {
                    appendLog(&record, .info, node.title, "条件分支未命中，已跳过本轮执行：\(blockedReason)")
                    var skippedRecord = NodeRunRecord(nodeID: node.id, nodeTitle: node.title, kind: node.kind, status: .skipped)
                    skippedRecord.output = "条件分支未命中：\(blockedReason)"
                    skippedRecord.endedAt = Date()
                    record.nodeRecords.append(skippedRecord)
                    continue
                }

                let missingInputs = missingRequiredInputTitles(
                    for: node,
                    project: project,
                    contextByNode: contextByNode,
                    dirtyNodeIDs: dirtyNodeIDs,
                    runningNodeIDs: runningNodeIDs,
                    pendingNodeIDs: Set(candidates).subtracting([nodeID]),
                    activatedEdgeIDs: activatedEdgeIDs
                )
                if node.kind != .start && !missingInputs.isEmpty {
                    waitCounts[nodeID, default: 0] += 1
                    waitStartDates[nodeID] = waitStartDates[nodeID] ?? Date()
                    stillWaiting.append(nodeID)
                    record.currentNodeTitle = node.title
                    syncDependencyState(waitingIDs: stillWaiting)
                    record.currentStage = "等待上游：\(node.title)"
                    let waitedSeconds = Int(Date().timeIntervalSince(waitStartDates[nodeID] ?? Date()))
                    record.diagnosticMessage = "正在等待上游完成：\(missingInputs.joined(separator: "、"))。等待上游时间不计入 \(node.title) 的模块/API 超时时间；该模块会显示为等待/预备，不会显示为运行中。"
                    if waitCounts[nodeID, default: 0] == 1 || waitCounts[nodeID, default: 0] % 10 == 0 {
                        appendLog(&record, .info, node.title, "等待上游：\(missingInputs.joined(separator: "、"))。已等待约 \(waitedSeconds) 秒；这段等待不计入模块/API timeout，模块计时只会在真正开始执行后启动。")
                    }
                    await onUpdate(record)
                    continue
                }

                if let started = waitStartDates[nodeID] {
                    let waitedSeconds = Int(Date().timeIntervalSince(started))
                    if waitedSeconds > 0 {
                        appendLog(&record, .info, node.title, "上游已齐，结束等待约 \(waitedSeconds) 秒；现在才开始计算 \(node.title) 的执行超时。")
                    }
                }
                waitStartDates[nodeID] = nil
                waitCounts[nodeID] = nil
                readyNodes.append(node)
            }

            if readyNodes.isEmpty {
                syncDependencyState(waitingIDs: stillWaiting)
                queue = stillWaiting
                if queue.isEmpty { break }

                // v6.7：这里已经没有正在执行的并行任务；如果仍然只剩等待节点，
                // 就不是“正常等待上游”，而是依赖死锁/未命中分支/坏连线。
                // 不能无限循环刷新 UI，看起来像进度消失或永远等待。
                if runningNodeIDs.isEmpty {
                    let waitingTitles = stillWaiting.compactMap { id in project.nodes.first(where: { $0.id == id })?.title }
                    let message = "没有可继续执行的模块，但仍有模块在等待上游：\(waitingTitles.joined(separator: "、"))。可能原因：条件分支未命中、返工线连错、某个上游模块没有被触发，或存在循环依赖。"
                    appendLog(&record, .error, nil, message)
                    record.status = .failed
                    record.endedAt = Date()
                    record.currentNodeIDs = []
                    record.waitingNodeIDs = stillWaiting
                    record.currentStage = "依赖等待死锁"
                    record.diagnosticMessage = message
                    await onUpdate(record)
                    throw WorkflowEngineError.dependencyDeadlock(message)
                }

                await onUpdate(record)
                try await Task.sleep(nanoseconds: 120_000_000)
                continue
            }

            if executed > safetyLimit, executed == safetyLimit + 1 || executed % safetyLimit == 0 {
                appendLog(&record, .warning, nil, "已超过默认循环参考值，但不会自动停止。只有目标模块设置了最大返工次数 > 0，系统才会因返工次数达到上限而退出；否则保持无限返工。")
                await onUpdate(record)
            }

            var fatalError: Error?
            var inputContexts: [UUID: String] = [:]

            func collectReadyNodes(from candidateIDs: [UUID]) -> [WorkflowNode] {
                var newlyReady: [WorkflowNode] = []
                var waitingAgain: [UUID] = []
                var seen = Set<UUID>()

                for nodeID in candidateIDs {
                    guard seen.insert(nodeID).inserted,
                          !runningNodeIDs.contains(nodeID),
                          let node = project.nodes.first(where: { $0.id == nodeID }) else { continue }

                    if node.kind != .start,
                       let blockedReason = blockedConditionalInputReason(for: node, project: project, contextByNode: contextByNode, dirtyNodeIDs: dirtyNodeIDs, runningNodeIDs: runningNodeIDs, pendingNodeIDs: Set(candidateIDs).subtracting([nodeID])) {
                        appendLog(&record, .info, node.title, "条件分支未命中，已跳过本轮执行：\(blockedReason)")
                        var skippedRecord = NodeRunRecord(nodeID: node.id, nodeTitle: node.title, kind: node.kind, status: .skipped)
                        skippedRecord.output = "条件分支未命中：\(blockedReason)"
                        skippedRecord.endedAt = Date()
                        record.nodeRecords.append(skippedRecord)
                        continue
                    }

                    let missingInputs = missingRequiredInputTitles(
                        for: node,
                        project: project,
                        contextByNode: contextByNode,
                        dirtyNodeIDs: dirtyNodeIDs,
                        runningNodeIDs: runningNodeIDs,
                        pendingNodeIDs: Set(candidateIDs).subtracting([nodeID]),
                        activatedEdgeIDs: activatedEdgeIDs
                    )
                    if node.kind != .start && !missingInputs.isEmpty {
                        waitCounts[nodeID, default: 0] += 1
                        waitStartDates[nodeID] = waitStartDates[nodeID] ?? Date()
                        waitingAgain.append(nodeID)
                        let waitedSeconds = Int(Date().timeIntervalSince(waitStartDates[nodeID] ?? Date()))
                        if waitCounts[nodeID, default: 0] == 1 || waitCounts[nodeID, default: 0] % 10 == 0 {
                            appendLog(&record, .info, node.title, "等待上游：\(missingInputs.joined(separator: "、"))。已等待约 \(waitedSeconds) 秒；这段等待不计入模块/API timeout，模块计时只会在真正开始执行后启动。")
                        }
                        continue
                    }

                    if let started = waitStartDates[nodeID] {
                        let waitedSeconds = Int(Date().timeIntervalSince(started))
                        if waitedSeconds > 0 {
                            appendLog(&record, .info, node.title, "上游已齐，结束等待约 \(waitedSeconds) 秒；现在才开始计算 \(node.title) 的执行超时。")
                        }
                    }
                    waitStartDates[nodeID] = nil
                    waitCounts[nodeID] = nil
                    newlyReady.append(node)
                }

                stillWaiting = deduplicated(waitingAgain)
                return newlyReady
            }

            func prepareNodesForExecution(_ nodes: [WorkflowNode], reason: String) {
                guard !nodes.isEmpty else { return }
                let titles = nodes.map(\.title).joined(separator: "、")
                runningNodeIDs.formUnion(nodes.map(\.id))
                syncDependencyState(waitingIDs: stillWaiting)
                record.currentNodeTitle = nodes.count == 1 ? nodes[0].title : "\(nodes.count) 个模块并行运行"
                record.currentStage = nodes.count == 1 ? "正在执行：\(nodes[0].title)" : "并行执行：\(titles)"
                record.diagnosticMessage = nodes.count == 1 ? "当前模块正在运行。" : "流水线调度：谁的直接上游全部满足，谁才启动；汇总者这类多输入节点会等待所有已连接上游最新结果。"
                appendLog(&record, .info, nil, nodes.count == 1 ? "启动模块：\(titles)（\(reason)）" : "并行启动模块：\(titles)（\(reason)）")

                for node in nodes {
                    visitCounts[node.id, default: 0] += 1
                    executed += 1
                    let inputContext = inputContextFor(node: node, project: project, contextByNode: contextByNode, activatedEdgeIDs: activatedEdgeIDs)
                    inputContexts[node.id] = inputContext
                    var nodeRecord = NodeRunRecord(nodeID: node.id, nodeTitle: node.title, kind: node.kind, status: .running)
                    nodeRecord.inputPreview = inputAuditPreview(for: node, inputContext: inputContext, project: project)
                    nodeRecord.returnCount = returnCounts[node.id] ?? 0
                    record.nodeRecords.append(nodeRecord)
                    let estimatedInputTokens = TokenEstimator.roughCount(inputContext)
                    let effectiveTimeoutForLog = effectiveTimeout(for: node, apiConfigs: apiConfigs, settings: settings)
                    appendLog(&record, .info, node.title, "开始执行模块。预计发送输入约 \(estimatedInputTokens) Token，字符 \(inputContext.count)。模块/API timeout 从现在开始计算：\(effectiveTimeoutForLog) 秒。")
                    if isThinkingModeEnabled(for: node, apiConfigs: apiConfigs, settings: settings) {
                        appendLog(&record, .info, node.title, "Thinking Mode 已启用：该模块使用加长超时，避免思考模型因为推理时间更久被过早停止。")
                    }
                    if node.kind.isReviewer {
                        appendLog(&record, .info, node.title, "检查者输入审计：已把已连接上游模块的完整输出放入请求体；输出详情里显示的是预览，不代表真实请求被截断。")
                    }
                    if node.kind == .dispatcher {
                        let targetCount = dispatchTargets(for: node, project: project).count
                        appendLog(&record, targetCount == 0 ? .warning : .info, node.title, targetCount == 0 ? "任务分配者没有检测到已连接工作者，请先从输出接口连接到工作者。" : "任务分配者已读取 \(targetCount) 个已连接下游工作者，并会按这些连接关系分配任务。")
                    }
                }
                record.progress = min(0.95, max(record.progress, (Double(executed) - 0.35) / Double(max(project.nodes.count, 1))))
            }

            prepareNodesForExecution(readyNodes, reason: "初始可运行")
            await onUpdate(record)

            func handleParallelResult(_ result: ParallelNodeResult) {
                let node = result.node
                runningNodeIDs.remove(node.id)
                syncDependencyState(waitingIDs: stillWaiting)

                if let error = result.error {
                    if let index = record.nodeRecords.lastIndex(where: { $0.nodeID == node.id && $0.status == .running }) {
                        record.nodeRecords[index].status = .failed
                        record.nodeRecords[index].endedAt = Date()
                        record.nodeRecords[index].errorMessage = error.localizedDescription
                    }
                    if error is CancellationError {
                        appendLog(&record, .warning, node.title, "运行被用户停止。")
                        record.status = .cancelled
                        record.endedAt = Date()
                        record.currentStage = "已停止"
                        record.diagnosticMessage = "用户点击停止运行。"
                        fatalError = error
                    } else {
                        appendLog(&record, .error, node.title, error.localizedDescription)
                        record.status = .failed
                        record.endedAt = Date()
                        record.currentStage = "失败：\(node.title)"
                        record.diagnosticMessage = error.localizedDescription
                        fatalError = error
                    }
                    return
                }

                guard let response = result.response else { return }
                var decision = reviewerDecision(node: node, output: response.text)
                var reviewerOverrideOutput: String?
                if node.kind.isReviewer, let localFeedback = localArtifactBlockingFeedback(for: node, project: project, inputContext: result.inputContext) {
                    decision = (false, localFeedback)
                    let escaped = localFeedback
                        .replacingOccurrences(of: "\\", with: "\\\\")
                        .replacingOccurrences(of: "\"", with: "\\\"")
                        .replacingOccurrences(of: "\n", with: "\\n")
                    reviewerOverrideOutput = "{\"passed\":false,\"severity\":\"blocking\",\"feedback\":\"\(escaped)\",\"blockingIssues\":[\"本地运行包完整性校验未通过\"]}"
                }
                let output = (node.kind.isReviewer && decision.passed == true)
                    ? reviewerPassThroughOutput(inputContext: result.inputContext)
                    : (reviewerOverrideOutput ?? response.text)
                contextByNode[node.id] = output
                dirtyNodeIDs.remove(node.id)
                syncDependencyState(waitingIDs: stillWaiting)
                record.output = latestCombinedOutput(project: project, contextByNode: contextByNode)
                record.tokenUsage = record.tokenUsage + response.tokenUsage

                if let index = record.nodeRecords.lastIndex(where: { $0.nodeID == node.id && $0.status == .running }) {
                    let reviewerPassed = node.kind.isReviewer ? (decision.passed ?? false) : true
                    record.nodeRecords[index].status = reviewerPassed ? .passed : .returned
                    record.nodeRecords[index].endedAt = Date()
                    record.nodeRecords[index].output = output
                    record.nodeRecords[index].tokenUsage = response.tokenUsage
                    let effectiveProvider = effectiveProviderID(for: node, settings: settings)
                    record.nodeRecords[index].providerName = effectiveProvider.flatMap { id in apiConfigs.first(where: { $0.id == id })?.name }
                    record.nodeRecords[index].modelID = effectiveModelID(for: node, settings: settings)
                }

                let passed = node.kind.isReviewer ? (decision.passed ?? false) : true
                appendLog(&record, passed ? .success : .warning, node.title, passed ? "模块完成，Token：\(response.tokenUsage.total)" : "模块完成但检查未通过，Token：\(response.tokenUsage.total)")
                if node.kind.isReviewer {
                    if passed {
                        appendLog(&record, .success, node.title, "检查通过：已清空修改建议，继续走通过出口。")
                    } else {
                        let feedback = decision.feedback?.trimmingCharacters(in: .whitespacesAndNewlines)
                        appendLog(&record, .warning, node.title, "检查未通过：走不合格出口。\(feedback?.isEmpty == false ? " 返工意见：\(feedback!)" : "")")
                    }
                }

                let next = nextEdges(from: node, passed: passed, project: project)
                if next.isEmpty && node.kind != .output {
                    appendLog(&record, .warning, node.title, "该模块没有后续连线，流程在这里结束。")
                }
                for edge in next {
                    if edge.condition == .failed || edge.condition == .scoreLow {
                        returnCounts[edge.to, default: 0] += 1
                        let count = returnCounts[edge.to, default: 0]
                        let userLimit = configuredReturnLimit(for: edge.to)
                        if userLimit > 0 {
                            appendLog(&record, .info, node.title, "返工次数：\(count)/\(userLimit)。该上限来自目标模块的最大返工次数设置。")
                            if count > userLimit {
                                appendLog(&record, .error, node.title, "已超过用户设置的最大返工次数 \(userLimit)，停止当前工作流。若需要无限返工，请把该模块最大返工次数设为 0。")
                                record.status = .failed
                                record.endedAt = Date()
                                record.currentStage = "达到返工次数上限"
                                record.diagnosticMessage = "已超过用户设置的最大返工次数 \(userLimit)。"
                                fatalError = WorkflowEngineError.safetyLimitReached
                                break
                            }
                        } else if count == 1 || count % 5 == 0 {
                            appendLog(&record, .info, node.title, "返工次数：\(count)。目标模块最大返工次数为 0，表示无限返工；系统不会自动退出。")
                        }
                    }
                    markDirtyCascade(from: edge.to)
                    activatedEdgeIDs.insert(edge.id)
                    syncDependencyState(waitingIDs: stillWaiting)
                    appendQueue(edge.to, into: &queue)
                }
            }

            await withTaskGroup(of: ParallelNodeResult.self) { group in
                func addTasks(_ nodes: [WorkflowNode]) {
                    for node in nodes {
                        let inputContext = inputContexts[node.id] ?? ""
                        let effectiveTimeout = effectiveTimeout(for: node, apiConfigs: apiConfigs, settings: settings)
                        group.addTask {
                            do {
                                try Task.checkCancellation()
                                let response = try await self.withTimeout(seconds: effectiveTimeout) {
                                    try await self.execute(node: node, project: project, context: inputContext, apiConfigs: apiConfigs, settings: settings, aiClient: aiClient)
                                }
                                try Task.checkCancellation()
                                return ParallelNodeResult(node: node, inputContext: inputContext, response: response, error: nil)
                            } catch {
                                return ParallelNodeResult(node: node, inputContext: inputContext, response: nil, error: error)
                            }
                        }
                    }
                }

                addTasks(readyNodes)

                for await result in group {
                    if fatalError == nil {
                        handleParallelResult(result)

                        // v6.9：流水线式调度。某个并行节点一完成，就立刻重新检查它的下游。
                        // 例如：计划者2完成后，代码工作者1 可立即开始；不需要等待计划者3/4。
                        // 只有汇总者这类多输入节点，才会因为仍缺其它上游而继续等待。
                        let reconsiderIDs = deduplicated(stillWaiting + queue)
                        stillWaiting.removeAll()
                        queue.removeAll()
                        let newlyReady = collectReadyNodes(from: reconsiderIDs)
                        if !newlyReady.isEmpty {
                            prepareNodesForExecution(newlyReady, reason: "上游局部完成后立即启动")
                            addTasks(newlyReady)
                        }

                        syncDependencyState(waitingIDs: stillWaiting)
                        record.progress = min(0.98, Double(executed) / Double(max(project.nodes.count, 1)))
                        await onUpdate(record)
                    }
                    if fatalError != nil { group.cancelAll() }
                }
            }

            if let fatalError {
                await onUpdate(record)
                if fatalError is CancellationError { throw CancellationError() }
                throw fatalError
            }

            queue = deduplicated(stillWaiting + queue)
            record.progress = min(0.98, Double(executed) / Double(max(project.nodes.count, 1)))
            await onUpdate(record)
        }

        record.status = .completed
        record.endedAt = Date()
        record.progress = 1
        record.currentNodeTitle = nil
        record.currentNodeIDs = []
        record.waitingNodeIDs = nil
        record.staleNodeIDs = nil
        record.currentStage = "运行完成"
        record.diagnosticMessage = "全部可达模块已执行完成。并行分支已按依赖关系合并。"
        record.output = latestCombinedOutput(project: project, contextByNode: contextByNode)
        appendLog(&record, .success, nil, "工作流运行完成")
        return record
    }

    private func effectiveTimeout(for node: WorkflowNode, apiConfigs: [APIProviderConfig], settings: AppSettings) -> Int {
        let base = min(max(node.timeoutSeconds, 5), 3600)
        guard isThinkingModeEnabled(for: node, apiConfigs: apiConfigs, settings: settings) else { return base }
        return min(max(base, settings.thinkingModeTimeoutSeconds), 7200)
    }

    private func isThinkingModeEnabled(for node: WorkflowNode, apiConfigs: [APIProviderConfig], settings: AppSettings) -> Bool {
        guard let providerID = effectiveProviderID(for: node, settings: settings),
              let config = apiConfigs.first(where: { $0.id == providerID }),
              let model = effectiveModelID(for: node, settings: settings),
              !model.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return false }
        return thinkingModeType(for: node, config: config, model: model, settings: settings) == "enabled"
    }

    private func effectiveOutputTokenLimit(for node: WorkflowNode) -> Int? {
        // 0 表示不限制：不发送 max_tokens，避免 App 自己把输出截断。
        // 供应商/模型仍可能有自己的上下文或最大输出限制。
        node.maxTokens > 0 ? node.maxTokens : nil
    }

    private func thinkingModeType(for node: WorkflowNode, config: APIProviderConfig, model: String, settings: AppSettings) -> String? {
        let modelInfo = config.models.first(where: { $0.id == model })
        guard modelSupportsThinkingMode(baseURL: config.baseURL, modelID: model, modelInfo: modelInfo) else { return nil }
        let enabled = node.useThinkingMode ?? settings.defaultUseThinkingMode
        return enabled ? "enabled" : "disabled"
    }

    private func truncationReason(response: AITextResponse, requestedMaxTokens: Int?) -> String? {
        let finish = response.finishReason?.lowercased().trimmingCharacters(in: .whitespacesAndNewlines)
        if finish == "length" {
            return "模型/供应商返回 finish_reason=length，说明输出被供应商长度上限截断。"
        }
        if let requestedMaxTokens, requestedMaxTokens > 0, response.tokenUsage.output >= Int(Double(requestedMaxTokens) * 0.92) {
            return "输出接近本模块 maxTokens 上限，可能被 App 请求参数截断。"
        }
        return nil
    }

    private func execute(node: WorkflowNode, project: WorkflowProject, context: String, apiConfigs: [APIProviderConfig], settings: AppSettings, aiClient: AIClient) async throws -> AITextResponse {
        switch node.kind {
        case .start:
            let imageNote = project.resources.contains(where: { $0.kind == .image }) ? "\n已检测到图片资源；图片内容将交给图片理解模块处理。" : ""
            let text = "已接收需求。\n\n\(project.userPrompt)\(imageNote)"
            return AITextResponse(text: text, tokenUsage: TokenUsage(input: TokenEstimator.roughCount(project.userPrompt), output: TokenEstimator.roughCount(text)))
        case .logger:
            let text = "日志记录模块已记录当前上下文、模块输出、Token 与状态。"
            return AITextResponse(text: text, tokenUsage: TokenUsage(input: 0, output: TokenEstimator.roughCount(text)))
        case .versionSnapshot:
            let text = "版本快照模块已保存工作流结构、提示词、模型配置和当前输出。"
            return AITextResponse(text: text, tokenUsage: TokenUsage(input: 0, output: TokenEstimator.roughCount(text)))
        case .output:
            let text = context.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? "输出模块没有收到上游内容。请把项目打包者、格式转换者或汇总者连接到输出模块的输入口。" : context
            return AITextResponse(text: text, tokenUsage: TokenUsage(input: TokenEstimator.roughCount(context), output: TokenEstimator.roughCount(text)))
        default:
            guard let providerID = effectiveProviderID(for: node, settings: settings),
                  let config = apiConfigs.first(where: { $0.id == providerID }),
                  let model = effectiveModelID(for: node, settings: settings),
                  !model.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
                throw WorkflowEngineError.missingModelConfiguration("\(node.title) 未配置可用模型。请先在设置页配置全局默认模型，或在模块详情里单独选择模型，然后在工作流页点击“一键应用默认模型”。")
            }
            let apiKey = try KeychainService.read(account: config.keychainAccount)
            let system = systemPrompt(for: node)
            let reviewerScope = reviewerScopeGuide(for: node, project: project)
            let outputRule: String
            if node.kind.isReviewer {
                outputRule = "输出要求：只能输出 JSON。\n\(reviewerScope)\n通过时 {\"passed\":true,\"severity\":\"pass\",\"feedback\":\"\",\"blockingIssues\":[]}；不通过时 {\"passed\":false,\"severity\":\"blocking\",\"feedback\":\"必须返工的阻塞问题\",\"blockingIssues\":[\"具体阻塞问题\"]}。只有直接上游输出本身存在阻塞问题才不通过；普通优化建议、风格偏好、可选重构必须通过，不要为了找问题而找问题。不要泄露 API Key。"
            } else if node.kind == .dispatcher {
                outputRule = "输出要求：必须按已连接工作者逐个分配任务，不能把完整项目原样发给每个工作者。优先输出 JSON：{\"sharedTechStack\":\"统一技术栈/框架/依赖/运行方式\",\"projectBoundaries\":\"每个工作者的边界，禁止重复做别人负责的部分\",\"assignments\":[{\"targetNodeID\":\"节点ID\",\"targetTitle\":\"工作者标题\",\"task\":\"只属于该工作者的具体任务\",\"mustNotDo\":\"不能做哪些其他工作者负责的内容\",\"ownedFiles\":[\"该工作者负责的文件/目录\"],\"inputsNeeded\":\"需要读取的上游资料\",\"expectedOutput\":\"期望输出\",\"acceptanceCriteria\":\"验收标准\"}],\"parallelPlan\":\"哪些任务可以并行，哪些必须等上游\"}。必须使用下面给出的真实 targetNodeID，不要编造不存在的模块；同一项目必须统一技术栈。"
            } else if node.kind == .formatter {
                outputRule = "输出要求：你是格式转换者，只负责把多个上游结果智能转换成最终文件内容，不要再做质量检查。若有多条上游线，你必须逐个读取每个上游模块的输出，判断它应该变成什么文件格式；如果上游内容已明确文件名/语言/用途，按它输出；如果不明确，先根据用户目标和上游内容智能推断。输出开头必须给出 FILE_FORMAT_PLAN，列出 来源模块 -> 文件路径 -> 格式 -> 理由。然后必须输出真实文件块，格式为 ```file path=\"snake.py\" 或 ```file path=\"README.md\"，代码内容放在代码块内；如果文件内容本身包含三反引号代码块，外层必须改用四反引号 ````file path=\"README.md\"。严禁只根据 {\"passed\":true} 重新脑补/重写项目；如果上游只有检查结果，没有真实文件、代码、文章或已通过检查的上游完整产物，必须输出 ERROR_MISSING_CONCRETE_ARTIFACTS，并说明需要上游透传真实产物。不要只给说明而不给文件内容。不要泄露 API Key。"
            } else if node.kind == .filePackager {
                outputRule = "输出要求：你是项目打包者 / 文件结构整理者，不是普通 ZIP 按钮。你要读取上游所有文件块和用户目标，智能决定项目目录结构；必要时补充 README.md、requirements.txt、package.json、配置文件、assets 目录、运行脚本或说明。必须输出 PROJECT_PACKAGE_PLAN，列出目录树、每个文件来源、为什么这样组织。然后输出最终文件块，格式为 ```file path=\"ProjectName/main.py\" ... ```；Markdown 文件内如果还要包含代码块，外层必须使用四反引号 ````file path=\"README.md\"。不得把目录树、教程命令、占位说明当作真实源码文件；不得省略上游已经存在的真实文件，例如 config.toml、样式文件、文章文件。不要随意重写核心业务代码；如果只需移动/补说明，保留原代码内容。不要泄露 API Key。"
            } else if node.kind == .optimizer {
                outputRule = "输出要求：你是意见提出者 / 优化者，但不能只提出意见。必须先用极短列表说明你发现的关键问题/优化动作，然后直接给出优化后的完整版本。不要输出 passed JSON，不要走检查者逻辑；如果输入是代码或文件块，必须输出修改后的完整文件块。不要泄露 API Key。"
            } else {
                outputRule = "输出要求：结构化、可执行、指出不确定内容和风险。不要泄露 API Key。"
            }
            let dispatchGuide = node.kind == .dispatcher ? """

            # 已连接工作者 / 可分配目标
            你必须只向下面这些真实连接的下游模块分配任务：
            \(connectedDispatchTargetSummary(for: node, project: project))

            分配要求：
            - 读取上面的连接关系，而不是按想象添加工作者。
            - 每个 assignment 必须对应一个真实连接的 targetNodeID。
            - 必须先确定 sharedTechStack，所有代码工作者必须使用同一个技术栈、同一项目结构、同一运行方式。
            - 多个代码工作者并行时，必须拆成互不重叠的文件/目录/功能边界：例如前端页面、后端 API、数据/样式/README，而不是三个人都做完整项目。
            - 每个工作者的 task 必须写清楚“只做什么”和“不能做什么”，避免互相覆盖。
            - expectedOutput 必须说明该工作者要输出哪些具体文件块或交付物。
            - 如果某个连接目标不是工作者，也要说明为什么需要给它什么输入。
            """ : ""
            let workerGuide = node.kind.isAssignableWorker ? """

            # 本模块身份
            当前模块 ID：\(node.id.uuidString)
            当前模块标题：\(node.title)
            当前模块类型：\(node.kind.title)
            如果上游包含任务分配者输出，请只执行分配给本模块 ID 或本模块标题的 assignment。
            严禁实现其他工作者的 ownedFiles / task / mustNotDo 范围；如果任务分配表没有明确分给你，只输出“未找到分配给本模块的任务”，不要擅自生成完整项目。
            所有代码工作者必须遵守任务分配者给出的 sharedTechStack，不得自行换成 Flask/React/Express/SQLite 等不同技术栈。
            """ : ""
            let user = """
            当前模块输入（包含用户原始需求 + 上游 AI 模块真实输出）：
            \(context)
            \(dispatchGuide)
            \(workerGuide)

            当前模块职责：
            \(node.kind == .custom ? node.prompt : node.kind.defaultPrompt)

            交流要求：必须明确参考上游模块输出继续工作；如果上游给了修改意见、识别结果、代码、方案或任务分配表，要把它作为本模块输入的一部分处理，不要从零开始。
            模块间追问规则：如果本模块确实缺少关键信息，可以写 ASK_UPSTREAM: <问题>。运行引擎会把上游已有输出作为回复上下文再次交给你生成最终结果；但不能因为小问题空等，能根据上游内容合理推断时必须继续完成。

            \(outputRule)
            """

            let outputTokenLimit = effectiveOutputTokenLimit(for: node)
            if node.kind == .imageUnderstanding, let image = project.resources.first(where: { $0.kind == .image })?.base64Preview {
                return try await aiClient.completeVision(baseURL: config.baseURL, apiKey: apiKey, model: model, prompt: user, imageBase64: image, maxTokens: outputTokenLimit, temperature: node.temperature, timeoutSeconds: effectiveTimeout(for: node, apiConfigs: apiConfigs, settings: settings), thinkingModeType: thinkingModeType(for: node, config: config, model: model, settings: settings))
            } else {
                let messages = [AIMessage(role: "system", content: system), AIMessage(role: "user", content: user)]
                let initial = try await aiClient.completeText(baseURL: config.baseURL, apiKey: apiKey, model: model, messages: messages, maxTokens: outputTokenLimit, temperature: node.temperature, timeoutSeconds: effectiveTimeout(for: node, apiConfigs: apiConfigs, settings: settings), thinkingModeType: thinkingModeType(for: node, config: config, model: model, settings: settings))
                var resolved = try await resolveUpstreamQuestionsIfNeeded(node: node, initial: initial, context: context, system: system, config: config, apiKey: apiKey, model: model, settings: settings, aiClient: aiClient, outputTokenLimit: outputTokenLimit)
                if let reason = truncationReason(response: resolved, requestedMaxTokens: outputTokenLimit) {
                    let warning = "\n\n> ⚠️ 系统提示：\(reason) 如果本模块 maxTokens 不是 0，请改成 0；如果已是 0，则是模型/供应商自身输出上限，需要换更长输出模型或把任务拆成更小文件。"
                    resolved.text += warning
                    resolved.tokenUsage.output += TokenEstimator.roughCount(warning)
                }
                return resolved
            }
        }
    }

    private func packageSummary(from context: String) -> String {
        let files = ZipArchiveService.detectGeneratedFilePaths(in: context)
        if files.isEmpty {
            return """
            # 项目打包者 / 文件结构整理者

            暂未在上游内容中识别到明确文件块。

            请让“格式转换者”先输出文件块；项目打包者会在此基础上整理目录结构，例如：

            ```file path="snake.py"
            # Python 代码
            ```

            如果没有可识别文件块，项目打包者无法整理项目目录；当前上游内容仍会进入输出模块。
            """
        }
        let list = files.map { "- `\($0)`" }.joined(separator: "\n")
        return """
        # 项目打包者 / 文件结构整理者

        已识别到以下文件块。项目打包者应把它们组织为合理的项目目录：

        \(list)

        ## 整理规则
        - 简单单文件可直接交给输出模块导出，不必使用项目打包者。
        - 多文件/项目任务应补齐 README、依赖文件、目录结构和运行说明。
        - 输出模块只负责展示和导出，不会重新整理这些文件。
        """
    }

    private func missingModelConfigurationMessage(project: WorkflowProject, apiConfigs: [APIProviderConfig], settings: AppSettings) -> String? {
        let reachableIDs = reachableNodeIDs(fromStartIn: project)
        let missing = project.nodes
            .filter { reachableIDs.contains($0.id) && requiresAIModel($0.kind) }
            .filter { node in
                guard let providerID = effectiveProviderID(for: node, settings: settings),
                      apiConfigs.contains(where: { $0.id == providerID }),
                      let modelID = effectiveModelID(for: node, settings: settings),
                      !modelID.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
                    return true
                }
                return false
            }

        guard !missing.isEmpty else { return nil }
        let names = missing.map { "• \($0.title)（\($0.kind.title)）" }.joined(separator: "\n")
        return "以下可达 AI 模块没有可用模型，已阻止运行，避免出现假完成/占位输出：\n\(names)\n\n请到设置页配置全局默认模型，或在模块详情中单独选择模型，然后点击工作流页“一键应用默认模型”。"
    }

    private func reachableNodeIDs(fromStartIn project: WorkflowProject) -> Set<UUID> {
        guard let start = project.nodes.first(where: { $0.kind == .start }) else { return [] }
        var visited = Set<UUID>()
        var queue: [UUID] = [start.id]
        while let id = queue.first {
            queue.removeFirst()
            guard !visited.contains(id) else { continue }
            visited.insert(id)
            let next = project.edges.filter { $0.from == id }.map(\.to)
            queue.append(contentsOf: next)
        }
        return visited
    }

    private func requiresAIModel(_ kind: WorkflowNodeKind) -> Bool {
        switch kind {
        case .start, .output, .logger, .versionSnapshot:
            return false
        default:
            return true
        }
    }

    private func effectiveProviderID(for node: WorkflowNode, settings: AppSettings) -> UUID? {
        if let providerID = node.providerID { return providerID }
        switch node.kind {
        case .codeWorker:
            return settings.defaultCodeProviderID ?? settings.defaultTextProviderID
        case .codeReviewer, .qualityReviewer:
            return settings.defaultReviewerProviderID ?? settings.defaultTextProviderID
        case .visualReviewer, .imageUnderstanding:
            return settings.defaultVisionProviderID ?? settings.defaultReviewerProviderID ?? settings.defaultTextProviderID
        case .imageGenerator:
            return settings.defaultImageProviderID ?? settings.defaultTextProviderID
        default:
            return settings.defaultTextProviderID
        }
    }

    private func effectiveModelID(for node: WorkflowNode, settings: AppSettings) -> String? {
        if let modelID = node.modelID, !modelID.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { return modelID }
        switch node.kind {
        case .codeWorker:
            return settings.defaultCodeModelID ?? settings.defaultTextModelID
        case .codeReviewer, .qualityReviewer:
            return settings.defaultReviewerModelID ?? settings.defaultTextModelID
        case .visualReviewer, .imageUnderstanding:
            return settings.defaultVisionModelID ?? settings.defaultReviewerModelID ?? settings.defaultTextModelID
        case .imageGenerator:
            return settings.defaultImageModelID ?? settings.defaultTextModelID
        default:
            return settings.defaultTextModelID
        }
    }

    private func systemPrompt(for node: WorkflowNode) -> String {
        switch node.kind {
        case .codeReviewer:
            return "你是代码检查者。你只能检查直接上游模块交给你的输出，不负责检查并行分支或未来整合后的完整项目。必须通过：普通优化、风格建议、命名偏好、可选重构、轻微体验问题、缺少其他工作者负责的文件。必须不通过：直接上游输出本身的语法错误、依赖明显错误、API Key 泄露、严重安全风险、明确违反它自己的 assignment/ownedFiles、它声明负责的核心文件缺失。完整运行包缺文件、文件类型错位等整包问题只允许最终汇总/格式转换/项目打包之后的检查者判定。必须只输出 JSON：{\"passed\":true,\"severity\":\"pass\",\"feedback\":\"\",\"blockingIssues\":[]} 或 {\"passed\":false,\"severity\":\"blocking\",\"feedback\":\"必须返工的直接上游阻塞问题\",\"blockingIssues\":[\"具体阻塞问题\"]}。通过时 feedback 必须为空，不要给修改建议。"
        case .qualityReviewer:
            return "你是质量评估者。默认只评估直接上游模块输出的准确性、完整性、格式和风险；不要检查并行分支缺少什么。只有当直接上游是汇总者、格式转换者、项目打包者或输出模块时，才把对象视为最终可交付产物并做整包验收。普通改进建议必须通过。必须只输出 JSON：{\"passed\":true,\"severity\":\"pass\",\"feedback\":\"\",\"blockingIssues\":[]} 或 {\"passed\":false,\"severity\":\"blocking\",\"feedback\":\"必须返工的问题\",\"blockingIssues\":[\"具体阻塞问题\"]}。通过时 feedback 必须为空。"
        case .visualReviewer:
            return "你是视觉检查者。只有严重影响使用的视觉/UI问题才不通过，例如文字看不清、关键按钮不可见、布局遮挡、尺寸严重不适配。普通美化建议必须通过。必须只输出 JSON：{\"passed\":true,\"severity\":\"pass\",\"feedback\":\"\",\"blockingIssues\":[]} 或 {\"passed\":false,\"severity\":\"blocking\",\"feedback\":\"必须返工的严重视觉问题\",\"blockingIssues\":[\"具体阻塞问题\"]}。通过时 feedback 必须为空。"
        case .codeWorker:
            return #"你是代码工作者。必须读取上游计划和检查者 review_notes；如果有上一轮代码输出，必须基于上一轮完整修改，不要只复述建议。输出可直接使用的完整代码/文件结构/运行说明。涉及项目代码时，必须用 ```file path="..." 文件块输出关键文件完整内容，不要只列文件名或省略核心文件。"#
        case .optimizer:
            return "你是意见提出者 / 优化者。你不是检查者，不负责通过/不通过；你需要阅读上游结果，简短指出关键改进点，然后直接生成优化后的完整版本。不要只输出建议。"
        case .aggregator:
            return "你是汇总者。你必须合并上游真实产物，不能只根据检查者的 passed JSON 脑补新项目。若上游来自检查者，必须使用其中的『已通过检查的上游完整产物』继续整合；如果缺少真实产物，明确报错，不要重新生成一个新版本。"
        case .formatter:
            return "你是格式转换者。必须基于上游真实内容转换成文件块，严禁只看到 passed JSON 就重新生成项目。缺少真实产物时输出 ERROR_MISSING_CONCRETE_ARTIFACTS。"
        case .filePackager:
            return "你是项目打包者 / 文件结构整理者。你的价值不是把文件压缩成 ZIP，而是把上游散乱文件整理成可交付项目：目录树、文件命名、README、依赖文件、资源目录和运行说明。严禁把 README 里的目录树示例误当成真实文件内容。"
        case .imageUnderstanding:
            return "你是图片理解模块。输出图片摘要、关键文字、可操作信息、不确定内容。"
        case .multiModelVote:
            return "你是裁判模型。比较多个答案，选择更可靠结果，并解释理由。"
        default:
            return "你是 AI Workflow Studio 的 \(node.kind.title)。你必须读取上游模块传来的内容，并在此基础上继续处理，形成真实多 AI 协作链。"
        }
    }

    private func localFallbackOutput(for node: WorkflowNode, context: String, project: WorkflowProject) -> String {
        switch node.kind {
        case .planner:
            return "未配置模型，使用本地占位计划：1. 拆解需求；2. 执行核心任务；3. 检查质量；4. 导出结果。"
        case .dispatcher:
            return localDispatcherFallback(for: node, project: project)
        case .codeReviewer, .qualityReviewer, .visualReviewer:
            return "{\"passed\":false,\"feedback\":\"未配置检查者模型，无法确认质量。请配置检查者模型后重新运行，或手动调整连线。\"}"
        case .imageUnderstanding:
            return "未配置图片理解模型，无法识别图片。请在设置中添加支持图片输入的模型。"
        default:
            return "未配置模型，\(node.kind.title) 已跳过真实 AI 调用，仅生成占位输出。"
        }
    }

    private func localDispatcherFallback(for node: WorkflowNode, project: WorkflowProject) -> String {
        let targets = dispatchTargets(for: node, project: project)
        guard !targets.isEmpty else {
            return "任务分配者没有检测到已连接的下游工作者。请从任务分配者输出接口连接到通用工作者、代码工作者、图片生成者等模块后再运行。"
        }
        let total = targets.count
        let assignments = targets.enumerated().map { index, target in
            let scope: String
            let mustNotDo: String
            let ownedFiles: String
            if target.kind == .codeWorker || target.kind == .worker {
                if total <= 1 {
                    scope = "完成完整项目，但必须遵守统一技术栈和上游计划。"
                    mustNotDo = "不要更换技术栈，不要输出与上游计划冲突的项目结构。"
                    ownedFiles = "[\"完整项目文件\"]"
                } else if index == 0 {
                    scope = "负责项目基础结构、共享类型/配置、核心入口和主要页面骨架。"
                    mustNotDo = "不要实现其他工作者负责的后端 API、测试、文档或独立完整项目。"
                    ownedFiles = "[\"package/config/entry files\", \"shared/core files\"]"
                } else if index == 1 {
                    scope = "负责主要业务逻辑、数据模型、API/状态管理或后端能力。"
                    mustNotDo = "不要重写入口文件或重复实现第 1 个工作者的基础结构。"
                    ownedFiles = "[\"business/API/state files\"]"
                } else {
                    scope = "负责样式、错误处理、README、运行说明、测试或补充模块。"
                    mustNotDo = "不要重写前两个工作者已负责的核心入口和业务逻辑。"
                    ownedFiles = "[\"styles/docs/tests/support files\"]"
                }
            } else {
                scope = "完成适合 \(target.kind.title) 的独立子任务。"
                mustNotDo = "不要重复其他并行模块已经负责的内容。"
                ownedFiles = "[]"
            }
            return """
            {
              \"targetNodeID\": \"\(target.id.uuidString)\",
              \"targetTitle\": \"\(target.title)\",
              \"task\": \"\(scope)\",
              \"mustNotDo\": \"\(mustNotDo)\",
              \"ownedFiles\": \(ownedFiles),
              \"inputsNeeded\": \"用户原始需求、计划者输出、统一技术栈和相关上游资料。\",
              \"expectedOutput\": \"\(target.kind.outputDescription)\",
              \"acceptanceCriteria\": \"只输出自己负责范围内的完整文件块；必须能与其他工作者输出合并；不得生成另一个独立技术栈项目。\"
            }
            """
        }.joined(separator: ",\n")
        return """
        {
          \"sharedTechStack\": \"由计划者决定的统一技术栈；所有代码工作者必须遵守，不得各自换技术栈。\",
          \"projectBoundaries\": \"每个工作者只做自己的 ownedFiles / task 范围，禁止互相覆盖。\",
          \"assignments\": [
        \(assignments)
          ],
          \"parallelPlan\": \"以上已连接工作者可以按依赖关系并行执行；多个下游同时连接时会同时启动，但每个工作者只执行自己的任务边界。\"
        }
        """
    }

    private func inputContextFor(node: WorkflowNode, project: WorkflowProject, contextByNode: [UUID: String], activatedEdgeIDs: Set<UUID>) -> String {
        if node.kind == .start { return "# 用户原始需求\n\(project.userPrompt)" }
        let incoming = project.edges.filter { $0.to == node.id }
        let formatterSourceList = incoming.compactMap { edge -> String? in
            guard let source = project.nodes.first(where: { $0.id == edge.from }) else { return nil }
            return "- 来源模块：\(source.title)｜类型：\(source.kind.title)｜连线条件：\(edge.condition.title)"
        }.joined(separator: "\n")
        let dispatcherConnectionContext: String = node.kind == .dispatcher ? """

        # 任务分配者实际连接的下游模块
        下面是当前画布上从“任务分配者”直接连出去的真实模块。任务分配必须基于这个列表：
        \(connectedDispatchTargetSummary(for: node, project: project))
        """ : ""
        let formatterConnectionContext: String = node.kind == .formatter ? """

        # 格式转换者多上游输入清单
        你当前连接了 \(incoming.count) 条上游线。必须逐个读取这些上游输出，智能判断每个来源应转换成什么文件格式；如果多个上游内容属于同一项目，可以合并成同一个文件或拆分成多个文件，并在 FILE_FORMAT_PLAN 说明原因。
        \(formatterSourceList)
        """ : ""
        let upstream = incoming.compactMap { edge -> String? in
            guard !isFeedbackReturnEdge(edge, in: project),
                  activatedEdgeIDs.contains(edge.id),
                  let source = project.nodes.first(where: { $0.id == edge.from }),
                  let output = contextByNode[source.id] else { return nil }
            if source.kind.isReviewer {
                let decision = reviewerDecision(node: source, output: output)
                if (edge.condition == .passed || edge.condition == .scoreHigh) && decision.passed != true { return nil }
                if (edge.condition == .failed || edge.condition == .scoreLow) && decision.passed == true { return nil }
            }
            return """
            ## 来自上游 AI：\(source.title)
            连线条件：\(edge.condition.title)
            上游输出：
            \(output)
            """
        }
        let reviewerCompletenessNote: String = node.kind.isReviewer ? """

        # 检查范围 / Scope
        \(reviewerScopeGuide(for: node, project: project))
        """ : ""

        let previousOwnOutput = contextByNode[node.id].map { previous in
            """

            # 本模块上一轮输出
            \(previous)
            """
        } ?? ""

        let reviewerFeedback = incoming.compactMap { edge -> String? in
            guard (edge.condition == .failed || edge.condition == .scoreLow),
                  activatedEdgeIDs.contains(edge.id),
                  let source = project.nodes.first(where: { $0.id == edge.from }),
                  source.kind.isReviewer,
                  let output = contextByNode[source.id] else { return nil }
            return "来自检查者 \(source.title) 的不合格返工意见：\n\(output)"
        }.joined(separator: "\n\n")

        if upstream.isEmpty {
            return """
            # 用户原始需求
            \(project.userPrompt)

            # 上游 AI 交流上下文
            暂无上游输出；此模块会直接基于用户需求工作。
            \(dispatcherConnectionContext)
            \(formatterConnectionContext)
            \(previousOwnOutput)
            """
        }
        return """
        # 用户原始需求
        \(project.userPrompt)

        # 上游 AI 交流上下文
        \(upstream.joined(separator: "\n\n"))
        \(dispatcherConnectionContext)
        \(formatterConnectionContext)
        \(reviewerCompletenessNote)
        \(previousOwnOutput)

        # 返工意见 / review_notes
        \(reviewerFeedback.isEmpty ? "无" : reviewerFeedback)

        # 执行要求
        当前模块必须基于以上上游输出继续处理，不要忽略上游结果。
        如果本次是检查者打回，请对照 review_notes 和本模块上一轮输出，直接产出修复后的完整版本。
        """
    }

    private func inputAuditPreview(for node: WorkflowNode, inputContext: String, project: WorkflowProject) -> String {
        let incoming = project.edges.filter { $0.to == node.id }
        let upstreamSummary = incoming.compactMap { edge -> String? in
            guard let source = project.nodes.first(where: { $0.id == edge.from }) else { return nil }
            return "- \(source.title) → \(node.title)（\(edge.condition.title)）"
        }.joined(separator: "\n")
        let maxVisibleCharacters = 6000
        let preview = String(inputContext.prefix(maxVisibleCharacters))
        let truncatedNote = inputContext.count > maxVisibleCharacters ? "\n\n……这里之后还有 \(inputContext.count - maxVisibleCharacters) 个字符未在界面展示，但运行请求会发送完整 inputContext。" : ""
        return """
        【输入审计】
        实际发送给模型的输入约 \(TokenEstimator.roughCount(inputContext)) Token，字符数 \(inputContext.count)。
        注意：这里是界面预览，不是请求截断；如果 API 自己返回的 prompt_tokens 更低，通常是模型/供应商计数方式不同。
        上游连接：
        \(upstreamSummary.isEmpty ? "无" : upstreamSummary)

        【输入预览】
        \(preview)\(truncatedNote)
        """
    }

    private func isFeedbackReturnEdge(_ edge: WorkflowEdge, in project: WorkflowProject) -> Bool {
        guard let source = project.nodes.first(where: { $0.id == edge.from }),
              let target = project.nodes.first(where: { $0.id == edge.to }),
              source.kind.isReviewer else { return false }

        // 关键修复：不能只因为 target 后续还能通过“大回路”绕回 reviewer，
        // 就把 reviewer -> downstream join 的“通过线”误判为返工线。
        // 典型误判链路：代码检查者 -> 汇总者 -> 质量检查者 -> 失败返回计划者 -> ... -> 代码检查者。
        // 上面这条 reviewer -> 汇总者 是正常前进依赖，汇总者必须等待所有通过线触发后才能运行。
        guard hasPath(from: edge.to, to: edge.from, in: project, ignoring: edge.id) else { return false }

        switch edge.condition {
        case .failed, .scoreLow:
            return true
        case .always:
            // 兼容旧工作流：用户如果误用“总是”把检查者连回左侧上游模块，仍按返工线处理。
            // 但连接到右侧汇总/输出等下游节点时，即使后面存在质量检查大回路，也不能忽略这条依赖。
            return target.x < source.x
        case .passed, .scoreHigh:
            return false
        }
    }

    private func hasPath(from start: UUID, to target: UUID, in project: WorkflowProject, ignoring ignoredEdgeID: UUID? = nil) -> Bool {
        if start == target { return true }
        var visited = Set<UUID>()
        var queue: [UUID] = [start]
        while let id = queue.first {
            queue.removeFirst()
            guard visited.insert(id).inserted else { continue }
            let next = project.edges
                .filter { $0.id != ignoredEdgeID && $0.from == id }
                .map(\.to)
            if next.contains(target) { return true }
            queue.append(contentsOf: next)
        }
        return false
    }

    private func blockedConditionalInputReason(
        for node: WorkflowNode,
        project: WorkflowProject,
        contextByNode: [UUID: String],
        dirtyNodeIDs: Set<UUID>,
        runningNodeIDs: Set<UUID>,
        pendingNodeIDs: Set<UUID>
    ) -> String? {
        let incoming = project.edges.filter { $0.to == node.id }
        for edge in incoming {
            guard !isFeedbackReturnEdge(edge, in: project),
                  let source = project.nodes.first(where: { $0.id == edge.from }),
                  !runningNodeIDs.contains(source.id),
                  !dirtyNodeIDs.contains(source.id),
                  !pendingNodeIDs.contains(source.id),
                  let sourceOutput = contextByNode[source.id] else { continue }

            if source.kind.isReviewer {
                let decision = reviewerDecision(node: source, output: sourceOutput)
                if (edge.condition == .passed || edge.condition == .scoreHigh) && decision.passed != true {
                    return "\(source.title) 没有通过，但当前输入线要求通过。"
                }
                if (edge.condition == .failed || edge.condition == .scoreLow) && decision.passed == true {
                    return "\(source.title) 已通过，但当前输入线要求失败/低分。"
                }
            }
        }
        return nil
    }

    private func missingRequiredInputTitles(
        for node: WorkflowNode,
        project: WorkflowProject,
        contextByNode: [UUID: String],
        dirtyNodeIDs: Set<UUID>,
        runningNodeIDs: Set<UUID>,
        pendingNodeIDs: Set<UUID>,
        activatedEdgeIDs: Set<UUID>
    ) -> [String] {
        let incoming = project.edges.filter { $0.to == node.id }
        return incoming.compactMap { edge in
            guard let source = project.nodes.first(where: { $0.id == edge.from }) else { return nil }

            // 返工/反馈线不是普通启动依赖。
            // 例如：汇总者 -> 综合检查者，不合格 -> 计划者/任务分配者。
            // 计划者第一次运行时不能等待“未来才会产生”的检查者失败输出；
            // 只有检查者真的失败后，这条线才作为触发线重新把计划者/任务分配者加入队列。
            if isFeedbackReturnEdge(edge, in: project) {
                return nil
            }

            if runningNodeIDs.contains(source.id) {
                return "\(source.title)（正在运行）"
            }
            if pendingNodeIDs.contains(source.id) {
                return "\(source.title)（等待本轮上游启动/完成）"
            }
            if dirtyNodeIDs.contains(source.id) {
                return "\(source.title)（等待最新输出）"
            }

            guard let sourceOutput = contextByNode[source.id] else {
                return source.title
            }

            if !activatedEdgeIDs.contains(edge.id) {
                return "\(source.title)（等待连线触发：\(edge.condition.title)）"
            }

            if source.kind.isReviewer {
                let decision = reviewerDecision(node: source, output: sourceOutput)
                if (edge.condition == .passed || edge.condition == .scoreHigh) && decision.passed != true {
                    return "\(source.title)（通过条件未满足）"
                }
                if (edge.condition == .failed || edge.condition == .scoreLow) && decision.passed == true {
                    return "\(source.title)（失败/低分条件未满足）"
                }
            }

            return nil
        }
    }

    private func nextEdges(from node: WorkflowNode, passed: Bool, project: WorkflowProject) -> [WorkflowEdge] {
        let outgoing = project.edges.filter { $0.from == node.id }
        if node.kind.isReviewer {
            if passed {
                let passEdges = outgoing.filter { $0.condition == .passed || $0.condition == .scoreHigh }
                if !passEdges.isEmpty { return passEdges }

                // If a reviewer passes and has only generic outgoing lines, do not follow obvious
                // feedback-return lines back to an ancestor. This prevents a successful review from
                // restarting the planner/dispatcher loop.
                return outgoing.filter { $0.condition == .always && !isFeedbackReturnEdge($0, in: project) }
            } else {
                let failEdges = outgoing.filter { $0.condition == .failed || $0.condition == .scoreLow }
                if !failEdges.isEmpty { return failEdges }

                // Fallback for workflows where the user connected the reviewer back to a planner/dispatcher
                // with a normal output port by mistake. Treat reviewer -> ancestor lines as return lines
                // only when the reviewer fails.
                let feedbackEdges = outgoing.filter { isFeedbackReturnEdge($0, in: project) }
                if !feedbackEdges.isEmpty { return feedbackEdges }

                return outgoing.filter { $0.condition == .always }
            }
        }
        return outgoing.filter { $0.condition == .always || $0.condition == .passed || $0.condition == .scoreHigh }
    }

    private func dispatchTargets(for dispatcher: WorkflowNode, project: WorkflowProject) -> [WorkflowNode] {
        let directTargetIDs = project.edges
            .filter { $0.from == dispatcher.id && ($0.condition == .always || $0.condition == .passed || $0.condition == .scoreHigh) }
            .map(\.to)
        return directTargetIDs.compactMap { targetID in
            project.nodes.first { $0.id == targetID }
        }
    }

    private func connectedDispatchTargetSummary(for dispatcher: WorkflowNode, project: WorkflowProject) -> String {
        let targets = dispatchTargets(for: dispatcher, project: project)
        guard !targets.isEmpty else {
            return "未检测到从任务分配者输出接口连接出去的工作者。请先连线，否则无法知道要把任务分给谁。"
        }
        return targets.map { target in
            let apiText: String
            if let modelID = target.modelID, !modelID.isEmpty {
                apiText = "模型：\(modelID)"
            } else {
                apiText = "模型：未设置，将使用本地占位或提示配置默认模型"
            }
            return """
            - targetNodeID: \(target.id.uuidString)
              标题：\(target.title)
              类型：\(target.kind.title)
              能力说明：\(target.kind.summary)
              输入能力：\(target.kind.inputDescription)
              期望输出：\(target.kind.outputDescription)
              \(apiText)
            """
        }.joined(separator: "\n")
    }

    private struct ReviewerDecision: Decodable {
        var passed: Bool?
        var severity: String?
        var feedback: String?
        var blockingIssues: [String]?
    }

    private func reviewerDecision(node: WorkflowNode, output: String) -> (passed: Bool?, feedback: String?) {
        guard node.kind.isReviewer else { return (true, nil) }
        if let jsonText = extractJSONObject(from: output),
           let data = jsonText.data(using: .utf8),
           let decoded = try? JSONDecoder().decode(ReviewerDecision.self, from: data) {
            let feedback = decoded.feedback?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
            let blockingIssues = decoded.blockingIssues?.map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }.filter { !$0.isEmpty } ?? []
            if decoded.passed == true { return (true, nil) }
            if isBlockingSeverity(decoded.severity) || !blockingIssues.isEmpty || isBlockingFeedback(feedback, for: node.kind) {
                let merged = (blockingIssues + (feedback.isEmpty ? [] : [feedback])).joined(separator: "\n")
                return (false, merged.isEmpty ? output : merged)
            }
            return (true, nil)
        }
        let lower = output.lowercased()
        if lower.contains("\"passed\":true") || lower.contains("passed: true") || lower.contains("通过") || lower.contains("合格") {
            return (true, nil)
        }
        if lower.contains("\"passed\":false") || lower.contains("passed: false") || lower.contains("不通过") || lower.contains("不合格") || lower.contains("failed") {
            return isBlockingFeedback(output, for: node.kind) ? (false, output) : (true, nil)
        }
        return (true, nil)
    }

    private func isBlockingSeverity(_ severity: String?) -> Bool {
        let text = (severity ?? "").lowercased()
        return text.contains("blocking") || text.contains("critical") || text.contains("fatal") || text.contains("blocker") || text.contains("严重") || text.contains("阻塞")
    }

    private func isBlockingFeedback(_ feedback: String, for kind: WorkflowNodeKind) -> Bool {
        let lower = feedback.lowercased()
        let sharedKeywords = [
            "blocking", "critical", "fatal", "cannot", "can't", "unable", "missing required", "not implemented",
            "阻塞", "严重", "无法", "不能", "缺少核心", "未实现核心", "完全错误", "必须返工"
        ]
        let codeKeywords = [
            "compile", "build failed", "syntax error", "type error", "cannot find", "no such module", "crash",
            "api key", "secret", "security", "xcode build", "编译", "构建失败", "语法错误", "类型错误", "找不到", "闪退", "泄露", "安全风险"
        ]
        let visualKeywords = [
            "unreadable", "invisible", "overlap", "blocked", "clipped", "看不清", "不可见", "遮挡", "重叠", "被裁切"
        ]
        var keywords = sharedKeywords
        if kind == .codeReviewer { keywords += codeKeywords }
        if kind == .visualReviewer { keywords += visualKeywords }
        return keywords.contains { lower.contains($0) }
    }

    private func extractJSONObject(from text: String) -> String? {
        guard let start = text.firstIndex(of: "{") else { return nil }
        var depth = 0
        var inString = false
        var escaping = false
        var index = start

        while index < text.endIndex {
            let ch = text[index]
            if inString {
                if escaping {
                    escaping = false
                } else if ch == "\\" {
                    escaping = true
                } else if ch == "\"" {
                    inString = false
                }
            } else {
                if ch == "\"" {
                    inString = true
                } else if ch == "{" {
                    depth += 1
                } else if ch == "}" {
                    depth -= 1
                    if depth == 0 {
                        return String(text[start...index])
                    }
                }
            }
            index = text.index(after: index)
        }
        return nil
    }


    private func localArtifactBlockingFeedback(for node: WorkflowNode, project: WorkflowProject, inputContext: String) -> String? {
        guard node.kind.isReviewer else { return nil }
        guard shouldRunWholeArtifactValidation(for: node, project: project, inputContext: inputContext) else { return nil }

        let issues = ZipArchiveService.generatedProjectValidationIssues(in: inputContext, strictWhenProjectMentioned: true)
        guard !issues.isEmpty else { return nil }

        return """
        本地最终运行包完整性校验未通过，不能放行。
        注意：该硬校验只会在检查者的直接上游是汇总者、格式转换者、项目打包者或输出模块时触发；普通分支检查者不会拿并行分支缺失文件来打回当前工作者。
        \(issues.enumerated().map { "\($0.offset + 1). \($0.element)" }.joined(separator: "\n"))
        """
    }

    private func directUpstreamNodes(for node: WorkflowNode, in project: WorkflowProject) -> [WorkflowNode] {
        project.edges
            .filter { $0.to == node.id }
            .compactMap { edge in project.nodes.first(where: { $0.id == edge.from }) }
    }

    private func shouldRunWholeArtifactValidation(for node: WorkflowNode, project: WorkflowProject, inputContext: String) -> Bool {
        guard node.kind.isReviewer else { return false }
        let upstreams = directUpstreamNodes(for: node, in: project)
        let finalKinds: Set<WorkflowNodeKind> = [.aggregator, .formatter, .filePackager, .output]
        if upstreams.contains(where: { finalKinds.contains($0.kind) }) { return true }

        let titleSignals = ["汇总", "整合", "打包", "格式转换", "最终", "输出", "package", "final", "formatter", "generated"]
        let upstreamTitleText = upstreams.map { "\($0.title) \($0.kind.title)" }.joined(separator: " ").lowercased()
        if titleSignals.contains(where: { upstreamTitleText.contains($0.lowercased()) }) { return true }

        // 只有完全没有直接上游信息的旧项目，才根据输入里的强最终产物信号兜底。
        // 不再因为普通代码工作者输出中提到“项目/博客/Hugo/Next.js”就触发整包校验。
        if upstreams.isEmpty {
            let lower = inputContext.lowercased()
            let strongFinalHints = ["项目打包者", "格式转换者", "运行包", "最终产物", "最终输出", "generated/", "file packager", "formatter", "final artifact", "final package", "generated package"]
            return strongFinalHints.contains { lower.contains($0) }
        }
        return false
    }

    private func reviewerScopeGuide(for node: WorkflowNode, project: WorkflowProject) -> String {
        guard node.kind.isReviewer else { return "" }
        let upstreams = directUpstreamNodes(for: node, in: project)
        let upstreamSummary = upstreams.isEmpty
            ? "未找到直接上游模块。"
            : upstreams.map { "- \($0.title)｜类型：\($0.kind.title)" }.joined(separator: "\n")

        if shouldRunWholeArtifactValidation(for: node, project: project, inputContext: "") {
            return """
            你是最终/整合阶段检查者。你的直接上游是汇总者、格式转换者、项目打包者或输出模块，因此可以检查最终可交付产物是否完整可运行。
            直接上游：
            \(upstreamSummary)
            检查重点：最终文件清单、入口文件、配置文件、依赖、资源路径、文件类型是否匹配、README 说明是否可执行。若是 Hugo/Next.js/静态博客，只按当前上游声明的技术栈检查，不要混用其他技术栈规则。
            """
        }

        return """
        你是局部分支检查者，只能检查直接上游模块自己的输出，不能检查并行工作者、其他分支或未来整合包。
        直接上游：
        \(upstreamSummary)
        严禁因为缺少并行分支负责的文件而判不通过。例如：代码工作者2只负责 lib/posts.ts 和 content/posts/*.md 时，不能因为缺 package.json、tailwind.config.ts、app/layout.tsx 而打回；文档工作者只负责 README 时，不能要求它补项目源码。
        你只能因直接上游输出本身的阻塞问题打回：它自己的 ownedFiles 缺失、它自己的代码语法/依赖明显错误、它越权覆盖其他工作者文件、它违反自己的 mustNotDo、泄露密钥或严重偏离本模块 assignment。
        若发现问题属于其他工作者或最终整合阶段，只能在 blockingIssues 里不列为阻塞，最终仍应 passed=true，让汇总/打包后的最终检查者处理。
        """
    }

    private func reviewerPassThroughOutput(inputContext: String) -> String {
        let artifactContext = upstreamArtifactContextForPassThrough(from: inputContext)
        let artifactText = artifactContext.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
            ? "（未识别到上游真实产物。后续汇总者/格式转换者必须报错，不能仅凭 passed JSON 重新生成项目。）"
            : artifactContext
        return """
        {"passed":true,"severity":"pass","feedback":"","blockingIssues":[]}

        # 已通过检查的上游完整产物
        以下是该检查者实际检查并确认通过的上游内容。后续汇总者、格式转换者、项目打包者必须继续使用这些真实产物；不能只读取 passed JSON，也不能重新脑补一个新项目。

        \(artifactText)
        """
    }

    private func upstreamArtifactContextForPassThrough(from inputContext: String) -> String {
        guard let range = inputContext.range(of: "# 上游 AI 交流上下文") else { return inputContext }
        var text = String(inputContext[range.lowerBound...])
        if let end = text.range(of: "\n\n# 返工意见 / review_notes") {
            text = String(text[..<end.lowerBound])
        }
        if let end = text.range(of: "\n\n# 执行要求") {
            text = String(text[..<end.lowerBound])
        }
        return text
    }

    private func resolveUpstreamQuestionsIfNeeded(
        node: WorkflowNode,
        initial: AITextResponse,
        context: String,
        system: String,
        config: APIProviderConfig,
        apiKey: String,
        model: String,
        settings: AppSettings,
        aiClient: AIClient,
        outputTokenLimit: Int? = nil
    ) async throws -> AITextResponse {
        guard !node.kind.isReviewer, outputRequestsUpstreamAnswer(initial.text) else { return initial }

        let clarificationPrompt = """
        当前模块第一次输出中包含对上游的追问。下面提供的是运行引擎整理出的上游回复上下文。

        # 当前模块
        \(node.title)（\(node.kind.title)）

        # 当前模块第一次输出 / 追问
        \(initial.text)

        # 上游回复上下文
        上游模块不会重新运行；请根据下面这些已完成的上游输出回答追问并继续完成当前模块任务：
        \(context)

        # 最终输出要求
        - 不要只重复问题。
        - 先用一小段“上游回复摘要”说明你如何理解上游回复。
        - 然后给出当前模块的最终完整输出。
        - 如果你是格式转换者，多上游输入必须输出 FILE_FORMAT_PLAN，并输出真实 ```file path="..." 文件块。
        - 如果仍有不确定内容，给出合理默认选择，不要让工作流空等。
        """
        let messages = [
            AIMessage(role: "system", content: system),
            AIMessage(role: "user", content: clarificationPrompt)
        ]
        let reply = try await aiClient.completeText(
            baseURL: config.baseURL,
            apiKey: apiKey,
            model: model,
            messages: messages,
            maxTokens: outputTokenLimit ?? effectiveOutputTokenLimit(for: node),
            temperature: min(node.temperature, 0.4),
            timeoutSeconds: effectiveTimeout(for: node, apiConfigs: [config], settings: settings),
            thinkingModeType: thinkingModeType(for: node, config: config, model: model, settings: settings)
        )
        return AITextResponse(text: reply.text, tokenUsage: initial.tokenUsage + reply.tokenUsage)
    }

    private func outputRequestsUpstreamAnswer(_ text: String) -> Bool {
        let lower = text.lowercased()
        let markers = [
            "ask_upstream", "ask upstream", "upstream question", "question for upstream",
            "向上游询问", "询问上游", "需要上游", "上游问题", "请上游", "需要确认上游"
        ]
        return markers.contains { lower.contains($0) }
    }

    private func withTimeout<T>(seconds: Int, operation: @escaping () async throws -> T) async throws -> T {
        try await withThrowingTaskGroup(of: T.self) { group in
            group.addTask { try await operation() }
            group.addTask {
                try await Task.sleep(nanoseconds: UInt64(max(seconds, 1)) * 1_000_000_000)
                throw WorkflowEngineError.apiTimeout("实际 AI 调用/模块执行超过 \(seconds) 秒没有返回，已自动停止。上游等待时间不会计入这个 timeout；请检查网络、Base URL、模型名或把该模块超时时间调大。")
            }
            guard let result = try await group.next() else { throw WorkflowEngineError.cancelled }
            group.cancelAll()
            return result
        }
    }

    private func latestCombinedOutput(project: WorkflowProject, contextByNode: [UUID: String]) -> String {
        project.nodes.compactMap { node in
            guard let output = contextByNode[node.id] else { return nil }
            return "## \(node.title)\n\(output)"
        }.joined(separator: "\n\n")
    }

    private func appendLog(_ record: inout RunRecord, _ level: LogLevel, _ nodeTitle: String?, _ message: String) {
        record.logs.append(RunLogEntry(level: level, nodeTitle: nodeTitle, message: message))
        record.lastLogAt = Date()
        record.diagnosticMessage = message
    }
}
