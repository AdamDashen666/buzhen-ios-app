import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView {
            GenerationView()
                .tabItem {
                    Label("生成", systemImage: "sparkles")
                }

            HistoryView()
                .tabItem {
                    Label("历史", systemImage: "photo.stack")
                }

            SettingsView()
                .tabItem {
                    Label("设置", systemImage: "gearshape")
                }
        }
    }
}

#Preview {
    ContentView()
        .environmentObject(AppSettings())
        .environmentObject(HistoryStore())
        .environmentObject(GenerationTaskStore())
}
