import SwiftUI

struct SettingsView: View {
    @EnvironmentObject private var settings: AppSettings
    @State private var isRefreshing = false
    @State private var statusText = ""
    @State private var alertMessage: String?

    private let client = APIClient()

    var body: some View {
        NavigationStack {
            Form {
                Section("API 配置") {
                    TextField("Base URL", text: $settings.baseURL)
                        .keyboardType(.URL)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()

                    SecureField("API Key", text: $settings.apiKey)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()

                    HStack {
                        Button {
                            Task { await refreshModels() }
                        } label: {
                            if isRefreshing {
                                Label("刷新中...", systemImage: "arrow.clockwise")
                            } else {
                                Label("刷新模型", systemImage: "arrow.clockwise")
                            }
                        }
                        .disabled(isRefreshing || settings.apiKey.isEmpty || settings.baseURL.isEmpty)

                        Spacer()

                        Button("恢复默认模型") {
                            settings.useFallbackModels()
                            statusText = "已载入默认模型列表"
                        }
                    }

                    if !statusText.isEmpty {
                        Text(statusText)
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                    }
                }

                Section("选择模型") {
                    Picker("当前模型", selection: $settings.selectedModel) {
                        ForEach(settings.availableModels) { model in
                            Text(model.id).tag(model.id)
                        }
                    }

                    ForEach(settings.availableModels) { model in
                        HStack(alignment: .top) {
                            VStack(alignment: .leading, spacing: 4) {
                                Text(model.id)
                                    .fontWeight(model.id == settings.selectedModel ? .bold : .regular)
                                if let ownedBy = model.ownedBy, !ownedBy.isEmpty {
                                    Text(ownedBy)
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                }
                            }
                            Spacer()
                            if model.id == settings.selectedModel {
                                Image(systemName: "checkmark.circle.fill")
                                    .foregroundStyle(.blue)
                            }
                        }
                        .contentShape(Rectangle())
                        .onTapGesture {
                            settings.selectedModel = model.id
                        }
                    }
                }

                Section("兼容选项") {
                    Toggle("优先请求 b64_json 返回", isOn: $settings.preferB64JSON)
                    Toggle("发送 quality 参数", isOn: $settings.sendQualityParameter)
                    HStack {
                        Text("超时秒数")
                        Slider(value: $settings.timeoutSeconds, in: 60...600, step: 30)
                        Text("\(Int(settings.timeoutSeconds))s")
                            .foregroundStyle(.secondary)
                    }
                    Text("APIYI 的 gpt-image-2-vip 示例返回 url；如果某个中转只返回 base64，可以打开 b64_json。quality 参数默认不发送，避免 VIP 线路不兼容。")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }

                Section("默认说明") {
                    Text("默认 Base URL 已写入：https://api.apiyi.com/v1")
                    Text("推荐模型：gpt-image-2-vip；4K 横屏尺寸：3840x2160。")
                }
            }
            .navigationTitle("设置")
            .alert("提示", isPresented: Binding(get: { alertMessage != nil }, set: { if !$0 { alertMessage = nil } })) {
                Button("好", role: .cancel) { alertMessage = nil }
            } message: {
                Text(alertMessage ?? "")
            }
        }
    }

    private func refreshModels() async {
        guard !settings.apiKey.isEmpty else {
            alertMessage = "请先输入 API Key。"
            return
        }
        isRefreshing = true
        statusText = "正在请求 \(settings.normalizedBaseURL())/models"
        defer { isRefreshing = false }

        do {
            let models = try await client.refreshModels(baseURL: settings.normalizedBaseURL(), apiKey: settings.apiKey, timeout: settings.timeoutSeconds)
            settings.availableModels = models
            if !models.contains(where: { $0.id == settings.selectedModel }) {
                settings.selectedModel = models.first?.id ?? "gpt-image-2-vip"
            }
            statusText = "刷新成功：\(models.count) 个模型"
        } catch {
            statusText = "刷新失败，保留原模型列表"
            alertMessage = error.localizedDescription
        }
    }
}
