import SwiftUI
import UIKit

struct CardView<Content: View>: View {
    let content: Content

    init(@ViewBuilder content: () -> Content) {
        self.content = content()
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            content
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 22, style: .continuous)
                .stroke(.primary.opacity(0.06), lineWidth: 1)
        )
    }
}

struct Badge: View {
    let text: String
    let systemImage: String

    var body: some View {
        Label(text, systemImage: systemImage)
            .font(.caption.weight(.medium))
            .padding(.horizontal, 10)
            .padding(.vertical, 6)
            .background(.blue.opacity(0.12), in: Capsule())
            .foregroundStyle(.blue)
    }
}

struct ResultCard: View {
    let record: GeneratedImageRecord
    @State private var saveMessage: String?

    var body: some View {
        CardView {
            VStack(alignment: .leading, spacing: 12) {
                HStack {
                    Label("生成结果", systemImage: "checkmark.seal.fill")
                        .font(.headline)
                    Spacer()
                    ShareLink(item: record.fileURL) {
                        Label("分享 / 保存", systemImage: "square.and.arrow.up")
                    }
                }

                if let uiImage = UIImage(contentsOfFile: record.fileURL.path) {
                    Image(uiImage: uiImage)
                        .resizable()
                        .scaledToFit()
                        .frame(maxWidth: .infinity)
                        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))

                    HStack(spacing: 10) {
                        Button {
                            UIImageWriteToSavedPhotosAlbum(uiImage, nil, nil, nil)
                            saveMessage = "已请求保存到相册"
                        } label: {
                            Label("保存到相册", systemImage: "square.and.arrow.down")
                        }
                        .buttonStyle(.bordered)

                        ShareLink(item: record.fileURL) {
                            Label("导出文件", systemImage: "doc")
                        }
                        .buttonStyle(.borderedProminent)
                    }
                }

                Text("模型：\(record.model) · 尺寸：\(record.size)")
                    .font(.footnote)
                    .foregroundStyle(.secondary)

                if let revised = record.revisedPrompt, !revised.isEmpty {
                    DisclosureGroup("Revised prompt") {
                        Text(revised)
                            .font(.footnote)
                            .textSelection(.enabled)
                    }
                }

                if let saveMessage {
                    Text(saveMessage)
                        .font(.footnote)
                        .foregroundStyle(.green)
                }
            }
        }
    }
}
