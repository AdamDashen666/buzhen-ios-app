import SwiftUI
import PhotosUI
import UniformTypeIdentifiers
import UIKit

@MainActor
final class GenerationTaskStore: ObservableObject {
    @Published private(set) var tasks: [GenerationTaskItem] = []

    private let client = APIClient()
    private let maxConcurrent = 3
    private var runningIDs: Set<UUID> = []
    private var workerTasks: [UUID: Task<Void, Never>] = [:]
    private var payloads: [UUID: GenerationTaskPayload] = [:]

    var activeCount: Int {
        tasks.filter { $0.status == .queued || $0.status == .running }.count
    }

    func enqueue(payload: GenerationTaskPayload, historyStore: HistoryStore) {
        let item = GenerationTaskItem(prompt: payload.prompt, model: payload.model, size: payload.size)
        tasks.insert(item, at: 0)
        payloads[item.id] = payload
        pumpQueue(historyStore: historyStore)
    }

    func clearFinished() {
        let finishedIDs = tasks.filter { [.completed, .failed, .cancelled].contains($0.status) }.map(\.id)
        for id in finishedIDs { payloads[id] = nil }
        tasks.removeAll { [.completed, .failed, .cancelled].contains($0.status) }
    }

    func cancel(_ taskID: UUID) {
        workerTasks[taskID]?.cancel()
        workerTasks[taskID] = nil
        runningIDs.remove(taskID)
        update(taskID) { task in
            task.status = .cancelled
            task.progress = 0
            task.statusMessage = "任务已取消"
        }
        pumpQueue(historyStore: nil)
    }

    private func pumpQueue(historyStore: HistoryStore?) {
        guard let historyStore else { return }
        while runningIDs.count < maxConcurrent,
              let next = tasks.first(where: { $0.status == .queued }),
              let payload = payloads[next.id] {
            start(next.id, payload: payload, historyStore: historyStore)
        }
    }

    private func start(_ taskID: UUID, payload: GenerationTaskPayload, historyStore: HistoryStore) {
        guard !runningIDs.contains(taskID) else { return }
        runningIDs.insert(taskID)
        update(taskID) { task in
            task.status = .running
            task.progress = 0.08
            task.statusMessage = payload.request.references.isEmpty ? "正在提交文生图请求…" : "正在上传图片并创建任务…"
        }

        let worker = Task { [weak self] in
            guard let self else { return }
            let progressLoop = Task { [weak self] in
                guard let self else { return }
                while !Task.isCancelled {
                    try? await Task.sleep(for: .seconds(1))
                    await self.bumpProgress(taskID)
                }
            }

            defer {
                progressLoop.cancel()
                Task { @MainActor [weak self] in
                    guard let self else { return }
                    self.runningIDs.remove(taskID)
                    self.workerTasks[taskID] = nil
                    self.pumpQueue(historyStore: historyStore)
                }
            }

            do {
                let (imageData, revisedPrompt) = try await client.generate(payload.request)
                try Task.checkCancellation()
                let record = try await MainActor.run {
                    try historyStore.add(imageData: imageData,
                                         prompt: payload.prompt,
                                         model: payload.model,
                                         size: payload.size,
                                         revisedPrompt: revisedPrompt)
                }
                await MainActor.run {
                    self.update(taskID) { task in
                        task.status = .completed
                        task.progress = 1
                        task.statusMessage = "生成完成，可下载 / 分享"
                        task.revisedPrompt = revisedPrompt
                        task.record = record
                        task.errorMessage = nil
                    }
                }
            } catch is CancellationError {
                await MainActor.run {
                    self.update(taskID) { task in
                        task.status = .cancelled
                        task.progress = 0
                        task.statusMessage = "任务已取消"
                    }
                }
            } catch {
                await MainActor.run {
                    self.update(taskID) { task in
                        task.status = .failed
                        task.progress = 1
                        task.statusMessage = "生成失败"
                        task.errorMessage = error.localizedDescription
                    }
                }
            }
        }
        workerTasks[taskID] = worker
    }

    private func bumpProgress(_ taskID: UUID) async {
        await MainActor.run {
            update(taskID) { task in
                guard task.status == .running else { return }
                let next = min(task.progress + 0.06, 0.92)
                task.progress = next
                if next < 0.22 {
                    task.statusMessage = "任务已创建，等待接口响应…"
                } else if next < 0.52 {
                    task.statusMessage = "接口正在处理中…"
                } else if next < 0.82 {
                    task.statusMessage = "正在生成图片…"
                } else {
                    task.statusMessage = "正在整理结果…"
                }
            }
        }
    }

    private func update(_ taskID: UUID, mutate: (inout GenerationTaskItem) -> Void) {
        guard let index = tasks.firstIndex(where: { $0.id == taskID }) else { return }
        var item = tasks[index]
        mutate(&item)
        tasks[index] = item
    }
}

struct GenerationView: View {
    @EnvironmentObject private var settings: AppSettings
    @EnvironmentObject private var historyStore: HistoryStore
    @EnvironmentObject private var taskStore: GenerationTaskStore

    @State private var prompt = ""
    @State private var selectedPreset = ImageSizePreset.auto
    @State private var customSize = ""
    @State private var quality = ImageQuality.auto
    @State private var references: [SelectedReferenceImage] = []
    @State private var photoItems: [PhotosPickerItem] = []
    @State private var showingFileImporter = false
    @State private var alertMessage: String?

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 18) {
                    headerCard
                    promptCard
                    referenceCard
                    outputCard
                    generateCard
                    taskListCard
                }
                .padding()
            }
            .navigationTitle("Image2Forge")
            .toolbar {
                NavigationLink(destination: SettingsView()) {
                    Label("设置", systemImage: "gearshape")
                }
            }
            .fileImporter(isPresented: $showingFileImporter, allowedContentTypes: [.image], allowsMultipleSelection: true) { result in
                Task { await importFiles(result) }
            }
            .onChange(of: photoItems.count) { _, _ in
                Task { await importPhotoItems(photoItems) }
            }
            .alert("提示", isPresented: Binding(get: { alertMessage != nil }, set: { if !$0 { alertMessage = nil } })) {
                Button("好", role: .cancel) { alertMessage = nil }
            } message: {
                Text(alertMessage ?? "")
            }
        }
    }

    private var headerCard: some View {
        CardView {
            VStack(alignment: .leading, spacing: 10) {
                HStack {
                    Image(systemName: "sparkles.rectangle.stack.fill")
                        .font(.largeTitle)
                        .foregroundStyle(.blue)
                    VStack(alignment: .leading, spacing: 4) {
                        Text("GPT Image 2 API 生成器")
                            .font(.title2.bold())
                        Text("默认 APIYI：\(settings.normalizedBaseURL())")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                            .lineLimit(1)
                    }
                    Spacer()
                }

                HStack(spacing: 8) {
                    Badge(text: settings.selectedModel.isEmpty ? "未选模型" : settings.selectedModel, systemImage: "cpu")
                    Badge(text: resolvedSize(), systemImage: "rectangle.compress.vertical")
                    Badge(text: "任务 \(taskStore.activeCount)", systemImage: "list.bullet.clipboard")
                }
            }
        }
    }

    private var promptCard: some View {
        CardView {
            VStack(alignment: .leading, spacing: 12) {
                Label("提示词", systemImage: "text.alignleft")
                    .font(.headline)
                TextEditor(text: $prompt)
                    .frame(minHeight: 160)
                    .padding(8)
                    .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 14))
                    .overlay(alignment: .topLeading) {
                        if prompt.isEmpty {
                            Text("输入图片描述，例如：电影级真实城市街拍，雨后地面反光，清新通透，细节丰富...")
                                .foregroundStyle(.secondary)
                                .padding(.top, 16)
                                .padding(.leading, 14)
                                .allowsHitTesting(false)
                        }
                    }
            }
        }
    }

    private var referenceCard: some View {
        CardView {
            VStack(alignment: .leading, spacing: 12) {
                HStack {
                    Label("参考图片 / 上传图片", systemImage: "photo.on.rectangle")
                        .font(.headline)
                    Spacer()
                    if !references.isEmpty {
                        Button("清空") { references.removeAll() }
                            .buttonStyle(.borderless)
                    }
                }

                HStack {
                    PhotosPicker(selection: $photoItems, maxSelectionCount: 8, matching: .images) {
                        Label("从相册选择", systemImage: "photo")
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.borderedProminent)

                    Button {
                        showingFileImporter = true
                    } label: {
                        Label("从文件选择", systemImage: "folder")
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.bordered)
                }

                if references.isEmpty {
                    Text("不上传图片就是文生图；上传图片后会走图片编辑 / 参考图模式。")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                } else {
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 10) {
                            ForEach(references) { item in
                                ZStack(alignment: .topTrailing) {
                                    if let uiImage = item.uiImage {
                                        Image(uiImage: uiImage)
                                            .resizable()
                                            .scaledToFill()
                                            .frame(width: 96, height: 96)
                                            .clipShape(RoundedRectangle(cornerRadius: 14))
                                    } else {
                                        RoundedRectangle(cornerRadius: 14)
                                            .fill(.secondary.opacity(0.15))
                                            .frame(width: 96, height: 96)
                                            .overlay(Image(systemName: "photo"))
                                    }

                                    Button {
                                        references.removeAll { $0.id == item.id }
                                    } label: {
                                        Image(systemName: "xmark.circle.fill")
                                            .symbolRenderingMode(.palette)
                                            .foregroundStyle(.white, .black.opacity(0.65))
                                    }
                                    .padding(6)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    private var outputCard: some View {
        CardView {
            VStack(alignment: .leading, spacing: 14) {
                Label("输出设置", systemImage: "slider.horizontal.3")
                    .font(.headline)

                Picker("分辨率", selection: $selectedPreset) {
                    ForEach(ImageSizePreset.presets) { preset in
                        Text(preset.displayTitle).tag(preset)
                    }
                }
                .pickerStyle(.navigationLink)

                HStack {
                    Text("自定义尺寸")
                    TextField("例如 3840x2160", text: $customSize)
                        .textInputAutocapitalization(.never)
                        .keyboardType(.numbersAndPunctuation)
                        .multilineTextAlignment(.trailing)
                }

                Picker("质量参数", selection: $quality) {
                    ForEach(ImageQuality.allCases) { item in
                        Text(item.title).tag(item)
                    }
                }
                .disabled(!settings.sendQualityParameter)

                Text("当前实际 size：\(resolvedSize())。留空自定义时，自动按图片比例适配；无图片默认 3840x2160。上传图片走 /images/edits 时，gpt-image-2-vip 会自动忽略 quality 参数，只用 size 锁定尺寸。")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
            }
        }
    }

    private var generateCard: some View {
        CardView {
            VStack(alignment: .leading, spacing: 12) {
                Button(action: createTask) {
                    HStack {
                        Image(systemName: "plus.circle.fill")
                        Text("开始生成（创建任务）")
                            .fontWeight(.semibold)
                    }
                    .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)
                .controlSize(.large)
                .disabled(prompt.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || settings.apiKey.isEmpty || settings.selectedModel.isEmpty)

                Text("点击后会立刻创建新任务，后台生成；不会堵住其他任务。默认最多同时并行 3 个，超出的会自动排队。")
                    .font(.footnote)
                    .foregroundStyle(.secondary)

                if settings.apiKey.isEmpty {
                    Text("还没填 API Key：去设置页输入后再创建任务。")
                        .foregroundStyle(.orange)
                        .font(.footnote)
                }
            }
        }
    }

    private var taskListCard: some View {
        CardView {
            VStack(alignment: .leading, spacing: 14) {
                HStack {
                    Label("任务列表", systemImage: "list.bullet.rectangle")
                        .font(.headline)
                    Spacer()
                    if !taskStore.tasks.isEmpty {
                        Button("清空已结束") {
                            taskStore.clearFinished()
                        }
                        .buttonStyle(.borderless)
                    }
                }

                if taskStore.tasks.isEmpty {
                    Text("还没有任务。开始生成后，这里会显示排队、进度、完成状态，以及下载 / 分享入口。")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                } else {
                    LazyVStack(spacing: 12) {
                        ForEach(taskStore.tasks) { item in
                            TaskRow(task: item, onCancel: { taskStore.cancel(item.id) })
                        }
                    }
                }
            }
        }
    }

    private func createTask() {
        let cleanPrompt = prompt.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleanPrompt.isEmpty else { return }
        guard !settings.apiKey.isEmpty else {
            alertMessage = "请先在设置里输入 API Key。"
            return
        }

        let payload = GenerationTaskPayload(
            request: APIClient.GenerationRequest(
                baseURL: settings.normalizedBaseURL(),
                apiKey: settings.apiKey,
                model: settings.selectedModel,
                prompt: cleanPrompt,
                size: resolvedSize(),
                quality: quality,
                sendQuality: settings.sendQualityParameter,
                preferB64JSON: settings.preferB64JSON,
                references: references,
                timeout: settings.timeoutSeconds
            ),
            prompt: cleanPrompt,
            model: settings.selectedModel,
            size: resolvedSize()
        )
        taskStore.enqueue(payload: payload, historyStore: historyStore)
        alertMessage = "已创建任务，去任务列表看进度。"
    }

    private func resolvedSize() -> String {
        let custom = customSize.trimmingCharacters(in: .whitespacesAndNewlines)
        if isValidSize(custom) { return custom }
        if let size = selectedPreset.size { return size }
        guard let ratio = references.first?.aspectRatio else { return "3840x2160" }
        if ratio > 1.55 { return "3840x2160" }
        if ratio < 0.70 { return "2160x3840" }
        if ratio > 1.20 { return "3520x2336" }
        if ratio < 0.88 { return "2336x3520" }
        return "2880x2880"
    }

    private func isValidSize(_ value: String) -> Bool {
        let parts = value.lowercased().split(separator: "x")
        guard parts.count == 2, let width = Int(parts[0]), let height = Int(parts[1]) else { return false }
        return width > 0 && height > 0 && width % 16 == 0 && height % 16 == 0
    }

    private func importPhotoItems(_ items: [PhotosPickerItem]) async {
        guard !items.isEmpty else { return }
        var imported: [SelectedReferenceImage] = []
        for (index, item) in items.enumerated() {
            if let data = try? await item.loadTransferable(type: Data.self) {
                imported.append(SelectedReferenceImage(data: data, fileName: "photo_\(index + 1).png"))
            }
        }
        references.append(contentsOf: imported)
        photoItems = []
    }

    private func importFiles(_ result: Result<[URL], Error>) async {
        switch result {
        case .success(let urls):
            var imported: [SelectedReferenceImage] = []
            for url in urls {
                let didStart = url.startAccessingSecurityScopedResource()
                defer { if didStart { url.stopAccessingSecurityScopedResource() } }
                if let data = try? Data(contentsOf: url) {
                    imported.append(SelectedReferenceImage(data: data, fileName: url.lastPathComponent))
                }
            }
            references.append(contentsOf: imported)
        case .failure(let error):
            alertMessage = error.localizedDescription
        }
    }
}

private struct TaskRow: View {
    let task: GenerationTaskItem
    let onCancel: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(alignment: .top) {
                VStack(alignment: .leading, spacing: 6) {
                    Text(task.prompt)
                        .font(.headline)
                        .lineLimit(2)
                    Text("\(task.model) · \(task.size)")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                Spacer()
                StatusBadge(status: task.status)
            }

            ProgressView(value: task.progress)
                .progressViewStyle(.linear)

            Text(task.statusMessage)
                .font(.footnote)
                .foregroundStyle(.secondary)

            if let errorMessage = task.errorMessage, !errorMessage.isEmpty {
                Text(errorMessage)
                    .font(.footnote)
                    .foregroundStyle(.red)
                    .textSelection(.enabled)
            }

            if let record = task.record, let image = UIImage(contentsOfFile: record.fileURL.path) {
                let pixels = Int(image.size.width * image.scale) * Int(image.size.height * image.scale)
                let mp = Double(pixels) / 1_000_000.0
                Text("实际输出：\(Int(image.size.width * image.scale))×\(Int(image.size.height * image.scale)) · \(String(format: "%.2f", mp))MP")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
                    .textSelection(.enabled)
            }

            HStack {
                if task.status == .queued || task.status == .running {
                    Button(role: .destructive, action: onCancel) {
                        Label("取消", systemImage: "xmark.circle")
                    }
                    .buttonStyle(.bordered)
                }

                if let record = task.record {
                    Button {
                        if let image = UIImage(contentsOfFile: record.fileURL.path) {
                            UIImageWriteToSavedPhotosAlbum(image, nil, nil, nil)
                        }
                    } label: {
                        Label("保存", systemImage: "square.and.arrow.down")
                    }
                    .buttonStyle(.bordered)

                    ShareLink(item: record.fileURL) {
                        Label("下载 / 分享", systemImage: "square.and.arrow.up")
                    }
                    .buttonStyle(.borderedProminent)
                }
            }
        }
        .padding(14)
        .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 18))
    }
}

private struct StatusBadge: View {
    let status: GenerationTaskStatus

    var body: some View {
        Text(status.title)
            .font(.caption.bold())
            .padding(.horizontal, 10)
            .padding(.vertical, 6)
            .background(backgroundColor, in: Capsule())
            .foregroundStyle(foregroundColor)
    }

    private var backgroundColor: Color {
        switch status {
        case .queued: return .gray.opacity(0.15)
        case .running: return .blue.opacity(0.15)
        case .completed: return .green.opacity(0.18)
        case .failed: return .red.opacity(0.15)
        case .cancelled: return .orange.opacity(0.15)
        }
    }

    private var foregroundColor: Color {
        switch status {
        case .queued: return .secondary
        case .running: return .blue
        case .completed: return .green
        case .failed: return .red
        case .cancelled: return .orange
        }
    }
}
