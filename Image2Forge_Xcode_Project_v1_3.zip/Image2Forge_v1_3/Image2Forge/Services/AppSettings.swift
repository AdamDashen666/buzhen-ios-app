import Foundation
import Combine

@MainActor
final class AppSettings: ObservableObject {
    @Published var baseURL: String {
        didSet { UserDefaults.standard.set(baseURL, forKey: Keys.baseURL) }
    }

    @Published var apiKey: String {
        didSet { KeychainHelper.shared.save(apiKey, account: Keys.apiKey) }
    }

    @Published var selectedModel: String {
        didSet { UserDefaults.standard.set(selectedModel, forKey: Keys.selectedModel) }
    }

    @Published var availableModels: [APIModel] {
        didSet {
            if let encoded = try? JSONEncoder().encode(availableModels) {
                UserDefaults.standard.set(encoded, forKey: Keys.availableModels)
            }
        }
    }

    @Published var preferB64JSON: Bool {
        didSet { UserDefaults.standard.set(preferB64JSON, forKey: Keys.preferB64JSON) }
    }

    @Published var sendQualityParameter: Bool {
        didSet { UserDefaults.standard.set(sendQualityParameter, forKey: Keys.sendQualityParameter) }
    }

    @Published var timeoutSeconds: Double {
        didSet { UserDefaults.standard.set(timeoutSeconds, forKey: Keys.timeoutSeconds) }
    }

    init() {
        self.baseURL = UserDefaults.standard.string(forKey: Keys.baseURL) ?? "https://api.apiyi.com/v1"
        self.apiKey = KeychainHelper.shared.read(account: Keys.apiKey)
        self.selectedModel = UserDefaults.standard.string(forKey: Keys.selectedModel) ?? "gpt-image-2-vip"
        self.preferB64JSON = UserDefaults.standard.object(forKey: Keys.preferB64JSON) as? Bool ?? false
        self.sendQualityParameter = UserDefaults.standard.object(forKey: Keys.sendQualityParameter) as? Bool ?? false
        self.timeoutSeconds = UserDefaults.standard.object(forKey: Keys.timeoutSeconds) as? Double ?? 180

        if let data = UserDefaults.standard.data(forKey: Keys.availableModels),
           let decoded = try? JSONDecoder().decode([APIModel].self, from: data),
           !decoded.isEmpty {
            self.availableModels = decoded
        } else {
            self.availableModels = AppSettings.fallbackModels
        }
    }

    func useFallbackModels() {
        availableModels = AppSettings.fallbackModels
        if selectedModel.isEmpty {
            selectedModel = "gpt-image-2-vip"
        }
    }

    func normalizedBaseURL() -> String {
        baseURL.trimmingCharacters(in: .whitespacesAndNewlines).trimmedTrailingSlash()
    }

    static let fallbackModels: [APIModel] = [
        APIModel(id: "gpt-image-2-vip", ownedBy: "APIYI 推荐：可锁定 size，适合便宜 4K"),
        APIModel(id: "gpt-image-2", ownedBy: "官方线：更正规，通常更贵"),
        APIModel(id: "gpt-image-2-all", ownedBy: "逆向线：可能不保证 size"),
        APIModel(id: "chatgpt-image-latest", ownedBy: "兼容别名：不优先推荐")
    ]

    private enum Keys {
        static let baseURL = "baseURL"
        static let apiKey = "apiKey"
        static let selectedModel = "selectedModel"
        static let availableModels = "availableModels"
        static let preferB64JSON = "preferB64JSON"
        static let sendQualityParameter = "sendQualityParameter"
        static let timeoutSeconds = "timeoutSeconds"
    }
}

extension String {
    func trimmedTrailingSlash() -> String {
        var value = self
        while value.hasSuffix("/") {
            value.removeLast()
        }
        return value
    }
}
