# API Notes

## Base URL

默认：

```text
https://api.apiyi.com/v1
```

App 会自动去掉末尾 `/`，再拼接：

```text
/models
/images/generations
/images/edits
```

## 文生图 JSON 示例

```json
{
  "model": "gpt-image-2-vip",
  "prompt": "A cinematic city street after rain...",
  "size": "3840x2160",
  "n": 1
}
```

## 参考图 / 编辑模式

App 使用 multipart/form-data：

- `model`
- `prompt`
- `size`
- `n`
- `image` 或多图 `image[]`

## 返回解析

App 同时兼容：

- `data[0].url`
- `data[0].b64_json`
- `data[0].revised_prompt`

## 4K 预设

- `3840x2160`：16:9 横屏 4K
- `2160x3840`：9:16 竖屏 4K
- `2880x2880`：1:1 方图 4K，约 8.29MP
- `3520x2336`：3:2 照片 4K
- `2336x3520`：2:3 海报 4K


## v1.3 上传图片 4K 修复说明

APIYI `gpt-image-2-vip` 的 `/v1/images/edits` 文档要求：

- 多图上传时重复字段名 `image`，不要用 `image[]`
- `quality` 在图片编辑接口会被拒绝，所以 App 对上传图片模式不再发送 `quality`
- `n` 在图片编辑接口会被拒绝，所以 App 对上传图片模式不再发送 `n`
- 明确发送 `response_format=url`，避免默认 `b64_json` 导致大图返回处理不稳定
- 如果返回 `b64_json` 带 `data:image/png;base64,` 前缀，App 会自动剥离前缀再解码
