# KieTopazGlass v1

一个 KIE.ai Topaz Video Upscale 测试版 iOS/iPadOS SwiftUI App。

## 功能

- Liquid Glass 风格 SwiftUI 界面，适配 iPhone / iPad。
- 支持选择本地视频，先上传到 KIE 临时文件服务。
- 支持直接粘贴公开视频 URL。
- 支持 KIE Topaz 参数：
  - `upscale_factor`: `1` / `2` / `4`
  - `nsfw_checker`: `true` / `false`
  - `callBackUrl`: 可选
- 创建任务：`POST https://api.kie.ai/api/v1/jobs/createTask`
- 查询任务：`GET https://api.kie.ai/api/v1/jobs/recordInfo?taskId=...`
- 上传文件：`POST https://kieai.redpandaai.co/api/file-stream-upload`
- 有上传/下载进度；云端进度只有在 KIE 返回 `progress` 时显示，否则显示不确定进度。
- 结果视频可下载到 App Documents，并通过系统分享面板保存到文件。

## 使用方式

1. 用 Xcode 打开 `KieTopazGlass.xcodeproj`。
2. 选择你的 Team，修改 Bundle Identifier。
3. 真机运行。
4. 在 App 里填 KIE API Key。
5. 选择视频或粘贴视频 URL。
6. 选择 1× / 2× / 4×，点击开始。

## 注意

- KIE Topaz Playground 标注最大文件 50MB，所以 App 默认限制本地上传为 50MB。
- API Key 现在保存在本机 `AppStorage`，测试方便；正式版建议改成你的后端代理，避免 Key 泄露。
- KIE 文档没有公开目标分辨率、目标帧率参数，所以 v1 没有做这些假选项。
- 云端视频会上传给第三方，敏感视频不要传。
