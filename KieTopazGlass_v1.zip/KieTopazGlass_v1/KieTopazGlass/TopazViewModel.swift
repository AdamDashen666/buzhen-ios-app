import Foundation
import SwiftUI

@MainActor
final class TopazViewModel: ObservableObject {
    @AppStorage("kie_api_key") var apiKey = ""
    @AppStorage("kie_public_video_url") var publicVideoURL = ""
    @AppStorage("kie_upscale_factor") var upscaleFactor = "2"
    @AppStorage("kie_nsfw_checker") var nsfwChecker = true
    @AppStorage("kie_callback_url") var callbackURL = ""
    @AppStorage("kie_create_endpoint") var createEndpoint = "https://api.kie.ai/api/v1/jobs/createTask"
    @AppStorage("kie_query_endpoint") var queryEndpoint = "https://api.kie.ai/api/v1/jobs/recordInfo"
    @AppStorage("kie_upload_endpoint") var uploadEndpoint = "https://kieai.redpandaai.co/api/file-stream-upload"
    @AppStorage("kie_upload_path") var uploadPath = "videos/kie-topaz"
    @AppStorage("kie_max_upload_mb") var maxUploadMB = 50.0
    @AppStorage("kie_poll_interval") var pollInterval = 5.0

    @Published var pickedVideo: PickedVideo?
    @Published var phase: JobPhase = .idle
    @Published var uploadProgress: Double?
    @Published var cloudProgress: Double?
    @Published var downloadProgress: Double?
    @Published var taskId = ""
    @Published var stateText = ""
    @Published var resultURL = ""
    @Published var localResultURL: URL?
    @Published var logLines: [String] = ["准备就绪"]
    @Published var errorMessage = ""
    @Published var isWorking = false

    private var runningTask: Task<Void, Never>?

    var canStart: Bool {
        !isWorking && !apiKey.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty && (pickedVideo != nil || !publicVideoURL.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
    }

    var client: KieClient {
        KieClient(apiKey: apiKey, createTaskEndpoint: createEndpoint, queryEndpoint: queryEndpoint, uploadEndpoint: uploadEndpoint, uploadPath: uploadPath)
    }

    func setVideo(_ video: PickedVideo) {
        pickedVideo = video
        publicVideoURL = ""
        localResultURL = nil
        resultURL = ""
        phase = .idle
        errorMessage = ""
        log("已选择：\(video.fileName) · \(video.fileSizeText)")
    }

    func start() {
        guard !isWorking else { return }
        errorMessage = ""
        localResultURL = nil
        resultURL = ""
        taskId = ""
        stateText = ""
        uploadProgress = nil
        cloudProgress = nil
        downloadProgress = nil
        isWorking = true
        runningTask = Task { [weak self] in
            guard let self else { return }
            do {
                try await runPipeline()
            } catch is CancellationError {
                finishWithError(KieError.cancelled.localizedDescription)
            } catch {
                finishWithError(error.localizedDescription)
            }
        }
    }

    func cancel() {
        runningTask?.cancel()
        runningTask = nil
        isWorking = false
        phase = .idle
        log("已取消")
    }

    func downloadResult() {
        guard !resultURL.isEmpty, !isWorking else { return }
        isWorking = true
        phase = .downloading
        downloadProgress = nil
        runningTask = Task { [weak self] in
            guard let self else { return }
            do {
                let url = try await client.downloadResult(from: resultURL) { [weak self] value in
                    self?.downloadProgress = value
                }
                localResultURL = url
                phase = .downloaded
                isWorking = false
                log("已下载到：\(url.lastPathComponent)")
            } catch {
                finishWithError(error.localizedDescription)
            }
        }
    }

    private func runPipeline() async throws {
        try client.validateAPIKey()
        let videoURL: String
        if let pickedVideo {
            let limit = Int64(maxUploadMB * 1024 * 1024)
            if pickedVideo.fileSize > limit {
                throw KieError.fileTooLarge("当前 \(pickedVideo.fileSizeText)，限制 \(Int(maxUploadMB))MB。KIE Playground 标注 Topaz 最大 50MB，建议先压缩或切片。")
            }
            phase = .uploading
            log("开始上传本地视频")
            let safeName = sanitizedFileName(pickedVideo.fileName)
            videoURL = try await client.uploadVideo(fileURL: pickedVideo.url, preferredName: safeName) { [weak self] value in
                self?.uploadProgress = value
            }
            log("上传完成")
        } else {
            let input = publicVideoURL.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !input.isEmpty else { throw KieError.noVideoInput }
            videoURL = input
            log("使用公开视频 URL")
        }

        try Task.checkCancellation()
        phase = .creatingTask
        log("创建 Topaz 任务：\(upscaleFactor)x")
        let createdId = try await client.createTopazTask(videoURL: videoURL, upscaleFactor: upscaleFactor, nsfwChecker: nsfwChecker, callbackURL: callbackURL)
        taskId = createdId
        log("任务 ID：\(createdId)")

        phase = .polling
        let started = Date()
        let maxSeconds: TimeInterval = 15 * 60
        var currentInterval = max(2, pollInterval)

        while true {
            try Task.checkCancellation()
            if Date().timeIntervalSince(started) > maxSeconds {
                throw KieError.queryFailed("超过 15 分钟仍未完成，建议稍后用任务 ID 继续查询。")
            }

            let detail = try await client.queryTask(taskId: createdId)
            let state = detail.state ?? "unknown"
            stateText = state
            if let p = detail.progress {
                cloudProgress = Double(max(0, min(100, p))) / 100.0
            }
            log("状态：\(state)" + (detail.progress != nil ? " · \(detail.progress!)%" : ""))

            if state == "success" {
                guard let url = URLTools.firstURL(in: detail.resultJson) else { throw KieError.noResultURL }
                resultURL = url
                phase = .success
                isWorking = false
                log("处理完成")
                return
            }

            if state == "fail" {
                throw KieError.taskFailed(detail.failMsg?.isEmpty == false ? detail.failMsg! : (detail.failCode ?? "未知错误"))
            }

            try await Task.sleep(nanoseconds: UInt64(currentInterval * 1_000_000_000))
            currentInterval = min(15, currentInterval + 1)
        }
    }

    private func finishWithError(_ message: String) {
        errorMessage = message
        phase = .failed
        isWorking = false
        log("错误：\(message)")
    }

    func log(_ text: String) {
        let time = DateFormatter.localizedString(from: Date(), dateStyle: .none, timeStyle: .medium)
        logLines.insert("[\(time)] \(text)", at: 0)
        if logLines.count > 80 { logLines.removeLast(logLines.count - 80) }
    }

    private func sanitizedFileName(_ name: String) -> String {
        let allowed = CharacterSet.alphanumerics.union(CharacterSet(charactersIn: "._-"))
        let cleaned = String(name.unicodeScalars.map { allowed.contains($0) ? Character($0) : Character("_") })
        if cleaned.lowercased().hasSuffix(".mp4") || cleaned.lowercased().hasSuffix(".mov") || cleaned.lowercased().hasSuffix(".mkv") {
            return "topaz_\(Int(Date().timeIntervalSince1970))_\(cleaned)"
        }
        return "topaz_\(Int(Date().timeIntervalSince1970))_input.mp4"
    }
}
