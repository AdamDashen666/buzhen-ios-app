import SwiftUI
import UniformTypeIdentifiers

struct VideoDocumentPicker: UIViewControllerRepresentable {
    var onPick: (PickedVideo) -> Void
    var onError: (String) -> Void

    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        var types: [UTType] = [.movie, .mpeg4Movie, .quickTimeMovie]
        if let mkv = UTType(filenameExtension: "mkv") { types.append(mkv) }
        let picker = UIDocumentPickerViewController(forOpeningContentTypes: types, asCopy: true)
        picker.delegate = context.coordinator
        picker.allowsMultipleSelection = false
        return picker
    }

    func updateUIViewController(_ uiViewController: UIDocumentPickerViewController, context: Context) {}

    func makeCoordinator() -> Coordinator { Coordinator(parent: self) }

    final class Coordinator: NSObject, UIDocumentPickerDelegate {
        let parent: VideoDocumentPicker
        init(parent: VideoDocumentPicker) { self.parent = parent }

        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            guard let original = urls.first else { return }
            let hasAccess = original.startAccessingSecurityScopedResource()
            defer { if hasAccess { original.stopAccessingSecurityScopedResource() } }

            do {
                let fileName = original.lastPathComponent.isEmpty ? "input.mp4" : original.lastPathComponent
                let tempURL = FileManager.default.temporaryDirectory
                    .appendingPathComponent("KieTopazInput_\(UUID().uuidString)_\(fileName)")
                if FileManager.default.fileExists(atPath: tempURL.path) {
                    try FileManager.default.removeItem(at: tempURL)
                }
                try FileManager.default.copyItem(at: original, to: tempURL)
                let attributes = try FileManager.default.attributesOfItem(atPath: tempURL.path)
                let size = (attributes[.size] as? NSNumber)?.int64Value ?? 0
                parent.onPick(PickedVideo(url: tempURL, fileName: fileName, fileSize: size))
            } catch {
                parent.onError(error.localizedDescription)
            }
        }
    }
}
