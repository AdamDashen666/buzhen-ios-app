import SwiftUI

@main
struct KieTopazGlassApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
