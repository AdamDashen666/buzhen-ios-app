import SwiftUI

struct ContentView: View {
    @StateObject private var vm = TopazViewModel()
    @State private var showPicker = false
    @State private var showAdvanced = false

    var body: some View {
        ZStack {
            LiquidBackground()

            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    header
                    inputCard
                    settingsCard
                    statusCard
                    resultCard
                    advancedCard
                    logCard
                }
                .padding(.horizontal, horizontalPadding)
                .padding(.vertical, 22)
                .frame(maxWidth: 980)
                .frame(maxWidth: .infinity)
            }
        }
        .sheet(isPresented: $showPicker) {
            VideoDocumentPicker { video in
                vm.setVideo(video)
                showPicker = false
            } onError: { message in
                vm.errorMessage = message
                showPicker = false
            }
        }
    }

    private var horizontalPadding: CGFloat {
        UIDevice.current.userInterfaceIdiom == .pad ? 34 : 16
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(alignment: .center, spacing: 14) {
                ZStack {
                    RoundedRectangle(cornerRadius: 22, style: .continuous)
                        .fill(.white.opacity(0.12))
                        .frame(width: 62, height: 62)
                        .overlay(RoundedRectangle(cornerRadius: 22).stroke(.white.opacity(0.24), lineWidth: 1))
                    Image(systemName: "play.rectangle.on.rectangle.fill")
                        .font(.system(size: 29, weight: .bold))
                        .foregroundStyle(.cyan)
                }
                VStack(alignment: .leading, spacing: 4) {
                    Text("KIE Topaz Upscale")
                        .font(.largeTitle.bold())
                        .foregroundStyle(.white)
                    Text("Liquid Glass · Cloud Video Upscaler")
                        .foregroundStyle(.white.opacity(0.62))
                }
                Spacer(minLength: 0)
            }
            HStack(spacing: 8) {
                CapsuleLabel(text: "topaz/video-upscale", systemImage: "sparkles")
                CapsuleLabel(text: "1× / 2× / 4×", systemImage: "arrow.up.left.and.arrow.down.right")
                CapsuleLabel(text: "iPhone + iPad", systemImage: "iphone.gen3")
            }
            .lineLimit(1)
            .minimumScaleFactor(0.7)
        }
    }

    private var inputCard: some View {
        GlassCard {
            SectionHeader(title: "输入视频", subtitle: "本地视频会先上传到 KIE 临时文件服务；也可以直接填公开视频 URL。")

            if let video = vm.pickedVideo {
                HStack(spacing: 12) {
                    Image(systemName: "film.stack.fill")
                        .font(.title2)
                        .foregroundStyle(.cyan)
                    VStack(alignment: .leading, spacing: 4) {
                        Text(video.fileName).font(.headline).foregroundStyle(.white)
                        Text(video.fileSizeText).font(.footnote).foregroundStyle(.white.opacity(0.62))
                    }
                    Spacer()
                }
                .padding(14)
                .background(.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
            }

            HStack(spacing: 12) {
                Button {
                    showPicker = true
                } label: {
                    Label("选择视频", systemImage: "folder.badge.plus")
                        .fontWeight(.bold)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 13)
                        .background(.white.opacity(0.12), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                        .overlay(RoundedRectangle(cornerRadius: 16).stroke(.white.opacity(0.18), lineWidth: 1))
                }
                .buttonStyle(.plain)
                .foregroundStyle(.white)

                Button {
                    vm.pickedVideo = nil
                } label: {
                    Image(systemName: "xmark")
                        .font(.headline)
                        .frame(width: 48, height: 48)
                        .background(.white.opacity(0.10), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                }
                .buttonStyle(.plain)
                .foregroundStyle(.white.opacity(0.88))
            }

            TextField("或粘贴公开视频 URL，例如 https://.../input.mp4", text: $vm.publicVideoURL, axis: .vertical)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .foregroundStyle(.white)
                .padding(14)
                .background(.black.opacity(0.23), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: 16).stroke(.white.opacity(0.15), lineWidth: 1))
        }
    }

    private var settingsCard: some View {
        GlassCard {
            SectionHeader(title: "Topaz 参数", subtitle: "KIE 公开支持的参数。没有公开目标分辨率/FPS 参数，所以这里不加假选项。")

            Picker("放大倍率", selection: $vm.upscaleFactor) {
                Text("1× 增强").tag("1")
                Text("2×").tag("2")
                Text("4×").tag("4")
            }
            .pickerStyle(.segmented)

            Toggle(isOn: $vm.nsfwChecker) {
                VStack(alignment: .leading, spacing: 3) {
                    Text("NSFW Checker")
                        .foregroundStyle(.white)
                    Text("对应 KIE Playground 里的 nsfw_checker。")
                        .font(.caption)
                        .foregroundStyle(.white.opacity(0.58))
                }
            }
            .tint(.cyan)

            SecureField("KIE API Key", text: $vm.apiKey)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .foregroundStyle(.white)
                .padding(14)
                .background(.black.opacity(0.23), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: 16).stroke(.white.opacity(0.15), lineWidth: 1))

            TextField("Callback URL，可不填", text: $vm.callbackURL)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .foregroundStyle(.white)
                .padding(14)
                .background(.black.opacity(0.23), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: 16).stroke(.white.opacity(0.15), lineWidth: 1))

            HStack(spacing: 12) {
                PrimaryButton(title: vm.isWorking ? "处理中" : "开始云端超分", systemImage: "wand.and.stars", disabled: !vm.canStart) {
                    vm.start()
                }
                if vm.isWorking {
                    Button(role: .destructive) { vm.cancel() } label: {
                        Image(systemName: "stop.fill")
                            .frame(width: 48, height: 48)
                            .background(.red.opacity(0.20), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                    }
                    .buttonStyle(.plain)
                    .foregroundStyle(.red.opacity(0.95))
                }
            }
        }
    }

    private var statusCard: some View {
        GlassCard {
            SectionHeader(title: "任务状态", subtitle: vm.taskId.isEmpty ? "未创建任务" : "Task ID：\(vm.taskId)")
            HStack {
                CapsuleLabel(text: vm.phase.title, systemImage: statusIcon)
                if !vm.stateText.isEmpty { CapsuleLabel(text: vm.stateText, systemImage: "cloud") }
                Spacer()
            }
            if vm.phase == .uploading || vm.uploadProgress != nil {
                ThinProgressView(title: "上传进度", value: vm.uploadProgress)
            }
            if vm.phase == .polling || vm.cloudProgress != nil {
                ThinProgressView(title: "云端进度", value: vm.cloudProgress)
            }
            if vm.phase == .downloading || vm.downloadProgress != nil {
                ThinProgressView(title: "下载进度", value: vm.downloadProgress)
            }
            if !vm.errorMessage.isEmpty {
                Text(vm.errorMessage)
                    .font(.footnote.weight(.semibold))
                    .foregroundStyle(.red.opacity(0.95))
                    .padding(12)
                    .background(.red.opacity(0.12), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
            }
        }
    }

    private var resultCard: some View {
        GlassCard {
            SectionHeader(title: "结果下载", subtitle: vm.resultURL.isEmpty ? "任务成功后会出现结果链接。" : "KIE 结果链接通常有时效，建议尽快下载。")

            if !vm.resultURL.isEmpty {
                Text(vm.resultURL)
                    .font(.caption.monospaced())
                    .foregroundStyle(.white.opacity(0.72))
                    .lineLimit(4)
                    .textSelection(.enabled)
                    .padding(12)
                    .background(.black.opacity(0.24), in: RoundedRectangle(cornerRadius: 14, style: .continuous))

                PrimaryButton(title: "下载到 App 文档", systemImage: "arrow.down.circle.fill", disabled: vm.isWorking) {
                    vm.downloadResult()
                }
            }

            if let local = vm.localResultURL {
                HStack(spacing: 12) {
                    Image(systemName: "checkmark.seal.fill").foregroundStyle(.green)
                    VStack(alignment: .leading, spacing: 4) {
                        Text("已保存：\(local.lastPathComponent)").foregroundStyle(.white)
                        Text(local.path).font(.caption2).foregroundStyle(.white.opacity(0.50)).lineLimit(2)
                    }
                    Spacer()
                }
                ShareLink(item: local) {
                    Label("分享 / 保存到文件", systemImage: "square.and.arrow.up")
                        .fontWeight(.bold)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 13)
                        .background(.white.opacity(0.12), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                }
                .foregroundStyle(.white)
            }
        }
    }

    private var advancedCard: some View {
        GlassCard {
            DisclosureGroup(isExpanded: $showAdvanced) {
                VStack(spacing: 10) {
                    field("Create Task Endpoint", text: $vm.createEndpoint)
                    field("Query Endpoint", text: $vm.queryEndpoint)
                    field("Upload Endpoint", text: $vm.uploadEndpoint)
                    field("Upload Path", text: $vm.uploadPath)
                    HStack {
                        Text("本地上传限制 MB")
                            .foregroundStyle(.white.opacity(0.72))
                        Spacer()
                        TextField("50", value: $vm.maxUploadMB, format: .number)
                            .keyboardType(.decimalPad)
                            .multilineTextAlignment(.trailing)
                            .foregroundStyle(.white)
                            .frame(width: 90)
                            .padding(10)
                            .background(.black.opacity(0.23), in: RoundedRectangle(cornerRadius: 12))
                    }
                    HStack {
                        Text("轮询间隔 秒")
                            .foregroundStyle(.white.opacity(0.72))
                        Spacer()
                        TextField("5", value: $vm.pollInterval, format: .number)
                            .keyboardType(.decimalPad)
                            .multilineTextAlignment(.trailing)
                            .foregroundStyle(.white)
                            .frame(width: 90)
                            .padding(10)
                            .background(.black.opacity(0.23), in: RoundedRectangle(cornerRadius: 12))
                    }
                }
                .padding(.top, 10)
            } label: {
                SectionHeader(title: "高级设置", subtitle: "默认已填 KIE 官方端点；一般不用改。")
            }
            .tint(.cyan)
        }
    }

    private var logCard: some View {
        GlassCard {
            SectionHeader(title: "运行日志", subtitle: "用于排查上传、创建任务、轮询和下载问题。")
            VStack(alignment: .leading, spacing: 6) {
                ForEach(Array(vm.logLines.prefix(12).enumerated()), id: \.offset) { _, line in
                    Text(line)
                        .font(.caption.monospaced())
                        .foregroundStyle(.white.opacity(0.68))
                        .textSelection(.enabled)
                }
            }
        }
    }

    private var statusIcon: String {
        switch vm.phase {
        case .idle: return "circle"
        case .uploading: return "arrow.up.circle"
        case .creatingTask: return "plus.circle"
        case .polling: return "cloud"
        case .success: return "checkmark.circle"
        case .failed: return "exclamationmark.triangle"
        case .downloading: return "arrow.down.circle"
        case .downloaded: return "checkmark.seal"
        }
    }

    private func field(_ title: String, text: Binding<String>) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(title)
                .font(.caption.weight(.semibold))
                .foregroundStyle(.white.opacity(0.58))
            TextField(title, text: text)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .foregroundStyle(.white)
                .padding(12)
                .background(.black.opacity(0.23), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: 14).stroke(.white.opacity(0.12), lineWidth: 1))
        }
    }
}
