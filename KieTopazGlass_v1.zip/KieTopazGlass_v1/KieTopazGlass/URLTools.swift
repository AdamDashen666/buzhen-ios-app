import Foundation

enum URLTools {
    static func appendQuery(_ name: String, value: String, to endpoint: String) throws -> URL {
        guard var components = URLComponents(string: endpoint) else {
            throw KieError.invalidURL(endpoint)
        }
        var items = components.queryItems ?? []
        items.removeAll { $0.name == name }
        items.append(URLQueryItem(name: name, value: value))
        components.queryItems = items
        guard let url = components.url else { throw KieError.invalidURL(endpoint) }
        return url
    }

    static func firstURL(in jsonString: String?) -> String? {
        guard let jsonString, let data = jsonString.data(using: .utf8) else { return nil }
        guard let object = try? JSONSerialization.jsonObject(with: data) else { return nil }
        return firstURL(in: object)
    }

    private static func firstURL(in value: Any) -> String? {
        if let string = value as? String, string.lowercased().hasPrefix("http") {
            return string
        }
        if let array = value as? [Any] {
            for item in array {
                if let found = firstURL(in: item) { return found }
            }
        }
        if let dict = value as? [String: Any] {
            let preferredKeys = ["resultUrls", "resultUrl", "videoUrl", "video_url", "url", "downloadUrl", "fileUrl", "output", "result"]
            for key in preferredKeys {
                if let item = dict[key], let found = firstURL(in: item) { return found }
            }
            for item in dict.values {
                if let found = firstURL(in: item) { return found }
            }
        }
        return nil
    }
}

enum KieError: LocalizedError {
    case invalidURL(String)
    case missingAPIKey
    case noVideoInput
    case uploadFailed(String)
    case createTaskFailed(String)
    case queryFailed(String)
    case taskFailed(String)
    case noResultURL
    case fileTooLarge(String)
    case cancelled

    var errorDescription: String? {
        switch self {
        case .invalidURL(let s): return "URL 无效：\(s)"
        case .missingAPIKey: return "请先填写 KIE API Key"
        case .noVideoInput: return "请先选择本地视频，或填写公开视频 URL"
        case .uploadFailed(let s): return "上传失败：\(s)"
        case .createTaskFailed(let s): return "创建任务失败：\(s)"
        case .queryFailed(let s): return "查询失败：\(s)"
        case .taskFailed(let s): return "任务失败：\(s)"
        case .noResultURL: return "任务成功但没有解析到结果视频 URL"
        case .fileTooLarge(let s): return "文件过大：\(s)"
        case .cancelled: return "任务已取消"
        }
    }
}
