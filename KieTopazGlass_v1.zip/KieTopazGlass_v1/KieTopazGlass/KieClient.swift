import Foundation

struct KieClient {
    var apiKey: String
    var createTaskEndpoint: String
    var queryEndpoint: String
    var uploadEndpoint: String
    var uploadPath: String

    private var authHeaders: [String: String] {
        ["Authorization": "Bearer \(apiKey.trimmingCharacters(in: .whitespacesAndNewlines))"]
    }

    func validateAPIKey() throws {
        if apiKey.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            throw KieError.missingAPIKey
        }
    }

    func uploadVideo(fileURL: URL, preferredName: String, progress: @escaping @MainActor (Double?) -> Void) async throws -> String {
        try validateAPIKey()
        guard let url = URL(string: uploadEndpoint) else { throw KieError.invalidURL(uploadEndpoint) }

        let boundary = "Boundary-\(UUID().uuidString)"
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")

        let body = try makeMultipartBody(fileURL: fileURL, fileName: preferredName, uploadPath: uploadPath, boundary: boundary)
        let delegate = UploadDelegate(progress: progress)
        let (data, _) = try await delegate.run(request: request, body: body)

        let text = String(data: data, encoding: .utf8) ?? ""
        let decoded = try? JSONDecoder().decode(KieUploadResponse.self, from: data)
        if decoded?.success == true || decoded?.code == 200 {
            if let download = decoded?.data?.downloadUrl, !download.isEmpty { return download }
            if let file = decoded?.data?.fileUrl, !file.isEmpty { return file }
        }
        throw KieError.uploadFailed(decoded?.msg ?? text)
    }

    func createTopazTask(videoURL: String, upscaleFactor: String, nsfwChecker: Bool, callbackURL: String?) async throws -> String {
        try validateAPIKey()
        guard let url = URL(string: createTaskEndpoint) else { throw KieError.invalidURL(createTaskEndpoint) }

        var input: [String: Any] = [
            "video_url": videoURL,
            "upscale_factor": upscaleFactor,
            "nsfw_checker": nsfwChecker
        ]

        var payload: [String: Any] = [
            "model": "topaz/video-upscale",
            "input": input
        ]

        let callback = (callbackURL ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        if !callback.isEmpty { payload["callBackUrl"] = callback }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try JSONSerialization.data(withJSONObject: payload, options: [])

        let (data, _) = try await URLSession.shared.data(for: request)
        let text = String(data: data, encoding: .utf8) ?? ""
        let decoded = try? JSONDecoder().decode(KieCreateTaskResponse.self, from: data)
        if decoded?.code == 200, let taskId = decoded?.data?.taskId, !taskId.isEmpty {
            return taskId
        }
        throw KieError.createTaskFailed(decoded?.msg ?? text)
    }

    func queryTask(taskId: String) async throws -> KieTaskData {
        try validateAPIKey()
        let url = try URLTools.appendQuery("taskId", value: taskId, to: queryEndpoint)
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")

        let (data, _) = try await URLSession.shared.data(for: request)
        let text = String(data: data, encoding: .utf8) ?? ""
        let decoded = try? JSONDecoder().decode(KieTaskResponse.self, from: data)
        if let data = decoded?.data { return data }
        throw KieError.queryFailed(decoded?.msg ?? text)
    }

    func downloadResult(from urlString: String, progress: @escaping @MainActor (Double?) -> Void) async throws -> URL {
        guard let url = URL(string: urlString) else { throw KieError.invalidURL(urlString) }
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        let folder = docs.appendingPathComponent("KIE Topaz Results", isDirectory: true)
        let name = "KIE_Topaz_\(Int(Date().timeIntervalSince1970)).mp4"
        let destination = folder.appendingPathComponent(name)
        let delegate = DownloadDelegate(destination: destination, progress: progress)
        return try await delegate.run(url: url)
    }

    private func makeMultipartBody(fileURL: URL, fileName: String, uploadPath: String, boundary: String) throws -> Data {
        var body = Data()
        func append(_ string: String) {
            body.append(Data(string.utf8))
        }

        append("--\(boundary)\r\n")
        append("Content-Disposition: form-data; name=\"uploadPath\"\r\n\r\n")
        append("\(uploadPath)\r\n")

        append("--\(boundary)\r\n")
        append("Content-Disposition: form-data; name=\"fileName\"\r\n\r\n")
        append("\(fileName)\r\n")

        let mime = mimeType(for: fileName)
        append("--\(boundary)\r\n")
        append("Content-Disposition: form-data; name=\"file\"; filename=\"\(fileName)\"\r\n")
        append("Content-Type: \(mime)\r\n\r\n")
        body.append(try Data(contentsOf: fileURL))
        append("\r\n--\(boundary)--\r\n")
        return body
    }

    private func mimeType(for fileName: String) -> String {
        let lower = fileName.lowercased()
        if lower.hasSuffix(".mov") { return "video/quicktime" }
        if lower.hasSuffix(".mkv") { return "video/x-matroska" }
        return "video/mp4"
    }
}
