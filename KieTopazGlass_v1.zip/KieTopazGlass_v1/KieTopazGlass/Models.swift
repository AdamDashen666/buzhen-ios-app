import Foundation

struct KieCreateTaskResponse: Decodable {
    let code: Int?
    let msg: String?
    let data: KieCreateTaskData?
}

struct KieCreateTaskData: Decodable {
    let taskId: String?
}

struct KieTaskResponse: Decodable {
    let code: Int?
    let msg: String?
    let data: KieTaskData?
}

struct KieTaskData: Decodable {
    let taskId: String?
    let model: String?
    let state: String?
    let resultJson: String?
    let failCode: String?
    let failMsg: String?
    let costTime: Int?
    let completeTime: Int?
    let createTime: Int?
    let updateTime: Int?
    let progress: Int?
    let creditsConsumed: Int?
}

struct KieUploadResponse: Decodable {
    let success: Bool?
    let code: Int?
    let msg: String?
    let data: KieUploadData?
}

struct KieUploadData: Decodable {
    let fileId: String?
    let fileName: String?
    let originalName: String?
    let fileSize: Int?
    let mimeType: String?
    let uploadPath: String?
    let fileUrl: String?
    let downloadUrl: String?
    let expiresAt: String?
    let uploadedAt: String?
}

struct PickedVideo: Identifiable, Equatable {
    let id = UUID()
    let url: URL
    let fileName: String
    let fileSize: Int64

    var fileSizeText: String { ByteCountFormatter.string(fromByteCount: fileSize, countStyle: .file) }
}

enum JobPhase: Equatable {
    case idle
    case uploading
    case creatingTask
    case polling
    case success
    case failed
    case downloading
    case downloaded

    var title: String {
        switch self {
        case .idle: return "待开始"
        case .uploading: return "上传视频"
        case .creatingTask: return "创建任务"
        case .polling: return "云端处理"
        case .success: return "处理完成"
        case .failed: return "失败"
        case .downloading: return "下载结果"
        case .downloaded: return "已下载"
        }
    }
}
