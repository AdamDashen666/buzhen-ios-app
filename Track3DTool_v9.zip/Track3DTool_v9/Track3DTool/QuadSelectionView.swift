import SwiftUI

struct QuadSelectionView: View {
    let image: UIImage
    @Binding var points: [CGPoint]   // normalized, image-space, 0...1
    let overlayText: String
    let textScale: Double
    let textOffsetX: Double
    let textOffsetY: Double

    var body: some View {
        GeometryReader { geo in
            let imageRect = fittedRect(imageSize: image.size, container: geo.size)
            ZStack(alignment: .topLeading) {
                Image(uiImage: image)
                    .resizable()
                    .scaledToFit()
                    .frame(width: geo.size.width, height: geo.size.height)

                Path { path in
                    let display = points.map { toViewPoint($0, in: imageRect) }
                    if let first = display.first {
                        path.move(to: first)
                        for p in display.dropFirst() { path.addLine(to: p) }
                        if display.count == 4 { path.closeSubpath() }
                    }
                }
                .stroke(.yellow, lineWidth: 3)

                ForEach(Array(points.enumerated()), id: \.offset) { index, p in
                    let vp = toViewPoint(p, in: imageRect)
                    ZStack {
                        Circle().fill(.yellow).frame(width: 24, height: 24)
                        Text("\(index + 1)")
                            .font(.caption.bold())
                            .foregroundStyle(.black)
                    }
                    .position(vp)
                }

                if points.count == 4 {
                    let display = points.map { toViewPoint($0, in: imageRect) }
                    PerspectiveTextPreview(
                        text: overlayText.isEmpty ? "TEXT" : overlayText,
                        quad: display,
                        scale: textScale,
                        offsetX: textOffsetX,
                        offsetY: textOffsetY
                    )
                }
            }
            .contentShape(Rectangle())
            .gesture(
                SpatialTapGesture().onEnded { value in
                    let normalized = toNormalized(value.location, in: imageRect)
                    guard normalized.x >= 0, normalized.x <= 1, normalized.y >= 0, normalized.y <= 1 else { return }
                    if points.count >= 4 { points.removeAll() }
                    points.append(normalized)
                }
            )
        }
    }

    private func fittedRect(imageSize: CGSize, container: CGSize) -> CGRect {
        guard imageSize.width > 0, imageSize.height > 0 else { return CGRect(origin: .zero, size: container) }
        let imageAspect = imageSize.width / imageSize.height
        let containerAspect = container.width / container.height
        if imageAspect > containerAspect {
            let width = container.width
            let height = width / imageAspect
            return CGRect(x: 0, y: (container.height - height) / 2, width: width, height: height)
        } else {
            let height = container.height
            let width = height * imageAspect
            return CGRect(x: (container.width - width) / 2, y: 0, width: width, height: height)
        }
    }

    private func toNormalized(_ p: CGPoint, in rect: CGRect) -> CGPoint {
        CGPoint(x: (p.x - rect.minX) / rect.width, y: (p.y - rect.minY) / rect.height)
    }

    private func toViewPoint(_ p: CGPoint, in rect: CGRect) -> CGPoint {
        CGPoint(x: rect.minX + p.x * rect.width, y: rect.minY + p.y * rect.height)
    }
}

struct PerspectiveTextPreview: View {
    let text: String
    let quad: [CGPoint]
    let scale: Double
    let offsetX: Double
    let offsetY: Double

    var body: some View {
        if quad.count == 4 {
            let center = bilinear(u: 0.5 + CGFloat(offsetX) * 0.35, v: 0.5 + CGFloat(offsetY) * 0.35)
            Text(text)
                .font(.system(size: CGFloat(max(12.0, 22.0 * scale)), weight: .heavy))
                .foregroundStyle(.white)
                .shadow(color: .black, radius: 4, x: 0, y: 1)
                .lineLimit(3)
                .multilineTextAlignment(.center)
                .frame(width: max(120, quadWidth * CGFloat(0.65 * scale)))
                .position(center)
                .allowsHitTesting(false)
        }
    }

    private var quadWidth: CGFloat {
        guard quad.count == 4 else { return 160 }
        let top = hypot(quad[1].x - quad[0].x, quad[1].y - quad[0].y)
        let bottom = hypot(quad[2].x - quad[3].x, quad[2].y - quad[3].y)
        return max(80, (top + bottom) / 2)
    }

    private func bilinear(u rawU: CGFloat, v rawV: CGFloat) -> CGPoint {
        let u = min(max(rawU, 0.05), 0.95)
        let v = min(max(rawV, 0.05), 0.95)
        let top = CGPoint(
            x: quad[0].x + (quad[1].x - quad[0].x) * u,
            y: quad[0].y + (quad[1].y - quad[0].y) * u
        )
        let bottom = CGPoint(
            x: quad[3].x + (quad[2].x - quad[3].x) * u,
            y: quad[3].y + (quad[2].y - quad[3].y) * u
        )
        return CGPoint(
            x: top.x + (bottom.x - top.x) * v,
            y: top.y + (bottom.y - top.y) * v
        )
    }
}
