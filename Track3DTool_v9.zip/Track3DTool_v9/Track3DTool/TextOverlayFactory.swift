import UIKit
import CoreImage

struct TextOverlayFactory {
    static func make(text: String, videoSize: CGSize, settings: TextOverlaySettings = .default) -> CIImage? {
        let width = max(512, Int(videoSize.width * 0.55))
        let height = max(180, Int(CGFloat(width) * 0.34))
        let format = UIGraphicsImageRendererFormat()
        format.scale = 1
        format.opaque = false
        let renderer = UIGraphicsImageRenderer(size: CGSize(width: CGFloat(width), height: CGFloat(height)), format: format)
        let image = renderer.image { ctx in
            UIColor.clear.setFill()
            ctx.fill(CGRect(x: 0, y: 0, width: CGFloat(width), height: CGFloat(height)))

            let paragraph = NSMutableParagraphStyle()
            paragraph.alignment = .center
            paragraph.lineBreakMode = .byWordWrapping

            let clampedScale = min(max(settings.scale, 0.35), 2.50)
            let fontSize = CGFloat(width) * 0.095 * CGFloat(clampedScale)
            let attrs: [NSAttributedString.Key: Any] = [
                .font: UIFont.systemFont(ofSize: fontSize, weight: .heavy),
                .foregroundColor: UIColor.white,
                .paragraphStyle: paragraph,
                .strokeColor: UIColor.black,
                .strokeWidth: -3.0
            ]

            let xOffset = CGFloat(min(max(settings.offsetX, -1.0), 1.0)) * CGFloat(width) * 0.34
            let yOffset = CGFloat(min(max(settings.offsetY, -1.0), 1.0)) * CGFloat(height) * 0.34
            let textWidth = CGFloat(width) * min(0.92, max(0.30, 0.64 * CGFloat(clampedScale)))
            let textHeight = CGFloat(height) * min(0.92, max(0.34, 0.52 * CGFloat(clampedScale)))
            let center = CGPoint(x: CGFloat(width) / 2 + xOffset, y: CGFloat(height) / 2 + yOffset)
            let rect = CGRect(
                x: center.x - textWidth / 2,
                y: center.y - textHeight / 2,
                width: textWidth,
                height: textHeight
            )
            text.draw(with: rect, options: [.usesLineFragmentOrigin, .usesFontLeading], attributes: attrs, context: nil)
        }
        guard let cg = image.cgImage else { return nil }
        return CIImage(cgImage: cg)
    }
}
