import SwiftUI
import AVFoundation
import UniformTypeIdentifiers
import PhotosUI

private enum ActiveSheet: Identifiable {
    case fileImporter
    case photoImporter
    case shareOutput

    var id: Int {
        switch self {
        case .fileImporter: return 1
        case .photoImporter: return 2
        case .shareOutput: return 3
        }
    }
}

struct ContentView: View {
    @State private var inputURL: URL?
    @State private var firstFrame: UIImage?
    @State private var selectedQuad: [CGPoint] = []
    @State private var activeSheet: ActiveSheet?
    @State private var overlayText = "By LaoDeng666"
    @State private var status = "从文件或相册导入视频，然后拖动视频条选起始帧，再在墙/地面/屏幕平面上按顺序点 4 个角。"
    @State private var progress: Double = 0
    @State private var isRendering = false
    @State private var outputURL: URL?
    @State private var trackingQuality = TrackingQuality.high
    @State private var outputProfile = OutputProfile.h264Compatibility
    @State private var preserveAudio = true
    @State private var exportCameraSolve = true
    @State private var videoDuration: Double = 0
    @State private var previewTime: Double = 0
    @State private var isLoadingPreview = false
    @State private var previewRequestID = 0
    @State private var textScale: Double = 1.0
    @State private var textOffsetX: Double = 0.0
    @State private var textOffsetY: Double = 0.0

    var body: some View {
        NavigationStack {
            VStack(spacing: 14) {
                header
                videoArea
                controls
                statusBar
            }
            .padding()
            .navigationTitle("3D Plane Tracker v9")
            .sheet(item: $activeSheet) { sheet in
                switch sheet {
                case .fileImporter:
                    FileVideoPicker(
                        onPick: { url in
                            activeSheet = nil
                            importPickedVideo(url)
                        },
                        onCancel: {
                            activeSheet = nil
                            status = "已取消文件导入。"
                        },
                        onError: { message in
                            activeSheet = nil
                            status = "文件导入失败：\(message)"
                        }
                    )
                case .photoImporter:
                    PhotoVideoPicker(
                        onPick: { url in
                            activeSheet = nil
                            importPickedVideo(url)
                        },
                        onCancel: {
                            activeSheet = nil
                            status = "已取消相册导入。"
                        },
                        onError: { message in
                            activeSheet = nil
                            status = "相册导入失败：\(message)"
                        }
                    )
                case .shareOutput:
                    if let outputURL {
                        ShareSheet(items: [outputURL])
                    } else {
                        Text("没有可分享的导出文件")
                    }
                }
            }
        }
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("本地视频平面 3D 追踪 v9")
                .font(.title2.bold())
            Text("v9 修复一按导出就容易闪退的问题：默认安全 H.264、加入分阶段初始化/延迟保护；新增视频拖动条、文字大小和位置调整。")
                .font(.footnote)
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private var videoArea: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 18)
                .fill(.thinMaterial)
            if let image = firstFrame {
                QuadSelectionView(
                    image: image,
                    points: $selectedQuad,
                    overlayText: overlayText,
                    textScale: textScale,
                    textOffsetX: textOffsetX,
                    textOffsetY: textOffsetY
                )
                .clipShape(RoundedRectangle(cornerRadius: 18))
                if isLoadingPreview {
                    VStack(spacing: 8) {
                        ProgressView()
                        Text("正在更新预览帧")
                            .font(.caption)
                    }
                    .padding(14)
                    .background(.ultraThinMaterial)
                    .clipShape(RoundedRectangle(cornerRadius: 14))
                }
            } else {
                VStack(spacing: 12) {
                    Image(systemName: "video.badge.plus")
                        .font(.system(size: 48))
                    Text("还没有导入视频")
                        .font(.headline)
                    Text("点下面的“从文件导入”或“从相册导入”开始")
                        .foregroundStyle(.secondary)
                }
            }
        }
        .frame(maxWidth: .infinity)
        .frame(height: 420)
    }

    private var controls: some View {
        VStack(spacing: 12) {
            HStack(spacing: 10) {
                Button("从文件导入") {
                    activeSheet = .fileImporter
                }
                .buttonStyle(.borderedProminent)
                .disabled(isRendering)

                Button("从相册导入") {
                    activeSheet = .photoImporter
                }
                .buttonStyle(.bordered)
                .disabled(isRendering)

                Button("重选四点") {
                    selectedQuad.removeAll()
                }
                .buttonStyle(.bordered)
                .disabled(firstFrame == nil || isRendering)
            }

            if inputURL != nil {
                videoScrubber
            }

            TextField("贴在墙上的文字", text: $overlayText)
                .textFieldStyle(.roundedBorder)
                .disabled(isRendering)

            textControls

            Picker("追踪质量", selection: $trackingQuality) {
                ForEach(TrackingQuality.allCases, id: \.self) { q in
                    Text(q.title).tag(q)
                }
            }
            .pickerStyle(.segmented)
            .disabled(isRendering)

            Picker("导出格式", selection: $outputProfile) {
                ForEach(OutputProfile.allCases, id: \.self) { p in
                    Text(p.title).tag(p)
                }
            }
            .pickerStyle(.segmented)
            .disabled(isRendering)

            Toggle("保留原视频音频", isOn: $preserveAudio)
                .disabled(isRendering)

            Toggle("导出平面相机位姿 JSON", isOn: $exportCameraSolve)
                .disabled(isRendering)

            Button {
                render()
            } label: {
                HStack {
                    if isRendering { ProgressView().scaleEffect(0.8) }
                    Text(isRendering ? "处理中..." : "开始追踪并导出 v9")
                }
                .frame(maxWidth: .infinity)
            }
            .buttonStyle(.borderedProminent)
            .disabled(inputURL == nil || selectedQuad.count != 4 || overlayText.isEmpty || isRendering || isLoadingPreview)

            if isRendering {
                ProgressView(value: progress)
            }

            if outputURL != nil {
                Button("分享 / 保存导出视频") {
                    activeSheet = .shareOutput
                }
                .buttonStyle(.bordered)
            }
        }
    }

    private var videoScrubber: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack {
                Text("起始帧")
                    .font(.footnote.bold())
                Spacer()
                Text("\(formatTime(previewTime)) / \(formatTime(videoDuration))")
                    .font(.caption.monospacedDigit())
                    .foregroundStyle(.secondary)
            }
            Slider(
                value: $previewTime,
                in: 0...max(videoDuration, 0.01),
                onEditingChanged: { editing in
                    if !editing {
                        loadPreviewFrame(at: previewTime, clearPoints: true)
                    }
                }
            )
            .disabled(isRendering || isLoadingPreview || videoDuration <= 0)
            HStack(spacing: 10) {
                Button("-1s") { jumpPreview(by: -1) }
                    .buttonStyle(.bordered)
                Button("+1s") { jumpPreview(by: 1) }
                    .buttonStyle(.bordered)
                Button("刷新当前帧") { loadPreviewFrame(at: previewTime, clearPoints: true) }
                    .buttonStyle(.bordered)
            }
            .disabled(isRendering || isLoadingPreview)
        }
    }

    private var textControls: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text("文字大小")
                Spacer()
                Text(String(format: "%.2fx", textScale))
                    .foregroundStyle(.secondary)
                    .monospacedDigit()
            }
            Slider(value: $textScale, in: 0.35...2.50)
                .disabled(isRendering)

            HStack {
                Text("左右位置")
                Spacer()
                Text(String(format: "%.2f", textOffsetX))
                    .foregroundStyle(.secondary)
                    .monospacedDigit()
            }
            Slider(value: $textOffsetX, in: -1.0...1.0)
                .disabled(isRendering)

            HStack {
                Text("上下位置")
                Spacer()
                Text(String(format: "%.2f", textOffsetY))
                    .foregroundStyle(.secondary)
                    .monospacedDigit()
            }
            Slider(value: $textOffsetY, in: -1.0...1.0)
                .disabled(isRendering)
        }
        .font(.footnote)
    }

    private var statusBar: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(status)
                .font(.footnote)
                .foregroundStyle(.secondary)
            Text("提示：四点顺序建议为 左上 → 右上 → 右下 → 左下。视频条选的是追踪/导出的起始帧；如果一开始画面太快，先拖到稳定清晰的位置再选四点。")
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private func importPickedVideo(_ pickedURL: URL) {
        do {
            let localURL = try FileStore.copyIntoDocuments(pickedURL)
            inputURL = localURL
            firstFrame = nil
            selectedQuad.removeAll()
            outputURL = nil
            progress = 0
            previewTime = 0
            videoDuration = 0
            status = "已导入：\(localURL.lastPathComponent)。初始化 1/3：读取视频信息..."
            Task {
                do {
                    let duration = try await FirstFrameLoader.duration(url: localURL)
                    let image = try await FirstFrameLoader.load(url: localURL, at: 0)
                    await MainActor.run {
                        videoDuration = duration
                        firstFrame = image
                        status = "初始化完成。可拖动视频条选择起始帧，然后在平面上点 4 个角。"
                    }
                } catch {
                    await MainActor.run {
                        status = "读取视频失败：\(error.localizedDescription)"
                    }
                }
            }
        } catch {
            status = "导入失败：\(error.localizedDescription)"
        }
    }

    private func jumpPreview(by delta: Double) {
        let next = min(max(previewTime + delta, 0), max(videoDuration, 0))
        previewTime = next
        loadPreviewFrame(at: next, clearPoints: true)
    }

    private func loadPreviewFrame(at seconds: Double, clearPoints: Bool) {
        guard let inputURL else { return }
        previewRequestID += 1
        let requestID = previewRequestID
        let clampedSeconds = min(max(seconds, 0), max(videoDuration, 0))
        isLoadingPreview = true
        status = "正在读取 \(formatTime(clampedSeconds)) 的预览帧..."
        Task {
            do {
                let image = try await FirstFrameLoader.load(url: inputURL, at: clampedSeconds)
                await MainActor.run {
                    guard requestID == previewRequestID else { return }
                    firstFrame = image
                    previewTime = clampedSeconds
                    if clearPoints { selectedQuad.removeAll() }
                    isLoadingPreview = false
                    status = "预览帧已更新。请在当前帧上点 4 个角。"
                }
            } catch {
                await MainActor.run {
                    guard requestID == previewRequestID else { return }
                    isLoadingPreview = false
                    status = "预览帧读取失败：\(error.localizedDescription)"
                }
            }
        }
    }

    private func render() {
        guard let inputURL, selectedQuad.count == 4 else { return }
        isRendering = true
        progress = 0
        outputURL = nil
        status = "初始化 1/6：锁定当前帧、四点和文字参数..."

        let text = overlayText
        let quad = selectedQuad
        let quality = trackingQuality
        let profile = outputProfile
        let keepAudio = preserveAudio
        let solveCamera = exportCameraSolve
        let startTime = previewTime
        let overlaySettings = TextOverlaySettings(
            scale: textScale,
            offsetX: textOffsetX,
            offsetY: textOffsetY
        )

        Task {
            do {
                await setRenderProgress(0.02, "初始化 1/6：锁定当前帧、四点和文字参数...")
                try await Task.sleep(nanoseconds: 180_000_000)
                await setRenderProgress(0.04, "初始化 2/6：准备视频读取器...")
                try await Task.sleep(nanoseconds: 180_000_000)
                await setRenderProgress(0.06, "初始化 3/6：准备导出编码器...")
                try await Task.sleep(nanoseconds: 180_000_000)
                await setRenderProgress(0.08, "初始化 4/6：准备文字贴图...")
                try await Task.sleep(nanoseconds: 180_000_000)
                await setRenderProgress(0.10, "初始化 5/6：启动追踪模块...")
                try await Task.sleep(nanoseconds: 180_000_000)
                await setRenderProgress(0.12, "初始化 6/6：开始逐帧处理...")

                let url = try await VideoPlaneCompositor.render(
                    inputURL: inputURL,
                    normalizedQuad: quad,
                    overlayText: text,
                    overlaySettings: overlaySettings,
                    startTimeSeconds: startTime,
                    quality: quality,
                    outputProfile: profile,
                    preserveAudio: keepAudio,
                    exportCameraSolve: solveCamera
                ) { value, message in
                    Task { @MainActor in
                        progress = value
                        status = message
                    }
                }
                await MainActor.run {
                    outputURL = url
                    isRendering = false
                    progress = 1
                    status = "导出完成：\(url.lastPathComponent)"
                }
            } catch {
                await MainActor.run {
                    isRendering = false
                    status = "导出失败：\(error.localizedDescription)"
                }
            }
        }
    }

    @MainActor
    private func setRenderProgress(_ value: Double, _ message: String) {
        progress = value
        status = message
    }

    private func formatTime(_ seconds: Double) -> String {
        guard seconds.isFinite else { return "0:00" }
        let total = max(0, Int(seconds.rounded()))
        let minutes = total / 60
        let secs = total % 60
        return String(format: "%d:%02d", minutes, secs)
    }
}

struct ShareSheet: UIViewControllerRepresentable {
    let items: [Any]
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: items, applicationActivities: nil)
    }
    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}
