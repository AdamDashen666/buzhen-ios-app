import AVFoundation
import Combine
import Foundation

@MainActor
final class LocalLibraryStore: ObservableObject {
    @Published private(set) var songs: [SongItem] = []

    private let fileManager = FileManager.default
    private var libraryDirectory: URL {
        let docs = fileManager.urls(for: .documentDirectory, in: .userDomainMask).first!
        return docs.appendingPathComponent("MineradioLibrary", isDirectory: true)
    }
    private var indexURL: URL {
        libraryDirectory.appendingPathComponent("library.json")
    }

    func load() async {
        do {
            try createLibraryIfNeeded()
            guard fileManager.fileExists(atPath: indexURL.path) else { return }
            let data = try Data(contentsOf: indexURL)
            songs = try JSONDecoder().decode([SongItem].self, from: data)
        } catch {
            print("Library load error:", error.localizedDescription)
        }
    }

    func importAudioFile(from sourceURL: URL) async throws {
        try createLibraryIfNeeded()
        let didStart = sourceURL.startAccessingSecurityScopedResource()
        defer {
            if didStart { sourceURL.stopAccessingSecurityScopedResource() }
        }

        let ext = sourceURL.pathExtension.isEmpty ? "audio" : sourceURL.pathExtension
        let destinationName = "\(UUID().uuidString).\(ext)"
        let destinationURL = libraryDirectory.appendingPathComponent(destinationName)
        if fileManager.fileExists(atPath: destinationURL.path) {
            try fileManager.removeItem(at: destinationURL)
        }
        try fileManager.copyItem(at: sourceURL, to: destinationURL)

        let metadata = readMetadata(from: destinationURL)
        let title = metadata.title?.isEmpty == false ? metadata.title! : sourceURL.deletingPathExtension().lastPathComponent
        let artist = metadata.artist?.isEmpty == false ? metadata.artist! : "Local File"

        let item = SongItem(
            id: UUID().uuidString,
            provider: .local,
            title: title,
            artist: artist,
            album: metadata.album,
            coverURL: nil,
            localFileName: destinationName,
            remoteSongID: nil,
            remoteURL: nil
        )
        songs.insert(item, at: 0)
        try save()
    }

    func fileURL(for song: SongItem) -> URL? {
        guard let localFileName = song.localFileName else { return nil }
        return libraryDirectory.appendingPathComponent(localFileName)
    }

    func delete(_ song: SongItem) {
        if let fileURL = fileURL(for: song), fileManager.fileExists(atPath: fileURL.path) {
            try? fileManager.removeItem(at: fileURL)
        }
        songs.removeAll { $0.id == song.id }
        try? save()
    }

    private func save() throws {
        let data = try JSONEncoder().encode(songs)
        try data.write(to: indexURL, options: [.atomic])
    }

    private func createLibraryIfNeeded() throws {
        if !fileManager.fileExists(atPath: libraryDirectory.path) {
            try fileManager.createDirectory(at: libraryDirectory, withIntermediateDirectories: true)
        }
    }

    private func readMetadata(from url: URL) -> (title: String?, artist: String?, album: String?) {
        let asset = AVURLAsset(url: url)
        let metadata = asset.commonMetadata
        func value(_ identifier: AVMetadataIdentifier) -> String? {
            AVMetadataItem.metadataItems(from: metadata, filteredByIdentifier: identifier).first?.stringValue
        }
        return (
            value(.commonIdentifierTitle),
            value(.commonIdentifierArtist),
            value(.commonIdentifierAlbumName)
        )
    }
}
