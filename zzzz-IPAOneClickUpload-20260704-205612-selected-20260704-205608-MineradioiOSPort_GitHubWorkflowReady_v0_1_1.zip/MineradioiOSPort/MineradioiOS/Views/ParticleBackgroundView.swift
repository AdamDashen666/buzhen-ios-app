import SwiftUI

struct ParticleBackgroundView: View {
    private let particles = Particle.make(count: 88)

    var body: some View {
        TimelineView(.animation) { timeline in
            Canvas { context, size in
                let time = timeline.date.timeIntervalSinceReferenceDate
                let background = LinearGradient(
                    colors: [Color.black, Color(red: 0.03, green: 0.04, blue: 0.10), Color(red: 0.10, green: 0.07, blue: 0.18)],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                context.fill(Path(CGRect(origin: .zero, size: size)), with: .linearGradient(background.gradient, startPoint: .zero, endPoint: CGPoint(x: size.width, y: size.height)))

                for particle in particles {
                    let x = (particle.x + CGFloat(time * particle.speedX)).truncatingRemainder(dividingBy: max(size.width, 1))
                    let wave = sin(time * particle.waveSpeed + particle.phase) * particle.waveAmplitude
                    let y = (particle.y + CGFloat(wave)).truncatingRemainder(dividingBy: max(size.height, 1))
                    let rect = CGRect(x: x, y: y, width: particle.radius, height: particle.radius)
                    context.opacity = particle.opacity
                    context.fill(Path(ellipseIn: rect), with: .color(.white))
                }
            }
        }
        .ignoresSafeArea()
    }
}

private struct Particle {
    let x: CGFloat
    let y: CGFloat
    let radius: CGFloat
    let opacity: Double
    let speedX: Double
    let waveSpeed: Double
    let waveAmplitude: Double
    let phase: Double

    static func make(count: Int) -> [Particle] {
        (0..<count).map { index in
            Particle(
                x: CGFloat.random(in: 0...1200),
                y: CGFloat.random(in: 0...1600),
                radius: CGFloat.random(in: 1.2...4.8),
                opacity: Double.random(in: 0.12...0.72),
                speedX: Double.random(in: 2...14),
                waveSpeed: Double.random(in: 0.45...1.45),
                waveAmplitude: Double.random(in: 12...48),
                phase: Double(index) * 0.7
            )
        }
    }
}
