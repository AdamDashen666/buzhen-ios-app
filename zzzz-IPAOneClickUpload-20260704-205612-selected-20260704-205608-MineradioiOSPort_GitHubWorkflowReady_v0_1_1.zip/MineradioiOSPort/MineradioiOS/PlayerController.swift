import AVFoundation
import Combine
import Foundation

final class PlayerController: ObservableObject {
    @Published private(set) var currentSong: SongItem?
    @Published private(set) var isPlaying = false
    @Published private(set) var currentTime: TimeInterval = 0
    @Published private(set) var duration: TimeInterval = 0
    @Published var lyrics: [LyricLine] = []

    private var player: AVPlayer?
    private var timeObserver: Any?

    init() {
        configureAudioSession()
    }

    deinit {
        if let timeObserver, let player {
            player.removeTimeObserver(timeObserver)
        }
    }

    func playRemote(song: SongItem, url: URL, lyrics: [LyricLine] = []) {
        start(song: song, item: AVPlayerItem(url: url), lyrics: lyrics)
    }

    func playLocal(song: SongItem, fileURL: URL, lyrics: [LyricLine] = []) {
        start(song: song, item: AVPlayerItem(url: fileURL), lyrics: lyrics)
    }

    func togglePlayPause() {
        guard let player else { return }
        if isPlaying {
            player.pause()
            isPlaying = false
        } else {
            player.play()
            isPlaying = true
        }
    }

    func seek(to seconds: TimeInterval) {
        guard let player else { return }
        let target = CMTime(seconds: seconds, preferredTimescale: 600)
        player.seek(to: target, toleranceBefore: .zero, toleranceAfter: .zero)
    }

    var activeLyric: String {
        lyrics.last(where: { $0.time <= currentTime })?.text ?? "让音乐开始流动"
    }

    private func start(song: SongItem, item: AVPlayerItem, lyrics: [LyricLine]) {
        removeTimeObserver()
        player = AVPlayer(playerItem: item)
        currentSong = song
        currentTime = 0
        duration = 0
        self.lyrics = lyrics
        addTimeObserver()
        player?.play()
        isPlaying = true
    }

    private func addTimeObserver() {
        guard let player else { return }
        let interval = CMTime(seconds: 0.25, preferredTimescale: 600)
        timeObserver = player.addPeriodicTimeObserver(forInterval: interval, queue: .main) { [weak self] time in
            guard let self else { return }
            self.currentTime = time.seconds.isFinite ? time.seconds : 0
            if let itemDuration = player.currentItem?.duration.seconds, itemDuration.isFinite {
                self.duration = itemDuration
            }
            if player.timeControlStatus == .playing {
                self.isPlaying = true
            }
        }
    }

    private func removeTimeObserver() {
        if let timeObserver, let player {
            player.removeTimeObserver(timeObserver)
        }
        timeObserver = nil
    }

    private func configureAudioSession() {
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default, options: [.allowAirPlay, .allowBluetooth])
            try AVAudioSession.sharedInstance().setActive(true)
        } catch {
            print("Audio session error:", error.localizedDescription)
        }
    }
}
