# Changelog

## 0.1.1 - GitHub Workflow Ready

- Added shared Xcode scheme: `MineradioiOS.xcscheme`.
- Added GitHub Actions workflow for unsigned IPA build.
- Added CI hints file: `ci/PROJECT_INFO.env`.
- Fixed Xcode target membership for `SettingsView.swift`.
- Updated project marketing version to `0.1.1`.
- Added workflow usage notes.

## 0.1.0 - Initial iOS Port MVP

- Added native SwiftUI Xcode project.
- Added local audio import and playback using AVFoundation.
- Added Mineradio-style particle background and lyric stage.
- Added 3D playlist shelf cards.
- Added settings for third-party API base URLs.
- Added NetEase QR login, search, stream URL, and lyric API client.
- Added placeholder QQ / custom provider settings for future adapter work.
- Added app icon, default cover, and stage backdrop assets.
