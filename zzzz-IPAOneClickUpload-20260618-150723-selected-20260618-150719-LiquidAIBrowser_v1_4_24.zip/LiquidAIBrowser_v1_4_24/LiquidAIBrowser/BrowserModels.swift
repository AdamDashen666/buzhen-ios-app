import Foundation
import UIKit

struct BrowserGroup: Identifiable, Equatable, Codable {
    let id: UUID
    var name: String
    var createdAt: Date
    var updatedAt: Date

    init(id: UUID = UUID(), name: String = "新分组") {
        self.id = id
        self.name = name
        self.createdAt = Date()
        self.updatedAt = Date()
    }

    var displayName: String {
        let clean = name.trimmingCharacters(in: .whitespacesAndNewlines)
        return clean.isEmpty ? "新分组" : clean
    }
}

struct BrowserTab: Identifiable, Equatable, Codable {
    let id: UUID
    var groupID: UUID
    var title: String
    var urlString: String
    var isLoading: Bool
    var estimatedProgress: Double
    var createdAt: Date
    var updatedAt: Date
    var thumbnailData: Data?

    init(id: UUID = UUID(), groupID: UUID, title: String = "新页面", urlString: String = "about:blank", isLoading: Bool = false, estimatedProgress: Double = 0) {
        self.id = id
        self.groupID = groupID
        self.title = title
        self.urlString = urlString
        self.isLoading = isLoading
        self.estimatedProgress = estimatedProgress
        self.createdAt = Date()
        self.updatedAt = Date()
        self.thumbnailData = nil
    }

    enum CodingKeys: String, CodingKey {
        case id, groupID, title, urlString, isLoading, estimatedProgress, createdAt, updatedAt, thumbnailData
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        id = try container.decodeIfPresent(UUID.self, forKey: .id) ?? UUID()
        groupID = try container.decodeIfPresent(UUID.self, forKey: .groupID) ?? UUID(uuidString: "00000000-0000-0000-0000-000000000001")!
        title = try container.decodeIfPresent(String.self, forKey: .title) ?? "新页面"
        urlString = try container.decodeIfPresent(String.self, forKey: .urlString) ?? "about:blank"
        isLoading = try container.decodeIfPresent(Bool.self, forKey: .isLoading) ?? false
        estimatedProgress = try container.decodeIfPresent(Double.self, forKey: .estimatedProgress) ?? 0
        createdAt = try container.decodeIfPresent(Date.self, forKey: .createdAt) ?? Date()
        updatedAt = try container.decodeIfPresent(Date.self, forKey: .updatedAt) ?? Date()
        thumbnailData = try container.decodeIfPresent(Data.self, forKey: .thumbnailData)
    }

    var displayTitle: String {
        if !title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { return title }
        return URL(string: urlString)?.host ?? "新页面"
    }

    var thumbnailImage: UIImage? {
        guard let data = thumbnailData else { return nil }
        return UIImage(data: data)
    }
}

enum TaskStatus: String, Codable, CaseIterable, Hashable {
    case queued
    case planning
    case running
    case paused
    case waitingConfirmation
    case waitingUser
    case timerRunning
    case completed
    case failed
    case stopped

    var title: String {
        switch self {
        case .queued: return "排队中"
        case .planning: return "规划中"
        case .running: return "执行中"
        case .paused: return "已暂停"
        case .waitingConfirmation: return "等待确认"
        case .waitingUser: return "等待用户"
        case .timerRunning: return "计时中"
        case .completed: return "已完成"
        case .failed: return "失败"
        case .stopped: return "已停止"
        }
    }

    var symbolName: String {
        switch self {
        case .queued: return "clock"
        case .planning: return "wand.and.stars"
        case .running: return "play.circle.fill"
        case .paused: return "pause.circle.fill"
        case .waitingConfirmation: return "exclamationmark.triangle.fill"
        case .waitingUser: return "person.crop.circle.badge.questionmark"
        case .timerRunning: return "timer"
        case .completed: return "checkmark.circle.fill"
        case .failed: return "xmark.octagon.fill"
        case .stopped: return "stop.circle.fill"
        }
    }

    var isTerminal: Bool {
        self == .completed || self == .failed || self == .stopped
    }
}

enum TaskLogLevel: String, Codable, CaseIterable, Hashable, Identifiable {
    case info
    case action
    case visual
    case user
    case timer
    case security
    case warning
    case error

    var id: String { rawValue }

    var title: String {
        switch self {
        case .info: return "信息"
        case .action: return "动作"
        case .visual: return "视觉"
        case .user: return "用户"
        case .timer: return "计时"
        case .security: return "安全"
        case .warning: return "警告"
        case .error: return "错误"
        }
    }
}

struct TaskChecklistItem: Identifiable, Codable, Equatable {
    var id: UUID = UUID()
    var title: String
    var detail: String
    var isDone: Bool = false
    var note: String = ""
}

struct TaskLogEntry: Identifiable, Codable, Equatable {
    var id: UUID = UUID()
    var date: Date = Date()
    var level: TaskLogLevel = .info
    var elapsedSeconds: Double = 0
    var message: String
    var actionType: String? = nil
    var coordinates: String? = nil
    var result: String? = nil

    var compactLine: String {
        let time = String(format: "+%.1fs", elapsedSeconds)
        let coord = coordinates.map { " @(\($0))" } ?? ""
        let action = actionType.map { " [\($0)]" } ?? ""
        return "[\(time)] [\(level.title)]\(action)\(coord) \(message)"
    }
}

struct SnapshotFileStore {
    static var rootDirectory: URL {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first ?? FileManager.default.temporaryDirectory
        let dir = base.appendingPathComponent("TaskSnapshots", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir
    }

    static func url(for fileName: String) -> URL {
        rootDirectory.appendingPathComponent(fileName)
    }

    static func image(for fileName: String) -> UIImage? {
        let url = self.url(for: fileName)
        guard let data = try? Data(contentsOf: url) else { return nil }
        return UIImage(data: data)
    }

    static func write(data: Data, taskID: UUID, index: Int) -> (fileName: String, width: Int, height: Int, fileSize: Int) {
        let taskDirName = taskID.uuidString
        let taskDir = rootDirectory.appendingPathComponent(taskDirName, isDirectory: true)
        try? FileManager.default.createDirectory(at: taskDir, withIntermediateDirectories: true)
        let fileNameOnly = String(format: "%04d.jpg", index)
        let relative = taskDirName + "/" + fileNameOnly
        let url = taskDir.appendingPathComponent(fileNameOnly)
        try? data.write(to: url, options: [.atomic])
        let image = UIImage(data: data)
        return (relative, Int(image?.size.width ?? 0), Int(image?.size.height ?? 0), data.count)
    }

    static func removeTaskSnapshots(taskID: UUID) {
        let dir = rootDirectory.appendingPathComponent(taskID.uuidString, isDirectory: true)
        try? FileManager.default.removeItem(at: dir)
    }

    static func taskSnapshotDirectory(taskID: UUID) -> URL {
        rootDirectory.appendingPathComponent(taskID.uuidString, isDirectory: true)
    }

    static func totalSize(taskID: UUID) -> Int64 {
        let dir = taskSnapshotDirectory(taskID: taskID)
        guard let enumerator = FileManager.default.enumerator(at: dir, includingPropertiesForKeys: [.fileSizeKey], options: [.skipsHiddenFiles]) else { return 0 }
        var total: Int64 = 0
        for case let url as URL in enumerator {
            let values = try? url.resourceValues(forKeys: [.fileSizeKey])
            total += Int64(values?.fileSize ?? 0)
        }
        return total
    }

    static func removeOrphanedSnapshots(validTaskIDs: Set<UUID>) {
        let root = rootDirectory
        guard let contents = try? FileManager.default.contentsOfDirectory(at: root, includingPropertiesForKeys: [.isDirectoryKey], options: [.skipsHiddenFiles]) else { return }
        for url in contents {
            let values = try? url.resourceValues(forKeys: [.isDirectoryKey])
            guard values?.isDirectory == true else { continue }
            guard let id = UUID(uuidString: url.lastPathComponent) else {
                try? FileManager.default.removeItem(at: url)
                continue
            }
            if !validTaskIDs.contains(id) {
                try? FileManager.default.removeItem(at: url)
            }
        }
    }
}

struct TaskStepSnapshot: Identifiable, Codable, Equatable {
    var id: UUID = UUID()
    var date: Date = Date()
    var elapsedSeconds: Double = 0
    var stepIndex: Int? = nil
    var actionType: String? = nil
    var title: String
    var note: String
    var tabID: UUID
    var urlString: String
    var imageFileName: String = ""
    var width: Int = 0
    var height: Int = 0
    var fileSize: Int = 0
    var imageData: Data? = nil // backward compatibility only; not persisted for new snapshots

    var image: UIImage? {
        if !imageFileName.isEmpty, let image = SnapshotFileStore.image(for: imageFileName) { return image }
        if let imageData { return UIImage(data: imageData) }
        return nil
    }
}

enum AgentTimerMode: String, Codable, CaseIterable, Hashable {
    case countDown
    case countUp
}

enum AgentTimerStatus: String, Codable, CaseIterable, Hashable {
    case running
    case completed
    case cancelled
}


struct AgentFinding: Identifiable, Codable, Equatable {
    var id: UUID = UUID()
    var subject: String
    var status: String
    var evidence: String
    var urlString: String
    var updatedAt: Date = Date()

    var compactLine: String {
        let cleanSubject = subject.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? "未命名结论" : subject
        let cleanStatus = status.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? "unknown" : status
        return "- \(cleanSubject)：\(cleanStatus)｜\(evidence)｜\(urlString)"
    }
}

struct PlanRevision: Identifiable, Codable, Equatable {
    var id: UUID = UUID()
    var date: Date = Date()
    var reason: String
    var steps: [TaskChecklistItem]
}

struct AgentTimerEntry: Identifiable, Codable, Equatable {
    var id: UUID = UUID()
    var taskID: UUID?
    var groupID: UUID?
    var title: String
    var mode: AgentTimerMode
    var durationSeconds: Double
    var startedAt: Date
    var endsAt: Date?
    var status: AgentTimerStatus
    var note: String

    var elapsedSeconds: Double {
        max(0, Date().timeIntervalSince(startedAt))
    }

    var remainingSeconds: Double {
        guard mode == .countDown, let endsAt else { return elapsedSeconds }
        return max(0, endsAt.timeIntervalSince(Date()))
    }

    var displayTime: String {
        let seconds = Int(mode == .countDown ? remainingSeconds : elapsedSeconds)
        let m = seconds / 60
        let s = seconds % 60
        if m >= 60 { return String(format: "%d:%02d:%02d", m / 60, m % 60, s) }
        return String(format: "%02d:%02d", m, s)
    }
}

struct AgentTask: Identifiable, Equatable, Codable {
    let id: UUID
    var groupID: UUID
    var tabID: UUID
    var workingTabIDs: [UUID]
    var goal: String
    var goalAnalysis: String
    var status: TaskStatus
    var checklist: [TaskChecklistItem]
    var originalPlan: [TaskChecklistItem]
    var planHistory: [PlanRevision]
    var rawPlanResponse: String
    var log: [TaskLogEntry]
    var report: String
    var pdfReportURLString: String
    var progress: Double
    var currentAction: String
    var pendingAction: AgentAction?
    var pendingActionRisk: String
    var lastError: String
    var iteration: Int
    var maxIterations: Int
    var createdAt: Date
    var updatedAt: Date
    var startedAt: Date?
    var finishedAt: Date?
    var queueIndex: Int
    var totalActionCount: Int
    var failureCount: Int
    var lastFailureCategory: String
    var lastScreenshotAt: Date?
    var lastScreenshotData: Data?
    var stepSnapshots: [TaskStepSnapshot]
    var findings: [AgentFinding]
    var pendingUserQuestion: String
    var pendingUserInput: String
    var pendingUserPlaceholder: String

    init(id: UUID = UUID(), groupID: UUID, tabID: UUID, goal: String, maxIterations: Int, queueIndex: Int = 0) {
        self.id = id
        self.groupID = groupID
        self.tabID = tabID
        self.workingTabIDs = [tabID]
        self.goal = goal
        self.goalAnalysis = ""
        self.status = .queued
        self.checklist = []
        self.originalPlan = []
        self.planHistory = []
        self.rawPlanResponse = ""
        self.log = [TaskLogEntry(message: "任务已创建：\(goal)")]
        self.report = ""
        self.pdfReportURLString = ""
        self.progress = 0
        self.currentAction = "等待开始"
        self.pendingAction = nil
        self.pendingActionRisk = ""
        self.lastError = ""
        self.iteration = 0
        self.maxIterations = maxIterations
        self.createdAt = Date()
        self.updatedAt = Date()
        self.startedAt = nil
        self.finishedAt = nil
        self.queueIndex = queueIndex
        self.totalActionCount = 0
        self.failureCount = 0
        self.lastFailureCategory = ""
        self.lastScreenshotAt = nil
        self.lastScreenshotData = nil
        self.stepSnapshots = []
        self.findings = []
        self.pendingUserQuestion = ""
        self.pendingUserInput = ""
        self.pendingUserPlaceholder = "请输入后继续任务"
    }

    enum CodingKeys: String, CodingKey {
        case id, groupID, tabID, workingTabIDs, goal, goalAnalysis, status, checklist, originalPlan, planHistory, rawPlanResponse, log, report, pdfReportURLString, progress, currentAction, pendingAction, pendingActionRisk, lastError, iteration, maxIterations, createdAt, updatedAt, startedAt, finishedAt, queueIndex, totalActionCount, failureCount, lastFailureCategory, lastScreenshotAt, lastScreenshotData, stepSnapshots, findings, pendingUserQuestion, pendingUserInput, pendingUserPlaceholder
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        id = try container.decodeIfPresent(UUID.self, forKey: .id) ?? UUID()
        let fallbackGroupID = UUID(uuidString: "00000000-0000-0000-0000-000000000001")!
        groupID = try container.decodeIfPresent(UUID.self, forKey: .groupID) ?? fallbackGroupID
        tabID = try container.decodeIfPresent(UUID.self, forKey: .tabID) ?? UUID()
        workingTabIDs = try container.decodeIfPresent([UUID].self, forKey: .workingTabIDs) ?? [tabID]
        goal = try container.decodeIfPresent(String.self, forKey: .goal) ?? ""
        goalAnalysis = try container.decodeIfPresent(String.self, forKey: .goalAnalysis) ?? ""
        status = try container.decodeIfPresent(TaskStatus.self, forKey: .status) ?? .queued
        checklist = try container.decodeIfPresent([TaskChecklistItem].self, forKey: .checklist) ?? []
        originalPlan = try container.decodeIfPresent([TaskChecklistItem].self, forKey: .originalPlan) ?? []
        planHistory = try container.decodeIfPresent([PlanRevision].self, forKey: .planHistory) ?? []
        rawPlanResponse = try container.decodeIfPresent(String.self, forKey: .rawPlanResponse) ?? ""
        log = try container.decodeIfPresent([TaskLogEntry].self, forKey: .log) ?? []
        report = try container.decodeIfPresent(String.self, forKey: .report) ?? ""
        pdfReportURLString = try container.decodeIfPresent(String.self, forKey: .pdfReportURLString) ?? ""
        progress = try container.decodeIfPresent(Double.self, forKey: .progress) ?? 0
        currentAction = try container.decodeIfPresent(String.self, forKey: .currentAction) ?? "等待开始"
        pendingAction = try container.decodeIfPresent(AgentAction.self, forKey: .pendingAction)
        pendingActionRisk = try container.decodeIfPresent(String.self, forKey: .pendingActionRisk) ?? ""
        lastError = try container.decodeIfPresent(String.self, forKey: .lastError) ?? ""
        iteration = try container.decodeIfPresent(Int.self, forKey: .iteration) ?? 0
        maxIterations = try container.decodeIfPresent(Int.self, forKey: .maxIterations) ?? 0
        createdAt = try container.decodeIfPresent(Date.self, forKey: .createdAt) ?? Date()
        updatedAt = try container.decodeIfPresent(Date.self, forKey: .updatedAt) ?? Date()
        startedAt = try container.decodeIfPresent(Date.self, forKey: .startedAt)
        finishedAt = try container.decodeIfPresent(Date.self, forKey: .finishedAt)
        queueIndex = try container.decodeIfPresent(Int.self, forKey: .queueIndex) ?? 0
        totalActionCount = try container.decodeIfPresent(Int.self, forKey: .totalActionCount) ?? 0
        failureCount = try container.decodeIfPresent(Int.self, forKey: .failureCount) ?? 0
        lastFailureCategory = try container.decodeIfPresent(String.self, forKey: .lastFailureCategory) ?? ""
        lastScreenshotAt = try container.decodeIfPresent(Date.self, forKey: .lastScreenshotAt)
        lastScreenshotData = try container.decodeIfPresent(Data.self, forKey: .lastScreenshotData)
        stepSnapshots = try container.decodeIfPresent([TaskStepSnapshot].self, forKey: .stepSnapshots) ?? []
        findings = try container.decodeIfPresent([AgentFinding].self, forKey: .findings) ?? []
        pendingUserQuestion = try container.decodeIfPresent(String.self, forKey: .pendingUserQuestion) ?? ""
        pendingUserInput = try container.decodeIfPresent(String.self, forKey: .pendingUserInput) ?? ""
        pendingUserPlaceholder = try container.decodeIfPresent(String.self, forKey: .pendingUserPlaceholder) ?? "请输入后继续任务"
    }
}


extension AgentTask {
    var needsUserAttention: Bool {
        if status == .waitingUser || status == .waitingConfirmation { return true }
        if status == .paused {
            let combined = (currentAction + " " + lastError).lowercased()
            return combined.contains("需要用户")
                || combined.contains("需要你")
                || combined.contains("手动处理")
                || combined.contains("验证码")
                || combined.contains("权限确认")
                || combined.contains("登录")
                || combined.contains("blocked")
        }
        return false
    }

    var attentionTitle: String {
        switch status {
        case .waitingUser: return "需要输入"
        case .waitingConfirmation: return "需要确认"
        case .paused: return "AI 已暂停"
        default: return "需要处理"
        }
    }

    var attentionMessage: String {
        if !pendingUserQuestion.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { return pendingUserQuestion }
        if !lastError.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { return lastError }
        if !currentAction.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { return currentAction }
        return "AI 任务需要你处理后才能继续。"
    }
}

struct APIPreset: Identifiable, Hashable {
    var id: String { name }
    let name: String
    let baseURL: String
    let defaultModel: String
}

struct AgentAction: Codable, Equatable {
    var type: String
    var selector: String?
    var text: String?
    var value: String?
    var url: String?
    var direction: String?
    var amount: Int?
    var stepIndex: Int?
    var reason: String?
    var x: Double?
    var y: Double?
    var startX: Double?
    var startY: Double?
    var endX: Double?
    var endY: Double?
    var durationMs: Int?
    var tabID: String?
    var tabHint: String?
    var groupName: String?
    var key: String?
    var modifiers: [String]?
    var question: String? = nil
    var placeholder: String? = nil
    var message: String? = nil
    var timerID: String? = nil
    var durationSeconds: Double? = nil
    var timerMode: String? = nil
    var title: String? = nil
    var allowDuplicate: Bool? = nil
    var allowRepeatedInput: Bool? = nil
    var expectedCount: Int? = nil
    var repeatCount: Int? = nil
    var inputCount: Int? = nil
}

struct AgentDecision: Codable {
    var status: String? = nil
    var summary: String? = nil
    var completedStepIndexes: [Int]? = nil
    var action: AgentAction? = nil
    var report: String? = nil
    var goalAnalysis: String? = nil
    var updatedSteps: [AgentPlanResponse.Step]? = nil
    var restartPlan: Bool? = nil
    var findings: [AgentFinding]? = nil
}

struct AgentVerification: Codable {
    var ok: Bool
    var summary: String
    var report: String?
    var missingSteps: [AgentPlanResponse.Step]?
}

struct AgentPlanResponse: Codable {
    struct Step: Codable {
        var title: String
        var detail: String?
    }
    var goalAnalysis: String?
    var steps: [Step]
}

struct AgentActionResult: Codable {
    var ok: Bool
    var message: String
    var category: String?
    var x: Double?
    var y: Double?
    var targetText: String?
    var tabID: UUID? = nil
}

struct AISettingsSnapshot {
    let apiKey: String
    let baseURL: String
    let model: String
    let temperature: Double
    let requestTimeout: Double
    let useJSONMode: Bool
    let enableVisionScreenshots: Bool
    let allowCoordinateFallback: Bool
    let maxActionRetries: Int
}

struct ShareItem: Identifiable {
    let id = UUID()
    let url: URL
}

// MARK: - Flexible AI JSON decoding
// v1.4.13: Some OpenAI-compatible providers occasionally return numeric/bool fields
// as strings, or mix array item types. A strict Codable decode then drops the whole
// decision and causes long "format unstable" retry loops. These flexible decoders
// keep the agent moving by normalizing common type mismatches locally.
private struct FlexibleCodingKey: CodingKey {
    var stringValue: String
    var intValue: Int?
    init?(stringValue: String) { self.stringValue = stringValue; self.intValue = nil }
    init?(intValue: Int) { self.stringValue = String(intValue); self.intValue = intValue }
    init(_ string: String) { self.stringValue = string; self.intValue = nil }
}

private extension KeyedDecodingContainer where Key == FlexibleCodingKey {
    func string(_ key: String) -> String? {
        let k = FlexibleCodingKey(key)
        if let value = try? decode(String.self, forKey: k) { return value }
        if let value = try? decode(Int.self, forKey: k) { return String(value) }
        if let value = try? decode(Double.self, forKey: k) { return String(value) }
        if let value = try? decode(Bool.self, forKey: k) { return value ? "true" : "false" }
        return nil
    }

    func int(_ key: String) -> Int? {
        let k = FlexibleCodingKey(key)
        if let value = try? decode(Int.self, forKey: k) { return value }
        if let value = try? decode(Double.self, forKey: k) { return Int(value) }
        if let value = try? decode(String.self, forKey: k) { return Int(value.trimmingCharacters(in: .whitespacesAndNewlines)) }
        return nil
    }

    func double(_ key: String) -> Double? {
        let k = FlexibleCodingKey(key)
        if let value = try? decode(Double.self, forKey: k) { return value }
        if let value = try? decode(Int.self, forKey: k) { return Double(value) }
        if let value = try? decode(String.self, forKey: k) { return Double(value.trimmingCharacters(in: .whitespacesAndNewlines)) }
        return nil
    }

    func bool(_ key: String) -> Bool? {
        let k = FlexibleCodingKey(key)
        if let value = try? decode(Bool.self, forKey: k) { return value }
        if let value = try? decode(Int.self, forKey: k) { return value != 0 }
        if let value = try? decode(String.self, forKey: k) {
            let lower = value.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
            if ["true", "yes", "1", "是"].contains(lower) { return true }
            if ["false", "no", "0", "否"].contains(lower) { return false }
        }
        return nil
    }

    func stringArray(_ key: String) -> [String]? {
        let k = FlexibleCodingKey(key)
        if let values = try? decode([String].self, forKey: k) { return values }
        if let values = try? decode([Int].self, forKey: k) { return values.map { String($0) } }
        if let values = try? decode([Double].self, forKey: k) { return values.map { String($0) } }
        if let single = string(key) { return [single] }
        return nil
    }

    func intArray(_ key: String) -> [Int]? {
        let k = FlexibleCodingKey(key)
        if let values = try? decode([Int].self, forKey: k) { return values }
        if let values = try? decode([Double].self, forKey: k) { return values.map { Int($0) } }
        if let values = try? decode([String].self, forKey: k) { return values.compactMap { Int($0.trimmingCharacters(in: .whitespacesAndNewlines)) } }
        if let single = int(key) { return [single] }
        return nil
    }

    func decodeIfPresentFlexible<T: Decodable>(_ type: T.Type, _ key: String) -> T? {
        try? decodeIfPresent(T.self, forKey: FlexibleCodingKey(key))
    }
}

extension AgentAction {
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: FlexibleCodingKey.self)
        self.type = c.string("type") ?? "wait"
        self.selector = c.string("selector")
        self.text = c.string("text")
        self.value = c.string("value")
        self.url = c.string("url")
        self.direction = c.string("direction")
        self.amount = c.int("amount")
        self.stepIndex = c.int("stepIndex")
        self.reason = c.string("reason")
        self.x = c.double("x")
        self.y = c.double("y")
        self.startX = c.double("startX")
        self.startY = c.double("startY")
        self.endX = c.double("endX")
        self.endY = c.double("endY")
        self.durationMs = c.int("durationMs")
        self.tabID = c.string("tabID")
        self.tabHint = c.string("tabHint")
        self.groupName = c.string("groupName")
        self.key = c.string("key")
        self.modifiers = c.stringArray("modifiers")
        self.question = c.string("question")
        self.placeholder = c.string("placeholder")
        self.message = c.string("message")
        self.timerID = c.string("timerID")
        self.durationSeconds = c.double("durationSeconds")
        self.timerMode = c.string("timerMode")
        self.title = c.string("title")
        self.allowDuplicate = c.bool("allowDuplicate")
        self.allowRepeatedInput = c.bool("allowRepeatedInput")
        self.expectedCount = c.int("expectedCount")
        self.repeatCount = c.int("repeatCount")
        self.inputCount = c.int("inputCount")
    }
}

extension AgentDecision {
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: FlexibleCodingKey.self)
        self.status = c.string("status")
        self.summary = c.string("summary")
        self.completedStepIndexes = c.intArray("completedStepIndexes")
        self.action = c.decodeIfPresentFlexible(AgentAction.self, "action")
        self.report = c.string("report")
        self.goalAnalysis = c.string("goalAnalysis")
        self.updatedSteps = c.decodeIfPresentFlexible([AgentPlanResponse.Step].self, "updatedSteps")
        self.restartPlan = c.bool("restartPlan")
        self.findings = c.decodeIfPresentFlexible([AgentFinding].self, "findings")
    }
}

extension AgentPlanResponse.Step {
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: FlexibleCodingKey.self)
        self.title = c.string("title") ?? c.string("name") ?? "未命名步骤"
        self.detail = c.string("detail") ?? c.string("description") ?? c.string("verify")
    }
}
