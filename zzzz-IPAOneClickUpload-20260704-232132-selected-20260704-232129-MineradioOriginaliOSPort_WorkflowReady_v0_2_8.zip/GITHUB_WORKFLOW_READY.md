# GitHub Workflow Ready

Version: `0.2.8`

Use these workflow inputs:

```text
FILE=MineradioiOS.xcodeproj
SCHEME=MineradioiOS
CONFIGURATION=Release
SDK=iphoneos
```

This package builds an unsigned IPA with the original Mineradio Web frontend loaded through WKWebView.

## Important runtime setup

After installing on iPad, tap the small `API` button in the lower-left corner and set the LAN address of the original Mineradio backend, for example:

```text
http://192.168.1.23:3000
```

Do not use `127.0.0.1` on iPad unless the API server is running on the iPad itself.
