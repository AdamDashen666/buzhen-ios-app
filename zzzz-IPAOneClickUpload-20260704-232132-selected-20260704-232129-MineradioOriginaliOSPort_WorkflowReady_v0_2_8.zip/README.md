# Mineradio iOS Original Web Port

目标：**不要仿版，不重画 UI，不阉割粒子 / 3D / 歌词舞台**。

这个工程是一个 iOS WKWebView 壳，构建时会下载原仓库：

`https://github.com/XxHuberrr/Mineradio`

并把原版 `public/` 目录整体复制进 App Bundle：

`MineradioWeb/index.html`

App 启动后直接加载原版 `index.html`，视觉层走原项目的 HTML/CSS/JS/Three.js/GSAP/music-tempo。

## 结构

- `MineradioiOSApp.swift`：iOS App 入口。
- `ContentView.swift`：WKWebView 原版前端加载器 + iOS/Electron 兼容桥。
- `Run Script Phase: Fetch Original Mineradio Web`：GitHub Actions / Xcode build 时下载原 `public/`。

## 这版的重点

- 视觉层不使用之前的 SwiftUI 卡片界面。
- 原版 `/api/...` 请求会转发到你配置的 Mineradio API Base。
- 加入 iOS 内置 API 配置面板：左下角 `API` 按钮。
- 如果二维码/搜索连接失败，会自动弹出 API 配置面板。

## API Base

真机 / iPad 不能使用：

`http://127.0.0.1:3000`

因为那代表 iPad 自己，不是你的电脑。

推荐在电脑上运行原 Mineradio 后端：

```bash
git clone https://github.com/XxHuberrr/Mineradio.git
cd Mineradio
npm install
HOST=0.0.0.0 PORT=3000 node server.js
```

Windows PowerShell 可用：

```powershell
$env:HOST="0.0.0.0"
$env:PORT="3000"
node server.js
```

然后在 iPad App 左下角 `API` 填：

```text
http://电脑局域网IP:3000
```

例子：

```text
http://192.168.1.23:3000
```

## 注意

1. 构建机器必须能访问 GitHub，否则 `Fetch Original Mineradio Web` 会失败。
2. iOS 只桥接底层能力：文件导入、WebView、Electron `desktopWindow` 兼容、`/api` 转发。
3. 原版里 Windows/Electron 独有能力无法 1:1 保证，比如窗口控制、桌面歌词穿透、Windows 安装器更新。它们会被 iOS 桥接为 no-op 或 fallback，但视觉代码不重写。
4. 电脑防火墙需要允许 3000 端口，否则 iPad 会连不上。

## GitHub Workflow 参数

```text
FILE=MineradioiOS.xcodeproj
SCHEME=MineradioiOS
CONFIGURATION=Release
SDK=iphoneos
```


## v0.2.8 Audio Terrain

Adds the iOS-only `音域回响` preset: a Three.js audio-reactive terrain / sound-field visual with touch camera controls.
