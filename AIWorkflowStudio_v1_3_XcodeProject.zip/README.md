# AI Workflow Studio v1.3

SwiftUI iOS / iPadOS project.

修复点：
- 恢复并重新生成 `.xcodeproj`。
- 修复画布端口拖拽里的 Double / CGFloat 类型混用。
- 保留 v1.2 的中文 UI、手动端口连线、缩放、真实 ZIP 导出。

打开 `AIWorkflowStudio.xcodeproj`，设置 Team / Bundle ID 后运行。
