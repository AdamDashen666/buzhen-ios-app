import SwiftUI

struct OutputHistoryView: View {
    @EnvironmentObject private var store: AppStore
    @State private var selectedRun: RunRecord?

    var body: some View {
        NavigationStack {
            List {
                Section("运行输出") {
                    ForEach(store.runRecords) { run in
                        Button { selectedRun = run } label: {
                            VStack(alignment: .leading, spacing: 6) {
                                Text(run.projectTitle).font(.headline)
                                Text("\(run.displayDate) · \(run.status.title) · Token \(run.tokenUsage.total)")
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                        }
                    }
                }
                Section("版本历史") {
                    ForEach(store.snapshots) { snapshot in
                        VStack(alignment: .leading) {
                            Text(snapshot.title).font(.headline)
                            Text("\(snapshot.createdAt.formatted(date: .abbreviated, time: .shortened)) · \(snapshot.note)")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                    }
                }
            }
            .scrollContentBackground(.hidden)
            .studioBackground()
            .navigationTitle("输出历史")
            .sheet(item: $selectedRun) { run in
                NavigationStack {
                    ScrollView {
                        Text(run.output.isEmpty ? LogExportService.markdown(for: run) : run.output)
                            .font(.system(.body, design: .monospaced))
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding()
                    }
                    .studioBackground()
                    .navigationTitle("输出详情")
                    .toolbar {
                        ShareLink("分享日志", item: LogExportService.markdown(for: run))
                        ShareLink("分享 ZIP", item: ZipArchiveService.shareableRunArchive(for: run))
                    }
                }
            }
        }
    }
}
