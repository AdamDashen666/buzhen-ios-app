import SwiftUI
import PhotosUI

struct NodeDetailView: View {
    @EnvironmentObject private var store: AppStore
    @Environment(\.dismiss) private var dismiss
    var projectID: UUID
    @State var node: WorkflowNode
    @State private var startPrompt = ""
    @State private var autoSelectModules = false
    @State private var selectedPhoto: PhotosPickerItem?

    var body: some View {
        NavigationStack {
            Form {
                Section("模块说明") {
                    Label(node.kind.title, systemImage: node.kind.icon)
                    Text(node.kind.summary)
                        .foregroundStyle(.secondary)
                    VStack(alignment: .leading, spacing: 8) {
                        Text(node.kind.inputDescription)
                        Text(node.kind.outputDescription)
                    }
                    .font(.caption)
                    .foregroundStyle(.secondary)
                }

                if node.kind == .start {
                    startModuleSection
                }

                Section("基础设置") {
                    TextField("模块名称", text: $node.title)
                    Stepper("最大返工次数：\(limitText(node.maxReturnCount))", value: $node.maxReturnCount, in: 0...99)
                    Text("0 表示无限返工。风险：可能导致费用增加，建议配合设置页的 Token 总限制。")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    Stepper("重试次数：\(limitText(node.retryLimit))", value: $node.retryLimit, in: 0...99)
                    Text("0 表示无限重试。适合长任务，但 API 持续失败时可能重复消耗时间。")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                Section("模块提示词") {
                    TextEditor(text: $node.prompt)
                        .frame(minHeight: 150)
                    Text("这里写这个模块自己的角色要求。上游模块的输出会作为上下文传入。")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                Section("模型设置") {
                    Picker("API 配置", selection: Binding(get: { node.providerID }, set: { node.providerID = $0 })) {
                        Text("未配置").tag(Optional<UUID>.none)
                        ForEach(store.apiConfigs) { config in
                            Text(config.name).tag(Optional(config.id))
                        }
                    }
                    if let providerID = node.providerID, let config = store.apiConfigs.first(where: { $0.id == providerID }) {
                        Picker("模型", selection: Binding(get: { node.modelID ?? "" }, set: { node.modelID = $0 })) {
                            Text("未选择").tag("")
                            ForEach(config.models) { model in
                                Text(model.name).tag(model.id)
                            }
                        }
                    }
                    Slider(value: $node.temperature, in: 0...1) {
                        Text("温度参数")
                    }
                    Text("温度参数：\(node.temperature, specifier: "%.2f")")
                    Text("温度参数控制模型回答的随机程度：越低越稳定、越适合代码检查；越高越发散、越适合创意写作。建议代码检查 0.1～0.3，普通写作 0.3～0.7。")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    Stepper("超时时间：\(node.timeoutSeconds) 秒", value: $node.timeoutSeconds, in: 15...300, step: 15)
                    Text("Token 总限制请到“设置 → Token 总限制”中设置；这里不再放单模块 Token 限制。")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                Section("输出设置") {
                    Picker("输出格式", selection: $node.outputFormat) {
                        ForEach(OutputFormat.allCases) { format in
                            Text(format.title).tag(format)
                        }
                    }
                    Stepper("质量阈值：\(node.scoreThreshold)", value: $node.scoreThreshold, in: 0...100, step: 5)
                    if node.kind == .multiModelVote {
                        Text("多模型投票上限在设置页统一控制；0 表示不限制。")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                }

                Section("危险操作") {
                    Button(role: .destructive) {
                        store.removeNode(projectID: projectID, nodeID: node.id)
                        dismiss()
                    } label: {
                        Label("删除这个模块", systemImage: "trash")
                    }
                    .disabled(node.kind == .start || node.kind == .output)
                    Text("开始模块和输出模块默认保留，避免工作流失去入口或出口。")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
            .scrollContentBackground(.hidden)
            .studioBackground()
            .navigationTitle(node.title)
            .onAppear(perform: loadStartValues)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("取消") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("保存") {
                        saveStartValuesIfNeeded()
                        store.updateNode(node, in: projectID)
                        dismiss()
                    }
                }
            }
        }
    }

    private var startModuleSection: some View {
        Section("开始模块：输入与运行") {
            TextEditor(text: $startPrompt)
                .frame(minHeight: 140)
            Toggle("AI 自动选择模块（只添加模块，不自动连线）", isOn: $autoSelectModules)
            Text("勾选后，运行前会根据需求自动添加需要的模块；v1.3 不会自动画连线，避免误连。")
                .font(.caption)
                .foregroundStyle(.secondary)
            PhotosPicker(selection: $selectedPhoto, matching: .images) {
                Label("上传图片到当前项目资源", systemImage: "photo.badge.plus")
            }
            .onChange(of: selectedPhoto) { _, newItem in
                Task { await importPhoto(newItem) }
            }
            Button {
                saveStartValuesIfNeeded()
                if autoSelectModules { store.autoBuildSelectedProject() }
            } label: {
                Label("保存开始模块输入", systemImage: "square.and.arrow.down")
            }
            Button {
                saveStartValuesIfNeeded()
                Task { await store.runSelectedProject() }
            } label: {
                Label("确认并运行", systemImage: "play.fill")
            }
        }
    }

    private func loadStartValues() {
        guard let project = store.projects.first(where: { $0.id == projectID }) else { return }
        startPrompt = project.userPrompt
        autoSelectModules = project.autoSelectModules
    }

    private func saveStartValuesIfNeeded() {
        guard var project = store.projects.first(where: { $0.id == projectID }) else { return }
        project.userPrompt = startPrompt
        project.autoSelectModules = autoSelectModules
        store.updateProject(project)
    }

    private func importPhoto(_ item: PhotosPickerItem?) async {
        guard let item,
              let data = try? await item.loadTransferable(type: Data.self),
              var project = store.projects.first(where: { $0.id == projectID }) else { return }
        let resource = ProjectResource(name: "Image-\(Date().timeIntervalSince1970).jpg", kind: .image, base64Preview: data.base64EncodedString())
        project.resources.append(resource)
        if !project.nodes.contains(where: { $0.kind == .imageUnderstanding }) {
            var imageNode = WorkflowNode(kind: .imageUnderstanding, title: WorkflowNodeKind.imageUnderstanding.title, x: 410, y: 340)
            imageNode.prompt = WorkflowNodeKind.imageUnderstanding.defaultPrompt
            project.nodes.append(imageNode)
        }
        store.updateProject(project)
    }

    private func limitText(_ value: Int) -> String {
        value == 0 ? "无限" : "\(value)"
    }
}
