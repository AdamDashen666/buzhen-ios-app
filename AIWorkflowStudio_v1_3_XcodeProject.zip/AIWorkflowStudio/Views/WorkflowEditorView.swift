import SwiftUI

struct WorkflowEditorView: View {
    @EnvironmentObject private var store: AppStore
    @State private var showingLibrary = false
    @State private var selectedNode: WorkflowNode?
    @State private var connectFrom: UUID?
    @State private var dragPoint: CGPoint?
    @State private var zoom: Double = 1.0
    @State private var lastZoom: Double = 1.0

    var body: some View {
        NavigationStack {
            Group {
                if let project = store.selectedProject {
                    GeometryReader { proxy in
                        if proxy.size.width > 720 {
                            canvas(project: project)
                        } else {
                            listEditor(project: project)
                        }
                    }
                } else {
                    ContentUnavailableView("没有项目", systemImage: "folder.badge.plus", description: Text("先在首页新建一个工作流。"))
                }
            }
            .studioBackground()
            .navigationTitle(store.selectedProject?.title ?? "工作流")
            .toolbar {
                ToolbarItemGroup(placement: .topBarTrailing) {
                    Button { showingLibrary = true } label: { Label("添加模块", systemImage: "plus") }
                    Button("AI 选择模块") { store.autoBuildSelectedProject() }
                    Button { Task { await store.runSelectedProject() } } label: { Label("运行", systemImage: "play.fill") }
                }
            }
            .sheet(isPresented: $showingLibrary) { ModuleLibrarySheet() }
            .sheet(item: $selectedNode) { node in
                if let project = store.selectedProject {
                    NodeDetailView(projectID: project.id, node: node)
                }
            }
        }
    }

    private func canvas(project: WorkflowProject) -> some View {
        ZStack(alignment: .topLeading) {
            Canvas { context, _ in
                for edge in project.edges {
                    guard let from = project.nodes.first(where: { $0.id == edge.from }), let to = project.nodes.first(where: { $0.id == edge.to }) else { continue }
                    var path = Path()
                    path.move(to: CGPoint(x: CGFloat(from.x) + 104, y: CGFloat(from.y)))
                    path.addCurve(
                        to: CGPoint(x: CGFloat(to.x) - 104, y: CGFloat(to.y)),
                        control1: CGPoint(x: CGFloat(from.x) + 168, y: CGFloat(from.y)),
                        control2: CGPoint(x: CGFloat(to.x) - 168, y: CGFloat(to.y))
                    )
                    context.stroke(path, with: .color(.cyan.opacity(0.72)), lineWidth: 2.5)
                }
                if let connectFrom,
                   let source = project.nodes.first(where: { $0.id == connectFrom }),
                   let dragPoint {
                    var path = Path()
                    path.move(to: CGPoint(x: CGFloat(source.x) + 104, y: CGFloat(source.y)))
                    path.addCurve(
                        to: dragPoint,
                        control1: CGPoint(x: CGFloat(source.x) + 168, y: CGFloat(source.y)),
                        control2: CGPoint(x: dragPoint.x - 100, y: dragPoint.y)
                    )
                    context.stroke(path, with: .color(.mint.opacity(0.90)), lineWidth: 3)
                }
            }
            .frame(width: 2400, height: 1600)

            ForEach(project.nodes) { node in
                NodeCard(
                    node: node,
                    isConnecting: connectFrom == node.id,
                    onInputTap: {
                        if let connectFrom, connectFrom != node.id {
                            store.connect(projectID: project.id, from: connectFrom, to: node.id)
                            self.connectFrom = nil
                            self.dragPoint = nil
                        }
                    },
                    onOutputTap: {
                        connectFrom = node.id
                        dragPoint = CGPoint(x: CGFloat(node.x) + 150, y: CGFloat(node.y))
                    },
                    onOutputDragChanged: { value in
                        connectFrom = node.id
                        dragPoint = CGPoint(x: CGFloat(node.x) + 104 + value.translation.width, y: CGFloat(node.y) + value.translation.height)
                    },
                    onOutputDragEnded: { value in
                        let endPoint = CGPoint(x: CGFloat(node.x) + 104 + value.translation.width, y: CGFloat(node.y) + value.translation.height)
                        if let target = targetNode(at: endPoint, in: project, excluding: node.id) {
                            store.connect(projectID: project.id, from: node.id, to: target.id)
                        }
                        connectFrom = nil
                        dragPoint = nil
                    }
                )
                .position(x: CGFloat(node.x), y: CGFloat(node.y))
                .gesture(
                    DragGesture()
                        .onChanged { value in
                            store.moveNode(projectID: project.id, nodeID: node.id, x: node.x + Double(value.translation.width), y: node.y + Double(value.translation.height))
                        }
                )
                .onTapGesture { selectedNode = node }
                .contextMenu {
                    Button("查看 / 编辑模块") { selectedNode = node }
                    Button("从右侧端口开始连线") {
                        connectFrom = node.id
                        dragPoint = CGPoint(x: CGFloat(node.x) + 150, y: CGFloat(node.y))
                    }
                    if let connectFrom, connectFrom != node.id {
                        Button("连接到此模块左侧端口") {
                            store.connect(projectID: project.id, from: connectFrom, to: node.id)
                            self.connectFrom = nil
                            self.dragPoint = nil
                        }
                    }
                    Button(role: .destructive) {
                        store.removeNode(projectID: project.id, nodeID: node.id)
                    } label: {
                        Text("删除模块")
                    }
                }
            }
        }
        .scaleEffect(CGFloat(zoom), anchor: .topLeading)
        .gesture(
            MagnificationGesture()
                .onChanged { value in
                    zoom = min(max(lastZoom * Double(value), 0.45), 2.0)
                }
                .onEnded { _ in
                    lastZoom = zoom
                }
        )
        .overlay(alignment: .topLeading) {
            VStack(alignment: .leading, spacing: 8) {
                Text("拖拽说明")
                    .font(.headline)
                Text("右侧圆点 = 输出端口；左侧圆点 = 输入端口。按住右侧端口拖到其他模块左侧即可连线。多个模块可以同时连到同一个输入端口。")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                HStack {
                    Button { zoom = max(0.45, zoom - 0.1); lastZoom = zoom } label: { Image(systemName: "minus.magnifyingglass") }
                    Slider(value: $zoom, in: 0.45...2.0) { Text("缩放") }
                        .frame(width: 160)
                        .onChange(of: zoom) { _, newValue in lastZoom = newValue }
                    Button { zoom = min(2.0, zoom + 0.1); lastZoom = zoom } label: { Image(systemName: "plus.magnifyingglass") }
                    Button("重置") { zoom = 1.0; lastZoom = 1.0 }
                    Button(role: .destructive) { store.removeAllEdges(projectID: project.id) } label: { Text("清空连线") }
                }
                .buttonStyle(.bordered)
            }
            .frame(width: 430, alignment: .leading)
            .liquidGlass(cornerRadius: 20, glow: false)
            .padding()
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
    }

    private func targetNode(at point: CGPoint, in project: WorkflowProject, excluding sourceID: UUID) -> WorkflowNode? {
        project.nodes
            .filter { $0.id != sourceID }
            .min { lhs, rhs in
                let leftPortL = CGPoint(x: CGFloat(lhs.x) - 104, y: CGFloat(lhs.y))
                let leftPortR = CGPoint(x: CGFloat(rhs.x) - 104, y: CGFloat(rhs.y))
                return distance(point, leftPortL) < distance(point, leftPortR)
            }
            .flatMap { candidate in
                distance(point, CGPoint(x: CGFloat(candidate.x) - 104, y: CGFloat(candidate.y))) < 90 ? candidate : nil
            }
    }

    private func distance(_ a: CGPoint, _ b: CGPoint) -> CGFloat {
        hypot(a.x - b.x, a.y - b.y)
    }

    private func listEditor(project: WorkflowProject) -> some View {
        List {
            Section("开始模块") {
                if let start = project.nodes.first(where: { $0.kind == .start }) {
                    Button { selectedNode = start } label: {
                        Label("输入需求、上传图片、运行工作流", systemImage: start.kind.icon)
                    }
                }
            }
            Section("节点") {
                ForEach(project.nodes) { node in
                    Button { selectedNode = node } label: {
                        VStack(alignment: .leading, spacing: 4) {
                            Label(node.title, systemImage: node.kind.icon)
                            Text(node.kind.summary).font(.caption).foregroundStyle(.secondary)
                        }
                    }
                }
                .onDelete { offsets in
                    for index in offsets { store.removeNode(projectID: project.id, nodeID: project.nodes[index].id) }
                }
            }
            Section("连线") {
                if project.edges.isEmpty {
                    Text("暂无连线。iPhone 小屏暂用详情页/上下文菜单操作；建议在 iPad 横屏画布拖端口连线。")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                ForEach(project.edges) { edge in
                    Text("\(project.nodes.first(where: { $0.id == edge.from })?.title ?? "?") → \(project.nodes.first(where: { $0.id == edge.to })?.title ?? "?")")
                }
                Button(role: .destructive) { store.removeAllEdges(projectID: project.id) } label: { Text("清空全部连线") }
            }
        }
        .scrollContentBackground(.hidden)
    }
}

struct NodeCard: View {
    var node: WorkflowNode
    var isConnecting: Bool
    var onInputTap: () -> Void
    var onOutputTap: () -> Void
    var onOutputDragChanged: (DragGesture.Value) -> Void
    var onOutputDragEnded: (DragGesture.Value) -> Void

    var body: some View {
        HStack(spacing: 10) {
            port(title: "输入", systemImage: "arrow.down.circle.fill")
                .onTapGesture(perform: onInputTap)
            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    Image(systemName: node.kind.icon)
                    Text(node.title).font(.headline)
                }
                Text(node.kind.summary)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .lineLimit(2)
                Text(node.status.title)
                    .font(.caption2.bold())
                    .padding(.horizontal, 8)
                    .padding(.vertical, 4)
                    .background(.cyan.opacity(0.20), in: Capsule())
            }
            .frame(width: 180, alignment: .leading)
            port(title: "输出", systemImage: "arrow.up.circle.fill")
                .onTapGesture(perform: onOutputTap)
                .gesture(
                    DragGesture(minimumDistance: 0)
                        .onChanged(onOutputDragChanged)
                        .onEnded(onOutputDragEnded)
                )
        }
        .liquidGlass(cornerRadius: 22, glow: isConnecting)
        .scaleEffect(isConnecting ? 1.04 : 1)
    }

    private func port(title: String, systemImage: String) -> some View {
        VStack(spacing: 3) {
            Image(systemName: systemImage)
                .font(.title3)
                .foregroundStyle(.cyan)
                .padding(6)
                .background(.black.opacity(0.24), in: Circle())
                .overlay(Circle().stroke(.cyan.opacity(0.65), lineWidth: 1.5))
            Text(title)
                .font(.caption2)
                .foregroundStyle(.secondary)
        }
    }
}
