import Foundation

// 完整模块系统：覆盖计划者、工作者、检查者、代码检查者、图片理解、多模型投票、日志、版本快照、输出等。
enum WorkflowNodeKind: String, Codable, CaseIterable, Identifiable {
    case start
    case autoGraph
    case planner
    case dispatcher
    case worker
    case codeWorker
    case codeReviewer
    case autoFixer
    case imageUnderstanding
    case imageGenerator
    case multiModelVote
    case qualityReviewer
    case visualReviewer
    case aggregator
    case formatter
    case filePackager
    case humanApproval
    case logger
    case versionSnapshot
    case output

    var id: String { rawValue }

    var title: String {
        switch self {
        case .start: return "开始模块"
        case .autoGraph: return "AI 自动选择模块"
        case .planner: return "计划者"
        case .dispatcher: return "任务分配者"
        case .worker: return "通用工作者"
        case .codeWorker: return "代码工作者"
        case .codeReviewer: return "代码检查者"
        case .autoFixer: return "自动修复者"
        case .imageUnderstanding: return "图片理解 / 识别"
        case .imageGenerator: return "图片生成者"
        case .multiModelVote: return "多模型投票"
        case .qualityReviewer: return "检查者 / 质量评估"
        case .visualReviewer: return "视觉检查者"
        case .aggregator: return "汇总者"
        case .formatter: return "格式转换者"
        case .filePackager: return "文件打包者"
        case .humanApproval: return "人工确认"
        case .logger: return "日志记录"
        case .versionSnapshot: return "版本快照"
        case .output: return "输出模块"
        }
    }

    var icon: String {
        switch self {
        case .start: return "play.circle"
        case .autoGraph: return "wand.and.stars"
        case .planner: return "list.bullet.clipboard"
        case .dispatcher: return "arrow.triangle.branch"
        case .worker: return "person.text.rectangle"
        case .codeWorker: return "chevron.left.forwardslash.chevron.right"
        case .codeReviewer: return "checkmark.seal"
        case .autoFixer: return "wrench.and.screwdriver"
        case .imageUnderstanding: return "photo.on.rectangle.angled"
        case .imageGenerator: return "paintbrush.pointed"
        case .multiModelVote: return "person.3.sequence"
        case .qualityReviewer: return "star.leadinghalf.filled"
        case .visualReviewer: return "eye"
        case .aggregator: return "square.stack.3d.up"
        case .formatter: return "doc.richtext"
        case .filePackager: return "archivebox"
        case .humanApproval: return "hand.raised"
        case .logger: return "list.clipboard"
        case .versionSnapshot: return "clock.arrow.circlepath"
        case .output: return "tray.and.arrow.down"
        }
    }

    var summary: String {
        switch self {
        case .start: return "整个工作流的入口，用来写需求、上传图片/文件和启动运行。"
        case .autoGraph: return "根据需求自动推荐要添加哪些模块，但 v1.3 不会自动连线。"
        case .planner: return "把大目标拆成步骤、风险点和交付物。"
        case .dispatcher: return "把任务分配给多个工作者，适合并行处理。"
        case .worker: return "处理普通写作、总结、整理和分析。"
        case .codeWorker: return "生成代码、文件结构和项目说明。"
        case .codeReviewer: return "专门检查代码语法、依赖、架构、安全和可运行性。"
        case .autoFixer: return "根据检查者意见自动改代码，再交回检查。"
        case .imageUnderstanding: return "识别图片、截图、作业题、图表、UI 和代码截图。"
        case .imageGenerator: return "生成图片提示词、图标方案、UI 草图或素材说明。"
        case .multiModelVote: return "让多个模型回答同一问题，再用投票/裁判选择结果。"
        case .qualityReviewer: return "检查最终质量，给分，不合格时打回。"
        case .visualReviewer: return "检查 UI、排版、颜色、可读性和移动端适配。"
        case .aggregator: return "合并多个模块输出，去重并统一风格。"
        case .formatter: return "把内容转换成 Markdown、JSON、TXT、HTML 或代码文件。"
        case .filePackager: return "整理文件结构并准备真实 ZIP 导出。"
        case .humanApproval: return "在关键步骤暂停，等用户确认后再继续。"
        case .logger: return "记录输入、输出、模型、Token、错误和耗时。"
        case .versionSnapshot: return "保存当前工作流结构、提示词、模型配置和输出。"
        case .output: return "把上游结果整理成最终输出。"
        }
    }

    var inputDescription: String {
        switch self {
        case .start: return "输入：用户提示词、要求、图片、文件、运行参数。"
        case .autoGraph: return "输入：开始模块的需求文本、上传资源、用户勾选的自动选择开关。"
        case .planner: return "输入：用户需求、图片理解结果、已有上下文。"
        case .dispatcher: return "输入：计划者输出的任务清单和项目目标。"
        case .worker: return "输入：计划者/分配者给出的具体任务和上游资料。"
        case .codeWorker: return "输入：代码需求、技术栈、文件结构要求、上游方案。"
        case .codeReviewer: return "输入：代码工作者生成的代码、文件结构和运行说明。"
        case .autoFixer: return "输入：代码检查者的错误列表、修复建议和原始代码。"
        case .imageUnderstanding: return "输入：开始模块或项目资源里的图片、截图、图表。"
        case .imageGenerator: return "输入：图片需求、风格、尺寸、参考说明。"
        case .multiModelVote: return "输入：同一问题或多个候选答案。"
        case .qualityReviewer: return "输入：工作者、汇总者或输出模块的结果。"
        case .visualReviewer: return "输入：UI 方案、截图、设计稿或前端代码。"
        case .aggregator: return "输入：多个上游模块的结果。"
        case .formatter: return "输入：需要转换格式的文本、代码或结构化内容。"
        case .filePackager: return "输入：文件内容、目录结构、README、日志和输出结果。"
        case .humanApproval: return "输入：需要用户确认的阶段结果。"
        case .logger: return "输入：所有模块运行状态、上下文、错误和 Token 数据。"
        case .versionSnapshot: return "输入：当前项目结构、模块设置、输出结果。"
        case .output: return "输入：所有连接到它的上游模块结果。"
        }
    }

    var outputDescription: String {
        switch self {
        case .start: return "输出：标准化需求、资源列表和初始上下文。"
        case .autoGraph: return "输出：建议模块列表；默认不输出连线。"
        case .planner: return "输出：步骤计划、模块建议、风险和验收标准。"
        case .dispatcher: return "输出：分配给各工作者的子任务。"
        case .worker: return "输出：文本、分析、总结或初稿。"
        case .codeWorker: return "输出：代码文件、项目结构和运行说明。"
        case .codeReviewer: return "输出：通过/不通过、问题清单、严重程度、修复建议。"
        case .autoFixer: return "输出：修复后的代码和修改说明。"
        case .imageUnderstanding: return "输出：图片摘要、OCR 文字、关键对象、可操作信息、不确定内容。"
        case .imageGenerator: return "输出：图片生成结果说明、提示词或素材方案。"
        case .multiModelVote: return "输出：获胜答案、投票结果、裁判理由和分歧点。"
        case .qualityReviewer: return "输出：评分、是否通过、返工意见。"
        case .visualReviewer: return "输出：视觉问题、可读性建议、移动端适配建议。"
        case .aggregator: return "输出：合并后的统一版本。"
        case .formatter: return "输出：指定格式文件内容。"
        case .filePackager: return "输出：ZIP 打包清单和可导出的文件结构。"
        case .humanApproval: return "输出：用户确认结果：继续、修改、终止。"
        case .logger: return "输出：Markdown / JSON / CSV / TXT 日志。"
        case .versionSnapshot: return "输出：可回滚的版本快照。"
        case .output: return "输出：最终文本、代码、ZIP、报告或项目文件。"
        }
    }

    var defaultPrompt: String {
        switch self {
        case .start: return "接收用户目标、文件、图片和参数。"
        case .autoGraph: return "根据用户目标推荐应添加的模块。注意：只生成模块，不自动连线。"
        case .planner: return "拆解目标，列出阶段、风险、所需模块和交付物。"
        case .dispatcher: return "把任务拆给多个工作者，说明每个工作者的输入、输出和检查标准。"
        case .worker: return "执行普通写作、总结、整理、分析任务。"
        case .codeWorker: return "生成代码、项目结构、文件内容和运行说明。"
        case .codeReviewer: return "检查语法、依赖、架构、安全、可运行性和 iOS 适配风险，输出通过/不通过与修复建议。"
        case .autoFixer: return "根据代码检查者意见修复代码，并说明修复点。"
        case .imageUnderstanding: return "识别图片内容，输出图片摘要、关键文字、可操作信息和不确定内容。"
        case .imageGenerator: return "根据需求生成图片提示词、图标或 UI 草图方案。"
        case .multiModelVote: return "汇总多个模型回答，用多数票、评分制或裁判模型选择结果。"
        case .qualityReviewer: return "从准确性、完整性、格式、风险四项评分；低于阈值时打回返工。"
        case .visualReviewer: return "检查 UI、排版、颜色、可读性和移动端适配。"
        case .aggregator: return "合并多个模块输出，去重，统一风格。"
        case .formatter: return "把内容转换为 Markdown、JSON、TXT、HTML 或代码文件。"
        case .filePackager: return "整理多文件目录结构，生成 README、日志和 ZIP 打包清单。"
        case .humanApproval: return "暂停流程，等待用户确认后继续。"
        case .logger: return "记录模块输入、输出、模型、Token、错误、耗时和返工记录。"
        case .versionSnapshot: return "保存工作流结构、提示词、模型配置和输出快照。"
        case .output: return "整理最终结果并导出文本、代码、图片说明或项目包。"
        }
    }

    var requiresVisionModel: Bool {
        self == .imageUnderstanding || self == .visualReviewer
    }

    var isCodeRelated: Bool {
        self == .codeWorker || self == .codeReviewer || self == .autoFixer
    }
}
