import UIKit
import CoreGraphics

struct ImageGray {
    let width: Int
    let height: Int
    let scaleFromOriginal: CGFloat
    var pixels: [UInt8]

    func value(x: Int, y: Int) -> UInt8 {
        guard x >= 0, x < width, y >= 0, y < height else { return 0 }
        return pixels[y * width + x]
    }

    func patch(center: CGPoint, radius: Int) -> [UInt8]? {
        let cx = Int(round(center.x))
        let cy = Int(round(center.y))
        guard cx - radius >= 0, cx + radius < width, cy - radius >= 0, cy + radius < height else { return nil }
        var out: [UInt8] = []
        out.reserveCapacity((radius * 2 + 1) * (radius * 2 + 1))
        for y in (cy - radius)...(cy + radius) {
            let base = y * width
            for x in (cx - radius)...(cx + radius) {
                out.append(pixels[base + x])
            }
        }
        return out
    }

    static func from(pixelBuffer: CVPixelBuffer, maxWidth: Int) -> ImageGray? {
        let width = CVPixelBufferGetWidth(pixelBuffer)
        let height = CVPixelBufferGetHeight(pixelBuffer)
        let targetWidth = min(width, maxWidth)
        let ratio = CGFloat(targetWidth) / CGFloat(width)
        let targetHeight = max(1, Int(CGFloat(height) * ratio))

        CVPixelBufferLockBaseAddress(pixelBuffer, .readOnly)
        defer { CVPixelBufferUnlockBaseAddress(pixelBuffer, .readOnly) }
        guard let base = CVPixelBufferGetBaseAddress(pixelBuffer) else { return nil }
        let bytesPerRow = CVPixelBufferGetBytesPerRow(pixelBuffer)

        var output = [UInt8](repeating: 0, count: targetWidth * targetHeight)
        for ty in 0..<targetHeight {
            let sy = min(height - 1, Int(CGFloat(ty) / ratio))
            let row = base.advanced(by: sy * bytesPerRow)
            for tx in 0..<targetWidth {
                let sx = min(width - 1, Int(CGFloat(tx) / ratio))
                let p = row.advanced(by: sx * 4).assumingMemoryBound(to: UInt8.self)
                // kCVPixelFormatType_32BGRA: B,G,R,A
                let b = Double(p[0])
                let g = Double(p[1])
                let r = Double(p[2])
                output[ty * targetWidth + tx] = UInt8(max(0, min(255, 0.299 * r + 0.587 * g + 0.114 * b)))
            }
        }
        return ImageGray(width: targetWidth, height: targetHeight, scaleFromOriginal: ratio, pixels: output)
    }
}
