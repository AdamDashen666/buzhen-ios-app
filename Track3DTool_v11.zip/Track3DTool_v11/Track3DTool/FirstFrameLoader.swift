import UIKit
import AVFoundation

struct FirstFrameLoader {
    static func duration(url: URL) async throws -> Double {
        try await Task.detached(priority: .userInitiated) {
            let asset = AVAsset(url: url)
            let seconds = asset.duration.seconds
            return seconds.isFinite ? max(0, seconds) : 0
        }.value
    }

    static func load(url: URL, at seconds: Double = 0) async throws -> UIImage {
        try await Task.detached(priority: .userInitiated) {
            let asset = AVAsset(url: url)
            let generator = AVAssetImageGenerator(asset: asset)
            generator.appliesPreferredTrackTransform = false // Keep coordinates aligned with AVAssetReader pixel buffers.
            generator.maximumSize = CGSize(width: 1920, height: 1920)
            generator.requestedTimeToleranceBefore = CMTime(seconds: 0.08, preferredTimescale: 600)
            generator.requestedTimeToleranceAfter = CMTime(seconds: 0.08, preferredTimescale: 600)
            let clamped = min(max(seconds, 0), max(asset.duration.seconds.isFinite ? asset.duration.seconds : 0, 0))
            let time = CMTime(seconds: clamped, preferredTimescale: 600)
            let cg = try generator.copyCGImage(at: time, actualTime: nil)
            return UIImage(cgImage: cg)
        }.value
    }
}
