import SwiftUI
import UniformTypeIdentifiers
import AVFoundation
import AVKit
import CoreImage
import PhotosUI
import Photos
import CoreTransferable
import UIKit
import Darwin

struct ContentView: View {
    private enum StartLaunchTarget: Equatable {
        case workflow(BuzhenWorkflowMode)
        case benchmark
        case calibration

        var title: String {
            switch self {
            case .workflow(let mode):
                return mode.title
            case .benchmark:
                return "补帧测试"
            case .calibration:
                return "性能校准"
            }
        }

        var detail: String {
            switch self {
            case .workflow(.videoInterpolation):
                return "正在加载视频补帧界面"
            case .workflow(.slowMotionInterpolation):
                return "正在加载慢放补帧界面"
            case .benchmark:
                return "正在加载补帧测试"
            case .calibration:
                return "正在加载性能校准"
            }
        }

        var systemImage: String {
            switch self {
            case .workflow(.videoInterpolation):
                return "film.stack"
            case .workflow(.slowMotionInterpolation):
                return "tortoise"
            case .benchmark:
                return "speedometer"
            case .calibration:
                return "gauge.with.dots.needle.67percent"
            }
        }
    }

    @StateObject private var vm = ProcessorViewModel()

    @State private var showDocumentPicker = false
    @State private var showPhotosPicker = false
    @State private var showBenchmarkSetupScreen = false
    @State private var showExtremePerformanceScreen = false
    @State private var showSlowMotionTrimScreen = false
    @State private var selectedPhotoItem: PhotosPickerItem?
    @State private var entranceAnimationReady = false
    @State private var hasSelectedWorkflow = false
    @State private var startLaunchTarget: StartLaunchTarget?
    @State private var startLaunchProgress: Double = 0
    @State private var startEntryHintPulse = false

    private var activeSceneKey: String {
        if vm.shouldShowInitializationOnlyScreen { return "initialization" }
        if vm.showProcessingScreen { return "processing" }
        if showExtremePerformanceScreen { return "performance" }
        if showBenchmarkSetupScreen { return "fillframeTest" }
        if showSlowMotionTrimScreen { return "slowTrim" }
        if startLaunchTarget != nil { return "startLoading" }
        if !hasSelectedWorkflow { return "start" }
        return "main"
    }

    var body: some View {
        NavigationStack {
            GeometryReader { proxy in
                ZStack {
                    LinearGradient(
                        colors: [
                            Color(.systemGroupedBackground),
                            Color(.secondarySystemGroupedBackground)
                        ],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                    .ignoresSafeArea()

                    SceneAmbientGlassOrbs(sceneKey: activeSceneKey)
                        .allowsHitTesting(false)

                    if vm.showProcessingScreen {
                        if vm.shouldShowInitializationOnlyScreen {
                            initializationOnlyScreen(proxy: proxy)
                                .id("initialization-scene")
                                .transition(.opacity.combined(with: .scale(scale: 0.985)))
                        } else {
                            processingOnlyScreen(proxy: proxy)
                                .id("processing-scene")
                                .transition(.liquidGlassStretchScene(direction: 1))
                        }
                    } else if showExtremePerformanceScreen {
                        extremePerformanceScreen(proxy: proxy)
                            .id("performance-scene")
                            .transition(.liquidGlassStretchScene(direction: 1))
                    } else if showBenchmarkSetupScreen {
                        benchmarkSetupScreen(proxy: proxy)
                            .id("fillframe-test-scene")
                            .transition(.liquidGlassStretchScene(direction: 1))
                    } else if showSlowMotionTrimScreen {
                        slowMotionTrimScreen(proxy: proxy)
                            .id("slow-motion-trim-scene")
                            .transition(.liquidGlassStretchScene(direction: 1))
                    } else if let target = startLaunchTarget {
                        startLaunchLoadingScreen(proxy: proxy, target: target)
                            .id("start-loading-scene")
                            .transition(.opacity.combined(with: .scale(scale: 0.985)))
                    } else if !hasSelectedWorkflow {
                        startSelectionScreen(proxy: proxy)
                            .id("start-scene")
                            .transition(.liquidGlassStretchScene(direction: -1))
                    } else {
                        LiquidGlassRoot(spacing: 18) {
                        ScrollView {
                            VStack(alignment: .leading, spacing: 24) {
                                headerCard

                                entranceCard(index: 0) { appOverviewCard }

                                if vm.shouldShowProgressPanel {
                                    progressStatusCard
                                }

                                settingsContentLayout(width: proxy.size.width)
                            }
                            .padding(.horizontal, horizontalPadding(for: proxy.size.width))
                            .padding(.top, max(proxy.safeAreaInsets.top + 34, proxy.size.width < 430 ? 22 : 38))
                            .padding(.bottom, max(18, proxy.safeAreaInsets.bottom + 14))
                            .frame(maxWidth: contentMaxWidth(for: proxy.size.width))
                            .frame(maxWidth: .infinity)
                            .frame(minHeight: proxy.size.height, alignment: .top)
                        }
                        .scrollIndicators(.visible)
                        .onAppear {
                            entranceAnimationReady = false
                            withAnimation(.spring(response: 0.72, dampingFraction: 0.82).delay(0.05)) {
                                entranceAnimationReady = true
                            }
                        }
                        }
                        .id("main-scene")
                        .transition(.liquidGlassStretchScene(direction: -1))
                    }
                }
                .animation(SceneAnimationPreset.sceneSwitch, value: activeSceneKey)
            }
            .navigationTitle(vm.shouldShowInitializationOnlyScreen ? "" : (vm.showProcessingScreen ? "处理进度" : ""))
            .navigationBarTitleDisplayMode(.inline)
            .navigationBarBackButtonHidden(vm.showProcessingScreen && vm.isProcessing)
            .toolbar(vm.showProcessingScreen && vm.isProcessing ? .hidden : .visible, for: .navigationBar)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    if vm.isProcessing {
                        StatusBadge(text: vm.progressPercentText, systemImage: "waveform.path.ecg")
                    }
                }
            }
            .sheet(isPresented: $showDocumentPicker) {
                VideoDocumentPicker { urls in
                    vm.handleDocumentPickerImport(urls)
                }
                .ignoresSafeArea()
            }
            .photosPicker(
                isPresented: $showPhotosPicker,
                selection: $selectedPhotoItem,
                matching: .videos,
                photoLibrary: .shared()
            )
            .onChange(of: selectedPhotoItem) { item in
                guard let item else { return }
                Task {
                    await vm.handlePhotoLibraryImport(item)
                    await MainActor.run {
                        selectedPhotoItem = nil
                    }
                }
            }
            .onReceive(NotificationCenter.default.publisher(for: UIApplication.didReceiveMemoryWarningNotification)) { _ in
                vm.handleMemoryWarning()
            }
            .onReceive(NotificationCenter.default.publisher(for: UIApplication.willResignActiveNotification)) { _ in
                vm.handleAppWillResignActive()
            }
            .onReceive(NotificationCenter.default.publisher(for: UIApplication.didBecomeActiveNotification)) { _ in
                vm.handleAppDidBecomeActive()
            }
        }
    }

    private func horizontalPadding(for width: CGFloat) -> CGFloat {
        if width < 390 { return 8 }
        if width < 430 { return 10 }
        if width < 760 { return 12 }
        if width < 1100 { return 18 }
        return 24
    }

    private func contentMaxWidth(for width: CGFloat) -> CGFloat {
        return .infinity
    }

    private func gridColumns(for width: CGFloat) -> [GridItem] {
        let usable = width - horizontalPadding(for: width) * 2

        if usable >= 1180 {
            return Array(repeating: GridItem(.flexible(minimum: 300), spacing: 16, alignment: .top), count: 3)
        }

        if usable >= 720 {
            return Array(repeating: GridItem(.flexible(minimum: 320), spacing: 16, alignment: .top), count: 2)
        }

        return [GridItem(.flexible(minimum: 0), spacing: 16, alignment: .top)]
    }

    @ViewBuilder
    private func entranceCard<Content: View>(index: Int, @ViewBuilder content: () -> Content) -> some View {
        content()
            .modifier(NonlinearEntranceModifier(index: index, isReady: entranceAnimationReady))
    }

    private func slowMotionTrimScreen(proxy: GeometryProxy) -> some View {
        LiquidGlassRoot(spacing: 18) {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    Card("慢放保留 / 预览", systemImage: "timeline.selection") {
                        VStack(alignment: .leading, spacing: 14) {
                            InfoRow("当前慢放", String(format: "%.3gx", vm.slowMotionFactor))
                            InfoRow("输出起点", String(format: "%.2f 秒", vm.slowMotionOutputStartSeconds))
                            InfoRow("保留时长", String(format: "%.2f 秒", vm.slowMotionKeepSeconds))
                            InfoRow("处理范围", vm.slowMotionSummaryText)

                            if let inputURL = vm.inputURL {
                                let playheadBinding = Binding<Double>(
                                    get: { vm.slowMotionPreviewPlayheadSeconds },
                                    set: { vm.setSlowMotionPreviewPlayhead($0) }
                                )
                                let startBinding = Binding<Double>(
                                    get: { vm.slowMotionOutputStartSeconds },
                                    set: { vm.setSlowMotionStartSeconds($0) }
                                )
                                let endBinding = Binding<Double>(
                                    get: { vm.slowMotionOutputEndSeconds },
                                    set: { vm.setSlowMotionEndSeconds($0) }
                                )
                                let keepBinding = Binding<Double>(
                                    get: { vm.slowMotionKeepSeconds },
                                    set: { vm.setSlowMotionKeepSeconds($0) }
                                )

                                SlowMotionTrimPreview(
                                    videoURL: inputURL,
                                    playheadSeconds: playheadBinding,
                                    maxSeconds: vm.slowMotionMaxOutputSeconds,
                                    sourcePreviewSeconds: vm.slowMotionPreviewSourceSeconds,
                                    sourceStartSeconds: vm.slowMotionSourceStartSeconds,
                                    sourceDurationSeconds: vm.slowMotionSourceDurationSeconds,
                                    frameStepSeconds: vm.slowMotionPreviewFrameStepSeconds,
                                    playbackRate: min(max(vm.slowMotionFactor, 0.05), 1.0)
                                )
                                .disabled(vm.isProcessing)

                                LazyVGrid(columns: [GridItem(.adaptive(minimum: 210), spacing: 12, alignment: .top)], alignment: .leading, spacing: 12) {
                                    PreciseDoubleInput(
                                        title: "播放位置",
                                        value: playheadBinding,
                                        range: 0...max(0.10, vm.slowMotionMaxOutputSeconds),
                                        unit: "秒",
                                        fractionDigits: 3
                                    )
                                    .disabled(vm.isProcessing)

                                    PreciseDoubleInput(
                                        title: "开始时间",
                                        value: startBinding,
                                        range: 0...max(0, vm.slowMotionMaxOutputSeconds - 0.10),
                                        unit: "秒",
                                        fractionDigits: 3
                                    )
                                    .disabled(vm.isProcessing)

                                    PreciseDoubleInput(
                                        title: "结束时间",
                                        value: endBinding,
                                        range: 0.10...max(0.10, vm.slowMotionMaxOutputSeconds),
                                        unit: "秒",
                                        fractionDigits: 3
                                    )
                                    .disabled(vm.isProcessing)

                                    PreciseDoubleInput(
                                        title: "保留时长",
                                        value: keepBinding,
                                        range: 0.10...max(0.10, vm.slowMotionMaxOutputSeconds),
                                        unit: "秒",
                                        fractionDigits: 3
                                    )
                                    .disabled(vm.isProcessing)
                                }
                            } else {
                                EmptyState(text: "先导入视频，再设置慢放后保留多少秒。", systemImage: "film")
                            }

                            Text("播放条只负责预览定位；开始时间、结束时间、保留时长可以精确输入，并会互相同步。App 会按慢放倍数自动换算需要处理的源视频片段。")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                                .lineLimit(nil)
                                .fixedSize(horizontal: false, vertical: true)
                        }
                    }

                    HStack(spacing: 12) {
                        Button {
                            withAnimation(SceneAnimationPreset.sceneSwitch) {
                                showSlowMotionTrimScreen = false
                            }
                        } label: {
                            Label("返回", systemImage: "chevron.left")
                                .frame(maxWidth: .infinity)
                        }
                        .liquidGlassButtonStyle(prominent: false)

                        Button {
                            vm.normalizeSlowMotionKeepSeconds()
                            withAnimation(SceneAnimationPreset.sceneSwitch) {
                                showSlowMotionTrimScreen = false
                            }
                        } label: {
                            Label("完成", systemImage: "checkmark.circle")
                                .frame(maxWidth: .infinity)
                        }
                        .liquidGlassButtonStyle(prominent: true)
                    }
                }
                .padding(.horizontal, horizontalPadding(for: proxy.size.width))
                .padding(.top, max(proxy.safeAreaInsets.top + 34, proxy.size.width < 430 ? 22 : 38))
                .padding(.bottom, max(18, proxy.safeAreaInsets.bottom + 14))
                .frame(maxWidth: contentMaxWidth(for: proxy.size.width))
                .frame(maxWidth: .infinity)
                .frame(minHeight: proxy.size.height, alignment: .top)
            }
            .scrollIndicators(.visible)
        }
    }

    private func startLaunchLoadingScreen(proxy: GeometryProxy, target: StartLaunchTarget) -> some View {
        LiquidGlassRoot(spacing: 18) {
            VStack(spacing: 18) {
                VStack(spacing: 14) {
                    Image(systemName: target.systemImage)
                        .font(.system(size: 38, weight: .semibold))
                        .symbolRenderingMode(.hierarchical)
                        .scaleEffect(startLaunchProgress >= 0.96 ? 1.06 : 1.0)
                        .animation(.interpolatingSpring(mass: 0.72, stiffness: 170, damping: 14), value: startLaunchProgress)

                    Text(target.title)
                        .font(.title2.bold())

                    Text(target.detail)
                        .font(.subheadline)
                        .foregroundStyle(.secondary)

                    LiquidGlassProgressBar(
                        title: "加载中",
                        value: startLaunchProgress,
                        detail: String(format: "%.0f%%", min(max(startLaunchProgress, 0), 1) * 100)
                    )
                    .frame(maxWidth: 520)
                    .padding(.top, 8)
                }
                .padding(22)
                .frame(maxWidth: 620)
                .liquidGlassCard(cornerRadius: 26)

                Text("正在准备界面和状态，加载完后自动进入。")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .padding(.horizontal, 14)
                    .padding(.vertical, 8)
                    .liquidGlassCard(cornerRadius: 16)
            }
            .padding(.horizontal, horizontalPadding(for: proxy.size.width))
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
    }

    private func beginStartLaunch(_ target: StartLaunchTarget) {
        guard startLaunchTarget == nil, !vm.isProcessing else { return }

        UIImpactFeedbackGenerator(style: .light).impactOccurred()
        startLaunchProgress = 0.02
        withAnimation(.interpolatingSpring(mass: 0.76, stiffness: 142, damping: 17)) {
            startLaunchTarget = target
        }

        Task { @MainActor in
            let steps: [(Double, UInt64)] = [
                (0.18, 90_000_000),
                (0.38, 115_000_000),
                (0.64, 130_000_000),
                (0.84, 120_000_000),
                (0.96, 90_000_000)
            ]

            for (value, delay) in steps {
                try? await Task.sleep(nanoseconds: delay)
                withAnimation(.easeOut(duration: 0.20)) {
                    startLaunchProgress = value
                }
            }

            try? await Task.sleep(nanoseconds: 120_000_000)

            withAnimation(SceneAnimationPreset.sceneSwitch) {
                switch target {
                case .workflow(let mode):
                    vm.workflowMode = mode
                    hasSelectedWorkflow = true
                case .benchmark:
                    vm.isBenchmarkMode = true
                    showBenchmarkSetupScreen = true
                case .calibration:
                    showExtremePerformanceScreen = true
                }

                startLaunchTarget = nil
                startLaunchProgress = 0
            }
        }
    }

    private func startSelectionScreen(proxy: GeometryProxy) -> some View {
        LiquidGlassRoot(spacing: 18) {
            VStack(alignment: .leading, spacing: 22) {
                VStack(alignment: .leading, spacing: 8) {
                    Text("Buzhen Local")
                        .font(.largeTitle.bold())
                    Text("选择要使用的功能")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
                .padding(18)
                .frame(maxWidth: .infinity, alignment: .leading)
                .liquidGlassCard(cornerRadius: 24)

                LazyVGrid(columns: gridColumns(for: proxy.size.width), alignment: .leading, spacing: 16) {
                    workflowChoiceCard(
                        mode: .videoInterpolation,
                        title: "视频补帧",
                        detail: "进入刚刚做好的普通补帧流程。",
                        icon: "film.stack"
                    )

                    workflowChoiceCard(
                        mode: .slowMotionInterpolation,
                        title: "慢放补帧",
                        detail: "先按慢放倍数拉长视频，再用光流生成慢放后的补帧视频。",
                        icon: "tortoise"
                    )
                }

                startToolsCard

                Text("风险：慢放补帧会增加输出时长和帧数，处理时间、缓存占用和发热都会比普通补帧更高。")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .padding(12)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .liquidGlassCard(cornerRadius: 16)
            }
            .padding(.horizontal, horizontalPadding(for: proxy.size.width))
            .padding(.top, max(proxy.safeAreaInsets.top + 34, proxy.size.width < 430 ? 22 : 38))
            .padding(.bottom, max(18, proxy.safeAreaInsets.bottom + 14))
            .frame(maxWidth: contentMaxWidth(for: proxy.size.width))
            .frame(maxWidth: .infinity)
            .frame(minHeight: proxy.size.height, alignment: .center)
            .onAppear {
                startEntryHintPulse = false
                withAnimation(.easeInOut(duration: 0.82).repeatCount(6, autoreverses: true)) {
                    startEntryHintPulse = true
                }
                DispatchQueue.main.asyncAfter(deadline: .now() + 5.0) {
                    withAnimation(.easeOut(duration: 0.25)) {
                        startEntryHintPulse = false
                    }
                }
            }
        }
    }

    private var startToolsCard: some View {
        Card("工具", systemImage: "wrench.and.screwdriver") {
            LazyVGrid(columns: [GridItem(.adaptive(minimum: 180), spacing: 12, alignment: .top)], alignment: .leading, spacing: 12) {
                Button {
                    beginStartLaunch(.benchmark)
                } label: {
                    Label("补帧测试", systemImage: "speedometer")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(BouncyLiquidGlassButtonStyle(prominent: false))
                .disabled(vm.isProcessing || startLaunchTarget != nil)

                Button {
                    beginStartLaunch(.calibration)
                } label: {
                    Label("性能校准", systemImage: "gauge.with.dots.needle.67percent")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(BouncyLiquidGlassButtonStyle(prominent: false))
                .disabled(vm.isProcessing || startLaunchTarget != nil)
            }

            Text("补帧测试和性能校准放在开始界面，不再塞进视频补帧流程里。")
                .font(.caption)
                .foregroundStyle(.secondary)
        }
    }

    private func workflowChoiceCard(mode: BuzhenWorkflowMode, title: String, detail: String, icon: String) -> some View {
        Button {
            beginStartLaunch(.workflow(mode))
        } label: {
            VStack(alignment: .leading, spacing: 14) {
                Image(systemName: icon)
                    .font(.system(size: 34, weight: .semibold))
                    .symbolRenderingMode(.hierarchical)

                Text(title)
                    .font(.title3.bold())
                    .foregroundStyle(.primary)

                Text(detail)
                    .font(.footnote)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.leading)

                Spacer(minLength: 0)

                HStack {
                    Label("进入", systemImage: "arrow.right.circle.fill")
                        .font(.footnote.weight(.semibold))
                        .foregroundStyle(.primary)
                        .padding(.horizontal, 14)
                        .padding(.vertical, 10)
                        .background {
                            Capsule()
                                .fill(Color.white.opacity(0.16))
                                .background(.ultraThinMaterial, in: Capsule())
                                .overlay(
                                    Capsule()
                                        .strokeBorder(
                                            LinearGradient(
                                                colors: [
                                                    .white.opacity(0.72),
                                                    .white.opacity(0.18)
                                                ],
                                                startPoint: .topLeading,
                                                endPoint: .bottomTrailing
                                            ),
                                            lineWidth: 1.0
                                        )
                                )
                                .overlay(alignment: .topLeading) {
                                    Capsule()
                                        .fill(
                                            LinearGradient(
                                                colors: [
                                                    .white.opacity(0.42),
                                                    .white.opacity(0.06)
                                                ],
                                                startPoint: .top,
                                                endPoint: .bottom
                                            )
                                        )
                                        .padding(1.2)
                                        .blur(radius: 0.3)
                                        .mask(
                                            Capsule()
                                                .scale(x: 0.96, y: 0.48, anchor: .top)
                                                .offset(y: 1)
                                        )
                                }
                        }
                        .scaleEffect(startEntryHintPulse ? 1.045 : 1.0)
                        .shadow(color: .white.opacity(startEntryHintPulse ? 0.34 : 0.18), radius: startEntryHintPulse ? 9 : 4, x: 0, y: 0)
                    Spacer(minLength: 0)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
            }
            .padding(18)
            .frame(maxWidth: .infinity, minHeight: 185, alignment: .topLeading)
            .liquidGlassCard(cornerRadius: 24)
        }
        .buttonStyle(BouncyLiquidGlassCardButtonStyle())
        .hoverEffect(.highlight)
        .disabled(vm.isProcessing || startLaunchTarget != nil)
    }

    @ViewBuilder
    private func settingsContentLayout(width: CGFloat) -> some View {
        let verticalSpacing: CGFloat = width >= 820 ? 22 : 14
        let horizontalSpacing: CGFloat = width >= 1100 ? 18 : 14

        if width >= 920 {
            VStack(alignment: .leading, spacing: verticalSpacing) {
                HStack(alignment: .top, spacing: horizontalSpacing) {
                    VStack(alignment: .leading, spacing: verticalSpacing) {
                        entranceCard(index: 0) { importCard }
                        entranceCard(index: 2) { processingCard }
                    }
                    .frame(maxWidth: .infinity, alignment: .top)

                    VStack(alignment: .leading, spacing: verticalSpacing) {
                        entranceCard(index: 1) { quickCoreSettingsCard }
                        if vm.workflowMode == .slowMotionInterpolation {
                            entranceCard(index: 2) { slowMotionCard }
                        }
                        entranceCard(index: 3) { startCard }
                    }
                    .frame(maxWidth: .infinity, alignment: .top)
                }

                entranceCard(index: 5) { advancedToolsCard }
            }
        } else {
            VStack(alignment: .leading, spacing: verticalSpacing) {
                entranceCard(index: 0) { importCard }
                entranceCard(index: 1) { quickCoreSettingsCard }
                if vm.workflowMode == .slowMotionInterpolation {
                    entranceCard(index: 2) { slowMotionCard }
                }
                entranceCard(index: 3) { processingCard }
                entranceCard(index: 4) { startCard }
                entranceCard(index: 6) { advancedToolsCard }
            }
        }
    }

    private var appOverviewCard: some View {
        Card("工作流 / 状态", systemImage: "sparkles") {
            VStack(alignment: .leading, spacing: 14) {
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 150), spacing: 10, alignment: .top)], alignment: .leading, spacing: 10) {
                    GlassStepPill(index: "1", title: "导入", detail: "相册 / 文件", systemImage: "square.and.arrow.down")
                    GlassStepPill(index: "2", title: "参数", detail: "帧率 / 光流 / HDR", systemImage: "slider.horizontal.3")
                    GlassStepPill(index: "3", title: "处理", detail: "本地补帧", systemImage: "wand.and.stars")
                    GlassStepPill(index: "4", title: "导出", detail: "保存后自动清理", systemImage: "square.and.arrow.up")
                }

                Divider().opacity(0.35)

                InfoRow("本地处理", "不登录、不上传视频、不调用云端服务")
                InfoRow("当前功能", vm.workflowMode.title)
                InfoRow("当前设备", vm.deviceModelText)
                InfoRow("当前计划", vm.segmentPlanText)

                Button {
                    withAnimation(SceneAnimationPreset.sceneSwitch) {
                        showSlowMotionTrimScreen = false
                        hasSelectedWorkflow = false
                    }
                } label: {
                    Label("返回开始界面", systemImage: "arrow.left.circle")
                        .frame(maxWidth: .infinity)
                }
                .liquidGlassButtonStyle(prominent: false)
                .disabled(vm.isProcessing)

                if let previous = vm.previousFailureText {
                    VStack(alignment: .leading, spacing: 8) {
                        InfoRow("上次任务", previous)

                        Button {
                            vm.dismissPreviousFailure()
                        } label: {
                            Label("隐藏上次提示", systemImage: "xmark.circle")
                                .frame(maxWidth: .infinity)
                        }
                        .liquidGlassButtonStyle(prominent: false)
                    }
                    .padding(10)
                    .liquidGlassCard(cornerRadius: 16)
                }

                if let notice = vm.stabilityNoticeText {
                    Text(notice)
                        .font(.footnote.weight(.semibold))
                        .foregroundStyle(.secondary)
                        .padding(10)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .liquidGlassCard(cornerRadius: 16)
                        .transition(.opacity.combined(with: .scale(scale: 0.96)))
                }

                DisclosureGroup {
                    VStack(alignment: .leading, spacing: 8) {
                        InfoRow("系统内存", vm.totalSystemMemoryText)
                        InfoRow("平台 / 系统", "\(vm.platformText) · \(vm.osVersionText)")
                        InfoRow("热状态", vm.thermalStateText)
                        InfoRow("隐私", "所有补帧、样片、日志都在本机完成；缓存返回时自动清理")
                        InfoRow("性能数据", vm.extremeCalibrationBriefText)
                    }
                    .padding(.top, 6)
                } label: {
                    Label("展开设备 / 隐私详情", systemImage: "info.circle")
                        .font(.footnote.weight(.semibold))
                }
                .padding(10)
                .liquidGlassCard(cornerRadius: 16)
            }
        }
    }

    private var quickCoreSettingsCard: some View {
        Card("核心参数", systemImage: "slider.horizontal.3") {
            VStack(alignment: .leading, spacing: 12) {
                Picker("目标帧率", selection: $vm.targetFPS) {
                    Text("60").tag(60.0)
                    Text("90").tag(90.0)
                    Text("120").tag(120.0)
                    Text("240").tag(240.0)
                }
                .pickerStyle(.segmented)
                .disabled(vm.isProcessing)

                PreciseDoubleInput(
                    title: "精确帧率",
                    value: $vm.targetFPS,
                    range: 24...240,
                    unit: "fps",
                    fractionDigits: 3
                )
                .disabled(vm.isProcessing)

                Picker("光流质量", selection: $vm.quality) {
                    ForEach(OpticalFlowQuality.allCases) { q in
                        Text(q.title).tag(q)
                    }
                }
                .pickerStyle(.menu)
                .disabled(vm.isProcessing)

                Picker("输出模式", selection: $vm.outputMode) {
                    ForEach(OutputMode.allCases) { mode in
                        Text(mode.title).tag(mode)
                    }
                }
                .pickerStyle(.menu)
                .disabled(vm.isProcessing)

                Picker("码率", selection: $vm.bitrateMode) {
                    ForEach(BitrateMode.allCases) { mode in
                        Text(mode.title).tag(mode)
                    }
                }
                .pickerStyle(.segmented)
                .disabled(vm.isProcessing)

                if vm.bitrateMode == .customMbps {
                    Stepper(value: $vm.customBitrateMbps, in: 1...1000, step: 1) {
                        Text("手动码率：\(Int(vm.customBitrateMbps)) Mbps")
                    }
                    .disabled(vm.isProcessing)

                    PreciseDoubleInput(
                        title: "精确码率",
                        value: $vm.customBitrateMbps,
                        range: 1...1000,
                        unit: "Mbps",
                        fractionDigits: 3
                    )
                    .disabled(vm.isProcessing)

                    InfoRow("等于", String(format: "%.0f Kbps", vm.customBitrateMbps * 1000))
                } else if let mbps = vm.recommendedBitrateMbps {
                    InfoRow("自动推荐", String(format: "%.1f Mbps / %.0f Kbps", mbps, mbps * 1000))
                }

                InfoRow("当前", vm.quickRecommendationText)
            }
        }
    }

    private var slowMotionCard: some View {
        Card("慢放补帧", systemImage: "tortoise") {
            VStack(alignment: .leading, spacing: 12) {
                PreciseDoubleInput(
                    title: "慢放倍数",
                    value: $vm.slowMotionFactor,
                    range: 0.01...1,
                    unit: "x",
                    fractionDigits: 3
                )
                .disabled(vm.isProcessing)
                .onChange(of: vm.slowMotionFactor) { _ in
                    vm.normalizeSlowMotionKeepSeconds()
                }

                InfoRow("慢放预览", vm.slowMotionSummaryText)

                Button {
                    withAnimation(SceneAnimationPreset.sceneSwitch) {
                        showSlowMotionTrimScreen = true
                    }
                } label: {
                    Label("设置保留秒数 / 预览", systemImage: "timeline.selection")
                        .frame(maxWidth: .infinity)
                }
                .liquidGlassButtonStyle(prominent: false)
                .disabled(vm.isProcessing)

                Text("保留多少秒、预览和拖动条已移到独立页面，主页面只保留核心慢放倍数，避免太挤。")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .lineLimit(nil)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
    }

    private var advancedToolsCard: some View {
        Card("高级设置 / 工具", systemImage: "ellipsis.circle") {
            VStack(alignment: .leading, spacing: 12) {
                DisclosureGroup {
                    VStack(alignment: .leading, spacing: 12) {
                        videoInfoCard
                        outputCard
                    }
                    .padding(.top, 8)
                } label: {
                    Label("展开视频 / 音频 / HDR 细节", systemImage: "slider.horizontal.3")
                        .font(.footnote.weight(.semibold))
                }
                .padding(10)
                .liquidGlassCard(cornerRadius: 16)

                DisclosureGroup {
                    VStack(alignment: .leading, spacing: 12) {
                        cacheCard
                        #if targetEnvironment(macCatalyst)
                        macDesktopPerformanceCard
                        #endif
                    }
                    .padding(.top, 8)
                } label: {
                    Label("展开缓存 / 设备工具", systemImage: "externaldrive")
                        .font(.footnote.weight(.semibold))
                }
                .padding(10)
                .liquidGlassCard(cornerRadius: 16)

                Text("正式版默认只显示主要流程；主页面放核心参数，测试/缓存/视频音频细节放在高级设置里。")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .lineLimit(nil)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
    }

    private var localProcessingNoticeCard: some View {
        Card("本地处理 / 隐私说明", systemImage: "lock.shield") {
            VStack(alignment: .leading, spacing: 10) {
                InfoRow("处理方式", "所有补帧、慢放补帧、性能测试、样片生成、日志生成都在本机完成")
                InfoRow("网络", "不需要登录账号，不上传视频，不调用云端补帧服务")
                InfoRow("媒体权限", "相册/文件只用于用户主动选择视频和保存导出结果")
                InfoRow("缓存", "中间文件保存在 App 沙盒内；处理完成返回时自动清理")
                InfoRow("App Store", "已加入隐私清单 PrivacyInfo.xcprivacy；隐私政策：https://adamdashen666.github.io/buzhen-ios-app/privacy.html")
                InfoRow("支持", "Support URL：https://adamdashen666.github.io/buzhen-ios-app/privacy.html")

                Text("注意：如果以后加入统计、广告、登录、云处理或崩溃上报 SDK，App Store 隐私标签必须同步更新。")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .lineLimit(nil)
                    .fixedSize(horizontal: false, vertical: true)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
        }
    }

    private var deviceSystemInfoCard: some View {
        Card("设备信息", systemImage: "info.circle") {
            VStack(alignment: .leading, spacing: 12) {
                VStack(alignment: .leading, spacing: 8) {
                    InfoRow("设备型号", vm.deviceModelText)
                    InfoRow("芯片", vm.chipText)
                    InfoRow("CPU 核心", vm.cpuCoreText)
                    InfoRow("系统内存", vm.totalSystemMemoryText)
                    InfoRow("平台", vm.platformText)
                    InfoRow("系统版本", vm.osVersionText)
                    InfoRow("热状态", vm.thermalStateText)
                    InfoRow("最高并行", vm.maxExtremeWorkerText)
                }

                Divider().opacity(0.35)

                VStack(alignment: .leading, spacing: 8) {
                    InfoRow("硬件标识", vm.deviceIdentifierText)
                    InfoRow("性能采样", vm.performanceSourceText)
                    InfoRow("自动并行", vm.autoParallelPreviewText)
                    InfoRow("性能校准", vm.extremeCalibrationBriefText)
                }

                Text("这些是 App 当前能直接读取到的信息；GPU 真实占用仍需 Xcode Instruments 查看。")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .lineLimit(nil)
                    .fixedSize(horizontal: false, vertical: true)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
    }

    private func extremePerformanceScreen(proxy: GeometryProxy) -> some View {
        LiquidGlassRoot(spacing: 18) {
            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    VStack(alignment: .leading, spacing: 12) {
                        ViewThatFits(in: .horizontal) {
                            HStack(spacing: 12) {
                                Image(systemName: "gauge.with.dots.needle.67percent")
                                    .font(.system(size: 36, weight: .semibold))
                                    .symbolRenderingMode(.hierarchical)

                                VStack(alignment: .leading, spacing: 4) {
                                    Text("性能校准")
                                        .font(.title2.bold())
                                    Text("选择一个清晰度做本机性能测试；每个清晰度的数据都会独立保存。")
                                        .font(.subheadline)
                                        .foregroundStyle(.secondary)
                                }

                                Spacer(minLength: 8)

                                Button {
                                    withAnimation(SceneAnimationPreset.sceneSwitch) {
                                        showExtremePerformanceScreen = false
                                    }
                                } label: {
                                    Label("返回", systemImage: "chevron.backward")
                                }
                                .buttonStyle(.bordered)
                                .disabled(vm.isProcessing || vm.isRunningExtremePerformanceTest)
                            }

                            VStack(alignment: .leading, spacing: 10) {
                                HStack(spacing: 10) {
                                    Image(systemName: "gauge.with.dots.needle.67percent")
                                        .font(.system(size: 32, weight: .semibold))
                                        .symbolRenderingMode(.hierarchical)

                                    Button {
                                        withAnimation(SceneAnimationPreset.sceneSwitch) {
                                            showExtremePerformanceScreen = false
                                        }
                                    } label: {
                                        Label("返回", systemImage: "chevron.backward")
                                    }
                                    .buttonStyle(.bordered)
                                    .disabled(vm.isProcessing || vm.isRunningExtremePerformanceTest)
                                }

                                Text("性能校准")
                                    .font(.title2.bold())
                                Text("选择一个清晰度做本机性能测试；每个清晰度的数据都会独立保存。")
                                    .font(.subheadline)
                                    .foregroundStyle(.secondary)
                            }
                        }
                    }
                    .padding(18)
                    .liquidGlassCard(cornerRadius: 24)

                    Card("测试参数", systemImage: "lock.fill") {
                        VStack(alignment: .leading, spacing: 12) {
                            Picker("测试清晰度", selection: $vm.benchmarkResolution) {
                                ForEach(BenchmarkResolution.allCases) { resolution in
                                    Text(resolution.title).tag(resolution)
                                }
                            }
                            .pickerStyle(.segmented)
                            .disabled(vm.isProcessing || vm.isPreparingBenchmark || vm.isRunningExtremePerformanceTest)

                            InfoRow("本次清晰度", vm.benchmarkResolution.title)
                            InfoRow("原始帧率", "60 fps")
                            InfoRow("样片时长", "至少 12 秒")
                            InfoRow("目标帧率", "120 fps")
                            InfoRow("光流质量", "1 快速")
                            InfoRow("处理模式", "并行分段 · 自动寻找稳定并行范围")
                            InfoRow("数据保存", "每个清晰度独立保存；自动模式会使用最接近当前视频分辨率的数据")
                        }
                    }

                    if vm.shouldShowProgressPanel || vm.isRunningExtremePerformanceTest {
                        progressStatusCard
                    }

                    Card("开始测试", systemImage: "speedometer") {
                        VStack(alignment: .leading, spacing: 12) {
                            InfoRow("当前状态", vm.extremePerformanceStatusText)

                            Button {
                                vm.isPreparingBenchmark = true
                                Task { await vm.startExtremePerformanceTest() }
                            } label: {
                                Label(vm.isRunningExtremePerformanceTest ? "性能校准中..." : "开始性能校准", systemImage: "play.fill")
                                    .frame(maxWidth: .infinity)
                            }
                            .liquidGlassButtonStyle(prominent: true)
                            .disabled(vm.isProcessing || vm.isPreparingBenchmark || vm.isRunningExtremePerformanceTest)

                            Text("只测试当前选择的清晰度；其他清晰度的历史数据会保留，测试完成后会汇总所有已保存数据。")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                    }

                    Card("测试结果", systemImage: "list.clipboard") {
                        Text(vm.extremePerformanceResultsText)
                            .font(.footnote.monospaced())
                            .foregroundStyle(.secondary)
                            .textSelection(.enabled)
                            .frame(maxWidth: .infinity, alignment: .leading)
                    }
                }
                .padding(.horizontal, horizontalPadding(for: proxy.size.width))
                .padding(.top, max(proxy.safeAreaInsets.top + 34, proxy.size.width < 430 ? 22 : 38))
                .padding(.bottom, max(18, proxy.safeAreaInsets.bottom + 14))
                .frame(maxWidth: .infinity)
                .frame(minHeight: proxy.size.height, alignment: .top)
            }
            .scrollIndicators(.visible)
        }
    }

    private func benchmarkSetupScreen(proxy: GeometryProxy) -> some View {
        LiquidGlassRoot(spacing: 18) {
            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    VStack(alignment: .leading, spacing: 12) {
                        ViewThatFits(in: .horizontal) {
                            HStack(spacing: 12) {
                                Image(systemName: "speedometer")
                                    .font(.system(size: 36, weight: .semibold))
                                    .symbolRenderingMode(.hierarchical)

                                VStack(alignment: .leading, spacing: 4) {
                                    Text("补帧测试")
                                        .font(.title2.bold())
                                    Text("可调参数，用内置 sample 视频测试补帧速度、CPU、GPU 估算和内存。")
                                        .font(.subheadline)
                                        .foregroundStyle(.secondary)
                                }

                                Spacer(minLength: 8)

                                Button {
                                    withAnimation(SceneAnimationPreset.sceneSwitch) {
                                        vm.isBenchmarkMode = false
                                        showBenchmarkSetupScreen = false
                                    }
                                } label: {
                                    Label("返回", systemImage: "chevron.backward")
                                }
                                .buttonStyle(.bordered)
                            }

                            VStack(alignment: .leading, spacing: 10) {
                                HStack(spacing: 10) {
                                    Image(systemName: "speedometer")
                                        .font(.system(size: 32, weight: .semibold))
                                        .symbolRenderingMode(.hierarchical)

                                    Button {
                                        withAnimation(SceneAnimationPreset.sceneSwitch) {
                                            vm.isBenchmarkMode = false
                                            showBenchmarkSetupScreen = false
                                        }
                                    } label: {
                                        Label("返回", systemImage: "chevron.backward")
                                    }
                                    .buttonStyle(.bordered)
                                }

                                Text("补帧测试")
                                    .font(.title2.bold())
                                Text("可调参数，用内置 sample 视频测试补帧速度、CPU、GPU 估算和内存。")
                                    .font(.subheadline)
                                    .foregroundStyle(.secondary)
                            }
                        }
                    }
                    .padding(18)
                    .liquidGlassCard(cornerRadius: 24)

                    benchmarkSampleCard
                    benchmarkSettingsLayout(width: proxy.size.width)
                    benchmarkStartCard
                }
                .padding(.horizontal, horizontalPadding(for: proxy.size.width))
                .padding(.top, max(proxy.safeAreaInsets.top + 34, proxy.size.width < 430 ? 22 : 38))
                .padding(.bottom, max(18, proxy.safeAreaInsets.bottom + 14))
                .frame(maxWidth: .infinity)
                .frame(minHeight: proxy.size.height, alignment: .top)
            }
            .scrollIndicators(.visible)
        }
    }

    @ViewBuilder
    private func benchmarkSettingsLayout(width: CGFloat) -> some View {
        let usableWidth = width - horizontalPadding(for: width) * 2

        if usableWidth >= 820 {
            HStack(alignment: .top, spacing: 28) {
                VStack(alignment: .leading, spacing: 24) {
                    entranceCard(index: 0) { fpsCard }
                    entranceCard(index: 2) { qualityCard }
                    entranceCard(index: 4) { bitrateCard }
                }
                .frame(maxWidth: .infinity, alignment: .topLeading)

                VStack(alignment: .leading, spacing: 24) {
                    entranceCard(index: 1) { outputCard }
                    entranceCard(index: 3) { processingCard }
                    entranceCard(index: 5) { cacheCard }
                    #if targetEnvironment(macCatalyst)
                    entranceCard(index: 6) { macDesktopPerformanceCard }
                    #endif
                }
                .frame(maxWidth: .infinity, alignment: .topLeading)
            }
        } else {
            VStack(alignment: .leading, spacing: 14) {
                entranceCard(index: 0) { fpsCard }
                entranceCard(index: 1) { outputCard }
                entranceCard(index: 2) { qualityCard }
                entranceCard(index: 3) { processingCard }
                entranceCard(index: 4) { bitrateCard }
                entranceCard(index: 5) { cacheCard }
                #if targetEnvironment(macCatalyst)
                entranceCard(index: 6) { macDesktopPerformanceCard }
                #endif
            }
        }
    }

    private func initializationOnlyScreen(proxy: GeometryProxy) -> some View {
        LiquidGlassRoot(spacing: 0) {
            VStack {
                Spacer(minLength: 0)

                LiquidGlassProgressBar(
                    title: "初始化",
                    value: vm.initializationProgressValue,
                    detail: vm.initializationDetailText
                )
                .frame(maxWidth: min(520, max(280, proxy.size.width - 64)))
                .padding(.horizontal, 32)
                .transition(.opacity.combined(with: .scale(scale: 0.985)))

                Spacer(minLength: 0)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
    }

    private func processingOnlyScreen(proxy: GeometryProxy) -> some View {
        LiquidGlassRoot(spacing: 18) {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    VStack(alignment: .leading, spacing: 12) {
                        ViewThatFits(in: .horizontal) {
                            HStack(spacing: 12) {
                                Image(systemName: vm.isProcessing ? "bolt.horizontal.circle" : (vm.errorMessage == nil ? "checkmark.circle" : "xmark.octagon"))
                                    .font(.system(size: 36, weight: .semibold))
                                    .symbolRenderingMode(.hierarchical)

                                VStack(alignment: .leading, spacing: 4) {
                                    Text(vm.isProcessing ? "正在补帧" : (vm.errorMessage == nil ? "补帧完成" : "补帧失败"))
                                        .font(.title2.bold())
                                    Text(vm.isProcessing ? "处理中不可返回，防止任务中断。" : (vm.errorMessage == nil ? (vm.isBenchmarkMode ? "导出日志后返回会自动清理缓存。" : "导出视频后返回会自动清理缓存。") : "处理失败，可以复制错误日志或返回设置。"))
                                        .font(.subheadline)
                                        .foregroundStyle(.secondary)
                                }

                                Spacer(minLength: 8)

                                StatusBadge(text: vm.progressPercentText, systemImage: "waveform.path.ecg")
                            }

                            VStack(alignment: .leading, spacing: 10) {
                                HStack(spacing: 10) {
                                    Image(systemName: vm.isProcessing ? "bolt.horizontal.circle" : (vm.errorMessage == nil ? "checkmark.circle" : "xmark.octagon"))
                                        .font(.system(size: 32, weight: .semibold))
                                        .symbolRenderingMode(.hierarchical)

                                    StatusBadge(text: vm.progressPercentText, systemImage: "waveform.path.ecg")
                                }

                                Text(vm.isProcessing ? "正在补帧" : (vm.errorMessage == nil ? "补帧完成" : "补帧失败"))
                                    .font(.title2.bold())
                                Text(vm.isProcessing ? "处理中不可返回，防止任务中断。" : (vm.errorMessage == nil ? (vm.isBenchmarkMode ? "导出日志后返回会自动清理缓存。" : "导出视频后返回会自动清理缓存。") : "处理失败，可以复制错误日志或返回设置。"))
                                    .font(.subheadline)
                                    .foregroundStyle(.secondary)
                            }
                        }

                        ProcessingProgressRing(
                            value: vm.progress,
                            percentText: vm.progressPercentText,
                            isComplete: !vm.isProcessing && vm.outputURL != nil && vm.errorMessage == nil
                        )
                        .frame(maxWidth: .infinity)

                        LiquidGlassProgressBar(title: "总进度", value: vm.progress, detail: vm.progressPercentText)

                        Text(vm.status)
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                            .textSelection(.enabled)
                    }
                    .padding(18)
                    .liquidGlassCard(cornerRadius: 24)

                    progressStatusCard
                    performanceCard

                    if !vm.isProcessing {
                        completionActionCard
                    }
                }
                .padding(.horizontal, horizontalPadding(for: proxy.size.width))
                .padding(.top, max(16, proxy.safeAreaInsets.top + 10))
                .padding(.bottom, max(28, proxy.safeAreaInsets.bottom + 18))
                .frame(maxWidth: .infinity)
                .frame(minHeight: proxy.size.height, alignment: .top)
            }
            .scrollIndicators(.visible)
        }
    }

    private var completionActionCard: some View {
        Card(vm.errorMessage == nil ? "导出结果" : "处理失败", systemImage: vm.errorMessage == nil ? "square.and.arrow.up" : "xmark.octagon") {
            VStack(alignment: .leading, spacing: 12) {
                if let error = vm.errorMessage {
                    Text(error)
                        .font(.footnote)
                        .foregroundStyle(.red)
                        .textSelection(.enabled)

                    Button {
                        vm.copyFullErrorLogToClipboard()
                    } label: {
                        Label("复制错误日志", systemImage: "doc.on.doc")
                            .frame(maxWidth: .infinity)
                    }
                    .liquidGlassButtonStyle(prominent: false)
                } else if vm.outputURL != nil {
                    SuccessPulseView()
                        .frame(maxWidth: .infinity)
                }

                if let copyMessage = vm.copyStatusMessage {
                    Text(copyMessage)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                if let outputURL = vm.outputURL {
                    if vm.isBenchmarkMode {
                        Text("测试完成，结果已保存到性能数据。")
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                    } else {
                        Text(outputURL.lastPathComponent)
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                            .lineLimit(2)
                            .textSelection(.enabled)

                        Button {
                            Task { await vm.saveOutputToPhotos() }
                        } label: {
                            Label(vm.isSavingToPhotos ? "正在保存到相册..." : "保存到相册", systemImage: "photo.badge.plus")
                                .frame(maxWidth: .infinity)
                        }
                        .liquidGlassButtonStyle(prominent: true)
                        .disabled(vm.isSavingToPhotos)

                        ShareLink(item: outputURL) {
                            Label("分享到文件 / 其他 App", systemImage: "square.and.arrow.up")
                                .frame(maxWidth: .infinity)
                        }
                        .liquidGlassButtonStyle(prominent: false)
                    }
                }

                if let logURL = vm.performanceLogURL {
                    ShareLink(item: logURL) {
                        Label("导出处理日志", systemImage: "doc.text")
                            .frame(maxWidth: .infinity)
                    }
                    .liquidGlassButtonStyle(prominent: false)
                }

                if !vm.isBenchmarkMode, vm.inputURL != nil {
                    Button {
                        vm.prepareReprocessFromCompletion()
                    } label: {
                        Label("重新调整参数", systemImage: "arrow.counterclockwise")
                            .frame(maxWidth: .infinity)
                    }
                    .liquidGlassButtonStyle(prominent: false)
                }

                Button {
                    vm.leaveProcessingScreen()
                } label: {
                    Label("返回并清理缓存", systemImage: "chevron.backward")
                        .frame(maxWidth: .infinity)
                }
                .liquidGlassButtonStyle(prominent: false)
            }
        }
    }

    #if targetEnvironment(macCatalyst)
    private var macDesktopPerformanceCard: some View {
        Card("Mac 运行状态", systemImage: "desktopcomputer.and.macbook") {
            VStack(alignment: .leading, spacing: 10) {
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 150), spacing: 10, alignment: .top)], alignment: .leading, spacing: 10) {
                    MetricTile(title: "CPU 核心", value: vm.cpuCoreText, systemImage: "cpu")
                    MetricTile(title: "系统内存", value: vm.totalSystemMemoryText, systemImage: "memorychip")
                    MetricTile(title: "采样来源", value: vm.performanceSourceText, systemImage: "waveform.path.ecg")
                    MetricTile(title: "平台", value: vm.platformText, systemImage: "laptopcomputer")
                }

                InfoRow("说明", "显示当前任务的运行状态。")
                InfoRow("适合场景", "长视频、并行分段、终极 AI 混合光流。")
            }
        }
    }
    #endif

    private var performanceCard: some View {
        Card("性能状态", systemImage: "speedometer") {
            VStack(alignment: .leading, spacing: 12) {
                LiquidGlassProgressBar(title: "CPU", value: vm.cpuUsageFraction, detail: vm.cpuUsageText)
                LiquidGlassProgressBar(title: "GPU", value: vm.gpuEstimateFraction, detail: vm.gpuEstimateText)
                LiquidGlassProgressBar(title: "内存", value: vm.memoryUsageFraction, detail: vm.memoryUsageText)

                LazyVGrid(columns: [GridItem(.adaptive(minimum: 140), spacing: 8, alignment: .top)], alignment: .leading, spacing: 10) {
                    MetricTile(title: "速度", value: vm.processingSpeedText, systemImage: "speedometer")
                    MetricTile(title: "平均", value: vm.averageSpeedText, systemImage: "chart.line.uptrend.xyaxis")
                    MetricTile(title: "温度", value: vm.thermalStateText, systemImage: "thermometer.medium")
                    MetricTile(title: "剩余", value: vm.estimatedRemainingText, systemImage: "timer")
                }

                InfoRow("已运行", vm.elapsedTimeText)
                InfoRow("任务", vm.liveWorkerText)

                DisclosureGroup {
                    VStack(alignment: .leading, spacing: 8) {
                        LiquidGlassProgressBar(title: "线程负载", value: vm.cpuThreadLoadFraction, detail: vm.cpuTotalThreadText)
                        InfoRow("最高单线程", vm.cpuPeakThreadText)
                        InfoRow("峰值速度", vm.peakSpeedText)
                        InfoRow("最低速度", vm.lowestSpeedText)
                        InfoRow("采样", "\(vm.performanceLogSampleCount) 条")
                    }
                    .padding(.top, 6)
                } label: {
                    Label("高级运行数据", systemImage: "waveform.path.ecg")
                        .font(.footnote.weight(.semibold))
                }
                .padding(10)
                .liquidGlassCard(cornerRadius: 16)
            }
        }
    }

    private var headerCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            ViewThatFits(in: .horizontal) {
                HStack(spacing: 12) {
                    Image(systemName: "sparkles.tv")
                        .font(.system(size: 32, weight: .semibold))
                        .symbolRenderingMode(.hierarchical)

                    VStack(alignment: .leading, spacing: 3) {
                        Text("Buzhen Local v101")
                            .font(.title2.bold())
                        Text("本地补帧 · 不上传视频 · 本机处理")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                    }

                    Spacer(minLength: 8)

                    StatusBadge(text: vm.inputURL == nil ? "未导入" : "已导入", systemImage: vm.inputURL == nil ? "tray" : "checkmark.circle")
                }

                VStack(alignment: .leading, spacing: 10) {
                    HStack(spacing: 10) {
                        Image(systemName: "sparkles.tv")
                            .font(.system(size: 30, weight: .semibold))
                            .symbolRenderingMode(.hierarchical)

                        StatusBadge(text: vm.inputURL == nil ? "未导入" : "已导入", systemImage: vm.inputURL == nil ? "tray" : "checkmark.circle")
                    }

                    Text("Buzhen Local v101")
                        .font(.title2.bold())
                    Text("本地补帧 · 不上传视频 · 本机处理")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
            }

            if vm.isProcessing {
                LiquidGlassProgressBar(title: "总进度", value: vm.progress, detail: vm.progressPercentText)
                Text(vm.status)
                    .font(.footnote)
                    .foregroundStyle(.secondary)
                    .lineLimit(2)
            }
        }
        .padding(18)
        .liquidGlassCard(cornerRadius: 24)
    }

    private var progressStatusCard: some View {
        Card("处理进度", systemImage: "chart.line.uptrend.xyaxis") {
            VStack(alignment: .leading, spacing: 14) {
                LiquidGlassProgressBar(title: "总进度", value: vm.progress, detail: vm.progressPercentText)

                HStack(spacing: 8) {
                    StatusBadge(text: vm.processingMode.title, systemImage: "square.stack.3d.up")
                    StatusBadge(text: vm.workerSummaryText, systemImage: "person.2.wave.2")
                    StatusBadge(text: vm.segmentSummaryText, systemImage: "scissors")
                }

                VStack(alignment: .leading, spacing: 8) {
                    InfoRow("当前阶段", vm.status)
                    if let stage = vm.currentStageText {
                        InfoRow("阶段状态", stage)
                    }
                }

                if !vm.segmentRows.isEmpty {
                    Divider()

                    HStack {
                        Text("分段任务")
                            .font(.subheadline.weight(.semibold))
                        Spacer()
                        Text("\(vm.completedSegmentCount)/\(vm.segmentRows.count) 完成")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }

                    ScrollView {
                        LazyVStack(spacing: 10) {
                            ForEach(vm.segmentRows) { row in
                                SegmentProgressRowView(row: row)
                            }
                        }
                        .padding(.vertical, 2)
                    }
                    .frame(maxHeight: vm.segmentRows.count > 6 ? 330 : nil)
                }
            }
        }
    }

    private var benchmarkSampleCard: some View {
        Card("Sample 视频", systemImage: "testtube.2") {
            VStack(alignment: .leading, spacing: 12) {
                Picker("清晰度", selection: $vm.benchmarkResolution) {
                    ForEach(BenchmarkResolution.allCases) { resolution in
                        Text(resolution.title).tag(resolution)
                    }
                }
                .pickerStyle(.segmented)
                .disabled(vm.isProcessing)

                Picker("原始帧率", selection: $vm.benchmarkSourceFPS) {
                    ForEach(BenchmarkSourceFPS.allCases) { fps in
                        Text(fps.title).tag(fps)
                    }
                }
                .pickerStyle(.segmented)
                .disabled(vm.isProcessing)

                InfoRow("样片参数", vm.benchmarkSampleSummaryText)

                PreciseDoubleInput(
                    title: "样片时长",
                    value: $vm.benchmarkDurationSeconds,
                    range: 1...30,
                    unit: "秒",
                    fractionDigits: 1
                )
                .disabled(vm.isProcessing)

                InfoRow("测试时长", vm.benchmarkDurationText)

                Text("点击开始后会按所选清晰度、原始帧率和时长生成内置 sample 视频，并使用单次完整处理进行测试。")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
    }

    private var performanceCalibrationCard: some View {
        Card("性能校准", systemImage: "gauge.with.dots.needle.67percent") {
            VStack(alignment: .leading, spacing: 12) {
                InfoRow("校准结果", vm.calibrationResultText)
                InfoRow("校准状态", vm.calibrationStatusText)

                Button {
                    vm.isPreparingBenchmark = true
                    Task { await vm.startPerformanceCalibration() }
                } label: {
                    Label(vm.isCalibratingPerformance ? "校准中..." : "开始性能校准", systemImage: "speedometer")
                        .frame(maxWidth: .infinity)
                }
                .liquidGlassButtonStyle(prominent: false)
                .disabled(vm.isProcessing || vm.isPreparingBenchmark || vm.isCalibratingPerformance)

                Text("会用当前样片清晰度、原始帧率和光流质量测试多个并行数；校准样片至少 12 秒，并丢弃启动预热段，除非失败或超过 90% 内存预算，否则选择稳定 total frame/s 最高的配置。")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
    }

    private var benchmarkStartCard: some View {
        Card("开始性能校准", systemImage: "speedometer") {
            VStack(alignment: .leading, spacing: 14) {
                Button {
                    vm.isPreparingBenchmark = true
                    Task { await vm.startBenchmark() }
                } label: {
                    Label(vm.isPreparingBenchmark ? "生成样片中..." : (vm.isProcessing ? "测试中..." : "生成样片并开始测试"), systemImage: "play.fill")
                        .frame(maxWidth: .infinity)
                }
                .liquidGlassButtonStyle(prominent: true)
                .disabled(vm.isProcessing || vm.isPreparingBenchmark)

                if let error = vm.errorMessage {
                    Text(error)
                        .font(.footnote)
                        .foregroundStyle(.red)
                        .textSelection(.enabled)
                }

                Text("测试会按当前处理模式运行，并记录速度、内存、温度和处理日志。")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
    }

    private var importCard: some View {
        Card("导入视频", systemImage: "square.and.arrow.down") {
            VStack(spacing: 12) {
                Button {
                    vm.isBenchmarkMode = false
                    showPhotosPicker = true
                } label: {
                    Label("从相册选择视频", systemImage: "photo.on.rectangle")
                        .frame(maxWidth: .infinity)
                }
                .liquidGlassButtonStyle(prominent: true)
                .disabled(vm.isProcessing)

                Button {
                    vm.isBenchmarkMode = false
                    showDocumentPicker = true
                } label: {
                    Label("从文件选择视频", systemImage: "folder")
                        .frame(maxWidth: .infinity)
                }
                .liquidGlassButtonStyle(prominent: false)
                .disabled(vm.isProcessing)

                if let inputURL = vm.inputURL {
                    Divider()

                    VStack(alignment: .leading, spacing: 6) {
                        Text("当前视频")
                            .font(.caption)
                            .foregroundStyle(.secondary)

                        Text(inputURL.lastPathComponent)
                            .font(.footnote.weight(.medium))
                            .lineLimit(2)
                            .textSelection(.enabled)
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)

                    Button(role: .destructive) {
                        vm.clearImportedVideo()
                    } label: {
                        Label("清除视频", systemImage: "trash")
                            .frame(maxWidth: .infinity)
                    }
                    .liquidGlassButtonStyle(prominent: false)
                    .disabled(vm.isProcessing)
                }

                Text("v71：编码器稳定修复版；HDR/高帧率会自动限制并行并失败重试。")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
        }
    }

    private var videoInfoCard: some View {
        Card("视频信息", systemImage: "info.circle") {
            if let info = vm.videoInfo {
                VStack(alignment: .leading, spacing: 10) {
                    InfoRow("分辨率", "\(info.width) × \(info.height)")
                    InfoRow("帧率", String(format: "%.3f fps", info.fps))
                    InfoRow("时长", info.durationText)
                    InfoRow("编码", info.codec)
                    InfoRow("HDR", info.hdrName)
                    InfoRow("音频", info.hasAudio ? "有" : "无")
                    InfoRow("估算码率", info.bitrateText)
                }
            } else {
                EmptyState(text: "导入视频后显示参数。", systemImage: "film")
            }
        }
    }

    private var fpsCard: some View {
        Card("目标帧率", systemImage: "speedometer") {
            VStack(alignment: .leading, spacing: 12) {
                Picker("目标帧率", selection: $vm.targetFPS) {
                    Text("60").tag(60.0)
                    Text("90").tag(90.0)
                    Text("120").tag(120.0)
                    Text("240").tag(240.0)
                }
                .pickerStyle(.segmented)
                .disabled(vm.isProcessing)

                Stepper(value: $vm.targetFPS, in: 24...240, step: 1) {
                    Text("自定义：\(Int(vm.targetFPS)) fps")
                }
                .disabled(vm.isProcessing)

                PreciseDoubleInput(
                    title: "精确帧率",
                    value: $vm.targetFPS,
                    range: 24...240,
                    unit: "fps",
                    fractionDigits: 3
                )
                .disabled(vm.isProcessing)

                Text("导入后会自动按原帧率推荐目标帧率，也可以手动输入精确数字。")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
    }

    private var outputCard: some View {
        Card("音频 / HDR 细节", systemImage: "rectangle.on.rectangle") {
            VStack(alignment: .leading, spacing: 12) {

                Toggle(isOn: $vm.keepAudio) {
                    Text("复制原音频")
                        .lineLimit(2)
                        .fixedSize(horizontal: false, vertical: true)
                }
                .disabled(vm.isProcessing)

                Toggle(isOn: $vm.keepMetadata) {
                    Text("复制元数据/章节")
                        .lineLimit(2)
                        .fixedSize(horizontal: false, vertical: true)
                }
                .disabled(vm.isProcessing)

                Toggle(isOn: $vm.preserveHDRTags) {
                    Text("尝试保留 HDR 色彩标签")
                        .lineLimit(2)
                        .minimumScaleFactor(0.72)
                        .fixedSize(horizontal: false, vertical: true)
                }
                .disabled(vm.outputMode != .hdrPreserve || vm.isProcessing)

                Text("HDR 模式会写入 BT.2020/PQ/HLG 相关输出标签；完整杜比视界元数据不保证。")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .lineLimit(nil)
                    .fixedSize(horizontal: false, vertical: true)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
        }
    }

    private var qualityCard: some View {
        Card("光流质量", systemImage: "point.3.connected.trianglepath.dotted") {
            VStack(alignment: .leading, spacing: 12) {
                Picker("光流质量", selection: $vm.quality) {
                    ForEach(OpticalFlowQuality.allCases) { q in
                        Text(q.title).tag(q)
                    }
                }
                .pickerStyle(.menu)
                .disabled(vm.isProcessing)

                Text(vm.quality.subtitle)
                    .font(.footnote)
                    .foregroundStyle(.secondary)

                VStack(alignment: .leading, spacing: 6) {
                    QualityLine(index: "1", title: "快速", detail: "速度优先")
                    QualityLine(index: "2", title: "高质量光流", detail: "画质优先")
                    QualityLine(index: "3", title: "终极 AI 混合", detail: "绝对质量，最慢")
                }
            }
        }
    }

    private var processingCard: some View {
        Card("处理模式", systemImage: "square.stack.3d.up") {
            VStack(alignment: .leading, spacing: 12) {
                InfoRow("性能配置", "高性能（默认）")
                InfoRow("设备内存", vm.totalSystemMemoryText)

                Picker("处理模式", selection: $vm.processingMode) {
                    ForEach(ProcessingMode.allCases) { mode in
                        Text(mode.title).tag(mode)
                    }
                }
                .pickerStyle(.menu)
                .disabled(vm.isProcessing || vm.isPreparingBenchmark)

                Text(vm.processingMode.subtitle)
                    .font(.footnote)
                    .foregroundStyle(.secondary)

                if vm.processingMode == .serialSegmented {
                    Stepper(value: $vm.desiredSegmentCount, in: 1...360, step: 1) {
                        Text("分段数量：\(vm.desiredSegmentCount)")
                    }
                    .disabled(vm.isProcessing)

                    PreciseIntInput(
                        title: "串行分段数量",
                        value: $vm.desiredSegmentCount,
                        range: 1...360,
                        unit: "段"
                    )
                    .disabled(vm.isProcessing)

                    if let count = vm.estimatedSegmentCount {
                        StatusBadge(text: "预计 \(count) 段", systemImage: "scissors")
                    }
                }

                if vm.processingMode == .parallelSegmented {
                    Picker("分段并行调度", selection: $vm.parallelTuningMode) {
                        ForEach(ParallelTuningMode.allCases) { mode in
                            Text(mode.title).tag(mode)
                        }
                    }
                    .pickerStyle(.segmented)
                    .disabled(vm.isProcessing || vm.isPreparingBenchmark)

                    Text(vm.parallelTuningMode.subtitle)
                        .font(.caption)
                        .foregroundStyle(.secondary)

                    if vm.parallelTuningMode == .manual {
                        Stepper(value: $vm.desiredSegmentCount, in: 1...360, step: 1) {
                            Text("分段数量：\(vm.desiredSegmentCount)")
                        }
                        .disabled(vm.isProcessing)

                        PreciseIntInput(
                            title: "分段数量",
                            value: $vm.desiredSegmentCount,
                            range: 1...360,
                            unit: "段"
                        )
                        .disabled(vm.isProcessing)

                        Stepper(value: $vm.maxParallelJobs, in: 1...32, step: 1) {
                            Text("并行任务：\(vm.maxParallelJobs)")
                        }
                        .disabled(vm.isProcessing)

                        PreciseIntInput(
                            title: "并行任务数",
                            value: $vm.maxParallelJobs,
                            range: 1...32,
                            unit: "个"
                        )
                        .disabled(vm.isProcessing)
                    } else if vm.parallelTuningMode == .automatic {
                        InfoRow("自动均衡", vm.autoParallelPreviewText)
                        Text("自动模式参考性能校准结果，选择稳定但不明显慢的配置；会按设备热状态和内存自动选择安全并行。")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    } else {
                        InfoRow("高性能计划", vm.extremeParallelPreviewText)
                        Text("高性能模式固定并行 20；分段时长和分段数量由系统自动计算，不再手动输入。")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }

                    InfoRow("当前计划", vm.segmentPlanText)
                }
            }
        }
    }

    private var bitrateCard: some View {
        Card("码率", systemImage: "slider.horizontal.3") {
            VStack(alignment: .leading, spacing: 12) {
                Picker("码率", selection: $vm.bitrateMode) {
                    ForEach(BitrateMode.allCases) { mode in
                        Text(mode.title).tag(mode)
                    }
                }
                .pickerStyle(.segmented)
                .disabled(vm.isProcessing)

                if let mbps = vm.recommendedBitrateMbps {
                    InfoRow("推荐", String(format: "%.1f Mbps / %.0f Kbps", mbps, mbps * 1000))
                }

                if vm.bitrateMode == .customMbps {
                    Stepper(value: $vm.customBitrateMbps, in: 1...1000, step: 1) {
                        Text("手动：\(Int(vm.customBitrateMbps)) Mbps")
                    }
                    .disabled(vm.isProcessing)

                    PreciseDoubleInput(
                        title: "精确码率",
                        value: $vm.customBitrateMbps,
                        range: 1...1000,
                        unit: "Mbps",
                        fractionDigits: 3
                    )
                    .disabled(vm.isProcessing)

                    InfoRow("等于", String(format: "%.0f Kbps", vm.customBitrateMbps * 1000))
                }
            }
        }
    }

    private var cacheCard: some View {
        Card("缓存管理", systemImage: "externaldrive.badge.xmark") {
            VStack(alignment: .leading, spacing: 12) {
                InfoRow("当前缓存", vm.cacheFootprintText)
                InfoRow("清理范围", "导入副本 / 输出副本 / 日志 / 临时分段")

                Button {
                    vm.cleanupExportCaches()
                } label: {
                    Label("一键清理全部缓存", systemImage: "trash")
                        .frame(maxWidth: .infinity)
                }
                .liquidGlassButtonStyle(prominent: false)
                .disabled(vm.isProcessing)

                if let cleanupMessage = vm.cacheCleanupMessage {
                    Text(cleanupMessage)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                Text("清理会删除 App 沙盒里的中间文件；已保存到相册/文件 App 的导出文件不会受影响。")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
    }

    private var startCard: some View {
        Card(vm.workflowMode == .slowMotionInterpolation ? "开始慢放补帧" : "开始处理", systemImage: "wand.and.stars") {
            VStack(alignment: .leading, spacing: 14) {
                Button {
                    Task { await vm.start() }
                } label: {
                    Label(vm.isProcessing ? "处理中..." : (vm.workflowMode == .slowMotionInterpolation ? "开始慢放补帧" : "开始补帧"), systemImage: "play.fill")
                        .frame(maxWidth: .infinity)
                }
                .liquidGlassButtonStyle(prominent: true)
                .disabled(vm.inputURL == nil || vm.isProcessing)

                if let error = vm.errorMessage {
                    Text(error)
                        .font(.footnote)
                        .foregroundStyle(.red)
                        .textSelection(.enabled)
                }

                if let notice = vm.stabilityNoticeText {
                    Text(notice)
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                        .textSelection(.enabled)
                }

                if let outputURL = vm.outputURL {
                    Divider()

                    VStack(alignment: .leading, spacing: 8) {
                        Text("输出完成")
                            .font(.headline)

                        Text(outputURL.lastPathComponent)
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                            .lineLimit(2)
                            .textSelection(.enabled)

                        ShareLink(item: outputURL) {
                            Label("分享 / 保存视频", systemImage: "square.and.arrow.up")
                                .frame(maxWidth: .infinity)
                        }
                        .liquidGlassButtonStyle(prominent: true)
                    }
                }

                if vm.inputURL == nil {
                    EmptyState(text: "先从相册或文件导入视频。", systemImage: "arrow.up.doc")
                }
            }
        }
    }
}

@MainActor
final class ProcessorViewModel: ObservableObject {
    private static let minimumCalibrationDurationSeconds: Double = 12.0
    private static let compatibilityCalibrationMaxParallelJobs: Int = 20

    @Published var inputURL: URL?
    @Published var outputURL: URL?
    @Published var videoInfo: VideoInfo?
    @Published var isSavingToPhotos = false
    @Published var previousFailureText: String? = UserDefaults.standard.string(forKey: "buzhen.last.failure.summary")
    @Published var workflowMode: BuzhenWorkflowMode = .videoInterpolation
    @Published var slowMotionFactor: Double = 0.5
    @Published var slowMotionKeepSeconds: Double = 6.0
    @Published var slowMotionOutputStartSeconds: Double = 0.0
    @Published var slowMotionPreviewPlayheadSeconds: Double = 0.0

    @Published var targetFPS: Double = 120
    @Published var quality: OpticalFlowQuality = .extreme
    @Published var processingMode: ProcessingMode = .serialSegmented
    @Published var performanceMode: PerformanceMode = .extreme
    @Published var parallelTuningMode: ParallelTuningMode = .manual
    @Published var segmentSeconds: Double = 3
    @Published var desiredSegmentCount: Int = 4
    @Published var maxParallelJobs: Int = 2
    @Published var autoParallelSummaryText: String = "导入视频或生成样片后自动估算"

    @Published var outputMode: OutputMode = .appleHEVC
    @Published var bitrateMode: BitrateMode = .automatic
    @Published var customBitrateMbps: Double = 80

    @Published var keepAudio = true
    @Published var keepMetadata = true
    @Published var preserveHDRTags = true

    @Published var benchmarkResolution: BenchmarkResolution = .p1080
    @Published var benchmarkSourceFPS: BenchmarkSourceFPS = .fps60
    @Published var benchmarkDurationSeconds: Double = 4.0
    @Published var isBenchmarkMode = false
    @Published var isPreparingBenchmark = false
    @Published var isCalibratingPerformance = false
    @Published var isRunningExtremePerformanceTest = false
    @Published var calibrationStatusText: String = "未开始"
    @Published var calibrationResultText: String = UserDefaults.standard.string(forKey: "buzhen.calibration.summary") ?? "未校准"
    @Published var extremePerformanceStatusText: String = "未开始"
    @Published var extremePerformanceResultsText: String = UserDefaults.standard.string(forKey: "buzhen.extreme.results") ?? "未测试"

    @Published var progress: Double = 0
    @Published var status: String = "等待开始"
    @Published var currentStageText: String?
    @Published var errorMessage: String?
    @Published var isProcessing: Bool = false
    @Published var showProcessingScreen: Bool = false
    @Published var isInitializationGateActive: Bool = false
    @Published var initializationProgress: Double = 0
    @Published var segmentRows: [TaskProgressRow] = []
    @Published var workerCount: Int = 0
    @Published var progressModeText: String = "未开始"

    @Published var cpuUsagePercent: Double = 0
    @Published var cpuTotalThreadPercent: Double = 0
    @Published var cpuPeakThreadPercent: Double = 0
    @Published var cpuThreadCount: Int = 0
    @Published var cpuThreadDetailsText: String = "--"
    @Published var memoryUsageMB: Double = 0
    @Published var gpuEstimatePercent: Double = 0
    @Published var processingFPS: Double = 0
    @Published var elapsedTimeText: String = "00:00"
    @Published var estimatedRemainingText: String = "--"
    @Published var thermalStateText: String = "正常"
    @Published var performanceLogURL: URL?
    @Published var performanceLogSampleCount: Int = 0
    @Published var averageProcessingFPS: Double = 0
    @Published var peakProcessingFPS: Double = 0
    @Published var lowestProcessingFPS: Double = 0
    @Published var cacheCleanupMessage: String?
    @Published var stabilityNoticeText: String?
    @Published var cacheFootprintText: String = "--"
    @Published var copyStatusMessage: String?
    @Published var cpuCoreText: String = ProcessorViewModel.cpuCoreDescription()
    @Published var totalSystemMemoryText: String = ProcessorViewModel.totalSystemMemoryDescription()
    @Published var performanceSourceText: String = ProcessorViewModel.performanceSourceDescription()
    @Published var platformText: String = ProcessorViewModel.platformDescription()
    @Published var deviceIdentifierText: String = ProcessorViewModel.hardwareIdentifier()
    @Published var deviceModelText: String = ProcessorViewModel.deviceModelDescription()
    @Published var chipText: String = ProcessorViewModel.chipDescription()
    @Published var osVersionText: String = ProcessorViewModel.osDescription()
    @Published var maxExtremeWorkerText: String = "32"

    private var performanceTimer: Timer?
    private var processingStartDate: Date?
    private var systemActivityToken: NSObjectProtocol?
    private var fpsStatsSampleCount: Int = 0
    private var lastFPSProgressSample: Double?
    private var lastFPSSampleDate: Date?

    var cpuUsageText: String {
        String(format: "%.0f%%", cpuUsagePercent)
    }

    var cpuTotalThreadText: String {
        String(format: "%.1f%%", cpuTotalThreadPercent)
    }

    var cpuPeakThreadText: String {
        String(format: "%.1f%%", cpuPeakThreadPercent)
    }

    var cpuThreadCountText: String {
        "\(cpuThreadCount)"
    }

    var memoryUsageText: String {
        String(format: "%.0f MB", memoryUsageMB)
    }

    var gpuEstimateText: String {
        String(format: "%.0f%% 估算", gpuEstimatePercent)
    }

    var cpuUsageFraction: Double {
        min(max(cpuUsagePercent / 100.0, 0), 1)
    }

    var gpuEstimateFraction: Double {
        min(max(gpuEstimatePercent / 100.0, 0), 1)
    }

    var memoryUsageFraction: Double {
        let totalMB = Self.totalSystemMemoryGB() * 1024.0
        guard totalMB > 0 else { return 0 }
        return min(max(memoryUsageMB / totalMB, 0), 1)
    }

    var cpuThreadLoadFraction: Double {
        let cores = max(1, ProcessInfo.processInfo.activeProcessorCount)
        let maxThreadLoad = Double(cores) * 100.0
        return min(max(cpuTotalThreadPercent / maxThreadLoad, 0), 1)
    }

    var processingSpeedText: String {
        processingFPS > 0 ? String(format: "%.1f frame/s", processingFPS) : "--"
    }

    var averageSpeedText: String {
        averageProcessingFPS > 0 ? String(format: "%.1f frame/s", averageProcessingFPS) : "--"
    }

    var peakSpeedText: String {
        peakProcessingFPS > 0 ? String(format: "%.1f frame/s", peakProcessingFPS) : "--"
    }

    var lowestSpeedText: String {
        lowestProcessingFPS > 0 ? String(format: "%.1f frame/s", lowestProcessingFPS) : "--"
    }

    var benchmarkSampleSummaryText: String {
        "\(benchmarkResolution.title) · \(benchmarkSourceFPS.title) · 内置 sample"
    }

    var benchmarkDurationText: String {
        String(format: "%.1f 秒", benchmarkDurationSeconds)
    }

    var quickRecommendationText: String {
        var parts: [String] = []
        parts.append(workflowMode.title)
        if workflowMode == .slowMotionInterpolation {
            parts.append(String(format: "慢放 %.3gx", slowMotionFactor))
        }
        parts.append(String(format: "%.0f fps", targetFPS))
        parts.append(quality.title)
        parts.append(outputMode.title)
        if let mbps = recommendedBitrateMbps {
            parts.append(String(format: "%.0f Mbps", mbps))
        } else {
            parts.append(bitrateMode.title)
        }
        return parts.joined(separator: " · ")
    }

    var slowMotionMaxOutputSeconds: Double {
        let duration = max(videoInfo?.duration ?? benchmarkDurationSeconds, 0.1)
        let factor = min(max(slowMotionFactor, 0.01), 1.0)
        return max(0.10, duration / factor)
    }

    var slowMotionOutputEndSeconds: Double {
        min(slowMotionMaxOutputSeconds, slowMotionOutputStartSeconds + slowMotionKeepSeconds)
    }

    var slowMotionPreviewSourceSeconds: Double {
        let factor = min(max(slowMotionFactor, 0.01), 1.0)
        let maxSource = max(videoInfo?.duration ?? benchmarkDurationSeconds, 0.1)
        return min(maxSource, max(0, slowMotionPreviewPlayheadSeconds * factor))
    }

    var slowMotionSourceStartSeconds: Double {
        let factor = min(max(slowMotionFactor, 0.01), 1.0)
        let maxSource = max(videoInfo?.duration ?? benchmarkDurationSeconds, 0.1)
        return min(maxSource, max(0, slowMotionOutputStartSeconds * factor))
    }

    var slowMotionSourceDurationSeconds: Double {
        let factor = min(max(slowMotionFactor, 0.01), 1.0)
        let maxSource = max(videoInfo?.duration ?? benchmarkDurationSeconds, 0.1)
        return min(maxSource - slowMotionSourceStartSeconds, max(0.05, slowMotionKeepSeconds * factor))
    }

    var slowMotionPreviewFrameStepSeconds: Double {
        let sourceFPS = max(videoInfo?.fps ?? benchmarkSourceFPS.doubleValue, 1)
        let factor = min(max(slowMotionFactor, 0.01), 1.0)
        return 1.0 / max(sourceFPS * factor, 1)
    }

    var slowMotionSummaryText: String {
        let sourceFPS = videoInfo?.fps ?? benchmarkSourceFPS.doubleValue
        let factor = min(max(slowMotionFactor, 0.01), 1.0)
        let slowedFPS = sourceFPS * factor
        let outputStart = max(0, slowMotionOutputStartSeconds)
        let outputEnd = slowMotionOutputEndSeconds
        let sourceStart = slowMotionSourceStartSeconds
        let sourceEnd = min(max(videoInfo?.duration ?? benchmarkDurationSeconds, 0.1), sourceStart + slowMotionSourceDurationSeconds)

        return String(
            format: "原始 %.1f fps → 慢放 %.3gx 后等效 %.1f fps / 输出 %.3f–%.3f 秒 / 对应源片段 %.3f–%.3f 秒 → 输出 %.0f fps",
            sourceFPS,
            factor,
            slowedFPS,
            outputStart,
            outputEnd,
            sourceStart,
            sourceEnd,
            targetFPS
        )
    }

    func setSlowMotionPreviewPlayhead(_ seconds: Double) {
        slowMotionPreviewPlayheadSeconds = min(max(seconds, 0), slowMotionMaxOutputSeconds)
    }

    func setSlowMotionStartSeconds(_ seconds: Double) {
        let maxOutput = slowMotionMaxOutputSeconds
        slowMotionOutputStartSeconds = min(max(seconds, 0), max(0, maxOutput - 0.10))
        if slowMotionOutputStartSeconds + slowMotionKeepSeconds > maxOutput {
            slowMotionKeepSeconds = max(0.10, maxOutput - slowMotionOutputStartSeconds)
        }
        normalizeSlowMotionKeepSeconds()
    }

    func setSlowMotionEndSeconds(_ seconds: Double) {
        let maxOutput = slowMotionMaxOutputSeconds
        let end = min(max(seconds, slowMotionOutputStartSeconds + 0.10), maxOutput)
        slowMotionKeepSeconds = max(0.10, end - slowMotionOutputStartSeconds)
        normalizeSlowMotionKeepSeconds()
    }

    func setSlowMotionKeepSeconds(_ seconds: Double) {
        slowMotionKeepSeconds = min(max(seconds, 0.10), slowMotionMaxOutputSeconds)
        normalizeSlowMotionKeepSeconds()
    }

    func normalizeSlowMotionKeepSeconds() {
        let maxOutput = slowMotionMaxOutputSeconds
        if slowMotionOutputStartSeconds < 0 {
            slowMotionOutputStartSeconds = 0
        }
        if slowMotionOutputStartSeconds > max(0, maxOutput - 0.10) {
            slowMotionOutputStartSeconds = max(0, maxOutput - 0.10)
        }
        if slowMotionKeepSeconds < 0.10 {
            slowMotionKeepSeconds = min(maxOutput, 0.10)
        }
        if slowMotionOutputStartSeconds + slowMotionKeepSeconds > maxOutput {
            slowMotionKeepSeconds = max(0.10, maxOutput - slowMotionOutputStartSeconds)
        }
        if slowMotionKeepSeconds > maxOutput {
            slowMotionKeepSeconds = maxOutput
            slowMotionOutputStartSeconds = 0
        }
        slowMotionPreviewPlayheadSeconds = min(max(slowMotionPreviewPlayheadSeconds, 0), maxOutput)
    }

    var extremeCalibrationBriefText: String {
        let text = extremePerformanceResultsText
        if text == "未测试" || text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            return "未测试"
        }

        if let line = text
            .split(separator: "\n")
            .map(String.init)
            .first(where: { $0.contains("全场最快") }) {
            return line
        }

        return calibrationResultText
    }

    var autoParallelPreviewText: String {
        if let videoInfo {
            return Self.automaticParallelPlan(
                width: videoInfo.width,
                height: videoInfo.height,
                duration: videoInfo.duration,
                quality: quality,
                performanceMode: performanceMode,
                outputMode: outputMode
            ).summary
        }

        if isBenchmarkMode || isPreparingBenchmark {
            return benchmarkParallelPreviewText
        }

        return "导入视频后再按真实分辨率、时长、内存和 CPU 核心自动估算"
    }

    var benchmarkParallelPreviewText: String {
        let size = benchmarkResolution.size
        return Self.automaticParallelPlan(
            width: Int(size.width),
            height: Int(size.height),
            duration: benchmarkDurationSeconds,
            quality: quality,
            performanceMode: performanceMode,
            outputMode: outputMode
        ).summary
    }

    var extremeParallelPreviewText: String {
        let size = videoInfo.map { CGSize(width: $0.width, height: $0.height) } ?? benchmarkResolution.size
        let duration = videoInfo?.duration ?? benchmarkDurationSeconds
        return Self.extremeParallelPlan(
            width: Int(size.width),
            height: Int(size.height),
            duration: duration
        ).summary
    }

    var segmentPlanText: String {
        if processingMode == .parallelSegmented {
            if parallelTuningMode == .automatic {
                return autoParallelPreviewText
            }

            if parallelTuningMode == .extreme {
                return extremeParallelPreviewText
            }

            let fallbackDuration = isBenchmarkMode ? benchmarkDurationSeconds : (Double(desiredSegmentCount) * segmentSeconds)
            let duration = max(videoInfo?.duration ?? fallbackDuration, 1)
            let seconds = max(0.25, duration / Double(max(1, desiredSegmentCount)))
            return String(format: "手动：%d 段 / 并行 %d / 每段约 %.2f 秒", desiredSegmentCount, maxParallelJobs, seconds)
        }

        if processingMode == .serialSegmented {
            let duration = max(videoInfo?.duration ?? benchmarkDurationSeconds, 1)
            let seconds = duration / Double(max(1, desiredSegmentCount))
            return String(format: "串行：%d 段 / 每段约 %.2f 秒", desiredSegmentCount, seconds)
        }

        if let count = estimatedSegmentCount {
            return "\(count) 段 / 每段 \(String(format: "%.2f", segmentSeconds)) 秒"
        }

        return "未分段"
    }

    var liveWorkerText: String {
        if processingMode == .parallelSegmented {
            return "活动 \(activeSegmentCount) / 并行 \(maxParallelJobs)"
        }
        return "活动 \(activeSegmentCount) / 任务 \(max(workerCount, 1))"
    }

    var shouldShowProgressPanel: Bool {
        isProcessing || !segmentRows.isEmpty || progress > 0
    }

    var shouldShowInitializationOnlyScreen: Bool {
        showProcessingScreen && isProcessing && isInitializationGateActive && outputURL == nil && errorMessage == nil
    }

    var initializationProgressValue: Double {
        min(max(initializationProgress, 0.02), 0.98)
    }

    var initializationDetailText: String {
        "初始化"
    }

    var completedSegmentCount: Int {
        segmentRows.filter { $0.state == .done }.count
    }

    var activeSegmentCount: Int {
        segmentRows.filter { $0.state == .running }.count
    }

    var segmentSummaryText: String {
        guard !segmentRows.isEmpty else { return "无分段" }
        return "\(completedSegmentCount)/\(segmentRows.count)"
    }

    var workerSummaryText: String {
        if workerCount <= 0 { return "未启动" }
        if processingMode == .parallelSegmented {
            return "并行 \(workerCount)"
        }
        return "任务 \(workerCount)"
    }

    var progressPercentText: String {
        "\(Int((min(max(progress, 0), 1) * 100).rounded()))%"
    }

    var estimatedSegmentCount: Int? {
        guard processingMode != .full else { return nil }

        if processingMode == .parallelSegmented {
            if parallelTuningMode == .automatic {
                if let videoInfo {
                    return Self.automaticParallelPlan(
                        width: videoInfo.width,
                        height: videoInfo.height,
                        duration: videoInfo.duration,
                        quality: quality,
                        performanceMode: performanceMode,
                        outputMode: outputMode
                    ).segmentCount
                }

                if isBenchmarkMode || isPreparingBenchmark {
                    let size = benchmarkResolution.size
                    return Self.automaticParallelPlan(
                        width: Int(size.width),
                        height: Int(size.height),
                        duration: benchmarkDurationSeconds,
                        quality: quality,
                        performanceMode: performanceMode,
                        outputMode: outputMode
                    ).segmentCount
                }

                return nil
            }

            if parallelTuningMode == .extreme {
                let size = videoInfo.map { CGSize(width: $0.width, height: $0.height) } ?? benchmarkResolution.size
                let duration = videoInfo?.duration ?? benchmarkDurationSeconds
                return Self.extremeParallelPlan(
                    width: Int(size.width),
                    height: Int(size.height),
                    duration: duration
                ).segmentCount
            }

            return max(1, desiredSegmentCount)
        }

        if processingMode == .serialSegmented {
            return max(1, desiredSegmentCount)
        }

        guard let duration = videoInfo?.duration else { return nil }
        return max(1, Int(ceil(duration / max(0.25, segmentSeconds))))
    }

    var recommendedBitrateMbps: Double? {
        guard let info = videoInfo else { return nil }

        let pixelsPerSecond = Double(info.width * info.height) * targetFPS
        let baseBppf: Double

        switch outputMode {
        case .h264Compatible:
            baseBppf = 0.13
        case .appleHEVC:
            baseBppf = 0.15
        case .hdrPreserve:
            baseBppf = 0.17
        }

        let raw = pixelsPerSecond * baseBppf * quality.bitrateMultiplier
        let floor: Double = outputMode == .hdrPreserve ? 70_000_000 : 45_000_000
        let cap: Double = outputMode == .hdrPreserve ? 380_000_000 : 300_000_000

        return min(max(raw, floor), cap) / 1_000_000
    }

    func handleDocumentPickerImport(_ urls: [URL]) {
        guard !isProcessing else { return }

        errorMessage = nil
        outputURL = nil
        videoInfo = nil
        cacheCleanupMessage = nil
        copyStatusMessage = nil
        stabilityNoticeText = nil
        resetProgressUI()

        refreshCacheFootprint()

        guard let picked = urls.first else {
            status = "未选择视频"
            return
        }

        status = "正在从文件导入视频..."

        Task {
            do {
                let copied = try await Task.detached(priority: .userInitiated) {
                    try ImportStore.copyIntoAppSandbox(from: picked, preferredExtension: picked.pathExtension)
                }.value

                await loadImportedVideo(copied, sourceName: "文件")
            } catch {
                await MainActor.run {
                    self.errorMessage = "文件导入失败：\(error.localizedDescription)"
                    self.status = "导入失败"
                }
            }
        }
    }

    func handlePhotoLibraryImport(_ item: PhotosPickerItem) async {
        guard !isProcessing else { return }

        errorMessage = nil
        outputURL = nil
        videoInfo = nil
        cacheCleanupMessage = nil
        copyStatusMessage = nil
        stabilityNoticeText = nil
        resetProgressUI()
        status = "正在从相册导入视频..."
        refreshCacheFootprint()

        do {
            if let picked = try await item.loadTransferable(type: PickedVideo.self) {
                await loadImportedVideo(picked.url, sourceName: "相册")
                return
            }

            if let data = try await item.loadTransferable(type: Data.self) {
                status = "正在复制相册视频..."
                let copied = try ImportStore.copyDataIntoAppSandbox(data, preferredExtension: preferredPhotoExtension(from: item))
                await loadImportedVideo(copied, sourceName: "相册")
                return
            }

            throw NSError(domain: "BuzhenLocal", code: 1101, userInfo: [
                NSLocalizedDescriptionKey: "相册没有返回可用的视频文件。"
            ])
        } catch {
            errorMessage = "相册导入失败：\(error.localizedDescription)"
            status = "导入失败"
        }
    }

    private func preferredPhotoExtension(from item: PhotosPickerItem) -> String {
        if item.supportedContentTypes.contains(.quickTimeMovie) {
            return "mov"
        }

        if item.supportedContentTypes.contains(.mpeg4Movie) {
            return "mp4"
        }

        if item.supportedContentTypes.contains(where: { $0.conforms(to: .mpeg4Movie) }) {
            return "mp4"
        }

        if item.supportedContentTypes.contains(where: { $0.conforms(to: .quickTimeMovie) }) {
            return "mov"
        }

        return "mov"
    }

    func clearImportedVideo() {
        inputURL = nil
        outputURL = nil
        videoInfo = nil
        cacheCleanupMessage = nil
        copyStatusMessage = nil
        stabilityNoticeText = nil
        resetProgressUI()
        status = "等待开始"
        errorMessage = nil
        isBenchmarkMode = false
        isPreparingBenchmark = false
        isInitializationGateActive = false
        initializationProgress = 0
        isCalibratingPerformance = false
        isRunningExtremePerformanceTest = false
        refreshCacheFootprint()
    }

    private func loadImportedVideo(_ url: URL, sourceName: String) async {
        inputURL = url
        outputURL = nil
        videoInfo = nil
        resetProgressUI()
        cacheCleanupMessage = nil
        copyStatusMessage = nil
        stabilityNoticeText = nil
        errorMessage = nil
        status = "正在读取视频信息..."

        do {
            let info = try await VideoInspector.inspect(url: url)
            videoInfo = info
            targetFPS = max(60, min(240, ceil(info.fps * 2)))
            slowMotionOutputStartSeconds = 0
            slowMotionPreviewPlayheadSeconds = 0
            slowMotionKeepSeconds = max(0.10, info.duration / min(max(slowMotionFactor, 0.01), 1.0))
            outputMode = info.isHDRLike ? .hdrPreserve : .appleHEVC
            status = "\(sourceName)视频已导入"
            refreshCacheFootprint()
        } catch {
            errorMessage = "读取视频信息失败：\(error.localizedDescription)"
            status = "读取失败"
        }
    }

    func startBenchmark() async {
        guard !isProcessing else { return }

        isPreparingBenchmark = true
        isBenchmarkMode = true
        errorMessage = nil
        outputURL = nil
        videoInfo = nil
        cacheCleanupMessage = nil
        copyStatusMessage = nil
        stabilityNoticeText = nil
        resetProgressUI()
        resetPerformanceUI()
        status = "正在生成性能校准样片..."
        currentStageText = "生成 sample 视频"

        do {
            let resolution = benchmarkResolution
            let fps = benchmarkSourceFPS
            let durationSeconds = max(benchmarkDurationSeconds, Self.minimumCalibrationDurationSeconds)
            calibrationStatusText = String(format: "正在生成校准样片：%.1f 秒", durationSeconds)
            let sampleURL = try await Task.detached(priority: .userInitiated) {
                try BenchmarkSampleVideoGenerator.generate(resolution: resolution, fps: fps, durationSeconds: durationSeconds)
            }.value

            keepAudio = false
            keepMetadata = false
            preserveHDRTags = false
            outputMode = .h264Compatible
            bitrateMode = .automatic

            await loadImportedVideo(sampleURL, sourceName: "性能校准样片")

            guard errorMessage == nil, inputURL != nil, videoInfo != nil else {
                throw NSError(domain: "BuzhenBenchmark", code: 3101, userInfo: [
                    NSLocalizedDescriptionKey: errorMessage ?? "性能校准样片读取失败。"
                ])
            }

            await start()
        } catch {
            errorMessage = "性能校准失败：\(error.localizedDescription)"
            status = "性能校准失败"
            currentStageText = "性能校准失败"
            isPreparingBenchmark = false
            isCalibratingPerformance = false
            isProcessing = false
        }
    }

    func startPerformanceCalibration() async {
        guard !isProcessing, !isCalibratingPerformance else { return }

        isPreparingBenchmark = true
        isCalibratingPerformance = true
        isBenchmarkMode = true
        errorMessage = nil
        outputURL = nil
        videoInfo = nil
        cacheCleanupMessage = nil
        copyStatusMessage = nil
        stabilityNoticeText = nil
        resetProgressUI()
        resetPerformanceUI()
        calibrationStatusText = "正在生成校准样片..."
        status = "正在生成校准样片..."
        currentStageText = "生成校准样片"

        do {
            let resolution = benchmarkResolution
            let fps = benchmarkSourceFPS
            let durationSeconds = benchmarkDurationSeconds
            let sampleURL = try await Task.detached(priority: .userInitiated) {
                try BenchmarkSampleVideoGenerator.generate(resolution: resolution, fps: fps, durationSeconds: durationSeconds)
            }.value

            keepAudio = false
            keepMetadata = false
            preserveHDRTags = false
            outputMode = .h264Compatible
            bitrateMode = .automatic
            processingMode = .parallelSegmented
            parallelTuningMode = .manual
            performanceMode = .extreme

            await loadImportedVideo(sampleURL, sourceName: "性能校准样片")

            guard errorMessage == nil, let videoInfo, inputURL != nil else {
                throw NSError(domain: "BuzhenCalibration", code: 4101, userInfo: [
                    NSLocalizedDescriptionKey: errorMessage ?? "校准样片读取失败。"
                ])
            }

            try await runPerformanceCalibration(sampleURL: sampleURL, videoInfo: videoInfo)
        } catch {
            errorMessage = "性能校准失败：\(error.localizedDescription)"
            status = "性能校准失败"
            currentStageText = "性能校准失败"
            calibrationStatusText = "失败：\(error.localizedDescription)"
            isPreparingBenchmark = false
            isCalibratingPerformance = false
            isProcessing = false
            endSystemProcessingActivity()
        }
    }

    func startExtremePerformanceTest() async {
        guard !isProcessing, !isRunningExtremePerformanceTest else { return }

        isPreparingBenchmark = true
        isRunningExtremePerformanceTest = true
        isCalibratingPerformance = true
        isBenchmarkMode = true
        errorMessage = nil
        outputURL = nil
        videoInfo = nil
        cacheCleanupMessage = nil
        copyStatusMessage = nil
        stabilityNoticeText = nil
        resetProgressUI()
        resetPerformanceUI()

        let selectedResolution = benchmarkResolution
        let fixedDuration = Self.minimumCalibrationDurationSeconds
        let fixedSourceFPS = BenchmarkSourceFPS.fps60
        let fixedTargetFPS = 120.0
        let fixedQuality = OpticalFlowQuality.fast

        benchmarkSourceFPS = fixedSourceFPS
        benchmarkDurationSeconds = fixedDuration
        targetFPS = fixedTargetFPS
        quality = fixedQuality
        processingMode = .parallelSegmented
        parallelTuningMode = .manual
        performanceMode = .extreme
        keepAudio = false
        keepMetadata = false
        preserveHDRTags = false
        outputMode = .h264Compatible
        bitrateMode = .automatic

        beginSystemProcessingActivity()
        startPerformanceMonitoring()

        var resultLines: [String] = []
        resultLines.append("性能校准固定参数")
        resultLines.append("本次清晰度: \(selectedResolution.title)")
        resultLines.append("源帧率: 60 fps")
        resultLines.append("目标帧率: 120 fps")
        resultLines.append("样片时长: 12 秒")
        resultLines.append("光流质量: 1 快速")
        resultLines.append("说明: 只测试当前选择的清晰度；其他清晰度历史数据会保留")
        resultLines.append("")

        do {
            benchmarkResolution = selectedResolution
            extremePerformanceStatusText = "正在生成 \(selectedResolution.title) 样片..."
            calibrationStatusText = extremePerformanceStatusText
            status = extremePerformanceStatusText
            currentStageText = "生成 \(selectedResolution.title) 样片"

            let sampleURL = try await Task.detached(priority: .userInitiated) {
                try BenchmarkSampleVideoGenerator.generate(
                    resolution: selectedResolution,
                    fps: fixedSourceFPS,
                    durationSeconds: fixedDuration
                )
            }.value

            await loadImportedVideo(sampleURL, sourceName: "性能校准 \(selectedResolution.title)")
            targetFPS = fixedTargetFPS
            quality = fixedQuality
            outputMode = .h264Compatible
            bitrateMode = .automatic
            processingMode = .parallelSegmented
            parallelTuningMode = .manual
            performanceMode = .extreme

            guard errorMessage == nil, let info = videoInfo else {
                throw NSError(domain: "BuzhenExtremeTest", code: 5101, userInfo: [
                    NSLocalizedDescriptionKey: "\(selectedResolution.title) 样片读取失败。"
                ])
            }

            let result = try await runCalibrationForCurrentSample(
                sampleURL: sampleURL,
                videoInfo: info,
                resolution: selectedResolution,
                prefix: "性能 \(selectedResolution.title)"
            )

            resultLines.append("====== 本次结果 ======")
            resultLines.append(result.summary)
            resultLines.append("")

            try? FileManager.default.removeItem(at: sampleURL)

            let saved = Self.savedExtremePerformanceSummary()
            resultLines.append("====== 已保存数据 ======")
            resultLines.append(contentsOf: saved.lines)
            resultLines.append("")
            resultLines.append("====== 总结 ======")
            resultLines.append(saved.bestLine)

            let finalText = resultLines.joined(separator: "\n")
            UserDefaults.standard.set(finalText, forKey: "buzhen.extreme.results")
            extremePerformanceResultsText = finalText
            extremePerformanceStatusText = "\(selectedResolution.title) 性能校准完成"
            calibrationResultText = finalText
            status = "性能校准完成"
            currentStageText = "\(selectedResolution.title) 完成"
            progress = 1
            outputURL = nil
        } catch {
            errorMessage = "性能校准失败：\(error.localizedDescription)"
            extremePerformanceStatusText = "失败：\(error.localizedDescription)"
            status = "性能校准失败"
            currentStageText = "性能校准失败"
        }

        refreshPerformanceMetrics(final: true)
        stopPerformanceMonitoring()
        endSystemProcessingActivity()
        isPreparingBenchmark = false
        isRunningExtremePerformanceTest = false
        isCalibratingPerformance = false
        isProcessing = false
        refreshCacheFootprint()
    }

    func start() async {
        guard let inputURL else {
            isPreparingBenchmark = false
            return
        }

        prepareProcessingConfiguration()

        guard applyAppStoreStabilityGuards() else {
            isPreparingBenchmark = false
            return
        }

        isPreparingBenchmark = false
        cacheCleanupMessage = nil
        copyStatusMessage = nil
        stabilityNoticeText = nil
        if !isBenchmarkMode {
            cleanupResidualTemporaryFiles()
        }
        refreshCacheFootprint()
        resetProgressUI()
        resetPerformanceUI()
        errorMessage = nil
        outputURL = nil
        status = "初始化"
        currentStageText = "初始化"
        progress = 0
        initializationProgress = 0.02
        progressModeText = processingMode.title
        isProcessing = true
        isInitializationGateActive = true

        withAnimation(SceneAnimationPreset.sceneSwitch) {
            showProcessingScreen = true
        }

        beginSystemProcessingActivity()
        startPerformanceMonitoring()

        let options = ProcessingOptions(
            targetFPS: targetFPS,
            quality: quality,
            processingMode: processingMode,
            segmentSeconds: segmentSeconds,
            maxParallelJobs: maxParallelJobs,
            performanceMode: performanceMode,
            outputMode: outputMode,
            bitrateMode: bitrateMode,
            customBitrateMbps: customBitrateMbps,
            slowMotionFactor: workflowMode == .slowMotionInterpolation ? min(max(slowMotionFactor, 0.01), 1.0) : 1.0,
            slowMotionOutputSeconds: workflowMode == .slowMotionInterpolation ? min(max(slowMotionKeepSeconds, 0.10), slowMotionMaxOutputSeconds) : 0,
            slowMotionOutputStartSeconds: workflowMode == .slowMotionInterpolation ? max(0, slowMotionOutputStartSeconds) : 0,
            keepAudio: workflowMode == .slowMotionInterpolation ? false : keepAudio,
            keepMetadata: keepMetadata,
            preserveHDRTags: preserveHDRTags && outputMode == .hdrPreserve,
            enableSceneChangeDetection: true,
            enableDuplicateFrameDetection: true,
            enableMotionSafety: true
        )

        do {
            try await runInitializationGate(inputURL: inputURL, options: options)

            withAnimation(SceneAnimationPreset.sceneSwitch) {
                isInitializationGateActive = false
            }

            initializationProgress = 0
            progress = 0
            resetPerformanceStats()
            processingStartDate = Date()
            status = "开始补帧"
            currentStageText = "准备分段"

            // 等待补帧页面完成一次渲染/切换后，再创建处理器并开始真实补帧。
            try await Task.sleep(nanoseconds: 260_000_000)
            await Task.yield()

            let processor = VideoFrameInterpolator()

            let result = try await processor.interpolate(
                inputURL: inputURL,
                options: options
            ) { [weak self] p, s in
                DispatchQueue.main.async {
                    self?.applyProcessorProgress(p, s)
                }
            }

            isInitializationGateActive = false
            initializationProgress = 0
            outputURL = result
            status = "完成"
            currentStageText = "全部完成"
            progress = 1
            markAllSegmentsDone()
        } catch {
            isInitializationGateActive = false
            initializationProgress = 0
            outputURL = nil
            errorMessage = "处理失败：\(error.localizedDescription)"
            status = "失败"
            currentStageText = "处理失败"
            markActiveSegmentsFailed(reason: "失败")
            saveLastFailureSummary(error.localizedDescription)
        }

        refreshPerformanceMetrics(final: true)
        stopPerformanceMonitoring()
        endSystemProcessingActivity()
        isInitializationGateActive = false
        initializationProgress = 0
        isProcessing = false
        refreshCacheFootprint()
    }

    private func runInitializationGate(inputURL: URL, options: ProcessingOptions) async throws {
        status = "初始化"
        currentStageText = "初始化"

        func step(_ value: Double, _ delay: UInt64) async throws {
            try Task.checkCancellation()
            initializationProgress = value
            try await Task.sleep(nanoseconds: delay)
        }

        try await step(0.10, 120_000_000)

        guard FileManager.default.fileExists(atPath: inputURL.path) else {
            throw NSError(domain: "BuzhenLocal", code: 1201, userInfo: [
                NSLocalizedDescriptionKey: "初始化失败：输入视频不存在。"
            ])
        }

        try await step(0.24, 160_000_000)

        // 真实预检查：确保视频文件在进入补帧页前可以被 AVFoundation 打开。
        _ = try await VideoInspector.inspect(url: inputURL)
        try await step(0.42, 180_000_000)

        // 预创建临时目录权限/沙盒写入检查。
        let probeURL = FileManager.default.temporaryDirectory
            .appendingPathComponent("buzhen_init_probe_\(UUID().uuidString)")
            .appendingPathExtension("tmp")
        try Data("ok".utf8).write(to: probeURL)
        try? FileManager.default.removeItem(at: probeURL)
        try await step(0.60, 180_000_000)

        // 按并行数留出初始化缓冲，但不改用户并行设置。
        if options.processingMode == .parallelSegmented {
            let extraDelay = UInt64(max(1, min(options.maxParallelJobs, 32))) * 26_000_000
            try await Task.sleep(nanoseconds: min(extraDelay, 1_050_000_000))
        }

        try await step(0.82, 160_000_000)
        try await step(0.96, 140_000_000)
        initializationProgress = 0.98
    }

    private func runCalibrationForCurrentSample(
        sampleURL: URL,
        videoInfo: VideoInfo,
        resolution: BenchmarkResolution,
        prefix: String
    ) async throws -> CalibrationRunResult {
        _ = Self.automaticParallelPlan(
            width: videoInfo.width,
            height: videoInfo.height,
            duration: videoInfo.duration,
            quality: quality,
            performanceMode: .extreme,
            outputMode: outputMode
        )

        let memoryLimitGB = Self.totalSystemMemoryGB() * PerformanceMode.extreme.memoryBudgetFraction
        let perWorkerGB = Self.estimatedMemoryGBPerWorker(width: videoInfo.width, height: videoInfo.height, quality: quality)
        let candidates = Self.calibrationWorkerCandidates(maxWorker: Self.compatibilityCalibrationMaxParallelJobs)

        var bestWorker = 0
        var bestFPS = 0.0
        var bestRawFPS = 0.0
        var bestMemoryMB = 0.0
        var bestSegmentCount = 0
        var triedCount = 0
        var skippedCount = 0

        for (position, worker) in candidates.enumerated() {
            let estimatedGB = perWorkerGB * Double(worker)
            if estimatedGB > memoryLimitGB {
                skippedCount += 1
                continue
            }

            triedCount += 1
            let segmentCount = max(worker * 3, Int(ceil(max(videoInfo.duration, 1) / 1.0)))
            let seconds = max(0.25, videoInfo.duration / Double(max(1, segmentCount)))
            desiredSegmentCount = segmentCount
            maxParallelJobs = worker
            segmentSeconds = seconds
            workerCount = worker

            calibrationStatusText = String(
                format: "%@：测试并行 %d / 预计 %.2fGB / 上限 %.2fGB",
                prefix,
                worker,
                estimatedGB,
                memoryLimitGB
            )
            extremePerformanceStatusText = calibrationStatusText
            status = calibrationStatusText
            currentStageText = "\(prefix) 并行 \(worker)"
            resetProgressUI()

            let options = ProcessingOptions(
                targetFPS: targetFPS,
                quality: quality,
                processingMode: .parallelSegmented,
                segmentSeconds: seconds,
                maxParallelJobs: worker,
                performanceMode: .extreme,
                outputMode: .h264Compatible,
                bitrateMode: .automatic,
                customBitrateMbps: customBitrateMbps,
                slowMotionFactor: 1.0,
                slowMotionOutputSeconds: 0,
                slowMotionOutputStartSeconds: 0,
                keepAudio: false,
                keepMetadata: false,
                preserveHDRTags: false,
                enableSceneChangeDetection: true,
                enableDuplicateFrameDetection: true,
                enableMotionSafety: true
            )

            let begin = Date()
            let candidateBase = Double(position) / Double(max(1, candidates.count))
            let candidateSpan = 1.0 / Double(max(1, candidates.count))

            do {
                let processor = VideoFrameInterpolator()
                let result = try await processor.interpolate(inputURL: sampleURL, options: options) { [weak self] localProgress, message in
                    DispatchQueue.main.async {
                        self?.applyProcessorProgress(candidateBase + min(max(localProgress, 0), 1) * candidateSpan, message)
                    }
                }

                let elapsed = max(0.001, Date().timeIntervalSince(begin))
                let totalFrames = max(videoInfo.duration, 1) * targetFPS
                let rawTotalFPS = totalFrames / elapsed
                let warmupSeconds = Self.calibrationWarmupSeconds(for: videoInfo.duration)
                let scoredDuration = max(videoInfo.duration - warmupSeconds, videoInfo.duration * 0.5)
                let scoredElapsed = max(elapsed - warmupSeconds, elapsed * 0.5, 0.001)
                let stableTotalFPS = max(scoredDuration, 0.5) * targetFPS / scoredElapsed
                let memory = memoryUsageMB

                try? FileManager.default.removeItem(at: result)

                if stableTotalFPS > bestFPS {
                    bestFPS = stableTotalFPS
                    bestRawFPS = rawTotalFPS
                    bestWorker = worker
                    bestMemoryMB = memory
                    bestSegmentCount = segmentCount
                }

                calibrationStatusText = String(
                    format: "%@：并行 %d 完成，稳定 %.1f / 全程 %.1f，当前最快 %.1f",
                    prefix,
                    worker,
                    stableTotalFPS,
                    rawTotalFPS,
                    bestFPS
                )
                extremePerformanceStatusText = calibrationStatusText
            } catch {
                calibrationStatusText = "\(prefix)：并行 \(worker) 失败，已跳过；性能校准会继续找 20 以内的稳定值"
                extremePerformanceStatusText = calibrationStatusText
                continue
            }
        }

        guard bestWorker > 0 else {
            throw NSError(domain: "BuzhenCalibration", code: 4102, userInfo: [
                NSLocalizedDescriptionKey: "\(prefix) 没有找到可用配置。已跳过 \(skippedCount) 个超过内存预算的配置。"
            ])
        }

        let keyBase = "buzhen.calibration.\(resolution.rawValue)"

        let summary = String(
            format: "%@：并行 %d / %d 段 / 稳定 %.1f total frame/s / 全程 %.1f / 内存 %.0fMB / 测试 %d 跳过 %d",
            prefix,
            bestWorker,
            bestSegmentCount,
            bestFPS,
            bestRawFPS,
            bestMemoryMB,
            triedCount,
            skippedCount
        )

        UserDefaults.standard.set(59, forKey: keyBase + ".version")
        UserDefaults.standard.set(summary, forKey: keyBase + ".summary")
        UserDefaults.standard.set(bestWorker, forKey: keyBase + ".worker")
        UserDefaults.standard.set(bestSegmentCount, forKey: keyBase + ".segment_count")
        UserDefaults.standard.set(bestFPS, forKey: keyBase + ".fps")
        UserDefaults.standard.set(bestRawFPS, forKey: keyBase + ".raw_fps")
        UserDefaults.standard.set(Double(videoInfo.width * videoInfo.height), forKey: keyBase + ".pixels")

        UserDefaults.standard.set(59, forKey: "buzhen.calibration.version")
        UserDefaults.standard.set(summary, forKey: "buzhen.calibration.summary")
        UserDefaults.standard.set(bestWorker, forKey: "buzhen.calibration.worker")
        UserDefaults.standard.set(bestFPS, forKey: "buzhen.calibration.fps")
        UserDefaults.standard.set(bestRawFPS, forKey: "buzhen.calibration.raw_fps")
        UserDefaults.standard.set(Double(videoInfo.width * videoInfo.height), forKey: "buzhen.calibration.pixels")

        calibrationResultText = summary
        autoParallelSummaryText = summary
        maxParallelJobs = bestWorker
        desiredSegmentCount = bestSegmentCount
        segmentSeconds = max(0.25, videoInfo.duration / Double(max(1, bestSegmentCount)))
        return CalibrationRunResult(
            resolutionTitle: resolution.title,
            summary: summary,
            stableFPS: bestFPS,
            rawFPS: bestRawFPS,
            worker: bestWorker,
            segmentCount: bestSegmentCount
        )
    }

    private func runPerformanceCalibration(sampleURL: URL, videoInfo: VideoInfo) async throws {
        showProcessingScreen = true
        isPreparingBenchmark = false
        isProcessing = true
        beginSystemProcessingActivity()
        resetProgressUI()
        resetPerformanceUI()
        status = "性能校准中..."
        currentStageText = "准备校准"
        progressModeText = "calibration"
        startPerformanceMonitoring()

        defer {
            refreshPerformanceMetrics(final: true)
            stopPerformanceMonitoring()
            endSystemProcessingActivity()
            isProcessing = false
            isCalibratingPerformance = false
            refreshCacheFootprint()
        }

        _ = Self.automaticParallelPlan(
            width: videoInfo.width,
            height: videoInfo.height,
            duration: videoInfo.duration,
            quality: quality,
            performanceMode: .extreme,
            outputMode: outputMode
        )

        let memoryLimitGB = Self.totalSystemMemoryGB() * PerformanceMode.extreme.memoryBudgetFraction
        let perWorkerGB = Self.estimatedMemoryGBPerWorker(width: videoInfo.width, height: videoInfo.height, quality: quality)
        let candidates = Self.calibrationWorkerCandidates(maxWorker: Self.compatibilityCalibrationMaxParallelJobs)

        var bestWorker = 0
        var bestFPS = 0.0
        var bestRawFPS = 0.0
        var bestMemoryMB = 0.0
        var bestSegmentCount = 0
        var triedCount = 0
        var skippedCount = 0

        for (position, worker) in candidates.enumerated() {
            let estimatedGB = perWorkerGB * Double(worker)
            if estimatedGB > memoryLimitGB {
                skippedCount += 1
                continue
            }

            triedCount += 1
            let segmentCount = max(worker * 3, Int(ceil(max(videoInfo.duration, 1) / 1.0)))
            let seconds = max(0.25, videoInfo.duration / Double(max(1, segmentCount)))
            desiredSegmentCount = segmentCount
            maxParallelJobs = worker
            segmentSeconds = seconds
            workerCount = worker

            calibrationStatusText = String(
                format: "测试并行 %d / 预计 %.2fGB / 上限 %.2fGB",
                worker,
                estimatedGB,
                memoryLimitGB
            )
            status = calibrationStatusText
            currentStageText = "性能校准并行 \(worker)"
            resetProgressUI()

            let options = ProcessingOptions(
                targetFPS: targetFPS,
                quality: quality,
                processingMode: .parallelSegmented,
                segmentSeconds: seconds,
                maxParallelJobs: worker,
                performanceMode: .extreme,
                outputMode: .h264Compatible,
                bitrateMode: .automatic,
                customBitrateMbps: customBitrateMbps,
                slowMotionFactor: 1.0,
                slowMotionOutputSeconds: 0,
                slowMotionOutputStartSeconds: 0,
                keepAudio: false,
                keepMetadata: false,
                preserveHDRTags: false,
                enableSceneChangeDetection: true,
                enableDuplicateFrameDetection: true,
                enableMotionSafety: true
            )

            let begin = Date()
            let candidateBase = Double(position) / Double(max(1, candidates.count))
            let candidateSpan = 1.0 / Double(max(1, candidates.count))

            do {
                let processor = VideoFrameInterpolator()
                let result = try await processor.interpolate(inputURL: sampleURL, options: options) { [weak self] localProgress, message in
                    DispatchQueue.main.async {
                        self?.applyProcessorProgress(candidateBase + min(max(localProgress, 0), 1) * candidateSpan, message)
                    }
                }

                let elapsed = max(0.001, Date().timeIntervalSince(begin))
                let totalFrames = max(videoInfo.duration, 1) * targetFPS
                let rawTotalFPS = totalFrames / elapsed
                let warmupSeconds = Self.calibrationWarmupSeconds(for: videoInfo.duration)
                let scoredDuration = max(videoInfo.duration - warmupSeconds, videoInfo.duration * 0.5)
                let scoredElapsed = max(elapsed - warmupSeconds, elapsed * 0.5, 0.001)
                let stableTotalFPS = max(scoredDuration, 0.5) * targetFPS / scoredElapsed
                let memory = memoryUsageMB

                try? FileManager.default.removeItem(at: result)

                if stableTotalFPS > bestFPS {
                    bestFPS = stableTotalFPS
                    bestRawFPS = rawTotalFPS
                    bestWorker = worker
                    bestMemoryMB = memory
                    bestSegmentCount = segmentCount
                }

                calibrationStatusText = String(
                    format: "并行 %d 完成：稳定 %.1f / 全程 %.1f total frame/s，当前最快稳定 %.1f",
                    worker,
                    stableTotalFPS,
                    rawTotalFPS,
                    bestFPS
                )
            } catch {
                calibrationStatusText = "并行 \(worker) 失败，已跳过；继续找 20 以内的稳定值"
                continue
            }
        }

        guard bestWorker > 0 else {
            throw NSError(domain: "BuzhenCalibration", code: 4102, userInfo: [
                NSLocalizedDescriptionKey: "没有找到可用的校准配置。已跳过 \(skippedCount) 个超过内存预算的配置。"
            ])
        }

        let summary = String(
            format: "最快稳定：%@ %@ %@ / 并行 %d / %d 段 / 稳定 %.1f total frame/s / 全程 %.1f / 内存 %.0fMB / 测试 %d 跳过 %d",
            benchmarkResolution.title,
            benchmarkSourceFPS.title,
            quality.title,
            bestWorker,
            bestSegmentCount,
            bestFPS,
            bestRawFPS,
            bestMemoryMB,
            triedCount,
            skippedCount
        )

        UserDefaults.standard.set(summary, forKey: "buzhen.calibration.summary")
        UserDefaults.standard.set(bestWorker, forKey: "buzhen.calibration.worker")
        UserDefaults.standard.set(bestFPS, forKey: "buzhen.calibration.fps")
        UserDefaults.standard.set(bestRawFPS, forKey: "buzhen.calibration.raw_fps")
        UserDefaults.standard.set(Double(videoInfo.width * videoInfo.height), forKey: "buzhen.calibration.pixels")

        calibrationResultText = summary
        calibrationStatusText = "校准完成"
        autoParallelSummaryText = summary
        maxParallelJobs = bestWorker
        desiredSegmentCount = bestSegmentCount
        segmentSeconds = max(0.25, videoInfo.duration / Double(max(1, bestSegmentCount)))

        status = "性能校准完成"
        currentStageText = "最快配置：并行 \(bestWorker)"
        progress = 1
        outputURL = nil
        markAllSegmentsDone()
    }

    private func applyAppStoreStabilityGuards() -> Bool {
        let thermal = ProcessInfo.processInfo.thermalState
        stabilityNoticeText = nil

        if thermal == .serious || thermal == .critical {
            stabilityNoticeText = "热警告：设备温度较高，仍保持高性能并行 20；初始化会更保守。"
            autoParallelSummaryText += " / 热警告：保持并行 20"
        }

        if processingMode == .parallelSegmented, let info = videoInfo {
            let requestedParallel = min(max(maxParallelJobs, 1), 32)

            if parallelTuningMode == .manual {
                maxParallelJobs = requestedParallel
                workerCount = requestedParallel

                let message = "手动并行 \(requestedParallel)：保留用户设置，不自动降低并行。"
                stabilityNoticeText = message
                autoParallelSummaryText += " / \(message)"
            } else {
                maxParallelJobs = 20
                workerCount = 20

                let megapixels = Double(max(info.width, 1) * max(info.height, 1)) / 1_000_000.0
                if outputMode == .hdrPreserve || targetFPS >= 120 || quality == .supremeAI || megapixels >= 4.0 {
                    let message = "高性能固定并行 20：不预先降并行、不改分段；仅加长编码器初始化。"
                    stabilityNoticeText = message
                    autoParallelSummaryText += " / \(message)"
                }
            }
        }

        return true
    }

    private static func writerStabilityPlan(
        width: Int,
        height: Int,
        targetFPS: Double,
        quality: OpticalFlowQuality,
        outputMode: OutputMode
    ) -> (minSegmentSeconds: Double, reason: String?) {
        let megapixels = Double(max(width, 1) * max(height, 1)) / 1_000_000.0
        let isHEVCLike = outputMode == .appleHEVC || outputMode == .hdrPreserve

        var minSeconds = 0.35
        var reasons: [String] = []

        if outputMode == .hdrPreserve {
            if megapixels >= 5.0 && targetFPS >= 120 {
                minSeconds = max(minSeconds, 1.25)
                reasons.append("HDR/PQ 高分辨率写入保护")
            } else if megapixels >= 3.5 || targetFPS >= 120 {
                minSeconds = max(minSeconds, 1.00)
                reasons.append("HDR 写入保护")
            } else {
                minSeconds = max(minSeconds, 0.75)
                reasons.append("HDR 写入保护")
            }
        }

        if isHEVCLike && targetFPS >= 120 {
            minSeconds = max(minSeconds, 0.85)
            reasons.append("HEVC 高帧率编码保护")
        }

        if quality == .supremeAI && megapixels >= 4.0 {
            minSeconds = max(minSeconds, 1.10)
            reasons.append("终极 AI 高分辨率保护")
        }

        if isHEVCLike && megapixels >= 5.0 {
            minSeconds = max(minSeconds, 1.25)
            reasons.append("高像素 HEVC 写入保护")
        }

        return (minSeconds, reasons.isEmpty ? nil : reasons.joined(separator: " + "))
    }

    private func prepareProcessingConfiguration() {
        performanceMode = .high

        let fallbackSize = benchmarkResolution.size
        let planWidth = videoInfo?.width ?? Int(fallbackSize.width)
        let planHeight = videoInfo?.height ?? Int(fallbackSize.height)
        let duration = max(videoInfo?.duration ?? benchmarkDurationSeconds, 1)

        if processingMode == .serialSegmented {
            let manualCount = min(360, max(1, desiredSegmentCount))
            desiredSegmentCount = manualCount
            workerCount = 1
            segmentSeconds = max(0.25, duration / Double(manualCount))
            autoParallelSummaryText = String(
                format: "串行：%d 段 / 每段约 %.2f 秒",
                desiredSegmentCount,
                segmentSeconds
            )
            return
        }

        guard processingMode == .parallelSegmented else { return }

        if parallelTuningMode == .automatic {
            let plan = Self.automaticParallelPlan(
                width: planWidth,
                height: planHeight,
                duration: duration,
                quality: quality,
                performanceMode: .extreme,
                outputMode: outputMode
            )

            desiredSegmentCount = plan.segmentCount
            maxParallelJobs = plan.workerCount
            workerCount = plan.workerCount
            segmentSeconds = plan.segmentSeconds
            autoParallelSummaryText = plan.summary
            return
        }

        if parallelTuningMode == .manual {
            let manualCount = max(1, desiredSegmentCount)
            let manualParallel = min(max(maxParallelJobs, 1), 32)
            desiredSegmentCount = manualCount
            maxParallelJobs = manualParallel
            workerCount = manualParallel
            segmentSeconds = max(0.25, duration / Double(manualCount))
            autoParallelSummaryText = String(
                format: "手动：%d 段 / 并行 %d / 每段 %.2f 秒",
                desiredSegmentCount,
                maxParallelJobs,
                segmentSeconds
            )
        } else {
            // 高性能 / 极限：固定并行 20，自动分段。
            let plan = Self.extremeParallelPlan(
                width: planWidth,
                height: planHeight,
                duration: duration
            )

            desiredSegmentCount = plan.segmentCount
            maxParallelJobs = plan.workerCount
            workerCount = plan.workerCount
            segmentSeconds = plan.segmentSeconds
            autoParallelSummaryText = plan.summary
        }
    }

    private static func extremeParallelPlan(
        width: Int,
        height: Int,
        duration: Double
    ) -> ParallelAutoPlan {
        let workers = 20
        let safeDuration = max(duration, 1.0)
        let segmentCount = min(360, max(workers, Int(ceil(safeDuration / 0.55))))
        let segmentSeconds = max(0.25, safeDuration / Double(max(1, segmentCount)))
        let summary = String(
            format: "高性能固定：并行 20 / %d 段 / 每段 %.2f 秒",
            segmentCount,
            segmentSeconds
        )

        return ParallelAutoPlan(
            segmentCount: segmentCount,
            workerCount: workers,
            segmentSeconds: segmentSeconds,
            summary: summary
        )
    }

    private static func automaticParallelPlan(
        width: Int,
        height: Int,
        duration: Double,
        quality: OpticalFlowQuality,
        performanceMode: PerformanceMode,
        outputMode: OutputMode
    ) -> ParallelAutoPlan {
        let process = ProcessInfo.processInfo
        let memoryGB = totalSystemMemoryGB()
        let cores = max(1, process.activeProcessorCount)
        let safeWidth = max(width, 640)
        let safeHeight = max(height, 360)
        let pixels = Double(safeWidth * safeHeight)

        let gbPerWorker = estimatedMemoryGBPerWorker(width: safeWidth, height: safeHeight, quality: quality)
        let budgetGB = max(0.8, memoryGB * 0.90)
        let memoryLimitedWorkers = max(1, Int(floor(budgetGB / max(gbPerWorker, 0.10))))

        // 自动模式：参考设备核心、内存和性能测试数据；不写死 20。
        let coreTarget = max(1, min(32, Int(ceil(Double(cores) * 2.0))))
        var workers = min(memoryLimitedWorkers, coreTarget, 32)
        var notes: [String] = []

        if let saved = nearestCalibrationWorker(for: pixels) {
            let scale = sqrt(saved.pixels / max(pixels, 1))
            let scaledWorker = max(1, Int((Double(saved.worker) * scale).rounded(.toNearestOrAwayFromZero)))
            let stableWorker = max(1, Int(ceil(Double(scaledWorker) * 0.90)))
            workers = min(max(1, stableWorker), memoryLimitedWorkers, 32)
            notes.append("参考性能数据")
        } else {
            notes.append("参考设备核心/内存")
        }

        if outputMode == .hdrPreserve {
            workers = min(workers, max(8, coreTarget))
            notes.append("HDR 自动稳态")
        }

        if quality == .supremeAI {
            workers = min(workers, max(8, Int(ceil(Double(coreTarget) * 0.85))))
            notes.append("终极 AI 自动稳态")
        }

        workers = max(1, workers)

        let safeDuration = max(duration, 1.0)
        let targetSeconds: Double
        if outputMode == .hdrPreserve || quality == .supremeAI {
            targetSeconds = 0.75
        } else {
            targetSeconds = 0.55
        }

        let targetSegmentCount = max(workers * 3, Int(ceil(safeDuration / targetSeconds)))
        let segmentCount = min(360, max(workers, targetSegmentCount))
        let segmentSeconds = max(0.25, safeDuration / Double(max(1, segmentCount)))

        let noteText = notes.isEmpty ? "" : " / " + notes.joined(separator: " + ")
        let summary = String(
            format: "自动调整%@：%.1fGB 内存 / 90%%预算 %.1fGB / 每任务约 %.2fGB → %d 段 / 并行 %d / 每段 %.2f 秒",
            noteText,
            memoryGB,
            budgetGB,
            gbPerWorker,
            segmentCount,
            workers,
            segmentSeconds
        )

        return ParallelAutoPlan(
            segmentCount: segmentCount,
            workerCount: workers,
            segmentSeconds: segmentSeconds,
            summary: summary
        )
    }

    private static func encoderSafeParallelLimit(
        width: Int,
        height: Int,
        outputMode: OutputMode,
        targetFPS: Double,
        quality: OpticalFlowQuality
    ) -> Int {
        20
    }

    private static func calibrationWarmupSeconds(for duration: Double) -> Double {
        let safeDuration = max(duration, 1.0)
        return min(max(1.0, safeDuration * 0.18), max(1.0, safeDuration * 0.45))
    }

    private static func savedExtremePerformanceSummary() -> (lines: [String], bestLine: String) {
        var lines: [String] = []
        var best: (title: String, worker: Int, segments: Int, stableFPS: Double, rawFPS: Double)?

        for resolution in BenchmarkResolution.allCases {
            let keyBase = "buzhen.calibration.\(resolution.rawValue)"
            let version = UserDefaults.standard.integer(forKey: keyBase + ".version")
            let worker = UserDefaults.standard.integer(forKey: keyBase + ".worker")
            let stableFPS = UserDefaults.standard.double(forKey: keyBase + ".fps")
            let rawFPS = UserDefaults.standard.double(forKey: keyBase + ".raw_fps")
            let segments = UserDefaults.standard.integer(forKey: keyBase + ".segment_count")
            let summary = UserDefaults.standard.string(forKey: keyBase + ".summary")

            guard version >= 59, worker > 0, stableFPS > 0 else {
                lines.append("\(resolution.title)：未测试")
                continue
            }

            if let summary {
                lines.append(summary)
            } else {
                lines.append(String(
                    format: "%@：并行 %d / %d 段 / 稳定 %.1f total frame/s / 全程 %.1f",
                    resolution.title,
                    worker,
                    max(segments, 0),
                    stableFPS,
                    rawFPS
                ))
            }

            if best == nil || stableFPS > best!.stableFPS {
                best = (resolution.title, worker, segments, stableFPS, rawFPS)
            }
        }

        if let best {
            let bestLine = String(
                format: "已保存数据最快：%@ / 并行 %d / %d 段 / 稳定 %.1f total frame/s / 全程 %.1f total frame/s",
                best.title,
                best.worker,
                best.segments,
                best.stableFPS,
                best.rawFPS
            )
            return (lines, bestLine)
        }

        return (lines, "已保存数据最快：暂无可用测试数据")
    }

    private static func nearestCalibrationWorker(for pixels: Double) -> (worker: Int, pixels: Double)? {
        let keys = BenchmarkResolution.allCases.map { "buzhen.calibration.\($0.rawValue)" } + ["buzhen.calibration"]
        var best: (worker: Int, pixels: Double, distance: Double)?

        for key in keys {
            let version = UserDefaults.standard.integer(forKey: key + ".version")
            let worker = UserDefaults.standard.integer(forKey: key + ".worker")
            let savedPixels = UserDefaults.standard.double(forKey: key + ".pixels")
            guard version >= 59, worker > 0, savedPixels > 0 else { continue }

            let distance = abs(log(max(savedPixels, 1) / max(pixels, 1)))
            if best == nil || distance < best!.distance {
                best = (worker, savedPixels, distance)
            }
        }

        if let best {
            return (best.worker, best.pixels)
        }

        return nil
    }

    private static func estimatedMemoryGBPerWorker(width: Int, height: Int, quality: OpticalFlowQuality) -> Double {
        let pixels = Double(max(width, 640) * max(height, 360))

        let qualityMultiplier: Double
        switch quality {
        case .fast:
            qualityMultiplier = 1.00
        case .extreme:
            qualityMultiplier = 1.55
        case .supremeAI:
            qualityMultiplier = 2.05
        }

        let bytesPerWorker = pixels * 4.0 * 18.0 * qualityMultiplier
        return max(0.25, bytesPerWorker / 1_073_741_824.0)
    }

    private static func totalSystemMemoryGB() -> Double {
        Double(ProcessInfo.processInfo.physicalMemory) / 1_073_741_824.0
    }

    private static func calibrationWorkerCandidates(maxWorker: Int) -> [Int] {
        Array(1...max(1, min(32, maxWorker)))
    }

    func dismissPreviousFailure() {
        previousFailureText = nil
        UserDefaults.standard.removeObject(forKey: "buzhen.last.failure.summary")
    }

    func prepareReprocessFromCompletion() {
        guard !isProcessing else { return }
        outputURL = nil
        errorMessage = nil
        copyStatusMessage = "可以重新调整参数后再次开始。"
        withAnimation(SceneAnimationPreset.sceneSwitch) {
            showProcessingScreen = false
        }
    }

    func handleAppWillResignActive() {
        if isProcessing {
            let message = "任务仍在处理中：请尽量保持 App 前台运行，避免系统暂停或降低速度。"
            stabilityNoticeText = message
            UserDefaults.standard.set(message, forKey: "buzhen.last.runtime.warning")
        }
    }

    func handleAppDidBecomeActive() {
        if let warning = UserDefaults.standard.string(forKey: "buzhen.last.runtime.warning"), !isProcessing {
            stabilityNoticeText = warning
            UserDefaults.standard.removeObject(forKey: "buzhen.last.runtime.warning")
        }
    }

    private func saveLastFailureSummary(_ reason: String) {
        let summary = "\(Date().formatted(date: .abbreviated, time: .shortened)) · \(reason)"
        previousFailureText = summary
        UserDefaults.standard.set(summary, forKey: "buzhen.last.failure.summary")
    }

    func saveOutputToPhotos() async {
        guard let outputURL, !isBenchmarkMode else { return }

        isSavingToPhotos = true
        copyStatusMessage = "正在保存到相册..."

        do {
            try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
                PHPhotoLibrary.shared().performChanges({
                    PHAssetChangeRequest.creationRequestForAssetFromVideo(atFileURL: outputURL)
                }) { success, error in
                    if let error {
                        continuation.resume(throwing: error)
                    } else if success {
                        continuation.resume()
                    } else {
                        continuation.resume(throwing: NSError(domain: "BuzhenPhotos", code: 6001, userInfo: [
                            NSLocalizedDescriptionKey: "相册保存失败。"
                        ]))
                    }
                }
            }

            copyStatusMessage = "已保存到相册。"
        } catch {
            copyStatusMessage = "保存到相册失败：\(error.localizedDescription)"
        }

        isSavingToPhotos = false
    }

    private func beginSystemProcessingActivity() {
        #if canImport(UIKit)
        UIApplication.shared.isIdleTimerDisabled = true
        #endif

        #if targetEnvironment(macCatalyst)
        if systemActivityToken == nil {
            systemActivityToken = ProcessInfo.processInfo.beginActivity(
                options: [.userInitiated, .idleSystemSleepDisabled, .suddenTerminationDisabled],
                reason: "Buzhen Local video interpolation"
            )
        }
        #endif
    }

    private func endSystemProcessingActivity() {
        #if canImport(UIKit)
        UIApplication.shared.isIdleTimerDisabled = false
        #endif

        #if targetEnvironment(macCatalyst)
        if let systemActivityToken {
            ProcessInfo.processInfo.endActivity(systemActivityToken)
            self.systemActivityToken = nil
        }
        #endif
    }

    func copyFullErrorLogToClipboard() {
        UIPasteboard.general.string = fullErrorLogText()
        copyStatusMessage = "完整错误日志已复制。"
    }

    private func fullErrorLogText() -> String {
        var lines: [String] = []
        lines.append("Buzhen Local Error Log")
        lines.append("time: \(ISO8601DateFormatter().string(from: Date()))")
        lines.append("status: \(status)")
        lines.append("stage: \(currentStageText ?? "-")")
        lines.append("progress: \(progressPercentText)")
        lines.append("error: \(errorMessage ?? "-")")
        lines.append("input: \(inputURL?.lastPathComponent ?? "-")")
        lines.append("output: \(outputURL?.lastPathComponent ?? "-")")
        lines.append("log: \(performanceLogURL?.lastPathComponent ?? "-")")
        lines.append("target_fps: \(String(format: "%.3f", targetFPS))")
        lines.append("quality: \(quality.title)")
        lines.append("processing_mode: \(processingMode.title)")
        lines.append("performance_mode: 高性能（默认）")
        lines.append("parallel_tuning_mode: \(parallelTuningMode.title)")
        lines.append("segment_seconds: \(String(format: "%.2f", segmentSeconds))")
        lines.append("desired_segment_count: \(desiredSegmentCount)")
        lines.append("parallel_jobs: \(maxParallelJobs)")
        lines.append("auto_parallel_plan: \(autoParallelSummaryText)")
        lines.append("calibration_result: \(calibrationResultText)")
        lines.append("output_mode: \(outputMode.title)")
        lines.append("bitrate_mode: \(bitrateMode.title)")
        lines.append("custom_bitrate_mbps: \(String(format: "%.3f", customBitrateMbps))")
        lines.append("keep_audio: \(keepAudio)")
        lines.append("keep_metadata: \(keepMetadata)")
        lines.append("preserve_hdr_tags: \(preserveHDRTags)")
        lines.append("local_processing: true")
        lines.append("network_required: false")
        lines.append("privacy_manifest: included")
        lines.append("ui_mode: simplified_visual")
        lines.append("device_model: \(deviceModelText)")
        lines.append("chip: \(chipText)")
        lines.append("os_version: \(osVersionText)")
        lines.append("app_store_stability_guard: enabled")
        lines.append("writer_stability_guard: no_stagger_ordered_progress_fps_fixed")
        lines.append("cpu_percent: \(String(format: "%.2f", cpuUsagePercent))")
        lines.append("cpu_thread_total_percent: \(String(format: "%.2f", cpuTotalThreadPercent))")
        lines.append("cpu_peak_thread_percent: \(String(format: "%.2f", cpuPeakThreadPercent))")
        lines.append("cpu_thread_count: \(cpuThreadCount)")
        lines.append("cpu_thread_details: \(cpuThreadDetailsText)")
        lines.append("gpu_estimate_percent: \(String(format: "%.2f", gpuEstimatePercent))")
        lines.append("memory_mb: \(String(format: "%.2f", memoryUsageMB))")
        lines.append("current_frame_second: \(String(format: "%.3f", processingFPS))")
        lines.append("average_frame_second: \(String(format: "%.3f", averageProcessingFPS))")
        lines.append("peak_frame_second: \(String(format: "%.3f", peakProcessingFPS))")
        lines.append("lowest_frame_second: \(String(format: "%.3f", lowestProcessingFPS))")
        lines.append("thermal_state: \(thermalStateText)")
        lines.append("cache: \(cacheFootprintText)")
        lines.append("is_benchmark: \(isBenchmarkMode)")
        lines.append("benchmark_resolution: \(benchmarkResolution.title)")
        lines.append("benchmark_source_fps: \(benchmarkSourceFPS.title)")
        lines.append("benchmark_duration_seconds: \(String(format: "%.1f", benchmarkDurationSeconds))")

        if let info = videoInfo {
            lines.append("video_width: \(info.width)")
            lines.append("video_height: \(info.height)")
            lines.append("video_fps: \(String(format: "%.3f", info.fps))")
            lines.append("video_duration: \(info.durationText)")
            lines.append("video_codec: \(info.codec)")
            lines.append("video_hdr: \(info.hdrName)")
            lines.append("video_audio: \(info.hasAudio)")
            lines.append("video_bitrate: \(info.bitrateText)")
        }

        lines.append("segments_done: \(completedSegmentCount)/\(segmentRows.count)")
        for row in segmentRows {
            let percent = Int((min(max(row.progress, 0), 1) * 100).rounded())
            lines.append("segment_\(row.id + 1): \(row.stateText) \(percent)% \(row.detail)")
        }

        return lines.joined(separator: "\n")
    }

    func handleMemoryWarning() {
        refreshCacheFootprint()

        if isProcessing {
            status = "系统内存警告"
            currentStageText = "系统内存警告"
            autoParallelSummaryText += " / 系统内存警告"
            return
        }

        cleanupExportCaches()
        cacheCleanupMessage = "系统内存警告：已自动清理临时缓存。"
    }

    func leaveProcessingScreen() {
        guard !isProcessing else { return }

        // 导出/处理页点击返回时自动清理 App 沙盒缓存，避免用户忘记清理导致空间占满。
        // 已保存到相册/文件 App 的导出结果不会受影响。
        cleanupExportCaches()
        withAnimation(SceneAnimationPreset.sceneSwitch) {
            showProcessingScreen = false
        }
    }

    func cleanupExportCaches() {
        guard !isProcessing else { return }

        let fileManager = FileManager.default
        var removed = 0
        var failures: [String] = []

        let directURLs = [inputURL, outputURL, performanceLogURL].compactMap { $0 }
        for url in Set(directURLs) {
            do {
                if fileManager.fileExists(atPath: url.path) {
                    try fileManager.removeItem(at: url)
                    removed += 1
                }
            } catch {
                failures.append(url.lastPathComponent)
            }
        }

        removed += removeContentsIfExists(in: documentsDirectory().appendingPathComponent("ImportedVideos", isDirectory: true), using: fileManager, failures: &failures)
        removed += removeContentsIfExists(in: documentsDirectory().appendingPathComponent("BuzhenBenchmarkSamples", isDirectory: true), using: fileManager, failures: &failures)
        removed += removeContentsIfExists(in: documentsDirectory().appendingPathComponent("BuzhenLogs", isDirectory: true), using: fileManager, failures: &failures)
        removed += removeTemporaryArtifacts(using: fileManager, failures: &failures)

        inputURL = nil
        outputURL = nil
        performanceLogURL = nil
        videoInfo = nil
        resetProgressUI()
        resetPerformanceUI()
        status = "缓存已清理"
        currentStageText = "缓存已清理"
        errorMessage = nil

        if failures.isEmpty {
            cacheCleanupMessage = "返回时已自动清理 \(removed) 个缓存/临时文件。"
        } else {
            cacheCleanupMessage = "返回时已自动清理 \(removed) 个项目，以下文件未删掉：\(failures.joined(separator: "、"))"
        }
        refreshCacheFootprint()
    }

    private func cleanupResidualTemporaryFiles() {
        let fileManager = FileManager.default
        var failures: [String] = []
        _ = removeTemporaryArtifacts(using: fileManager, failures: &failures)
    }

    private func documentsDirectory() -> URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
    }

    @discardableResult
    private func removeContentsIfExists(in directory: URL, using fileManager: FileManager, failures: inout [String]) -> Int {
        guard fileManager.fileExists(atPath: directory.path) else { return 0 }
        guard let items = try? fileManager.contentsOfDirectory(at: directory, includingPropertiesForKeys: nil) else {
            failures.append(directory.lastPathComponent)
            return 0
        }

        var removed = 0
        for item in items {
            do {
                try fileManager.removeItem(at: item)
                removed += 1
            } catch {
                failures.append(item.lastPathComponent)
            }
        }
        return removed
    }

    @discardableResult
    private func removeTemporaryArtifacts(using fileManager: FileManager, failures: inout [String]) -> Int {
        let tempRoot = fileManager.temporaryDirectory
        guard let items = try? fileManager.contentsOfDirectory(at: tempRoot, includingPropertiesForKeys: nil) else {
            return 0
        }

        var removed = 0
        let prefixes = ["buzhen_", "buzhensegments_", "buzhen_segments_", "buzhen_benchmark_"]
        for item in items {
            let name = item.lastPathComponent.lowercased()
            guard prefixes.contains(where: { name.hasPrefix($0) }) else { continue }
            do {
                try fileManager.removeItem(at: item)
                removed += 1
            } catch {
                failures.append(item.lastPathComponent)
            }
        }
        return removed
    }

    private func refreshCacheFootprint() {
        cacheFootprintText = Self.byteText(cacheFootprintBytes())
    }

    private func cacheFootprintBytes() -> Int64 {
        let fileManager = FileManager.default
        var total: Int64 = 0
        var seen = Set<URL>()

        func addURL(_ url: URL?) {
            guard let url else { return }
            guard !seen.contains(url) else { return }
            seen.insert(url)
            total += Self.sizeOfItem(at: url, fileManager: fileManager)
        }

        addURL(inputURL)
        addURL(outputURL)
        addURL(performanceLogURL)
        addURL(documentsDirectory().appendingPathComponent("ImportedVideos", isDirectory: true))
        addURL(documentsDirectory().appendingPathComponent("BuzhenBenchmarkSamples", isDirectory: true))
        addURL(documentsDirectory().appendingPathComponent("BuzhenLogs", isDirectory: true))

        if let items = try? fileManager.contentsOfDirectory(at: fileManager.temporaryDirectory, includingPropertiesForKeys: nil) {
            for item in items {
                let name = item.lastPathComponent.lowercased()
                if ["buzhen_", "buzhensegments_", "buzhen_segments_"].contains(where: { name.hasPrefix($0) }) {
                    addURL(item)
                }
            }
        }

        return total
    }

    private static func sizeOfItem(at url: URL, fileManager: FileManager) -> Int64 {
        var isDirectory: ObjCBool = false
        guard fileManager.fileExists(atPath: url.path, isDirectory: &isDirectory) else { return 0 }

        if isDirectory.boolValue {
            guard let enumerator = fileManager.enumerator(at: url, includingPropertiesForKeys: [.fileSizeKey], options: []) else { return 0 }
            var total: Int64 = 0
            for case let fileURL as URL in enumerator {
                if let size = try? fileURL.resourceValues(forKeys: [.fileSizeKey]).fileSize {
                    total += Int64(size)
                }
            }
            return total
        }

        return Int64((try? url.resourceValues(forKeys: [.fileSizeKey]).fileSize) ?? 0)
    }

    private static func byteText(_ bytes: Int64) -> String {
        let value = Double(max(0, bytes))
        if value >= 1_073_741_824 {
            return String(format: "%.2f GB", value / 1_073_741_824)
        }
        if value >= 1_048_576 {
            return String(format: "%.1f MB", value / 1_048_576)
        }
        if value >= 1024 {
            return String(format: "%.1f KB", value / 1024)
        }
        return "\(bytes) B"
    }

    private func resetProgressUI() {
        progress = 0
        currentStageText = nil
        segmentRows = []
        workerCount = 0
        progressModeText = "未开始"
        performanceLogURL = nil
        performanceLogSampleCount = 0
    }

    private func resetPerformanceStats() {
        averageProcessingFPS = 0
        peakProcessingFPS = 0
        lowestProcessingFPS = 0
        processingFPS = 0
        fpsStatsSampleCount = 0
        lastFPSProgressSample = nil
        lastFPSSampleDate = nil
    }

    private func resetPerformanceUI() {
        performanceTimer?.invalidate()
        performanceTimer = nil
        processingStartDate = nil
        endSystemProcessingActivity()
        cpuUsagePercent = 0
        cpuTotalThreadPercent = 0
        cpuPeakThreadPercent = 0
        cpuThreadCount = 0
        cpuThreadDetailsText = "--"
        memoryUsageMB = 0
        gpuEstimatePercent = 0
        processingFPS = 0
        elapsedTimeText = "00:00"
        estimatedRemainingText = "--"
        thermalStateText = Self.thermalText(ProcessInfo.processInfo.thermalState)
        performanceLogSampleCount = 0
        resetPerformanceStats()
    }

    private func startPerformanceMonitoring() {
        processingStartDate = Date()
        preparePerformanceLogFile()
        refreshPerformanceMetrics()
        performanceTimer?.invalidate()
        performanceTimer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { [weak self] _ in
            Task { @MainActor in
                self?.refreshPerformanceMetrics()
            }
        }
    }

    private func stopPerformanceMonitoring() {
        performanceTimer?.invalidate()
        performanceTimer = nil
    }

    private func refreshPerformanceMetrics(final: Bool = false) {
        let cpuSample = PerformanceSampler.appCPUUsageSample()
        cpuUsagePercent = cpuSample.normalizedPercent
        cpuTotalThreadPercent = cpuSample.totalThreadPercent
        cpuPeakThreadPercent = cpuSample.peakThreadPercent
        cpuThreadCount = cpuSample.threadCount
        cpuThreadDetailsText = cpuSample.shortDetails
        memoryUsageMB = PerformanceSampler.memoryFootprintMB()
        thermalStateText = Self.thermalText(ProcessInfo.processInfo.thermalState)

        let now = Date()
        let elapsed = max(0, now.timeIntervalSince(processingStartDate ?? now))
        elapsedTimeText = Self.timeText(elapsed)

        let duration = videoInfo?.duration ?? benchmarkDurationSeconds
        let progressForProcessing = isInitializationGateActive ? 0 : min(max(progress, 0), 1)
        let stageText = currentStageText ?? status
        let isFrameProcessingStage = !final &&
            !isInitializationGateActive &&
            !segmentRows.isEmpty &&
            activeSegmentCount > 0 &&
            progressForProcessing > 0.02 &&
            progressForProcessing < 0.85 &&
            !stageText.contains("合并") &&
            !stageText.contains("完成") &&
            !stageText.contains("等待分段") &&
            !stageText.contains("写入音频")

        if isFrameProcessingStage, duration > 0 {
            if let lastProgress = lastFPSProgressSample,
               let lastDate = lastFPSSampleDate {
                let deltaTime = max(0, now.timeIntervalSince(lastDate))
                let deltaProgress = max(0, progressForProcessing - lastProgress)

                if deltaTime >= 0.20, deltaProgress > 0.00001 {
                    // 分段处理阶段只占总进度约 80%，换算回真实视频帧速度。
                    let frameProgressDelta = deltaProgress / 0.80
                    let rawFPS = frameProgressDelta * duration * targetFPS / deltaTime
                    if rawFPS.isFinite && rawFPS > 0 {
                        if processingFPS > 0 {
                            processingFPS = processingFPS * 0.55 + rawFPS * 0.45
                        } else {
                            processingFPS = rawFPS
                        }
                    }
                } else if deltaTime >= 2.0, deltaProgress <= 0.00001 {
                    processingFPS = max(0, processingFPS * 0.65)
                }
            } else {
                processingFPS = 0
            }

            lastFPSProgressSample = progressForProcessing
            lastFPSSampleDate = now
        } else {
            // 非补帧阶段不要用合并/完成进度计算 frame/s，避免最后 86→100% 瞬间跳成假高速度。
            if !final && progressForProcessing < 0.85 && activeSegmentCount > 0 {
                processingFPS = max(0, processingFPS * 0.85)
            } else if final || progressForProcessing >= 0.85 {
                processingFPS = 0
            }
            lastFPSProgressSample = nil
            lastFPSSampleDate = nil
        }

        updatePerformanceStats()

        if progressForProcessing > 0.005, progressForProcessing < 0.999, elapsed > 1 {
            let remaining = elapsed * (1 - progressForProcessing) / max(progressForProcessing, 0.001)
            estimatedRemainingText = Self.timeText(remaining)
        } else if final || progressForProcessing >= 0.999 {
            estimatedRemainingText = "00:00"
        } else {
            estimatedRemainingText = "--"
        }

        let workerBase = processingMode == .parallelSegmented ? max(1, maxParallelJobs) : max(1, workerCount)
        let activityRatio = Double(max(activeSegmentCount, (!isInitializationGateActive && isProcessing && progressForProcessing < 0.85) ? 1 : 0)) / Double(workerBase)
        let speedRatio = duration > 0 ? min(max(processingFPS / max(targetFPS, 1), 0), 1) : 0
        gpuEstimatePercent = isProcessing ? min(99, max(8, activityRatio * 68 + speedRatio * 28)) : 0

        appendPerformanceLogSample(final: final)
    }

    private func updatePerformanceStats() {
        let stageText = currentStageText ?? status
        guard !isInitializationGateActive,
              !segmentRows.isEmpty,
              activeSegmentCount > 0,
              progress < 0.85,
              !stageText.contains("合并"),
              !stageText.contains("完成"),
              processingFPS > 0.001,
              processingFPS.isFinite else { return }

        fpsStatsSampleCount += 1
        peakProcessingFPS = max(peakProcessingFPS, processingFPS)
        lowestProcessingFPS = lowestProcessingFPS == 0 ? processingFPS : min(lowestProcessingFPS, processingFPS)
        let previousWeight = Double(max(0, fpsStatsSampleCount - 1))
        averageProcessingFPS = ((averageProcessingFPS * previousWeight) + processingFPS) / Double(fpsStatsSampleCount)
    }

    private func preparePerformanceLogFile() {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        let dir = docs.appendingPathComponent("BuzhenLogs", isDirectory: true)

        do {
            if !FileManager.default.fileExists(atPath: dir.path) {
                try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
            }

            let stamp = ISO8601DateFormatter().string(from: Date())
                .replacingOccurrences(of: ":", with: "-")
                .replacingOccurrences(of: ".", with: "-")
            let url = dir.appendingPathComponent("buzhen_performance_\(stamp).csv")
            let header = "time_iso,elapsed_seconds,progress_percent,status,stage,cpu_percent,cpu_thread_total_percent,cpu_peak_thread_percent,cpu_thread_count,cpu_thread_details,gpu_estimate_percent,memory_mb,total_frames_per_second,total_average_frame_second,total_peak_frame_second,total_lowest_frame_second,thermal_state,active_segments,completed_segments,total_segments,worker_count,processing_mode,performance_mode,parallel_tuning_mode,desired_segment_count,auto_parallel_plan,calibration_result,target_fps,quality,bitrate_mbps,platform,cpu_cores,total_system_memory,is_benchmark,benchmark_resolution,benchmark_source_fps,benchmark_duration_seconds,marker" + "\n"
            try header.write(to: url, atomically: true, encoding: .utf8)
            performanceLogURL = url
            performanceLogSampleCount = 0
        } catch {
            performanceLogURL = nil
            performanceLogSampleCount = 0
        }
    }

    private func appendPerformanceLogSample(final: Bool = false) {
        guard let url = performanceLogURL else { return }

        let elapsed = max(0, Date().timeIntervalSince(processingStartDate ?? Date()))
        let timestamp = ISO8601DateFormatter().string(from: Date())
        let bitrateText = bitrateMode == .customMbps
            ? String(format: "%.3f", customBitrateMbps)
            : (recommendedBitrateMbps.map { String(format: "%.3f", $0) } ?? "automatic")

        let progressForLog = isInitializationGateActive ? 0 : min(max(progress, 0), 1)

        let fields: [String] = [
            timestamp,
            String(format: "%.3f", elapsed),
            String(format: "%.2f", progressForLog * 100),
            status,
            currentStageText ?? "",
            String(format: "%.2f", cpuUsagePercent),
            String(format: "%.2f", cpuTotalThreadPercent),
            String(format: "%.2f", cpuPeakThreadPercent),
            "\(cpuThreadCount)",
            cpuThreadDetailsText,
            String(format: "%.2f", gpuEstimatePercent),
            String(format: "%.2f", memoryUsageMB),
            String(format: "%.3f", processingFPS),
            String(format: "%.3f", averageProcessingFPS),
            String(format: "%.3f", peakProcessingFPS),
            String(format: "%.3f", lowestProcessingFPS),
            thermalStateText,
            "\(activeSegmentCount)",
            "\(completedSegmentCount)",
            "\(segmentRows.count)",
            "\(workerCount)",
            processingMode.title,
            "高性能（默认）",
            parallelTuningMode.title,
            "\(desiredSegmentCount)",
            autoParallelSummaryText,
            calibrationResultText,
            String(format: "%.3f", targetFPS),
            quality.title,
            bitrateText,
            platformText,
            cpuCoreText,
            totalSystemMemoryText,
            isBenchmarkMode ? "true" : "false",
            benchmarkResolution.title,
            benchmarkSourceFPS.title,
            String(format: "%.1f", benchmarkDurationSeconds),
            final ? "FINAL" : ""
        ]

        let line = fields.map(Self.csvEscape).joined(separator: ",") + "\n"

        guard let data = line.data(using: .utf8), let handle = try? FileHandle(forWritingTo: url) else { return }
        defer { try? handle.close() }
        handle.seekToEndOfFile()
        handle.write(data)
        performanceLogSampleCount += 1
    }

    private static func csvEscape(_ value: String) -> String {
        if value.contains(",") || value.contains("\n") || value.contains("\"") {
            return "\"" + value.replacingOccurrences(of: "\"", with: "\"\"") + "\""
        }
        return value
    }

    private static func timeText(_ seconds: TimeInterval) -> String {
        let total = max(0, Int(seconds.rounded()))
        let hours = total / 3600
        let minutes = (total % 3600) / 60
        let secs = total % 60
        if hours > 0 {
            return String(format: "%02d:%02d:%02d", hours, minutes, secs)
        }
        return String(format: "%02d:%02d", minutes, secs)
    }

    static func hardwareIdentifier() -> String {
        var systemInfo = utsname()
        uname(&systemInfo)

        let mirror = Mirror(reflecting: systemInfo.machine)
        let identifier = mirror.children.reduce(into: "") { result, element in
            guard let value = element.value as? Int8, value != 0 else { return }
            result.append(String(UnicodeScalar(UInt8(value))))
        }

        if !identifier.isEmpty {
            return identifier
        }

        return sysctlString("hw.model").isEmpty ? "未知" : sysctlString("hw.model")
    }

    static func deviceModelDescription() -> String {
        let identifier = hardwareIdentifier()

        let known: [String: String] = [
            "iPad16,3": "iPad Pro 11-inch (M4)",
            "iPad16,4": "iPad Pro 11-inch (M4)",
            "iPad16,5": "iPad Pro 13-inch (M4)",
            "iPad16,6": "iPad Pro 13-inch (M4)",
            "iPad14,3": "iPad Pro 11-inch (M2)",
            "iPad14,4": "iPad Pro 11-inch (M2)",
            "iPad14,5": "iPad Pro 12.9-inch (M2)",
            "iPad14,6": "iPad Pro 12.9-inch (M2)",
            "iPad13,4": "iPad Pro 11-inch (M1)",
            "iPad13,5": "iPad Pro 11-inch (M1)",
            "iPad13,6": "iPad Pro 11-inch (M1)",
            "iPad13,7": "iPad Pro 11-inch (M1)",
            "iPad13,8": "iPad Pro 12.9-inch (M1)",
            "iPad13,9": "iPad Pro 12.9-inch (M1)",
            "iPad13,10": "iPad Pro 12.9-inch (M1)",
            "iPad13,11": "iPad Pro 12.9-inch (M1)"
        ]

        if let name = known[identifier] {
            return name
        }

        #if targetEnvironment(macCatalyst)
        let model = sysctlString("hw.model")
        return model.isEmpty ? "Mac" : model
        #else
        return UIDevice.current.model
        #endif
    }

    static func chipDescription() -> String {
        let identifier = hardwareIdentifier()

        if ["iPad16,3", "iPad16,4", "iPad16,5", "iPad16,6"].contains(identifier) {
            return "Apple M4"
        }

        if ["iPad14,3", "iPad14,4", "iPad14,5", "iPad14,6"].contains(identifier) {
            return "Apple M2"
        }

        if ["iPad13,4", "iPad13,5", "iPad13,6", "iPad13,7", "iPad13,8", "iPad13,9", "iPad13,10", "iPad13,11"].contains(identifier) {
            return "Apple M1"
        }

        let brand = sysctlString("machdep.cpu.brand_string")
        if !brand.isEmpty {
            return brand
        }

        #if targetEnvironment(macCatalyst)
        return "Mac 芯片：系统未公开具体名称"
        #else
        return "iOS 设备芯片：未识别"
        #endif
    }

    static func osDescription() -> String {
        #if targetEnvironment(macCatalyst)
        let version = ProcessInfo.processInfo.operatingSystemVersion
        return "macOS \(version.majorVersion).\(version.minorVersion).\(version.patchVersion)"
        #else
        return "\(UIDevice.current.systemName) \(UIDevice.current.systemVersion)"
        #endif
    }

    private static func sysctlString(_ name: String) -> String {
        var size = 0
        guard sysctlbyname(name, nil, &size, nil, 0) == 0, size > 0 else {
            return ""
        }

        var buffer = [CChar](repeating: 0, count: size)
        guard sysctlbyname(name, &buffer, &size, nil, 0) == 0 else {
            return ""
        }

        return String(cString: buffer).trimmingCharacters(in: .whitespacesAndNewlines)
    }

    static func cpuCoreDescription() -> String {
        let process = ProcessInfo.processInfo
        return "\(process.activeProcessorCount)/\(process.processorCount) 核"
    }

    static func totalSystemMemoryDescription() -> String {
        let bytes = Int64(ProcessInfo.processInfo.physicalMemory)
        let gb = Double(bytes) / 1_073_741_824.0
        return String(format: "%.1f GB", gb)
    }

    static func performanceSourceDescription() -> String {
        #if targetEnvironment(macCatalyst)
        return "Mach + Metal"
        #else
        return "iOS App 采样"
        #endif
    }

    static func platformDescription() -> String {
        #if targetEnvironment(macCatalyst)
        return "Mac"
        #else
        return "iOS"
        #endif
    }

    private static func thermalText(_ state: ProcessInfo.ThermalState) -> String {
        switch state {
        case .nominal:
            return "正常"
        case .fair:
            return "偏热"
        case .serious:
            return "过热"
        case .critical:
            return "严重过热"
        @unknown default:
            return "未知"
        }
    }

    private func applyProcessorProgress(_ rawProgress: Double, _ message: String) {
        let clamped = min(max(rawProgress, 0), 1)

        if parseSegmentEvent(message) {
            setProgressSmooth(max(progress, clamped))
            return
        }

        if message.hasPrefix("STAGE|") {
            let text = String(message.dropFirst("STAGE|".count))
            if text.contains("等待分段") || text.contains("合并") || text.contains("写入音频") || text.contains("完成") {
                markAllSegmentsDone()
            }
            status = text
            currentStageText = text
            setProgressSmooth(max(progress, clamped))
            return
        }

        status = message
        currentStageText = message
        setProgressSmooth(max(progress, clamped))
    }

    private func setProgressSmooth(_ value: Double) {
        let target = min(max(value, 0), 1)
        guard target >= progress else { return }

        withAnimation(.linear(duration: target >= 0.999 ? 0.20 : 0.38)) {
            progress = target
        }
    }

    private func parseSegmentEvent(_ message: String) -> Bool {
        let parts = message.split(separator: "|", omittingEmptySubsequences: false).map(String.init)
        guard let kind = parts.first else { return false }

        switch kind {
        case "SEGMENT_SETUP":
            let count = Int(parts[safe: 1] ?? "") ?? 0
            let workers = Int(parts[safe: 2] ?? "") ?? 1
            let mode = parts[safe: 3] ?? processingMode.rawValue

            workerCount = max(1, workers)
            progressModeText = mode
            status = mode == "parallel" ? "并行分段准备中：共 \(count) 段" : "分段准备中：共 \(count) 段"
            currentStageText = "准备分段"

            segmentRows = (0..<max(0, count)).map { index in
                TaskProgressRow(
                    id: index,
                    title: "第 \(index + 1) 段",
                    detail: "等待中",
                    progress: 0,
                    state: .waiting
                )
            }
            return true

        case "SEGMENT_START":
            guard let index = Int(parts[safe: 1] ?? "") else { return true }
            updateSegment(index: index, progress: nil, state: .running, detail: "处理中")
            status = "第 \(index + 1) 段开始处理"
            currentStageText = "处理视频帧"
            return true

        case "SEGMENT_PROGRESS":
            guard let index = Int(parts[safe: 1] ?? "") else { return true }
            let local = Double(parts[safe: 2] ?? "") ?? 0
            let percent = Int((min(max(local, 0), 1) * 100).rounded())
            updateSegment(index: index, progress: local, state: .running, detail: "\(percent)%")
            status = "第 \(index + 1) 段：\(percent)%"
            currentStageText = "光流补帧中"
            return true

        case "SEGMENT_DONE":
            guard let index = Int(parts[safe: 1] ?? "") else { return true }
            updateSegment(index: index, progress: 1, state: .done, detail: "完成")
            status = "第 \(index + 1) 段完成"
            currentStageText = "分段处理中"
            return true

        case "SEGMENT_FAILED":
            guard let index = Int(parts[safe: 1] ?? "") else { return true }
            updateSegment(index: index, progress: nil, state: .failed, detail: "写入失败")
            status = "第 \(index + 1) 段写入失败，准备重试"
            currentStageText = "编码器保护"
            return true

        case "ENCODER_RETRY":
            let text = parts.dropFirst().joined(separator: "|")
            status = text.isEmpty ? "编码器稳定计划重试中" : text
            currentStageText = "编码器稳定重试"
            for index in segmentRows.indices where segmentRows[index].state != .done {
                segmentRows[index].state = .waiting
                segmentRows[index].detail = "等待重试"
                segmentRows[index].progress = 0
            }
            return true

        default:
            return false
        }
    }

    private func updateSegment(index: Int, progress localProgress: Double?, state: TaskProgressState, detail: String) {
        guard index >= 0 else { return }

        if let existingIndex = segmentRows.firstIndex(where: { $0.id == index }) {
            if let localProgress {
                let target = max(segmentRows[existingIndex].progress, min(max(localProgress, 0), 1))
                withAnimation(.linear(duration: target >= 0.999 ? 0.20 : 0.32)) {
                    segmentRows[existingIndex].progress = target
                }
            }
            segmentRows[existingIndex].state = state
            segmentRows[existingIndex].detail = detail
        } else {
            segmentRows.append(
                TaskProgressRow(
                    id: index,
                    title: "第 \(index + 1) 段",
                    detail: detail,
                    progress: min(max(localProgress ?? 0, 0), 1),
                    state: state
                )
            )
            segmentRows.sort { $0.id < $1.id }
        }
    }

    private func markAllSegmentsDone() {
        for index in segmentRows.indices {
            segmentRows[index].progress = 1
            segmentRows[index].state = .done
            segmentRows[index].detail = "完成"
        }
    }

    private func markActiveSegmentsFailed(reason: String) {
        for index in segmentRows.indices where segmentRows[index].state != .done {
            segmentRows[index].state = .failed
            segmentRows[index].detail = reason
        }
    }
}

struct CalibrationRunResult {
    let resolutionTitle: String
    let summary: String
    let stableFPS: Double
    let rawFPS: Double
    let worker: Int
    let segmentCount: Int
}

struct ParallelAutoPlan {
    let segmentCount: Int
    let workerCount: Int
    let segmentSeconds: Double
    let summary: String
}

enum BenchmarkResolution: String, CaseIterable, Identifiable, Sendable {
    case p720
    case p1080
    case p2k
    case p4k

    var id: String { rawValue }

    var title: String {
        switch self {
        case .p720: return "720p"
        case .p1080: return "1080p"
        case .p2k: return "2K"
        case .p4k: return "4K"
        }
    }

    var size: CGSize {
        switch self {
        case .p720: return CGSize(width: 1280, height: 720)
        case .p1080: return CGSize(width: 1920, height: 1080)
        case .p2k: return CGSize(width: 2560, height: 1440)
        case .p4k: return CGSize(width: 3840, height: 2160)
        }
    }

    var bitrate: Int {
        switch self {
        case .p720: return 8_000_000
        case .p1080: return 16_000_000
        case .p2k: return 32_000_000
        case .p4k: return 70_000_000
        }
    }
}

enum BenchmarkSourceFPS: Int, CaseIterable, Identifiable, Sendable {
    case fps24 = 24
    case fps30 = 30
    case fps60 = 60

    var id: Int { rawValue }
    var title: String { "\(rawValue) fps" }
    var doubleValue: Double { Double(rawValue) }
}

enum BenchmarkSampleVideoGenerator {
    static func generate(resolution: BenchmarkResolution, fps: BenchmarkSourceFPS, durationSeconds: Double) throws -> URL {
        let durationSeconds = min(max(durationSeconds, 1.0), 30.0)
        let size = resolution.size
        let width = Int(size.width)
        let height = Int(size.height)

        let directory = try benchmarkDirectory()
        let url = directory
            .appendingPathComponent("buzhen_benchmark_\(resolution.rawValue)_\(fps.rawValue)_\(String(format: "%.1f", durationSeconds))s_\(UUID().uuidString)")
            .appendingPathExtension("mp4")

        if FileManager.default.fileExists(atPath: url.path) {
            try FileManager.default.removeItem(at: url)
        }

        let writer = try AVAssetWriter(outputURL: url, fileType: .mp4)
        let settings: [String: Any] = [
            AVVideoCodecKey: AVVideoCodecType.h264,
            AVVideoWidthKey: width,
            AVVideoHeightKey: height,
            AVVideoCompressionPropertiesKey: [
                AVVideoAverageBitRateKey: resolution.bitrate,
                AVVideoExpectedSourceFrameRateKey: fps.rawValue,
                AVVideoMaxKeyFrameIntervalKey: fps.rawValue
            ]
        ]

        let input = AVAssetWriterInput(mediaType: .video, outputSettings: settings)
        input.expectsMediaDataInRealTime = false

        let pixelAttributes: [String: Any] = [
            kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA,
            kCVPixelBufferWidthKey as String: width,
            kCVPixelBufferHeightKey as String: height,
            kCVPixelBufferIOSurfacePropertiesKey as String: [:]
        ]

        let adaptor = AVAssetWriterInputPixelBufferAdaptor(
            assetWriterInput: input,
            sourcePixelBufferAttributes: pixelAttributes
        )

        guard writer.canAdd(input) else {
            throw NSError(domain: "BuzhenBenchmark", code: 3001, userInfo: [
                NSLocalizedDescriptionKey: "无法创建 sample 视频写入器。"
            ])
        }

        writer.add(input)

        guard writer.startWriting() else {
            throw writer.error ?? NSError(domain: "BuzhenBenchmark", code: 3002, userInfo: [
                NSLocalizedDescriptionKey: "无法开始写入 sample 视频。"
            ])
        }

        writer.startSession(atSourceTime: .zero)

        let context = CIContext(options: [.workingColorSpace: NSNull()])
        let frameCount = max(1, Int(durationSeconds * fps.doubleValue))
        let timescale = CMTimeScale(fps.rawValue)

        for frame in 0..<frameCount {
            while !input.isReadyForMoreMediaData {
                Thread.sleep(forTimeInterval: 0.002)
            }

            var pixelBuffer: CVPixelBuffer?
            if let pool = adaptor.pixelBufferPool {
                CVPixelBufferPoolCreatePixelBuffer(nil, pool, &pixelBuffer)
            }

            if pixelBuffer == nil {
                CVPixelBufferCreate(
                    kCFAllocatorDefault,
                    width,
                    height,
                    kCVPixelFormatType_32BGRA,
                    pixelAttributes as CFDictionary,
                    &pixelBuffer
                )
            }

            guard let pixelBuffer else {
                throw NSError(domain: "BuzhenBenchmark", code: 3003, userInfo: [
                    NSLocalizedDescriptionKey: "无法创建 sample 视频帧。"
                ])
            }

            let image = makeFrameImage(frame: frame, width: width, height: height)
            context.render(image, to: pixelBuffer)

            let presentationTime = CMTime(value: CMTimeValue(frame), timescale: timescale)
            if !adaptor.append(pixelBuffer, withPresentationTime: presentationTime) {
                throw writer.error ?? NSError(domain: "BuzhenBenchmark", code: 3004, userInfo: [
                    NSLocalizedDescriptionKey: "sample 视频帧写入失败。"
                ])
            }
        }

        input.markAsFinished()

        let semaphore = DispatchSemaphore(value: 0)
        writer.finishWriting {
            semaphore.signal()
        }
        semaphore.wait()

        guard writer.status == .completed else {
            throw writer.error ?? NSError(domain: "BuzhenBenchmark", code: 3005, userInfo: [
                NSLocalizedDescriptionKey: "sample 视频生成失败。"
            ])
        }

        return url
    }

    private static func benchmarkDirectory() throws -> URL {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        let dir = docs.appendingPathComponent("BuzhenBenchmarkSamples", isDirectory: true)

        if !FileManager.default.fileExists(atPath: dir.path) {
            try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        }

        return dir
    }

    private static func makeFrameImage(frame: Int, width: Int, height: Int) -> CIImage {
        let extent = CGRect(x: 0, y: 0, width: width, height: height)

        let checker = CIFilter(name: "CICheckerboardGenerator")!
        checker.setValue(CIColor(red: 0.05, green: 0.08, blue: 0.14), forKey: "inputColor0")
        checker.setValue(CIColor(red: 0.16, green: 0.24, blue: 0.42), forKey: "inputColor1")
        checker.setValue(CIVector(x: CGFloat((frame * 9) % max(width, 1)), y: CGFloat((frame * 5) % max(height, 1))), forKey: "inputCenter")
        checker.setValue(max(36, width / 28), forKey: "inputWidth")

        let base = (checker.outputImage ?? CIImage(color: .black)).cropped(to: extent)

        let barWidth = max(120, width / 8)
        let x = CGFloat((frame * max(10, width / 90)) % (width + barWidth)) - CGFloat(barWidth)
        let y = CGFloat(height / 4)
        let movingBar = CIImage(color: CIColor(red: 1.0, green: 0.72, blue: 0.20, alpha: 0.86))
            .cropped(to: CGRect(x: x, y: y, width: CGFloat(barWidth), height: CGFloat(height) / 2))

        let smallBoxSize = max(60, min(width, height) / 10)
        let orbitX = CGFloat(width / 2) + cos(CGFloat(frame) * 0.11) * CGFloat(width / 4) - CGFloat(smallBoxSize / 2)
        let orbitY = CGFloat(height / 2) + sin(CGFloat(frame) * 0.09) * CGFloat(height / 4) - CGFloat(smallBoxSize / 2)
        let box = CIImage(color: CIColor(red: 0.18, green: 0.85, blue: 1.0, alpha: 0.82))
            .cropped(to: CGRect(x: orbitX, y: orbitY, width: CGFloat(smallBoxSize), height: CGFloat(smallBoxSize)))

        return box.composited(over: movingBar.composited(over: base)).cropped(to: extent)
    }
}

struct TaskProgressRow: Identifiable, Equatable {
    let id: Int
    var title: String
    var detail: String
    var progress: Double
    var state: TaskProgressState

    var stateText: String {
        switch state {
        case .waiting: return "等待"
        case .running: return "进行中"
        case .done: return "完成"
        case .failed: return "失败"
        }
    }

    var symbolName: String {
        switch state {
        case .waiting: return "clock"
        case .running: return "arrow.triangle.2.circlepath"
        case .done: return "checkmark.circle"
        case .failed: return "xmark.circle"
        }
    }
}

enum TaskProgressState: Equatable {
    case waiting
    case running
    case done
    case failed
}

struct PickedVideo: Transferable {
    let url: URL

    static var transferRepresentation: some TransferRepresentation {
        FileRepresentation(contentType: .video) { video in
            SentTransferredFile(video.url)
        } importing: { received in
            let copied = try ImportStore.copyIntoAppSandbox(from: received.file, preferredExtension: received.file.pathExtension)
            return PickedVideo(url: copied)
        }

        FileRepresentation(contentType: .movie) { video in
            SentTransferredFile(video.url)
        } importing: { received in
            let copied = try ImportStore.copyIntoAppSandbox(from: received.file, preferredExtension: received.file.pathExtension)
            return PickedVideo(url: copied)
        }

        FileRepresentation(contentType: .mpeg4Movie) { video in
            SentTransferredFile(video.url)
        } importing: { received in
            let copied = try ImportStore.copyIntoAppSandbox(from: received.file, preferredExtension: "mp4")
            return PickedVideo(url: copied)
        }

        FileRepresentation(contentType: .quickTimeMovie) { video in
            SentTransferredFile(video.url)
        } importing: { received in
            let copied = try ImportStore.copyIntoAppSandbox(from: received.file, preferredExtension: "mov")
            return PickedVideo(url: copied)
        }
    }
}

enum ImportStore {
    static let supportedVideoTypes: [UTType] = [
        .movie,
        .video,
        .audiovisualContent,
        .mpeg4Movie,
        .quickTimeMovie,
        UTType(filenameExtension: "mov") ?? .quickTimeMovie,
        UTType(filenameExtension: "mp4") ?? .mpeg4Movie,
        UTType(filenameExtension: "m4v") ?? .mpeg4Movie
    ]

    static func copyIntoAppSandbox(from source: URL, preferredExtension: String? = nil) throws -> URL {
        let importDir = try importDirectory()
        let ext = normalizedExtension(source: source, preferred: preferredExtension)
        let filename = "input_\(Int(Date().timeIntervalSince1970))_\(String(UUID().uuidString.prefix(8))).\(ext)"
        let destination = importDir.appendingPathComponent(filename)

        if FileManager.default.fileExists(atPath: destination.path) {
            try FileManager.default.removeItem(at: destination)
        }

        let scoped = source.startAccessingSecurityScopedResource()
        defer {
            if scoped {
                source.stopAccessingSecurityScopedResource()
            }
        }

        var coordinationError: NSError?
        var copyError: Error?

        let coordinator = NSFileCoordinator(filePresenter: nil)
        coordinator.coordinate(readingItemAt: source, options: [], error: &coordinationError) { readableURL in
            do {
                try FileManager.default.copyItem(at: readableURL, to: destination)
            } catch {
                copyError = error
            }
        }

        if let coordinationError {
            throw coordinationError
        }

        if let copyError {
            throw copyError
        }

        guard FileManager.default.fileExists(atPath: destination.path) else {
            throw NSError(domain: "BuzhenLocal", code: 1102, userInfo: [
                NSLocalizedDescriptionKey: "视频没有成功复制到 App 沙盒。"
            ])
        }

        return destination
    }

    static func copyDataIntoAppSandbox(_ data: Data, preferredExtension: String = "mov") throws -> URL {
        let importDir = try importDirectory()
        let ext = preferredExtension.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? "mov" : preferredExtension.lowercased()
        let filename = "input_\(Int(Date().timeIntervalSince1970))_\(String(UUID().uuidString.prefix(8))).\(ext)"
        let destination = importDir.appendingPathComponent(filename)

        if FileManager.default.fileExists(atPath: destination.path) {
            try FileManager.default.removeItem(at: destination)
        }

        try data.write(to: destination, options: [.atomic])

        guard FileManager.default.fileExists(atPath: destination.path) else {
            throw NSError(domain: "BuzhenLocal", code: 1103, userInfo: [
                NSLocalizedDescriptionKey: "相册视频数据没有成功保存到 App 沙盒。"
            ])
        }

        return destination
    }

    private static func importDirectory() throws -> URL {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        let dir = docs.appendingPathComponent("ImportedVideos", isDirectory: true)
        if !FileManager.default.fileExists(atPath: dir.path) {
            try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        }
        return dir
    }

    private static func normalizedExtension(source: URL, preferred: String?) -> String {
        let preferredExt = (preferred ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        let sourceExt = source.pathExtension.trimmingCharacters(in: .whitespacesAndNewlines)
        let ext = preferredExt.isEmpty ? sourceExt : preferredExt

        if ext.isEmpty { return "mov" }
        return ext.lowercased()
    }
}

private struct CPUUsageSample {
    let normalizedPercent: Double
    let totalThreadPercent: Double
    let peakThreadPercent: Double
    let threadCount: Int
    let threadPercents: [Double]

    var shortDetails: String {
        guard !threadPercents.isEmpty else { return "--" }

        let top = threadPercents
            .enumerated()
            .sorted { $0.element > $1.element }
            .prefix(8)
            .map { item in
                "T\(item.offset + 1)=\(String(format: "%.1f", item.element))%"
            }
            .joined(separator: "; ")

        if threadPercents.count > 8 {
            return top + "; ..."
        }
        return top
    }
}

private enum PerformanceSampler {
    static func appCPUUsageSample() -> CPUUsageSample {
        var threadList: thread_act_array_t?
        var threadCount = mach_msg_type_number_t(0)

        let result = task_threads(mach_task_self_, &threadList, &threadCount)
        guard result == KERN_SUCCESS, let threadList else {
            return CPUUsageSample(
                normalizedPercent: 0,
                totalThreadPercent: 0,
                peakThreadPercent: 0,
                threadCount: 0,
                threadPercents: []
            )
        }

        defer {
            let size = vm_size_t(Int(threadCount) * MemoryLayout<thread_t>.stride)
            vm_deallocate(mach_task_self_, vm_address_t(UInt(bitPattern: threadList)), size)
        }

        var threadPercents: [Double] = []

        for index in 0..<Int(threadCount) {
            var info = thread_basic_info()
            var count = mach_msg_type_number_t(THREAD_INFO_MAX)

            let kr = withUnsafeMutablePointer(to: &info) { pointer in
                pointer.withMemoryRebound(to: integer_t.self, capacity: Int(count)) { rebound in
                    thread_info(threadList[index], thread_flavor_t(THREAD_BASIC_INFO), rebound, &count)
                }
            }

            if kr == KERN_SUCCESS, (info.flags & Int32(TH_FLAGS_IDLE)) == 0 {
                let percent = max(0, Double(info.cpu_usage) / Double(TH_USAGE_SCALE) * 100.0)
                threadPercents.append(percent)
            }
        }

        let totalThreadPercent = threadPercents.reduce(0, +)
        let peakThreadPercent = threadPercents.max() ?? 0
        let coreCount = Double(max(1, ProcessInfo.processInfo.activeProcessorCount))
        let normalizedPercent = min(100.0, max(0.0, totalThreadPercent / coreCount))

        return CPUUsageSample(
            normalizedPercent: normalizedPercent,
            totalThreadPercent: totalThreadPercent,
            peakThreadPercent: peakThreadPercent,
            threadCount: threadPercents.count,
            threadPercents: threadPercents
        )
    }

    static func memoryFootprintMB() -> Double {
        var info = task_vm_info_data_t()
        var count = mach_msg_type_number_t(MemoryLayout<task_vm_info_data_t>.size / MemoryLayout<natural_t>.size)

        let result = withUnsafeMutablePointer(to: &info) { pointer in
            pointer.withMemoryRebound(to: integer_t.self, capacity: Int(count)) { rebound in
                task_info(mach_task_self_, task_flavor_t(TASK_VM_INFO), rebound, &count)
            }
        }

        guard result == KERN_SUCCESS else { return 0 }
        return Double(info.phys_footprint) / 1_048_576.0
    }
}

private struct PreciseDoubleInput: View {
    let title: String
    @Binding var value: Double
    let range: ClosedRange<Double>
    let unit: String
    let fractionDigits: Int

    @State private var draftText: String = ""
    @FocusState private var isFocused: Bool

    var body: some View {
        ViewThatFits(in: .horizontal) {
            horizontalLayout
            verticalLayout
        }
        .padding(10)
        .liquidGlassCard(cornerRadius: 14)
        .onAppear {
            draftText = formatted(value)
        }
        .onChange(of: value) { newValue in
            if !isFocused {
                draftText = formatted(newValue)
            }
        }
        .onChange(of: isFocused) { focused in
            if focused {
                draftText = rawEditingText(from: value)
            } else {
                draftText = formatted(value)
            }
        }
    }

    private var horizontalLayout: some View {
        HStack(spacing: 10) {
            titleLabel

            Spacer(minLength: 8)

            valueField
                .frame(minWidth: 104, idealWidth: 140, maxWidth: 190)

            unitLabel
            confirmButton
        }
    }

    private var verticalLayout: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                titleLabel
                Spacer(minLength: 8)
                unitLabel
            }

            HStack(spacing: 8) {
                valueField
                confirmButton
            }
        }
    }

    private var titleLabel: some View {
        Text(title)
            .font(.footnote.weight(.medium))
            .lineLimit(1)
            .minimumScaleFactor(0.82)
    }

    private var unitLabel: some View {
        Text(unit)
            .font(.footnote)
            .foregroundStyle(.secondary)
            .lineLimit(1)
            .minimumScaleFactor(0.82)
            .frame(minWidth: 32, alignment: .leading)
    }

    private var valueField: some View {
        TextField(title, text: $draftText)
            .keyboardType(.decimalPad)
            .textInputAutocapitalization(.never)
            .autocorrectionDisabled(true)
            .focused($isFocused)
            .multilineTextAlignment(.trailing)
            .font(.body.monospacedDigit())
            .submitLabel(.done)
            .liquidGlassTextField(cornerRadius: 12)
            .onSubmit {
                commitDraft()
            }
    }

    private var confirmButton: some View {
        Button {
            commitDraft()
            isFocused = false
        } label: {
            Text("确认")
                .font(.footnote.weight(.semibold))
        }
        .buttonStyle(.bordered)
        .controlSize(.small)
        .disabled(parsedValue == nil)
    }

    private var parsedValue: Double? {
        let normalized = draftText
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .replacingOccurrences(of: ",", with: ".")

        guard !normalized.isEmpty, let parsed = Double(normalized), parsed.isFinite else {
            return nil
        }

        return min(max(parsed, range.lowerBound), range.upperBound)
    }

    private func commitDraft() {
        guard let parsed = parsedValue else {
            draftText = formatted(value)
            return
        }

        value = parsed
        draftText = formatted(parsed)
    }

    private func formatted(_ number: Double) -> String {
        let clamped = min(max(number, range.lowerBound), range.upperBound)
        return String(format: "%.\(fractionDigits)f", clamped)
    }

    private func rawEditingText(from number: Double) -> String {
        let rounded = number.rounded()
        if abs(number - rounded) < 0.000001 {
            return String(Int(rounded))
        }
        return formatted(number)
    }
}

private struct PreciseIntInput: View {
    let title: String
    @Binding var value: Int
    let range: ClosedRange<Int>
    let unit: String

    @State private var draftText: String = ""
    @FocusState private var isFocused: Bool

    var body: some View {
        ViewThatFits(in: .horizontal) {
            horizontalLayout
            verticalLayout
        }
        .padding(10)
        .liquidGlassCard(cornerRadius: 14)
        .onAppear {
            draftText = "\(value)"
        }
        .onChange(of: value) { newValue in
            if !isFocused {
                draftText = "\(newValue)"
            }
        }
        .onChange(of: isFocused) { focused in
            if !focused {
                commitDraft()
            }
        }
    }

    private var horizontalLayout: some View {
        HStack(spacing: 10) {
            titleLabel

            Spacer(minLength: 8)

            valueField
                .frame(minWidth: 96, idealWidth: 128, maxWidth: 175)

            unitLabel
            confirmButton
        }
    }

    private var verticalLayout: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                titleLabel
                Spacer(minLength: 8)
                unitLabel
            }

            HStack(spacing: 8) {
                valueField
                confirmButton
            }
        }
    }

    private var titleLabel: some View {
        Text(title)
            .font(.footnote.weight(.medium))
            .lineLimit(1)
            .minimumScaleFactor(0.82)
    }

    private var unitLabel: some View {
        Text(unit)
            .font(.footnote)
            .foregroundStyle(.secondary)
            .lineLimit(1)
            .minimumScaleFactor(0.82)
            .frame(minWidth: 28, alignment: .leading)
    }

    private var valueField: some View {
        TextField(title, text: $draftText)
            .keyboardType(.numberPad)
            .textInputAutocapitalization(.never)
            .autocorrectionDisabled(true)
            .focused($isFocused)
            .multilineTextAlignment(.trailing)
            .font(.body.monospacedDigit())
            .submitLabel(.done)
            .liquidGlassTextField(cornerRadius: 12)
            .onSubmit {
                commitDraft()
            }
    }

    private var confirmButton: some View {
        Button {
            commitDraft()
            isFocused = false
        } label: {
            Text("确认")
                .font(.footnote.weight(.semibold))
        }
        .buttonStyle(.bordered)
        .controlSize(.small)
        .disabled(parsedValue == nil)
    }

    private var parsedValue: Int? {
        let normalized = draftText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !normalized.isEmpty, let parsed = Int(normalized) else { return nil }
        return min(max(parsed, range.lowerBound), range.upperBound)
    }

    private func commitDraft() {
        guard let parsed = parsedValue else {
            draftText = "\(value)"
            return
        }

        value = parsed
        draftText = "\(parsed)"
    }
}

private struct GlassStepPill: View {
    let index: String
    let title: String
    let detail: String
    let systemImage: String

    var body: some View {
        HStack(alignment: .center, spacing: 10) {
            ZStack {
                Circle()
                    .fill(.ultraThinMaterial)
                    .frame(width: 34, height: 34)
                    .overlay(
                        Circle().strokeBorder(.white.opacity(0.35), lineWidth: 0.7)
                    )

                Text(index)
                    .font(.caption.bold())
                    .monospacedDigit()
            }

            VStack(alignment: .leading, spacing: 2) {
                Label {
                    Text(title)
                        .lineLimit(1)
                        .minimumScaleFactor(0.72)
                } icon: {
                    Image(systemName: systemImage)
                }
                .font(.footnote.weight(.semibold))

                Text(detail)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .lineLimit(2)
                    .minimumScaleFactor(0.70)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
        .padding(10)
        .frame(maxWidth: .infinity, minHeight: 58, alignment: .leading)
        .liquidGlassCard(cornerRadius: 18)
        .modifier(LiquidGlassCardStretchAppearModifier())
    }
}

private struct MetricTile: View {
    let title: String
    let value: String
    let systemImage: String

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Label {
                Text(title)
                    .lineLimit(2)
                    .minimumScaleFactor(0.62)
            } icon: {
                Image(systemName: systemImage)
            }
            .font(.caption.weight(.semibold))
            .foregroundStyle(.secondary)

            Text(value)
                .font(.subheadline.monospacedDigit().weight(.semibold))
                .lineLimit(4)
                .minimumScaleFactor(0.48)
                .multilineTextAlignment(.leading)
                .textSelection(.enabled)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(10)
        .frame(maxWidth: .infinity, minHeight: 76, alignment: .topLeading)
        .contentShape(Rectangle())
        .liquidGlassCard(cornerRadius: 16)
    }
}

private struct Card<Content: View>: View {
    let title: String
    let systemImage: String
    let content: Content

    init(_ title: String, systemImage: String, @ViewBuilder content: () -> Content) {
        self.title = title
        self.systemImage = systemImage
        self.content = content()
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack(spacing: 8) {
                Image(systemName: systemImage)
                    .foregroundStyle(.secondary)
                Text(title)
                    .font(.headline)
                    .lineLimit(nil)
                    .minimumScaleFactor(0.70)
                    .fixedSize(horizontal: false, vertical: true)
            }

            content
                .frame(maxWidth: .infinity, alignment: .leading)
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .topLeading)
        .clipped()
        .liquidGlassCard(cornerRadius: 22)
        .modifier(LiquidGlassCardStretchAppearModifier())
    }
}

private struct InfoRow: View {
    let title: String
    let value: String

    init(_ title: String, _ value: String) {
        self.title = title
        self.value = value
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(title)
                .foregroundStyle(.secondary)
                .lineLimit(nil)
                .minimumScaleFactor(0.72)
                .fixedSize(horizontal: false, vertical: true)

            Text(value)
                .multilineTextAlignment(.leading)
                .textSelection(.enabled)
                .lineLimit(nil)
                .fixedSize(horizontal: false, vertical: true)
        }
        .font(.footnote)
        .padding(.vertical, 2)
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}

private struct EmptyState: View {
    let text: String
    let systemImage: String

    var body: some View {
        HStack(spacing: 8) {
            Image(systemName: systemImage)
            Text(text)
        }
        .font(.footnote)
        .foregroundStyle(.secondary)
        .padding(10)
        .frame(maxWidth: .infinity, alignment: .leading)
        .liquidGlassCard(cornerRadius: 14)
    }
}

private struct StatusBadge: View {
    let text: String
    let systemImage: String

    var body: some View {
        Label {
            Text(text)
                .lineLimit(1)
                .minimumScaleFactor(0.62)
        } icon: {
            Image(systemName: systemImage)
        }
        .font(.caption.weight(.semibold))
        .padding(.horizontal, 10)
        .padding(.vertical, 6)
        .frame(maxWidth: .infinity, alignment: .center)
        .liquidGlassCapsule()
    }
}

private struct QualityLine: View {
    let index: String
    let title: String
    let detail: String

    var body: some View {
        HStack(alignment: .top, spacing: 10) {
            Text(index)
                .font(.caption.bold())
                .frame(width: 22, height: 22)
                .liquidGlassCircle()

            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(.footnote.weight(.medium))
                    .lineLimit(2)
                    .minimumScaleFactor(0.75)

                Text(detail)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .lineLimit(2)
                    .minimumScaleFactor(0.70)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
    }
}

private struct ProcessingProgressRing: View {
    let value: Double
    let percentText: String
    let isComplete: Bool

    @State private var spin = false
    @State private var pulse = false
    @State private var displayedValue: Double = 0

    private var clamped: Double {
        min(max(value, 0), 1)
    }

    private var displayedClamped: Double {
        min(max(displayedValue, 0), 1)
    }

    var body: some View {
        ZStack {
            Circle()
                .stroke(.secondary.opacity(0.16), lineWidth: 14)
                .liquidGlassCircle()

            Circle()
                .trim(from: 0, to: displayedClamped)
                .stroke(
                    .tint.opacity(0.82),
                    style: StrokeStyle(lineWidth: 14, lineCap: .round, lineJoin: .round)
                )
                .rotationEffect(.degrees(-90))

            Circle()
                .trim(from: 0, to: 0.16)
                .stroke(.white.opacity(0.58), style: StrokeStyle(lineWidth: 5, lineCap: .round))
                .rotationEffect(.degrees(spin ? 360 : 0))
                .opacity(isComplete ? 0 : 0.92)
                .animation(isComplete ? .default : .linear(duration: 1.25).repeatForever(autoreverses: false), value: spin)

            VStack(spacing: 4) {
                Image(systemName: isComplete ? "checkmark" : "bolt.horizontal.fill")
                    .font(.title2.weight(.bold))
                    .symbolRenderingMode(.hierarchical)
                    .scaleEffect(isComplete ? (pulse ? 1.12 : 1.0) : 1.0)

                Text(percentText)
                    .font(.title3.monospacedDigit().bold())
                    .contentTransition(.numericText())
                    .animation(.easeOut(duration: 0.28), value: percentText)
            }
        }
        .frame(width: 118, height: 118)
        .scaleEffect(isComplete ? (pulse ? 1.03 : 0.98) : 1.0)
        .onAppear {
            spin = true
            displayedValue = clamped
        }
        .onChange(of: clamped) { newValue in
            withAnimation(.interpolatingSpring(mass: 0.80, stiffness: 92, damping: 21, initialVelocity: 0.10)) {
                displayedValue = newValue
            }
        }
        .onChange(of: isComplete) { done in
            if done {
                withAnimation(.spring(response: 0.45, dampingFraction: 0.48)) {
                    pulse = true
                    displayedValue = 1
                }
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) {
                    withAnimation(.spring(response: 0.52, dampingFraction: 0.72)) {
                        pulse = false
                    }
                }
            }
        }
    }
}

private struct SuccessPulseView: View {
    @State private var show = false
    @State private var ripple = false

    var body: some View {
        VStack(spacing: 10) {
            ZStack {
                Circle()
                    .stroke(.tint.opacity(ripple ? 0 : 0.32), lineWidth: 7)
                    .scaleEffect(ripple ? 1.55 : 0.72)
                    .opacity(ripple ? 0 : 1)

                Circle()
                    .fill(.tint.opacity(0.16))
                    .liquidGlassCircle()
                    .frame(width: 70, height: 70)

                Image(systemName: "checkmark.circle.fill")
                    .font(.system(size: 50, weight: .semibold))
                    .symbolRenderingMode(.hierarchical)
                    .scaleEffect(show ? 1 : 0.55)
                    .opacity(show ? 1 : 0)
            }
            .frame(width: 104, height: 104)

            Text("处理完成")
                .font(.headline)

            Text("可以导出视频或下载性能日志。")
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .padding(.vertical, 8)
        .onAppear {
            withAnimation(.spring(response: 0.50, dampingFraction: 0.52)) {
                show = true
            }
            withAnimation(.easeOut(duration: 0.95).repeatCount(2, autoreverses: false)) {
                ripple = true
            }
        }
    }
}

private enum SceneAnimationPreset {
    static let sceneSwitch = Animation.interpolatingSpring(
        mass: 0.88,
        stiffness: 142,
        damping: 24,
        initialVelocity: 0.18
    )
}

private struct SceneAmbientGlassOrbs: View {
    let sceneKey: String

    private var sceneIndex: Int {
        switch sceneKey {
        case "processing": return 3
        case "performance": return 2
        case "fillframeTest": return 1
        default: return 0
        }
    }

    var body: some View {
        ZStack {
            Circle()
                .fill(.ultraThinMaterial)
                .frame(width: 260, height: 260)
                .opacity(0.26)
                .blur(radius: 2)
                .offset(x: sceneIndex.isMultiple(of: 2) ? -170 : 170, y: sceneIndex >= 2 ? -270 : -210)

            Circle()
                .fill(.thinMaterial)
                .frame(width: 190, height: 190)
                .opacity(0.18)
                .blur(radius: 6)
                .offset(x: sceneIndex >= 2 ? 150 : -145, y: sceneIndex == 1 ? 260 : 220)

            RoundedRectangle(cornerRadius: 44, style: .continuous)
                .fill(.ultraThinMaterial)
                .frame(width: 210, height: 88)
                .opacity(0.10)
                .rotationEffect(.degrees(sceneIndex.isMultiple(of: 2) ? -9 : 9))
                .offset(x: sceneIndex == 0 ? 125 : -125, y: sceneIndex == 3 ? 42 : -36)
        }
        .animation(SceneAnimationPreset.sceneSwitch, value: sceneKey)
    }
}

private struct SceneLiquidGlassStretchModifier: ViewModifier {
    let phase: CGFloat
    let direction: CGFloat

    private var amount: CGFloat {
        min(max(abs(phase), 0), 1)
    }

    func body(content: Content) -> some View {
        content
            .opacity(Double(1 - amount * 0.72))
            .scaleEffect(x: 1 + amount * 0.115, y: 1 - amount * 0.055, anchor: .center)
            .blur(radius: amount * 5.8)
            .offset(x: phase * direction * 18, y: amount * 8)
            .brightness(Double(amount) * 0.025)
            .overlay(
                RoundedRectangle(cornerRadius: 34, style: .continuous)
                    .strokeBorder(.white.opacity(Double(amount) * 0.22), lineWidth: 0.9)
                    .padding(10)
                    .allowsHitTesting(false)
            )
            .clipShape(RoundedRectangle(cornerRadius: 34, style: .continuous))
            .compositingGroup()
    }
}

private extension AnyTransition {
    static func liquidGlassStretchScene(direction: CGFloat) -> AnyTransition {
        .asymmetric(
            insertion: .modifier(
                active: SceneLiquidGlassStretchModifier(phase: 1, direction: direction),
                identity: SceneLiquidGlassStretchModifier(phase: 0, direction: direction)
            ),
            removal: .modifier(
                active: SceneLiquidGlassStretchModifier(phase: -1, direction: direction),
                identity: SceneLiquidGlassStretchModifier(phase: 0, direction: direction)
            )
        )
    }
}

private struct LiquidGlassCardStretchAppearModifier: ViewModifier {
    @State private var isVisible = false

    func body(content: Content) -> some View {
        content
            .opacity(isVisible ? 1 : 0)
            .scaleEffect(x: isVisible ? 1 : 0.74, y: isVisible ? 1 : 1.10, anchor: .center)
            .blur(radius: isVisible ? 0 : 6)
            .brightness(isVisible ? 0 : 0.035)
            .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
            .animation(
                .interpolatingSpring(mass: 0.74, stiffness: 168, damping: 22, initialVelocity: 0.22),
                value: isVisible
            )
            .onAppear {
                isVisible = false
                DispatchQueue.main.async {
                    isVisible = true
                }
            }
    }
}

private struct NonlinearEntranceModifier: ViewModifier {
    let index: Int
    let isReady: Bool

    @ViewBuilder
    func body(content: Content) -> some View {
        if #available(iOS 17.0, *) {
            base(content)
                .scrollTransition(axis: .vertical) { view, phase in
                    view
                        .scaleEffect(scrollScale(phase.value))
                        .opacity(scrollOpacity(phase.value))
                        .blur(radius: scrollBlur(phase.value))
                        .rotation3DEffect(
                            .degrees(scrollRotation(phase.value)),
                            axis: (x: 1, y: 0, z: 0),
                            perspective: 0.72
                        )
                        .offset(y: scrollOffset(phase.value))
                }
        } else {
            base(content)
        }
    }

    private func base(_ content: Content) -> some View {
        let delay = Double(index) * 0.028
        return content
            .opacity(isReady ? 1 : 0)
            .scaleEffect(x: isReady ? 1 : 0.80, y: isReady ? 1 : 1.08, anchor: .center)
            .blur(radius: isReady ? 0 : 5)
            .offset(y: isReady ? 0 : 16 + CGFloat(index % 3) * 3)
            .brightness(isReady ? 0 : 0.025)
            .animation(
                .interpolatingSpring(mass: 0.72, stiffness: 170, damping: 24, initialVelocity: 0.20)
                    .delay(delay),
                value: isReady
            )
    }

    nonisolated private func scrollCurve(_ value: Double) -> Double {
        let t = min(max(abs(value), 0), 1)
        return t * t * (3 - 2 * t)
    }

    nonisolated private func scrollOpacity(_ value: Double) -> Double {
        max(0.38, 1.0 - scrollCurve(value) * 0.62)
    }

    nonisolated private func scrollScale(_ value: Double) -> Double {
        1.0 - scrollCurve(value) * 0.07
    }

    nonisolated private func scrollBlur(_ value: Double) -> Double {
        scrollCurve(value) * 3.5
    }

    nonisolated private func scrollRotation(_ value: Double) -> Double {
        value * 2.4 * scrollCurve(value)
    }

    nonisolated private func scrollOffset(_ value: Double) -> CGFloat {
        CGFloat(value * (10.0 + scrollCurve(value) * 12.0))
    }

    nonisolated private func smoothstep(_ x: Double) -> Double {
        let t = min(max(x, 0), 1)
        return t * t * (3 - 2 * t)
    }
}

private struct LiquidGlassProgressBar: View {
    let title: String
    let value: Double
    let detail: String

    @State private var displayedValue: Double = 0

    private var clamped: Double {
        min(max(value, 0), 1)
    }

    private var displayedClamped: Double {
        min(max(displayedValue, 0), 1)
    }

    var body: some View {
        VStack(alignment: .leading, spacing: title.isEmpty ? 0 : 7) {
            if !title.isEmpty || !detail.isEmpty {
                HStack {
                    if !title.isEmpty {
                        Text(title)
                            .font(.caption.weight(.semibold))
                    }
                    Spacer()
                    if !detail.isEmpty {
                        Text(detail)
                            .font(.caption.monospacedDigit())
                            .foregroundStyle(.secondary)
                            .contentTransition(.numericText())
                            .animation(.easeOut(duration: 0.25), value: detail)
                    }
                }
            }

            GeometryReader { geometry in
                ZStack(alignment: .leading) {
                    Capsule()
                        .fill(.secondary.opacity(0.16))
                        .overlay(
                            Capsule()
                                .strokeBorder(.white.opacity(0.25), lineWidth: 0.6)
                        )
                        .liquidGlassCapsule()

                    Capsule()
                        .fill(.tint.opacity(0.72))
                        .frame(width: max(0, geometry.size.width * CGFloat(displayedClamped)))
                        .liquidGlassCapsule()
                }
            }
            .frame(height: 13)
        }
        .onAppear {
            displayedValue = clamped
        }
        .onChange(of: clamped) { newValue in
            let isReset = newValue < displayedValue - 0.18
            let isComplete = newValue >= 0.999
            let animation = isReset
                ? Animation.easeOut(duration: 0.18)
                : (isComplete
                   ? Animation.easeOut(duration: 0.22)
                   : Animation.interpolatingSpring(mass: 0.82, stiffness: 86, damping: 22, initialVelocity: 0.08))

            withAnimation(animation) {
                displayedValue = newValue
            }
        }
    }
}

private struct SegmentProgressRowView: View {
    let row: TaskProgressRow

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 8) {
                Image(systemName: row.symbolName)
                    .font(.caption.weight(.semibold))
                    .frame(width: 20)

                Text(row.title)
                    .font(.footnote.weight(.semibold))

                Spacer()

                Text(row.stateText)
                    .font(.caption)
                    .foregroundStyle(.secondary)

                Text("\(Int((min(max(row.progress, 0), 1) * 100).rounded()))%")
                    .font(.caption.monospacedDigit())
                    .foregroundStyle(.secondary)
                    .contentTransition(.numericText())
                    .animation(.easeOut(duration: 0.25), value: row.progress)
            }

            LiquidGlassProgressBar(title: "", value: row.progress, detail: row.detail)
                .frame(height: 28)
                .animation(.easeOut(duration: 0.30), value: row.detail)
        }
        .padding(10)
        .liquidGlassCard(cornerRadius: 16)
    }
}

private struct SlowMotionTrimPreview: View {
    let videoURL: URL
    @Binding var playheadSeconds: Double
    let maxSeconds: Double
    let sourcePreviewSeconds: Double
    let sourceStartSeconds: Double
    let sourceDurationSeconds: Double
    let frameStepSeconds: Double
    let playbackRate: Double

    @State private var player: AVPlayer?
    @State private var proxyURL: URL?
    @State private var proxyStatusText = "准备预览"
    @State private var proxyProgress: Double = 0
    @State private var videoAspectRatio: CGFloat = 16.0 / 9.0
    @State private var previewTaskID = UUID()
    @State private var isTrimPreviewPlaying = false
    @State private var timeObserverToken: Any?

    private var upperBound: Double {
        max(0.10, maxSeconds)
    }

    private var clampedPlayhead: Double {
        min(max(playheadSeconds, 0), upperBound)
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            ZStack(alignment: .bottomLeading) {
                RoundedRectangle(cornerRadius: 22, style: .continuous)
                    .fill(.black.opacity(0.08))

                if let player {
                    PlayerLayerPreview(player: player)
                        .aspectRatio(videoAspectRatio, contentMode: .fit)
                        .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
                } else {
                    VStack(spacing: 12) {
                        ProgressView()
                            .scaleEffect(1.08)

                        Text(proxyStatusText)
                            .font(.subheadline.weight(.medium))

                        LiquidGlassProgressBar(
                            title: "720p 代理",
                            value: proxyProgress,
                            detail: String(format: "%.0f%%", min(max(proxyProgress, 0), 1) * 100)
                        )
                        .frame(maxWidth: 420)
                        .padding(.horizontal, 26)
                    }
                    .foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                }

                VStack(alignment: .leading, spacing: 6) {
                    Text(String(format: "播放位置 %.3f 秒", clampedPlayhead))
                        .font(.caption.monospacedDigit().weight(.semibold))
                    Text(String(format: "对应源时间 %.3f 秒", sourcePreviewSeconds))
                        .font(.caption2.monospacedDigit())
                        .foregroundStyle(.secondary)
                    Text(proxyStatusText)
                        .font(.caption2)
                        .foregroundStyle(.secondary)

                    if proxyProgress > 0, proxyProgress < 1 {
                        LiquidGlassProgressBar(
                            title: "",
                            value: proxyProgress,
                            detail: String(format: "%.0f%%", proxyProgress * 100)
                        )
                        .frame(width: 150)
                    }
                }
                .padding(.horizontal, 12)
                .padding(.vertical, 8)
                .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                .padding(12)
            }
            .frame(maxWidth: .infinity)
            .aspectRatio(videoAspectRatio, contentMode: .fit)
            .frame(maxHeight: 520)
            .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 22, style: .continuous)
                    .strokeBorder(.white.opacity(0.22), lineWidth: 0.9)
            )
            .background(
                KeyboardArrowCommandCatcher { step in
                    movePlayheadByFrames(step)
                }
                .frame(width: 0, height: 0)
            )

            VStack(alignment: .leading, spacing: 10) {
                Slider(value: $playheadSeconds, in: 0...upperBound) {
                    Text("播放位置")
                } minimumValueLabel: {
                    Text("0s")
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                } maximumValueLabel: {
                    Text(String(format: "%.1fs", upperBound))
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                }
                .onChange(of: playheadSeconds) { newValue in
                    let clamped = min(max(newValue, 0), upperBound)
                    if clamped != newValue {
                        playheadSeconds = clamped
                    }
                    stopTrimPlaybackIfNeeded()
                    seekPreview(toSourceSecond: sourcePreviewSeconds)
                }

                HStack {
                    Text("←/→ 一帧，Shift+←/→ 十帧；播放条只负责预览定位。")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    Spacer(minLength: 8)
                    Text(String(format: "%.3f / %.3f 秒", clampedPlayhead, upperBound))
                        .font(.caption.monospacedDigit())
                        .foregroundStyle(.secondary)
                }

                Button {
                    toggleTrimPlayback()
                } label: {
                    Label(isTrimPreviewPlaying ? "停止播放" : "播放裁剪慢放预览", systemImage: isTrimPreviewPlaying ? "stop.fill" : "play.fill")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(BouncyLiquidGlassButtonStyle(prominent: true))
                .disabled(player == nil || proxyProgress < 1)
            }
        }
        .padding(12)
        .liquidGlassCard(cornerRadius: 20)
        .task(id: previewTaskID) {
            await loadPreviewAssets()
        }
        .onAppear {
            previewTaskID = UUID()
        }
        .onDisappear {
            stopTrimPlaybackIfNeeded()
            player?.pause()
            player = nil
        }
        .onChange(of: videoURL) { _ in
            previewTaskID = UUID()
        }
        .onChange(of: sourcePreviewSeconds) { newValue in
            if !isTrimPreviewPlaying {
                seekPreview(toSourceSecond: newValue)
            }
        }
    }

    @MainActor
    private func loadPreviewAssets() async {
        stopTrimPlaybackIfNeeded()
        player?.pause()
        player = nil
        proxyURL = nil
        proxyProgress = 0.02
        proxyStatusText = "分析视频比例"

        let asset = AVURLAsset(url: videoURL)
        if let track = try? await asset.loadTracks(withMediaType: .video).first,
           let size = try? await track.load(.naturalSize),
           let transform = try? await track.load(.preferredTransform) {
            let transformed = size.applying(transform)
            let width = abs(transformed.width)
            let height = abs(transformed.height)
            if width > 0 && height > 0 {
                videoAspectRatio = width / height
            }
        }

        proxyStatusText = "生成 720p 预览代理"
        proxyProgress = max(proxyProgress, 0.08)
        let previewURL = await buildPreviewProxy(asset: asset, sourceURL: videoURL)
        proxyURL = previewURL

        let item = AVPlayerItem(url: previewURL)
        if #available(iOS 16.0, *) {
            item.preferredMaximumResolution = CGSize(width: 1280, height: 720)
        }
        item.preferredForwardBufferDuration = 0

        let newPlayer = AVPlayer(playerItem: item)
        newPlayer.isMuted = true
        newPlayer.automaticallyWaitsToMinimizeStalling = false
        player = newPlayer

        proxyProgress = 1
        proxyStatusText = previewURL == videoURL ? "使用原视频预览" : "720p 代理预览"
        seekPreview(toSourceSecond: sourcePreviewSeconds)
    }

    private func buildPreviewProxy(asset: AVAsset, sourceURL: URL) async -> URL {
        let naturalSize = await previewNaturalSize(asset: asset)
        let maxSide = max(naturalSize.width, naturalSize.height)
        if maxSide <= 1280 {
            await MainActor.run {
                proxyProgress = 1
                proxyStatusText = "原视频已足够流畅，无需代理"
            }
            return sourceURL
        }

        let safeName = String(abs(sourceURL.absoluteString.hashValue))
        let outputURL = FileManager.default.temporaryDirectory
            .appendingPathComponent("buzhen_preview_proxy_720p_\(safeName).mp4")

        if FileManager.default.fileExists(atPath: outputURL.path) {
            await MainActor.run {
                proxyProgress = 1
                proxyStatusText = "读取已缓存的 720p 代理"
            }
            return outputURL
        }

        try? FileManager.default.removeItem(at: outputURL)

        guard let export = AVAssetExportSession(asset: asset, presetName: AVAssetExportPreset1280x720) else {
            await MainActor.run {
                proxyProgress = 1
                proxyStatusText = "代理不可用，改用原视频"
            }
            return sourceURL
        }

        export.outputURL = outputURL
        export.outputFileType = .mp4
        export.shouldOptimizeForNetworkUse = true

        await MainActor.run {
            proxyProgress = 0.10
            proxyStatusText = "正在生成 720p 代理"
        }

        return await withCheckedContinuation { continuation in
            let poller = Task {
                while !Task.isCancelled {
                    let progress = min(max(Double(export.progress), 0), 0.98)
                    await MainActor.run {
                        proxyProgress = max(proxyProgress, progress)
                        proxyStatusText = String(format: "正在生成 720p 代理 %.0f%%", proxyProgress * 100)
                    }

                    if export.status != .waiting && export.status != .exporting && progress >= 0.98 {
                        break
                    }

                    try? await Task.sleep(nanoseconds: 120_000_000)
                }
            }

            export.exportAsynchronously {
                poller.cancel()

                let finalURL: URL
                let finalText: String

                if export.status == .completed,
                   FileManager.default.fileExists(atPath: outputURL.path) {
                    finalURL = outputURL
                    finalText = "720p 代理生成完成"
                } else {
                    finalURL = sourceURL
                    finalText = "代理生成失败，改用原视频"
                }

                Task { @MainActor in
                    proxyProgress = 1
                    proxyStatusText = finalText
                    continuation.resume(returning: finalURL)
                }
            }
        }
    }

    private func previewNaturalSize(asset: AVAsset) async -> CGSize {
        guard let track = try? await asset.loadTracks(withMediaType: .video).first,
              let size = try? await track.load(.naturalSize),
              let transform = try? await track.load(.preferredTransform) else {
            return .zero
        }

        let transformed = size.applying(transform)
        return CGSize(width: abs(transformed.width), height: abs(transformed.height))
    }

    private func seekPreview(toSourceSecond second: Double) {
        guard let player else { return }
        let clampedSecond = max(0, second)
        let time = CMTime(seconds: clampedSecond, preferredTimescale: 600)
        let tolerance = CMTime(seconds: 0.055, preferredTimescale: 600)

        player.currentItem?.cancelPendingSeeks()
        player.pause()
        player.seek(to: time, toleranceBefore: tolerance, toleranceAfter: tolerance)
    }

    private func movePlayheadByFrames(_ frames: Int) {
        guard frames != 0 else { return }
        let delta = Double(frames) * max(frameStepSeconds, 0.0001)
        playheadSeconds = min(max(playheadSeconds + delta, 0), upperBound)
    }

    private func toggleTrimPlayback() {
        if isTrimPreviewPlaying {
            stopTrimPlaybackIfNeeded()
        } else {
            playTrimPreview()
        }
    }

    private func playTrimPreview() {
        guard let player else { return }

        stopTrimPlaybackIfNeeded()

        let start = max(0, sourceStartSeconds)
        let end = max(start + 0.02, sourceStartSeconds + sourceDurationSeconds)
        let startTime = CMTime(seconds: start, preferredTimescale: 600)
        let rate = Float(min(max(playbackRate, 0.05), 1.0))

        player.currentItem?.cancelPendingSeeks()
        player.seek(to: startTime, toleranceBefore: .zero, toleranceAfter: .zero) { _ in
            Task { @MainActor in
                isTrimPreviewPlaying = true
                player.rate = rate

                let interval = CMTime(seconds: 0.025, preferredTimescale: 600)
                timeObserverToken = player.addPeriodicTimeObserver(forInterval: interval, queue: .main) { time in
                    let seconds = time.seconds
                    let outputSeconds = seconds / max(playbackRate, 0.01)

                    if outputSeconds.isFinite {
                        playheadSeconds = min(max(outputSeconds, 0), upperBound)
                    }

                    if seconds >= end {
                        stopTrimPlaybackIfNeeded()
                        seekPreview(toSourceSecond: end)
                    }
                }
            }
        }
    }

    private func stopTrimPlaybackIfNeeded() {
        if let token = timeObserverToken {
            player?.removeTimeObserver(token)
            timeObserverToken = nil
        }

        player?.pause()
        isTrimPreviewPlaying = false
    }
}

private struct KeyboardArrowCommandCatcher: UIViewRepresentable {
    let onStep: (Int) -> Void

    func makeUIView(context: Context) -> ArrowKeyView {
        let view = ArrowKeyView()
        view.onStep = onStep
        return view
    }

    func updateUIView(_ uiView: ArrowKeyView, context: Context) {
        uiView.onStep = onStep
        DispatchQueue.main.async {
            uiView.becomeFirstResponder()
        }
    }

    final class ArrowKeyView: UIView {
        var onStep: ((Int) -> Void)?

        override var canBecomeFirstResponder: Bool {
            true
        }

        override var keyCommands: [UIKeyCommand]? {
            [
                UIKeyCommand(input: UIKeyCommand.inputLeftArrow, modifierFlags: [], action: #selector(leftOneFrame)),
                UIKeyCommand(input: UIKeyCommand.inputRightArrow, modifierFlags: [], action: #selector(rightOneFrame)),
                UIKeyCommand(input: UIKeyCommand.inputLeftArrow, modifierFlags: .shift, action: #selector(leftTenFrames)),
                UIKeyCommand(input: UIKeyCommand.inputRightArrow, modifierFlags: .shift, action: #selector(rightTenFrames))
            ]
        }

        override func didMoveToWindow() {
            super.didMoveToWindow()
            DispatchQueue.main.async {
                self.becomeFirstResponder()
            }
        }

        @objc private func leftOneFrame() {
            onStep?(-1)
        }

        @objc private func rightOneFrame() {
            onStep?(1)
        }

        @objc private func leftTenFrames() {
            onStep?(-10)
        }

        @objc private func rightTenFrames() {
            onStep?(10)
        }
    }
}

private struct PlayerLayerPreview: UIViewRepresentable {
    let player: AVPlayer

    func makeUIView(context: Context) -> PlayerLayerPreviewView {
        let view = PlayerLayerPreviewView()
        view.playerLayer.videoGravity = .resizeAspect
        view.playerLayer.player = player
        return view
    }

    func updateUIView(_ uiView: PlayerLayerPreviewView, context: Context) {
        uiView.playerLayer.videoGravity = .resizeAspect
        uiView.playerLayer.player = player
    }
}

private final class PlayerLayerPreviewView: UIView {
    override static var layerClass: AnyClass {
        AVPlayerLayer.self
    }

    var playerLayer: AVPlayerLayer {
        layer as! AVPlayerLayer
    }
}

// MARK: - UIKit 文件选择器

struct VideoDocumentPicker: UIViewControllerRepresentable {
    let onPick: ([URL]) -> Void

    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        let picker = UIDocumentPickerViewController(forOpeningContentTypes: ImportStore.supportedVideoTypes, asCopy: true)
        picker.allowsMultipleSelection = false
        picker.delegate = context.coordinator
        picker.shouldShowFileExtensions = true
        picker.modalPresentationStyle = .formSheet
        return picker
    }

    func updateUIViewController(_ uiViewController: UIDocumentPickerViewController, context: Context) {}

    func makeCoordinator() -> Coordinator {
        Coordinator(onPick: onPick)
    }

    final class Coordinator: NSObject, UIDocumentPickerDelegate {
        let onPick: ([URL]) -> Void

        init(onPick: @escaping ([URL]) -> Void) {
            self.onPick = onPick
        }

        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            DispatchQueue.main.async {
                self.onPick(urls)
            }
        }

        func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
            DispatchQueue.main.async {
                self.onPick([])
            }
        }
    }
}

// MARK: - Native Liquid Glass helpers

private struct LiquidGlassRoot<Content: View>: View {
    let spacing: CGFloat
    let content: Content

    init(spacing: CGFloat = 18, @ViewBuilder content: () -> Content) {
        self.spacing = spacing
        self.content = content()
    }

    var body: some View {
        if #available(iOS 26.0, *) {
            GlassEffectContainer(spacing: spacing) {
                content
            }
        } else {
            content
        }
    }
}

private struct BouncyLiquidGlassCardButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .overlay {
                RoundedRectangle(cornerRadius: 24, style: .continuous)
                    .fill(Color.white.opacity(configuration.isPressed ? 0.13 : 0.0))
                    .overlay(
                        RoundedRectangle(cornerRadius: 24, style: .continuous)
                            .strokeBorder(Color.white.opacity(configuration.isPressed ? 0.48 : 0.0), lineWidth: 1.2)
                    )
                    .allowsHitTesting(false)
            }
            .scaleEffect(configuration.isPressed ? 0.94 : 1.0)
            .brightness(configuration.isPressed ? -0.018 : 0)
            .shadow(color: .black.opacity(configuration.isPressed ? 0.04 : 0.08), radius: configuration.isPressed ? 4 : 12, x: 0, y: configuration.isPressed ? 2 : 8)
            .animation(.interpolatingSpring(mass: 0.58, stiffness: 310, damping: 16, initialVelocity: 0.45), value: configuration.isPressed)
    }
}

private struct BouncyLiquidGlassButtonStyle: ButtonStyle {
    let prominent: Bool

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.subheadline.weight(.semibold))
            .padding(.horizontal, 14)
            .padding(.vertical, 12)
            .frame(minHeight: 48)
            .background {
                Capsule()
                    .fill(prominent ? Color.accentColor.opacity(0.20) : Color.secondary.opacity(0.10))
                    .background(.ultraThinMaterial, in: Capsule())
                    .overlay(
                        Capsule()
                            .strokeBorder(.white.opacity(configuration.isPressed ? 0.42 : 0.24), lineWidth: 0.8)
                    )
            }
            .scaleEffect(configuration.isPressed ? 0.92 : 1.0)
            .brightness(configuration.isPressed ? -0.025 : 0)
            .shadow(color: .black.opacity(configuration.isPressed ? 0.03 : 0.07), radius: configuration.isPressed ? 3 : 10, x: 0, y: configuration.isPressed ? 1 : 6)
            .animation(.interpolatingSpring(mass: 0.56, stiffness: 310, damping: 15, initialVelocity: 0.45), value: configuration.isPressed)
    }
}

extension View {
    @ViewBuilder
    func liquidGlassCard(cornerRadius: CGFloat) -> some View {
        if #available(iOS 26.0, *) {
            self
                .glassEffect(.regular, in: .rect(cornerRadius: cornerRadius))
        } else {
            self
                .background(.regularMaterial, in: RoundedRectangle(cornerRadius: cornerRadius, style: .continuous))
        }
    }

    @ViewBuilder
    func liquidGlassCapsule() -> some View {
        if #available(iOS 26.0, *) {
            self
                .glassEffect(.regular, in: .capsule)
        } else {
            self
                .background(.quaternary, in: Capsule())
        }
    }

    @ViewBuilder
    func liquidGlassCircle() -> some View {
        if #available(iOS 26.0, *) {
            self
                .glassEffect(.regular, in: .circle)
        } else {
            self
                .background(.quaternary, in: Circle())
        }
    }

    @ViewBuilder
    func liquidGlassTextField(cornerRadius: CGFloat) -> some View {
        if #available(iOS 26.0, *) {
            self
                .padding(.horizontal, 12)
                .padding(.vertical, 9)
                .glassEffect(.regular, in: .rect(cornerRadius: cornerRadius))
        } else {
            self
                .padding(.horizontal, 12)
                .padding(.vertical, 9)
                .background(.thinMaterial, in: RoundedRectangle(cornerRadius: cornerRadius, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
                        .strokeBorder(.quaternary, lineWidth: 0.7)
                )
        }
    }

    @ViewBuilder
    func liquidGlassButtonStyle(prominent: Bool) -> some View {
        if #available(iOS 26.0, *) {
            self
                .buttonStyle(.glass)
                .controlSize(.large)
        } else {
            if prominent {
                self
                    .buttonStyle(.borderedProminent)
                    .controlSize(.large)
            } else {
                self
                    .buttonStyle(.bordered)
                    .controlSize(.large)
            }
        }
    }
}

private extension Array {
    subscript(safe index: Int) -> Element? {
        guard indices.contains(index) else { return nil }
        return self[index]
    }
}
