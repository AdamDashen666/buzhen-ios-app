import Foundation
import SwiftUI

@MainActor
final class AppStore: ObservableObject {
    @Published var projects: [WorkflowProject] = []
    @Published var apiConfigs: [APIProviderConfig] = [] { didSet { saveAPIConfigs() } }
    @Published var runRecords: [RunRecord] = [] { didSet { saveRunRecords() } }
    @Published var snapshots: [VersionSnapshot] = [] { didSet { saveSnapshots() } }
    @Published var settings: AppSettings = AppSettings() { didSet { saveSettings() } }
    @Published var selectedProjectID: UUID?
    @Published var activeRunID: UUID?

    let aiClient = AIClient()
    let engine = WorkflowEngine()

    init() {
        loadAll()
        if projects.isEmpty {
            let starter = WorkflowProject.blank(title: "AI 工作流项目")
            projects = [starter]
            selectedProjectID = starter.id
            saveProjects()
        } else {
            selectedProjectID = projects.first?.id
        }
    }

    var selectedProject: WorkflowProject? {
        guard let selectedProjectID else { return projects.first }
        return projects.first(where: { $0.id == selectedProjectID }) ?? projects.first
    }

    func createProject(title: String = "新工作流") {
        let project = WorkflowProject.blank(title: title)
        projects.insert(project, at: 0)
        selectedProjectID = project.id
        saveProjects()
    }

    func deleteProject(_ project: WorkflowProject) {
        projects.removeAll { $0.id == project.id }
        if selectedProjectID == project.id { selectedProjectID = projects.first?.id }
        saveProjects()
    }

    func updateProject(_ project: WorkflowProject) {
        guard let index = projects.firstIndex(where: { $0.id == project.id }) else { return }
        var updated = project
        updated.updatedAt = Date()
        projects[index] = updated
        saveProjects()
    }

    func updatePrompt(projectID: UUID, prompt: String, autoSelect: Bool) {
        guard var project = projects.first(where: { $0.id == projectID }) else { return }
        project.userPrompt = prompt
        project.autoSelectModules = autoSelect
        updateProject(project)
    }

    func autoBuildSelectedProject() {
        guard var project = selectedProject else { return }
        project = WorkflowAutoBuilder.build(from: project)
        updateProject(project)
    }

    func addNode(_ kind: WorkflowNodeKind, to projectID: UUID) {
        guard var project = projects.first(where: { $0.id == projectID }) else { return }
        var node = WorkflowNode(kind: kind, title: kind.title, x: 220 + Double(project.nodes.count * 36), y: 220 + Double(project.nodes.count * 18))
        node.prompt = kind.defaultPrompt
        node.retryLimit = settings.maxReturnCount
        node.maxReturnCount = settings.maxReturnCount
        applyDefaultModel(to: &node)
        project.nodes.append(node)
        // v1.4：新增模块默认不自动连线，必须由用户拖拽端口连接。
        updateProject(project)
    }

    func removeNode(projectID: UUID, nodeID: UUID) {
        guard var project = projects.first(where: { $0.id == projectID }) else { return }
        project.nodes.removeAll { $0.id == nodeID && $0.kind != .start && $0.kind != .output }
        project.edges.removeAll { $0.from == nodeID || $0.to == nodeID }
        updateProject(project)
    }

    func updateNode(_ node: WorkflowNode, in projectID: UUID) {
        guard var project = projects.first(where: { $0.id == projectID }) else { return }
        guard let index = project.nodes.firstIndex(where: { $0.id == node.id }) else { return }
        project.nodes[index] = node
        updateProject(project)
    }

    func moveNode(projectID: UUID, nodeID: UUID, x: Double, y: Double, persist: Bool = true) {
        guard let projectIndex = projects.firstIndex(where: { $0.id == projectID }) else { return }
        guard let nodeIndex = projects[projectIndex].nodes.firstIndex(where: { $0.id == nodeID }) else { return }
        let clampedX = min(max(x, 110), 2290)
        let clampedY = min(max(y, 90), 1510)
        objectWillChange.send()
        projects[projectIndex].nodes[nodeIndex].x = clampedX
        projects[projectIndex].nodes[nodeIndex].y = clampedY
        projects[projectIndex].updatedAt = Date()
        if persist { saveProjects() }
    }

    func connect(projectID: UUID, from: UUID, to: UUID) {
        guard var project = projects.first(where: { $0.id == projectID }) else { return }
        guard from != to else { return }
        guard !project.edges.contains(where: { $0.from == from && $0.to == to }) else { return }
        project.edges.append(WorkflowEdge(from: from, to: to, condition: .always))
        updateProject(project)
    }

    func removeAllEdges(projectID: UUID) {
        guard var project = projects.first(where: { $0.id == projectID }) else { return }
        project.edges.removeAll()
        updateProject(project)
    }


    func resetWorkflow(projectID: UUID) {
        guard var project = projects.first(where: { $0.id == projectID }) else { return }
        let blank = WorkflowProject.blank(title: project.title)
        project.nodes = blank.nodes
        project.edges = []
        updateProject(project)
    }

    func applyDefaultModelsToSelectedProject() {
        guard let project = selectedProject else { return }
        applyDefaultModels(to: project.id)
    }

    func applyDefaultModels(to projectID: UUID) {
        guard let projectIndex = projects.firstIndex(where: { $0.id == projectID }) else { return }
        guard let config = apiConfigs.first else { return }
        objectWillChange.send()
        for nodeIndex in projects[projectIndex].nodes.indices {
            let kind = projects[projectIndex].nodes[nodeIndex].kind
            guard kind != .start && kind != .output && kind != .logger && kind != .versionSnapshot && kind != .filePackager && kind != .humanApproval else { continue }
            projects[projectIndex].nodes[nodeIndex].providerID = config.id
            projects[projectIndex].nodes[nodeIndex].modelID = defaultModelID(for: kind, in: config)
        }
        projects[projectIndex].updatedAt = Date()
        saveProjects()
    }

    func addAPIConfig(_ config: APIProviderConfig, apiKey: String) {
        apiConfigs.append(config)
        try? KeychainService.save(apiKey, account: config.keychainAccount)
    }

    func updateAPIConfig(_ config: APIProviderConfig, apiKey: String?) {
        guard let index = apiConfigs.firstIndex(where: { $0.id == config.id }) else { return }
        apiConfigs[index] = config
        if let apiKey, !apiKey.isEmpty {
            try? KeychainService.save(apiKey, account: config.keychainAccount)
        }
    }

    func deleteAPIConfig(_ config: APIProviderConfig) {
        apiConfigs.removeAll { $0.id == config.id }
        try? KeychainService.delete(account: config.keychainAccount)
    }

    func refreshModels(for config: APIProviderConfig) async throws {
        let key = try KeychainService.read(account: config.keychainAccount)
        let models = try await aiClient.fetchModels(baseURL: config.baseURL, apiKey: key)
        var updated = config
        updated.models = models
        if updated.defaultTextModel.isEmpty { updated.defaultTextModel = models.first?.id ?? "" }
        if updated.defaultVisionModel.isEmpty { updated.defaultVisionModel = models.first(where: { $0.supportsVision })?.id ?? models.first?.id ?? "" }
        updateAPIConfig(updated, apiKey: nil)
    }

    func runSelectedProject() async {
        guard var project = selectedProject else { return }
        if project.autoSelectModules {
            project = WorkflowAutoBuilder.build(from: project)
            updateProject(project)
        }

        let estimate = TokenEstimator.estimate(project: project)
        if let tokenBlockMessage = tokenLimitBlockMessage(for: estimate.estimatedTotal) {
            var record = RunRecord(projectID: project.id, projectTitle: project.title, status: .failed)
            record.endedAt = Date()
            record.logs.append(RunLogEntry(level: .error, message: tokenBlockMessage))
            runRecords.insert(record, at: 0)
            return
        }

        var record = RunRecord(projectID: project.id, projectTitle: project.title)
        runRecords.insert(record, at: 0)
        activeRunID = record.id

        do {
            record = try await engine.run(
                project: project,
                apiConfigs: apiConfigs,
                settings: settings,
                aiClient: aiClient
            ) { [weak self] partial in
                Task { @MainActor in
                    self?.replaceRunRecord(partial)
                }
            }
            replaceRunRecord(record)
            saveSnapshot(project: project, output: record.output, note: "运行完成自动快照")
        } catch {
            record.status = .failed
            record.endedAt = Date()
            record.logs.append(RunLogEntry(level: .error, message: error.localizedDescription))
            replaceRunRecord(record)
        }
    }

    func replaceRunRecord(_ record: RunRecord) {
        if let index = runRecords.firstIndex(where: { $0.id == record.id }) {
            runRecords[index] = record
        } else {
            runRecords.insert(record, at: 0)
        }
    }

    func saveSnapshot(project: WorkflowProject, output: String, note: String) {
        let snapshot = VersionSnapshot(projectID: project.id, title: project.title, project: project, output: output, note: note)
        snapshots.insert(snapshot, at: 0)
    }

    private func tokenLimitBlockMessage(for estimatedTotal: Int) -> String? {
        switch settings.tokenLimitMode {
        case .none:
            return nil
        case .singleWorkflow:
            return estimatedTotal > settings.singleWorkflowTokenLimit
                ? "预估 Token 超过单次工作流限制：\(estimatedTotal) / \(settings.singleWorkflowTokenLimit)"
                : nil
        case .daily:
            let usedToday = runRecords
                .filter { Calendar.current.isDateInToday($0.startedAt) }
                .map { $0.tokenUsage.total }
                .reduce(0, +)
            let projected = usedToday + estimatedTotal
            return projected > settings.dailyTokenLimit
                ? "预估 Token 超过今日总量限制：今日已用 \(usedToday)，本次预估 \(estimatedTotal)，限制 \(settings.dailyTokenLimit)"
                : nil
        }
    }

    private func applyDefaultModel(to node: inout WorkflowNode) {
        guard let config = apiConfigs.first else { return }
        node.providerID = config.id
        node.modelID = defaultModelID(for: node.kind, in: config)
    }

    private func defaultModelID(for kind: WorkflowNodeKind, in config: APIProviderConfig) -> String {
        if kind.requiresImageGenerationModel {
            return config.defaultImageModel.isEmpty ? config.defaultTextModel : config.defaultImageModel
        }
        if kind.requiresVisionModel {
            return config.defaultVisionModel.isEmpty ? config.defaultTextModel : config.defaultVisionModel
        }
        return config.defaultTextModel
    }

    private func loadAll() {
        projects = Self.load([WorkflowProject].self, key: "projects") ?? []
        apiConfigs = Self.load([APIProviderConfig].self, key: "apiConfigs") ?? []
        runRecords = Self.load([RunRecord].self, key: "runRecords") ?? []
        snapshots = Self.load([VersionSnapshot].self, key: "snapshots") ?? []
        settings = Self.load(AppSettings.self, key: "settings") ?? AppSettings()
    }

    private func saveProjects() { Self.save(projects, key: "projects") }
    private func saveAPIConfigs() { Self.save(apiConfigs, key: "apiConfigs") }
    private func saveRunRecords() { Self.save(runRecords, key: "runRecords") }
    private func saveSnapshots() { Self.save(snapshots, key: "snapshots") }
    private func saveSettings() { Self.save(settings, key: "settings") }

    private static func save<T: Encodable>(_ value: T, key: String) {
        let encoder = JSONEncoder()
        encoder.dateEncodingStrategy = .iso8601
        if let data = try? encoder.encode(value) {
            UserDefaults.standard.set(data, forKey: key)
        }
    }

    private static func load<T: Decodable>(_ type: T.Type, key: String) -> T? {
        guard let data = UserDefaults.standard.data(forKey: key) else { return nil }
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        return try? decoder.decode(T.self, from: data)
    }
}
