import SwiftUI

struct WorkflowEditorView: View {
    @EnvironmentObject private var store: AppStore
    @State private var showingLibrary = false
    @State private var selectedNode: WorkflowNode?
    @State private var connectFrom: UUID?
    @State private var dragPoint: CGPoint?
    @State private var zoom: CGFloat = 1.0
    @State private var lastZoom: CGFloat = 1.0
    @State private var dragStartPositions: [UUID: CGPoint] = [:]

    private let canvasSize = CGSize(width: 2400, height: 1600)
    private let minZoom: CGFloat = 0.55
    private let maxZoom: CGFloat = 1.65

    var body: some View {
        NavigationStack {
            Group {
                if let project = store.selectedProject {
                    GeometryReader { proxy in
                        if proxy.size.width > 720 {
                            canvas(project: project)
                        } else {
                            listEditor(project: project)
                        }
                    }
                } else {
                    ContentUnavailableView("没有项目", systemImage: "folder.badge.plus", description: Text("先在首页新建一个工作流。"))
                }
            }
            .studioBackground()
            .navigationTitle(store.selectedProject?.title ?? "工作流")
            .toolbar {
                ToolbarItemGroup(placement: .topBarTrailing) {
                    Button { showingLibrary = true } label: { Label("添加模块", systemImage: "plus") }
                    Button("AI 选择模块") { store.autoBuildSelectedProject() }
                    Button { store.applyDefaultModelsToSelectedProject() } label: { Label("应用默认模型", systemImage: "wand.and.stars.inverse") }
                    Button { Task { await store.runSelectedProject() } } label: { Label("运行", systemImage: "play.fill") }
                }
            }
            .sheet(isPresented: $showingLibrary) { ModuleLibrarySheet() }
            .sheet(item: $selectedNode) { node in
                if let project = store.selectedProject {
                    NodeDetailView(projectID: project.id, node: node)
                }
            }
        }
    }

    private func canvas(project: WorkflowProject) -> some View {
        ScrollView([.horizontal, .vertical], showsIndicators: false) {
            ZStack(alignment: .topLeading) {
                Canvas { context, _ in
                    drawEdges(project: project, context: &context)
                }
                .frame(width: canvasSize.width, height: canvasSize.height)

                ForEach(project.nodes) { node in
                    NodeCard(
                        node: node,
                        isConnecting: connectFrom == node.id,
                        onInputTap: {
                            if let connectFrom, connectFrom != node.id {
                                store.connect(projectID: project.id, from: connectFrom, to: node.id)
                                self.connectFrom = nil
                                self.dragPoint = nil
                            }
                        },
                        onOutputTap: {
                            connectFrom = node.id
                            dragPoint = CGPoint(x: CGFloat(node.x) + 150, y: CGFloat(node.y))
                        },
                        onOutputDragChanged: { value in
                            connectFrom = node.id
                            let start = CGPoint(x: CGFloat(node.x) + 104, y: CGFloat(node.y))
                            dragPoint = CGPoint(
                                x: start.x + value.translation.width / max(zoom, 0.1),
                                y: start.y + value.translation.height / max(zoom, 0.1)
                            )
                        },
                        onOutputDragEnded: { value in
                            let start = CGPoint(x: CGFloat(node.x) + 104, y: CGFloat(node.y))
                            let endPoint = CGPoint(
                                x: start.x + value.translation.width / max(zoom, 0.1),
                                y: start.y + value.translation.height / max(zoom, 0.1)
                            )
                            if let target = targetNode(at: endPoint, in: project, excluding: node.id) {
                                store.connect(projectID: project.id, from: node.id, to: target.id)
                            }
                            connectFrom = nil
                            dragPoint = nil
                        }
                    )
                    .position(x: CGFloat(node.x), y: CGFloat(node.y))
                    .highPriorityGesture(nodeDragGesture(project: project, node: node))
                    .onTapGesture { selectedNode = node }
                    .contextMenu { nodeContextMenu(project: project, node: node) }
                }
            }
            .frame(width: canvasSize.width, height: canvasSize.height, alignment: .topLeading)
            .scaleEffect(zoom, anchor: .topLeading)
            .frame(width: canvasSize.width * zoom, height: canvasSize.height * zoom, alignment: .topLeading)
            .contentShape(Rectangle())
            .gesture(zoomGesture)
        }
        .overlay(alignment: .topLeading) {
            cleanLeftControls(project: project)
                .padding(12)
        }
        .overlay(alignment: .topTrailing) {
            cleanRightControls(project: project)
                .padding(12)
        }
        .overlay(alignment: .bottomLeading) {
            Text("右端口拖到其他模块左端口即可连线 · 支持多个模块连到同一个模块 · 双指轻捏缩放")
                .font(.caption2)
                .foregroundStyle(.white.opacity(0.72))
                .padding(.horizontal, 12)
                .padding(.vertical, 8)
                .background(.black.opacity(0.26), in: Capsule())
                .padding(12)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
    }

    private func drawEdges(project: WorkflowProject, context: inout GraphicsContext) {
        for edge in project.edges {
            guard let from = project.nodes.first(where: { $0.id == edge.from }),
                  let to = project.nodes.first(where: { $0.id == edge.to }) else { continue }
            var path = Path()
            path.move(to: CGPoint(x: CGFloat(from.x) + 104, y: CGFloat(from.y)))
            path.addCurve(
                to: CGPoint(x: CGFloat(to.x) - 104, y: CGFloat(to.y)),
                control1: CGPoint(x: CGFloat(from.x) + 168, y: CGFloat(from.y)),
                control2: CGPoint(x: CGFloat(to.x) - 168, y: CGFloat(to.y))
            )
            context.stroke(path, with: .color(.cyan.opacity(0.72)), lineWidth: 2.5)
        }
        if let connectFrom,
           let source = project.nodes.first(where: { $0.id == connectFrom }),
           let dragPoint {
            var path = Path()
            path.move(to: CGPoint(x: CGFloat(source.x) + 104, y: CGFloat(source.y)))
            path.addCurve(
                to: dragPoint,
                control1: CGPoint(x: CGFloat(source.x) + 168, y: CGFloat(source.y)),
                control2: CGPoint(x: dragPoint.x - 100, y: dragPoint.y)
            )
            context.stroke(path, with: .color(.mint.opacity(0.90)), lineWidth: 3)
        }
    }

    private func nodeDragGesture(project: WorkflowProject, node: WorkflowNode) -> some Gesture {
        DragGesture(minimumDistance: 8)
            .onChanged { value in
                let start = dragStartPositions[node.id] ?? CGPoint(x: CGFloat(node.x), y: CGFloat(node.y))
                if dragStartPositions[node.id] == nil {
                    dragStartPositions[node.id] = start
                }
                let nextX = start.x + value.translation.width / max(zoom, 0.1)
                let nextY = start.y + value.translation.height / max(zoom, 0.1)
                store.moveNode(projectID: project.id, nodeID: node.id, x: Double(nextX), y: Double(nextY), persist: false)
            }
            .onEnded { value in
                let start = dragStartPositions[node.id] ?? CGPoint(x: CGFloat(node.x), y: CGFloat(node.y))
                let nextX = start.x + value.translation.width / max(zoom, 0.1)
                let nextY = start.y + value.translation.height / max(zoom, 0.1)
                dragStartPositions[node.id] = nil
                store.moveNode(projectID: project.id, nodeID: node.id, x: Double(nextX), y: Double(nextY), persist: true)
            }
    }

    private var zoomGesture: some Gesture {
        MagnificationGesture()
            .onChanged { value in
                // 降低缩放灵敏度：只取原始捏合变化量的 28%，避免轻轻一捏就放大/缩小很多。
                let softened = 1 + (value - 1) * 0.28
                zoom = min(max(lastZoom * softened, minZoom), maxZoom)
            }
            .onEnded { _ in
                lastZoom = zoom
            }
    }

    @ViewBuilder
    private func nodeContextMenu(project: WorkflowProject, node: WorkflowNode) -> some View {
        Button("查看 / 编辑模块") { selectedNode = node }
        Button("从右侧端口开始连线") {
            connectFrom = node.id
            dragPoint = CGPoint(x: CGFloat(node.x) + 150, y: CGFloat(node.y))
        }
        if let connectFrom, connectFrom != node.id {
            Button("连接到此模块左侧端口") {
                store.connect(projectID: project.id, from: connectFrom, to: node.id)
                self.connectFrom = nil
                self.dragPoint = nil
            }
        }
        Button(role: .destructive) {
            store.removeNode(projectID: project.id, nodeID: node.id)
        } label: {
            Text("删除模块")
        }
    }

    private func cleanLeftControls(project: WorkflowProject) -> some View {
        HStack(spacing: 8) {
            Button(role: .destructive) {
                store.resetWorkflow(projectID: project.id)
            } label: {
                Label("重置", systemImage: "arrow.counterclockwise")
            }
            Button(role: .destructive) {
                store.removeAllEdges(projectID: project.id)
            } label: {
                Label("清空连线", systemImage: "link.badge.minus")
            }
        }
        .buttonStyle(.borderedProminent)
        .controlSize(.small)
    }

    private func cleanRightControls(project: WorkflowProject) -> some View {
        HStack(spacing: 8) {
            Text("缩放 \(Int(zoom * 100))%")
                .font(.caption.weight(.semibold))
                .padding(.horizontal, 10)
                .padding(.vertical, 7)
                .background(.black.opacity(0.28), in: Capsule())
            Button("1:1") {
                zoom = 1.0
                lastZoom = 1.0
            }
            Button {
                store.applyDefaultModels(to: project.id)
            } label: {
                Label("默认 API/模型", systemImage: "bolt.badge.checkmark")
            }
        }
        .buttonStyle(.bordered)
        .controlSize(.small)
    }

    private func targetNode(at point: CGPoint, in project: WorkflowProject, excluding sourceID: UUID) -> WorkflowNode? {
        project.nodes
            .filter { $0.id != sourceID }
            .min { lhs, rhs in
                let leftPortL = CGPoint(x: CGFloat(lhs.x) - 104, y: CGFloat(lhs.y))
                let leftPortR = CGPoint(x: CGFloat(rhs.x) - 104, y: CGFloat(rhs.y))
                return distance(point, leftPortL) < distance(point, leftPortR)
            }
            .flatMap { candidate in
                distance(point, CGPoint(x: CGFloat(candidate.x) - 104, y: CGFloat(candidate.y))) < 90 ? candidate : nil
            }
    }

    private func distance(_ a: CGPoint, _ b: CGPoint) -> CGFloat {
        hypot(a.x - b.x, a.y - b.y)
    }

    private func listEditor(project: WorkflowProject) -> some View {
        List {
            Section("开始模块") {
                if let start = project.nodes.first(where: { $0.kind == .start }) {
                    Button { selectedNode = start } label: {
                        Label("输入需求、上传图片、运行工作流", systemImage: start.kind.icon)
                    }
                }
            }
            Section("快速操作") {
                Button { store.applyDefaultModels(to: project.id) } label: { Label("一键应用默认 API/模型", systemImage: "bolt.badge.checkmark") }
                Button(role: .destructive) { store.resetWorkflow(projectID: project.id) } label: { Label("重置：清除所有模块", systemImage: "arrow.counterclockwise") }
                Button(role: .destructive) { store.removeAllEdges(projectID: project.id) } label: { Label("清空全部连线", systemImage: "link.badge.minus") }
            }
            Section("节点") {
                ForEach(project.nodes) { node in
                    Button { selectedNode = node } label: {
                        VStack(alignment: .leading, spacing: 4) {
                            Label(node.title, systemImage: node.kind.icon)
                            Text(node.kind.summary).font(.caption).foregroundStyle(.secondary)
                        }
                    }
                }
                .onDelete { offsets in
                    for index in offsets { store.removeNode(projectID: project.id, nodeID: project.nodes[index].id) }
                }
            }
            Section("连线") {
                if project.edges.isEmpty {
                    Text("暂无连线。iPhone 小屏建议用 iPad 横屏画布拖端口连线。")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                ForEach(project.edges) { edge in
                    Text("\(project.nodes.first(where: { $0.id == edge.from })?.title ?? "?") → \(project.nodes.first(where: { $0.id == edge.to })?.title ?? "?")")
                }
            }
        }
        .scrollContentBackground(.hidden)
    }
}

struct NodeCard: View {
    var node: WorkflowNode
    var isConnecting: Bool
    var onInputTap: () -> Void
    var onOutputTap: () -> Void
    var onOutputDragChanged: (DragGesture.Value) -> Void
    var onOutputDragEnded: (DragGesture.Value) -> Void

    var body: some View {
        HStack(spacing: 10) {
            port(title: "输入", systemImage: "arrow.down.circle.fill")
                .onTapGesture(perform: onInputTap)
            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    Image(systemName: node.kind.icon)
                    Text(node.title).font(.headline)
                }
                Text(node.kind.summary)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .lineLimit(2)
                Text(node.status.title)
                    .font(.caption2.bold())
                    .padding(.horizontal, 8)
                    .padding(.vertical, 4)
                    .background(.cyan.opacity(0.20), in: Capsule())
            }
            .frame(width: 180, alignment: .leading)
            port(title: "输出", systemImage: "arrow.up.circle.fill")
                .onTapGesture(perform: onOutputTap)
                .gesture(
                    DragGesture(minimumDistance: 0)
                        .onChanged(onOutputDragChanged)
                        .onEnded(onOutputDragEnded)
                )
        }
        .liquidGlass(cornerRadius: 22, glow: isConnecting)
        .scaleEffect(isConnecting ? 1.04 : 1)
    }

    private func port(title: String, systemImage: String) -> some View {
        VStack(spacing: 3) {
            Image(systemName: systemImage)
                .font(.title3)
                .foregroundStyle(.cyan)
                .padding(6)
                .background(.black.opacity(0.24), in: Circle())
                .overlay(Circle().stroke(.cyan.opacity(0.65), lineWidth: 1.5))
            Text(title)
                .font(.caption2)
                .foregroundStyle(.secondary)
        }
    }
}
