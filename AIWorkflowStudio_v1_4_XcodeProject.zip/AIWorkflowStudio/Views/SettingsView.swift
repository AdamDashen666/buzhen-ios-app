import SwiftUI

struct SettingsView: View {
    @EnvironmentObject private var store: AppStore
    @State private var editingConfig: APIProviderConfig?
    @State private var addingConfig = false

    var body: some View {
        NavigationStack {
            Form {
                Section("多 API 与模型库") {
                    ForEach(store.apiConfigs) { config in
                        Button { editingConfig = config } label: {
                            VStack(alignment: .leading, spacing: 4) {
                                Text(config.name).font(.headline)
                                Text(config.baseURL).font(.caption).foregroundStyle(.secondary)
                                Text("模型：\(config.models.count) · 默认文本模型：\(config.defaultTextModel.isEmpty ? "未设置" : config.defaultTextModel)")
                                    .font(.caption2)
                                    .foregroundStyle(.secondary)
                                Text("接口类型：\(config.interfaceTypes.map(\.title).sorted().joined(separator: "、"))")
                                    .font(.caption2)
                                    .foregroundStyle(.secondary)
                            }
                        }
                    }
                    Button { addingConfig = true } label: { Label("添加 API 配置", systemImage: "plus.circle") }
                }

                Section("Token 总限制") {
                    Picker("限制方式", selection: $store.settings.tokenLimitMode) {
                        ForEach(TokenLimitMode.allCases) { mode in
                            Text(mode.title).tag(mode)
                        }
                    }
                    Text(store.settings.tokenLimitMode.detail)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    if store.settings.tokenLimitMode == .daily {
                        integerInput("每日 Token 总量", value: $store.settings.dailyTokenLimit, suffix: "Token")
                    }
                    if store.settings.tokenLimitMode == .singleWorkflow {
                        integerInput("单次工作流 Token 总量", value: $store.settings.singleWorkflowTokenLimit, suffix: "Token")
                    }
                    Text("每日限制和单次限制只能选一个，也可以选择不限制。Token 统计仍会记录到运行日志。")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                Section("全局默认次数") {
                    integerInput("多模型投票模型上限", value: $store.settings.maxVoteModels, suffix: "个，0 = 无限")
                    Text("0 表示不限制投票模型数量。风险：模型越多，Token 和费用越高。")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    integerInput("新模块默认最大返工次数", value: $store.settings.maxReturnCount, suffix: "次，0 = 无限")
                    Text("0 表示无限返工。建议搭配 Token 总限制或手动确认模块使用。")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                Section("外观与隐私") {
                    Toggle("使用深色 Liquid Glass 外观", isOn: $store.settings.forceDarkMode)
                    Text("默认开启，避免系统浅色模式下毛玻璃太亮、文字看不清。")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    Toggle("日志导出前默认脱敏", isOn: $store.settings.privacyModeForLogs)
                }
            }
            .scrollContentBackground(.hidden)
            .studioBackground()
            .navigationTitle("设置")
            .onDisappear(perform: sanitizeSettings)
            .sheet(isPresented: $addingConfig) { APIConfigEditorView(config: .empty, isNew: true) }
            .sheet(item: $editingConfig) { config in APIConfigEditorView(config: config, isNew: false) }
        }
    }

    private func sanitizeSettings() {
        store.settings.dailyTokenLimit = min(max(store.settings.dailyTokenLimit, 1), 100_000_000)
        store.settings.singleWorkflowTokenLimit = min(max(store.settings.singleWorkflowTokenLimit, 1), 100_000_000)
        store.settings.maxVoteModels = min(max(store.settings.maxVoteModels, 0), 999)
        store.settings.maxReturnCount = min(max(store.settings.maxReturnCount, 0), 999)
    }

    private func integerInput(_ title: String, value: Binding<Int>, suffix: String) -> some View {
        HStack {
            Text(title)
            Spacer()
            TextField(title, value: value, format: .number)
                .keyboardType(.numberPad)
                .multilineTextAlignment(.trailing)
                .frame(maxWidth: 150)
            Text(suffix)
                .font(.caption)
                .foregroundStyle(.secondary)
        }
    }
}
