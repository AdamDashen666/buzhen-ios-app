# AI Workflow Studio v1.4

SwiftUI iOS / iPadOS project.

本版修复：
- 降低画布双指缩放灵敏度。
- 清空连线、重置按钮改到画布角落，移除大说明面板。
- 重置按钮改为清除所有自定义模块，仅保留开始模块和输出模块。
- 修复节点左右拖动/轻划后飞出画布的问题。
- 拖动节点时不再每帧写入 UserDefaults，松手后再保存，改善帧率。
- 所有数字项改为直接输入，不再用加减按钮。
- 工作流页新增一键应用默认 API/模型。
- 运行引擎按用户连线执行，未连接模块不会被误运行。

打开 `AIWorkflowStudio.xcodeproj`，设置 Team / Bundle ID 后运行。
