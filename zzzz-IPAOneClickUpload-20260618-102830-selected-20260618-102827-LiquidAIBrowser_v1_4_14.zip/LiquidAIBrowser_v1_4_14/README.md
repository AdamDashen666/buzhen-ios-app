# Liquid AI Browser v1.4.14

本版本根据外部静态检查建议，重点修复 Requirements 合规缺口和长任务稳定性。

## v1.4.14 重点

- 设置页改为独立页面，不再是 sheet。
- 任务完成后自动生成 PDF，但不自动弹分享窗口。
- 截图改为文件存储，避免 session JSON 暴涨。
- collectState 增强 readyState / activeElement / focused / disabled / style 等字段。
- 新增 reload / forward / stopLoading / 原生 wait。
- 失败任务折叠后仍显示失败原因。
- 新增清除失败任务、清除停止任务。
- 移除系统 alert / 清空确认 dialog，改用 toast。
- 后台任务切换页面不再抢占用户当前 UI。
- countUp 正计时不会自动结束。
- 保存 AI 原始计划、重规划历史，并写入 PDF。

# Liquid AI Browser v1.4.11

## v1.4.11 重点

- 修复多网站测试任务中 AI 容易“忘记已验证结果”的问题。
- 新增结构化 findings/事实记忆：每轮可记录平台/网站结论、状态、证据和 URL。
- 最终验收改为读取所有参与页面状态，不再只看当前活动页面。
- 修复计时器结束后重复显示“任务 worker 已启动”的体验问题。
- 修复步骤截图被重复缓存的问题。
- 修复 PDF 已选择关键截图但实际仍输出全部截图的问题。
- PDF 报告继续使用 720p 等比例截图，最多 10 张关键图，日志最多 120 行；完整日志仍在任务卡复制。

## 使用建议

对“比较多个网站/多个页面”的任务，AI 会记录每个对象的结论，最终报告会列出事实记忆。
