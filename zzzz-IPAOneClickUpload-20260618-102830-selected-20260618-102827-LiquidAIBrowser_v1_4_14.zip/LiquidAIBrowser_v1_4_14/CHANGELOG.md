# Changelog

## v1.4.14

- 设置页从 sheet 改为独立主页面。
- 任务完成后自动生成 PDF，任务卡可打开/分享已生成报告。
- 截图从内存/session JSON 改为文件存储，避免长任务 session 暴涨。
- `collectState()` 增强 readyState、isLoading、activeElement、focused、disabled、style、inputButtonSummary。
- 新增原生 `reload / forward / stopLoading / wait / back` 动作处理。
- `wait` 改为 Swift 原生等待，不再由 JS 立即返回。
- 失败任务折叠状态也显示失败原因。
- 新增清除失败任务、清除停止任务。
- 移除主界面系统 alert 和清空确认 dialog，改为 toast/banner。
- AI 后台任务切换页面不再抢占用户当前 UI。
- countUp 正计时器不再自动结束。
- 保存 AI 原始计划、重规划历史、raw plan response。
- PDF 增加原始计划、重规划历史、分组/页面信息、截图大小统计；截图显示高度提升。
- Agent 对页面读取和截图增加超时保护。

## v1.4.13

- 取消步骤截图数量限制。
- 增强 AI JSON 容错，减少“格式不稳定”导致长时间等待。
