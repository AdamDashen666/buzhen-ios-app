# LiquidAIBrowser v1.4.14 Project Index

## Version
- Marketing Version: 1.4.14
- Build: 21

## Main source files
- `LiquidAIBrowserApp.swift`: App entry.
- `ContentView.swift`: Main route, browser layout, settings page, task overview page, toast banner.
- `BrowserStore.swift`: Groups, tabs, tasks, timers, PDF generation, session persistence.
- `BrowserModels.swift`: Data models, task snapshots, plan history, findings.
- `AgentEngine.swift`: Agent loop, planning, decisions, verification, action execution.
- `WebViewPool.swift`: WKWebView pool, JS bridge, DOM reading, actions, screenshots.
- `PDFReportExporter.swift`: PDF report generation.
- `Panels.swift`: New task, task cards, settings, task management panels.
- `AIClient.swift`: OpenAI-compatible API client and JSON extraction.
- `AISettings.swift`: API settings, presets, Keychain.
- `NotificationService.swift`: Local notifications.
- `WindowSizingSupport.swift`: Stage Manager/window sizing support.

## Important reports
- `QA_V14_14_STABILITY_COMPLIANCE_FIX_REPORT.md`: This version's fix report.
- `AI_REVIEW_REQUIREMENTS.md`: Current requirements document.
- `QA_CHECK_REPORT.md`: Prior static check report.
- `QA_FIX_REPORT.md`: Prior fix summary.

## Key v1.4.14 changes
- Independent settings page.
- Auto PDF report after task completion.
- Screenshot file storage under Application Support.
- Enhanced DOM/page state reading.
- Native wait/reload/forward/stopLoading/back.
- Clear failed/stopped task actions.
- No system alert/confirmation dialog for normal operations.
- Background task no longer hijacks current UI.
- Count-up timer fixed.
- Original plan and plan history stored.
