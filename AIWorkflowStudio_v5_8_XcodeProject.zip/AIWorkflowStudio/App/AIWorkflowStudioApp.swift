import SwiftUI

@main
struct AIWorkflowStudioApp: App {
    @StateObject private var store = AppStore()

    var body: some Scene {
        WindowGroup {
            RootTabView()
                .environmentObject(store)
                .preferredColorScheme(store.settings.forceDarkMode ? .dark : nil)
        }
    }
}
