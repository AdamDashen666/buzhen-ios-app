import Foundation
import SwiftUI

struct AppAlert: Identifiable, Hashable {
    let id = UUID()
    var title: String
    var message: String
}

private enum WorkflowImportError: LocalizedError {
    case noDataRead
    case noWorkflowJSONInArchive
    case unsupportedZipCompression(String)
    case invalidWorkflowJSON

    var errorDescription: String? {
        switch self {
        case .noDataRead:
            return "没有从所选文件读取到内容。请确认文件仍在本机/iCloud 已下载，然后重试。"
        case .noWorkflowJSONInArchive:
            return "这个 ZIP 里没有找到可导入的工作流 JSON。请导入首页导出的工作流 JSON，或包含 workflow/project JSON 的 ZIP。"
        case .unsupportedZipCompression(let name):
            return "ZIP 条目使用了当前轻量导入器暂不支持的压缩方式：\(name)。请先解压后选择里面的 .json 文件。"
        case .invalidWorkflowJSON:
            return "文件不是有效的 AI Workflow Studio 工作流 JSON。"
        }
    }
}

@MainActor
final class AppStore: ObservableObject {
    @Published var projects: [WorkflowProject] = []
    @Published var apiConfigs: [APIProviderConfig] = [] { didSet { saveAPIConfigs() } }
    @Published var runRecords: [RunRecord] = [] { didSet { saveRunRecords() } }
    @Published var snapshots: [VersionSnapshot] = [] { didSet { saveSnapshots() } }
    @Published var settings: AppSettings = AppSettings() { didSet { saveSettings() } }
    @Published var selectedProjectID: UUID?
    @Published var activeRunID: UUID?
    @Published var isAutoBuilding = false
    @Published var autoBuildProgress: Double = 0
    @Published var autoBuildMessage = ""
    @Published var appAlert: AppAlert?
    @Published var cacheSizeText: String = "计算中"

    let aiClient = AIClient()
    let engine = WorkflowEngine()
    private var activeRunTask: Task<Void, Never>?
    private var runWatchdogTask: Task<Void, Never>?
    private var undoStacks: [UUID: [WorkflowProject]] = [:]
    private var redoStacks: [UUID: [WorkflowProject]] = [:]

    init() {
        loadAll()
        if migrateDuplicateAPIConfigs() { saveAPIConfigs() }
        if migrateLegacyModuleTitles() { saveProjects() }
        if projects.isEmpty {
            let starter = WorkflowProject.blank(title: "AI 工作流项目")
            projects = [starter]
            selectedProjectID = starter.id
            saveProjects()
        } else {
            selectedProjectID = projects.first?.id
        }
        refreshCacheSize()
    }

    var selectedProject: WorkflowProject? {
        guard let selectedProjectID else { return projects.first }
        return projects.first(where: { $0.id == selectedProjectID }) ?? projects.first
    }

    var selectedProjectRunRecords: [RunRecord] {
        guard let id = selectedProject?.id else { return [] }
        return runRecords.filter { $0.projectID == id }
    }

    var selectedProjectSnapshots: [VersionSnapshot] {
        guard let id = selectedProject?.id else { return [] }
        return snapshots.filter { $0.projectID == id }
    }

    var selectedProjectActiveRun: RunRecord? {
        guard let projectID = selectedProject?.id else { return nil }
        if let id = activeRunID, let run = runRecords.first(where: { $0.id == id && $0.projectID == projectID }) { return run }
        return runRecords.first(where: { $0.projectID == projectID })
    }

    var canUndoSelectedProject: Bool {
        guard let id = selectedProject?.id else { return false }
        return !(undoStacks[id]?.isEmpty ?? true)
    }

    var canRedoSelectedProject: Bool {
        guard let id = selectedProject?.id else { return false }
        return !(redoStacks[id]?.isEmpty ?? true)
    }

    private func pushUndoSnapshot(projectID: UUID) {
        guard let project = projects.first(where: { $0.id == projectID }) else { return }
        var stack = undoStacks[projectID] ?? []
        stack.append(project)
        if stack.count > 80 { stack.removeFirst(stack.count - 80) }
        undoStacks[projectID] = stack
        redoStacks[projectID] = []
    }

    func undoSelectedProject() {
        guard let projectID = selectedProject?.id,
              var undo = undoStacks[projectID],
              let previous = undo.popLast(),
              let index = projects.firstIndex(where: { $0.id == projectID }) else { return }
        var redo = redoStacks[projectID] ?? []
        redo.append(projects[index])
        redoStacks[projectID] = redo
        undoStacks[projectID] = undo
        projects[index] = previous
        saveProjects()
    }

    func redoSelectedProject() {
        guard let projectID = selectedProject?.id,
              var redo = redoStacks[projectID],
              let next = redo.popLast(),
              let index = projects.firstIndex(where: { $0.id == projectID }) else { return }
        var undo = undoStacks[projectID] ?? []
        undo.append(projects[index])
        undoStacks[projectID] = undo
        redoStacks[projectID] = redo
        projects[index] = next
        saveProjects()
    }

    func createProject(title: String = "新工作流") {
        let project = WorkflowProject.blank(title: title)
        projects.insert(project, at: 0)
        selectedProjectID = project.id
        saveProjects()
    }

    func deleteProject(_ project: WorkflowProject) {
        projects.removeAll { $0.id == project.id }
        runRecords.removeAll { $0.projectID == project.id }
        snapshots.removeAll { $0.projectID == project.id }
        if selectedProjectID == project.id { selectedProjectID = projects.first?.id }
        saveProjects()
    }

    func updateProject(_ project: WorkflowProject) {
        guard let index = projects.firstIndex(where: { $0.id == project.id }) else { return }
        var updated = project
        updated.updatedAt = Date()
        projects[index] = updated
        saveProjects()
    }

    func renameProject(projectID: UUID, title: String) {
        let trimmed = title.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else {
            appAlert = AppAlert(title: "不能重命名", message: "工作流名称不能为空。")
            return
        }
        guard let index = projects.firstIndex(where: { $0.id == projectID }) else { return }
        pushUndoSnapshot(projectID: projectID)
        projects[index].title = trimmed
        projects[index].updatedAt = Date()
        saveProjects()
    }

    func updatePrompt(projectID: UUID, prompt: String, autoSelect: Bool) {
        guard var project = projects.first(where: { $0.id == projectID }) else { return }
        project.userPrompt = prompt
        project.autoSelectModules = autoSelect
        updateProject(project)
    }

    func autoBuildSelectedProject() {
        startAutoBuildSelectedProject()
    }

    func startAutoBuildSelectedProject() {
        guard let project = selectedProject else { return }
        let trimmed = project.userPrompt.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else {
            appAlert = AppAlert(title: "需要先填写提示词", message: "请打开开始模块，填写这次工作流要完成的任务/要求，然后再使用 AI 自动选择模块。")
            return
        }

        Task { [weak self] in
            await self?.autoBuildSelectedProjectWithAI(projectID: project.id)
        }
    }

    private func autoBuildSelectedProjectWithAI(projectID: UUID) async {
        guard var project = projects.first(where: { $0.id == projectID }) else { return }
        isAutoBuilding = true
        autoBuildProgress = 0.08
        autoBuildMessage = "正在读取开始模块提示词"
        defer {
            isAutoBuilding = false
            autoBuildProgress = 0
            autoBuildMessage = ""
        }

        var preferredKinds: [WorkflowNodeKind]? = nil
        autoBuildProgress = 0.22
        autoBuildMessage = "正在调用默认文本模型规划模块"

        if let resolved = defaultTextResolution(),
           let config = apiConfigs.first(where: { $0.id == resolved.providerID }),
           let apiKey = try? KeychainService.read(account: config.keychainAccount),
           !apiKey.isEmpty {
            do {
                let prompt = WorkflowAutoBuilder.aiPlannerPrompt(for: project)
                let response = try await aiClient.completeText(
                    baseURL: config.baseURL,
                    apiKey: apiKey,
                    model: resolved.modelID,
                    messages: [AIMessage(role: "system", content: "你是工作流架构师，只输出适合的模块类型列表。"), AIMessage(role: "user", content: prompt)],
                    maxTokens: 900,
                    temperature: 0.2,
                    timeoutSeconds: 90
                )
                preferredKinds = WorkflowAutoBuilder.parseKinds(from: response.text)
                autoBuildProgress = 0.72
                autoBuildMessage = "AI 已返回模块方案，正在生成连线"
            } catch {
                appAlert = AppAlert(title: "AI 自动选择失败，已使用本地规则", message: error.localizedDescription)
                preferredKinds = nil
            }
        } else {
            appAlert = AppAlert(title: "未配置默认文本模型", message: "已使用本地规则生成工作流。要让 AI 根据提示词选择模块，请先在设置页配置全局默认文本模型。")
        }

        pushUndoSnapshot(projectID: project.id)
        project = WorkflowAutoBuilder.build(from: project, preferredKinds: preferredKinds)
        applyDefaultModels(to: &project)
        updateProject(project)
        autoBuildProgress = 1
        autoBuildMessage = "工作流已生成"
    }

    func addNode(_ kind: WorkflowNodeKind, to projectID: UUID, near preferredPoint: CGPoint? = nil) {
        guard var project = projects.first(where: { $0.id == projectID }) else { return }
        pushUndoSnapshot(projectID: projectID)
        let point = nextVisiblePoint(for: project, preferredPoint: preferredPoint)
        let title = nextModuleTitle(base: kind.title, existingNodes: project.nodes)
        var node = WorkflowNode(kind: kind, title: title, x: Double(point.x), y: Double(point.y))
        node.prompt = kind == .custom ? "" : kind.defaultPrompt
        node.retryLimit = settings.maxReturnCount
        node.maxReturnCount = settings.maxReturnCount
        if kind == .codeWorker { node.timeoutSeconds = 180 }
        applyDefaultModel(to: &node)
        project.nodes.append(node)
        updateProject(project)
    }

    private func nextVisiblePoint(for project: WorkflowProject, preferredPoint: CGPoint? = nil) -> CGPoint {
        if let preferredPoint {
            let offset = CGFloat(project.nodes.count % 5) * 26
            return CGPoint(x: max(preferredPoint.x + offset, 160), y: max(preferredPoint.y + offset, 160))
        }
        let count = CGFloat(project.nodes.count)
        let x = 220 + (count.truncatingRemainder(dividingBy: 4)) * 260
        let y = 220 + floor(count / 4) * 170
        return CGPoint(x: min(max(x, 160), 1100), y: min(max(y, 160), 760))
    }

    private func normalizedModuleBaseTitle(_ title: String, fallback: String) -> String {
        var base = title.replacingOccurrences(of: " 副本", with: "")
            .trimmingCharacters(in: .whitespacesAndNewlines)
        let parts = base.split(separator: " ")
        if let last = parts.last, Int(last) != nil, parts.count > 1 {
            base = parts.dropLast().joined(separator: " ")
        }
        return base.isEmpty ? fallback : base
    }

    private func nextModuleTitle(base: String, existingNodes: [WorkflowNode]) -> String {
        var usedNumbers = Set<Int>()
        for node in existingNodes {
            let title = node.title.trimmingCharacters(in: .whitespacesAndNewlines)
            if title == base {
                usedNumbers.insert(1)
                continue
            }
            guard title.hasPrefix(base + " ") else { continue }
            let suffix = title.dropFirst(base.count + 1)
            if let number = Int(suffix) {
                usedNumbers.insert(number)
            }
        }
        if !usedNumbers.contains(1) { return base }
        var number = 2
        while usedNumbers.contains(number) { number += 1 }
        return "\(base) \(number)"
    }

    func removeNode(projectID: UUID, nodeID: UUID) {
        guard var project = projects.first(where: { $0.id == projectID }) else { return }
        pushUndoSnapshot(projectID: projectID)
        project.nodes.removeAll { $0.id == nodeID && $0.kind != .start && $0.kind != .output }
        project.edges.removeAll { $0.from == nodeID || $0.to == nodeID }
        updateProject(project)
    }

    func duplicateNode(projectID: UUID, nodeID: UUID) -> UUID? {
        guard var project = projects.first(where: { $0.id == projectID }),
              let original = project.nodes.first(where: { $0.id == nodeID }),
              original.kind != .start,
              original.kind != .output else { return nil }
        pushUndoSnapshot(projectID: projectID)
        var copy = original
        copy.id = UUID()
        let baseTitle = normalizedModuleBaseTitle(original.title, fallback: original.kind.title)
        copy.title = nextModuleTitle(base: baseTitle, existingNodes: project.nodes)
        copy.x += 34
        copy.y += 34
        copy.status = .waiting
        copy.lastOutput = ""
        project.nodes.append(copy)
        updateProject(project)
        return copy.id
    }

    func pasteNode(_ node: WorkflowNode, to projectID: UUID, near preferredPoint: CGPoint? = nil) -> UUID? {
        guard var project = projects.first(where: { $0.id == projectID }) else { return nil }
        pushUndoSnapshot(projectID: projectID)
        var copy = node
        copy.id = UUID()
        let baseTitle = normalizedModuleBaseTitle(node.title, fallback: node.kind.title)
        copy.title = nextModuleTitle(base: baseTitle, existingNodes: project.nodes)
        if let preferredPoint {
            copy.x = Double(max(preferredPoint.x, 160))
            copy.y = Double(max(preferredPoint.y, 160))
        } else {
            copy.x += 42
            copy.y += 42
        }
        copy.status = .waiting
        copy.lastOutput = ""
        project.nodes.append(copy)
        updateProject(project)
        return copy.id
    }

    func updateNode(_ node: WorkflowNode, in projectID: UUID) {
        guard var project = projects.first(where: { $0.id == projectID }) else { return }
        guard let index = project.nodes.firstIndex(where: { $0.id == node.id }) else { return }
        pushUndoSnapshot(projectID: projectID)
        project.nodes[index] = node
        updateProject(project)
    }

    func moveNode(projectID: UUID, nodeID: UUID, x: Double, y: Double, persist: Bool = true) {
        guard let projectIndex = projects.firstIndex(where: { $0.id == projectID }) else { return }
        guard let nodeIndex = projects[projectIndex].nodes.firstIndex(where: { $0.id == nodeID }) else { return }
        if persist { pushUndoSnapshot(projectID: projectID) }
        let clampedX = max(x, 120)
        let clampedY = max(y, 100)
        objectWillChange.send()
        projects[projectIndex].nodes[nodeIndex].x = clampedX
        projects[projectIndex].nodes[nodeIndex].y = clampedY
        projects[projectIndex].updatedAt = Date()
        if persist { saveProjects() }
    }

    func moveNodes(projectID: UUID, positions: [UUID: CGPoint], persist: Bool = true) {
        guard let projectIndex = projects.firstIndex(where: { $0.id == projectID }) else { return }
        if persist { pushUndoSnapshot(projectID: projectID) }
        objectWillChange.send()
        for (id, point) in positions {
            guard let nodeIndex = projects[projectIndex].nodes.firstIndex(where: { $0.id == id }) else { continue }
            projects[projectIndex].nodes[nodeIndex].x = Double(max(point.x, 120))
            projects[projectIndex].nodes[nodeIndex].y = Double(max(point.y, 100))
        }
        projects[projectIndex].updatedAt = Date()
        if persist { saveProjects() }
    }

    func removeNodes(projectID: UUID, nodeIDs: Set<UUID>) {
        guard var project = projects.first(where: { $0.id == projectID }) else { return }
        let removable = Set(project.nodes.filter { nodeIDs.contains($0.id) && $0.kind != .start && $0.kind != .output }.map(\.id))
        guard !removable.isEmpty else { return }
        pushUndoSnapshot(projectID: projectID)
        project.nodes.removeAll { removable.contains($0.id) }
        project.edges.removeAll { removable.contains($0.from) || removable.contains($0.to) }
        updateProject(project)
    }

    func pasteNodes(_ nodes: [WorkflowNode], to projectID: UUID, near preferredPoint: CGPoint? = nil) -> Set<UUID> {
        guard var project = projects.first(where: { $0.id == projectID }) else { return [] }
        let copyable = nodes.filter { $0.kind != .start && $0.kind != .output }
        guard !copyable.isEmpty else { return [] }
        pushUndoSnapshot(projectID: projectID)
        let minX = copyable.map(\.x).min() ?? 0
        let minY = copyable.map(\.y).min() ?? 0
        let anchor = preferredPoint
        var newIDs = Set<UUID>()
        for original in copyable {
            var copy = original
            copy.id = UUID()
            let baseTitle = normalizedModuleBaseTitle(original.title, fallback: original.kind.title)
            copy.title = nextModuleTitle(base: baseTitle, existingNodes: project.nodes)
            if let anchor {
                copy.x = Double(anchor.x) + (original.x - minX)
                copy.y = Double(anchor.y) + (original.y - minY)
            } else {
                copy.x = original.x + 52
                copy.y = original.y + 52
            }
            copy.status = .waiting
            copy.lastOutput = ""
            newIDs.insert(copy.id)
            project.nodes.append(copy)
        }
        updateProject(project)
        return newIDs
    }


    func arrangeWorkflow(projectID: UUID, around center: CGPoint) {
        guard var project = projects.first(where: { $0.id == projectID }) else { return }
        pushUndoSnapshot(projectID: projectID)

        let originalNodes = project.nodes
        guard !originalNodes.isEmpty else { return }

        // v4.8：整理时先记录真实连线，再只重排模块，最后按记录重新生成连线。
        // 这样不会因为整理位置时节点顺序变化、旧边顺序混乱或无效边残留，导致线看起来乱连。
        let validNodeIDs = Set(originalNodes.map(\.id))
        let edgeSnapshots = project.edges
            .filter { validNodeIDs.contains($0.from) && validNodeIDs.contains($0.to) && $0.from != $0.to }
            .map { (id: $0.id, from: $0.from, to: $0.to, condition: $0.condition) }

        let nodeOrder = Dictionary(uniqueKeysWithValues: originalNodes.enumerated().map { ($0.element.id, $0.offset) })
        let nodeByID = Dictionary(uniqueKeysWithValues: originalNodes.map { ($0.id, $0) })

        func kindPriority(_ kind: WorkflowNodeKind) -> Int {
            switch kind {
            case .start: return 0
            case .planner, .autoGraph: return 1
            case .dispatcher: return 2
            case .imageUnderstanding: return 3
            case .codeWorker, .worker, .custom, .autoFixer: return 4
            case .codeReviewer, .qualityReviewer, .visualReviewer: return 5
            case .optimizer, .multiModelVote: return 6
            case .aggregator: return 7
            case .formatter: return 8
            case .filePackager: return 9
            case .logger, .versionSnapshot: return 10
            case .humanApproval: return 11
            case .imageGenerator: return 12
            case .output: return 99
            }
        }

        func conditionPriority(_ condition: EdgeCondition) -> Int {
            switch condition {
            case .always: return 0
            case .passed: return 1
            case .scoreHigh: return 2
            case .failed: return 3
            case .scoreLow: return 4
            }
        }

        // 正向执行边用于排序；返工边保留但不参与主层级，否则容易把布局拉成巨大回环。
        let forwardEdges = edgeSnapshots.filter { snapshot in
            snapshot.condition == .always || snapshot.condition == .passed || snapshot.condition == .scoreHigh
        }

        var outgoing: [UUID: [UUID]] = [:]
        var incomingCount: [UUID: Int] = Dictionary(uniqueKeysWithValues: originalNodes.map { ($0.id, 0) })
        for edge in forwardEdges {
            outgoing[edge.from, default: []].append(edge.to)
            incomingCount[edge.to, default: 0] += 1
        }
        for key in outgoing.keys {
            outgoing[key]?.sort {
                let lhs = nodeByID[$0]
                let rhs = nodeByID[$1]
                let lp = lhs.map { kindPriority($0.kind) } ?? 50
                let rp = rhs.map { kindPriority($0.kind) } ?? 50
                if lp != rp { return lp < rp }
                return (nodeOrder[$0] ?? 0) < (nodeOrder[$1] ?? 0)
            }
        }

        // 稳定拓扑顺序：从开始模块和无入度模块开始，保持用户创建顺序和模块类型顺序。
        var queue = originalNodes
            .filter { $0.kind == .start || incomingCount[$0.id, default: 0] == 0 }
            .sorted {
                let lp = kindPriority($0.kind)
                let rp = kindPriority($1.kind)
                if lp != rp { return lp < rp }
                return (nodeOrder[$0.id] ?? 0) < (nodeOrder[$1.id] ?? 0)
            }
            .map(\.id)

        if queue.isEmpty, let first = originalNodes.first?.id { queue = [first] }
        var visited = Set<UUID>()
        var orderedIDs: [UUID] = []
        var remainingIncoming = incomingCount
        var cursor = 0
        while cursor < queue.count {
            let current = queue[cursor]
            cursor += 1
            guard !visited.contains(current) else { continue }
            visited.insert(current)
            orderedIDs.append(current)
            for target in outgoing[current, default: []] {
                remainingIncoming[target, default: 0] -= 1
                if remainingIncoming[target, default: 0] <= 0 && !visited.contains(target) {
                    queue.append(target)
                }
            }
        }
        for node in originalNodes.sorted(by: {
            let lp = kindPriority($0.kind)
            let rp = kindPriority($1.kind)
            if lp != rp { return lp < rp }
            return (nodeOrder[$0.id] ?? 0) < (nodeOrder[$1.id] ?? 0)
        }) where !visited.contains(node.id) {
            orderedIDs.append(node.id)
            visited.insert(node.id)
        }
        let arrangedOrder = Dictionary(uniqueKeysWithValues: orderedIDs.enumerated().map { ($0.element, $0.offset) })

        // 层级仍按最长正向路径计算，但排序使用 arrangedOrder，避免按名字排序。
        var level: [UUID: Int] = Dictionary(uniqueKeysWithValues: originalNodes.map { ($0.id, 0) })
        for id in orderedIDs {
            let currentLevel = level[id, default: 0]
            for target in outgoing[id, default: []] {
                level[target] = max(level[target, default: 0], currentLevel + 1)
            }
        }
        let nonOutputMax = level.filter { (nodeByID[$0.key]?.kind ?? .worker) != .output }.map(\.value).max() ?? 0
        for node in originalNodes where node.kind == .output {
            level[node.id] = max(level[node.id, default: 0], nonOutputMax + 1)
        }

        var groups: [Int: [WorkflowNode]] = [:]
        for node in originalNodes {
            groups[level[node.id, default: 0], default: []].append(node)
        }
        for key in groups.keys {
            groups[key]?.sort { lhs, rhs in
                let lhsUpstream = edgeSnapshots
                    .filter { $0.to == lhs.id && ($0.condition == .always || $0.condition == .passed || $0.condition == .scoreHigh) }
                    .compactMap { arrangedOrder[$0.from] }
                    .min() ?? Int.max
                let rhsUpstream = edgeSnapshots
                    .filter { $0.to == rhs.id && ($0.condition == .always || $0.condition == .passed || $0.condition == .scoreHigh) }
                    .compactMap { arrangedOrder[$0.from] }
                    .min() ?? Int.max
                if lhsUpstream != rhsUpstream { return lhsUpstream < rhsUpstream }
                let lp = kindPriority(lhs.kind)
                let rp = kindPriority(rhs.kind)
                if lp != rp { return lp < rp }
                return (arrangedOrder[lhs.id] ?? 0) < (arrangedOrder[rhs.id] ?? 0)
            }
        }

        let sortedLevels = groups.keys.sorted()
        let columnWidth: CGFloat = 410
        let rowHeight: CGFloat = 190
        let rowBandGap: CGFloat = 230
        let horizontalMargin: CGFloat = 220
        let verticalMargin: CGFloat = 180

        // v5.4：一行最多 7 层，减少“正向线被迫换行”导致的大量回绕。
        // 典型结构：开始/计划/分配/工作者/检查者/汇总/输出，刚好能在一行内完成。
        let maxColumnsPerRow = 7
        var rowsOfLevels: [[Int]] = []
        var levelIndex = 0
        while levelIndex < sortedLevels.count {
            let end = min(levelIndex + maxColumnsPerRow, sortedLevels.count)
            rowsOfLevels.append(Array(sortedLevels[levelIndex..<end]))
            levelIndex = end
        }
        if rowsOfLevels.isEmpty { rowsOfLevels = [[]] }

        let rowHeights = rowsOfLevels.map { row -> CGFloat in
            let maxRows = max(row.map { groups[$0]?.count ?? 1 }.max() ?? 1, 1)
            return CGFloat(maxRows - 1) * rowHeight + 250
        }
        let totalHeight = rowHeights.reduce(0, +) + CGFloat(max(0, rowHeights.count - 1)) * rowBandGap
        var currentTop = max(center.y - totalHeight / 2, verticalMargin)

        var nodeMap = Dictionary(uniqueKeysWithValues: project.nodes.map { ($0.id, $0) })
        for (rowIndex, rowLevels) in rowsOfLevels.enumerated() {
            let rowHeightTotal = rowHeights.indices.contains(rowIndex) ? rowHeights[rowIndex] : 250
            let rowWidth = CGFloat(max(rowLevels.count - 1, 0)) * columnWidth
            let startX = max(center.x - rowWidth / 2, horizontalMargin)

            for (columnIndex, levelKey) in rowLevels.enumerated() {
                let columnNodes = groups[levelKey] ?? []
                let columnHeight = CGFloat(max(columnNodes.count - 1, 0)) * rowHeight
                let startY = currentTop + max(70, (rowHeightTotal - columnHeight) / 2)
                for (nodeIndex, node) in columnNodes.enumerated() {
                    var updated = node
                    updated.x = Double(startX + CGFloat(columnIndex) * columnWidth)
                    updated.y = Double(startY + CGFloat(nodeIndex) * rowHeight)
                    nodeMap[node.id] = updated
                }
            }
            currentTop += rowHeightTotal + rowBandGap
        }

        project.nodes = project.nodes.compactMap { nodeMap[$0.id] }

        // 按整理后的模块顺序重新生成边，并去重。这里不改变连接关系，只刷新边顺序和移除无效残留。
        let sortedSnapshots = edgeSnapshots.sorted { lhs, rhs in
            let lf = arrangedOrder[lhs.from] ?? Int.max
            let rf = arrangedOrder[rhs.from] ?? Int.max
            if lf != rf { return lf < rf }
            let lt = arrangedOrder[lhs.to] ?? Int.max
            let rt = arrangedOrder[rhs.to] ?? Int.max
            if lt != rt { return lt < rt }
            return conditionPriority(lhs.condition) < conditionPriority(rhs.condition)
        }
        var seen = Set<String>()
        var rebuiltEdges: [WorkflowEdge] = []
        for edge in sortedSnapshots {
            let key = "\(edge.from.uuidString)-\(edge.to.uuidString)-\(edge.condition.rawValue)"
            guard !seen.contains(key) else { continue }
            seen.insert(key)
            rebuiltEdges.append(WorkflowEdge(id: edge.id, from: edge.from, to: edge.to, condition: edge.condition))
        }
        project.edges = rebuiltEdges

        updateProject(project)
    }

    func connect(projectID: UUID, from: UUID, to: UUID, condition: EdgeCondition = .always) {
        guard var project = projects.first(where: { $0.id == projectID }) else { return }
        guard from != to else { return }
        guard project.nodes.first(where: { $0.id == from })?.kind != .output else { return }
        guard !project.edges.contains(where: { $0.from == from && $0.to == to && $0.condition == condition }) else { return }
        pushUndoSnapshot(projectID: projectID)
        project.edges.append(WorkflowEdge(from: from, to: to, condition: condition))
        updateProject(project)
    }

    func removeEdge(projectID: UUID, edgeID: UUID) {
        guard var project = projects.first(where: { $0.id == projectID }) else { return }
        pushUndoSnapshot(projectID: projectID)
        project.edges.removeAll { $0.id == edgeID }
        updateProject(project)
    }

    func removeAllEdges(projectID: UUID) {
        guard var project = projects.first(where: { $0.id == projectID }) else { return }
        pushUndoSnapshot(projectID: projectID)
        project.edges.removeAll()
        updateProject(project)
    }

    func resetWorkflow(projectID: UUID) {
        guard var project = projects.first(where: { $0.id == projectID }) else { return }
        pushUndoSnapshot(projectID: projectID)
        let blank = WorkflowProject.blank(title: project.title)
        project.nodes = blank.nodes
        project.edges = []
        project.resources = []
        updateProject(project)
    }

    func applyDefaultModelsToSelectedProject() {
        guard let project = selectedProject else { return }
        applyDefaultModels(to: project.id)
    }

    func applyDefaultModels(to projectID: UUID) {
        guard let projectIndex = projects.firstIndex(where: { $0.id == projectID }) else { return }
        pushUndoSnapshot(projectID: projectID)
        objectWillChange.send()
        for nodeIndex in projects[projectIndex].nodes.indices {
            let kind = projects[projectIndex].nodes[nodeIndex].kind
            guard kind != .start && kind != .output else { continue }
            guard let resolved = resolvedGlobalDefault(for: kind) else { continue }
            projects[projectIndex].nodes[nodeIndex].providerID = resolved.providerID
            projects[projectIndex].nodes[nodeIndex].modelID = resolved.modelID
        }
        projects[projectIndex].updatedAt = Date()
        saveProjects()
    }

    func addAPIConfig(_ config: APIProviderConfig, apiKey: String) {
        var newConfig = config
        if apiConfigs.contains(where: { $0.id == newConfig.id }) {
            newConfig.id = UUID()
        }
        if newConfig.keychainAccount.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || apiConfigs.contains(where: { $0.keychainAccount == newConfig.keychainAccount }) {
            newConfig.keychainAccount = UUID().uuidString
        }
        newConfig.createdAt = Date()
        newConfig.updatedAt = Date()
        apiConfigs.append(newConfig)
        try? KeychainService.save(apiKey, account: newConfig.keychainAccount)
        seedGlobalDefaultsIfEmpty(providerID: newConfig.id, models: newConfig.models)
    }

    func updateAPIConfig(_ config: APIProviderConfig, apiKey: String?) {
        guard let index = apiConfigs.firstIndex(where: { $0.id == config.id }) else { return }
        var updated = config
        updated.updatedAt = Date()
        if updated.keychainAccount.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            updated.keychainAccount = UUID().uuidString
        }
        apiConfigs[index] = updated
        if let apiKey, !apiKey.isEmpty {
            try? KeychainService.save(apiKey, account: updated.keychainAccount)
        }
    }

    func deleteAPIConfig(_ config: APIProviderConfig) {
        apiConfigs.removeAll { $0.id == config.id }
        try? KeychainService.delete(account: config.keychainAccount)
    }

    func refreshModels(for config: APIProviderConfig) async throws {
        let key = try KeychainService.read(account: config.keychainAccount)
        let models = try await aiClient.fetchModels(baseURL: config.baseURL, apiKey: key)
        var updated = config
        updated.models = models
        updateAPIConfig(updated, apiKey: nil)
        seedGlobalDefaultsIfEmpty(providerID: config.id, models: models)
    }

    func refreshAllModelLists() async -> String {
        guard !apiConfigs.isEmpty else { return "没有可刷新的 API 配置。" }

        var successCount = 0
        var failureCount = 0
        var lines: [String] = []
        let snapshot = apiConfigs

        for config in snapshot {
            do {
                let key = try KeychainService.read(account: config.keychainAccount)
                let models = try await aiClient.fetchModels(baseURL: config.baseURL, apiKey: key)
                if let index = apiConfigs.firstIndex(where: { $0.id == config.id }) {
                    apiConfigs[index].models = models
                    apiConfigs[index].updatedAt = Date()
                }
                seedGlobalDefaultsIfEmpty(providerID: config.id, models: models)
                successCount += 1
                lines.append("✅ \(config.name)：刷新成功，\(models.count) 个模型")
            } catch {
                failureCount += 1
                lines.append("❌ \(config.name)：刷新失败\nBase URL：\(config.baseURL)\n错误：\(error.localizedDescription)")
            }
        }

        return "刷新全部模型完成\n成功：\(successCount) 个\n失败：\(failureCount) 个\n\n" + lines.joined(separator: "\n\n")
    }

    func seedGlobalDefaultsIfEmpty(providerID: UUID, models: [AIModelInfo]) {
        guard let first = models.first?.id else { return }
        if settings.defaultTextProviderID == nil || settings.defaultTextModelID?.isEmpty != false {
            settings.defaultTextProviderID = providerID
            settings.defaultTextModelID = first
        }
        if settings.defaultVisionProviderID == nil || settings.defaultVisionModelID?.isEmpty != false {
            settings.defaultVisionProviderID = providerID
            settings.defaultVisionModelID = models.first(where: { $0.supportsVision })?.id ?? first
        }
        if settings.defaultImageProviderID == nil || settings.defaultImageModelID?.isEmpty != false {
            settings.defaultImageProviderID = providerID
            settings.defaultImageModelID = models.first(where: { $0.supportsImageGeneration })?.id ?? first
        }
        if settings.defaultCodeProviderID == nil || settings.defaultCodeModelID?.isEmpty != false {
            settings.defaultCodeProviderID = providerID
            settings.defaultCodeModelID = first
        }
        if settings.defaultReviewerProviderID == nil || settings.defaultReviewerModelID?.isEmpty != false {
            settings.defaultReviewerProviderID = providerID
            settings.defaultReviewerModelID = first
        }
    }

    func startSelectedProjectRun() {
        guard activeRunTask == nil else { return }
        activeRunTask = Task { [weak self] in
            await self?.runSelectedProject()
            await MainActor.run {
                self?.activeRunTask = nil
                self?.stopRunWatchdog()
            }
        }
    }

    func stopActiveRun() {
        activeRunTask?.cancel()
        activeRunTask = nil
        stopRunWatchdog()
        guard let id = activeRunID, let index = runRecords.firstIndex(where: { $0.id == id }) else { return }
        runRecords[index].status = .cancelled
        runRecords[index].endedAt = Date()
        runRecords[index].currentNodeIDs = []
        runRecords[index].currentStage = "用户已停止"
        runRecords[index].diagnosticMessage = "运行已被用户手动停止。"
        runRecords[index].lastLogAt = Date()
        runRecords[index].logs.append(RunLogEntry(level: .warning, message: "用户点击停止运行"))
    }

    func runSelectedProject() async {
        guard let project = selectedProject else { return }
        let trimmed = project.userPrompt.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else {
            appAlert = AppAlert(title: "不能运行", message: "开始模块里的提示词/要求为空。请先填写任务目标，再运行工作流。")
            return
        }


        let estimate = TokenEstimator.estimate(project: project)
        if let tokenBlockMessage = tokenLimitBlockMessage(for: estimate.estimatedTotal) {
            var record = RunRecord(projectID: project.id, projectTitle: project.title, status: .failed)
            record.endedAt = Date()
            record.currentStage = "Token 限制拦截"
            record.diagnosticMessage = tokenBlockMessage
            record.logs.append(RunLogEntry(level: .error, message: tokenBlockMessage))
            runRecords.insert(record, at: 0)
            activeRunID = record.id
            return
        }

        var record = RunRecord(projectID: project.id, projectTitle: project.title)
        record.currentStage = "已创建运行任务"
        record.diagnosticMessage = "正在准备模块执行队列。"
        record.logs.append(RunLogEntry(level: .info, message: "运行记录已创建，正在交给工作流引擎。"))
        runRecords.insert(record, at: 0)
        activeRunID = record.id
        startRunWatchdog(for: record.id)

        do {
            record = try await engine.run(
                runID: record.id,
                project: project,
                apiConfigs: apiConfigs,
                settings: settings,
                aiClient: aiClient
            ) { [weak self] partial in
                Task { @MainActor in
                    self?.replaceRunRecord(partial)
                }
            }
            replaceRunRecord(record)
            saveSnapshot(project: project, output: record.output, note: "运行完成自动快照")
        } catch is CancellationError {
            var current = runRecords.first(where: { $0.id == record.id }) ?? record
            current.status = .cancelled
            current.endedAt = Date()
            current.currentNodeIDs = []
            current.currentStage = "已停止"
            current.diagnosticMessage = "运行被取消。"
            current.logs.append(RunLogEntry(level: .warning, message: "运行已停止"))
            replaceRunRecord(current)
        } catch {
            var current = runRecords.first(where: { $0.id == record.id }) ?? record
            current.status = .failed
            current.endedAt = Date()
            current.currentNodeIDs = []
            current.currentStage = "运行失败"
            current.diagnosticMessage = error.localizedDescription
            current.logs.append(RunLogEntry(level: .error, message: error.localizedDescription))
            replaceRunRecord(current)
        }
    }

    func replaceRunRecord(_ record: RunRecord) {
        var updated = record
        updated.lastLogAt = Date()
        activeRunID = updated.id
        if let index = runRecords.firstIndex(where: { $0.id == updated.id }) {
            runRecords[index] = updated
        } else {
            runRecords.insert(updated, at: 0)
        }
    }

    private func startRunWatchdog(for runID: UUID) {
        stopRunWatchdog()
        runWatchdogTask = Task { [weak self] in
            while !Task.isCancelled {
                try? await Task.sleep(nanoseconds: 10_000_000_000)
                await MainActor.run {
                    self?.tickRunWatchdog(runID: runID)
                }
            }
        }
    }

    private func stopRunWatchdog() {
        runWatchdogTask?.cancel()
        runWatchdogTask = nil
    }

    private func tickRunWatchdog(runID: UUID) {
        guard let index = runRecords.firstIndex(where: { $0.id == runID }) else { return }
        guard runRecords[index].status == .running else { return }
        let idle = Date().timeIntervalSince(runRecords[index].lastLogAt)
        guard idle > 18 else { return }
        let seconds = Int(idle)
        let current = runRecords[index].currentNodeTitle ?? "未进入模块"
        runRecords[index].currentStage = "等待中：\(current)"
        runRecords[index].diagnosticMessage = "超过 \(seconds) 秒没有新日志。可能正在等待 API 返回、网络超时或模型响应过慢；可点停止运行。"
        runRecords[index].logs.append(RunLogEntry(level: .warning, nodeTitle: runRecords[index].currentNodeTitle, message: "Watchdog：\(seconds) 秒无新日志，仍在等待 \(current)。"))
        runRecords[index].lastLogAt = Date()
    }

    func saveSnapshot(project: WorkflowProject, output: String, note: String) {
        let snapshot = VersionSnapshot(projectID: project.id, title: project.title, project: project, output: output, note: note)
        snapshots.insert(snapshot, at: 0)
    }

    private func tokenLimitBlockMessage(for estimatedTotal: Int) -> String? {
        switch settings.tokenLimitMode {
        case .none:
            return nil
        case .singleWorkflow:
            return estimatedTotal > settings.singleWorkflowTokenLimit
                ? "预估 Token 超过单次工作流限制：\(estimatedTotal) / \(settings.singleWorkflowTokenLimit)"
                : nil
        case .daily:
            let usedToday = runRecords
                .filter { Calendar.current.isDateInToday($0.startedAt) }
                .map { $0.tokenUsage.total }
                .reduce(0, +)
            let projected = usedToday + estimatedTotal
            return projected > settings.dailyTokenLimit
                ? "预估 Token 超过今日总量限制：今日已用 \(usedToday)，本次预估 \(estimatedTotal)，限制 \(settings.dailyTokenLimit)"
                : nil
        }
    }

    func applyDefaultModelIfPossible(to node: inout WorkflowNode) {
        applyDefaultModel(to: &node)
    }

    private func applyDefaultModel(to node: inout WorkflowNode) {
        guard node.kind != .start && node.kind != .output else { return }
        guard let resolved = resolvedGlobalDefault(for: node.kind) else { return }
        node.providerID = resolved.providerID
        node.modelID = resolved.modelID
    }

    private func applyDefaultModels(to project: inout WorkflowProject) {
        for index in project.nodes.indices {
            let kind = project.nodes[index].kind
            guard kind != .start && kind != .output else { continue }
            guard let resolved = resolvedGlobalDefault(for: kind) else { continue }
            project.nodes[index].providerID = resolved.providerID
            project.nodes[index].modelID = resolved.modelID
        }
    }

    private func defaultTextResolution() -> (providerID: UUID, modelID: String)? {
        guard let providerID = settings.defaultTextProviderID,
              let modelID = settings.defaultTextModelID,
              !modelID.isEmpty else { return nil }
        return (providerID, modelID)
    }

    private func resolvedGlobalDefault(for kind: WorkflowNodeKind) -> (providerID: UUID, modelID: String)? {
        let preferred: (providerID: UUID?, modelID: String?)

        if kind.requiresImageGenerationModel {
            preferred = (settings.defaultImageProviderID, settings.defaultImageModelID)
        } else if kind.requiresVisionModel {
            preferred = (settings.defaultVisionProviderID, settings.defaultVisionModelID)
        } else if kind == .codeWorker || kind == .autoFixer {
            preferred = (settings.defaultCodeProviderID, settings.defaultCodeModelID)
        } else if kind == .codeReviewer || kind == .qualityReviewer || kind == .visualReviewer {
            preferred = (settings.defaultReviewerProviderID, settings.defaultReviewerModelID)
        } else {
            preferred = (settings.defaultTextProviderID, settings.defaultTextModelID)
        }

        if let providerID = preferred.providerID,
           let modelID = preferred.modelID,
           !modelID.isEmpty,
           apiConfigs.contains(where: { $0.id == providerID }) {
            return (providerID, modelID)
        }

        guard let fallbackConfig = apiConfigs.first,
              let fallbackModel = fallbackConfig.models.first?.id else { return nil }
        return (fallbackConfig.id, fallbackModel)
    }


    func exportSelectedProjectData() -> Data? {
        guard let project = selectedProject else {
            appAlert = AppAlert(title: "无法导出", message: "当前没有可导出的工作流。")
            return nil
        }
        let package = WorkflowExportPackage(project: sanitizedProjectForExport(project))
        let encoder = JSONEncoder()
        encoder.dateEncodingStrategy = .iso8601
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        do {
            return try encoder.encode(package)
        } catch {
            appAlert = AppAlert(title: "导出失败", message: error.localizedDescription)
            return nil
        }
    }

    func exportFileNameForSelectedProject() -> String {
        let raw = selectedProject?.title.trimmingCharacters(in: .whitespacesAndNewlines) ?? "workflow"
        let cleaned = raw
            .replacingOccurrences(of: "/", with: "-")
            .replacingOccurrences(of: ":", with: "-")
            .replacingOccurrences(of: "\\", with: "-")
        return "\(cleaned.isEmpty ? "workflow" : cleaned)-workflow"
    }

    func importWorkflow(from url: URL) {
        let hasAccess = url.startAccessingSecurityScopedResource()
        defer {
            if hasAccess { url.stopAccessingSecurityScopedResource() }
        }

        do {
            let data = try coordinatedFileData(from: url)
            let workflowData = try workflowJSONDataForImport(data, suggestedFileName: url.lastPathComponent)
            try importWorkflow(from: workflowData)
        } catch {
            appAlert = AppAlert(
                title: "导入失败",
                message: "文件：\(url.lastPathComponent)\n\n\(error.localizedDescription)"
            )
        }
    }

    func importWorkflow(from data: Data) throws {
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601

        let decodedProject: WorkflowProject
        if let package = try? decoder.decode(WorkflowExportPackage.self, from: data) {
            decodedProject = package.project
        } else if let project = try? decoder.decode(WorkflowProject.self, from: data) {
            decodedProject = project
        } else {
            throw WorkflowImportError.invalidWorkflowJSON
        }

        var project = remappedImportedProject(decodedProject)
        project.title = uniqueImportedProjectTitle(project.title)
        projects.insert(project, at: 0)
        selectedProjectID = project.id
        saveProjects()
        appAlert = AppAlert(
            title: "导入完成",
            message: "已导入“\(project.title)”。API Key 不会随工作流导入；如模型不可用，请在工作流页点击“一键应用默认模型”。"
        )
    }

    private func coordinatedFileData(from url: URL) throws -> Data {
        var coordinatedError: NSError?
        var readResult: Result<Data, Error>?
        let coordinator = NSFileCoordinator(filePresenter: nil)
        coordinator.coordinate(readingItemAt: url, options: [], error: &coordinatedError) { coordinatedURL in
            do {
                readResult = .success(try Data(contentsOf: coordinatedURL))
            } catch {
                readResult = .failure(error)
            }
        }
        if let coordinatedError { throw coordinatedError }
        guard let readResult else { throw WorkflowImportError.noDataRead }
        return try readResult.get()
    }

    private func workflowJSONDataForImport(_ data: Data, suggestedFileName: String) throws -> Data {
        if !looksLikeZip(data) { return data }

        let entries = try storedZipEntries(from: data)
        let candidates = entries
            .filter { $0.name.lowercased().hasSuffix(".json") }
            .sorted { lhs, rhs in
                scoreWorkflowJSONName(lhs.name) > scoreWorkflowJSONName(rhs.name)
            }

        for candidate in candidates {
            if isImportableWorkflowJSON(candidate.data) { return candidate.data }
        }
        throw WorkflowImportError.noWorkflowJSONInArchive
    }

    private func isImportableWorkflowJSON(_ data: Data) -> Bool {
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        if (try? decoder.decode(WorkflowExportPackage.self, from: data)) != nil { return true }
        if (try? decoder.decode(WorkflowProject.self, from: data)) != nil { return true }
        return false
    }

    private func looksLikeZip(_ data: Data) -> Bool {
        data.count >= 4 && data[0] == 0x50 && data[1] == 0x4b && data[2] == 0x03 && data[3] == 0x04
    }

    private func scoreWorkflowJSONName(_ name: String) -> Int {
        let lower = name.lowercased()
        var score = 0
        if lower.contains("workflow") { score += 100 }
        if lower.contains("project") { score += 60 }
        if lower.contains("aiworkflowstudio") { score += 40 }
        if lower.hasSuffix(".json") { score += 10 }
        return score
    }

    private func storedZipEntries(from data: Data) throws -> [(name: String, data: Data)] {
        var offset = 0
        var entries: [(String, Data)] = []

        while offset + 30 <= data.count {
            let signature = readUInt32LE(data, offset)
            if signature == 0x02014b50 || signature == 0x06054b50 { break }
            guard signature == 0x04034b50 else { break }

            let method = readUInt16LE(data, offset + 8)
            let compressedSize = Int(readUInt32LE(data, offset + 18))
            let nameLength = Int(readUInt16LE(data, offset + 26))
            let extraLength = Int(readUInt16LE(data, offset + 28))
            let nameStart = offset + 30
            let nameEnd = nameStart + nameLength
            let dataStart = nameEnd + extraLength
            let dataEnd = dataStart + compressedSize
            guard nameEnd <= data.count, dataEnd <= data.count else { break }

            let nameData = data[nameStart..<nameEnd]
            let name = String(data: nameData, encoding: .utf8) ?? "unknown"

            if method == 0 {
                entries.append((name, Data(data[dataStart..<dataEnd])))
            } else if name.lowercased().hasSuffix(".json") {
                throw WorkflowImportError.unsupportedZipCompression(name)
            }

            offset = dataEnd
        }

        return entries
    }

    private func readUInt16LE(_ data: Data, _ offset: Int) -> UInt16 {
        guard offset + 1 < data.count else { return 0 }
        return UInt16(data[offset]) | (UInt16(data[offset + 1]) << 8)
    }

    private func readUInt32LE(_ data: Data, _ offset: Int) -> UInt32 {
        guard offset + 3 < data.count else { return 0 }
        return UInt32(data[offset])
            | (UInt32(data[offset + 1]) << 8)
            | (UInt32(data[offset + 2]) << 16)
            | (UInt32(data[offset + 3]) << 24)
    }

    private func sanitizedProjectForExport(_ project: WorkflowProject) -> WorkflowProject {
        var exported = project
        exported.updatedAt = Date()
        exported.nodes = exported.nodes.map { node in
            var copy = node
            copy.status = .waiting
            copy.lastOutput = ""
            return copy
        }
        exported.resources = exported.resources.map { resource in
            var copy = resource
            copy.localPath = nil
            copy.base64Preview = nil
            return copy
        }
        return exported
    }

    private func remappedImportedProject(_ project: WorkflowProject) -> WorkflowProject {
        var imported = project
        imported.id = UUID()
        imported.createdAt = Date()
        imported.updatedAt = Date()

        var nodeIDMap: [UUID: UUID] = [:]
        imported.nodes = imported.nodes.map { node in
            var copy = node
            let newID = UUID()
            nodeIDMap[node.id] = newID
            copy.id = newID
            copy.status = .waiting
            copy.lastOutput = ""
            return copy
        }
        imported.edges = imported.edges.compactMap { edge in
            guard let from = nodeIDMap[edge.from], let to = nodeIDMap[edge.to] else { return nil }
            var copy = edge
            copy.id = UUID()
            copy.from = from
            copy.to = to
            return copy
        }
        imported.resources = imported.resources.map { resource in
            var copy = resource
            copy.id = UUID()
            copy.localPath = nil
            copy.base64Preview = nil
            return copy
        }
        return imported
    }

    private func uniqueImportedProjectTitle(_ title: String) -> String {
        let base = title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? "导入的工作流" : title.trimmingCharacters(in: .whitespacesAndNewlines)
        let existing = Set(projects.map { $0.title })
        if !existing.contains(base) { return base }
        var index = 2
        while existing.contains("\(base) \(index)") { index += 1 }
        return "\(base) \(index)"
    }

    func refreshCacheSize() {
        let bytes = cacheBytes()
        cacheSizeText = ByteCountFormatter.string(fromByteCount: Int64(bytes), countStyle: .file)
    }

    func clearCache() {
        URLCache.shared.removeAllCachedResponses()
        let tmp = FileManager.default.temporaryDirectory
        if let items = try? FileManager.default.contentsOfDirectory(at: tmp, includingPropertiesForKeys: nil) {
            for item in items where item.lastPathComponent.contains("AIWorkflowStudio") || item.pathExtension.lowercased() == "zip" {
                try? FileManager.default.removeItem(at: item)
            }
        }
        refreshCacheSize()
        appAlert = AppAlert(title: "缓存已清除", message: "已清除网络缓存和临时导出文件。项目、API 配置、运行记录不会被删除。")
    }

    private func cacheBytes() -> Int {
        var total = URLCache.shared.currentDiskUsage
        let tmp = FileManager.default.temporaryDirectory
        if let items = try? FileManager.default.contentsOfDirectory(at: tmp, includingPropertiesForKeys: [.fileSizeKey]) {
            for item in items where item.lastPathComponent.contains("AIWorkflowStudio") || item.pathExtension.lowercased() == "zip" {
                let values = try? item.resourceValues(forKeys: [.fileSizeKey])
                total += values?.fileSize ?? 0
            }
        }
        return total
    }

    private func loadAll() {
        projects = Self.load([WorkflowProject].self, key: "projects") ?? []
        apiConfigs = Self.load([APIProviderConfig].self, key: "apiConfigs") ?? []
        runRecords = Self.load([RunRecord].self, key: "runRecords") ?? []
        snapshots = Self.load([VersionSnapshot].self, key: "snapshots") ?? []
        settings = Self.load(AppSettings.self, key: "settings") ?? AppSettings()
    }

    private func migrateDuplicateAPIConfigs() -> Bool {
        var seenIDs: Set<UUID> = []
        var seenKeychainAccounts: Set<String> = []
        var changed = false

        for index in apiConfigs.indices {
            if seenIDs.contains(apiConfigs[index].id) {
                apiConfigs[index].id = UUID()
                apiConfigs[index].updatedAt = Date()
                changed = true
            }
            seenIDs.insert(apiConfigs[index].id)

            let account = apiConfigs[index].keychainAccount.trimmingCharacters(in: .whitespacesAndNewlines)
            if account.isEmpty || seenKeychainAccounts.contains(account) {
                let oldAccount = apiConfigs[index].keychainAccount
                let newAccount = UUID().uuidString
                if !oldAccount.isEmpty, let existingKey = try? KeychainService.read(account: oldAccount), !existingKey.isEmpty {
                    try? KeychainService.save(existingKey, account: newAccount)
                }
                apiConfigs[index].keychainAccount = newAccount
                apiConfigs[index].updatedAt = Date()
                changed = true
            }
            seenKeychainAccounts.insert(apiConfigs[index].keychainAccount)
        }

        return changed
    }

    private func migrateLegacyModuleTitles() -> Bool {
        var changed = false
        for projectIndex in projects.indices {
            for nodeIndex in projects[projectIndex].nodes.indices {
                let node = projects[projectIndex].nodes[nodeIndex]
                guard node.kind == .filePackager else { continue }
                let trimmed = node.title.trimmingCharacters(in: .whitespacesAndNewlines)
                guard trimmed == "文件打包者" || trimmed.hasPrefix("文件打包者 ") else { continue }
                let suffix = trimmed.dropFirst("文件打包者".count)
                projects[projectIndex].nodes[nodeIndex].title = "\(WorkflowNodeKind.filePackager.title)\(suffix)"
                changed = true
            }
        }
        return changed
    }

    private func saveProjects() { Self.save(projects, key: "projects") }
    private func saveAPIConfigs() { Self.save(apiConfigs, key: "apiConfigs") }
    private func saveRunRecords() { Self.save(runRecords, key: "runRecords") }
    private func saveSnapshots() { Self.save(snapshots, key: "snapshots") }
    private func saveSettings() { Self.save(settings, key: "settings") }

    private static func save<T: Encodable>(_ value: T, key: String) {
        let encoder = JSONEncoder()
        encoder.dateEncodingStrategy = .iso8601
        if let data = try? encoder.encode(value) {
            UserDefaults.standard.set(data, forKey: key)
        }
    }

    private static func load<T: Decodable>(_ type: T.Type, key: String) -> T? {
        guard let data = UserDefaults.standard.data(forKey: key) else { return nil }
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        return try? decoder.decode(T.self, from: data)
    }
}
