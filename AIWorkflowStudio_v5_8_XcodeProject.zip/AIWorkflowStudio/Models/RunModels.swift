import Foundation

struct RunRecord: Identifiable, Codable, Hashable {
    var id: UUID = UUID()
    var projectID: UUID
    var projectTitle: String
    var startedAt: Date = Date()
    var endedAt: Date?
    var status: RunStatus = .running
    var progress: Double = 0
    var nodeRecords: [NodeRunRecord] = []
    var output: String = ""
    var tokenUsage: TokenUsage = .zero
    var logs: [RunLogEntry] = []
    var currentNodeTitle: String? = nil
    var currentNodeIDs: [UUID] = []
    var currentStage: String = "等待开始"
    var diagnosticMessage: String = ""
    var lastLogAt: Date = Date()

    var displayDate: String {
        startedAt.formatted(date: .abbreviated, time: .shortened)
    }
}

enum RunStatus: String, Codable, CaseIterable, Identifiable {
    case running
    case completed
    case failed
    case cancelled

    var id: String { rawValue }
    var title: String {
        switch self {
        case .running: return "运行中"
        case .completed: return "完成"
        case .failed: return "失败"
        case .cancelled: return "已取消"
        }
    }
}

struct NodeRunRecord: Identifiable, Codable, Hashable {
    var id: UUID = UUID()
    var nodeID: UUID
    var nodeTitle: String
    var kind: WorkflowNodeKind
    var status: NodeStatus
    var startedAt: Date = Date()
    var endedAt: Date?
    var inputPreview: String = ""
    var output: String = ""
    var errorMessage: String?
    var tokenUsage: TokenUsage = .zero
    var providerName: String?
    var modelID: String?
    var returnCount: Int = 0
}

struct RunLogEntry: Identifiable, Codable, Hashable {
    var id: UUID = UUID()
    var date: Date = Date()
    var level: LogLevel
    var nodeTitle: String?
    var message: String
}

enum LogLevel: String, Codable, CaseIterable, Identifiable {
    case info
    case warning
    case error
    case success

    var id: String { rawValue }
    var symbol: String {
        switch self {
        case .info: return "ℹ️"
        case .warning: return "⚠️"
        case .error: return "❌"
        case .success: return "✅"
        }
    }
}

struct TokenUsage: Codable, Hashable {
    var input: Int
    var output: Int

    var total: Int { input + output }

    static let zero = TokenUsage(input: 0, output: 0)

    static func + (lhs: TokenUsage, rhs: TokenUsage) -> TokenUsage {
        TokenUsage(input: lhs.input + rhs.input, output: lhs.output + rhs.output)
    }
}

struct VersionSnapshot: Identifiable, Codable, Hashable {
    var id: UUID = UUID()
    var projectID: UUID
    var createdAt: Date = Date()
    var title: String
    var project: WorkflowProject
    var output: String
    var note: String
}

enum TokenLimitMode: String, Codable, CaseIterable, Identifiable {
    case none
    case daily
    case singleWorkflow

    var id: String { rawValue }
    var title: String {
        switch self {
        case .none: return "不限制"
        case .daily: return "每日总量限制"
        case .singleWorkflow: return "单次工作流限制"
        }
    }

    var detail: String {
        switch self {
        case .none: return "不拦截运行，只记录 Token 使用。"
        case .daily: return "只检查当天全部运行累计 Token。"
        case .singleWorkflow: return "只检查本次工作流预估 Token。"
        }
    }
}

struct AppSettings: Codable, Hashable {
    var tokenLimitMode: TokenLimitMode = .none
    var dailyTokenLimit: Int = 300_000
    var singleWorkflowTokenLimit: Int = 80_000
    var singleModuleTokenLimit: Int = 128_000
    /// 0 表示多模型投票不限制模型数量。
    var maxVoteModels: Int = 0
    /// 0 表示默认无限返工。
    var maxReturnCount: Int = 0
    var confirmWhenEstimatedCostOver: Double = 1.0
    var forceDarkMode: Bool = true
    var privacyModeForLogs: Bool = false

    /// 全局默认模型：不再放在单个 API 配置里。
    /// 工作流页“一键应用全局默认模型”会按模块类型读取这些值。
    var defaultTextProviderID: UUID? = nil
    var defaultTextModelID: String? = nil
    var defaultVisionProviderID: UUID? = nil
    var defaultVisionModelID: String? = nil
    var defaultImageProviderID: UUID? = nil
    var defaultImageModelID: String? = nil
    var defaultCodeProviderID: UUID? = nil
    var defaultCodeModelID: String? = nil
    var defaultReviewerProviderID: UUID? = nil
    var defaultReviewerModelID: String? = nil
}
