import Foundation

struct WorkflowProject: Identifiable, Codable, Hashable {
    var id: UUID = UUID()
    var title: String
    var userPrompt: String
    var autoSelectModules: Bool
    var nodes: [WorkflowNode]
    var edges: [WorkflowEdge]
    var resources: [ProjectResource] = []
    var createdAt: Date = Date()
    var updatedAt: Date = Date()

    static func blank(title: String = "新工作流") -> WorkflowProject {
        let start = WorkflowNode(kind: .start, title: "开始模块", x: 160, y: 220)
        let output = WorkflowNode(kind: .output, title: "输出模块", x: 640, y: 220)
        return WorkflowProject(
            title: title,
            userPrompt: "",
            autoSelectModules: false,
            nodes: [start, output],
            edges: []
        )
    }
}

struct ProjectResource: Identifiable, Codable, Hashable {
    var id: UUID = UUID()
    var name: String
    var kind: ResourceKind
    var localPath: String?
    var base64Preview: String?
    var createdAt: Date = Date()
}

enum ResourceKind: String, Codable, CaseIterable, Identifiable {
    case image
    case file
    case code
    case text

    var id: String { rawValue }
    var title: String {
        switch self {
        case .image: return "图片"
        case .file: return "文件"
        case .code: return "代码"
        case .text: return "文本"
        }
    }
}

struct WorkflowNode: Identifiable, Codable, Hashable {
    var id: UUID = UUID()
    var kind: WorkflowNodeKind
    var title: String
    var prompt: String = ""
    var providerID: UUID?
    var modelID: String?
    var maxTokens: Int = 2_000
    var temperature: Double = 0.3
    var timeoutSeconds: Int = 90
    /// 0 表示无限重试；实际运行时仍建议用户自行停止，避免费用失控。
    var retryLimit: Int = 0
    /// 0 表示无限返工；检查者/自动修复循环仍会写入日志，方便用户手动终止。
    var maxReturnCount: Int = 0
    var x: Double
    var y: Double
    var status: NodeStatus = .waiting
    var lastOutput: String = ""
    var scoreThreshold: Int = 80
    var voteModelIDs: [String] = []
    var outputFormat: OutputFormat = .markdown
}

struct WorkflowEdge: Identifiable, Codable, Hashable {
    var id: UUID = UUID()
    var from: UUID
    var to: UUID
    var condition: EdgeCondition
}

enum EdgeCondition: String, Codable, CaseIterable, Identifiable {
    case always
    case passed
    case failed
    case scoreLow
    case scoreHigh

    var id: String { rawValue }
    var title: String {
        switch self {
        case .always: return "总是"
        case .passed: return "通过"
        case .failed: return "失败"
        case .scoreLow: return "低分返工"
        case .scoreHigh: return "高分输出"
        }
    }
}

enum NodeStatus: String, Codable, CaseIterable, Identifiable {
    case waiting
    case running
    case passed
    case failed
    case retrying
    case returned
    case skipped

    var id: String { rawValue }
    var title: String {
        switch self {
        case .waiting: return "等待"
        case .running: return "运行中"
        case .passed: return "已通过"
        case .failed: return "失败"
        case .retrying: return "重试中"
        case .returned: return "已打回"
        case .skipped: return "已跳过"
        }
    }
}

enum OutputFormat: String, Codable, CaseIterable, Identifiable {
    case txt
    case markdown
    case json
    case csv
    case html
    case swift
    case python
    case zipPlan

    var id: String { rawValue }
    var title: String {
        switch self {
        case .txt: return "TXT"
        case .markdown: return "Markdown"
        case .json: return "JSON"
        case .csv: return "CSV"
        case .html: return "HTML"
        case .swift: return "Swift"
        case .python: return "Python"
        case .zipPlan: return "真实 ZIP 项目包"
        }
    }
}


struct WorkflowExportPackage: Codable, Hashable {
    var appName: String = "AI Workflow Studio"
    var schemaVersion: Int = 1
    var exportedAt: Date = Date()
    var project: WorkflowProject
}
