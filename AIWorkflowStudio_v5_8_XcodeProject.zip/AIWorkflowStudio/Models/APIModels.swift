import Foundation

struct APIProviderConfig: Identifiable, Codable, Hashable {
    var id: UUID = UUID()
    var name: String
    var baseURL: String
    var keychainAccount: String
    var interfaceTypes: Set<AIInterfaceType> = [.chat]
    var models: [AIModelInfo] = []
    var defaultTextModel: String = ""
    var defaultVisionModel: String = ""
    var defaultImageModel: String = ""
    var inputPricePerMillionTokens: Double = 0
    var outputPricePerMillionTokens: Double = 0
    var createdAt: Date = Date()
    var updatedAt: Date = Date()

    static var empty: APIProviderConfig {
        APIProviderConfig(
            id: UUID(),
            name: "OpenAI 兼容接口",
            baseURL: "https://api.openai.com/v1",
            keychainAccount: UUID().uuidString
        )
    }
}

enum AIInterfaceType: String, Codable, CaseIterable, Identifiable, Hashable {
    case chat
    case responses
    case vision
    case imageGeneration
    case embedding

    var id: String { rawValue }
    var title: String {
        switch self {
        case .chat: return "对话接口"
        case .responses: return "响应接口"
        case .vision: return "图片理解接口"
        case .imageGeneration: return "图片生成接口"
        case .embedding: return "向量接口"
        }
    }

    var detail: String {
        switch self {
        case .chat: return "兼容 /v1/chat/completions 的文本调用。"
        case .responses: return "兼容 /v1/responses 的新式响应调用，后续适配。"
        case .vision: return "支持把图片和文字一起发给模型。"
        case .imageGeneration: return "用于生成图片、图标或素材。"
        case .embedding: return "用于文本向量化、检索和记忆库。"
        }
    }
}

struct AIModelInfo: Identifiable, Codable, Hashable {
    var id: String
    var name: String
    var supportsVision: Bool = false
    var supportsImageGeneration: Bool = false
    var contextLength: Int? = nil
}

struct OpenAIModelListResponse: Decodable {
    let data: [OpenAIModelItem]
}

struct OpenAIModelItem: Decodable {
    let id: String
}
