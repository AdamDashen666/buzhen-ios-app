import SwiftUI
import PhotosUI

struct NodeDetailView: View {
    @EnvironmentObject private var store: AppStore
    @Environment(\.dismiss) private var dismiss
    var projectID: UUID
    @State var node: WorkflowNode
    @State private var startPrompt = ""
    @State private var selectedPhoto: PhotosPickerItem?
    @State private var modelSearch = ""

    var body: some View {
        NavigationStack {
            Form {
                Section("模块说明") {
                    Label(node.kind.title, systemImage: node.kind.icon)
                    Text(node.kind.summary)
                        .foregroundStyle(.secondary)
                    VStack(alignment: .leading, spacing: 8) {
                        Text(node.kind.inputDescription)
                        Text(node.kind.outputDescription)
                    }
                    .font(.caption)
                    .foregroundStyle(.secondary)
                }

                if node.kind == .start {
                    startModuleSection
                }

                Section("基础设置") {
                    TextField("模块名称", text: $node.title)
                    if node.kind != .start && node.kind != .output {
                        integerInput("最大返工次数", value: $node.maxReturnCount, suffix: "次，0 = 无限")
                        Text("0 表示无限返工。风险：可能导致费用增加，建议配合设置页的 Token 总限制。")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                        integerInput("重试次数", value: $node.retryLimit, suffix: "次，0 = 无限")
                        Text("0 表示无限重试。适合长任务，但 API 持续失败时可能重复消耗时间。")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                }

                if node.kind == .custom {
                    Section("自定义模块提示词") {
                        TextEditor(text: $node.prompt)
                            .frame(minHeight: 150)
                        Text("只有自定义模块需要这里。内置模块会自动使用自己的固定职责说明，避免用户误以为每个模块都必须手写 prompt。")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                }

                if node.kind != .start && node.kind != .output {
                    modelSettingsSection
                }

                if node.kind.isReviewer {
                    Section("检查者连线规则") {
                        Text("检查通过：走右侧“通过”接口，不需要输出修改建议。")
                        Text("检查不合格：走右侧“不合格”接口，可直接打回任意工作者的输入口。")
                        Text("返工线可以绕回上游模块；运行时可用“停止运行”手动终止。")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                }

                Section("输出设置") {
                    Picker("输出格式", selection: $node.outputFormat) {
                        ForEach(OutputFormat.allCases) { format in
                            Text(format.title).tag(format)
                        }
                    }
                    integerInput("质量阈值", value: $node.scoreThreshold, suffix: "0～100")
                    if node.kind == .multiModelVote {
                        Text("多模型投票上限在设置页统一控制；0 表示不限制。")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                }

                Section("危险操作") {
                    Button(role: .destructive) {
                        store.removeNode(projectID: projectID, nodeID: node.id)
                        dismiss()
                    } label: {
                        Label("删除这个模块", systemImage: "trash")
                    }
                    .disabled(node.kind == .start || node.kind == .output)
                    Text("开始模块和输出模块默认保留，避免工作流失去入口或出口。")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
            .scrollContentBackground(.hidden)
            .studioBackground()
            .navigationTitle(node.title)
            .onAppear(perform: loadStartValues)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("取消") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("保存") {
                        saveStartValuesIfNeeded()
                        sanitizeNodeNumbers()
                        store.updateNode(node, in: projectID)
                        dismiss()
                    }
                }
            }
        }
    }

    private var startModuleSection: some View {
        Section("开始模块：输入") {
            TextEditor(text: $startPrompt)
                .frame(minHeight: 140)
            Text("这里仅保存工作流输入。AI 自动选择和运行按钮在工作流页面右上角。")
                .font(.caption)
                .foregroundStyle(.secondary)
            PhotosPicker(selection: $selectedPhoto, matching: .images) {
                Label("上传图片给图片理解模块处理", systemImage: "photo.badge.plus")
            }
            .onChange(of: selectedPhoto) { _, newItem in
                Task { await importPhoto(newItem) }
            }
            Text("上传图片后会自动添加“图片理解 / 识别”模块，并连到开始模块；开始模块本身不识别图片。")
                .font(.caption)
                .foregroundStyle(.secondary)
        }
    }

    private var modelSettingsSection: some View {
        Section("模型设置") {
            Picker("API 配置", selection: Binding(get: { node.providerID }, set: { node.providerID = $0; modelSearch = "" })) {
                Text("未配置").tag(Optional<UUID>.none)
                ForEach(store.apiConfigs) { config in
                    Text(config.name).tag(Optional(config.id))
                }
            }
            if let providerID = node.providerID, let config = store.apiConfigs.first(where: { $0.id == providerID }) {
                TextField("搜索模型", text: $modelSearch)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                Picker("模型", selection: Binding(get: { node.modelID ?? "" }, set: { node.modelID = $0 })) {
                    Text("未选择").tag("")
                    ForEach(filteredModels(in: config)) { model in
                        Text(model.name).tag(model.id)
                    }
                }
                Text("当前列表：\(filteredModels(in: config).count) / \(config.models.count) 个模型")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            decimalInput("温度参数", value: $node.temperature, suffix: "0～1")
            Text("温度参数控制模型回答的随机程度：越低越稳定、越适合代码检查；越高越发散、越适合创意写作。建议代码检查 0.1～0.3，普通写作 0.3～0.7。")
                .font(.caption)
                .foregroundStyle(.secondary)
            integerInput("超时时间", value: $node.timeoutSeconds, suffix: "秒")
            Text("Token 总限制请到“设置 → Token 总限制”中设置；这里不再放单模块 Token 限制。")
                .font(.caption)
                .foregroundStyle(.secondary)
        }
    }

    private func filteredModels(in config: APIProviderConfig) -> [AIModelInfo] {
        let query = modelSearch.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        guard !query.isEmpty else { return config.models }
        return config.models.filter { $0.id.lowercased().contains(query) || $0.name.lowercased().contains(query) }
    }

    private func loadStartValues() {
        guard let project = store.projects.first(where: { $0.id == projectID }) else { return }
        startPrompt = project.userPrompt
    }

    private func saveStartValuesIfNeeded() {
        guard node.kind == .start else { return }
        guard var project = store.projects.first(where: { $0.id == projectID }) else { return }
        project.userPrompt = startPrompt
        project.autoSelectModules = false
        store.updateProject(project)
    }

    private func importPhoto(_ item: PhotosPickerItem?) async {
        guard let item,
              let data = try? await item.loadTransferable(type: Data.self),
              var project = store.projects.first(where: { $0.id == projectID }) else { return }
        let resource = ProjectResource(name: "Image-\(Int(Date().timeIntervalSince1970)).jpg", kind: .image, base64Preview: data.base64EncodedString())
        project.resources.append(resource)

        let startID = project.nodes.first(where: { $0.kind == .start })?.id
        let imageNodeID: UUID
        if let existing = project.nodes.first(where: { $0.kind == .imageUnderstanding }) {
            imageNodeID = existing.id
        } else {
            var imageNode = WorkflowNode(kind: .imageUnderstanding, title: WorkflowNodeKind.imageUnderstanding.title, x: 410, y: 340)
            imageNode.prompt = WorkflowNodeKind.imageUnderstanding.defaultPrompt
            store.applyDefaultModelIfPossible(to: &imageNode)
            project.nodes.append(imageNode)
            imageNodeID = imageNode.id
        }

        if let startID, !project.edges.contains(where: { $0.from == startID && $0.to == imageNodeID }) {
            project.edges.append(WorkflowEdge(from: startID, to: imageNodeID, condition: .always))
        }
        store.updateProject(project)
    }

    private func sanitizeNodeNumbers() {
        node.maxReturnCount = min(max(node.maxReturnCount, 0), 999)
        node.retryLimit = min(max(node.retryLimit, 0), 999)
        node.maxTokens = min(max(node.maxTokens, 1), 1_000_000)
        node.temperature = min(max(node.temperature, 0), 2)
        node.timeoutSeconds = min(max(node.timeoutSeconds, 5), 3600)
        node.scoreThreshold = min(max(node.scoreThreshold, 0), 100)
    }

    private func integerInput(_ title: String, value: Binding<Int>, suffix: String) -> some View {
        HStack {
            Text(title)
            Spacer()
            TextField(title, value: value, format: .number)
                .keyboardType(.numberPad)
                .multilineTextAlignment(.trailing)
                .frame(maxWidth: 130)
            Text(suffix)
                .font(.caption)
                .foregroundStyle(.secondary)
        }
    }

    private func decimalInput(_ title: String, value: Binding<Double>, suffix: String) -> some View {
        HStack {
            Text(title)
            Spacer()
            TextField(title, value: value, format: .number.precision(.fractionLength(2)))
                .keyboardType(.decimalPad)
                .multilineTextAlignment(.trailing)
                .frame(maxWidth: 130)
            Text(suffix)
                .font(.caption)
                .foregroundStyle(.secondary)
        }
    }
}
