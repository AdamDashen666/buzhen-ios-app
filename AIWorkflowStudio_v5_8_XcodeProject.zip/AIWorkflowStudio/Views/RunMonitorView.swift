import SwiftUI

struct RunMonitorView: View {
    @EnvironmentObject private var store: AppStore
    @State private var showFullLogs = false
    @State private var showNodeStatus = false

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    if let run = activeRun {
                        runHeader(run)
                        nodeTimeline(run)
                        logs(run)
                    } else {
                        ContentUnavailableView("当前工作流暂无运行记录", systemImage: "play.slash", description: Text("切换工作流后这里只显示当前工作流自己的记录。"))
                    }
                }
                .padding()
            }
            .studioBackground()
            .navigationTitle("运行监控")
            .toolbar {
                Button("运行当前项目") { store.startSelectedProjectRun() }
                Button(role: .destructive) { store.stopActiveRun() } label: { Label("停止", systemImage: "stop.fill") }
            }
        }
    }

    private var activeRun: RunRecord? {
        store.selectedProjectActiveRun
    }

    private func runHeader(_ run: RunRecord) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(run.projectTitle).font(.title2.bold())
            FlowingStatusBar(progress: run.progress)
            HStack {
                Label(run.status.title, systemImage: "circle.fill")
                Spacer()
                Text("Token \(run.tokenUsage.total)")
            }
            .font(.caption)
            .foregroundStyle(.secondary)

            VStack(alignment: .leading, spacing: 6) {
                Text("当前阶段：\(run.currentStage)")
                    .font(.headline)
                if let current = run.currentNodeTitle {
                    Text("当前模块：\(current)")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                Text(run.diagnosticMessage.isEmpty ? "暂无诊断信息。" : run.diagnosticMessage)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .textSelection(.enabled)
                Text("最后日志：\(run.lastLogAt.formatted(date: .omitted, time: .standard))")
                    .font(.caption2)
                    .foregroundStyle(.secondary)
            }
            .padding()
            .background(.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
        }
        .liquidGlass()
    }

    private func nodeTimeline(_ run: RunRecord) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text("模块状态").font(.headline)
                Spacer()
                Button(showNodeStatus ? "收起" : "展开") { showNodeStatus.toggle() }
                    .font(.caption)
            }
            if run.nodeRecords.isEmpty {
                Text("运行已创建，但还没有模块开始执行。通常是刚启动、提示词为空被拦截，或等待 API 响应。")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            } else if !showNodeStatus {
                moduleStatusSummary(run)
            } else {
                ForEach(run.nodeRecords) { node in
                    nodeStatusCard(node)
                }
            }
        }
        .liquidGlass()
    }

    private func moduleStatusSummary(_ run: RunRecord) -> some View {
        let running = run.nodeRecords.filter { $0.status == .running }.count
        let completed = run.nodeRecords.filter { $0.status == .passed }.count
        let failed = run.nodeRecords.filter { $0.status == .failed }.count
        return VStack(alignment: .leading, spacing: 6) {
            Text("默认折叠模块状态，展开后查看每个模块的输入，减少运行时重绘卡顿。")
                .font(.caption2)
                .foregroundStyle(.secondary)
            Text("已记录 \(run.nodeRecords.count) 个模块 · 运行中 \(running) · 已完成 \(completed) · 失败 \(failed)")
                .font(.caption)
                .foregroundStyle(.secondary)
            if let latest = run.nodeRecords.last {
                Text("最近模块：\(latest.nodeTitle) · \(latest.status.title)")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
        .padding()
        .background(.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
    }

    private func nodeStatusCard(_ node: NodeRunRecord) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(alignment: .top) {
                Image(systemName: node.kind.icon)
                VStack(alignment: .leading) {
                    Text(node.nodeTitle).font(.headline)
                    Text("\(node.status.title) · Token \(node.tokenUsage.total) · \(node.modelID ?? "本地/未配置")")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    if let error = node.errorMessage { Text(error).font(.caption).foregroundStyle(.red).textSelection(.enabled) }
                }
                Spacer()
            }
            DisclosureGroup("查看这个模块的输入") {
                Text(node.inputPreview.isEmpty ? "无输入记录" : node.inputPreview)
                    .font(.system(.caption, design: .monospaced))
                    .textSelection(.enabled)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
        }
        .padding()
        .background(.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
    }

    private func logs(_ run: RunRecord) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text("运行日志").font(.headline)
                Spacer()
                Button(showFullLogs ? "收起" : "展开") { showFullLogs.toggle() }
                ShareLink("导出 Markdown", item: LogExportService.markdown(for: run))
                ShareLink("导出 ZIP", item: ZipArchiveService.shareableRunArchive(for: run))
            }
            if run.logs.isEmpty {
                Text("暂无日志。如果进度条不动，这里会显示最后卡住的模块和诊断信息。")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            } else if !showFullLogs {
                VStack(alignment: .leading, spacing: 6) {
                    Text("默认只显示最近 3 条日志，展开后查看完整日志，减少运行时重绘卡顿。")
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                    ForEach(Array(run.logs.suffix(3))) { log in
                        logLine(log)
                    }
                }
            } else {
                ForEach(run.logs) { log in
                    logLine(log)
                }
            }
        }
        .liquidGlass()
    }

    private func logLine(_ log: RunLogEntry) -> some View {
        Text("\(log.level.symbol) \(log.nodeTitle.map { "[\($0)] " } ?? "")\(log.message)")
            .font(.caption)
            .textSelection(.enabled)
            .frame(maxWidth: .infinity, alignment: .leading)
    }
}
