import SwiftUI
import UIKit

struct SettingsView: View {
    @EnvironmentObject private var store: AppStore
    @State private var editingConfig: APIProviderConfig?
    @State private var addingConfig = false
    @State private var refreshingAllModels = false
    @State private var refreshAllLog = ""
    @State private var showingRefreshAllLog = false

    var body: some View {
        NavigationStack {
            Form {
                Section("多 API 配置") {
                    Button {
                        Task { await refreshAllModels() }
                    } label: {
                        Label(refreshingAllModels ? "正在刷新全部模型..." : "刷新全部模型", systemImage: "arrow.clockwise.circle")
                    }
                    .disabled(refreshingAllModels || store.apiConfigs.isEmpty)

                    ForEach(store.apiConfigs) { config in
                        Button { editingConfig = config } label: {
                            VStack(alignment: .leading, spacing: 4) {
                                Text(config.name).font(.headline)
                                Text(config.baseURL).font(.caption).foregroundStyle(.secondary)
                                Text("模型：\(config.models.count) 个")
                                    .font(.caption2)
                                    .foregroundStyle(.secondary)
                                Text("接口类型：\(config.interfaceTypes.map(\.title).sorted().joined(separator: "、"))")
                                    .font(.caption2)
                                    .foregroundStyle(.secondary)
                            }
                        }
                    }
                    Button { addingConfig = true } label: { Label("添加 API 配置", systemImage: "plus.circle") }
                    Text("这里只管理接口地址、Key、模型列表和价格。默认使用哪个模型在下面的“全局默认模型”里设置。")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                Section("全局默认模型") {
                    Text("这些默认值不属于某个 API 内部设置。工作流页面点击“一键应用全局默认模型”时，会按模块类型自动填入对应 API 和模型。")
                        .font(.caption)
                        .foregroundStyle(.secondary)

                    GlobalDefaultModelPicker(
                        title: "默认文本模型",
                        detail: "计划者、通用工作者、汇总者、格式转换者等普通文本模块使用。",
                        providerID: $store.settings.defaultTextProviderID,
                        modelID: $store.settings.defaultTextModelID
                    )
                    GlobalDefaultModelPicker(
                        title: "默认图片理解模型",
                        detail: "图片理解、截图分析、视觉检查等需要看图的模块使用。",
                        providerID: $store.settings.defaultVisionProviderID,
                        modelID: $store.settings.defaultVisionModelID,
                        preferVision: true
                    )
                    GlobalDefaultModelPicker(
                        title: "默认图片生成模型",
                        detail: "图片生成者模块使用。",
                        providerID: $store.settings.defaultImageProviderID,
                        modelID: $store.settings.defaultImageModelID,
                        preferImageGeneration: true
                    )
                    GlobalDefaultModelPicker(
                        title: "默认代码模型",
                        detail: "代码工作者、自动修复者等写代码模块使用。",
                        providerID: $store.settings.defaultCodeProviderID,
                        modelID: $store.settings.defaultCodeModelID
                    )
                    GlobalDefaultModelPicker(
                        title: "默认检查者模型",
                        detail: "代码检查者、质量评估者等审查模块使用，建议选稳定、低温度、推理强的模型。",
                        providerID: $store.settings.defaultReviewerProviderID,
                        modelID: $store.settings.defaultReviewerModelID
                    )
                }

                Section("Token 总限制") {
                    Picker("限制方式", selection: $store.settings.tokenLimitMode) {
                        ForEach(TokenLimitMode.allCases) { mode in
                            Text(mode.title).tag(mode)
                        }
                    }
                    Text(store.settings.tokenLimitMode.detail)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    if store.settings.tokenLimitMode == .daily {
                        integerInput("每日 Token 总量", value: $store.settings.dailyTokenLimit, suffix: "Token")
                    }
                    if store.settings.tokenLimitMode == .singleWorkflow {
                        integerInput("单次工作流 Token 总量", value: $store.settings.singleWorkflowTokenLimit, suffix: "Token")
                    }
                    Text("每日限制和单次限制只能选一个，也可以选择不限制。Token 统计仍会记录到运行日志。")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                Section("全局默认次数") {
                    integerInput("多模型投票模型上限", value: $store.settings.maxVoteModels, suffix: "个，0 = 无限")
                    Text("0 表示不限制投票模型数量。风险：模型越多，Token 和费用越高。")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    integerInput("新模块默认最大返工次数", value: $store.settings.maxReturnCount, suffix: "次，0 = 无限")
                    Text("0 表示无限返工。建议搭配 Token 总限制或人工确认模块使用。")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }


                Section("缓存") {
                    HStack {
                        Text("当前缓存大小")
                        Spacer()
                        Text(store.cacheSizeText)
                            .foregroundStyle(.secondary)
                    }
                    Button { store.refreshCacheSize() } label: { Label("重新计算缓存", systemImage: "arrow.clockwise") }
                    Button(role: .destructive) { store.clearCache() } label: { Label("清除缓存", systemImage: "trash") }
                    Text("只清除网络缓存和临时导出文件，不删除项目、API 配置、运行记录或版本历史。")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                Section("外观与隐私") {
                    Toggle("使用深色 Liquid Glass 外观", isOn: $store.settings.forceDarkMode)
                    Text("默认开启，避免系统浅色模式下毛玻璃太亮、文字看不清。")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    Toggle("日志导出前默认脱敏", isOn: $store.settings.privacyModeForLogs)
                }
            }
            .scrollContentBackground(.hidden)
            .studioBackground()
            .navigationTitle("设置")
            .onDisappear(perform: sanitizeSettings)
            .sheet(isPresented: $addingConfig) { APIConfigEditorView(config: .empty, isNew: true) }
            .sheet(item: $editingConfig) { config in APIConfigEditorView(config: config, isNew: false) }
            .alert(item: $store.appAlert) { alert in
                Alert(title: Text(alert.title), message: Text(alert.message), dismissButton: .default(Text("知道了")))
            }
            .alert("刷新全部模型结果", isPresented: $showingRefreshAllLog) {
                Button("复制结果日志") { UIPasteboard.general.string = refreshAllLog }
                Button("关闭", role: .cancel) { }
            } message: {
                Text(refreshAllLog)
            }
        }
    }


    private func refreshAllModels() async {
        refreshingAllModels = true
        defer { refreshingAllModels = false }
        refreshAllLog = await store.refreshAllModelLists()
        showingRefreshAllLog = true
    }

    private func sanitizeSettings() {
        store.settings.dailyTokenLimit = min(max(store.settings.dailyTokenLimit, 1), 100_000_000)
        store.settings.singleWorkflowTokenLimit = min(max(store.settings.singleWorkflowTokenLimit, 1), 100_000_000)
        store.settings.maxVoteModels = min(max(store.settings.maxVoteModels, 0), 999)
        store.settings.maxReturnCount = min(max(store.settings.maxReturnCount, 0), 999)
    }

    private func integerInput(_ title: String, value: Binding<Int>, suffix: String) -> some View {
        HStack {
            Text(title)
            Spacer()
            TextField(title, value: value, format: .number)
                .keyboardType(.numberPad)
                .multilineTextAlignment(.trailing)
                .frame(maxWidth: 150)
            Text(suffix)
                .font(.caption)
                .foregroundStyle(.secondary)
        }
    }
}

struct GlobalDefaultModelPicker: View {
    @EnvironmentObject private var store: AppStore
    var title: String
    var detail: String
    @Binding var providerID: UUID?
    @Binding var modelID: String?
    var preferVision: Bool = false
    var preferImageGeneration: Bool = false
    @State private var searchText = ""

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title).font(.headline)
            Text(detail)
                .font(.caption)
                .foregroundStyle(.secondary)

            Picker("API", selection: $providerID) {
                Text("不设置").tag(UUID?.none)
                ForEach(store.apiConfigs) { config in
                    Text(config.name).tag(Optional(config.id))
                }
            }
            .onChange(of: providerID) { _, newValue in
                guard let newValue,
                      let config = store.apiConfigs.first(where: { $0.id == newValue }) else {
                    modelID = nil
                    return
                }
                if let current = modelID,
                   config.models.contains(where: { $0.id == current }) {
                    return
                }
                modelID = bestDefaultModel(in: config)?.id
            }

            TextField("搜索模型", text: $searchText)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()

            Picker("模型", selection: $modelID) {
                Text("不设置").tag(String?.none)
                ForEach(filteredModels) { model in
                    Text(model.name).tag(Optional(model.id))
                }
            }

            Text(modelStatusText)
                .font(.caption2)
                .foregroundStyle(.secondary)
        }
        .padding(.vertical, 6)
    }

    private var selectedConfig: APIProviderConfig? {
        guard let providerID else { return nil }
        return store.apiConfigs.first(where: { $0.id == providerID })
    }

    private var filteredModels: [AIModelInfo] {
        guard let selectedConfig else { return [] }
        let base = selectedConfig.models
        let query = searchText.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        guard !query.isEmpty else { return sortedPreferred(base) }
        return sortedPreferred(base.filter { $0.id.lowercased().contains(query) || $0.name.lowercased().contains(query) })
    }

    private var modelStatusText: String {
        guard let selectedConfig else { return "未选择 API。" }
        if selectedConfig.models.isEmpty { return "这个 API 还没有模型列表，请先进入 API 配置刷新模型。" }
        return "当前显示：\(filteredModels.count) / \(selectedConfig.models.count) 个模型。"
    }

    private func sortedPreferred(_ models: [AIModelInfo]) -> [AIModelInfo] {
        models.sorted { lhs, rhs in
            score(lhs) > score(rhs)
        }
    }

    private func bestDefaultModel(in config: APIProviderConfig) -> AIModelInfo? {
        sortedPreferred(config.models).first
    }

    private func score(_ model: AIModelInfo) -> Int {
        var value = 0
        if preferVision && model.supportsVision { value += 20 }
        if preferImageGeneration && model.supportsImageGeneration { value += 20 }
        if model.id.lowercased().contains("vision") || model.id.lowercased().contains("vl") { value += preferVision ? 8 : 0 }
        if model.id.lowercased().contains("image") { value += preferImageGeneration ? 8 : 0 }
        return value
    }
}
