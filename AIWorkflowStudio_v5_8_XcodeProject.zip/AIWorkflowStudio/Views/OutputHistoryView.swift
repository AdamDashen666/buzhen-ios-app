import SwiftUI

struct OutputHistoryView: View {
    @EnvironmentObject private var store: AppStore
    @State private var selectedRun: RunRecord?

    var body: some View {
        NavigationStack {
            List {
                Section("当前工作流运行输出") {
                    if store.selectedProjectRunRecords.isEmpty {
                        ContentUnavailableView("暂无输出", systemImage: "tray", description: Text("这里只显示当前工作流自己的输出，切换工作流不会串记录。"))
                    }
                    ForEach(store.selectedProjectRunRecords) { run in
                        Button { selectedRun = run } label: {
                            RunOutputRow(run: run)
                        }
                    }
                }
                Section("当前工作流版本历史") {
                    if store.selectedProjectSnapshots.isEmpty {
                        Text("暂无版本快照。")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    ForEach(store.selectedProjectSnapshots) { snapshot in
                        VStack(alignment: .leading) {
                            Text(snapshot.title).font(.headline)
                            Text("\(snapshot.createdAt.formatted(date: .abbreviated, time: .shortened)) · \(snapshot.note)")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                    }
                }
            }
            .scrollContentBackground(.hidden)
            .studioBackground()
            .navigationTitle("输出历史")
            .sheet(item: $selectedRun) { run in
                OutputDetailView(run: run)
            }
        }
    }
}

private struct RunOutputRow: View {
    let run: RunRecord

    private var mayContainFiles: Bool {
        run.output.contains("```file") || run.nodeRecords.contains { node in
            node.kind == .formatter || node.kind == .filePackager || node.output.contains("```file")
        }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(run.projectTitle).font(.headline)
            Text("\(run.displayDate) · \(run.status.title) · Token \(run.tokenUsage.total)")
                .font(.caption)
                .foregroundStyle(.secondary)
            Text(run.currentStage)
                .font(.caption2)
                .foregroundStyle(.secondary)
            if mayContainFiles {
                Label("可能包含可单独导出的文件，点开后懒加载识别", systemImage: "doc.badge.arrow.up")
                    .font(.caption2)
                    .foregroundStyle(.green)
            }
        }
    }
}

private struct OutputDetailView: View {
    @Environment(\.dismiss) private var dismiss
    let run: RunRecord

    @State private var files: [ZipArchiveService.GeneratedFile]? = nil
    @State private var showFinalOutput = false
    @State private var showModuleIO = false

    var body: some View {
        NavigationStack {
            ScrollView {
                LazyVStack(alignment: .leading, spacing: 18) {
                    exportActions
                    GeneratedFilesSection(run: run, files: files)

                    DisclosureGroup(isExpanded: $showFinalOutput) {
                        Text(run.output.isEmpty ? "暂无最终输出" : run.output)
                            .font(.system(.body, design: .monospaced))
                            .textSelection(.enabled)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.top, 8)
                    } label: {
                        Label("最终输出", systemImage: "doc.text.magnifyingglass")
                            .font(.title2.bold())
                    }
                    .padding()
                    .background(.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 20, style: .continuous))

                    DisclosureGroup(isExpanded: $showModuleIO) {
                        LazyVStack(alignment: .leading, spacing: 12) {
                            ForEach(run.nodeRecords) { node in
                                ModuleIOCard(node: node)
                            }
                        }
                        .padding(.top, 8)
                    } label: {
                        Label("模块输入 / 输出", systemImage: "rectangle.stack")
                            .font(.title2.bold())
                    }
                    .padding()
                    .background(.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 20, style: .continuous))
                }
                .padding()
            }
            .studioBackground()
            .navigationTitle("输出详情")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button {
                        dismiss()
                    } label: {
                        Label("关闭", systemImage: "xmark.circle.fill")
                    }
                }
            }
            .task(id: run.id) {
                guard files == nil else { return }
                await Task.yield()
                files = ZipArchiveService.generatedFiles(for: run)
            }
        }
    }

    private var exportActions: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("导出")
                .font(.title2.bold())
            HStack(spacing: 10) {
                ShareLink(item: LogExportService.markdown(for: run)) {
                    Label("导出日志", systemImage: "doc.text")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)

                ShareLink(item: ZipArchiveService.shareableRunArchive(for: run)) {
                    Label("完整运行包", systemImage: "archivebox")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.bordered)
            }
            if let files, !files.isEmpty {
                ShareLink(item: ZipArchiveService.shareableGeneratedFilesArchive(for: run)) {
                    Label("导出全部文件 ZIP", systemImage: "doc.zipper")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)
            }
        }
        .padding()
        .background(.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 20, style: .continuous))
    }
}

private struct GeneratedFilesSection: View {
    let run: RunRecord
    let files: [ZipArchiveService.GeneratedFile]?

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Label("文件输出", systemImage: "doc.on.doc")
                    .font(.title2.bold())
                Spacer()
                if let files, !files.isEmpty {
                    ShareLink("导出全部文件", item: ZipArchiveService.shareableGeneratedFilesArchive(for: run))
                        .font(.caption.bold())
                }
            }

            if files == nil {
                ProgressView("正在识别可单独导出的文件…")
                    .padding()
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(.white.opacity(0.05), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
            } else if files?.isEmpty == true {
                Text("未检测到可单独导出的文件。建议让格式转换者输出 ```file path=\"xxx.py\"``` 这类文件块；需要完整项目目录时再连接项目打包者。")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .padding()
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(.white.opacity(0.05), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
            } else {
                ForEach(files ?? []) { file in
                    HStack(spacing: 12) {
                        Image(systemName: iconName(for: file.path))
                            .font(.title3)
                            .frame(width: 28)
                        VStack(alignment: .leading, spacing: 4) {
                            Text(file.path)
                                .font(.headline)
                                .lineLimit(2)
                            Text("来自：\(file.sourceNodeTitle) · \(file.sourceKindTitle) · \(file.byteCountText)")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                        Spacer()
                        ShareLink("导出", item: ZipArchiveService.shareableGeneratedFile(file, run: run))
                            .font(.caption.bold())
                    }
                    .padding()
                    .background(.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                }
            }
        }
        .padding()
        .background(.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 20, style: .continuous))
    }

    private func iconName(for path: String) -> String {
        let lower = path.lowercased()
        if lower.hasSuffix(".py") { return "chevron.left.forwardslash.chevron.right" }
        if lower.hasSuffix(".md") || lower.hasSuffix(".txt") { return "doc.text" }
        if lower.hasSuffix(".json") || lower.hasSuffix(".plist") { return "curlybraces" }
        if lower.hasSuffix(".html") || lower.hasSuffix(".css") { return "globe" }
        return "doc"
    }
}

private struct ModuleIOCard: View {
    let node: NodeRunRecord
    @State private var showInput = false
    @State private var showOutput = false

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Label(node.nodeTitle, systemImage: node.kind.icon)
                .font(.headline)
            Text("\(node.kind.title) · \(node.status.title) · 输入 Token \(node.tokenUsage.input) · 输出 Token \(node.tokenUsage.output)")
                .font(.caption2)
                .foregroundStyle(.secondary)
            DisclosureGroup("输入预览 / 审计", isExpanded: $showInput) {
                Text(node.inputPreview.isEmpty ? "无输入记录" : node.inputPreview)
                    .font(.system(.caption, design: .monospaced))
                    .textSelection(.enabled)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.top, 4)
            }
            DisclosureGroup("输出", isExpanded: $showOutput) {
                Text(node.output.isEmpty ? (node.errorMessage ?? "无输出") : node.output)
                    .font(.system(.caption, design: .monospaced))
                    .textSelection(.enabled)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.top, 4)
            }
        }
        .padding()
        .background(.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
    }
}
