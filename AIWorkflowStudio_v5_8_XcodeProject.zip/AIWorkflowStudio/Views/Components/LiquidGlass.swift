import SwiftUI

struct LiquidGlassCard: ViewModifier {
    var cornerRadius: CGFloat = 28
    var glow: Bool = true

    func body(content: Content) -> some View {
        content
            .padding()
            .background(
                ZStack {
                    RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
                        .fill(.ultraThinMaterial)
                    RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
                        .fill(
                            LinearGradient(
                                colors: [Color.white.opacity(0.13), Color.cyan.opacity(0.07), Color.black.opacity(0.20)],
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            )
                        )
                }
            )
            .overlay(
                RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
                    .stroke(.white.opacity(0.26), lineWidth: 1)
            )
            .shadow(color: .black.opacity(0.25), radius: 18, x: 0, y: 10)
            .shadow(color: .cyan.opacity(glow ? 0.16 : 0), radius: 24, x: 0, y: 8)
    }
}

extension View {
    func liquidGlass(cornerRadius: CGFloat = 28, glow: Bool = true) -> some View {
        modifier(LiquidGlassCard(cornerRadius: cornerRadius, glow: glow))
    }

    func studioBackground() -> some View {
        background(
            ZStack {
                LinearGradient(
                    colors: [Color(red: 0.025, green: 0.035, blue: 0.07), Color(red: 0.05, green: 0.10, blue: 0.18), Color(red: 0.10, green: 0.05, blue: 0.16)],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                RadialGradient(colors: [Color.cyan.opacity(0.25), Color.clear], center: .topLeading, startRadius: 20, endRadius: 520)
                RadialGradient(colors: [Color.purple.opacity(0.20), Color.clear], center: .bottomTrailing, startRadius: 20, endRadius: 560)
            }
            .ignoresSafeArea()
        )
    }
}

struct FlowingStatusBar: View {
    var progress: Double

    var body: some View {
        GeometryReader { geometry in
            ZStack(alignment: .leading) {
                Capsule().fill(.white.opacity(0.16))
                Capsule()
                    .fill(.linearGradient(colors: [.cyan, .blue, .purple], startPoint: .leading, endPoint: .trailing))
                    .frame(width: max(8, geometry.size.width * progress))
            }
        }
        .frame(height: 10)
    }
}

struct InfoPill: View {
    var icon: String
    var text: String

    var body: some View {
        Label(text, systemImage: icon)
            .font(.caption.weight(.medium))
            .padding(.horizontal, 10)
            .padding(.vertical, 6)
            .background(.white.opacity(0.10), in: Capsule())
            .overlay(Capsule().stroke(.white.opacity(0.18), lineWidth: 1))
    }
}
