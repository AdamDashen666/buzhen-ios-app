import SwiftUI
import UIKit

struct APIConfigEditorView: View {
    @EnvironmentObject private var store: AppStore
    @Environment(\.dismiss) private var dismiss
    @State var config: APIProviderConfig
    var isNew: Bool
    @State private var apiKey = ""
    @State private var refreshMessage = ""
    @State private var refreshing = false
    @State private var errorLog = ""
    @State private var showingErrorLog = false
    @State private var modelSearch = ""

    var body: some View {
        NavigationStack {
            Form {
                Section("基础") {
                    TextField("配置名称", text: $config.name)
                    TextField("API Base URL", text: $config.baseURL)
                        .textInputAutocapitalization(.never)
                        .keyboardType(.URL)
                    SecureField(isNew ? "API Key" : "新 API Key（不填则保留）", text: $apiKey)
                    Text("目前优先支持 OpenAI 兼容格式，例如 /v1/models 和 /v1/chat/completions。")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                Section("接口类型") {
                    ForEach(AIInterfaceType.allCases) { type in
                        Toggle(isOn: Binding(
                            get: { config.interfaceTypes.contains(type) },
                            set: { enabled in
                                if enabled { config.interfaceTypes.insert(type) } else { config.interfaceTypes.remove(type) }
                            }
                        )) {
                            VStack(alignment: .leading, spacing: 2) {
                                Text(type.title)
                                Text(type.detail)
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                        }
                    }
                }
                Section("模型") {
                    Text("模型列表请在设置页的“多 API 配置”区域点击“刷新全部模型”统一刷新。")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    if !refreshMessage.isEmpty { Text(refreshMessage).font(.caption).foregroundStyle(.secondary) }
                    TextField("搜索模型", text: $modelSearch)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                    Text("当前显示：\(filteredModels.count) / \(config.models.count) 个模型")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    Text("这里不再设置默认模型。默认文本 / 图片理解 / 图片生成 / 代码 / 检查者模型，请到设置页的“全局默认模型”里统一选择。")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    ForEach(filteredModels) { model in
                        VStack(alignment: .leading, spacing: 2) {
                            Text(model.id).font(.caption)
                            Text("图片理解：\(model.supportsVision ? "可能支持" : "未识别") · 图片生成：\(model.supportsImageGeneration ? "可能支持" : "未识别")")
                                .font(.caption2)
                                .foregroundStyle(.secondary)
                        }
                    }
                }
                Section("价格 / Token") {
                    TextField("输入 Token 每百万价格", value: $config.inputPricePerMillionTokens, format: .number)
                        .keyboardType(.decimalPad)
                    TextField("输出 Token 每百万价格", value: $config.outputPricePerMillionTokens, format: .number)
                        .keyboardType(.decimalPad)
                    Text("只用于费用估算，不会影响 API 真实计费。")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
            .scrollContentBackground(.hidden)
            .studioBackground()
            .navigationTitle(isNew ? "添加 API" : "编辑 API")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("取消") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("保存") {
                        if isNew { store.addAPIConfig(config, apiKey: apiKey) }
                        else { store.updateAPIConfig(config, apiKey: apiKey.isEmpty ? nil : apiKey) }
                        dismiss()
                    }
                }
            }
            .alert("刷新模型失败", isPresented: $showingErrorLog) {
                Button("复制错误日志") { UIPasteboard.general.string = errorLog }
                Button("关闭", role: .cancel) { }
            } message: {
                Text(errorLog)
            }
        }
    }

    private var filteredModels: [AIModelInfo] {
        let query = modelSearch.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        guard !query.isEmpty else { return config.models }
        return config.models.filter { $0.id.lowercased().contains(query) || $0.name.lowercased().contains(query) }
    }

    private func refreshModels() async {
        refreshing = true
        defer { refreshing = false }
        do {
            let key = apiKey.isEmpty ? (try? KeychainService.read(account: config.keychainAccount)) ?? "" : apiKey
            let models = try await store.aiClient.fetchModels(baseURL: config.baseURL, apiKey: key)
            config.models = models
            store.seedGlobalDefaultsIfEmpty(providerID: config.id, models: models)
            refreshMessage = "已刷新 \(models.count) 个模型，可到设置页选择全局默认模型"
        } catch {
            errorLog = "API 配置：\(config.name)\nBase URL：\(config.baseURL)\n错误：\(error.localizedDescription)"
            refreshMessage = "刷新失败，已弹出错误日志"
            showingErrorLog = true
        }
    }
}
