import Foundation
import Security

enum KeychainError: Error, LocalizedError {
    case unableToSave(OSStatus)
    case unableToRead(OSStatus)
    case missingValue

    var errorDescription: String? {
        switch self {
        case .unableToSave(let status): return "Keychain 保存失败：\(status)"
        case .unableToRead(let status): return "Keychain 读取失败：\(status)"
        case .missingValue: return "Keychain 中没有找到 API Key"
        }
    }
}

enum KeychainService {
    static func save(_ value: String, account: String) throws {
        let data = Data(value.utf8)
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: "AIWorkflowStudio.APIKey",
            kSecAttrAccount as String: account
        ]
        SecItemDelete(query as CFDictionary)
        var attributes = query
        attributes[kSecValueData as String] = data
        let status = SecItemAdd(attributes as CFDictionary, nil)
        guard status == errSecSuccess else { throw KeychainError.unableToSave(status) }
    }

    static func read(account: String) throws -> String {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: "AIWorkflowStudio.APIKey",
            kSecAttrAccount as String: account,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]
        var item: CFTypeRef?
        let status = SecItemCopyMatching(query as CFDictionary, &item)
        guard status == errSecSuccess else { throw KeychainError.unableToRead(status) }
        guard let data = item as? Data, let value = String(data: data, encoding: .utf8) else { throw KeychainError.missingValue }
        return value
    }

    static func delete(account: String) throws {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: "AIWorkflowStudio.APIKey",
            kSecAttrAccount as String: account
        ]
        SecItemDelete(query as CFDictionary)
    }
}
