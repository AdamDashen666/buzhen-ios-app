import Foundation

enum LogExportService {
    static func markdown(for run: RunRecord) -> String {
        var md = "# AI Workflow Studio 运行日志\n\n"
        md += "- 项目：\(run.projectTitle)\n"
        md += "- 开始：\(run.startedAt.formatted(date: .abbreviated, time: .standard))\n"
        md += "- 状态：\(run.status.title)\n"
        md += "- Token：输入 \(run.tokenUsage.input)，输出 \(run.tokenUsage.output)，总计 \(run.tokenUsage.total)\n\n"
        md += "## 模块记录\n\n"
        for node in run.nodeRecords {
            md += "### \(node.nodeTitle)\n"
            md += "- 类型：\(node.kind.title)\n"
            md += "- 状态：\(node.status.title)\n"
            md += "- 模型：\(node.modelID ?? "未配置")\n"
            md += "- Token：\(node.tokenUsage.total)\n\n"
            md += "```text\n\(node.output)\n```\n\n"
        }
        md += "## 事件\n\n"
        for log in run.logs {
            md += "- \(log.level.symbol) \(log.date.formatted(date: .omitted, time: .standard)) \(log.nodeTitle.map { "[\($0)] " } ?? "")\(log.message)\n"
        }
        return md
    }

    static func jsonData(for run: RunRecord) throws -> Data {
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        encoder.dateEncodingStrategy = .iso8601
        return try encoder.encode(run)
    }

    static func exportMarkdownToDocuments(run: RunRecord) throws -> URL {
        let fileName = "run-log-\(run.id.uuidString.prefix(8)).md"
        let url = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent(fileName)
        try markdown(for: run).write(to: url, atomically: true, encoding: .utf8)
        return url
    }
}
