import Foundation

struct TokenEstimate: Hashable {
    var estimatedInput: Int
    var estimatedOutput: Int
    var estimatedCalls: Int
    var estimatedTotal: Int { estimatedInput + estimatedOutput }
    var estimatedCost: Double
}

enum TokenEstimator {
    static func roughCount(_ text: String) -> Int {
        let scalarCount = max(text.unicodeScalars.count, 1)
        return max(1, Int(Double(scalarCount) / 3.6))
    }

    static func estimate(project: WorkflowProject, apiConfigs: [APIProviderConfig] = []) -> TokenEstimate {
        var input = roughCount(project.userPrompt)
        var output = 0
        var calls = 0
        for node in project.nodes {
            if node.kind == .start || node.kind == .output || node.kind == .logger || node.kind == .versionSnapshot { continue }
            calls += max(1, node.kind == .multiModelVote ? max(2, node.voteModelIDs.count) : 1)
            input += roughCount(node.prompt) + roughCount(project.userPrompt)
            output += node.maxTokens
        }
        let avgInputPrice = apiConfigs.map(\.inputPricePerMillionTokens).filter { $0 > 0 }.first ?? 0
        let avgOutputPrice = apiConfigs.map(\.outputPricePerMillionTokens).filter { $0 > 0 }.first ?? 0
        let cost = (Double(input) / 1_000_000.0 * avgInputPrice) + (Double(output) / 1_000_000.0 * avgOutputPrice)
        return TokenEstimate(estimatedInput: input, estimatedOutput: output, estimatedCalls: calls, estimatedCost: cost)
    }
}
