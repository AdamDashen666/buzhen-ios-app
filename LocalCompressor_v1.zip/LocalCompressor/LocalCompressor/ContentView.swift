import SwiftUI
import UniformTypeIdentifiers

struct ContentView: View {
    @StateObject private var model = CompressorViewModel()
    @State private var showImporter = false

    private let columns = [GridItem(.adaptive(minimum: 260), spacing: 14)]

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    heroCard
                    selectionCard
                    if model.summary.totalBytes > 0 {
                        estimatesCard
                        optionsCard
                        actionCard
                        detailsCard
                    }
                    if let errorText = model.errorText {
                        errorCard(errorText)
                    }
                }
                .padding()
                .frame(maxWidth: 1000, alignment: .center)
                .frame(maxWidth: .infinity)
            }
            .navigationTitle("Local Compressor")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        showImporter = true
                    } label: {
                        Label("选择", systemImage: "plus")
                    }
                    .disabled(model.isBusy)
                }
            }
            .fileImporter(
                isPresented: $showImporter,
                allowedContentTypes: [.item, .folder],
                allowsMultipleSelection: true,
                onCompletion: model.handleImportResult
            )
        }
    }

    private var heroCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 12) {
                Image(systemName: "archivebox.fill")
                    .font(.system(size: 36))
                    .symbolRenderingMode(.hierarchical)
                VStack(alignment: .leading, spacing: 4) {
                    Text("本地 iPadOS 压缩工具")
                        .font(.title2.bold())
                    Text("多选文件/文件夹 → 扫描原始大小 → 选择压缩模式 → 输出到本地")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
            }

            Text("注意：MP4、JPG、HEIC、ZIP、MP3 这类本来就压缩过的文件，很难再压小；想极小通常需要转码/降画质。")
                .font(.footnote)
                .foregroundStyle(.secondary)
        }
        .padding(18)
        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 24, style: .continuous))
    }

    private var selectionCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text("输入文件")
                        .font(.headline)
                    Text(model.statusText)
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
                Spacer()
                Button {
                    showImporter = true
                } label: {
                    Label("选择文件/文件夹", systemImage: "folder.badge.plus")
                }
                .buttonStyle(.borderedProminent)
                .disabled(model.isBusy)
            }

            if model.isBusy {
                ProgressView()
            }

            if !model.summary.items.isEmpty {
                LazyVGrid(columns: columns, alignment: .leading, spacing: 12) {
                    ForEach(model.summary.items) { item in
                        HStack(spacing: 12) {
                            Image(systemName: item.isDirectory ? "folder.fill" : "doc.fill")
                                .font(.title3)
                                .frame(width: 28)
                            VStack(alignment: .leading, spacing: 3) {
                                Text(item.displayName)
                                    .font(.subheadline.weight(.semibold))
                                    .lineLimit(1)
                                Text("\(Formatters.byteString(item.byteSize)) · \(item.fileCount) 文件")
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                            Spacer()
                        }
                        .padding(12)
                        .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                    }
                }
            }
        }
        .padding(18)
        .background(.background, in: RoundedRectangle(cornerRadius: 24, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 24).stroke(.quaternary))
    }

    private var estimatesCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                VStack(alignment: .leading, spacing: 3) {
                    Text("压缩预估")
                        .font(.headline)
                    Text("原始大小：\(Formatters.byteString(model.summary.totalBytes))")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
                Spacer()
            }

            LazyVGrid(columns: columns, alignment: .leading, spacing: 12) {
                ForEach(model.estimates) { estimate in
                    Button {
                        model.selectedProfile = estimate.profile
                    } label: {
                        VStack(alignment: .leading, spacing: 8) {
                            HStack {
                                Text(estimate.profile.title)
                                    .font(.headline)
                                Spacer()
                                if model.selectedProfile == estimate.profile {
                                    Image(systemName: "checkmark.circle.fill")
                                }
                            }
                            Text(estimate.profile.subtitle)
                                .font(.caption)
                                .foregroundStyle(.secondary)
                                .multilineTextAlignment(.leading)
                            HStack(alignment: .firstTextBaseline) {
                                Text(Formatters.byteString(estimate.estimatedBytes))
                                    .font(.title3.bold())
                                Text("约为原来的 \(Formatters.percent(estimate.ratio))")
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                        }
                        .padding(14)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                        .overlay(
                            RoundedRectangle(cornerRadius: 18)
                                .stroke(model.selectedProfile == estimate.profile ? .primary.opacity(0.55) : .quaternary, lineWidth: 1)
                        )
                    }
                    .buttonStyle(.plain)
                }
            }
        }
        .padding(18)
        .background(.background, in: RoundedRectangle(cornerRadius: 24, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 24).stroke(.quaternary))
    }

    private var optionsCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text("压缩选项")
                .font(.headline)

            TextField("输出文件名", text: $model.options.outputName)
                .textFieldStyle(.roundedBorder)

            Toggle("跳过隐藏文件（.DS_Store、隐藏缓存等）", isOn: $model.options.skipHiddenFiles)

            Text(profileWarning)
                .font(.footnote)
                .foregroundStyle(.secondary)
        }
        .padding(18)
        .background(.background, in: RoundedRectangle(cornerRadius: 24, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 24).stroke(.quaternary))
    }

    private var actionCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Button {
                    Task { await model.compress() }
                } label: {
                    Label(model.isBusy ? "处理中…" : "开始压缩", systemImage: "arrow.down.doc.fill")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)
                .controlSize(.large)
                .disabled(model.isBusy || model.summary.totalBytes == 0)
            }

            if let outputURL = model.outputURL {
                VStack(alignment: .leading, spacing: 8) {
                    Text("输出完成")
                        .font(.headline)
                    Text(outputURL.lastPathComponent)
                        .font(.footnote.monospaced())
                        .lineLimit(2)
                    ShareLink(item: outputURL) {
                        Label("分享 / 存到文件", systemImage: "square.and.arrow.up")
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.bordered)
                }
                .padding(14)
                .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
            }
        }
        .padding(18)
        .background(.background, in: RoundedRectangle(cornerRadius: 24, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 24).stroke(.quaternary))
    }

    private var detailsCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("文件类型分析")
                .font(.headline)
            ForEach(FileCategory.allCases, id: \.self) { category in
                let bytes = model.summary.categoryBytes[category, default: 0]
                if bytes > 0 {
                    HStack {
                        Text(category.title)
                        Spacer()
                        Text(Formatters.byteString(bytes))
                            .foregroundStyle(.secondary)
                    }
                    .font(.subheadline)
                }
            }
        }
        .padding(18)
        .background(.background, in: RoundedRectangle(cornerRadius: 24, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 24).stroke(.quaternary))
    }

    private func errorCard(_ text: String) -> some View {
        HStack(alignment: .top, spacing: 10) {
            Image(systemName: "exclamationmark.triangle.fill")
            Text(text)
                .font(.footnote)
        }
        .foregroundStyle(.red)
        .padding(14)
        .background(.red.opacity(0.08), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
    }

    private var profileWarning: String {
        switch model.selectedProfile {
        case .zipCompatible:
            return "ZIP 兼容性最好，但压缩率通常不是最高。"
        case .appleLZFSE:
            return "LZFSE 输出为本 App 的 .lcz 本地包，更适合 Apple 设备之间保存。"
        case .appleLZMA:
            return "LZMA 可能最小，但对超大文件会更慢、更吃内存。"
        }
    }
}
