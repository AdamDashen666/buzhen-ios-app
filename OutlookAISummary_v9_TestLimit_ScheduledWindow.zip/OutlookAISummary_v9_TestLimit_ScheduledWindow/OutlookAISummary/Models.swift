import Foundation

struct AppSettings: Codable, Equatable {
    var enabled: Bool = true
    var frequency: SummaryFrequency = .daily
    var language: String = "zh-CN"
    var includeJunkUnread: Bool = true
    var autoDeleteEnabled: Bool = true
    var deleteAfterDays: Int = 30
    var permanentDeleteAfterDays: Int = 7
}

enum SummaryFrequency: String, Codable, CaseIterable, Identifiable {
    case daily
    case sixHours
    case monthly

    var id: String { rawValue }

    var title: String {
        switch self {
        case .daily: return "每天"
        case .sixHours: return "每 6 小时"
        case .monthly: return "每月"
        }
    }

    var windowHours: Int {
        switch self {
        case .sixHours: return 6
        case .daily: return 24
        case .monthly: return 720
        }
    }

    var maxMessages: Int {
        switch self {
        case .monthly: return 50
        case .daily, .sixHours: return 30
        }
    }

    var scheduleDescription: String {
        switch self {
        case .sixHours: return "每次只总结最近 6 小时内的新邮件。"
        case .daily: return "每次只总结最近 24 小时内的新邮件。"
        case .monthly: return "每次只总结最近 30 天内的新邮件。"
        }
    }
}

struct AuthStatusResponse: Codable {
    let linked: Bool
    let user: LinkedUser?
}

struct LinkedUser: Codable {
    let displayName: String?
    let email: String?
    let settings: AppSettings?
    let lastRunAt: String?
}

struct SummaryItem: Codable, Identifiable, Equatable {
    let id: String
    let title: String
    let content: String
    let unreadCount: Int
    let junkUnreadCount: Int
    let createdAt: String
}

struct SummariesResponse: Codable {
    let summaries: [SummaryItem]
}

struct DeviceRegisterResponse: Codable {
    let deviceId: String
    let deviceToken: String?
    let platform: String?
    let updatedAt: String?
}

struct RunSummaryResponse: Codable {
    let ok: Bool
    let summary: SummaryItem?
    let hasMore: Bool?
    let processedCount: Int?
    let mode: String?
    let error: String?
    let message: String?
}

struct SettingsResponse: Codable {
    let ok: Bool
    let settings: AppSettings
}

struct BackendHealthResponse: Codable, Equatable {
    let ok: Bool
    let time: String?
    let provider: String?
}

struct IMAPTestResponse: Codable, Equatable {
    let ok: Bool
    let account: String?
    let host: String?
    let inboxMailbox: String?
    let messages: Int?
    let unseen: Int?
    let error: String?
}

struct AITestResponse: Codable, Equatable {
    let ok: Bool
    let reply: String?
    let error: String?
}
