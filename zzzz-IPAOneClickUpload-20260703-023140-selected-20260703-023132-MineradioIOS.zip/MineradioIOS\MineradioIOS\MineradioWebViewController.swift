import UIKit
import WebKit

final class MineradioWebViewController: UIViewController, WKNavigationDelegate, WKScriptMessageHandler {
    private lazy var webView: WKWebView = {
        let configuration = WKWebViewConfiguration()
        configuration.setURLSchemeHandler(MineradioSchemeHandler(), forURLScheme: "mineradio")
        configuration.allowsInlineMediaPlayback = true
        configuration.mediaTypesRequiringUserActionForPlayback = []
        configuration.userContentController = makeUserContentController()

        let view = WKWebView(frame: .zero, configuration: configuration)
        view.navigationDelegate = self
        view.isOpaque = false
        view.backgroundColor = .black
        view.scrollView.backgroundColor = .black
        view.scrollView.contentInsetAdjustmentBehavior = .never
        return view
    }()

    override var prefersStatusBarHidden: Bool { true }
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask { .all }

    override func loadView() {
        view = webView
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        webView.load(URLRequest(url: URL(string: "mineradio://app/index.html")!))
    }

    deinit {
        webView.configuration.userContentController.removeScriptMessageHandler(forName: "mineradioLog")
    }

    func webView(
        _ webView: WKWebView,
        decidePolicyFor navigationAction: WKNavigationAction,
        decisionHandler: @escaping (WKNavigationActionPolicy) -> Void
    ) {
        if let url = navigationAction.request.url,
           ["http", "https"].contains(url.scheme?.lowercased()),
           navigationAction.navigationType == .linkActivated {
            UIApplication.shared.open(url)
            decisionHandler(.cancel)
            return
        }
        decisionHandler(.allow)
    }

    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        guard message.name == "mineradioLog" else { return }
        print("[MineradioWeb]", message.body)
    }

    private func makeUserContentController() -> WKUserContentController {
        let controller = WKUserContentController()
        controller.add(self, name: "mineradioLog")
        controller.addUserScript(WKUserScript(source: Self.diagnosticsScript, injectionTime: .atDocumentStart, forMainFrameOnly: false))
        return controller
    }

    private static let diagnosticsScript = """
    (function () {
      function post(level, args) {
        try {
          window.webkit.messageHandlers.mineradioLog.postMessage({
            level: level,
            message: Array.prototype.slice.call(args || []).map(function (item) {
              if (item instanceof Error) return item.stack || item.message || String(item);
              if (typeof item === 'object') {
                try { return JSON.stringify(item); } catch (_) { return String(item); }
              }
              return String(item);
            }).join(' ')
          });
        } catch (_) {}
      }
      ['log', 'warn', 'error'].forEach(function (level) {
        var original = console[level];
        console[level] = function () {
          post(level, arguments);
          return original && original.apply(console, arguments);
        };
      });
      window.addEventListener('error', function (event) {
        post('error', [event.message + ' @ ' + event.filename + ':' + event.lineno + ':' + event.colno]);
      });
      window.addEventListener('unhandledrejection', function (event) {
        post('error', ['Unhandled promise rejection', event.reason]);
      });
    })();
    """
}
