import Foundation
import WebKit

final class MineradioAPIStub {
    private let netease = NeteaseNativeProvider()
    private let emptyList = [Any]()
    private let emptyObject = [String: Any]()

    func respond(to task: WKURLSchemeTask) {
        guard let url = task.request.url else {
            send(emptyObject, to: task, statusCode: 400)
            return
        }

        switch url.path {
        case "/favicon.ico":
            send(Data(), mimeType: "image/x-icon", to: task)
        case "/api/app/version":
            send(["version": "1.1.2", "platform": "ios", "source": "mineradio-ios-port"], to: task)
        case "/api/update/latest":
            send(["ok": true, "hasUpdate": false, "version": "1.1.2"], to: task)
        case "/api/update/download/status", "/api/update/patch/status":
            send(["ok": true, "status": "idle", "progress": 0], to: task)
        case "/api/update/download", "/api/update/patch":
            send(["ok": false, "status": "unsupported", "message": "Desktop updater is disabled on iOS."], to: task, statusCode: 501)
        case "/api/beatmap/cache/status":
            send(["ok": true, "available": false, "items": emptyList], to: task)
        case "/api/beatmap/cache":
            send(["ok": false, "cached": false, "beatmap": NSNull(), "message": "Beatmap cache is not implemented in the iOS stub yet."], to: task, statusCode: 501)
        case "/api/weather/ip-location":
            send([
                "ok": true,
                "name": "Shanghai",
                "country": "China",
                "latitude": 31.2304,
                "longitude": 121.4737,
                "timezone": "Asia/Shanghai"
            ], to: task)
        case "/api/weather/radio":
            send([
                "ok": true,
                "location": "Shanghai",
                "summary": "iOS port preview",
                "temperature": 26,
                "weatherCode": 1
            ], to: task)
        case "/api/discover/home":
            send([
                "ok": true,
                "playlists": emptyList,
                "songs": emptyList,
                "radios": emptyList,
                "message": "Native iOS service layer is ready for real provider implementations."
            ], to: task)
        case "/api/search":
            netease.search(url: url) { [weak self] result in
                self?.send(result.object, to: task, statusCode: result.statusCode)
            }
        case "/api/qq/search", "/api/kugou/search", "/api/ytmusic/search", "/api/qishui/search", "/api/podcast/search":
            send(searchStub(url: url), to: task)
        case "/api/login/status", "/api/qq/login/status":
            send(["ok": true, "loggedIn": false, "profile": NSNull()], to: task)
        case "/api/logout", "/api/qq/logout":
            send(["ok": true], to: task)
        case "/api/login/cookie", "/api/qq/login/cookie":
            send(["ok": false, "message": "Cookie import is not implemented on iOS yet."], to: task, statusCode: 501)
        case "/api/login/qr/key":
            send(["ok": false, "unikey": NSNull(), "message": "QR login is not implemented on iOS yet."], to: task, statusCode: 501)
        case "/api/login/qr/create":
            send(["ok": false, "qrimg": NSNull(), "message": "QR login is not implemented on iOS yet."], to: task, statusCode: 501)
        case "/api/login/qr/check":
            send(["ok": true, "code": 800, "message": "QR login is not implemented on iOS yet."], to: task)
        case "/api/user/playlists", "/api/qq/user/playlists", "/api/kugou/user/playlists", "/api/qishui/user/playlists":
            send(["ok": true, "playlists": emptyList], to: task)
        case "/api/playlist/tracks", "/api/qq/playlist/tracks", "/api/kugou/playlist/tracks", "/api/qishui/playlist/tracks":
            send(["ok": true, "songs": emptyList, "tracks": emptyList], to: task)
        case "/api/song/url":
            send(netease.songURL(url: url), to: task)
        case "/api/qq/song/url", "/api/kugou/song/url", "/api/ytmusic/song/url", "/api/qishui/song/url":
            send(["ok": false, "url": NSNull(), "message": "This provider is not implemented in the native iOS port yet."], to: task, statusCode: 501)
        case "/api/lyric":
            netease.lyric(url: url) { [weak self] result in
                self?.send(result.object, to: task, statusCode: result.statusCode)
            }
        case "/api/qq/lyric":
            send(["ok": true, "lyric": "", "tlyric": ""], to: task)
        case "/api/song/comments", "/api/qq/song/comments":
            send(["ok": true, "comments": emptyList], to: task)
        case "/api/artist/detail", "/api/qq/artist/detail":
            send(["ok": true, "artist": NSNull(), "songs": emptyList], to: task)
        case "/api/song/like/check":
            send(["ok": true, "liked": [String: Bool](), "ids": emptyList], to: task)
        case "/api/song/like":
            send(["ok": false, "message": "Like syncing is not implemented on iOS yet."], to: task, statusCode: 501)
        case "/api/playlist/create", "/api/playlist/add-song":
            send(["ok": false, "message": "Playlist mutation is not implemented on iOS yet."], to: task, statusCode: 501)
        case "/api/podcast/detail":
            send(["ok": true, "detail": NSNull(), "programs": emptyList], to: task)
        case "/api/podcast/dj-beatmap":
            send(["ok": false, "message": "Podcast beatmap analysis is not implemented on iOS yet."], to: task, statusCode: 501)
        case "/api/podcast/hot", "/api/podcast/my", "/api/podcast/my/items", "/api/podcast/programs":
            send(["ok": true, "items": emptyList, "programs": emptyList], to: task)
        case "/api/cover":
            proxyRemoteAsset(url: url, task: task, defaultMimeType: "image/jpeg")
        case "/api/audio":
            proxyRemoteAsset(url: url, task: task, defaultMimeType: "audio/mpeg")
        default:
            send(["ok": false, "message": "Route not implemented in iOS port", "path": url.path], to: task, statusCode: 501)
        }
    }

    private func searchStub(url: URL) -> [String: Any] {
        let components = URLComponents(url: url, resolvingAgainstBaseURL: false)
        let keyword = components?.queryItems?.first(where: { ["keywords", "keyword", "q"].contains($0.name) })?.value ?? ""
        return [
            "ok": true,
            "keyword": keyword,
            "songs": emptyList,
            "result": emptyList,
            "message": "Search UI is wired; native provider implementation is pending."
        ]
    }

    private func send(_ object: [String: Any], to task: WKURLSchemeTask, statusCode: Int = 200) {
        let data = (try? JSONSerialization.data(withJSONObject: object, options: [])) ?? Data("{}".utf8)
        send(data, mimeType: "application/json", to: task, statusCode: statusCode)
    }

    private func send(_ data: Data, mimeType: String, to task: WKURLSchemeTask, statusCode: Int = 200) {
        finish(task, statusCode: statusCode, mimeType: mimeType, data: data)
    }

    private func proxyRemoteAsset(url: URL, task: WKURLSchemeTask, defaultMimeType: String) {
        let components = URLComponents(url: url, resolvingAgainstBaseURL: false)
        guard let raw = components?.queryItems?.first(where: { $0.name == "url" })?.value,
              let remoteURL = URL(string: raw),
              ["http", "https"].contains(remoteURL.scheme?.lowercased()) else {
            send(emptyObject, to: task, statusCode: 404)
            return
        }

        var request = URLRequest(url: remoteURL)
        request.setValue(NeteaseNativeProvider.userAgent, forHTTPHeaderField: "User-Agent")
        request.setValue("https://music.163.com/", forHTTPHeaderField: "Referer")

        URLSession.shared.dataTask(with: request) { data, response, error in
            guard error == nil, let data = data, !data.isEmpty else {
                self.send(["ok": false, "message": error?.localizedDescription ?? "Proxy failed"], to: task, statusCode: 502)
                return
            }
            let mimeType = response?.mimeType ?? defaultMimeType
            self.send(data, mimeType: mimeType, to: task)
        }.resume()
    }
}

struct APIResult {
    let object: [String: Any]
    let statusCode: Int
}

final class NeteaseNativeProvider {
    static let userAgent = "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1"

    func search(url: URL, completion: @escaping (APIResult) -> Void) {
        let components = URLComponents(url: url, resolvingAgainstBaseURL: false)
        let keyword = queryValue(["keywords", "keyword", "q"], in: components).trimmingCharacters(in: .whitespacesAndNewlines)
        let limit = Int(queryValue(["limit"], in: components)) ?? 20
        let emptySongs = [[String: Any]]()
        guard !keyword.isEmpty else {
            completion(APIResult(object: ["ok": true, "keyword": keyword, "songs": emptySongs, "result": emptySongs], statusCode: 200))
            return
        }

        var endpoint = URLComponents(string: "https://itunes.apple.com/search")!
        endpoint.queryItems = [
            URLQueryItem(name: "media", value: "music"),
            URLQueryItem(name: "entity", value: "song"),
            URLQueryItem(name: "limit", value: String(max(1, min(limit, 50)))),
            URLQueryItem(name: "term", value: keyword)
        ]

        var request = URLRequest(url: endpoint.url!)
        request.setValue(Self.userAgent, forHTTPHeaderField: "User-Agent")

        URLSession.shared.dataTask(with: request) { data, _, error in
            guard error == nil, let data = data else {
                completion(APIResult(object: [
                    "ok": false,
                    "keyword": keyword,
                    "songs": emptySongs,
                    "message": error?.localizedDescription ?? "Search request failed"
                ], statusCode: 502))
                return
            }

            let songs = self.parseITunesSongs(data: data)
            completion(APIResult(object: [
                "ok": true,
                "keyword": keyword,
                "songs": songs,
                "result": songs,
                "source": "itunes-preview"
            ], statusCode: 200))
        }.resume()
    }

    func songURL(url: URL) -> [String: Any] {
        let components = URLComponents(url: url, resolvingAgainstBaseURL: false)
        let id = queryValue(["id"], in: components)
        guard !id.isEmpty else {
            return ["ok": false, "url": NSNull(), "message": "Missing song id"]
        }

        if id.hasPrefix("itunes:") {
            let preview = String(id.dropFirst("itunes:".count))
            guard let decoded = preview.removingPercentEncoding, URL(string: decoded) != nil else {
                return ["ok": false, "url": NSNull(), "message": "Invalid iTunes preview URL"]
            }
            return [
                "ok": true,
                "id": id,
                "url": decoded,
                "source": "itunes-preview"
            ]
        }

        return [
            "ok": true,
            "id": id,
            "url": "https://music.163.com/song/media/outer/url?id=\(id).mp3",
            "source": "netease"
        ]
    }

    func lyric(url: URL, completion: @escaping (APIResult) -> Void) {
        let components = URLComponents(url: url, resolvingAgainstBaseURL: false)
        let id = queryValue(["id"], in: components)
        guard !id.isEmpty else {
            completion(APIResult(object: ["ok": false, "lyric": "", "message": "Missing song id"], statusCode: 400))
            return
        }

        var lyricURL = URLComponents(string: "https://music.163.com/api/song/lyric")!
        lyricURL.queryItems = [
            URLQueryItem(name: "id", value: id),
            URLQueryItem(name: "lv", value: "1"),
            URLQueryItem(name: "kv", value: "1"),
            URLQueryItem(name: "tv", value: "-1")
        ]

        var request = URLRequest(url: lyricURL.url!)
        request.setValue(Self.userAgent, forHTTPHeaderField: "User-Agent")
        request.setValue("https://music.163.com/", forHTTPHeaderField: "Referer")

        URLSession.shared.dataTask(with: request) { data, _, error in
            guard error == nil, let data = data else {
                completion(APIResult(object: [
                    "ok": false,
                    "lyric": "",
                    "message": error?.localizedDescription ?? "Lyric request failed"
                ], statusCode: 502))
                return
            }

            let json = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any]
            let lrc = json?["lrc"] as? [String: Any]
            let tlyric = json?["tlyric"] as? [String: Any]
            completion(APIResult(object: [
                "ok": true,
                "lyric": lrc?["lyric"] as? String ?? "",
                "tlyric": tlyric?["lyric"] as? String ?? ""
            ], statusCode: 200))
        }.resume()
    }

    private func parseITunesSongs(data: Data) -> [[String: Any]] {
        guard let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let rawSongs = json["results"] as? [[String: Any]] else {
            return []
        }

        return rawSongs.map { item in
            let preview = item["previewUrl"] as? String ?? ""
            let artistName = item["artistName"] as? String ?? ""
            let artists: [[String: String]] = [
                [
                    "id": stringValue(item["artistId"]),
                    "name": artistName
                ]
            ].filter { !$0["name", default: ""].isEmpty }
            let cover = item["artworkUrl100"] as? String ?? ""

            return [
                "provider": "itunes-preview",
                "source": "itunes-preview",
                "type": "song",
                "id": "itunes:\(preview.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? preview)",
                "name": item["trackName"] as? String ?? "",
                "artist": artistName,
                "artists": artists,
                "album": item["collectionName"] as? String ?? "",
                "albumId": stringValue(item["collectionId"]),
                "cover": cover,
                "duration": intValue(item["trackTimeMillis"]),
                "fee": item["fee"] as? Int ?? 0
            ]
        }
    }

    private func queryValue(_ names: [String], in components: URLComponents?) -> String {
        components?.queryItems?.first(where: { names.contains($0.name) })?.value ?? ""
    }

    private func stringValue(_ value: Any?) -> String {
        if let value = value as? String { return value }
        if let value = value as? NSNumber { return value.stringValue }
        if let value = value as? Int { return String(value) }
        return ""
    }

    private func intValue(_ value: Any?) -> Int {
        if let value = value as? Int { return value }
        if let value = value as? NSNumber { return value.intValue }
        if let value = value as? String { return Int(value) ?? 0 }
        return 0
    }
}
