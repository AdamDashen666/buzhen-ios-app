#!/bin/sh
set -eu

cd "$(dirname "$0")"

echo "== Mineradio iOS verification =="
echo "Project: $(pwd)/MineradioIOS.xcodeproj"

if ! command -v xcodebuild >/dev/null 2>&1; then
  echo "xcodebuild not found. Install Xcode and select it with xcode-select." >&2
  exit 1
fi

echo "== Listing schemes =="
xcodebuild -list -project MineradioIOS.xcodeproj

echo "== Building for generic iOS Simulator =="
xcodebuild \
  -project MineradioIOS.xcodeproj \
  -scheme MineradioIOS \
  -destination 'generic/platform=iOS Simulator' \
  CODE_SIGNING_ALLOWED=NO \
  build

echo "== OK =="
