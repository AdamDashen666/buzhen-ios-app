# Mineradio iOS Port

This is a first-pass iOS project generated from the macOS Electron package `Mineradio-1.1.2-arm64..dmg`.

## What works

- Opens as a normal Xcode iOS app project.
- Embeds the recovered Electron `public` web UI under `MineradioIOS/WebAssets`.
- Loads the original `index.html` in `WKWebView` through `mineradio://app/index.html`.
- Serves bundled CSS, JavaScript, images, vendor scripts, and binary assets through `WKURLSchemeHandler`.
- Provides structured responses for the Electron server routes that the UI calls.
- Implements a native iOS search/playback preview loop through the iTunes Search API:
  - `/api/search` returns real song rows with artwork and preview metadata.
  - `/api/song/url` resolves generated `itunes:` IDs to playable preview audio.
  - `/api/cover` and `/api/audio` proxy remote artwork/audio into the WebView.
- Keeps the NetEase outer song URL fallback for existing NetEase numeric IDs.
- Includes `verify-on-mac.sh` to list schemes and build the app for a generic iOS Simulator.
- Includes `verify-on-windows.ps1` for repeatable offline checks of the hand-written Xcode project, plist/storyboard XML, Swift file shape, and bundled WebAssets.
- Includes a minimal `LaunchScreen.storyboard` and shared Xcode scheme for more reliable command-line builds.
- Includes `Assets.xcassets` with generated iOS app icon sizes based on the recovered Mineradio icon.
- Routes `WKURLSchemeTask` completion back through the main queue and ignores tasks already stopped by WebKit.

## What still needs native implementation

- Full music-provider APIs from `server.js`, especially authenticated Netease, QQ Music, Kugou, Qishui, YouTube Music, podcast routes, and provider-specific lyrics.
- Login cookie flows that were previously handled by Electron sessions.
- Desktop-only features such as global hotkeys, desktop lyrics windows, wallpapers, updater patches, and tray behavior.

## Recommended next step

On a Mac, run:

```sh
chmod +x verify-on-mac.sh
./verify-on-mac.sh
```

Then open `MineradioIOS.xcodeproj`, pick an iOS simulator, and run the `MineradioIOS` scheme. After the shell loads, replace routes in `MineradioAPIStub.swift` one by one with native Swift service implementations translated from the recovered `server.js`.
