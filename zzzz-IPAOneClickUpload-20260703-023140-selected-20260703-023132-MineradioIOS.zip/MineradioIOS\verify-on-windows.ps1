$ErrorActionPreference = 'Stop'

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$project = Join-Path $root 'MineradioIOS.xcodeproj\project.pbxproj'
$appDir = Join-Path $root 'MineradioIOS'
$plist = Join-Path $appDir 'Info.plist'
$storyboard = Join-Path $appDir 'LaunchScreen.storyboard'
$scheme = Join-Path $root 'MineradioIOS.xcodeproj\xcshareddata\xcschemes\MineradioIOS.xcscheme'
$webAssets = Join-Path $appDir 'WebAssets'
$assetCatalog = Join-Path $appDir 'Assets.xcassets'
$appIconSet = Join-Path $assetCatalog 'AppIcon.appiconset'

function Assert-Exists($path) {
    if (!(Test-Path -LiteralPath $path)) {
        throw "Missing required path: $path"
    }
}

function Assert-Contains($text, $needle, $label) {
    if (!$text.Contains($needle)) {
        throw "Missing ${label}: $needle"
    }
}

function Test-BalancedProjectText($text) {
    $stack = New-Object System.Collections.Generic.Stack[char]
    foreach ($ch in $text.ToCharArray()) {
        if ($ch -eq '{' -or $ch -eq '(') {
            $stack.Push($ch)
        } elseif ($ch -eq '}') {
            if ($stack.Count -eq 0 -or $stack.Pop() -ne '{') { throw 'Unbalanced } in project.pbxproj' }
        } elseif ($ch -eq ')') {
            if ($stack.Count -eq 0 -or $stack.Pop() -ne '(') { throw 'Unbalanced ) in project.pbxproj' }
        }
    }
    if ($stack.Count -ne 0) { throw 'Unclosed delimiter in project.pbxproj' }
}

function Test-SwiftShape($path) {
    $text = Get-Content -LiteralPath $path -Raw
    $stack = New-Object System.Collections.Generic.Stack[char]
    $inString = $false
    $escape = $false
    foreach ($ch in $text.ToCharArray()) {
        if ($inString) {
            if ($escape) { $escape = $false }
            elseif ($ch -eq '\') { $escape = $true }
            elseif ($ch -eq '"') { $inString = $false }
            continue
        }
        if ($ch -eq '"') { $inString = $true }
        elseif ($ch -eq '(' -or $ch -eq '{' -or $ch -eq '[') { $stack.Push($ch) }
        elseif ($ch -eq ')' -or $ch -eq '}' -or $ch -eq ']') {
            if ($stack.Count -eq 0) { throw "Unbalanced $ch in $path" }
            $open = $stack.Pop()
            if (($ch -eq ')' -and $open -ne '(') -or ($ch -eq '}' -and $open -ne '{') -or ($ch -eq ']' -and $open -ne '[')) {
                throw "Mismatched $open/$ch in $path"
            }
        }
    }
    if ($stack.Count -ne 0) { throw "Unclosed delimiter in $path" }
}

Assert-Exists $project
Assert-Exists $plist
Assert-Exists $storyboard
Assert-Exists $scheme
Assert-Exists $webAssets
Assert-Exists $assetCatalog
Assert-Exists $appIconSet
Assert-Exists (Join-Path $webAssets 'index.html')
Assert-Exists (Join-Path $webAssets 'vendor\three.r128.min.js')
Assert-Exists (Join-Path $webAssets 'assets\skull-decimation-points.bin')
Assert-Exists (Join-Path $appIconSet 'Contents.json')
Assert-Exists (Join-Path $appIconSet 'Icon-1024.png')

[xml](Get-Content -LiteralPath $plist -Raw) | Out-Null
[xml](Get-Content -LiteralPath $storyboard -Raw) | Out-Null
[xml](Get-Content -LiteralPath $scheme -Raw) | Out-Null
Get-Content -LiteralPath (Join-Path $assetCatalog 'Contents.json') -Raw | ConvertFrom-Json | Out-Null
Get-Content -LiteralPath (Join-Path $appIconSet 'Contents.json') -Raw | ConvertFrom-Json | Out-Null
Get-Content -LiteralPath (Join-Path $assetCatalog 'AccentColor.colorset\Contents.json') -Raw | ConvertFrom-Json | Out-Null

$projectText = Get-Content -LiteralPath $project -Raw
Test-BalancedProjectText $projectText
Assert-Contains $projectText 'WebAssets in Resources' 'WebAssets resource build phase'
Assert-Contains $projectText 'LaunchScreen.storyboard in Resources' 'LaunchScreen resource build phase'
Assert-Contains $projectText 'Assets.xcassets in Resources' 'asset catalog resource build phase'
Assert-Contains $projectText 'MineradioAPIStub.swift in Sources' 'API stub source build phase'
Assert-Contains $projectText 'productType = "com.apple.product-type.application";' 'iOS app product type'
Assert-Contains $projectText 'INFOPLIST_KEY_UILaunchStoryboardName = LaunchScreen;' 'launch storyboard build setting'
Assert-Contains $projectText 'ASSETCATALOG_COMPILER_APPICON_NAME = AppIcon;' 'app icon build setting'

Get-ChildItem -LiteralPath $appDir -Filter '*.swift' | ForEach-Object {
    Test-SwiftShape $_.FullName
}

$api = Get-Content -LiteralPath (Join-Path $appDir 'MineradioAPIStub.swift') -Raw
Assert-Contains $api 'https://itunes.apple.com/search' 'iTunes search implementation'
Assert-Contains $api 'proxyRemoteAsset' 'cover/audio proxy implementation'

$schemeHandler = Get-Content -LiteralPath (Join-Path $appDir 'MineradioSchemeHandler.swift') -Raw
Assert-Contains $schemeHandler 'SchemeTaskState.shared.start' 'scheme task start tracking'
Assert-Contains $schemeHandler 'DispatchQueue.main.async' 'main queue delivery'

$assetStats = Get-ChildItem -LiteralPath $webAssets -Recurse -File | Measure-Object -Property Length -Sum
$iconStats = Get-ChildItem -LiteralPath $appIconSet -Filter '*.png' | Measure-Object
Write-Host "Swift files:" (Get-ChildItem -LiteralPath $appDir -Filter '*.swift').Count
Write-Host "WebAssets files:" $assetStats.Count
Write-Host "WebAssets bytes:" $assetStats.Sum
Write-Host "AppIcon pngs:" $iconStats.Count
Write-Host 'MineradioIOS Windows-side verification OK'
