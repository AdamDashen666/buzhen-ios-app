import Foundation
import WebKit
import UniformTypeIdentifiers

final class MineradioSchemeHandler: NSObject, WKURLSchemeHandler {
    private let api = MineradioAPIStub()

    func webView(_ webView: WKWebView, start urlSchemeTask: WKURLSchemeTask) {
        SchemeTaskState.shared.start(urlSchemeTask)
        guard let url = urlSchemeTask.request.url else {
            finish(urlSchemeTask, statusCode: 400, mimeType: "application/json", data: Data("{}".utf8))
            return
        }

        if url.path.hasPrefix("/api/") || url.path == "/favicon.ico" {
            api.respond(to: urlSchemeTask)
            return
        }

        serveStaticAsset(for: url, task: urlSchemeTask)
    }

    func webView(_ webView: WKWebView, stop urlSchemeTask: WKURLSchemeTask) {
        SchemeTaskState.shared.stop(urlSchemeTask)
    }

    private func serveStaticAsset(for url: URL, task: WKURLSchemeTask) {
        let requestedPath = normalizedAssetPath(from: url)
        guard let fileURL = fileURLInWebAssets(for: requestedPath),
              let data = try? Data(contentsOf: fileURL) else {
            finish(task, statusCode: 404, mimeType: "text/plain", data: Data("Not found".utf8))
            return
        }

        finish(task, statusCode: 200, mimeType: mimeType(for: fileURL), data: data)
    }

    private func normalizedAssetPath(from url: URL) -> String {
        var path = url.path
        if path.isEmpty || path == "/" { path = "/index.html" }
        path = path.removingPercentEncoding ?? path
        path = path.trimmingCharacters(in: CharacterSet(charactersIn: "/"))

        let parts = path.split(separator: "/").filter { $0 != "." && $0 != ".." }
        return parts.isEmpty ? "index.html" : parts.joined(separator: "/")
    }

    private func fileURLInWebAssets(for requestedPath: String) -> URL? {
        guard let root = Bundle.main.resourceURL?.appendingPathComponent("WebAssets", isDirectory: true) else {
            return nil
        }

        let candidate = root.appendingPathComponent(requestedPath, isDirectory: false).standardizedFileURL
        let rootPath = root.standardizedFileURL.path
        guard candidate.path == rootPath || candidate.path.hasPrefix(rootPath + "/") else {
            return nil
        }
        return FileManager.default.fileExists(atPath: candidate.path) ? candidate : nil
    }

    private func mimeType(for fileURL: URL) -> String {
        if let type = UTType(filenameExtension: fileURL.pathExtension),
           let mime = type.preferredMIMEType {
            return mime
        }

        switch fileURL.pathExtension.lowercased() {
        case "js": return "application/javascript"
        case "json": return "application/json"
        case "svg": return "image/svg+xml"
        case "bin": return "application/octet-stream"
        default: return "application/octet-stream"
        }
    }
}

final class SchemeTaskState {
    static let shared = SchemeTaskState()

    private let lock = NSLock()
    private var active = Set<ObjectIdentifier>()

    func start(_ task: WKURLSchemeTask) {
        lock.lock()
        active.insert(ObjectIdentifier(task as AnyObject))
        lock.unlock()
    }

    func stop(_ task: WKURLSchemeTask) {
        lock.lock()
        active.remove(ObjectIdentifier(task as AnyObject))
        lock.unlock()
    }

    func finish(_ task: WKURLSchemeTask, _ body: () -> Void) {
        lock.lock()
        let identifier = ObjectIdentifier(task as AnyObject)
        guard active.remove(identifier) != nil else {
            lock.unlock()
            return
        }
        lock.unlock()
        body()
    }
}

func finish(_ task: WKURLSchemeTask, statusCode: Int, mimeType: String, data: Data) {
    let complete = {
        SchemeTaskState.shared.finish(task) {
            let textualTypes = [
                "application/json",
                "application/javascript",
                "text/html",
                "text/css",
                "text/plain",
                "image/svg+xml"
            ]
            let contentType = textualTypes.contains(mimeType) ? "\(mimeType); charset=utf-8" : mimeType
            let response = HTTPURLResponse(
                url: task.request.url!,
                statusCode: statusCode,
                httpVersion: "HTTP/1.1",
                headerFields: [
                    "Content-Type": contentType,
                    "Cache-Control": "no-store"
                ]
            )!
            task.didReceive(response)
            task.didReceive(data)
            task.didFinish()
        }
    }

    if Thread.isMainThread {
        complete()
    } else {
        DispatchQueue.main.async(execute: complete)
    }
}
