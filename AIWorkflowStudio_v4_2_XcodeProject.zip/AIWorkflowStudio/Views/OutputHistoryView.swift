import SwiftUI

struct OutputHistoryView: View {
    @EnvironmentObject private var store: AppStore
    @State private var selectedRun: RunRecord?

    var body: some View {
        NavigationStack {
            List {
                Section("当前工作流运行输出") {
                    if store.selectedProjectRunRecords.isEmpty {
                        ContentUnavailableView("暂无输出", systemImage: "tray", description: Text("这里只显示当前工作流自己的输出，切换工作流不会串记录。"))
                    }
                    ForEach(store.selectedProjectRunRecords) { run in
                        Button { selectedRun = run } label: {
                            RunOutputRow(run: run)
                        }
                    }
                }
                Section("当前工作流版本历史") {
                    if store.selectedProjectSnapshots.isEmpty {
                        Text("暂无版本快照。")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    ForEach(store.selectedProjectSnapshots) { snapshot in
                        VStack(alignment: .leading) {
                            Text(snapshot.title).font(.headline)
                            Text("\(snapshot.createdAt.formatted(date: .abbreviated, time: .shortened)) · \(snapshot.note)")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                    }
                }
            }
            .scrollContentBackground(.hidden)
            .studioBackground()
            .navigationTitle("输出历史")
            .sheet(item: $selectedRun) { run in
                NavigationStack {
                    ScrollView {
                        VStack(alignment: .leading, spacing: 18) {
                            GeneratedFilesSection(run: run)

                            Text("最终输出")
                                .font(.title2.bold())
                            Text(run.output.isEmpty ? "暂无最终输出" : run.output)
                                .font(.system(.body, design: .monospaced))
                                .textSelection(.enabled)
                                .frame(maxWidth: .infinity, alignment: .leading)

                            Divider().padding(.vertical, 6)
                            Text("模块输入 / 输出")
                                .font(.title2.bold())
                            ForEach(run.nodeRecords) { node in
                                VStack(alignment: .leading, spacing: 8) {
                                    Label(node.nodeTitle, systemImage: node.kind.icon)
                                        .font(.headline)
                                    DisclosureGroup("输入") {
                                        Text(node.inputPreview.isEmpty ? "无输入记录" : node.inputPreview)
                                            .font(.system(.caption, design: .monospaced))
                                            .textSelection(.enabled)
                                            .frame(maxWidth: .infinity, alignment: .leading)
                                    }
                                    DisclosureGroup("输出") {
                                        Text(node.output.isEmpty ? (node.errorMessage ?? "无输出") : node.output)
                                            .font(.system(.caption, design: .monospaced))
                                            .textSelection(.enabled)
                                            .frame(maxWidth: .infinity, alignment: .leading)
                                    }
                                }
                                .padding()
                                .background(.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                            }
                        }
                        .padding()
                    }
                    .studioBackground()
                    .navigationTitle("输出详情")
                    .toolbar {
                        ShareLink("分享日志", item: LogExportService.markdown(for: run))
                        ShareLink("导出文件 ZIP", item: ZipArchiveService.shareableGeneratedFilesArchive(for: run))
                        ShareLink("分享完整 ZIP", item: ZipArchiveService.shareableRunArchive(for: run))
                    }
                }
            }
        }
    }
}

private struct RunOutputRow: View {
    let run: RunRecord

    private var fileCount: Int {
        ZipArchiveService.generatedFiles(for: run).count
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(run.projectTitle).font(.headline)
            Text("\(run.displayDate) · \(run.status.title) · Token \(run.tokenUsage.total)")
                .font(.caption)
                .foregroundStyle(.secondary)
            Text(run.currentStage)
                .font(.caption2)
                .foregroundStyle(.secondary)
            if fileCount > 0 {
                Label("检测到 \(fileCount) 个可单独导出的文件", systemImage: "doc.badge.arrow.up")
                    .font(.caption2)
                    .foregroundStyle(.green)
            }
        }
    }
}

private struct GeneratedFilesSection: View {
    let run: RunRecord

    private var files: [ZipArchiveService.GeneratedFile] {
        ZipArchiveService.generatedFiles(for: run)
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Label("文件输出", systemImage: "doc.on.doc")
                    .font(.title2.bold())
                Spacer()
                if !files.isEmpty {
                    ShareLink("导出全部文件", item: ZipArchiveService.shareableGeneratedFilesArchive(for: run))
                        .font(.caption.bold())
                }
            }

            if files.isEmpty {
                Text("未检测到可单独导出的文件。建议让格式转换者输出 ```file path=\"xxx.py\"``` 这类文件块；需要完整项目目录时再连接项目打包者。")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .padding()
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(.white.opacity(0.05), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
            } else {
                ForEach(files) { file in
                    HStack(spacing: 12) {
                        Image(systemName: iconName(for: file.path))
                            .font(.title3)
                            .frame(width: 28)
                        VStack(alignment: .leading, spacing: 4) {
                            Text(file.path)
                                .font(.headline)
                                .lineLimit(2)
                            Text("来自：\(file.sourceNodeTitle) · \(file.sourceKindTitle) · \(file.byteCountText)")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                        Spacer()
                        ShareLink("导出", item: ZipArchiveService.shareableGeneratedFile(file, run: run))
                            .font(.caption.bold())
                    }
                    .padding()
                    .background(.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                }
            }
        }
    }

    private func iconName(for path: String) -> String {
        let lower = path.lowercased()
        if lower.hasSuffix(".py") { return "chevron.left.forwardslash.chevron.right" }
        if lower.hasSuffix(".md") || lower.hasSuffix(".txt") { return "doc.text" }
        if lower.hasSuffix(".json") || lower.hasSuffix(".plist") { return "curlybraces" }
        if lower.hasSuffix(".html") || lower.hasSuffix(".css") { return "globe" }
        return "doc"
    }
}
