import SwiftUI
import UIKit

struct WorkflowEditorView: View {
    @EnvironmentObject private var store: AppStore
    @State private var showingLibrary = false
    @State private var selectedNode: WorkflowNode?
    @State private var connectFrom: UUID?
    @State private var dragPoint: CGPoint?
    @State private var zoom: CGFloat = 1.0
    @State private var lastZoom: CGFloat = 1.0
    @State private var nodePositions: [UUID: CGPoint] = [:]
    @State private var dragStartPositions: [UUID: CGPoint] = [:]
    @State private var selectedEdgeID: UUID?
    @State private var edgeAwaitingDeleteID: UUID?

    private let canvasSize = CGSize(width: 2400, height: 1600)
    private let minZoom: CGFloat = 0.55
    private let maxZoom: CGFloat = 1.65

    var body: some View {
        NavigationStack {
            Group {
                if let project = store.selectedProject {
                    GeometryReader { proxy in
                        if proxy.size.width > 720 {
                            canvas(project: project)
                        } else {
                            listEditor(project: project)
                        }
                    }
                } else {
                    ContentUnavailableView("没有项目", systemImage: "folder.badge.plus", description: Text("先在首页新建一个工作流。"))
                }
            }
            .studioBackground()
            .navigationTitle(store.selectedProject?.title ?? "工作流")
            .toolbar {
                ToolbarItemGroup(placement: .topBarTrailing) {
                    Button("添加模块") { showingLibrary = true }
                    Button("AI 自动选择并连线") { store.autoBuildSelectedProject() }
                    Button("一键应用全局默认模型") { store.applyDefaultModelsToSelectedProject() }
                    Button { Task { await store.runSelectedProject() } } label: { Label("运行", systemImage: "play.fill") }
                }
            }
            .sheet(isPresented: $showingLibrary) { ModuleLibrarySheet() }
            .sheet(item: $selectedNode) { node in
                if let project = store.selectedProject {
                    NodeDetailView(projectID: project.id, node: node)
                }
            }
        }
    }

    private func canvas(project: WorkflowProject) -> some View {
        ScrollView([.horizontal, .vertical], showsIndicators: false) {
            ZStack(alignment: .topLeading) {
                edgeLayer(project: project)

                ForEach(project.nodes) { node in
                    let position = localPosition(for: node)
                    NodeCard(
                        node: node,
                        isConnecting: connectFrom == node.id,
                        onInputTap: {
                            if let connectFrom, connectFrom != node.id {
                                store.connect(projectID: project.id, from: connectFrom, to: node.id)
                                self.connectFrom = nil
                                self.dragPoint = nil
                            }
                        },
                        onOutputTap: {
                            connectFrom = node.id
                            dragPoint = CGPoint(x: position.x + 150, y: position.y)
                        },
                        onOutputDragChanged: { value in
                            connectFrom = node.id
                            let start = CGPoint(x: position.x + 104, y: position.y)
                            dragPoint = CGPoint(
                                x: start.x + value.translation.width / max(zoom, 0.1),
                                y: start.y + value.translation.height / max(zoom, 0.1)
                            )
                        },
                        onOutputDragEnded: { value in
                            let start = CGPoint(x: position.x + 104, y: position.y)
                            let endPoint = CGPoint(
                                x: start.x + value.translation.width / max(zoom, 0.1),
                                y: start.y + value.translation.height / max(zoom, 0.1)
                            )
                            if let target = targetNode(at: endPoint, in: project, excluding: node.id) {
                                store.connect(projectID: project.id, from: node.id, to: target.id)
                            }
                            connectFrom = nil
                            dragPoint = nil
                        }
                    )
                    .position(x: position.x, y: position.y)
                    .onTapGesture { selectedNode = node }
                    .simultaneousGesture(nodeMoveGesture(project: project, node: node))
                }
            }
            .frame(width: canvasSize.width, height: canvasSize.height, alignment: .topLeading)
            .scaleEffect(zoom, anchor: .topLeading)
            .frame(width: canvasSize.width * zoom, height: canvasSize.height * zoom, alignment: .topLeading)
            .contentShape(Rectangle())
            .gesture(zoomGesture)
            .background(DeleteKeyReader {
                if let edgeID = selectedEdgeID {
                    store.removeEdge(projectID: project.id, edgeID: edgeID)
                    selectedEdgeID = nil
                    edgeAwaitingDeleteID = nil
                }
            })
            .onAppear { syncNodePositions(project) }
            .onChange(of: project.nodes) { _, _ in syncNodePositions(project) }
        }
        .overlay(alignment: .topLeading) {
            cleanLeftControls(project: project)
                .padding(12)
        }
        .overlay(alignment: .topTrailing) {
            cleanRightControls(project: project)
                .padding(12)
        }
        .overlay(alignment: .bottomLeading) {
            Text("右端口拖到左端口连线 · 长按模块再拖动才会移动 · 点连线选中，再点一次显示删除")
                .font(.caption2)
                .foregroundStyle(.white.opacity(0.72))
                .padding(.horizontal, 12)
                .padding(.vertical, 8)
                .background(.black.opacity(0.26), in: Capsule())
                .padding(12)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
    }

    private func edgeLayer(project: WorkflowProject) -> some View {
        ZStack(alignment: .topLeading) {
            ForEach(project.edges) { edge in
                if let points = edgePoints(edge, in: project) {
                    let selected = selectedEdgeID == edge.id
                    EdgeCurveShape(start: points.start, end: points.end)
                        .stroke(selected ? Color.mint.opacity(0.95) : Color.cyan.opacity(0.68), lineWidth: selected ? 4 : 2.2)
                    EdgeCurveShape(start: points.start, end: points.end)
                        .stroke(Color.white.opacity(0.001), lineWidth: 34)
                        .contentShape(EdgeCurveShape(start: points.start, end: points.end))
                        .onTapGesture {
                            if selectedEdgeID == edge.id {
                                edgeAwaitingDeleteID = edge.id
                            } else {
                                selectedEdgeID = edge.id
                                edgeAwaitingDeleteID = nil
                            }
                        }
                    if edgeAwaitingDeleteID == edge.id {
                        Button(role: .destructive) {
                            store.removeEdge(projectID: project.id, edgeID: edge.id)
                            selectedEdgeID = nil
                            edgeAwaitingDeleteID = nil
                        } label: {
                            Label("删除连线", systemImage: "trash")
                                .font(.caption.bold())
                        }
                        .buttonStyle(.borderedProminent)
                        .controlSize(.small)
                        .position(midpoint(points.start, points.end))
                    }
                }
            }

            if let connectFrom,
               let source = project.nodes.first(where: { $0.id == connectFrom }),
               let dragPoint {
                let sourcePosition = localPosition(for: source)
                EdgeCurveShape(start: CGPoint(x: sourcePosition.x + 104, y: sourcePosition.y), end: dragPoint)
                    .stroke(Color.mint.opacity(0.92), lineWidth: 3)
            }
        }
        .frame(width: canvasSize.width, height: canvasSize.height)
    }

    private func edgePoints(_ edge: WorkflowEdge, in project: WorkflowProject) -> (start: CGPoint, end: CGPoint)? {
        guard let from = project.nodes.first(where: { $0.id == edge.from }),
              let to = project.nodes.first(where: { $0.id == edge.to }) else { return nil }
        let fromPosition = localPosition(for: from)
        let toPosition = localPosition(for: to)
        return (CGPoint(x: fromPosition.x + 104, y: fromPosition.y), CGPoint(x: toPosition.x - 104, y: toPosition.y))
    }

    private func localPosition(for node: WorkflowNode) -> CGPoint {
        nodePositions[node.id] ?? CGPoint(x: CGFloat(node.x), y: CGFloat(node.y))
    }

    private func syncNodePositions(_ project: WorkflowProject) {
        var next = nodePositions
        let ids = Set(project.nodes.map(\.id))
        next = next.filter { ids.contains($0.key) }
        for node in project.nodes where next[node.id] == nil {
            next[node.id] = CGPoint(x: CGFloat(node.x), y: CGFloat(node.y))
        }
        nodePositions = next
    }

    private func nodeMoveGesture(project: WorkflowProject, node: WorkflowNode) -> some Gesture {
        LongPressGesture(minimumDuration: 0.22)
            .sequenced(before: DragGesture(minimumDistance: 1))
            .onChanged { value in
                guard case .second(true, let drag?) = value else { return }
                let start = dragStartPositions[node.id] ?? localPosition(for: node)
                if dragStartPositions[node.id] == nil {
                    dragStartPositions[node.id] = start
                }
                let next = clampedPoint(
                    x: start.x + drag.translation.width / max(zoom, 0.1),
                    y: start.y + drag.translation.height / max(zoom, 0.1)
                )
                nodePositions[node.id] = next
            }
            .onEnded { value in
                defer { dragStartPositions[node.id] = nil }
                guard case .second(true, let drag?) = value else { return }
                let start = dragStartPositions[node.id] ?? localPosition(for: node)
                let next = clampedPoint(
                    x: start.x + drag.translation.width / max(zoom, 0.1),
                    y: start.y + drag.translation.height / max(zoom, 0.1)
                )
                nodePositions[node.id] = next
                store.moveNode(projectID: project.id, nodeID: node.id, x: Double(next.x), y: Double(next.y), persist: true)
            }
    }

    private func clampedPoint(x: CGFloat, y: CGFloat) -> CGPoint {
        CGPoint(x: min(max(x, 110), canvasSize.width - 110), y: min(max(y, 90), canvasSize.height - 90))
    }

    private var zoomGesture: some Gesture {
        MagnificationGesture()
            .onChanged { value in
                let softened = 1 + (value - 1) * 0.20
                zoom = min(max(lastZoom * softened, minZoom), maxZoom)
            }
            .onEnded { _ in
                lastZoom = zoom
            }
    }

    private func cleanLeftControls(project: WorkflowProject) -> some View {
        HStack(spacing: 8) {
            Button(role: .destructive) {
                store.resetWorkflow(projectID: project.id)
                selectedEdgeID = nil
                edgeAwaitingDeleteID = nil
            } label: {
                Label("重置", systemImage: "arrow.counterclockwise")
            }
            Button(role: .destructive) {
                store.removeAllEdges(projectID: project.id)
                selectedEdgeID = nil
                edgeAwaitingDeleteID = nil
            } label: {
                Label("清空连线", systemImage: "link.badge.minus")
            }
        }
        .buttonStyle(.borderedProminent)
        .controlSize(.small)
    }

    private func cleanRightControls(project: WorkflowProject) -> some View {
        HStack(spacing: 8) {
            Text("缩放 \(Int(zoom * 100))%")
                .font(.caption.weight(.semibold))
                .padding(.horizontal, 10)
                .padding(.vertical, 7)
                .background(.black.opacity(0.28), in: Capsule())
            Button("1:1") {
                zoom = 1.0
                lastZoom = 1.0
            }
            Button("一键全局默认模型") {
                store.applyDefaultModels(to: project.id)
            }
        }
        .buttonStyle(.bordered)
        .controlSize(.small)
    }

    private func targetNode(at point: CGPoint, in project: WorkflowProject, excluding sourceID: UUID) -> WorkflowNode? {
        project.nodes
            .filter { $0.id != sourceID }
            .min { lhs, rhs in
                let leftPortL = CGPoint(x: localPosition(for: lhs).x - 104, y: localPosition(for: lhs).y)
                let leftPortR = CGPoint(x: localPosition(for: rhs).x - 104, y: localPosition(for: rhs).y)
                return distance(point, leftPortL) < distance(point, leftPortR)
            }
            .flatMap { candidate in
                let target = CGPoint(x: localPosition(for: candidate).x - 104, y: localPosition(for: candidate).y)
                return distance(point, target) < 90 ? candidate : nil
            }
    }

    private func midpoint(_ a: CGPoint, _ b: CGPoint) -> CGPoint {
        CGPoint(x: (a.x + b.x) / 2, y: (a.y + b.y) / 2)
    }

    private func distance(_ a: CGPoint, _ b: CGPoint) -> CGFloat {
        hypot(a.x - b.x, a.y - b.y)
    }

    private func listEditor(project: WorkflowProject) -> some View {
        List {
            Section("快速操作") {
                Button { store.applyDefaultModels(to: project.id) } label: { Label("一键应用全局默认模型", systemImage: "bolt.badge.checkmark") }
                Button { Task { await store.runSelectedProject() } } label: { Label("运行工作流", systemImage: "play.fill") }
                Button(role: .destructive) { store.resetWorkflow(projectID: project.id) } label: { Label("重置：清除所有模块", systemImage: "arrow.counterclockwise") }
                Button(role: .destructive) { store.removeAllEdges(projectID: project.id) } label: { Label("清空全部连线", systemImage: "link.badge.minus") }
            }
            Section("节点") {
                ForEach(project.nodes) { node in
                    Button { selectedNode = node } label: {
                        VStack(alignment: .leading, spacing: 4) {
                            Label(node.title, systemImage: node.kind.icon)
                            Text(node.kind.summary).font(.caption).foregroundStyle(.secondary)
                        }
                    }
                }
                .onDelete { offsets in
                    for index in offsets { store.removeNode(projectID: project.id, nodeID: project.nodes[index].id) }
                }
            }
            Section("连线") {
                if project.edges.isEmpty {
                    Text("暂无连线。iPhone 小屏建议用 iPad 横屏画布拖端口连线。")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                ForEach(project.edges) { edge in
                    HStack {
                        Text("\(project.nodes.first(where: { $0.id == edge.from })?.title ?? "?") → \(project.nodes.first(where: { $0.id == edge.to })?.title ?? "?")")
                        Spacer()
                        Button(role: .destructive) { store.removeEdge(projectID: project.id, edgeID: edge.id) } label: { Image(systemName: "trash") }
                    }
                }
            }
        }
        .scrollContentBackground(.hidden)
    }
}

struct EdgeCurveShape: Shape {
    var start: CGPoint
    var end: CGPoint

    func path(in rect: CGRect) -> Path {
        var path = Path()
        path.move(to: start)
        path.addCurve(
            to: end,
            control1: CGPoint(x: start.x + 72, y: start.y),
            control2: CGPoint(x: end.x - 72, y: end.y)
        )
        return path
    }
}

struct NodeCard: View {
    var node: WorkflowNode
    var isConnecting: Bool
    var onInputTap: () -> Void
    var onOutputTap: () -> Void
    var onOutputDragChanged: (DragGesture.Value) -> Void
    var onOutputDragEnded: (DragGesture.Value) -> Void

    var body: some View {
        HStack(spacing: 10) {
            port(title: "输入", systemImage: "arrow.down.circle.fill")
                .onTapGesture(perform: onInputTap)
            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    Image(systemName: node.kind.icon)
                    Text(node.title).font(.headline)
                }
                Text(node.kind.summary)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .lineLimit(2)
                Text(node.status.title)
                    .font(.caption2.bold())
                    .padding(.horizontal, 8)
                    .padding(.vertical, 4)
                    .background(.cyan.opacity(0.20), in: Capsule())
                Text("长按拖动")
                    .font(.caption2)
                    .foregroundStyle(.secondary)
            }
            .frame(width: 180, alignment: .leading)
            port(title: "输出", systemImage: "arrow.up.circle.fill")
                .onTapGesture(perform: onOutputTap)
                .gesture(
                    DragGesture(minimumDistance: 0)
                        .onChanged(onOutputDragChanged)
                        .onEnded(onOutputDragEnded)
                )
        }
        .liquidGlass(cornerRadius: 22, glow: isConnecting)
        .scaleEffect(isConnecting ? 1.04 : 1)
    }

    private func port(title: String, systemImage: String) -> some View {
        VStack(spacing: 3) {
            Image(systemName: systemImage)
                .font(.title3)
                .foregroundStyle(.cyan)
                .padding(8)
                .background(.black.opacity(0.24), in: Circle())
                .overlay(Circle().stroke(.cyan.opacity(0.65), lineWidth: 1.5))
            Text(title)
                .font(.caption2)
                .foregroundStyle(.secondary)
        }
        .contentShape(Rectangle())
    }
}

struct DeleteKeyReader: UIViewRepresentable {
    var onDelete: () -> Void

    func makeUIView(context: Context) -> KeyCatcherView {
        let view = KeyCatcherView()
        view.onDelete = onDelete
        DispatchQueue.main.async { view.becomeFirstResponder() }
        return view
    }

    func updateUIView(_ uiView: KeyCatcherView, context: Context) {
        uiView.onDelete = onDelete
        DispatchQueue.main.async { uiView.becomeFirstResponder() }
    }
}

final class KeyCatcherView: UIView {
    var onDelete: (() -> Void)?
    override var canBecomeFirstResponder: Bool { true }
    override var keyCommands: [UIKeyCommand]? {
        [UIKeyCommand(input: UIKeyCommand.inputDelete, modifierFlags: [], action: #selector(deletePressed))]
    }
    @objc private func deletePressed() { onDelete?() }
}
