import Foundation

enum WorkflowAutoBuilder {
    static func build(from project: WorkflowProject) -> WorkflowProject {
        var newProject = project
        let lower = project.userPrompt.lowercased()
        let hasImage = !project.resources.filter { $0.kind == .image }.isEmpty || lower.contains("图片") || lower.contains("截图") || lower.contains("image") || lower.contains("ocr")
        let isCode = lower.contains("代码") || lower.contains("app") || lower.contains("xcode") || lower.contains("swift") || lower.contains("python") || lower.contains("javascript") || lower.contains("网页") || lower.contains("项目")
        let wantsImageGeneration = lower.contains("生成图片") || lower.contains("图标") || lower.contains("插图") || lower.contains("image generation")
        let complex = lower.count > 120 || lower.contains("复杂") || lower.contains("多模型") || lower.contains("投票") || lower.contains("工作流")

        var kinds: [WorkflowNodeKind] = [.start]
        if hasImage { kinds.append(.imageUnderstanding) }
        kinds.append(.planner)
        if complex { kinds.append(.dispatcher) }
        if isCode {
            kinds += [.codeWorker, .codeReviewer, .autoFixer]
        } else {
            kinds += [.worker, .qualityReviewer]
        }
        if wantsImageGeneration { kinds += [.imageGenerator, .visualReviewer] }
        if complex { kinds += [.multiModelVote] }
        kinds += [.aggregator, .logger, .versionSnapshot, .output]

        var seen = Set<WorkflowNodeKind>()
        kinds = kinds.filter { seen.insert($0).inserted }

        var nodesByKind: [WorkflowNodeKind: WorkflowNode] = [:]
        var nodes: [WorkflowNode] = []
        for (index, kind) in kinds.enumerated() {
            var node = WorkflowNode(kind: kind, title: kind.title, x: 150 + Double(index % 4) * 260, y: 180 + Double(index / 4) * 200)
            node.prompt = kind == .custom ? "" : kind.defaultPrompt
            node.maxReturnCount = 0
            node.retryLimit = 0
            node.temperature = kind == .codeReviewer || kind == .qualityReviewer ? 0.1 : 0.3
            nodes.append(node)
            nodesByKind[kind] = node
        }

        func edge(_ from: WorkflowNodeKind, _ to: WorkflowNodeKind, _ condition: EdgeCondition = .always) -> WorkflowEdge? {
            guard let source = nodesByKind[from], let target = nodesByKind[to] else { return nil }
            return WorkflowEdge(from: source.id, to: target.id, condition: condition)
        }

        var edges: [WorkflowEdge] = []
        if hasImage {
            if let e = edge(.start, .imageUnderstanding) { edges.append(e) }
            if let e = edge(.imageUnderstanding, .planner) { edges.append(e) }
        } else if let e = edge(.start, .planner) {
            edges.append(e)
        }

        if complex {
            if let e = edge(.planner, .dispatcher) { edges.append(e) }
            if isCode {
                if let e = edge(.dispatcher, .codeWorker) { edges.append(e) }
            } else if let e = edge(.dispatcher, .worker) {
                edges.append(e)
            }
            if wantsImageGeneration, let e = edge(.dispatcher, .imageGenerator) { edges.append(e) }
        } else {
            if isCode {
                if let e = edge(.planner, .codeWorker) { edges.append(e) }
            } else if let e = edge(.planner, .worker) {
                edges.append(e)
            }
            if wantsImageGeneration, let e = edge(.planner, .imageGenerator) { edges.append(e) }
        }

        if isCode {
            if let e = edge(.codeWorker, .codeReviewer) { edges.append(e) }
            if let e = edge(.codeReviewer, .autoFixer, .failed) { edges.append(e) }
            if let e = edge(.autoFixer, .codeReviewer) { edges.append(e) }
            if let e = edge(.codeReviewer, .aggregator, .passed) { edges.append(e) }
        } else {
            if let e = edge(.worker, .qualityReviewer) { edges.append(e) }
            if let e = edge(.qualityReviewer, .aggregator, .passed) { edges.append(e) }
            if let e = edge(.qualityReviewer, .worker, .failed) { edges.append(e) }
        }

        if wantsImageGeneration {
            if let e = edge(.imageGenerator, .visualReviewer) { edges.append(e) }
            if let e = edge(.visualReviewer, .aggregator, .passed) { edges.append(e) }
        }

        if complex {
            if let e = edge(.aggregator, .multiModelVote) { edges.append(e) }
            if let e = edge(.multiModelVote, .logger) { edges.append(e) }
        } else if let e = edge(.aggregator, .logger) {
            edges.append(e)
        }
        if let e = edge(.logger, .versionSnapshot) { edges.append(e) }
        if let e = edge(.versionSnapshot, .output) { edges.append(e) }

        newProject.nodes = nodes
        newProject.edges = deduplicated(edges)
        newProject.updatedAt = Date()
        return newProject
    }

    private static func deduplicated(_ edges: [WorkflowEdge]) -> [WorkflowEdge] {
        var seen = Set<String>()
        return edges.filter { edge in
            let key = "\(edge.from.uuidString)-\(edge.to.uuidString)-\(edge.condition.rawValue)"
            return seen.insert(key).inserted
        }
    }
}
