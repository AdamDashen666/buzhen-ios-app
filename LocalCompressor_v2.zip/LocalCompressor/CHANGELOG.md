# Changelog

## v1.0

- Created initial local iPadOS compression app.
- Added multiple file/folder selection.
- Added recursive size scanning before compression.
- Added file type analysis.
- Added estimated output size for ZIP, LZFSE, and LZMA modes.
- Added local ZIP output.
- Added custom Apple LZFSE/LZMA `.lcz` archive output.
- Added ShareLink export.
- Added adaptive SwiftUI layout for iPad and iPhone.
