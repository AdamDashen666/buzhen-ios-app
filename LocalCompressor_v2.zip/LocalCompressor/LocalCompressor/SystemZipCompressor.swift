import Foundation

struct SystemZipCompressor {
    static func createZip(from stagedDirectory: URL, outputURL: URL) throws {
        let manager = FileManager.default
        if manager.fileExists(atPath: outputURL.path) {
            try manager.removeItem(at: outputURL)
        }

        var coordinationError: NSError?
        var copyError: Error?
        let coordinator = NSFileCoordinator(filePresenter: nil)

        coordinator.coordinate(readingItemAt: stagedDirectory, options: .forUploading, error: &coordinationError) { zipURL in
            do {
                try manager.copyItem(at: zipURL, to: outputURL)
            } catch {
                copyError = error
            }
        }

        if let coordinationError { throw coordinationError }
        if let copyError { throw copyError }
    }
}
