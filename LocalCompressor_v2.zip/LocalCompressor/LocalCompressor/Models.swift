import Foundation

struct SelectedItem: Identifiable, Hashable {
    let id = UUID()
    let url: URL
    let displayName: String
    let isDirectory: Bool
    let fileCount: Int
    let folderCount: Int
    let byteSize: Int64
}

struct ScanSummary {
    var items: [SelectedItem]
    var totalBytes: Int64
    var fileCount: Int
    var folderCount: Int
    var categoryBytes: [FileCategory: Int64]

    static let empty = ScanSummary(items: [], totalBytes: 0, fileCount: 0, folderCount: 0, categoryBytes: [:])
}

enum FileCategory: String, CaseIterable, Codable, Hashable {
    case text
    case officeOrPDF
    case archive
    case compressedImage
    case rawImage
    case video
    case audio
    case database
    case other

    var title: String {
        switch self {
        case .text: return "文本 / 代码"
        case .officeOrPDF: return "文档 / PDF"
        case .archive: return "压缩包"
        case .compressedImage: return "JPG / PNG / HEIC"
        case .rawImage: return "RAW / BMP / TIFF"
        case .video: return "视频"
        case .audio: return "音频"
        case .database: return "数据库 / 日志"
        case .other: return "其他"
        }
    }
}

enum CompressionProfile: String, CaseIterable, Identifiable, Codable {
    case zipCompatible
    case appleLZFSE
    case appleLZMA

    var id: String { rawValue }

    var title: String {
        switch self {
        case .zipCompatible: return "兼容 ZIP"
        case .appleLZFSE: return "Apple LZFSE"
        case .appleLZMA: return "最小 LZMA"
        }
    }

    var subtitle: String {
        switch self {
        case .zipCompatible:
            return "通用 .zip，最适合分享给别人"
        case .appleLZFSE:
            return "Apple 平台友好，速度和体积平衡"
        case .appleLZMA:
            return "压缩率最高，但更慢、更吃内存"
        }
    }

    var fileExtension: String {
        switch self {
        case .zipCompatible: return "zip"
        case .appleLZFSE: return "lcz"
        case .appleLZMA: return "lcz"
        }
    }

    var algorithmName: String {
        switch self {
        case .zipCompatible: return "zip"
        case .appleLZFSE: return "lzfse"
        case .appleLZMA: return "lzma"
        }
    }
}

struct EstimateResult: Identifiable, Hashable {
    let id = UUID()
    let profile: CompressionProfile
    let estimatedBytes: Int64
    let ratio: Double
}

struct CompressionOptions: Codable, Equatable {
    var skipHiddenFiles: Bool = true
    var keepTopLevelFolder: Bool = true
    var outputName: String = "Compressed"
}
