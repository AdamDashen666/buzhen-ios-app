import SwiftUI

@main
struct LocalCompressorApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
