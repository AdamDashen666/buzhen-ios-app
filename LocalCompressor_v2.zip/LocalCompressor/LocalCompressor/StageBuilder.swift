import Foundation

struct StageBuilder {
    static func createStage(from urls: [URL], options: CompressionOptions) throws -> URL {
        let tempRoot = FileManager.default.temporaryDirectory
            .appendingPathComponent("LocalCompressor-")
            .appendingPathComponent(UUID().uuidString, isDirectory: true)
        let stage = tempRoot.appendingPathComponent(options.outputName.isEmpty ? "Compressed" : options.outputName, isDirectory: true)
        try FileManager.default.createDirectory(at: stage, withIntermediateDirectories: true)

        for source in urls {
            let didAccess = source.startAccessingSecurityScopedResource()
            defer { if didAccess { source.stopAccessingSecurityScopedResource() } }

            let destination = uniqueDestination(for: source.lastPathComponent, in: stage)
            try copyItem(at: source, to: destination, skipHiddenFiles: options.skipHiddenFiles)
        }

        return stage
    }

    private static func uniqueDestination(for name: String, in directory: URL) -> URL {
        let manager = FileManager.default
        let baseURL = directory.appendingPathComponent(name)
        if !manager.fileExists(atPath: baseURL.path) { return baseURL }

        let nsName = name as NSString
        let basename = nsName.deletingPathExtension
        let ext = nsName.pathExtension

        for index in 2...9999 {
            let newName = ext.isEmpty ? "\(basename) \(index)" : "\(basename) \(index).\(ext)"
            let candidate = directory.appendingPathComponent(newName)
            if !manager.fileExists(atPath: candidate.path) { return candidate }
        }
        return directory.appendingPathComponent("\(UUID().uuidString)-\(name)")
    }

    private static func copyItem(at source: URL, to destination: URL, skipHiddenFiles: Bool) throws {
        let values = try source.resourceValues(forKeys: [.isDirectoryKey, .isRegularFileKey])
        let name = source.lastPathComponent
        if skipHiddenFiles && name.hasPrefix(".") { return }

        if values.isDirectory == true {
            try FileManager.default.createDirectory(at: destination, withIntermediateDirectories: true)
            let children = try FileManager.default.contentsOfDirectory(
                at: source,
                includingPropertiesForKeys: [.isDirectoryKey, .isRegularFileKey],
                options: skipHiddenFiles ? [.skipsHiddenFiles] : []
            )
            for child in children {
                try copyItem(
                    at: child,
                    to: destination.appendingPathComponent(child.lastPathComponent),
                    skipHiddenFiles: skipHiddenFiles
                )
            }
        } else {
            try FileManager.default.copyItem(at: source, to: destination)
        }
    }
}
