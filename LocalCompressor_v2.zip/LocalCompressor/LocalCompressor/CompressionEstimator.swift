import Foundation

struct CompressionEstimator {
    static func estimates(for summary: ScanSummary) -> [EstimateResult] {
        CompressionProfile.allCases.map { profile in
            let estimate = estimatedBytes(for: summary, profile: profile)
            let ratio = summary.totalBytes == 0 ? 1 : Double(estimate) / Double(summary.totalBytes)
            return EstimateResult(profile: profile, estimatedBytes: estimate, ratio: ratio)
        }
    }

    static func estimatedBytes(for summary: ScanSummary, profile: CompressionProfile) -> Int64 {
        guard summary.totalBytes > 0 else { return 0 }
        var estimated: Double = 0

        for category in FileCategory.allCases {
            let bytes = Double(summary.categoryBytes[category, default: 0])
            estimated += bytes * ratio(for: category, profile: profile)
        }

        // Container overhead: file headers, paths, manifest.
        let overhead = Double(max(4096, summary.fileCount * 256 + summary.folderCount * 128))
        return Int64(max(0, estimated + overhead).rounded())
    }

    private static func ratio(for category: FileCategory, profile: CompressionProfile) -> Double {
        switch profile {
        case .zipCompatible:
            switch category {
            case .text: return 0.36
            case .officeOrPDF: return 0.92
            case .archive: return 1.00
            case .compressedImage: return 0.97
            case .rawImage: return 0.54
            case .video: return 0.99
            case .audio: return 0.98
            case .database: return 0.52
            case .other: return 0.72
            }
        case .appleLZFSE:
            switch category {
            case .text: return 0.29
            case .officeOrPDF: return 0.90
            case .archive: return 0.99
            case .compressedImage: return 0.96
            case .rawImage: return 0.48
            case .video: return 0.99
            case .audio: return 0.98
            case .database: return 0.45
            case .other: return 0.64
            }
        case .appleLZMA:
            switch category {
            case .text: return 0.20
            case .officeOrPDF: return 0.88
            case .archive: return 0.99
            case .compressedImage: return 0.95
            case .rawImage: return 0.40
            case .video: return 0.99
            case .audio: return 0.98
            case .database: return 0.36
            case .other: return 0.56
            }
        }
    }
}
