import Foundation

struct LocalArchiveManifest: Codable {
    var format: String = "LocalCompressor Archive"
    var version: Int = 1
    var createdAt: Date = Date()
    var entries: [LocalArchiveEntry]
}

struct LocalArchiveEntry: Codable {
    var path: String
    var isDirectory: Bool
    var size: Int64
    var offset: Int64
}

struct LocalArchiveCompressor {
    static func createArchive(from stagedDirectory: URL, outputURL: URL, profile: CompressionProfile) throws {
        let tempDirectory = FileManager.default.temporaryDirectory.appendingPathComponent("LocalArchive-\(UUID().uuidString)", isDirectory: true)
        try FileManager.default.createDirectory(at: tempDirectory, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: tempDirectory) }

        let payloadURL = tempDirectory.appendingPathComponent("payload.bin")
        FileManager.default.createFile(atPath: payloadURL.path, contents: nil)
        let payloadHandle = try FileHandle(forWritingTo: payloadURL)
        defer { try? payloadHandle.close() }

        var entries: [LocalArchiveEntry] = []
        var currentOffset: Int64 = 0

        guard let enumerator = FileManager.default.enumerator(
            at: stagedDirectory,
            includingPropertiesForKeys: [.isDirectoryKey, .isRegularFileKey, .fileSizeKey],
            options: [.skipsPackageDescendants]
        ) else {
            throw CocoaError(.fileReadUnknown)
        }

        for case let fileURL as URL in enumerator {
            let values = try fileURL.resourceValues(forKeys: [.isDirectoryKey, .isRegularFileKey, .fileSizeKey])
            let relativePath = relativePath(from: stagedDirectory, to: fileURL)
            if values.isDirectory == true {
                entries.append(LocalArchiveEntry(path: relativePath, isDirectory: true, size: 0, offset: currentOffset))
            } else {
                let fileSize = Int64(values.fileSize ?? 0)
                entries.append(LocalArchiveEntry(path: relativePath, isDirectory: false, size: fileSize, offset: currentOffset))
                let inputHandle = try FileHandle(forReadingFrom: fileURL)
                while true {
                    let data = try inputHandle.read(upToCount: 1024 * 1024) ?? Data()
                    if data.isEmpty { break }
                    try payloadHandle.write(contentsOf: data)
                    currentOffset += Int64(data.count)
                }
                try inputHandle.close()
            }
        }

        try payloadHandle.close()

        let manifest = LocalArchiveManifest(entries: entries)
        let manifestData = try JSONEncoder.pretty.encode(manifest)

        let packURL = tempDirectory.appendingPathComponent("archive.pack")
        FileManager.default.createFile(atPath: packURL.path, contents: nil)
        let packHandle = try FileHandle(forWritingTo: packURL)
        defer { try? packHandle.close() }

        try packHandle.write(contentsOf: Data("LCZ1".utf8))
        try packHandle.write(contentsOf: UInt64(manifestData.count).littleEndianData)
        try packHandle.write(contentsOf: manifestData)
        let payloadData = try Data(contentsOf: payloadURL, options: [.mappedIfSafe])
        try packHandle.write(contentsOf: payloadData)
        try packHandle.close()

        let packData = try Data(contentsOf: packURL, options: [.mappedIfSafe])
        let compressedData = try compress(data: packData, profile: profile)

        var output = Data()
        output.append(Data("LCZA".utf8))
        output.append(UInt8(profile == .appleLZMA ? 2 : 1))
        output.append(compressedData)

        if FileManager.default.fileExists(atPath: outputURL.path) {
            try FileManager.default.removeItem(at: outputURL)
        }
        try output.write(to: outputURL, options: [.atomic])
    }

    private static func compress(data: Data, profile: CompressionProfile) throws -> Data {
        let nsData = data as NSData
        switch profile {
        case .appleLZFSE:
            return try nsData.compressed(using: .lzfse) as Data
        case .appleLZMA:
            return try nsData.compressed(using: .lzma) as Data
        case .zipCompatible:
            return data
        }
    }

    private static func relativePath(from root: URL, to child: URL) -> String {
        let rootPath = root.standardizedFileURL.path
        let childPath = child.standardizedFileURL.path
        guard childPath.hasPrefix(rootPath) else { return child.lastPathComponent }
        let index = childPath.index(childPath.startIndex, offsetBy: rootPath.count)
        return String(childPath[index...]).trimmingCharacters(in: CharacterSet(charactersIn: "/"))
    }
}

private extension JSONEncoder {
    static var pretty: JSONEncoder {
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        encoder.dateEncodingStrategy = .iso8601
        return encoder
    }
}

private extension UInt64 {
    var littleEndianData: Data {
        var value = self.littleEndian
        return Data(bytes: &value, count: MemoryLayout<UInt64>.size)
    }
}
