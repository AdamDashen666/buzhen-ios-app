import Foundation

enum Formatters {
    static let bytes: ByteCountFormatter = {
        let formatter = ByteCountFormatter()
        formatter.allowedUnits = [.useKB, .useMB, .useGB, .useTB]
        formatter.countStyle = .file
        formatter.includesUnit = true
        formatter.isAdaptive = true
        return formatter
    }()

    static func byteString(_ bytes: Int64) -> String {
        Self.bytes.string(fromByteCount: bytes)
    }

    static func percent(_ value: Double) -> String {
        let clamped = max(0, min(1, value))
        return "\(Int((clamped * 100).rounded()))%"
    }

    static func timestamp() -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyyMMdd-HHmmss"
        return formatter.string(from: Date())
    }
}
