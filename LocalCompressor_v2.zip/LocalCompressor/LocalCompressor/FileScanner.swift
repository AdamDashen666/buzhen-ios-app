import Foundation

struct FileScanner {
    static func scan(urls: [URL]) throws -> ScanSummary {
        var items: [SelectedItem] = []
        var totalBytes: Int64 = 0
        var totalFiles = 0
        var totalFolders = 0
        var categoryBytes: [FileCategory: Int64] = [:]

        for url in urls {
            let didAccess = url.startAccessingSecurityScopedResource()
            defer { if didAccess { url.stopAccessingSecurityScopedResource() } }

            let isDirectory = (try? url.resourceValues(forKeys: [.isDirectoryKey]).isDirectory) ?? false
            let result = try scanSingleURL(url)

            items.append(
                SelectedItem(
                    url: url,
                    displayName: url.lastPathComponent,
                    isDirectory: isDirectory,
                    fileCount: result.fileCount,
                    folderCount: result.folderCount,
                    byteSize: result.bytes
                )
            )

            totalBytes += result.bytes
            totalFiles += result.fileCount
            totalFolders += result.folderCount

            for (category, bytes) in result.categoryBytes {
                categoryBytes[category, default: 0] += bytes
            }
        }

        return ScanSummary(items: items, totalBytes: totalBytes, fileCount: totalFiles, folderCount: totalFolders, categoryBytes: categoryBytes)
    }

    private static func scanSingleURL(_ url: URL) throws -> (bytes: Int64, fileCount: Int, folderCount: Int, categoryBytes: [FileCategory: Int64]) {
        let resourceValues = try url.resourceValues(forKeys: [.isDirectoryKey, .fileSizeKey])
        if resourceValues.isDirectory == true {
            return try scanDirectory(url)
        } else {
            let size = Int64(resourceValues.fileSize ?? 0)
            return (size, 1, 0, [category(for: url): size])
        }
    }

    private static func scanDirectory(_ directory: URL) throws -> (bytes: Int64, fileCount: Int, folderCount: Int, categoryBytes: [FileCategory: Int64]) {
        var bytes: Int64 = 0
        var fileCount = 0
        var folderCount = 1
        var categoryBytes: [FileCategory: Int64] = [:]

        guard let enumerator = FileManager.default.enumerator(
            at: directory,
            includingPropertiesForKeys: [.isDirectoryKey, .isRegularFileKey, .fileSizeKey],
            options: [.skipsPackageDescendants]
        ) else {
            return (0, 0, 1, [:])
        }

        for case let fileURL as URL in enumerator {
            let values = try fileURL.resourceValues(forKeys: [.isDirectoryKey, .isRegularFileKey, .fileSizeKey])
            if values.isDirectory == true {
                folderCount += 1
            } else if values.isRegularFile == true || values.isRegularFile == nil {
                let size = Int64(values.fileSize ?? 0)
                bytes += size
                fileCount += 1
                categoryBytes[category(for: fileURL), default: 0] += size
            }
        }

        return (bytes, fileCount, folderCount, categoryBytes)
    }

    static func category(for url: URL) -> FileCategory {
        let ext = url.pathExtension.lowercased()
        let text = ["txt", "md", "json", "xml", "csv", "html", "css", "js", "ts", "swift", "py", "java", "c", "cpp", "h", "log", "rtf", "yaml", "yml", "sql"]
        let office = ["pdf", "doc", "docx", "ppt", "pptx", "xls", "xlsx", "pages", "numbers", "key"]
        let archives = ["zip", "rar", "7z", "tar", "gz", "bz2", "xz", "lzfse", "lzma", "lcz", "ipa", "apk"]
        let compressedImages = ["jpg", "jpeg", "png", "heic", "heif", "webp", "gif", "avif"]
        let rawImages = ["raw", "dng", "cr2", "nef", "arw", "bmp", "tif", "tiff", "psd"]
        let videos = ["mp4", "mov", "m4v", "mkv", "avi", "webm", "hevc"]
        let audio = ["mp3", "m4a", "aac", "wav", "flac", "aiff", "ogg"]
        let database = ["sqlite", "sqlite3", "db", "realm", "trace", "plist"]

        if text.contains(ext) { return .text }
        if office.contains(ext) { return .officeOrPDF }
        if archives.contains(ext) { return .archive }
        if compressedImages.contains(ext) { return .compressedImage }
        if rawImages.contains(ext) { return .rawImage }
        if videos.contains(ext) { return .video }
        if audio.contains(ext) { return .audio }
        if database.contains(ext) { return .database }
        return .other
    }
}
