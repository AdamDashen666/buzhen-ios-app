import Foundation

struct CompressionService {
    static func compress(urls: [URL], profile: CompressionProfile, options: CompressionOptions) throws -> URL {
        let outputDirectory = try outputDirectoryURL()
        let safeName = sanitizedFileName(options.outputName.isEmpty ? "Compressed" : options.outputName)
        let outputName = "\(safeName)-\(profile.algorithmName)-\(Formatters.timestamp()).\(profile.fileExtension)"
        let outputURL = outputDirectory.appendingPathComponent(outputName)

        let stage = try StageBuilder.createStage(from: urls, options: options)
        defer {
            let tempParent = stage.deletingLastPathComponent()
            try? FileManager.default.removeItem(at: tempParent)
        }

        switch profile {
        case .zipCompatible:
            try SystemZipCompressor.createZip(from: stage, outputURL: outputURL)
        case .appleLZFSE, .appleLZMA:
            try LocalArchiveCompressor.createArchive(from: stage, outputURL: outputURL, profile: profile)
        }

        return outputURL
    }

    private static func outputDirectoryURL() throws -> URL {
        let documents = try FileManager.default.url(
            for: .documentDirectory,
            in: .userDomainMask,
            appropriateFor: nil,
            create: true
        )
        let output = documents.appendingPathComponent("LocalCompressor Outputs", isDirectory: true)
        try FileManager.default.createDirectory(at: output, withIntermediateDirectories: true)
        return output
    }

    private static func sanitizedFileName(_ name: String) -> String {
        let invalid = CharacterSet(charactersIn: "/\\?%*|\"<>:")
        return name.components(separatedBy: invalid).joined(separator: "-").trimmingCharacters(in: .whitespacesAndNewlines)
    }
}
