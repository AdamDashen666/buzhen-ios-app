# Local Compressor v1

A local iPadOS SwiftUI compression tool.

## Features

- Select multiple files and folders with the iPadOS file picker.
- Recursively scan folder size before compression.
- Show total original size, file count, folder count, and file type breakdown.
- Show estimated compressed size for:
  - Compatible ZIP
  - Apple LZFSE local archive
  - Apple LZMA local archive
- Compress locally on device.
- Save output into the app's Documents folder and export with ShareLink.

## Important notes

- ZIP output is the safest option for sharing with other people.
- LZFSE/LZMA output uses a custom `.lcz` container. It is designed for this app, not universal unzip tools.
- Already-compressed files such as MP4, JPG, HEIC, MP3, ZIP, and PDF usually cannot shrink much with lossless compression.
- LZMA may produce a smaller file, but it is slower and can use more memory.
- This v1 focuses on lossless compression. Extreme shrinking of video/images requires lossy transcoding, which is intentionally not enabled in this v1.

## Build

1. Open `LocalCompressor.xcodeproj` in Xcode.
2. Choose an iPad/iPhone simulator or your device.
3. Set your signing team if needed.
4. Build and run.

## Files

- `ContentView.swift` – adaptive SwiftUI interface.
- `FileScanner.swift` – recursive size and type scanning.
- `CompressionEstimator.swift` – estimated compressed size calculation.
- `SystemZipCompressor.swift` – compatible ZIP output using Apple file coordination.
- `LocalArchiveCompressor.swift` – custom LZFSE/LZMA local archive output.
