# Changelog

## v1.4.3

- 修复 iPadOS 台前调度 / 窗口化无法尽量贴满窗口的问题。
- 新增 LaunchScreen.storyboard，降低 iPad letterbox / 尺寸识别异常风险。
- 新增 WindowSizingSupport.swift，设置 iPad 窗口最小/最大尺寸限制。
- 根视图改为忽略容器安全区，移除常规布局外层边距。
- AI navigate 改为 App 原生 WKWebView 加载，不再用网页 JS 直接跳转。
- WKNavigationDelegate 和 window.open 全面拦截外部 App scheme。
- 版本更新到 1.4.3 / build 10。

# CHANGELOG

## v1.4.2

- 修复 iPadOS 台前调度/窗口化 App 拉伸适配。
- 保持 `UIRequiresFullScreen=false`，支持窗口化和多 Scene。
- 背景改为单一深色，移除过亮蓝色渐变感。
- UI 调整为更简洁现代的低亮度玻璃风。
- 动画改为更自然的非线性 spring。
- 启动和新建页面默认空白页，不再默认 Google。
- Agent 设任务前会先扫描当前页面再规划。
- Agent 支持每轮动态修改当前/后续步骤。
- Agent 支持从头重新规划任务。
- 全部任务完成后新增最终验收检查。
- 最终验收失败会自动追加缺失步骤并继续执行。
- 移除敏感操作确认功能和设置项。
- 直接输入链接、navigate、createTab 不再触发确认。
- 新增直接修改网页 action：setText / setHTML / setStyle / modifyPage。
- 修复“去抖音搜索 macbook”误打开 iPad 抖音 App：阻止外部 scheme，规整为 Douyin Web 搜索 URL。

## v1.4

- 标签页重构为分组。
- 一个分组支持多个页面和多个任务。
- AI 可创建/切换页面，适合跨网页任务。
- 新增键盘动作。
