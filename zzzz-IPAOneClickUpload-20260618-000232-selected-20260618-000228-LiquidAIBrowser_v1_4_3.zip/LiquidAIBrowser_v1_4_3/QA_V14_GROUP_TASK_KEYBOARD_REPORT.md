# LiquidAIBrowser v1.4 修复报告

## 用户反馈

1. “标签页”应改为“分组”。
2. 一个分组可以有多个任务。
3. 每个任务可以根据需要使用多个页面。
4. AI 可以自己创建新的页面，并在两个页面之间来回切换。
5. AI 拆任务不够详细，需要把每个点击、输入、滚动、检查都拆成单独步骤。
6. 每一步完成后要重新检查是否满足要求。
7. 动画太僵硬，需要更接近苹果系统的非线性丝滑动效。
8. AI 要有键盘输入能力。

## 已完成修改

### 1. 分组架构

新增 `BrowserGroup`：

- `id`
- `name`
- `createdAt`
- `updatedAt`
- `displayName`

`BrowserTab` 新增：

- `groupID`

`AgentTask` 新增：

- `groupID`
- `workingTabIDs`
- `goalAnalysis`

### 2. 多页面任务

`BrowserStore` 新增：

- `groups`
- `selectedGroupID`
- `selectedGroup`
- `selectedGroupTabs`
- `selectedGroupTasks`
- `createGroup`
- `renameGroup`
- `selectGroup`
- `closeGroup`
- `createTabForTask`
- `switchTask`
- `tabsSummary`

任务现在归属于分组，并且可以把多个页面加入 `workingTabIDs`。

### 3. Agent 跨页面动作

`AgentEngine` 新增浏览器级动作处理：

- `createTab`
- `openTab`
- `switchTab`

AI 返回这些动作时，不再交给网页 JS，而是由原生层创建/切换 `WKWebView` 页面。

### 4. 键盘动作

JS bridge 新增：

- `keyPress`
- `pressEnter`
- `pressTab`
- `keyboardShortcut`
- `typeText`

实现方式：

- 对目标元素 focus。
- 派发 `keydown / keypress / keyup`。
- `pressEnter` 会尝试提交表单。
- `pressTab` 会在可聚焦元素之间移动焦点。
- `typeText` 会逐字输入并触发 `input/change`。

### 5. 详细任务规划

`makePlan` prompt 已重写：

- 先输出 `goalAnalysis`。
- 再输出动作级步骤。
- 每个点击、输入、按键、滚动、切换页面、创建页面、等待、检查都要求拆成独立步骤。
- 上限从 12 步提升到 24 步。

### 6. 每步后检查

`decide` prompt 已重写：

- 每轮只执行一个最小动作。
- 执行后重新读取页面。
- 必须检查步骤是否满足，再返回 `completedStepIndexes`。

### 7. UI 修改

- 侧栏从“标签页列表”改成“分组列表”。
- 当前分组展开后显示该分组内页面。
- 任务卡显示分组名和参与页面数量。
- 展开任务卡可查看最终目标分析和参与页面。
- 设置页仍保持独立页面。

### 8. 动画优化

- 全局动画改成 `Animation.spring(response: 0.34, dampingFraction: 0.82, blendDuration: 0.16)`。
- 分组展开、页面出现/移除、任务面板开关均接入非线性 spring。
- 保留 v1.3.2 的 ProMotion 相关配置。

## 已做静态检查

- `Info.plist` 通过 `plutil -lint`。
- Agent Bridge JS 通过 `node --check`。
- Xcode project 文件仍包含所有 Swift 源文件引用。
- 版本号更新到 1.4 / build 7。

## 仍需真机验证

- Xcode clean build。
- iPadOS 真机全屏显示。
- 同一分组创建多个页面并由 AI 切换。
- AI 键盘动作在真实网站输入框中的表现。
- 跨页面任务的日志和 PDF 报告是否满足预期。
