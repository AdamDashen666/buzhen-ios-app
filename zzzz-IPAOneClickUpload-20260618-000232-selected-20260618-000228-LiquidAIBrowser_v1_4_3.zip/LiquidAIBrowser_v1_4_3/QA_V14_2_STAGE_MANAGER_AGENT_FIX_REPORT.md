# LiquidAIBrowser v1.4.2 修复报告

## 修复范围

本版针对用户反馈集中修复：iPadOS 台前调度/窗口化拉伸、UI 过亮和老旧、初始页面、Agent 任务前识别页面、动态重规划、最终验收、取消敏感确认、直接网页跳转，以及抖音搜索误打开 iPad 抖音 App 的问题。

## 关键修复

### 1. iPadOS 台前调度 / 窗口化
- 保持 `UIRequiresFullScreen=false`。
- 保持 `UIApplicationSupportsMultipleScenes=true`。
- 保持 iPhone/iPad 通用目标 `TARGETED_DEVICE_FAMILY=1,2`。
- 主界面改为响应式窗口布局，避免固定全屏假设。
- 缩小侧栏和右侧任务面板的窗口占比。
- 主内容区域优先填满当前 Stage Manager 窗口。

### 2. UI 视觉重做
- 背景改为单一深色，不再使用高亮蓝色渐变。
- 玻璃卡片降低模糊、阴影、边框强度。
- 选中态改为低亮度白色层，不再大面积蓝色高亮。
- 动画改为更自然的非线性 spring。

### 3. 初始页面
- 启动不再默认打开 Google。
- 新建页面默认 `about:blank`。
- 没有页面时显示空白页提示。

### 4. 任务前先识别页面
- Agent 开始规划前会先读取当前活动页面 DOM/文本/元素坐标。
- 日志中会记录“开始任务前先扫描当前活动页面”。
- 规划 prompt 强调不能盲目操作。

### 5. 动态重规划
- `AgentDecision` 支持 `updatedSteps` 和 `restartPlan`。
- 每轮判断后，AI 可以修改当前/后续步骤。
- 如果发现方向错了，AI 可以从头重规划任务。

### 6. 每步检查与最终验收
- 每轮只执行一个最小动作。
- 完成步骤后必须重新读取页面检查。
- 全部步骤完成后新增最终验收模型调用。
- 最终验收失败会自动追加缺失步骤并继续执行。

### 7. 取消敏感确认
- 移除“敏感操作需要确认”设置项。
- 本地不再弹出敏感操作确认框。
- 直接输入网址、navigate、createTab 不会被视为敏感操作。

### 8. 直接修改网页能力
新增 action：
- `setText`
- `setHTML`
- `setStyle`
- `modifyPage`

### 9. 抖音搜索误打开 App 修复
- 阻止 WebView 打开所有外部 App scheme。
- 禁止 `douyin://`、`snssdk://`、`aweme://`、`itms-apps://` 自动跳出 App。
- Agent 输入“去抖音搜索 macbook”时，会规整为网页链接：`https://www.douyin.com/search/macbook`。
- JS navigate 也加入 URL sanitization，防止模型直接传 App scheme。

## 静态检查

- Info.plist：OK
- Swift 语法 parse：OK
- Agent Bridge JS node --check：OK
- 外部 App 自动打开入口：已移除
- 敏感确认设置残留：已清理
- 版本号：1.4.2 / build 9

## 未真机验证

由于当前环境没有 Xcode/iPad 真机，以下仍需在设备上验证：
- Stage Manager 窗口拖动缩放表现。
- 抖音网页是否稳定阻止跳 App。
- 真正视觉/坐标动作在复杂网页上的成功率。
- iOS 27 Liquid Glass 编译和效果。
