# v1.3.2 UI / 全屏 / ProMotion 修复报告

## 修复目标

用户反馈：

1. iPadOS 无法全屏。
2. 整体 UI 太大，挡住浏览器内容，可显示内容有限。
3. 动画太卡，需要适配 ProMotion / 120Hz。
4. 不要自动创建初始标签页。
5. 可以清除所有标签页。
6. Agent 按钮和任务列表按钮不要放在浏览器画面内，且与“给当前页设任务”重复。
7. 设置按钮进入独立设置页，不要放侧栏。

## 已完成修改

### 1. iPadOS 全屏

- `Info.plist` 新增：
  - `UIRequiresFullScreen = true`
  - `UIStatusBarHidden = true`
  - `UIViewControllerBasedStatusBarAppearance = false`
- `ContentView` 新增：
  - `.ignoresSafeArea(.container, edges: .all)`
  - `.statusBarHidden(true)`

说明：这会让 App 更偏全屏浏览器体验，减少 iPad 分屏/边框导致的非全屏感。

### 2. 紧凑 UI

- 左侧标签栏宽度改为 190–230pt。
- 右侧任务面板宽度改为 292–340pt。
- 主布局 padding 从 14pt 降到 8pt。
- 浏览器容器圆角、内边距降低。
- 任务卡片、标签卡片、缩略图、New Task 面板尺寸缩小。
- 浏览器内容区不再覆盖悬浮按钮。

### 3. ProMotion / 120Hz 友好优化

- `Info.plist` 新增：`CADisableMinimumFrameDurationOnPhone = true`。
- 所有主要面板切换动画统一为轻量 `interactiveSpring(response: 0.22, dampingFraction: 0.90)`。
- 减少 Liquid Glass fallback 的阴影半径、模糊半径和高透明叠层。
- 减少大面积半透明卡片和大阴影，降低重绘压力。

说明：iOS 不能让普通 App 手动强制所有动画 120fps，但可以解除最小帧时长限制，并减少重绘压力，让 ProMotion 设备更容易跑满高刷。

### 4. 标签页行为

- 首次启动不再自动打开任何网页。
- 关闭最后一个标签页后保持空状态，不再自动新建。
- 新增 `clearAllTabs()`：清空全部标签页并停止相关任务。
- 地址栏在无标签页时输入网址/关键词，会自动创建新标签并加载。

### 5. 按钮位置

- 删除浏览器 WebView 内右下角悬浮 `AgentFloatingButton`。
- 删除浏览器画面内任务列表入口。
- 当前页设任务入口保留在顶部工具栏，位于网页画面外。
- 任务管理入口保留在顶部工具栏 / 底部 Dock / 左侧栏，均不覆盖网页内容。

### 6. 设置页

- 设置不再作为右侧侧栏面板显示。
- 新增 `showingSettingsPage` 状态。
- 设置按钮打开独立 `NavigationStack` 设置页。
- API Key 缺失时直接进入设置页。

## 静态检查结果

- Swift 文件语法解析：OK。
- `Info.plist` 可解析：OK。
- `project.pbxproj` 版本号更新：OK。
- 无 `AgentFloatingButton` 残留引用：OK。
- 无自动创建初始 Google 标签逻辑：OK。
- zip 完整性：OK。

## 未完成/需真机确认

- Xcode 真机编译未在当前环境执行。
- iPadOS 全屏效果需在真实 iPad 上确认。
- ProMotion 流畅度需在 iPad Pro / iPhone Pro 真机确认。
- `UIRequiresFullScreen` 会禁用 iPad 多任务分屏，如需要分屏模式可在后续版本做开关或移除。
