# LiquidAIBrowser v1.4.3 Project Index

## 当前版本

- Version: 1.4.3
- Build: 10
- 重点：iPad Stage Manager/窗口化尺寸修复、LaunchScreen、窗口 sizing support、外部 App 跳转硬拦截、AI 原生浏览器导航。

## 关键新增文件

- `LiquidAIBrowser/WindowSizingSupport.swift`：iPad 窗口化尺寸限制与边距修复。
- `LiquidAIBrowser/LaunchScreen.storyboard`：iPad 启动尺寸识别 / 全屏适配。
- `QA_V14_3_WINDOW_EXTERNAL_FIX_REPORT.md`：本次修复报告。

## 主要源码

- `LiquidAIBrowser/ContentView.swift`：根布局、窗口填充、UI。
- `LiquidAIBrowser/BrowserStore.swift`：分组、页面、任务、原生加载 URL。
- `LiquidAIBrowser/WebViewPool.swift`：WKWebView 池、导航拦截、外部 scheme 拦截。
- `LiquidAIBrowser/AgentEngine.swift`：AI 动作执行，navigate 改为原生加载。

## 检查

- Info.plist OK
- project.pbxproj includes WindowSizingSupport.swift and LaunchScreen.storyboard
- swiftc -parse OK

# PROJECT_INDEX

版本：LiquidAIBrowser v1.4.2  
构建号：9

## 主要源码

- `LiquidAIBrowser/LiquidAIBrowserApp.swift`：App 入口，每个窗口独立 `BrowserStore`。
- `LiquidAIBrowser/BrowserModels.swift`：分组、页面、任务、动作、动态重规划和验收模型。
- `LiquidAIBrowser/BrowserStore.swift`：分组/页面/任务状态管理、URL 规整、抖音网页搜索规整。
- `LiquidAIBrowser/WebViewPool.swift`：WKWebView 池、JS bridge、DOM/坐标扫描、网页动作执行、阻止外部 App scheme。
- `LiquidAIBrowser/AgentEngine.swift`：Agent 规划、执行、动态重规划、最终验收、跨页面动作。
- `LiquidAIBrowser/AIClient.swift`：OpenAI-compatible API。
- `LiquidAIBrowser/AISettings.swift`：API 设置、Keychain、模型参数。
- `LiquidAIBrowser/ContentView.swift`：主界面、Stage Manager 响应式布局、分组栏、浏览器区域。
- `LiquidAIBrowser/Panels.swift`：任务面板、设置页、任务卡、日志/PDF 导出入口。
- `LiquidAIBrowser/LiquidGlassSupport.swift`：单色现代玻璃 UI fallback。
- `LiquidAIBrowser/PDFReportExporter.swift`：任务 PDF 报告导出。
- `LiquidAIBrowser/ActivityView.swift`：系统分享。

## 关键文档

- `README.md`：使用说明。
- `CHANGELOG.md`：版本更新记录。
- `QA_V14_2_STAGE_MANAGER_AGENT_FIX_REPORT.md`：本次修复报告。
- `AI_REVIEW_REQUIREMENTS.md`：需求/验收标准。
- 历史 QA 报告：保留在 zip 内。
