# Liquid AI Browser v1.1 自查与修复报告

## 检查范围

检查 v1.0 的 Xcode Project 结构、Info.plist、project.pbxproj、Swift 代码逻辑、WebView 注入脚本、Agent 循环、多标签逻辑、设置页、任务 UI、Liquid Glass 兼容层。

## 发现并修复的问题

### 1. project.pbxproj 存在重复逗号
- 问题：PBXGroup / PBXSourcesBuildPhase 中多处 `,,`，可能导致 Xcode 打开或解析失败。
- 修复：已清理所有重复逗号。
- 验证：`plutil -lint LiquidAIBrowser.xcodeproj/project.pbxproj` 通过。

### 2. 切换标签页可能仍显示旧 WKWebView
- 问题：`BrowserWebView` 的 `updateUIView` 为空，SwiftUI 复用 UIViewRepresentable 时可能不重新创建对应 tab 的 WKWebView。
- 修复：在 `BrowserWebView(tabID:)` 上添加 `.id(tab.id)`，切换标签时强制绑定正确 WebView。

### 3. 敏感操作确认会反复卡住
- 问题：v1.0 检测敏感动作后进入 waitingConfirmation，但没有保存待执行动作；用户点继续后 AI 可能再次返回同一敏感动作，导致无限确认。
- 修复：给 `AgentTask` 增加 `pendingAction`。检测敏感动作时保存；用户确认后先执行 pendingAction，再进入下一轮判断。

### 4. AI 返回 blocked 没有专门处理
- 问题：遇到验证码/登录/付款等 `blocked` 状态时，v1.0 可能继续循环或等待。
- 修复：`blocked` 现在会暂停任务，显示“需要用户处理”，写入日志，用户手动处理后可继续。

### 5. 同一标签页可能出现多个未结束任务
- 问题：v1.0 允许在已有 paused 任务时创建新任务，可能导致同一页面多个 Agent 争抢控制。
- 修复：同一 tab 只允许一个非终态任务。必须完成、停止或关闭后才能创建新任务。

### 6. `window.__liquidAgent` 未注入时执行动作会抛 JS 错误
- 问题：`performAction` 直接调用 `window.__liquidAgent.performAction`。
- 修复：增加 bridge not ready fallback，避免直接 JS 异常中断。

### 7. PointerEvent 不存在时点击可能失败
- 问题：某些 WebKit 场景 PointerEvent 不可用时，构造 PointerEvent 会抛错。
- 修复：PointerEvent 存在才派发；否则 fallback 到 MouseEvent / el.click()。

### 8. React/Vue 输入框兼容不够稳
- 问题：非标准输入元素或 contenteditable 输入可能不触发正确事件。
- 修复：增强 nativeSetValue，兼容 input、textarea、select-like value、contenteditable，并派发 input/change。

### 9. target=_blank / window.open 链接可能无响应
- 问题：没有 WKUIDelegate 的 createWebViewWith 处理。
- 修复：加入 WKUIDelegate，targetFrame nil 时在当前标签加载该请求。

### 10. JS alert / confirm / prompt 没处理
- 问题：网页 JS 弹窗可能无响应。
- 修复：加入 WKUIDelegate 弹窗处理，找不到 presenter 时自动 completion，避免卡死。

### 11. 固定三栏 UI 在窄屏设备不可用
- 问题：固定 290px 侧边栏 + 380px 面板可能在 iPhone 或窄屏 Stage Manager 下挤爆。
- 修复：增加 compact layout：窄屏隐藏侧边栏，底部 Dock 管理标签/任务/设置，面板浮层显示。

### 12. 刷新/停止按钮逻辑不准确
- 问题：loading 时按钮图标是 xmark，但动作仍 reload。
- 修复：loading 时执行 stopLoading，否则 reload。

### 13. Base URL 填完整 endpoint 时可能重复拼接
- 问题：用户填 `/chat/completions` 时会变成 `/chat/completions/chat/completions`。
- 修复：endpoint 拼接逻辑已识别完整 `/chat/completions` 和 `/models`。

### 14. OpenRouter headers 兼容性增强
- 问题：部分 OpenAI-compatible 服务对 HTTP-Referer/X-Title 更友好。
- 修复：chat 和 models 请求增加 HTTP-Referer/X-Title。

### 15. Liquid Glass 旧 SDK 编译风险
- 问题：旧 Xcode/旧 SDK 可能没有 `glassEffect` 符号。
- 修复：`LiquidGlassSupport.swift` 加 `#if compiler(>=6.2)`，新 SDK 用 glassEffect，旧编译器 fallback 到 ultraThinMaterial。

### 16. API Key 不方便清除
- 问题：v1.0 只能覆盖输入。
- 修复：设置页增加“清除”按钮。

## 已执行的静态检查

- `plutil -lint LiquidAIBrowser/Info.plist`：通过。
- `plutil -lint LiquidAIBrowser.xcodeproj/project.pbxproj`：通过。
- 从 Swift raw string 中提取 Agent Bridge JS，并执行 `node --check`：通过。
- 检查 Xcode project 是否包含所有 Swift 源文件：通过。
- 检查 zip 完整性：通过。

## 未能执行的检查

当前环境不是 macOS，没有 Xcode / iOS SDK，无法执行：

- `xcodebuild` 真机/模拟器编译。
- 真机 WKWebView 行为测试。
- iOS 27 Liquid Glass 实机效果确认。
- 真实第三方 API 连通测试。

## 建议外部 AI / 人工重点检查

1. 用 Xcode 打开 project.pbxproj 是否还有解析警告。
2. 用你的 Apple Developer Team 进行签名编译。
3. 检查 `glassEffect` 在你当前 Xcode / iOS SDK 的可用性。
4. 真机测试 target=_blank、JS alert、输入框、点击、任务暂停/继续。
5. 测试多个标签同时执行任务时，WebKit 是否对后台 tab 节流明显。
