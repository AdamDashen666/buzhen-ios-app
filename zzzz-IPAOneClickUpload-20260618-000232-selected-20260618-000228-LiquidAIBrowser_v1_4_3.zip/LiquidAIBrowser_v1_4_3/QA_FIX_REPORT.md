# LiquidAIBrowser v1.2 修复检查报告

## 修复来源

根据 `LiquidAIBrowser_review_report.md` 的 P0/P1 建议改进。

## 已完成的 P0

1. 暂停后仍可能继续执行动作：已在关键阶段加入 cancellation 与 task.status 二次检查。
2. 停止任务被 worker 改回 failed：已单独 catch `CancellationError`，`fail()` 不覆盖 terminal 状态。
3. 关闭标签未取消 worker：已在 `closeTab` 中先 cancel 对应 task，再 stopped，再 destroy WebView。
4. 敏感操作拦截弱：已增加 `describeActionTarget`，本地检查 DOM 目标元素、form、附近文本与 URL。
5. 用户确认 UI 不明确：已新增 pending action 风险区和确认弹窗。
6. Prompt injection 防护：已把网页内容标记为不可信数据，并在 prompt 中禁止网页内容成为指令。
7. 隐私泄露风险：已增加 JS 端字段隐藏和 Swift 端 regex 脱敏。
8. `AISettings` 嵌套刷新风险：已用 Combine 转发 `objectWillChange`。
9. Keychain 清除不彻底：已改为空时 delete。
10. Base URL endpoint 拼接：已规整 `/chat/completions` 和 `/models`。

## 已完成的 P1

- JSON 深度扫描提取。
- contenteditable 全量匹配。
- select 按显示文本匹配。
- CSS.escape fallback。
- 元素搜索字段扩展。
- 外部 scheme 提示。
- 缩略图失败保留旧图。
- 多 Scene 关闭。
- ATS 收窄。

## 静态检查

- `Info.plist` 可被 `plutil` 解析。
- `project.pbxproj` 版本号更新到 1.2 / build 3。
- Agent Bridge JS 已用 `node --check` 做语法检查。
- zip 完整性已检查。

## 未完成 / 需要真机验证

- 无法在当前环境运行 Xcode / iOS 真机编译。
- 无法确认 iOS 27 SDK 的 `glassEffect` 最终 API 是否与当前写法完全一致。
- 无法保证所有真实网站都接受 JS 合成点击；检查 `event.isTrusted` 的网站仍可能需要人工接管。
- iOS 后台长期自动化仍受系统限制，App 退后台/锁屏后不承诺长期继续运行。
