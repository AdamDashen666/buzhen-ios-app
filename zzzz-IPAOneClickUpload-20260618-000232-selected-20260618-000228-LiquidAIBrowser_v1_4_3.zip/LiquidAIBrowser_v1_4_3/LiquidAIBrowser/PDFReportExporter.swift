import Foundation
import UIKit

struct PDFReportExporter {
    static func export(task: AgentTask, tab: BrowserTab?, detailedLog: String) throws -> URL {
        let pageRect = CGRect(x: 0, y: 0, width: 595.2, height: 841.8)
        let renderer = UIGraphicsPDFRenderer(bounds: pageRect)
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("LiquidAIBrowser_Report_\(task.id.uuidString.prefix(8)).pdf")
        let margin: CGFloat = 36
        let width = pageRect.width - margin * 2
        let titleFont = UIFont.systemFont(ofSize: 22, weight: .bold)
        let hFont = UIFont.systemFont(ofSize: 14, weight: .bold)
        let bodyFont = UIFont.systemFont(ofSize: 11, weight: .regular)
        let captionFont = UIFont.systemFont(ofSize: 9, weight: .regular)
        let monoFont = UIFont.monospacedSystemFont(ofSize: 8.5, weight: .regular)
        let paragraph = NSMutableParagraphStyle(); paragraph.lineSpacing = 4; paragraph.paragraphSpacing = 8
        let smallParagraph = NSMutableParagraphStyle(); smallParagraph.lineSpacing = 3

        try renderer.writePDF(to: url) { context in
            func newPage() -> CGFloat { context.beginPage(); return margin }
            func ensure(_ y: inout CGFloat, _ height: CGFloat) { if y + height > pageRect.height - margin { y = newPage() } }
            func drawText(_ text: String, font: UIFont, color: UIColor = .label, y: inout CGFloat, maxWidth: CGFloat = width, style: NSParagraphStyle? = nil) {
                let attrs: [NSAttributedString.Key: Any] = [.font: font, .foregroundColor: color, .paragraphStyle: style ?? paragraph]
                let rect = NSString(string: text).boundingRect(with: CGSize(width: maxWidth, height: .greatestFiniteMagnitude), options: [.usesLineFragmentOrigin, .usesFontLeading], attributes: attrs, context: nil)
                ensure(&y, ceil(rect.height) + 8)
                NSString(string: text).draw(with: CGRect(x: margin, y: y, width: maxWidth, height: ceil(rect.height) + 5), options: [.usesLineFragmentOrigin, .usesFontLeading], attributes: attrs, context: nil)
                y += ceil(rect.height) + 10
            }
            func drawDivider(y: inout CGFloat) {
                ensure(&y, 12)
                UIColor.systemBlue.withAlphaComponent(0.25).setStroke()
                UIBezierPath(roundedRect: CGRect(x: margin, y: y, width: width, height: 1), cornerRadius: 0.5).stroke()
                y += 16
            }
            func drawMetricCards(y: inout CGFloat) {
                let duration = Int((task.finishedAt ?? Date()).timeIntervalSince(task.startedAt ?? task.createdAt))
                let values = [
                    ("进度", "\(Int(task.progress * 100))%"),
                    ("动作", "\(task.totalActionCount)"),
                    ("失败/重试", "\(task.failureCount)"),
                    ("运行时间", "\(duration)s")
                ]
                let cardW = (width - 18) / 4
                ensure(&y, 58)
                for (i, item) in values.enumerated() {
                    let x = margin + CGFloat(i) * (cardW + 6)
                    let rect = CGRect(x: x, y: y, width: cardW, height: 50)
                    UIColor.systemBlue.withAlphaComponent(0.08).setFill()
                    UIBezierPath(roundedRect: rect, cornerRadius: 10).fill()
                    (item.0 as NSString).draw(in: CGRect(x: x + 8, y: y + 8, width: cardW - 16, height: 14), withAttributes: [.font: captionFont, .foregroundColor: UIColor.secondaryLabel])
                    (item.1 as NSString).draw(in: CGRect(x: x + 8, y: y + 24, width: cardW - 16, height: 20), withAttributes: [.font: UIFont.systemFont(ofSize: 14, weight: .bold), .foregroundColor: UIColor.systemBlue])
                }
                y += 64
            }
            func drawImage(_ image: UIImage, title: String, y: inout CGFloat) {
                drawText(title, font: hFont, y: &y)
                ensure(&y, 190)
                let ratio = image.size.width > 0 ? image.size.height / image.size.width : 0.65
                let imgW: CGFloat = min(width, 360)
                let imgH: CGFloat = min(190, imgW * ratio)
                image.draw(in: CGRect(x: margin, y: y, width: imgW, height: imgH))
                y += imgH + 12
            }

            var y = newPage()
            drawText("Liquid AI Browser 任务报告", font: titleFont, color: .systemBlue, y: &y)
            drawText("状态：\(task.status.title)    生成时间：\(Date().formatted(date: .abbreviated, time: .standard))", font: bodyFont, color: .secondaryLabel, y: &y)
            drawMetricCards(y: &y)
            if let tab { drawText("网页：\(tab.displayTitle)\nURL：\(tab.urlString)", font: bodyFont, y: &y) }
            if let image = tab?.thumbnailImage { drawImage(image, title: "网页缩略图", y: &y) }
            if let data = task.lastScreenshotData, let image = UIImage(data: data) { drawImage(image, title: "最近一次 AI 视觉截图", y: &y) }
            drawDivider(y: &y)
            drawText("用户目标", font: hFont, y: &y)
            drawText(task.goal, font: bodyFont, y: &y)
            drawText("完成清单", font: hFont, y: &y)
            let checklistText = task.checklist.enumerated().map { index, item in
                "\(item.isDone ? "✓" : "○") \(index + 1). \(item.title)\n   \(item.detail)\(item.note.isEmpty ? "" : "\n   备注：\(item.note)")"
            }.joined(separator: "\n")
            drawText(checklistText.isEmpty ? "没有生成清单。" : checklistText, font: bodyFont, y: &y)
            drawText("总结报告", font: hFont, y: &y)
            drawText(task.report.isEmpty ? "任务尚未生成总结报告。" : task.report, font: bodyFont, y: &y)
            drawText("详细运行日志", font: hFont, y: &y)
            for line in detailedLog.split(separator: "\n", omittingEmptySubsequences: false) {
                drawText(String(line), font: monoFont, color: .secondaryLabel, y: &y, style: smallParagraph)
            }
        }
        return url
    }
}
