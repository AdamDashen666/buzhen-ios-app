import SwiftUI

extension View {
    @ViewBuilder
    func liquidGlassCard(cornerRadius: CGFloat = 18) -> some View {
        let shape = RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
        #if compiler(>=6.2)
        if #available(iOS 26.0, *) {
            self
                .glassEffect(.regular, in: shape)
                .overlay(shape.stroke(Color.white.opacity(0.10), lineWidth: 0.6))
                .shadow(color: .black.opacity(0.12), radius: 10, x: 0, y: 5)
        } else {
            self.modernFallbackBackground(shape: shape)
        }
        #else
        self.modernFallbackBackground(shape: shape)
        #endif
    }

    @ViewBuilder
    func liquidGlassCapsule() -> some View {
        #if compiler(>=6.2)
        if #available(iOS 26.0, *) {
            self
                .glassEffect(.regular, in: Capsule())
                .overlay(Capsule().stroke(Color.white.opacity(0.10), lineWidth: 0.6))
                .shadow(color: .black.opacity(0.10), radius: 8, x: 0, y: 4)
        } else {
            self.modernFallbackBackground(shape: Capsule())
        }
        #else
        self.modernFallbackBackground(shape: Capsule())
        #endif
    }

    private func modernFallbackBackground<S: Shape>(shape: S) -> some View {
        self
            .background(.thinMaterial, in: shape)
            .background(Color.white.opacity(0.026), in: shape)
            .overlay(shape.stroke(Color.white.opacity(0.09), lineWidth: 0.6))
            .shadow(color: .black.opacity(0.12), radius: 9, x: 0, y: 5)
    }
}

struct LiquidBackground: View {
    var body: some View {
        Color(red: 0.055, green: 0.057, blue: 0.064)
            .ignoresSafeArea()
    }
}
