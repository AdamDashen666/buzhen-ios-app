import SwiftUI
import UIKit

/// Keeps iPad Stage Manager / windowed iPadOS scenes freely resizable.
/// This does not force full-screen mode; it removes app-side minimum-size limits
/// so the OS can maximize or resize the window as far as the current iPad mode allows.
struct WindowSizingSupportView: UIViewRepresentable {
    func makeUIView(context: Context) -> WindowSizingProbeView { WindowSizingProbeView() }
    func updateUIView(_ uiView: WindowSizingProbeView, context: Context) { uiView.applyWindowSizing() }
}

final class WindowSizingProbeView: UIView {
    override func didMoveToWindow() {
        super.didMoveToWindow()
        applyWindowSizing()
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        applyWindowSizing()
    }

    func applyWindowSizing() {
        DispatchQueue.main.async { [weak self] in
            guard let self, let window = self.window, let scene = window.windowScene else { return }
            if UIDevice.current.userInterfaceIdiom == .pad {
                scene.sizeRestrictions?.minimumSize = CGSize(width: 320, height: 360)
                scene.sizeRestrictions?.maximumSize = CGSize(width: 10000, height: 10000)
            }
            window.clipsToBounds = false
            window.rootViewController?.additionalSafeAreaInsets = .zero
            window.rootViewController?.view.insetsLayoutMarginsFromSafeArea = false
            window.rootViewController?.viewRespectsSystemMinimumLayoutMargins = false
        }
    }
}
