import Foundation
import UIKit

struct BrowserGroup: Identifiable, Equatable, Codable {
    let id: UUID
    var name: String
    var createdAt: Date
    var updatedAt: Date

    init(id: UUID = UUID(), name: String = "新分组") {
        self.id = id
        self.name = name
        self.createdAt = Date()
        self.updatedAt = Date()
    }

    var displayName: String {
        let clean = name.trimmingCharacters(in: .whitespacesAndNewlines)
        return clean.isEmpty ? "新分组" : clean
    }
}

struct BrowserTab: Identifiable, Equatable, Codable {
    let id: UUID
    var groupID: UUID
    var title: String
    var urlString: String
    var isLoading: Bool
    var estimatedProgress: Double
    var createdAt: Date
    var updatedAt: Date
    var thumbnailData: Data?

    init(id: UUID = UUID(), groupID: UUID, title: String = "新页面", urlString: String = "about:blank", isLoading: Bool = false, estimatedProgress: Double = 0) {
        self.id = id
        self.groupID = groupID
        self.title = title
        self.urlString = urlString
        self.isLoading = isLoading
        self.estimatedProgress = estimatedProgress
        self.createdAt = Date()
        self.updatedAt = Date()
        self.thumbnailData = nil
    }

    enum CodingKeys: String, CodingKey {
        case id, groupID, title, urlString, isLoading, estimatedProgress, createdAt, updatedAt, thumbnailData
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        id = try container.decodeIfPresent(UUID.self, forKey: .id) ?? UUID()
        groupID = try container.decodeIfPresent(UUID.self, forKey: .groupID) ?? UUID(uuidString: "00000000-0000-0000-0000-000000000001")!
        title = try container.decodeIfPresent(String.self, forKey: .title) ?? "新页面"
        urlString = try container.decodeIfPresent(String.self, forKey: .urlString) ?? "about:blank"
        isLoading = try container.decodeIfPresent(Bool.self, forKey: .isLoading) ?? false
        estimatedProgress = try container.decodeIfPresent(Double.self, forKey: .estimatedProgress) ?? 0
        createdAt = try container.decodeIfPresent(Date.self, forKey: .createdAt) ?? Date()
        updatedAt = try container.decodeIfPresent(Date.self, forKey: .updatedAt) ?? Date()
        thumbnailData = try container.decodeIfPresent(Data.self, forKey: .thumbnailData)
    }

    var displayTitle: String {
        if !title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { return title }
        return URL(string: urlString)?.host ?? "新页面"
    }

    var thumbnailImage: UIImage? {
        guard let data = thumbnailData else { return nil }
        return UIImage(data: data)
    }
}

enum TaskStatus: String, Codable, CaseIterable, Hashable {
    case queued
    case planning
    case running
    case paused
    case waitingConfirmation
    case completed
    case failed
    case stopped

    var title: String {
        switch self {
        case .queued: return "排队中"
        case .planning: return "规划中"
        case .running: return "执行中"
        case .paused: return "已暂停"
        case .waitingConfirmation: return "等待确认"
        case .completed: return "已完成"
        case .failed: return "失败"
        case .stopped: return "已停止"
        }
    }

    var symbolName: String {
        switch self {
        case .queued: return "clock"
        case .planning: return "wand.and.stars"
        case .running: return "play.circle.fill"
        case .paused: return "pause.circle.fill"
        case .waitingConfirmation: return "exclamationmark.triangle.fill"
        case .completed: return "checkmark.circle.fill"
        case .failed: return "xmark.octagon.fill"
        case .stopped: return "stop.circle.fill"
        }
    }

    var isTerminal: Bool {
        self == .completed || self == .failed || self == .stopped
    }
}

enum TaskLogLevel: String, Codable, CaseIterable, Hashable, Identifiable {
    case info
    case action
    case visual
    case security
    case warning
    case error

    var id: String { rawValue }

    var title: String {
        switch self {
        case .info: return "信息"
        case .action: return "动作"
        case .visual: return "视觉"
        case .security: return "安全"
        case .warning: return "警告"
        case .error: return "错误"
        }
    }
}

struct TaskChecklistItem: Identifiable, Codable, Equatable {
    var id: UUID = UUID()
    var title: String
    var detail: String
    var isDone: Bool = false
    var note: String = ""
}

struct TaskLogEntry: Identifiable, Codable, Equatable {
    var id: UUID = UUID()
    var date: Date = Date()
    var level: TaskLogLevel = .info
    var elapsedSeconds: Double = 0
    var message: String
    var actionType: String? = nil
    var coordinates: String? = nil
    var result: String? = nil

    var compactLine: String {
        let time = String(format: "+%.1fs", elapsedSeconds)
        let coord = coordinates.map { " @(\($0))" } ?? ""
        let action = actionType.map { " [\($0)]" } ?? ""
        return "[\(time)] [\(level.title)]\(action)\(coord) \(message)"
    }
}

struct AgentTask: Identifiable, Equatable, Codable {
    let id: UUID
    var groupID: UUID
    var tabID: UUID
    var workingTabIDs: [UUID]
    var goal: String
    var goalAnalysis: String
    var status: TaskStatus
    var checklist: [TaskChecklistItem]
    var log: [TaskLogEntry]
    var report: String
    var progress: Double
    var currentAction: String
    var pendingAction: AgentAction?
    var pendingActionRisk: String
    var lastError: String
    var iteration: Int
    var maxIterations: Int
    var createdAt: Date
    var updatedAt: Date
    var startedAt: Date?
    var finishedAt: Date?
    var queueIndex: Int
    var totalActionCount: Int
    var failureCount: Int
    var lastFailureCategory: String
    var lastScreenshotAt: Date?
    var lastScreenshotData: Data?

    init(id: UUID = UUID(), groupID: UUID, tabID: UUID, goal: String, maxIterations: Int, queueIndex: Int = 0) {
        self.id = id
        self.groupID = groupID
        self.tabID = tabID
        self.workingTabIDs = [tabID]
        self.goal = goal
        self.goalAnalysis = ""
        self.status = .queued
        self.checklist = []
        self.log = [TaskLogEntry(message: "任务已创建：\(goal)")]
        self.report = ""
        self.progress = 0
        self.currentAction = "等待开始"
        self.pendingAction = nil
        self.pendingActionRisk = ""
        self.lastError = ""
        self.iteration = 0
        self.maxIterations = maxIterations
        self.createdAt = Date()
        self.updatedAt = Date()
        self.startedAt = nil
        self.finishedAt = nil
        self.queueIndex = queueIndex
        self.totalActionCount = 0
        self.failureCount = 0
        self.lastFailureCategory = ""
        self.lastScreenshotAt = nil
        self.lastScreenshotData = nil
    }

    enum CodingKeys: String, CodingKey {
        case id, groupID, tabID, workingTabIDs, goal, goalAnalysis, status, checklist, log, report, progress, currentAction, pendingAction, pendingActionRisk, lastError, iteration, maxIterations, createdAt, updatedAt, startedAt, finishedAt, queueIndex, totalActionCount, failureCount, lastFailureCategory, lastScreenshotAt, lastScreenshotData
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        id = try container.decodeIfPresent(UUID.self, forKey: .id) ?? UUID()
        let fallbackGroupID = UUID(uuidString: "00000000-0000-0000-0000-000000000001")!
        groupID = try container.decodeIfPresent(UUID.self, forKey: .groupID) ?? fallbackGroupID
        tabID = try container.decodeIfPresent(UUID.self, forKey: .tabID) ?? UUID()
        workingTabIDs = try container.decodeIfPresent([UUID].self, forKey: .workingTabIDs) ?? [tabID]
        goal = try container.decodeIfPresent(String.self, forKey: .goal) ?? ""
        goalAnalysis = try container.decodeIfPresent(String.self, forKey: .goalAnalysis) ?? ""
        status = try container.decodeIfPresent(TaskStatus.self, forKey: .status) ?? .queued
        checklist = try container.decodeIfPresent([TaskChecklistItem].self, forKey: .checklist) ?? []
        log = try container.decodeIfPresent([TaskLogEntry].self, forKey: .log) ?? []
        report = try container.decodeIfPresent(String.self, forKey: .report) ?? ""
        progress = try container.decodeIfPresent(Double.self, forKey: .progress) ?? 0
        currentAction = try container.decodeIfPresent(String.self, forKey: .currentAction) ?? "等待开始"
        pendingAction = try container.decodeIfPresent(AgentAction.self, forKey: .pendingAction)
        pendingActionRisk = try container.decodeIfPresent(String.self, forKey: .pendingActionRisk) ?? ""
        lastError = try container.decodeIfPresent(String.self, forKey: .lastError) ?? ""
        iteration = try container.decodeIfPresent(Int.self, forKey: .iteration) ?? 0
        maxIterations = try container.decodeIfPresent(Int.self, forKey: .maxIterations) ?? 18
        createdAt = try container.decodeIfPresent(Date.self, forKey: .createdAt) ?? Date()
        updatedAt = try container.decodeIfPresent(Date.self, forKey: .updatedAt) ?? Date()
        startedAt = try container.decodeIfPresent(Date.self, forKey: .startedAt)
        finishedAt = try container.decodeIfPresent(Date.self, forKey: .finishedAt)
        queueIndex = try container.decodeIfPresent(Int.self, forKey: .queueIndex) ?? 0
        totalActionCount = try container.decodeIfPresent(Int.self, forKey: .totalActionCount) ?? 0
        failureCount = try container.decodeIfPresent(Int.self, forKey: .failureCount) ?? 0
        lastFailureCategory = try container.decodeIfPresent(String.self, forKey: .lastFailureCategory) ?? ""
        lastScreenshotAt = try container.decodeIfPresent(Date.self, forKey: .lastScreenshotAt)
        lastScreenshotData = try container.decodeIfPresent(Data.self, forKey: .lastScreenshotData)
    }
}

struct APIPreset: Identifiable, Hashable {
    var id: String { name }
    let name: String
    let baseURL: String
    let defaultModel: String
}

struct AgentAction: Codable, Equatable {
    var type: String
    var selector: String?
    var text: String?
    var value: String?
    var url: String?
    var direction: String?
    var amount: Int?
    var stepIndex: Int?
    var reason: String?
    var x: Double?
    var y: Double?
    var startX: Double?
    var startY: Double?
    var endX: Double?
    var endY: Double?
    var durationMs: Int?
    var tabID: String?
    var tabHint: String?
    var groupName: String?
    var key: String?
    var modifiers: [String]?
}

struct AgentDecision: Codable {
    var status: String?
    var summary: String?
    var completedStepIndexes: [Int]?
    var action: AgentAction?
    var report: String?
    var goalAnalysis: String?
    var updatedSteps: [AgentPlanResponse.Step]?
    var restartPlan: Bool?
}

struct AgentVerification: Codable {
    var ok: Bool
    var summary: String
    var report: String?
    var missingSteps: [AgentPlanResponse.Step]?
}

struct AgentPlanResponse: Codable {
    struct Step: Codable {
        var title: String
        var detail: String?
    }
    var goalAnalysis: String?
    var steps: [Step]
}

struct AgentActionResult: Codable {
    var ok: Bool
    var message: String
    var category: String?
    var x: Double?
    var y: Double?
    var targetText: String?
    var tabID: UUID? = nil
}

struct AISettingsSnapshot {
    let apiKey: String
    let baseURL: String
    let model: String
    let temperature: Double
    let requestTimeout: Double
    let useJSONMode: Bool
    let enableVisionScreenshots: Bool
    let allowCoordinateFallback: Bool
    let maxActionRetries: Int
}

struct ShareItem: Identifiable {
    let id = UUID()
    let url: URL
}
