# Liquid AI Browser v1.4.2

独立 iOS/iPadOS AI 浏览器。支持分组、多页面、多任务、AI 自动规划和执行网页操作。

## v1.4.2 重点

- 适配 iPadOS 台前调度和窗口化拉伸。
- 启动为空白页，不默认打开 Google。
- 背景改为单一深色，UI 更简洁现代。
- Agent 设任务前会先扫描当前页。
- 每一步后检查，可动态修改计划或从头重规划。
- 全部完成后做最终验收，失败会自动补步骤。
- 取消敏感操作确认弹窗。
- 支持直接输入网址并前往网页。
- 支持直接修改当前网页内容。
- 修复抖音搜索误打开 iPad 抖音 App：外部 App scheme 会被拦截，抖音搜索规整为 Web URL。

## 打开方式

1. 解压 zip。
2. 打开 `LiquidAIBrowser.xcodeproj`。
3. 选择 `LiquidAIBrowser` target。
4. 设置自己的 Team / Bundle ID。
5. 真机运行。
6. 在设置页填写 API Key、Base URL、模型。

## 注意

- App 前台时，后台页面任务可继续调度；App 退后台或锁屏后，iPadOS 可能挂起任务。
- 坐标/点击/键盘/修改网页动作都是 WebView 内 JS 合成事件，不等于系统级真手指。
- 视觉截图辅助需要模型支持图片输入。
