# LiquidAIBrowser v1.4.3：iPad 窗口化 / 全屏贴边 / 外部 App 跳转修复报告

## 修复目标

1. 修复 iPadOS 台前调度 / 窗口化下窗口无法尽量贴满、拉伸不自然的问题。
2. 修复 AI 或网页导航时仍可能跳转到抖音 App、App Store 或其他外部软件的问题。
3. 让 AI 的 `navigate` 行为改为由 App 原生浏览器加载，而不是网页 JS 直接 `location.href` 跳转。

## 关键判断

- iPad 的台前调度 / 窗口化最大化由系统控制，App 不能强行覆盖系统窗口栏、Dock、台前调度边距。
- App 能做的是：支持 iPad multitasking、提供完整 launch screen、不要设置过大的最小窗口尺寸、根视图铺满窗口、不要在内容层再加外边距。
- 外部 App 跳转必须在 `WKNavigationDelegate` 层硬拦截，不能只靠 AI prompt 提醒。

## 代码修改

### 1. Info.plist

- `UIRequiresFullScreen = false`：保留窗口化 / Stage Manager 支持。
- `UIApplicationSupportsMultipleScenes = true`：保留 iPad 多窗口能力。
- 新增 `UILaunchStoryboardName = LaunchScreen`。
- 版本更新：`1.4.3 / build 10`。

### 2. LaunchScreen.storyboard

新增 `LaunchScreen.storyboard` 并加入 Xcode Resources，避免 iPad 兼容模式或启动尺寸识别异常导致的非全屏/黑边/letterbox 风险。

### 3. WindowSizingSupport.swift

新增窗口尺寸探针：

- iPad 上设置 `windowScene.sizeRestrictions?.minimumSize = 320x360`。
- 设置 `maximumSize = 10000x10000`。
- 清理 root view 的额外 safe area inset 和系统最小 layout margin。

目的：减少 App 自身对台前调度窗口大小的限制，让系统可以尽量拉伸窗口。

### 4. ContentView.swift

- 根视图增加 `ignoresSafeArea(.container, edges: .all)`。
- 挂载 `WindowSizingSupportView()`。
- 移除 RegularRootLayout 外层 4pt padding。
- Compact 布局减少顶部/左右 padding。

### 5. WebViewPool.swift

- 新增 `shouldLoadInsideBrowser(_:)`。
- 只允许 `http / https / about / file` 在内置浏览器加载。
- 所有非网页 scheme 一律取消：`douyin://`、`snssdk://`、`aweme://`、`itms-apps://`、`mailto:`、`tel:` 等。
- `createWebViewWith` 也加入同样拦截，防止 target=_blank 或 window.open 绕过。

### 6. AgentEngine.swift + BrowserStore.swift

- AI 的 `navigate` 不再交给网页 JS 执行。
- 改为调用 `BrowserStore.loadURLInTab(tabID:urlString:)`，由 App 原生 WKWebView 加载。
- 这样“去某个网站/搜索某内容”会在当前内置浏览器页面打开，不会通过系统外跳。

## 已做静态检查

- `Info.plist`：OK
- `project.pbxproj`：LaunchScreen / WindowSizingSupport 已加入 Sources / Resources
- `swiftc -parse LiquidAIBrowser/*.swift`：OK
- 版本号：1.4.3 / build 10

## 仍需真机验证

1. iPadOS 台前调度：窗口拖到最大后是否比 v1.4.2 更贴边。
2. iPadOS 26 窗口化：拖拽窗口四角是否可以自由变大/变小。
3. 抖音搜索：让 AI “去抖音搜索 MacBook”，确认仍停留在 App 内 WKWebView。
4. 点击网页内“打开 App”按钮，确认被拦截并弹提示。

## 已知边界

- App 不能覆盖 iPadOS 系统级窗口边框、标题栏、Dock、台前调度系统边距。
- 如果系统当前处于窗口化模式，App 只能填满自己的窗口内容区，不能强制占满整个屏幕。
- 若用户需要真正全屏，需要在 iPadOS 的窗口控制里选择全屏，或关闭台前调度/切换全屏模式。
