import Foundation
import Metal
import CoreVideo

final class MetalFrameRenderer {
    private let device: MTLDevice
    private let commandQueue: MTLCommandQueue
    private let textureCache: CVMetalTextureCache
    private let flowPipeline: MTLComputePipelineState

    init() throws {
        guard let device = MTLCreateSystemDefaultDevice() else {
            throw NSError(domain: "BuzhenLocal", code: 3001, userInfo: [NSLocalizedDescriptionKey: "当前设备不支持 Metal"])
        }

        guard let commandQueue = device.makeCommandQueue() else {
            throw NSError(domain: "BuzhenLocal", code: 3002, userInfo: [NSLocalizedDescriptionKey: "无法创建 Metal 队列"])
        }

        var cache: CVMetalTextureCache?
        CVMetalTextureCacheCreate(nil, nil, device, nil, &cache)

        guard let textureCache = cache else {
            throw NSError(domain: "BuzhenLocal", code: 3003, userInfo: [NSLocalizedDescriptionKey: "无法创建 Metal 纹理缓存"])
        }

        guard let library = device.makeDefaultLibrary(),
              let flowFunction = library.makeFunction(name: "flowWarpBlend") else {
            throw NSError(domain: "BuzhenLocal", code: 3004, userInfo: [NSLocalizedDescriptionKey: "无法加载 Metal Shader"])
        }

        self.device = device
        self.commandQueue = commandQueue
        self.textureCache = textureCache
        self.flowPipeline = try device.makeComputePipelineState(function: flowFunction)
    }

    func renderOpticalFlowBlend(
        previous: CVPixelBuffer,
        next: CVPixelBuffer,
        flow: CVPixelBuffer,
        alpha: Float,
        pixelBufferPool: CVPixelBufferPool?
    ) throws -> CVPixelBuffer {
        let output = try makeOutputBuffer(like: previous, pool: pixelBufferPool)

        let texA = try makeTexture(from: previous, pixelFormat: .bgra8Unorm)
        let texB = try makeTexture(from: next, pixelFormat: .bgra8Unorm)
        let texFlow = try makeTexture(from: flow, pixelFormat: .rg32Float)
        let texOut = try makeTexture(from: output, pixelFormat: .bgra8Unorm)

        var params = FlowParams(alpha: alpha)

        try encode(
            pipeline: flowPipeline,
            textures: [texA, texB, texFlow, texOut],
            bytes: &params,
            byteCount: MemoryLayout<FlowParams>.stride
        )

        return output
    }

    private func makeOutputBuffer(like source: CVPixelBuffer, pool: CVPixelBufferPool?) throws -> CVPixelBuffer {
        var out: CVPixelBuffer?

        if let pool {
            CVPixelBufferPoolCreatePixelBuffer(nil, pool, &out)
        }

        if out == nil {
            let attrs: [String: Any] = [
                kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA,
                kCVPixelBufferWidthKey as String: CVPixelBufferGetWidth(source),
                kCVPixelBufferHeightKey as String: CVPixelBufferGetHeight(source),
                kCVPixelBufferMetalCompatibilityKey as String: true,
                kCVPixelBufferIOSurfacePropertiesKey as String: [:]
            ]

            CVPixelBufferCreate(
                nil,
                CVPixelBufferGetWidth(source),
                CVPixelBufferGetHeight(source),
                kCVPixelFormatType_32BGRA,
                attrs as CFDictionary,
                &out
            )
        }

        guard let out else {
            throw NSError(domain: "BuzhenLocal", code: 3005, userInfo: [NSLocalizedDescriptionKey: "无法创建输出帧"])
        }

        return out
    }

    private func makeTexture(from pixelBuffer: CVPixelBuffer, pixelFormat: MTLPixelFormat) throws -> MTLTexture {
        let width = CVPixelBufferGetWidth(pixelBuffer)
        let height = CVPixelBufferGetHeight(pixelBuffer)

        var cvTexture: CVMetalTexture?
        let status = CVMetalTextureCacheCreateTextureFromImage(
            nil,
            textureCache,
            pixelBuffer,
            nil,
            pixelFormat,
            width,
            height,
            0,
            &cvTexture
        )

        guard status == kCVReturnSuccess,
              let cvTexture,
              let texture = CVMetalTextureGetTexture(cvTexture) else {
            throw NSError(domain: "BuzhenLocal", code: 3006, userInfo: [NSLocalizedDescriptionKey: "无法创建 Metal 纹理"])
        }

        return texture
    }

    private func encode(
        pipeline: MTLComputePipelineState,
        textures: [MTLTexture],
        bytes: UnsafeRawPointer,
        byteCount: Int
    ) throws {
        guard let commandBuffer = commandQueue.makeCommandBuffer(),
              let encoder = commandBuffer.makeComputeCommandEncoder() else {
            throw NSError(domain: "BuzhenLocal", code: 3007, userInfo: [NSLocalizedDescriptionKey: "无法创建 Metal 命令"])
        }

        encoder.setComputePipelineState(pipeline)

        for (index, texture) in textures.enumerated() {
            encoder.setTexture(texture, index: index)
        }

        encoder.setBytes(bytes, length: byteCount, index: 0)

        let width = pipeline.threadExecutionWidth
        let height = max(1, pipeline.maxTotalThreadsPerThreadgroup / width)
        let group = MTLSize(width: width, height: height, depth: 1)
        let grid = MTLSize(width: textures.last!.width, height: textures.last!.height, depth: 1)

        encoder.dispatchThreads(grid, threadsPerThreadgroup: group)
        encoder.endEncoding()

        commandBuffer.commit()
        commandBuffer.waitUntilCompleted()

        if let error = commandBuffer.error {
            throw error
        }
    }
}

struct FlowParams {
    let alpha: Float
}
