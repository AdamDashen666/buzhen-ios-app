#include <metal_stdlib>
using namespace metal;

struct FlowParams {
    float alpha;
};

kernel void flowWarpBlend(
    texture2d<float, access::sample> previous [[texture(0)]],
    texture2d<float, access::sample> next [[texture(1)]],
    texture2d<float, access::sample> flow [[texture(2)]],
    texture2d<float, access::write> output [[texture(3)]],
    constant FlowParams &params [[buffer(0)]],
    uint2 gid [[thread_position_in_grid]]
) {
    if (gid.x >= output.get_width() || gid.y >= output.get_height()) {
        return;
    }

    constexpr sampler s(address::clamp_to_edge, filter::linear);

    float alpha = clamp(params.alpha, 0.0, 1.0);
    float2 size = float2(output.get_width(), output.get_height());
    float2 uv = (float2(gid) + 0.5) / size;

    float2 flowUV = (float2(gid) + 0.5) / float2(flow.get_width(), flow.get_height());
    float2 motion = flow.sample(s, flowUV).xy;

    // 简化双向光流采样：
    // previous 按 alpha 往 next 方向推，next 按 1-alpha 往 previous 方向拉。
    float2 prevUV = uv - (motion * alpha) / size;
    float2 nextUV = uv + (motion * (1.0 - alpha)) / size;

    float4 a = previous.sample(s, prevUV);
    float4 b = next.sample(s, nextUV);

    output.write(mix(a, b, alpha), gid);
}
