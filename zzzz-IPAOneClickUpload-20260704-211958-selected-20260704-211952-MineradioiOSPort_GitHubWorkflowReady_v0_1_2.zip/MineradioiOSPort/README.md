# Mineradio iOS Port MVP

这是一个 **Mineradio 风格的 iOS / iPadOS SwiftUI 原生移植尝试版**。它不是 Electron 套壳，而是用 SwiftUI、AVFoundation、Canvas 重做了移动端原型。

## 已实现

- 本地 MP3 / FLAC / M4A / WAV 文件导入与播放
- 沉浸式粒子背景
- 歌词舞台 UI
- 3D 歌单架 / 音乐卡片
- 网易云第三方 API 服务地址配置
- 网易云二维码登录流程：`/login/qr/key`、`/login/qr/create`、`/login/qr/check`
- 网易云搜索、获取播放 URL、歌词解析
- QQ / Custom API 设置入口：先留了 Base URL + Cookie/Token 位，具体接口模板可按你使用的第三方服务补上
- App Icon、默认封面、背景图资源

## 打开方式

1. 用 Xcode 打开 `MineradioiOS.xcodeproj`
2. 选择 Team / Signing
3. 运行到 iPhone / iPad / Simulator

推荐环境：Xcode 16+、iOS 17+


## GitHub Actions 打包

这个版本已整理成 GitHub workflow 可识别的结构：

```text
Project: MineradioiOS.xcodeproj
Scheme: MineradioiOS
Configuration: Release
SDK: iphoneos
```

已包含共享 scheme：

```text
MineradioiOS.xcodeproj/xcshareddata/xcschemes/MineradioiOS.xcscheme
```

也附带独立 workflow：

```text
.github/workflows/build-app.yml
```

如果用你已有的“自动找 zip → 解压 → xcodebuild → Payload 打 IPA”的 workflow，直接上传这个 zip 即可。

## 网易云 API 服务

本 App 不内置 Node 服务。你需要自己运行第三方 API，例如 `Binaryify/NeteaseCloudMusicApi`。

```bash
# 在电脑或服务器上
npm install
node app.js
```

然后在 App 设置里填：

- iOS Simulator：`http://127.0.0.1:3000`
- 真机 / iPad：`http://你的电脑局域网IP:3000`

注意：真机不能用 `localhost` 指向电脑，需要用电脑的局域网 IP，并允许防火墙访问。

## 学习用途说明

这个项目只做技术学习和个人自用原型。第三方音乐接口、账号登录、播放链接可能受平台规则、版权、地区和账号状态影响。不要用于绕过付费、版权限制或公开分发。

## 文件结构

```text
MineradioiOS/
├── MineradioiOSApp.swift
├── ContentView.swift
├── Models.swift
├── PlayerController.swift
├── LocalLibraryStore.swift
├── SettingsStore.swift
├── APIClient.swift
├── NetEaseService.swift
├── QQGenericService.swift
├── LyricParser.swift
├── Views/
└── Assets.xcassets/
```
