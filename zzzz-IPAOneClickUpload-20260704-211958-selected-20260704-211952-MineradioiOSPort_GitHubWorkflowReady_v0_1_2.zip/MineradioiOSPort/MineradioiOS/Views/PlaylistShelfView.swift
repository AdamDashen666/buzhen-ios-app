import SwiftUI
import UniformTypeIdentifiers

struct PlaylistShelfView: View {
    @EnvironmentObject private var library: LocalLibraryStore
    @EnvironmentObject private var player: PlayerController
    @State private var isImporterPresented = false
    @State private var errorMessage: String?

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text("3D Local Shelf")
                        .font(.title2.bold())
                        .foregroundStyle(.white)
                    Text("导入本地音乐后会出现在这里")
                        .font(.caption)
                        .foregroundStyle(.white.opacity(0.62))
                }
                Spacer()
                Button {
                    isImporterPresented = true
                } label: {
                    Label("Import", systemImage: "plus")
                        .font(.headline)
                        .padding(.horizontal, 16)
                        .padding(.vertical, 10)
                        .background(.white.opacity(0.16), in: Capsule())
                }
                .foregroundStyle(.white)
            }

            if library.songs.isEmpty {
                GlassPanel {
                    VStack(spacing: 10) {
                        Image(systemName: "music.note.list")
                            .font(.system(size: 38))
                        Text("还没有本地音乐")
                            .font(.headline)
                        Text("点 Import 选 MP3 / FLAC / M4A / WAV")
                            .font(.caption)
                            .foregroundStyle(.white.opacity(0.7))
                    }
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity)
                }
            } else {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 18) {
                        ForEach(library.songs) { song in
                            LocalSongCard(song: song) {
                                guard let url = library.fileURL(for: song) else { return }
                                player.playLocal(song: song, fileURL: url)
                            }
                            .contextMenu {
                                Button(role: .destructive) {
                                    library.delete(song)
                                } label: {
                                    Label("Delete", systemImage: "trash")
                                }
                            }
                        }
                    }
                    .padding(.vertical, 14)
                }
            }
        }
        .fileImporter(
            isPresented: $isImporterPresented,
            allowedContentTypes: [.audio],
            allowsMultipleSelection: true
        ) { result in
            Task {
                do {
                    let urls = try result.get()
                    for url in urls {
                        try await library.importAudioFile(from: url)
                    }
                } catch {
                    errorMessage = error.localizedDescription
                }
            }
        }
        .alert("导入失败", isPresented: Binding(get: { errorMessage != nil }, set: { if !$0 { errorMessage = nil } })) {
            Button("OK", role: .cancel) { errorMessage = nil }
        } message: {
            Text(errorMessage ?? "")
        }
    }
}

private struct LocalSongCard: View {
    let song: SongItem
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            VStack(alignment: .leading, spacing: 12) {
                Image("DefaultCover")
                    .resizable()
                    .scaledToFill()
                    .frame(width: 160, height: 160)
                    .clipShape(RoundedRectangle(cornerRadius: 28, style: .continuous))
                    .overlay(alignment: .bottomTrailing) {
                        Image(systemName: "play.fill")
                            .foregroundStyle(.black)
                            .padding(10)
                            .background(.white, in: Circle())
                            .padding(10)
                    }

                Text(song.title)
                    .font(.headline)
                    .foregroundStyle(.white)
                    .lineLimit(1)
                Text(song.artist)
                    .font(.caption)
                    .foregroundStyle(.white.opacity(0.62))
                    .lineLimit(1)
            }
            .frame(width: 180)
            .padding(14)
            .background(.white.opacity(0.10), in: RoundedRectangle(cornerRadius: 34, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 34, style: .continuous).stroke(.white.opacity(0.12)))
            .rotation3DEffect(.degrees(-7), axis: (x: 0, y: 1, z: 0))
        }
        .buttonStyle(.plain)
    }
}
