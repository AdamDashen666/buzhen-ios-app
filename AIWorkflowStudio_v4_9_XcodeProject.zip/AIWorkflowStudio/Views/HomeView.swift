import SwiftUI
import Foundation
import UniformTypeIdentifiers

struct HomeView: View {
    @EnvironmentObject private var store: AppStore
    @State private var exportDocument: WorkflowJSONDocument?
    @State private var isShowingImporter = false
    @State private var isImportingWorkflow = false
    @State private var renameProjectID: UUID?
    @State private var renameText = ""
    @State private var isShowingRenameDialog = false

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    hero
                    projectGuide
                    recentProjects
                }
                .padding()
            }
            .studioBackground()
            .navigationTitle("AI Workflow Studio")
            .fileExporter(
                isPresented: Binding(
                    get: { exportDocument != nil },
                    set: { if !$0 { exportDocument = nil } }
                ),
                document: exportDocument,
                contentType: .json,
                defaultFilename: store.exportFileNameForSelectedProject()
            ) { result in
                if case .failure(let error) = result {
                    store.appAlert = AppAlert(title: "导出失败", message: error.localizedDescription)
                }
                exportDocument = nil
            }
            .fileImporter(
                isPresented: $isShowingImporter,
                allowedContentTypes: WorkflowImportTypes.allowed,
                allowsMultipleSelection: false
            ) { result in
                switch result {
                case .success(let urls):
                    guard let url = urls.first else { return }
                    isImportingWorkflow = true
                    DispatchQueue.main.async {
                        store.importWorkflow(from: url)
                        isImportingWorkflow = false
                    }
                case .failure(let error):
                    store.appAlert = AppAlert(title: "导入失败", message: error.localizedDescription)
                }
            }
            .overlay {
                if isImportingWorkflow {
                    ProgressView("正在导入工作流…")
                        .padding(18)
                        .liquidGlass()
                }
            }
            .alert("重命名工作流", isPresented: $isShowingRenameDialog) {
                TextField("工作流名称", text: $renameText)
                Button("取消", role: .cancel) {
                    renameProjectID = nil
                    renameText = ""
                }
                Button("保存") {
                    if let id = renameProjectID {
                        store.renameProject(projectID: id, title: renameText)
                    }
                    renameProjectID = nil
                    renameText = ""
                }
            } message: {
                Text("修改首页和工作流页显示的项目名称。")
            }
        }
    }

    private var hero: some View {
        VStack(alignment: .leading, spacing: 14) {
            Label("可视化多 AI 工作流", systemImage: "sparkles")
                .font(.title.bold())
            Text("首页负责项目管理、导入和导出。提示词、上传图片、AI 自动选择模块和运行按钮都在“工作流”里。")
                .foregroundStyle(.secondary)
            HStack(spacing: 10) {
                InfoPill(icon: "rectangle.3.group", text: "模块化")
                InfoPill(icon: "cable.connector", text: "手动连线")
                InfoPill(icon: "archivebox", text: "真实 ZIP")
                InfoPill(icon: "square.and.arrow.down", text: "工作流导入导出")
            }
            .lineLimit(1)
            HStack(spacing: 10) {
                Button {
                    store.createProject(title: "AI 工作流项目")
                } label: {
                    Label("新建空白项目", systemImage: "plus.circle.fill")
                        .font(.headline)
                }
                .buttonStyle(.borderedProminent)

                Button {
                    guard let data = store.exportSelectedProjectData() else { return }
                    exportDocument = WorkflowJSONDocument(data: data)
                } label: {
                    Label("导出当前工作流", systemImage: "square.and.arrow.up")
                }
                .buttonStyle(.bordered)
                .disabled(store.selectedProject == nil)

                Button {
                    isShowingImporter = true
                } label: {
                    Label("导入工作流", systemImage: "square.and.arrow.down")
                }
                .buttonStyle(.bordered)
                .disabled(isImportingWorkflow)
            }
        }
        .liquidGlass()
    }

    private var projectGuide: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("页面说明")
                .font(.headline)
            GuideRow(icon: "house", title: "首页", text: "项目管理、新建项目、导入/导出工作流。导出不包含 API Key。")
            GuideRow(icon: "point.3.connected.trianglepath.dotted", title: "工作流", text: "写需求、上传图片、添加模块、拖端口连线、缩放画布、运行。")
            GuideRow(icon: "gearshape", title: "设置", text: "添加 API、刷新模型、选择 Token 总限制方式、查看错误日志。")
        }
        .liquidGlass()
    }

    private var recentProjects: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("最近项目")
                .font(.headline)
            if store.projects.isEmpty {
                ContentUnavailableView("暂无项目", systemImage: "folder.badge.plus", description: Text("点击上方“新建空白项目”开始。"))
            } else {
                ForEach(store.projects) { project in
                    HStack(alignment: .center, spacing: 12) {
                            Image(systemName: "square.stack.3d.up")
                                .font(.title2)
                                .frame(width: 34)
                            VStack(alignment: .leading, spacing: 4) {
                                Text(project.title).font(.headline)
                                Text("节点：\(project.nodes.count) · 连线：\(project.edges.count) · 更新：\(project.updatedAt.formatted(date: .abbreviated, time: .shortened))")
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                                Text("用途：点击选择这个项目，再进入“工作流”编辑。")
                                    .font(.caption2)
                                    .foregroundStyle(.secondary)
                            }
                            Spacer()
                            Button {
                                renameProjectID = project.id
                                renameText = project.title
                                isShowingRenameDialog = true
                            } label: {
                                Label("重命名", systemImage: "pencil")
                                    .labelStyle(.iconOnly)
                            }
                            .buttonStyle(.bordered)
                            .controlSize(.small)

                            if store.selectedProjectID == project.id {
                                Image(systemName: "checkmark.circle.fill")
                                    .foregroundStyle(.cyan)
                            }
                    }
                    .padding()
                    .contentShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                    .onTapGesture { store.selectedProjectID = project.id }
                    .background(.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous).stroke(.white.opacity(0.12)))
                }
            }
        }
        .liquidGlass()
    }
}

private enum WorkflowImportTypes {
    static var allowed: [UTType] {
        var types: [UTType] = [.json]
        if let zip = UTType(filenameExtension: "zip") { types.append(zip) }
        if let workflow = UTType(filenameExtension: "workflow") { types.append(workflow) }
        types.append(.data)
        return types
    }
}

struct WorkflowJSONDocument: FileDocument {
    static var readableContentTypes: [UTType] { [.json, .data] }

    var data: Data

    init(data: Data = Data()) {
        self.data = data
    }

    init(configuration: ReadConfiguration) throws {
        data = configuration.file.regularFileContents ?? Data()
    }

    func fileWrapper(configuration: WriteConfiguration) throws -> FileWrapper {
        FileWrapper(regularFileWithContents: data)
    }
}

private struct GuideRow: View {
    var icon: String
    var title: String
    var text: String

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: icon)
                .frame(width: 26)
                .foregroundStyle(.cyan)
            VStack(alignment: .leading, spacing: 2) {
                Text(title).font(.subheadline.bold())
                Text(text).font(.caption).foregroundStyle(.secondary)
            }
        }
    }
}
