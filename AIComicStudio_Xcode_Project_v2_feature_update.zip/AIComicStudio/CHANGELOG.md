# AIComicStudio Changelog

## v2.0 Feature Update

- API 设置里 Max Tokens、Temperature、超时、页数、每页分镜等数值项改为直接输入具体数值。
- 图片生成预设新增火山方舟 Seedream，Base URL 预设为 `https://ark.cn-beijing.volces.com/api/v3`。
- Seedream 图片尺寸自动修正：低于 3,686,400 像素时自动升到 1536×2400 / 1920×1920 / 2400×1536，修复火山 400 size 错误。
- UI 全局改成 Liquid Glass 风格：超薄材质卡片、柔和高光、玻璃背景。
- 创作页新增“AI 自动决定页数/分镜”与“我手动设置”模式。
- 页面工作区新增 PDF 导出，可选择全部或部分页面。
- 每个 Panel 分镜支持单独重画，并保存单独的分镜图片、状态与错误。
- 图片 Prompt 增强角色一致性锚点，锁定角色脸型、发型、服装、配色、年龄与身份特征。
- 保留 FINAL2 的 Info.plist iOS 必需字段修复。
