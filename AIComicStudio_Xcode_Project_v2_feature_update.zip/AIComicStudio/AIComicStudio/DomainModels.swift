import Foundation
import SwiftUI

enum CreationMode: String, Codable, CaseIterable, Identifiable {
    case story = "story"
    case idea = "idea"

    var id: String { rawValue }
    var title: String {
        switch self {
        case .story: return "已有故事"
        case .idea: return "AI 写故事"
        }
    }

    var explanation: String {
        switch self {
        case .story: return "粘贴完整故事，AI 自动拆角色、分镜和页面。"
        case .idea: return "输入几个提示词或设定，AI 先补成完整故事，再拆角色、分镜和页面。"
        }
    }
}

enum GenerationStatus: String, Codable, CaseIterable {
    case draft = "草稿"
    case planning = "规划中"
    case planned = "已规划"
    case generating = "生成中"
    case generated = "已生成"
    case failed = "失败"
}

enum ComicStyle: String, CaseIterable, Codable, Identifiable {
    case anime = "Anime"
    case japaneseManga = "Japanese Manga"
    case shonen = "Shonen Manga"
    case shojo = "Shojo Manga"
    case manhwaWebtoon = "Korean Manhwa / Webtoon"
    case americanComic = "American Comic Book"
    case noirGraphicNovel = "Noir Graphic Novel"
    case cyberpunkManga = "Cyberpunk Manga"
    case chineseManhua = "Chinese Manhua"
    case watercolor = "Watercolor Storybook"
    case pixelComic = "Pixel Comic"
    case fourKoma = "4-Koma Comedy"

    var id: String { rawValue }
    var displayName: String { rawValue }

    var promptStyle: String {
        switch self {
        case .anime:
            return "clean anime illustration, expressive faces, cinematic lighting, crisp line art, dynamic composition"
        case .japaneseManga:
            return "black and white Japanese manga, screentone shading, ink linework, dramatic panel flow, authentic manga layout"
        case .shonen:
            return "high-energy shonen manga, speed lines, action poses, bold inks, emotional facial expressions"
        case .shojo:
            return "shojo manga, elegant linework, soft lighting, floral effects, delicate facial expressions, romantic panel composition"
        case .manhwaWebtoon:
            return "vertical webtoon manhwa style, clean digital colors, cinematic closeups, modern Korean comic lighting"
        case .americanComic:
            return "American comic book style, bold outlines, halftone texture, dramatic superhero lighting, strong color blocking"
        case .noirGraphicNovel:
            return "noir graphic novel, moody shadows, high contrast, rain-soaked atmosphere, cinematic black ink composition"
        case .cyberpunkManga:
            return "cyberpunk manga, neon city lights, futuristic fashion, holograms, high contrast blue and magenta lighting"
        case .chineseManhua:
            return "Chinese manhua style, polished digital painting, elegant costumes, expressive action, clean dramatic layout"
        case .watercolor:
            return "watercolor storybook comic, soft brush texture, warm colors, gentle expressions, readable family-friendly layout"
        case .pixelComic:
            return "pixel art comic, retro game style, limited palette, blocky expressive characters, clean comic panels"
        case .fourKoma:
            return "Japanese 4-koma comedy comic, simple readable panels, cute expressions, clear punchline timing"
        }
    }
}

struct CharacterProfile: Identifiable, Codable, Hashable {
    var id: UUID = UUID()
    var name: String
    var role: String
    var personality: String
    var visualDescription: String
    var outfit: String
    var colorPalette: String
    var promptAnchor: String

    enum CodingKeys: String, CodingKey { case id, name, role, personality, visualDescription, outfit, colorPalette, promptAnchor }

    init(id: UUID = UUID(), name: String, role: String, personality: String, visualDescription: String, outfit: String, colorPalette: String, promptAnchor: String) {
        self.id = id
        self.name = name
        self.role = role
        self.personality = personality
        self.visualDescription = visualDescription
        self.outfit = outfit
        self.colorPalette = colorPalette
        self.promptAnchor = promptAnchor
    }

    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        id = try c.decodeIfPresent(UUID.self, forKey: .id) ?? UUID()
        name = try c.decodeIfPresent(String.self, forKey: .name) ?? "Unnamed"
        role = try c.decodeIfPresent(String.self, forKey: .role) ?? ""
        personality = try c.decodeIfPresent(String.self, forKey: .personality) ?? ""
        visualDescription = try c.decodeIfPresent(String.self, forKey: .visualDescription) ?? ""
        outfit = try c.decodeIfPresent(String.self, forKey: .outfit) ?? ""
        colorPalette = try c.decodeIfPresent(String.self, forKey: .colorPalette) ?? ""
        promptAnchor = try c.decodeIfPresent(String.self, forKey: .promptAnchor) ?? ""
    }
}

struct DialogueLine: Identifiable, Codable, Hashable {
    var id: UUID = UUID()
    var speaker: String
    var text: String
    var emotion: String

    enum CodingKeys: String, CodingKey { case id, speaker, text, emotion }

    init(id: UUID = UUID(), speaker: String, text: String, emotion: String) {
        self.id = id
        self.speaker = speaker
        self.text = text
        self.emotion = emotion
    }

    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        id = try c.decodeIfPresent(UUID.self, forKey: .id) ?? UUID()
        speaker = try c.decodeIfPresent(String.self, forKey: .speaker) ?? ""
        text = try c.decodeIfPresent(String.self, forKey: .text) ?? ""
        emotion = try c.decodeIfPresent(String.self, forKey: .emotion) ?? ""
    }
}

struct ComicPanel: Identifiable, Codable, Hashable {
    var id: UUID = UUID()
    var panelNumber: Int
    var shotType: String
    var setting: String
    var action: String
    var visualPrompt: String
    var narration: String
    var dialogue: [DialogueLine]
    var characters: [String]
    var camera: String
    var mood: String
    var imageData: Data?
    var generatedAt: Date?
    var status: GenerationStatus
    var errorMessage: String?

    enum CodingKeys: String, CodingKey { case id, panelNumber, shotType, setting, action, visualPrompt, narration, dialogue, characters, camera, mood, imageData, generatedAt, status, errorMessage }

    init(
        id: UUID = UUID(),
        panelNumber: Int,
        shotType: String,
        setting: String,
        action: String,
        visualPrompt: String,
        narration: String,
        dialogue: [DialogueLine],
        characters: [String],
        camera: String,
        mood: String,
        imageData: Data? = nil,
        generatedAt: Date? = nil,
        status: GenerationStatus = .planned,
        errorMessage: String? = nil
    ) {
        self.id = id
        self.panelNumber = panelNumber
        self.shotType = shotType
        self.setting = setting
        self.action = action
        self.visualPrompt = visualPrompt
        self.narration = narration
        self.dialogue = dialogue
        self.characters = characters
        self.camera = camera
        self.mood = mood
        self.imageData = imageData
        self.generatedAt = generatedAt
        self.status = status
        self.errorMessage = errorMessage
    }

    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        id = try c.decodeIfPresent(UUID.self, forKey: .id) ?? UUID()
        panelNumber = try c.decodeIfPresent(Int.self, forKey: .panelNumber) ?? 1
        shotType = try c.decodeIfPresent(String.self, forKey: .shotType) ?? ""
        setting = try c.decodeIfPresent(String.self, forKey: .setting) ?? ""
        action = try c.decodeIfPresent(String.self, forKey: .action) ?? ""
        visualPrompt = try c.decodeIfPresent(String.self, forKey: .visualPrompt) ?? ""
        narration = try c.decodeIfPresent(String.self, forKey: .narration) ?? ""
        dialogue = try c.decodeIfPresent([DialogueLine].self, forKey: .dialogue) ?? []
        characters = try c.decodeIfPresent([String].self, forKey: .characters) ?? []
        camera = try c.decodeIfPresent(String.self, forKey: .camera) ?? ""
        mood = try c.decodeIfPresent(String.self, forKey: .mood) ?? ""
        imageData = try c.decodeIfPresent(Data.self, forKey: .imageData)
        generatedAt = try c.decodeIfPresent(Date.self, forKey: .generatedAt)
        status = try c.decodeIfPresent(GenerationStatus.self, forKey: .status) ?? .planned
        errorMessage = try c.decodeIfPresent(String.self, forKey: .errorMessage)
    }
}

struct ComicPage: Identifiable, Codable, Hashable {
    var id: UUID = UUID()
    var pageNumber: Int
    var title: String
    var summary: String
    var pagePrompt: String
    var continuityNotes: String
    var panels: [ComicPanel]
    var imageData: Data?
    var generatedAt: Date?
    var status: GenerationStatus
    var errorMessage: String?

    enum CodingKeys: String, CodingKey { case id, pageNumber, title, summary, pagePrompt, continuityNotes, panels, imageData, generatedAt, status, errorMessage }

    init(
        id: UUID = UUID(),
        pageNumber: Int,
        title: String,
        summary: String,
        pagePrompt: String,
        continuityNotes: String,
        panels: [ComicPanel],
        imageData: Data? = nil,
        generatedAt: Date? = nil,
        status: GenerationStatus = .planned,
        errorMessage: String? = nil
    ) {
        self.id = id
        self.pageNumber = pageNumber
        self.title = title
        self.summary = summary
        self.pagePrompt = pagePrompt
        self.continuityNotes = continuityNotes
        self.panels = panels
        self.imageData = imageData
        self.generatedAt = generatedAt
        self.status = status
        self.errorMessage = errorMessage
    }

    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        id = try c.decodeIfPresent(UUID.self, forKey: .id) ?? UUID()
        pageNumber = try c.decodeIfPresent(Int.self, forKey: .pageNumber) ?? 1
        title = try c.decodeIfPresent(String.self, forKey: .title) ?? "Page"
        summary = try c.decodeIfPresent(String.self, forKey: .summary) ?? ""
        pagePrompt = try c.decodeIfPresent(String.self, forKey: .pagePrompt) ?? ""
        continuityNotes = try c.decodeIfPresent(String.self, forKey: .continuityNotes) ?? ""
        panels = try c.decodeIfPresent([ComicPanel].self, forKey: .panels) ?? []
        imageData = try c.decodeIfPresent(Data.self, forKey: .imageData)
        generatedAt = try c.decodeIfPresent(Date.self, forKey: .generatedAt)
        status = try c.decodeIfPresent(GenerationStatus.self, forKey: .status) ?? .planned
        errorMessage = try c.decodeIfPresent(String.self, forKey: .errorMessage)
    }
}

struct ComicProject: Identifiable, Codable, Hashable {
    var id: UUID = UUID()
    var title: String
    var sourceInput: String
    var generatedStory: String
    var mode: CreationMode
    var style: ComicStyle
    var pageCount: Int
    var panelsPerPage: Int
    var createdAt: Date
    var updatedAt: Date
    var logline: String
    var characters: [CharacterProfile]
    var pages: [ComicPage]
    var status: GenerationStatus

    init(
        id: UUID = UUID(),
        title: String,
        sourceInput: String,
        generatedStory: String,
        mode: CreationMode,
        style: ComicStyle,
        pageCount: Int,
        panelsPerPage: Int,
        createdAt: Date = Date(),
        updatedAt: Date = Date(),
        logline: String,
        characters: [CharacterProfile],
        pages: [ComicPage],
        status: GenerationStatus = .draft
    ) {
        self.id = id
        self.title = title
        self.sourceInput = sourceInput
        self.generatedStory = generatedStory
        self.mode = mode
        self.style = style
        self.pageCount = pageCount
        self.panelsPerPage = panelsPerPage
        self.createdAt = createdAt
        self.updatedAt = updatedAt
        self.logline = logline
        self.characters = characters
        self.pages = pages
        self.status = status
    }
}

extension ComicProject {
    static let empty = ComicProject(
        title: "新漫画项目",
        sourceInput: "",
        generatedStory: "",
        mode: .story,
        style: .anime,
        pageCount: 4,
        panelsPerPage: 4,
        logline: "",
        characters: [],
        pages: [],
        status: .draft
    )

    static let sample = ComicProject(
        title: "Rain City Chase",
        sourceInput: "A young courier discovers a glowing memory chip in a rainy neon city.",
        generatedStory: "In a city where memories can be bought, a courier named Rin finds a forbidden chip that belongs to a missing scientist.",
        mode: .idea,
        style: .cyberpunkManga,
        pageCount: 3,
        panelsPerPage: 4,
        logline: "A courier must protect a stolen memory before the city erases the truth.",
        characters: [
            CharacterProfile(name: "Rin", role: "Courier protagonist", personality: "fast, nervous, loyal", visualDescription: "teen courier with short black hair and sharp eyes", outfit: "yellow rain jacket, messenger bag", colorPalette: "yellow, black, electric blue", promptAnchor: "Rin, short black hair, yellow rain jacket, messenger bag, sharp determined eyes"),
            CharacterProfile(name: "Kade", role: "Hunter antagonist", personality: "cold, patient, precise", visualDescription: "tall masked agent with silver hair", outfit: "dark tactical coat, glowing visor", colorPalette: "black, silver, red", promptAnchor: "Kade, silver hair, dark tactical coat, red glowing visor, silent hunter")
        ],
        pages: [
            ComicPage(
                pageNumber: 1,
                title: "The Chip",
                summary: "Rin finds a glowing chip after a crash in the rain.",
                pagePrompt: "A rainy neon alley comic page where Rin kneels beside a broken drone and finds a glowing memory chip while Kade watches from a rooftop.",
                continuityNotes: "Keep Rin's yellow rain jacket and messenger bag visible. Kade only appears as a distant silhouette.",
                panels: [
                    ComicPanel(panelNumber: 1, shotType: "Wide shot", setting: "rainy neon alley", action: "Rin runs through puddles", visualPrompt: "neon signs reflected in puddles, Rin sprinting", narration: "Rain City never sleeps.", dialogue: [], characters: ["Rin"], camera: "low wide angle", mood: "urgent"),
                    ComicPanel(panelNumber: 2, shotType: "Close-up", setting: "crashed drone", action: "Rin picks up a glowing chip", visualPrompt: "glowing blue chip in Rin's hand", narration: "Then something impossible fell from the sky.", dialogue: [DialogueLine(speaker: "Rin", text: "What are you?", emotion: "shocked")], characters: ["Rin"], camera: "hand close-up", mood: "mysterious")
                ]
            )
        ],
        status: .planned
    )
}
