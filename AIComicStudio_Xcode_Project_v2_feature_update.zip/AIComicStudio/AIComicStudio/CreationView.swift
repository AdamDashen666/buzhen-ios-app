import SwiftUI

struct CreationView: View {
    @EnvironmentObject private var store: ProjectStore
    @EnvironmentObject private var apiSettings: APISettings

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                SectionHeader(
                    title: "AI 漫画制作",
                    subtitle: "输入故事或关键词，AI 可自动决定页数/分镜，也可以按你输入的页数和每页分镜生成。"
                )

                GlassCard(title: "基础设置") {
                    TextField("项目标题", text: Binding(get: { store.project.title }, set: { store.project.title = $0; store.save() }))
                        .textFieldStyle(.roundedBorder)

                    Picker("创作模式", selection: Binding(get: { store.project.mode }, set: { store.project.mode = $0; store.save() })) {
                        ForEach(CreationMode.allCases) { mode in Text(mode.title).tag(mode) }
                    }
                    .pickerStyle(.segmented)

                    Text(store.project.mode.explanation)
                        .font(.footnote)
                        .foregroundStyle(.secondary)

                    Picker("漫画风格", selection: Binding(get: { store.project.style }, set: { store.project.style = $0; store.save() })) {
                        ForEach(ComicStyle.allCases) { style in Text(style.displayName).tag(style) }
                    }

                    Picker("页数和分镜规划", selection: $store.aiControlsLayout) {
                        Text("AI 自动决定").tag(true)
                        Text("我手动设置").tag(false)
                    }
                    .pickerStyle(.segmented)

                    if store.aiControlsLayout {
                        Text("AI 会根据剧情节奏决定总页数和每页分镜数。适合一键自动漫画。")
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                    } else {
                        HStack(spacing: 14) {
                            VStack(alignment: .leading) {
                                Text("页数")
                                    .font(.caption.weight(.semibold))
                                TextField("4", value: Binding(get: { store.project.pageCount }, set: { store.project.pageCount = max(1, min($0, 30)); store.save() }), format: .number)
                                    .keyboardType(.numberPad)
                                    .textFieldStyle(.roundedBorder)
                            }
                            VStack(alignment: .leading) {
                                Text("每页分镜")
                                    .font(.caption.weight(.semibold))
                                TextField("4", value: Binding(get: { store.project.panelsPerPage }, set: { store.project.panelsPerPage = max(1, min($0, 8)); store.save() }), format: .number)
                                    .keyboardType(.numberPad)
                                    .textFieldStyle(.roundedBorder)
                            }
                        }
                    }
                }

                GlassCard(title: store.project.mode == .story ? "粘贴故事" : "输入提示词 / 世界观 / 人物想法") {
                    TextEditor(text: Binding(get: { store.project.sourceInput }, set: { store.project.sourceInput = $0; store.save() }))
                        .frame(minHeight: 220)
                        .padding(10)
                        .background(Color(.secondarySystemBackground).opacity(0.5), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                        .overlay(RoundedRectangle(cornerRadius: 18).strokeBorder(.secondary.opacity(0.16)))

                    HStack {
                        LoadingButton(isLoading: store.isBusy) { Task { await store.planComic(settings: apiSettings) } } label: {
                            Label("自动规划漫画", systemImage: "sparkles")
                        }
                        .buttonStyle(.borderedProminent)

                        LoadingButton(isLoading: store.isBusy) { Task { await store.generateAllPages(settings: apiSettings) } } label: {
                            Label("一键生成所有页", systemImage: "photo.stack")
                        }
                        .buttonStyle(.bordered)

                        Spacer()
                        StatusPill(status: store.project.status)
                    }
                }

                if !store.project.logline.isEmpty || !store.project.generatedStory.isEmpty {
                    GlassCard(title: "AI 故事结果") {
                        if !store.project.logline.isEmpty { Text(store.project.logline).font(.title3.weight(.semibold)) }
                        if !store.project.generatedStory.isEmpty { Text(store.project.generatedStory).font(.body).foregroundStyle(.secondary) }
                    }
                }
            }
            .padding(24)
        }
        .background(LiquidGlassBackground())
    }
}
