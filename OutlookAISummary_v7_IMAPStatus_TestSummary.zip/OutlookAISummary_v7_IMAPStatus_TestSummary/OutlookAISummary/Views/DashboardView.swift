import SwiftUI

struct DashboardView: View {
    @EnvironmentObject private var state: AppState

    var body: some View {
        ZStack {
            LiquidBackground()
            ScrollView {
                VStack(spacing: 18) {
                    header
                    if let warning = state.backendValidationMessage {
                        backendWarningCard(warning)
                    }
                    statusCard
                    connectionCheckCard
                    if state.linkedUser != nil {
                        controlCard
                        summariesList
                    } else {
                        loginCard
                    }
                    if let error = state.lastError, !error.isEmpty {
                        errorCard(error)
                    }
                }
                .padding()
                .frame(maxWidth: 860)
                .frame(maxWidth: .infinity)
            }
            .refreshable { await state.refreshAll() }
        }
        .navigationTitle("总览")
        .toolbar {
            Button("刷新") { Task { await state.refreshAll() } }
        }
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Mail AI Summary")
                .font(.largeTitle.bold())
            Text("自动总结转发到 QQ 邮箱的未读邮件；默认中文推送。")
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }


    private func backendWarningCard(_ message: String) -> some View {
        GlassCard {
            VStack(alignment: .leading, spacing: 10) {
                Label("需要先配置后端", systemImage: "server.rack")
                    .font(.headline)
                Text(message)
                    .font(.footnote)
                    .textSelection(.enabled)
                Text("设置 → 后端地址：填 Render/Railway/Vercel/自建服务器的 HTTPS 地址。")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
            }
            .foregroundStyle(.orange.opacity(0.95))
        }
    }

    private var statusCard: some View {
        GlassCard {
            VStack(alignment: .leading, spacing: 14) {
                HStack {
                    Image(systemName: state.linkedUser == nil ? "link.badge.plus" : "checkmark.seal.fill")
                        .font(.title2)
                    VStack(alignment: .leading, spacing: 3) {
                        Text(state.linkedUser == nil ? "未连接邮箱" : "邮箱已连接")
                            .font(.headline)
                        Text(state.statusText)
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                    }
                    Spacer()
                    if state.isLoading { ProgressView().tint(.white) }
                }
                HStack(spacing: 8) {
                    CapsuleTag(text: state.settings.frequency.title, systemImage: "clock")
                    CapsuleTag(text: "中文", systemImage: "textformat")
                    CapsuleTag(text: state.backendHealth?.provider ?? "后端未检查", systemImage: "server.rack")
                    CapsuleTag(text: state.imapStatus?.ok == true ? "IMAP 正常" : "IMAP 未检查", systemImage: "envelope.badge")
                }
            }
        }
    }


    private var connectionCheckCard: some View {
        GlassCard {
            VStack(alignment: .leading, spacing: 14) {
                HStack {
                    SectionTitle(title: "后端连接检查", subtitle: "检查 Render 后端是否在线，以及 QQ 邮箱 IMAP 是否可读取。")
                    Spacer()
                    Button {
                        Task { await state.refreshBackendConnection() }
                    } label: {
                        Image(systemName: "arrow.clockwise")
                            .font(.headline)
                    }
                }

                VStack(alignment: .leading, spacing: 8) {
                    connectionRow("后端服务", state.backendHealth?.ok == true ? "正常" : "未连接", ok: state.backendHealth?.ok == true)
                    connectionRow("邮件模式", state.backendHealth?.provider ?? "未读取", ok: state.backendHealth?.provider == "imap")
                    connectionRow("QQ IMAP", state.imapStatus?.ok == true ? "正常" : (state.imapStatus?.error ?? "未检查"), ok: state.imapStatus?.ok == true)
                    if let imap = state.imapStatus, imap.ok {
                        infoRow("邮箱", imap.account ?? "未返回")
                        infoRow("IMAP", imap.host ?? "未返回")
                        infoRow("未读", "\(imap.unseen ?? 0) / 总邮件 \(imap.messages ?? 0)")
                    }
                    Text(state.connectionStatus)
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
                .textSelection(.enabled)
            }
        }
    }

    private func connectionRow(_ title: String, _ value: String, ok: Bool) -> some View {
        HStack(alignment: .top, spacing: 8) {
            Image(systemName: ok ? "checkmark.circle.fill" : "exclamationmark.triangle.fill")
                .foregroundStyle(ok ? .green : .orange)
            infoRow(title, value)
        }
        .font(.footnote)
    }

    private func infoRow(_ title: String, _ value: String) -> some View {
        HStack(alignment: .top, spacing: 8) {
            Text(title)
                .foregroundStyle(.secondary)
                .frame(width: 72, alignment: .leading)
            Text(value)
                .frame(maxWidth: .infinity, alignment: .leading)
        }
        .font(.footnote)
    }

    private var loginCard: some View {
        GlassCard {
            VStack(alignment: .leading, spacing: 14) {
                SectionTitle(title: "连接邮箱后端", subtitle: "QQ 邮箱模式不需要 Microsoft 登录；后端使用 QQ 邮箱授权码读取 IMAP。")
                Button {
                    state.openMailConnectionInfo()
                } label: {
                    Label("查看连接说明", systemImage: "person.crop.circle.badge.checkmark")
                }
                .buttonStyle(PrimaryButtonStyle())
                .disabled(state.backendValidationMessage != nil)
                .opacity(state.backendValidationMessage == nil ? 1 : 0.45)

                Button {
                    Task { await state.refreshAll() }
                } label: {
                    Label("我已配置，检查状态", systemImage: "arrow.clockwise")
                }
                .buttonStyle(PrimaryButtonStyle())
            }
        }
    }

    private var controlCard: some View {
        GlassCard {
            VStack(alignment: .leading, spacing: 14) {
                SectionTitle(title: "测试 AI 总结", subtitle: "立即读取当前 QQ 邮箱未读邮件并生成一次总结；后端会把已总结邮件标记为已读。")
                Button {
                    Task { await state.runNow() }
                } label: {
                    Label("测试总结当前邮件", systemImage: "sparkles")
                }
                .buttonStyle(PrimaryButtonStyle())
                .disabled(state.imapStatus?.ok != true || state.isLoading)
                .opacity((state.imapStatus?.ok == true && !state.isLoading) ? 1 : 0.45)

                Text(state.testSummaryStatus)
                    .font(.footnote)
                    .foregroundStyle(.secondary)
                    .textSelection(.enabled)

                Button {
                    state.requestNotifications()
                } label: {
                    Label("开启推送通知", systemImage: "bell.badge.fill")
                }
                .buttonStyle(PrimaryButtonStyle())
            }
        }
    }

    private var summariesList: some View {
        VStack(alignment: .leading, spacing: 12) {
            SectionTitle(title: "历史总结", subtitle: state.summaries.isEmpty ? "暂无总结。" : nil)
            ForEach(state.summaries) { summary in
                GlassCard {
                    VStack(alignment: .leading, spacing: 12) {
                        HStack {
                            Text(summary.title)
                                .font(.headline)
                            Spacer()
                            Text(summary.createdAt.shortDisplayDate)
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                        HStack(spacing: 8) {
                            CapsuleTag(text: "未读 \(summary.unreadCount)", systemImage: "envelope.badge")
                            CapsuleTag(text: "转发 \(summary.junkUnreadCount)", systemImage: "trash")
                        }
                        Text(summary.content)
                            .font(.body)
                            .textSelection(.enabled)
                    }
                }
            }
        }
    }

    private func errorCard(_ message: String) -> some View {
        GlassCard {
            VStack(alignment: .leading, spacing: 8) {
                Label("错误", systemImage: "exclamationmark.triangle.fill")
                    .font(.headline)
                Text(message)
                    .font(.footnote)
                    .textSelection(.enabled)
            }
            .foregroundStyle(.red.opacity(0.9))
        }
    }
}

private extension String {
    var shortDisplayDate: String {
        let formatter = ISO8601DateFormatter()
        guard let date = formatter.date(from: self) else { return self }
        return date.formatted(date: .abbreviated, time: .shortened)
    }
}
